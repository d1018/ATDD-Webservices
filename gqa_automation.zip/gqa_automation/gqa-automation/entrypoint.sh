#!/bin/bash

while getopts "e:p:c:t:f:r:" flag; do
    case $flag in
        e) environment=$OPTARG ;;
        p) product=$OPTARG ;;
        c) client=$OPTARG ;;
        t) test_type=$OPTARG ;;
        f) feature=$OPTARG ;;
        r) region=$OPTARG ;;
        *) exit 1 ;;
    esac
done

for param in environment product client test_type; do
  echo $param
    if [ -z "${!param}" ]; then
        echo "$param is required"
        exit 1
    fi
done

product_lcase="$(tr [:upper:] [:lower:] <<< "$product")"

feature_validator='[a-zA-Z0-9_-]+\.feature'

if [[ -n "$feature" && ! "$feature" =~ $feature_validator ]]; then
  echo "invalid feature name"
  exit 1
fi

npm install
cp .suitestrc.shadow .suitestrc
export CLIENT=$client

[ "$region" != "none" ] && export GEO=$region
[ "$client" == "hwa" ] && export DEVICE=$test_type

echo "environment ${environment}"
echo "product: ${product}"
echo "product_lcase ${product_lcase}"
echo "client ${client}"
echo "test_type ${test_type}"
echo "region ${region}"

npx jake "utils:setEnvVars[$environment,$product_lcase,$client,$test_type,$region]"

echo "Available Tasks: "
npx jake --tasks

if [ -n "$feature" ]; then
  echo "running jake"
  npx jake "$product:$client[$feature]"
else
  echo "running jake ${product}:${client}"
  npx jake $product:$client
fi
