class SignInScreen {
  get node() {
    return {
      sampleScr: { xpath: `` },
    };
  }

  get label() {
    return {
      sampleLbl: { xpath: `` },
    };
  }

  get poster() {
    return {
      samplePstr: { xpath: `` },
    };
  }

  get button() {
    return {
      sampleBtn: { xpath: `` },
    };
  }

  get popUpMessage() {
    return {
      sampleMsg: { xpath: `` },
    };
  }

  get inputField() {
    return {
      sampleInpt: { xpath: `` },
    };
  }
}

module.exports = new SignInScreen();
