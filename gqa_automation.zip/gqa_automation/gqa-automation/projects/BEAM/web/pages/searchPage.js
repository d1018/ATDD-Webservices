const assert = require('assert');
const { BasePage, browserActions, testdataHelper } = require('./basePage');

const commons = browserActions;

const content = {
  query: testdataHelper.getContent('searchPage.query'),
};

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  searchButton = this.#getSelectorData('searchButton');

  searchInput = this.#getSelectorData('searchInput');

  enterSearchQuery = async (contentType) => {
    await commons.waitUntil(this.searchInput, 40);
    await commons.sendText(this.searchInput, content[contentType]);
  };

  verifySearchQuery = async (contentType) => {
    await commons.waitUntil(this.searchInput, 40);
    const searchText = await commons.getAttribute(
      this.searchInput,
      'value',
      40,
    );

    assert(
      content[contentType] === searchText,
      `Search prompt is not replaced with Expected : ${content[contentType]} Actual : ${searchText}`,
    );
  };

  verifySearchResult = async (contentType) => {
    assert(
      await commons.isDisplayed(
        { xpath: `//p/*[contains(text(), '${content[contentType]}')]` },
        30,
      ),
      `Search result does not show up searched content search text: ${content[contentType]}`,
    );
  };
}

module.exports = new SearchPage();
