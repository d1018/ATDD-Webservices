const path = require('path');
const {
  browserActions,
  customErrors,
  testdataHelper,
} = require('@wbd/gqa-core/support');

const ymlpath = path.resolve(__dirname);

const EnvBase = require('../../../support/env');

const { skipReason } = require('../../../support/skipReason');

const commons = browserActions;
let episodeNameText;

let showNameText;

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }

  #getSelectorData(locator) {
    return this.getElementByPage('basePage', locator);
  }

  myListRail_lbl = this.#getSelectorData('myListRail_lbl');

  networkRail_lbl = this.#getSelectorData('networkRail_lbl');

  recommendedForYouRail_lbl = this.#getSelectorData(
    'recommendedForYouRail_lbl',
  );

  railsList = {
    'My List': this.#getSelectorData('myListRail_lbl'),
    Network: this.#getSelectorData('networkRail_lbl'),
    'Recommended for You': this.#getSelectorData('recommendedForYouRail_lbl'),
  };

  returnRandomNumber = (len) => {
    const randomNumber = Math.floor(Math.random() * len);

    return `${randomNumber}`;
  };

  getShowNameText() {
    return showNameText;
  }

  setShowNameText(showName) {
    showNameText = showName;
  }

  getEpisodeNameText() {
    return episodeNameText;
  }

  setEpisodeNameText(episodeName) {
    episodeNameText = episodeName;
  }

  scrollToRail = async (railName) => {
    if (await commons.isDisplayed(this.railsList[railName])) {
      await commons.scrollToElement(this.railsList[railName]);
      return true;
    }
    return false;
  };
}

module.exports = {
  browserActions,
  testdataHelper,
  customErrors,
  skipReason,
  BasePage,
};
