const assert = require('assert');
const retry = require('async-retry');
const { BasePage, browserActions, testdataHelper } = require('./basePage');

const commons = browserActions;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  signIn_btn = this.getElementByPage('signInPage', 'signIn_btn');

  focusedSignInPage = this.getElementByPage('signInPage', 'focusedSignInPage');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  homeMenu_lbl = this.getElementByPage('homePage', 'homeMenu_lbl');

  manageProfileMenu_lbl = this.#getSelectorData('manageProfileMenu_lbl');

  userMenu_dropdown = this.#getSelectorData('userMenu_dropdown');

  profile_section = this.getElementByPage('profilePage', 'manageProfile_btn');

  searchButton = this.getElementByPage('searchPage', 'searchButton');

  isSearchButtonFocused = this.getElementByPage('searchPage', 'searchInput');

  myStuff_lbl = this.#getSelectorData('myStuff_lbl');

  myStuff_section = this.#getSelectorData('myStuff_section');

  settingMenu_lbl = this.#getSelectorData('settingMenu_lbl');

  accountMenu_lbl = this.#getSelectorData('accountMenu_lbl');

  subscriptionMenu_lbl = this.#getSelectorData('subscriptionMenu_lbl');

  privacyTermMenu_lbl = this.#getSelectorData('privacyTermMenu_lbl');

  helpMenu_lbl = this.#getSelectorData('helpMenu_lbl');

  signoutMenu_lbl = this.#getSelectorData('signoutMenu_lbl');

  settingScreen_lbl = this.#getSelectorData('settingScreen_lbl');

  accountScreen_lbl = this.#getSelectorData('accountScreen_lbl');

  subscriptionScreen_lbl = this.#getSelectorData('subscriptionScreen_lbl');

  privacyTermScreen_lbl = this.#getSelectorData('privacyTermScreen_lbl');

  helpScreen_lbl = this.#getSelectorData('helpScreen_lbl');

  focusedMenuBar = this.#getSelectorData('focusedMenuBar');

  seriesMenu = this.getElementByPage('homePage', 'seriesMenu');

  moviesMenu = this.getElementByPage('homePage', 'moviesMenu');

  hboMenu = this.getElementByPage('homePage', 'hboMenu');

  focusedSeriesMenu = this.getElementByPage('homePage', 'focusedSeriesMenu');

  focusedMoviesMenu = this.getElementByPage('homePage', 'focusedMoviesMenu');

  focusedHboMenu = this.getElementByPage('homePage', 'focusedHboMenu');

  selectedUserName = this.#getSelectorData('selectedUserName');

  menuItem = {
    Signin: this.signIn_btn,
    Home: this.homeMenu_lbl,
    'Manage Profile': this.manageProfileMenu_lbl,
    Search: this.searchButton,
    myStuff: this.myStuff_lbl,
    'My Stuff': this.myStuff_lbl,
    Setting: this.settingMenu_lbl,
    Account: this.accountMenu_lbl,
    Subscription: this.subscriptionMenu_lbl,
    PrivacyTerm: this.privacyTermMenu_lbl,
    Help: this.helpMenu_lbl,
    Signout: this.signoutMenu_lbl,
    Series: this.seriesMenu,
    Movies: this.moviesMenu,
    HBO: this.hboMenu,
  };

  pageFocused = {
    Signin: this.focusedSignInPage,
    Home: this.focusedHomePage,
    'Manage Profile': this.profile_section,
    Search: this.isSearchButtonFocused,
    myStuff: this.myStuff_section,
    'My Stuff': this.myStuff_section,
    Setting: this.settingScreen_lbl,
    Account: this.accountScreen_lbl,
    Subscription: this.subscriptionScreen_lbl,
    PrivacyTerm: this.privacyTermScreen_lbl,
    Help: this.helpScreen_lbl,
    Signout: this.signIn_btn,
    Series: this.focusedSeriesMenu,
    Movies: this.focusedMoviesMenu,
    HBO: this.focusedHboMenu,
  };

  navigateToPage = async (pageValue) => {
    if (pageValue === 'Signin') {
      await retry(
        async () => {
          await commons.refreshPage();
          await commons.waitUntil(this.signIn_btn, 10);
        },
        { retries: 3, minTimeout: 3000, maxTimeout: 5000 },
      );
    }
    if (pageValue === 'Manage Profile') {
      await commons.waitUntil(this.userMenu_dropdown, 10);
      await commons.hover(this.userMenu_dropdown);
    }
    await commons.waitUntil(this.menuItem[pageValue], 40);
    await commons.click(this.menuItem[pageValue]);
    if (pageValue === 'Help') {
      await commons.switchTab(1);
    }
    try {
      await commons.waitUntil(this.pageFocused[pageValue], 80);
    } catch (error) {
      await commons.refreshPage();
      await retry(
        async () => {
          await commons.waitUntil(this.pageFocused[pageValue], 80);
        },
        { retries: 5, minTimeout: 3000, maxTimeout: 5000 },
      );
    }
  };

  assertPage = async (pageValue) => {
    await commons.waitUntil(this.pageFocused[pageValue], 10);
  };

  navigateToAccountMenu = async () => {
    await commons.waitUntil(this.userMenu_dropdown, 10);
    await commons.hover(this.userMenu_dropdown);
  };

  getUserMenuItems = async () => {
    let userMenu = [];

    userMenu = await testdataHelper.getContent('menuPage.accountUserMenuList');
    return userMenu;
  };

  verifySubnavigationItems = async () => {
    const userMenu = await this.getUserMenuItems();

    for (let i = 0; i < userMenu.length; i++) {
      const menu = this.menuItem[userMenu[i]];

      assert(
        await commons.isDisplayed(this.menuItem[userMenu[i]], 5),
        `${menu} is not displayed`,
      );
    }
  };

  navigateToSubnavigationAndVerify = async () => {
    await commons.waitUntil(this.manageProfileMenu_lbl);
    const userMenu = await this.getUserMenuItems();

    for (let i = 0; i < userMenu.length; i++) {
      await this.navigateToPage(userMenu[i]);
      if (userMenu[i] === 'Help') {
        await commons.switchTab(0);
      } else if (userMenu[i] === 'Signout') {
        break;
      } else {
        await commons.clickBack();
      }
      await this.navigateToAccountMenu();
    }
  };

  getGNMenu = async () => {
    let menu = [];

    await this.navigateToAccountMenu();
    const userName = await commons.getText(this.selectedUserName);

    if (userName === 'Default') {
      menu = await testdataHelper.getContent('menuPage.webDefaultMenuItems');
    } else if (userName === 'Kids') {
      menu = await testdataHelper.getContent('menuPage.webKidsMenuItems');
    }
    return menu;
  };

  accessGlobalNavigationMenu = async () => {
    await commons.waitUntil(this.focusedMenuBar);
  };

  verifyMenuList = async () => {
    const homeMenu = await this.getGNMenu();

    for (let i = 0; i < homeMenu.length; i++) {
      const menu = await this.menuItem[homeMenu[i]];

      assert(await commons.isDisplayed(menu, 5), `${menu} is not displayed`);
    }
  };

  verifyGlobalNavigation = async () => {
    const homeMenu = await this.getGNMenu();

    for (let i = 0; i < homeMenu.length; i++) {
      await this.navigateToPage(homeMenu[i]);
    }
  };
}

module.exports = new MenuPage();
