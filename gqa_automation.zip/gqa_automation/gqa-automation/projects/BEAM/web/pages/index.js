const signInPage = require('./signInPage');
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');
const myStuffPage = require('./myStuffPage');
const homePage = require('./homePage');
const searchPage = require('./searchPage');
const onboardingPage = require('./onboardingPage');
const networkLandingPage = require('./networkLandingPage');
const videoPlayerPage = require('./videoPlayerPage');

module.exports = {
  menuPage,
  signInPage,
  profilePage,
  myStuffPage,
  homePage,
  searchPage,
  onboardingPage,
  networkLandingPage,
  videoPlayerPage,
};
