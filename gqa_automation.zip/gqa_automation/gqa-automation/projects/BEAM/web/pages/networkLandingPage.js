const { BasePage, browserActions } = require('./basePage');

const commons = browserActions;
const homePage = require('./homePage');

class NetworkLandingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('networkLandingPage', locator);
  }

  network_img = this.#getSelectorData('network_img');

  network_logo = this.#getSelectorData('network_logo');

  showRail_lbl = this.#getSelectorData('showRail_lbl');

  episodeRail_lbl = this.#getSelectorData('episodeRail_lbl');

  euroSports1Network_txt = this.#getSelectorData('euroSports1Network_txt');

  liveRail_lbl = this.#getSelectorData('liveRail_lbl');

  liveRail = this.#getSelectorData('liveRail');

  upcomingRail = this.#getSelectorData('upcomingRail');

  nextArrow_btn = this.#getSelectorData('nextArrow_btn');

  entertainmentNetworkLandingPage = [
    this.showRail_lbl,
    this.episodeRail_lbl,
    this.network_img,
  ];

  validateEntertainmentNetworkLandingPage = async () => {
    try {
      await commons.click(this.network_img);
    } catch (error) {
      await commons.click(this.network_img);
    }
    await commons.waitUntil(this.network_logo);
    for (let i = 0; i < this.entertainmentNetworkLandingPage.length; i++) {
      await commons.scrollToElement(
        this.entertainmentNetworkLandingPage[i],
        10,
      );
      await commons.waitUntil(this.entertainmentNetworkLandingPage[i]);
    }
  };

  validateSportsNetworkLandingPage = async () => {
    if (this.euroSports1Network_txt) {
      await commons.click(this.euroSports1Network_txt);
    } else {
      while (!(await commons.isDisplayed(this.euroSports1Network_txt, 10))) {
        await commons.hover(this.networkRail_lbl);
        await commons.click(this.nextArrow_btn);
        if (this.euroSports1Network_txt) {
          await commons.click(this.euroSports1Network_txt);
          break;
        }
      }
    }
    await commons.waitUntil(this.network_logo);
    if (await commons.isDisplayed(this.liveRail_lbl, 10)) {
      await commons.waitUntil(this.liveRail);
    }
    await commons.scrollToElement(this.upcomingRail, 5);
    await commons.waitUntil(this.upcomingRail);
  };

  selectAndValidateNetworkLandingPage = async (network) => {
    if (network === 'Entertainment') {
      await this.validateEntertainmentNetworkLandingPage();
    } else if (network === 'Sports') {
      await commons.clickBack();
      await homePage.scrollToRail('Network');
      await this.validateSportsNetworkLandingPage();
    }
  };
}

module.exports = new NetworkLandingPage();
