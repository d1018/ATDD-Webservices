const assert = require('assert');
const retry = require('async-retry');
const { BasePage, browserActions, testdataHelper } = require('./basePage');
const menuPage = require('./menuPage');
const searchPage = require('./searchPage');

const commons = browserActions;
const addedShowName = '';

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  focusedHomePage = this.#getSelectorData('focusedHomePage');

  userMenu_dropdown = this.getElementByPage('menuPage', 'userMenu_dropdown');

  signOut_btn = this.getElementByPage('signInPage', 'signOut_btn');

  signIn_btn = this.getElementByPage('signInPage', 'signIn_btn');

  myListRail_lbl = this.#getSelectorData('myListRail_lbl');

  contentRating = this.#getSelectorData('contentRating');

  showName_txt = this.#getSelectorData('showName_txt');

  railsList = {
    'My List': this.#getSelectorData('myListRail_lbl'),
  };

  myListRailShowName = this.#getSelectorData('myListRailShowName');

  searchResultContent = this.getElementByPage(
    'searchPage',
    'searchResultContent',
  );

  searchresults_btn = this.getElementByPage('browserPage', 'metadata_img');

  nextEpisodeRating = this.getElementByPage(
    'showPage',
    'nextEpisodeRating_txt',
  );

  episodeInfo_lbl = this.getElementByPage('showPage', 'episodeInfo_lbl');

  animatedata = this.getElementByPage('showPage', 'animatedata');

  watchNow_btn = this.getElementByPage('showPage', 'watchNow_btn');

  rating = this.#getSelectorData('rating_txt');

  rfyRailShows = this.#getSelectorData('rfyRailShows');

  cwRailShows = this.#getSelectorData('cwRailShows');

  signOut = async () => {
    await commons.waitUntil(this.userMenu_dropdown);
    await commons.hover(this.userMenu_dropdown);
    await commons.click(this.signOut_btn);
    try {
      await commons.waitUntil(this.signIn_btn, 30);
    } catch (error) {
      await retry(
        async () => {
          await commons.waitUntil(this.signIn_btn, 60);
        },
        { retries: 5, minTimeout: 3000, maxTimeout: 5000 },
      );
    }
  };

  verifyMyListRailOnHomePage = async (railStatus) => {
    await menuPage.navigateToPage('Home');
    assert.equal(railStatus, await this.scrollToRail('My List'));
  };

  verifyMyListRailContentRemoved = async (displayStatus) => {
    let flag;

    if (await this.scrollToRail('My List')) {
      const listofShows = await commons.findElements(this.myListRailShowName);

      for (let i = 0; i < listofShows.length; i++) {
        if ((await commons.getText(listofShows[i])) === addedShowName) {
          flag = false;
          break;
        } else flag = true;
      }
      assert.equal(displayStatus, flag);
    }
  };

  verifyKidsContent = async (screens) => {
    let currentRating = '';

    switch (screens) {
      case 'Home page':
        await menuPage.navigateToPage('Home');
        currentRating = await commons.getText(this.contentRating);
        break;
      case 'Show Details Page':
        await commons.waitUntil(this.showName_txt, 10);
        await commons.click(this.showName_txt);
        currentRating = await commons.getText(this.contentRating);
        break;
      case 'Search Page':
        await menuPage.navigateToPage('Search');
        await searchPage.enterSearchQuery(
          testdataHelper.getContent(`searchPage.kidsShowName`),
        );
        currentRating = await commons.getText(this.contentRating);
        break;
      default:
        break;
    }
    assert(
      testdataHelper.getContent('kidsRatingList').includes(currentRating),
      `Rating is not as per rating standards`,
    );
  };

  verifyAgeRatingAndContentDescriptors = async (screensType) => {
    switch (screensType) {
      case 'Main Hero':
        await commons.waitUntil(this.focusedHomePage, 60);
        break;

      case 'Show Details Page': {
        await menuPage.navigateToPage('Search');
        await searchPage.enterSearchQuery(
          testdataHelper.getContent('searchPage.query'),
        );
        await commons.waitUntil(this.searchResultContent);
        const searchResults = await commons.findElement(this.searchresults_btn);

        await commons.clickAndRelease(searchResults, 60);
        await commons.waitUntil(this.animatedata, 60);
        break;
      }

      case 'Currently Playing Episode': {
        const watchNowbtn = await commons.findElement(this.watchNow_btn);

        await commons.click(watchNowbtn, 30);
        await commons.clickBack();
        await commons.waitUntil(this.animatedata, 60);
        break;
      }

      case 'Next Episodes listed on Episode Landing Page': {
        const ratingsize = await commons.findElements(this.rating);

        await commons.pageDown();
        await commons.hover(this.nextEpisodeRating, 20);
        for (let i = 0; i < ratingsize.length; i++) {
          await commons.isDisplayed(ratingsize[2]);
        }
        break;
      }

      case 'Episode Info Panel':
        await commons.isDisplayed(this.episodeInfo_lbl);
        break;

      default:
        throw new Error(
          'Actual screenType provided is not as per the expectations',
        );
    }

    if (screensType !== 'Next Episodes listed on Episode Landing Page') {
      const ratinglabel = await commons.findElement(this.rating);

      assert(
        await commons.isDisplayed(ratinglabel, 120),
        `Rating for the show is not displayed`,
      );

      const currentRating = await commons.getAttribute(
        this.rating,
        'innerText',
        10,
      );

      assert(
        testdataHelper.getContent('ratingList').includes(currentRating),
        `Rating is not as per rating standards`,
      );
    }
  };

  verifyRecommendedForYou = async (assetType) => {
    assert(
      await this.scrollToRail('Recommended for You'),
      `${assetType} Recommended for You is not displayed`,
    );
  };

  validateNetworkRail = async () => {
    await commons.waitUntil(this.networkRail_lbl, 20);
  };
}

module.exports = new HomePage();
