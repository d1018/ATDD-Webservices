const assert = require('assert');
const { BasePage, browserActions, testdataHelper } = require('./basePage');

const commons = browserActions;
const menuPage = require('./menuPage');

let addedShowName = '';

class MyStuffPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myStuffPage', locator);
  }

  myList_lbl = this.#getSelectorData('myList_lbl');

  noSavedShow_txt = this.#getSelectorData('noSavedShow_txt');

  kebab_icon = this.getElementByPage('homePage', 'kebab_icon');

  addToMyList_btn = this.getElementByPage('homePage', 'addToMyList_btn');

  showName_txt = this.getElementByPage('homePage', 'showName_txt');

  myListShows = this.#getSelectorData('myListShows');

  myListShowName = this.#getSelectorData('myListShowName');

  showCards = this.#getSelectorData('showCards');

  myListKebab_icon = this.#getSelectorData('myListKebab_icon');

  removeFromMylist_btn = this.#getSelectorData('removeFromMylist_btn');

  selectMyList = async () => {
    await commons.waitUntil(this.myList_lbl, 10);
    await commons.click(this.myList_lbl);
  };

  verifyMyListContent = async () => {
    assert(
      testdataHelper.getContent(`myStuffPage.noSavedShow_txt`) ===
        (await commons.getText(this.noSavedShow_txt)),
      `no Shows saved message is not displayed`,
    );
  };

  addShowsToMylist = async () => {
    await menuPage.navigateToPage('Home');
    addedShowName = await commons.getText(this.showName_txt);
    await commons.waitUntil(this.kebab_icon, 10);
    await commons.click(this.kebab_icon);
    const addToMyListTxt = testdataHelper.getContent(
      `myStuffPage.addToMyList_txt`,
    );
    const addToMyListBtn = await commons.findElement(
      this.getCustomLocator(this.addToMyList_btn, addToMyListTxt),
    );

    await commons.waitUntil(addToMyListBtn, 10);
    await commons.click(addToMyListBtn);
  };

  verifyMyListData = async (railStatus) => {
    await menuPage.navigateToPage('myStuff');
    await commons.refreshPage();
    if (railStatus) {
      assert(
        (await commons.getText(this.myListShows)).includes(addedShowName),
        `Shows is not displayed in my list`,
      );
    } else {
      assert(
        !(await commons.getText(this.myListShows)).includes(addedShowName),
        `Shows is displayed in my list`,
      );
    }
  };

  verifyMyListAsset = async () => {
    await this.addShowsToMylist();
    await menuPage.navigateToPage('myStuff');
    await commons.refreshPage();
  };

  removeMyListContent = async () => {
    addedShowName = await commons.getText(this.myListShowName);
    await commons.click(this.myListKebab_icon, 20);
    const removeFromMylistBtn = await this.getCustomLocator(
      this.removeFromMylist_btn,
      testdataHelper.getContent(`myStuffPage.removeFromMyList_txt`),
    );

    await commons.click(removeFromMylistBtn, 20);
  };

  verifyMyListTabContentRemoved = async () => {
    await commons.refreshPage();
    if (await commons.isDisplayed(this.showCards)) {
      assert(
        (await commons.getText(this.myListShowName)) !== addedShowName,
        `My List item is not removed`,
      );
    }
  };

  navigateToMyListTab = async () => {};

  invokeAsset = async () => {};

  verifyInfoModal = async () => {};

  verifyInfoModalElement = async () => {};
}

module.exports = new MyStuffPage();
