const assert = require('assert');
const process = require('process');
const { BasePage, browserActions, testdataHelper } = require('./basePage');
const menuPage = require('./menuPage');

const commons = browserActions;
const playerPositionAfterScrub = 0;
const contentDetail = {
  movie: testdataHelper.getContent('videoPlayerPage.webMovie'),
};

const baseUrl = String(process.env.URL)?.split('?')[0];

class VideoPlayerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('videoPlayerPage', locator);
  }

  progressBar = this.#getSelectorData('progressBar');

  playPauseButton = this.#getSelectorData('playPauseButton');

  videoContainer = this.#getSelectorData('videoContainer');

  playbackTimeline = this.#getSelectorData('playbackTimeline');

  timeline_scrubber = this.#getSelectorData('timeline_scrubber');

  cwRailShows = this.getElementByPage('homePage', 'cwRailShows');

  autoPlayEpisodes = this.getElementByPage('settingsPage', 'autoPlayEpisodes');

  autoPlayEpisodesButton = this.getElementByPage(
    'settingsPage',
    'autoPlayEpisodesButton',
  );

  adPodOnProgressBar = this.#getSelectorData('adPodOnProgressBar');

  mode = {
    minimized: this.#getSelectorData('minimizeButton'),
    fullscreen: this.#getSelectorData('maximizeButton'),
  };

  tryUntil = (ms) => new Promise((res) => setTimeout(res, ms));

  /**
   * This funtion is used to play the video with the given content
   *
   * @param {string} content - value in string. i.e "video/<content-id>/<content-id>"
   */
  navigateAndPlay = async (content) => {
    const contentName = ['minimized', 'fullscreen', 'Movie', 'Series'].includes(
      content,
    )
      ? contentDetail.movie
      : contentDetail[content];

    await commons.deepLinkTo(`https://${baseUrl}${contentName}`);
    if (content === 'minimized' || content === 'fullscreen')
      await this.switchToOrientation(content);
    await commons.waitUntil(this.playPauseButton, 30);
    await commons.click(this.playPauseButton);
    assert(await this.isVideoPlaying(), 'Video is not Playing');
  };

  /**
   This funtion is used to bring the video control to focus 
   */
  fetchControl = async () => {
    await commons.waitUntil(this.videoContainer);
    await commons.hover(this.videoContainer, 5);
  };

  /**
   * This function is used to check the video is playing or not
   *
   */
  isVideoPlaying = async () => {
    await this.fetchControl();
    const videoStarted = await commons.getAttribute(this.progressBar, 'style');

    await this.tryUntil(20000); // currently we dont have the timer in seek bar we are letting the player to play for sometime and ccheking the seekbar position
    if (
      (await commons.getAttribute(this.progressBar, 'style')) === videoStarted
    ) {
      return false;
    }
    return true;
  };

  /**
   * This function is used to switch the video playback mode
   *
   * @param {string} mode - value in string, i.e "fullscreen" or "minimized"
   */
  switchToOrientation = async (mode) => {
    const switchToMode = mode === 'fullscreen' ? 'minimized' : 'fullscreen';

    await this.fetchControl();
    if (!(await commons.isDisplayed(this.mode[switchToMode], 30))) {
      await this.fetchControl();
      await commons.waitUntil(this.mode[mode], 30);
      await commons.click(this.mode[mode]);
    }
  };

  /**
   * This function is used to play verify the video is playing the particular mode
   *
   * @param {string} mode - value in string, i.e "fullscreen" or "minimized"
   */
  verifyVideoOrientation = async (mode) => {
    const switchToMode = mode === 'fullscreen' ? 'minimized' : 'fullscreen';

    await this.fetchControl();
    assert(
      await commons.isDisplayed(this.mode[switchToMode], 30),
      `Unable switch to the ${mode} mode`,
    );
    assert(
      await this.isVideoPlaying(),
      'Video is not playing after mode switch',
    );
  };

  scrubVideo = async (scrubPercent) => {
    // Percentages higher than 95% result in unexpected behaviors in web
    const percent = scrubPercent > 95 ? 95 : scrubPercent;
    const timelineSizeAndLocation = await commons.getElementSizeAndLocation(
      this.playbackTimeline,
    );

    await commons.waitUntil(this.playbackTimeline, 30);
    const xOffset = parseInt(
      timelineSizeAndLocation.width * (percent / 100),
      10,
    );

    const scrubDetails = {
      offset: {
        x: xOffset,
        y: 0,
      },
    };

    await commons.clickAndDrag(this.playbackTimeline, scrubDetails);
  };

  resumeAndPlayVideo = async () => {
    const cwRailShows = await commons.findElements(this.cwRailShows);

    for (let i = 0; i < cwRailShows.length; i++) {
      if (cwRailShows[i].getAttribute('href') === contentDetail.movie) {
        await commons.click(cwRailShows[i]);
        break;
      }
    }
    assert(await this.isVideoPlaying(), 'Video is not Playing');
  };

  videoPlayerPosition = async () => {
    await commons.waitUntil(this.videoContainer, 20);
    await commons.click(this.videoContainer, 50);
    await commons.waitUntil(this.timeline_scrubber);
    const currentPlayerPosition = await commons.getElementSizeAndLocation(
      this.timeline_scrubber,
    );

    return currentPlayerPosition;
  };

  validateResumePoint = async () => {
    const playerPositionAOnResume = await this.videoPlayerPosition();

    assert(
      playerPositionAOnResume >= playerPositionAfterScrub,
      `Resume video is not successful as the player position on resume is ${playerPositionAOnResume} which is less than the player position after scrub ${playerPositionAfterScrub}`,
    );
  };

  setAutoPlayMode = async (settings) => {
    await menuPage.navigateToAccountMenu();
    await commons.waitUntil(menuPage.settingMenu_lbl);
    await commons.click(menuPage.settingMenu_lbl);
    const state = settings === 'On';

    await this.tryUntil(10000);
    if (
      state !==
      ((await commons.getAttribute(this.autoPlayEpisodes, 'aria-checked')) ===
        'true')
    ) {
      await commons.isDisplayed(this.autoPlayEpisodesButton);
      await commons.click(this.autoPlayEpisodesButton, 10);
    }
    assert(
      ((await commons.getAttribute(this.autoPlayEpisodes, 'aria-checked')) ===
        'true') ===
        state,
      `Unable to Turn ${settings} Auto Play Episodes`,
    );
  };

  selectEpisode = async () => {
    // TODO: Identify content for this section
    await this.navigateAndPlay('Movie');
  };

  verifyPlayStatus = async () => {
    // TODO: Add Verify Implementation once it available
    await this.tryUntil(20000);
  };

  isAdsPlaying = async () => {
    // TODO
  };

  verifyAdPods = async () => {
    await this.fetchControl();
    assert(
      await commons.isDisplayed(this.adPodOnProgressBar, 10),
      'Ad Pod is not present',
    );
  };

  verifyAdPlayBack = async () => {
    // TODO: this is not an actual implementation need to revisit
    assert(await this.isAdsPlaying, 'Ad is not playing ');
  };

  verifyCC = async () => {
    // TODO: this is not an actual implementation need to revisit
  };
}

module.exports = new VideoPlayerPage();
