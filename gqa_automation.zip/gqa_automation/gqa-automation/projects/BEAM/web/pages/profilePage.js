const { SkipError } = require('@wbd/gqa-core/support/customErrors');
const assert = require('assert');
const retry = require('async-retry');
const { BasePage, skipReason, browserActions } = require('./basePage');
const menuPage = require('./menuPage');

const commons = browserActions;

let newProfileName = '';
let editedProfileimage = '';
let editedProfileName = '';
let profileCountBeforeDeletion = 0;

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  defaultProfile = this.getElementByPage('signInPage', 'defaultProfile');

  defaultProfile_txt = this.#getSelectorData('defaultProfile_txt');

  profilePickerContainer = this.#getSelectorData('profilePickerContainer');

  manageMode = this.#getSelectorData('manageMode');

  addProfile_btn = this.#getSelectorData('addProfile_btn');

  listOfAllProfiles = this.#getSelectorData('listOfAllProfiles');

  deleteProfile_btn = this.#getSelectorData('deleteProfile_btn');

  deleteProfilePopup_btn = this.#getSelectorData('deleteProfilePopup_btn');

  dynamicProfileName_lbl = this.#getSelectorData('dynamicProfileName_lbl');

  cancelProfile_btn = this.#getSelectorData('cancelProfile_btn');

  avatarImage = this.#getSelectorData('avatarImage');

  avatarImageList = this.#getSelectorData('avatarImageList');

  createProfileName_txtBx = this.#getSelectorData('createProfileName_txtBx');

  save_btn = this.#getSelectorData('save_btn');

  saveChanges_btn = this.#getSelectorData('saveChanges_btn');

  done_btn = this.#getSelectorData('done_btn');

  kidsProfileToggle_btn = this.#getSelectorData('kidsProfileToggle_btn');

  contentRatingBadge = this.#getSelectorData('contentRatingBadge');

  selectCreatedProfile_txt = this.#getSelectorData('selectCreatedProfile_txt');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  manageProfiles_btn = this.#getSelectorData('manageProfiles_btn');

  editCreatedProfile_icon = this.#getSelectorData('editCreatedProfile_icon');

  createdProfileImage = this.#getSelectorData('createdProfileImage');

  standardProfile_txt = this.#getSelectorData('standardProfile_txt');

  kidsProfile_txt = this.#getSelectorData('kidsProfile_txt');

  editAvatar_btn = this.#getSelectorData('editAvatar_btn');

  navigateToManageProfiles = async () => {
    await menuPage.navigateToPage('Manage Profile');
    await commons.waitUntil(this.manageMode, 30);
  };

  verifyProfileScreen = async () => {
    if (!(await commons.isDisplayed(this.profilePickerContainer)))
      await this.navigateToManageProfiles();
    await commons.waitUntil(this.profilePickerContainer);
  };

  selectDefaultProfile = async () => {
    await commons.waitUntil(this.profilePickerContainer, 10);
    if (await commons.isDisplayed(this.defaultProfile)) {
      await commons.click(this.defaultProfile);
    } else {
      await commons.click(this.chevronDropdown_lbl);
      await commons.click(this.chevronDefaultProfile_txt);
    }
    try {
      await commons.waitUntil(this.focusedHomePage, 10);
    } catch (error) {
      await commons.refreshPage();
      await commons.waitUntil(this.focusedHomePage, 30);
    }
  };

  selectProfile = async (profileType) => {
    if (!profileType.includes('Anonymous')) {
      if (!(await commons.isDisplayed(this.profilePickerContainer))) {
        await this.navigateToManageProfiles();
      }
      if (await commons.isDisplayed(this.done_btn, 10)) {
        await commons.click(this.done_btn);
      }
      if (profileType.includes('Default') || profileType.includes('any')) {
        await this.selectDefaultProfile();
      } else if (profileType === 'Standard') {
        await commons.waitUntil(this.standardProfile_txt, 10);
        await commons.click(this.standardProfile_txt);
      } else if (profileType.includes('Kids')) {
        await commons.waitUntil(this.kidsProfile_txt, 10);
        await commons.click(this.kidsProfile_txt);
      } else {
        const selectCreatedProfile = await commons.findElement(
          this.getCustomLocator(this.selectCreatedProfile_txt, newProfileName),
        );

        if (await commons.isDisplayed(selectCreatedProfile, 15)) {
          await commons.click(selectCreatedProfile);
        } else {
          await commons.click(this.chevronDropdown_lbl);
          const selectCreatedChevronProfile = await commons.findElement(
            this.getCustomLocator(
              this.selectCreatedChevronProfile_txt,
              newProfileName,
            ),
          );

          await commons.click(selectCreatedChevronProfile);
        }
      }
      await commons.waitUntil(this.focusedHomePage, 40);
    }
  };

  verifyAddProfile = async () => {
    const isAddProfileDisplayed = await commons.isDisplayed(
      this.addProfile_btn,
    );

    return isAddProfileDisplayed;
  };

  getListOfProfiles = async () => {
    let individualProfileName;
    const profileNames = [];
    let elements = await commons.findElements(this.listOfAllProfiles, 10);

    profileCountBeforeDeletion = await elements.length;
    for (let i = 0; i < profileCountBeforeDeletion; i++) {
      elements = await commons.findElements(this.listOfAllProfiles, 10);

      individualProfileName = await commons.getText(elements[i]);
      let oldProfile = true;

      // Split the individualProfileName and then compare the timestamp.
      // if <4 minutes, then do not delete that profile, else mark that profile as old profile.
      if (!individualProfileName.includes('Default')) {
        const existingProfileRandomTime =
          individualProfileName.match(/[a-z]+|\d+/gi);

        if (existingProfileRandomTime.length > 1) {
          if (
            Math.round(
              Math.abs(
                Date.now() / 1000 -
                  existingProfileRandomTime[
                    existingProfileRandomTime.length - 1
                  ],
              ) / 60,
            ) <= 4
          ) {
            oldProfile = false;
          }
        }
      }

      if (!individualProfileName.includes('Default') && oldProfile) {
        profileNames.push(individualProfileName);
      }
      // For Oldprofile == false, we need to delete the newly created profile each time. Hence we need below condition
      if (individualProfileName === newProfileName) {
        profileNames.push(individualProfileName);
      }
    }
    return profileNames;
  };

  deleteProfile = async (profileName) => {
    let profileNames = [];

    if (!(await commons.isDisplayed(this.deleteProfile_btn))) {
      if (!(await commons.isDisplayed(this.manageMode)))
        await this.navigateToManageProfiles();
      if (await profileName.includes('Kids')) {
        await this.selectDefaultProfile();
        await this.navigateToManageProfiles();
      }
      if (await commons.isDisplayed(this.manageProfiles_btn, 30))
        await commons.click(this.manageProfiles_btn);
      profileNames = await this.getListOfProfiles();
      const arraySize = profileNames.length;

      if (arraySize === 0) {
        throw new SkipError(skipReason.noProfilesAvailableToDelete);
      }
      let requiredProfileName;

      if (profileNames.includes(profileName)) {
        requiredProfileName = this.getCustomLocator(
          this.dynamicProfileName_lbl,
          profileName,
        );
      } else {
        for (let i = 0; i < arraySize; i++) {
          if (typeof profileNames[0] !== 'undefined') {
            requiredProfileName = this.getCustomLocator(
              this.dynamicProfileName_lbl,
              profileNames[0],
            );
          }
        }
      }
      await commons.waitUntil(requiredProfileName, 5);
      await commons.click(requiredProfileName);
    }
    await commons.click(this.deleteProfile_btn);
    await commons.waitUntil(this.deleteProfilePopup_btn, 5);
    await commons.click(this.deleteProfilePopup_btn);
    await commons.refreshPage();
    await commons.waitUntil(this.done_btn, 30);
    await commons.click(this.done_btn, 20);
    await commons.waitUntil(this.manageProfiles_btn, 30);
  };

  deleteExistingProfile = async () => {
    await this.deleteProfile(newProfileName);
    await this.verifyUserProfileDeleted();
  };

  createNewProfile = async (profileType) => {
    const newProfileType = profileType.includes('Standard')
      ? 'Base'
      : profileType;

    if (!(await commons.isDisplayed(this.manageMode, 10))) {
      await this.navigateToManageProfiles();
    }
    const isAddProfileDisplayed = await this.verifyAddProfile();
    // get timestamp (in millseconds)

    newProfileName = newProfileType + Math.floor(Date.now() / 1000);
    if (!isAddProfileDisplayed) {
      await this.deleteProfile('anyprofile');
    }
    await commons.refreshPage();
    await commons.waitUntil(this.addProfile_btn);
    await commons.click(this.addProfile_btn);
    await commons.waitUntil(this.avatarImage);
    await commons.click(this.avatarImage);
    await commons.sendText(this.createProfileName_txtBx, newProfileName);
    if (newProfileType.includes('Kids')) {
      await commons.isDisplayed(this.kidsProfileToggle_btn, 10);
      await commons.click(this.kidsProfileToggle_btn);
      await commons.waitUntil(this.contentRatingBadge, 20);
    }
    await commons.click(this.save_btn);
    await commons.waitUntil(this.done_btn, 10);
    if (await commons.isEnabled(this.done_btn, 10)) {
      await retry(
        async () => {
          await commons.click(this.done_btn);
        },
        { retries: 3, minTimeout: 3000, maxTimeout: 5000 },
      );
    }
  };

  profileCreation = async (profileType) => {
    await this.createNewProfile(profileType);
    await this.selectProfile(newProfileName);
  };

  editUserProfile = async () => {
    await commons.click(this.editAvatar_btn);
    const avatarImageList = await commons.findElements(this.avatarImageList);

    await commons.waitUntil(avatarImageList[2], 10);
    editedProfileimage = await commons.getAttribute(
      avatarImageList[2],
      'title',
    );
    await commons.click(avatarImageList[2]);
    editedProfileName = newProfileName.replace(
      newProfileName.slice(0, 4),
      'edit',
    );
    await commons.sendText(this.createProfileName_txtBx, editedProfileName);
    await commons.waitUntil(this.saveChanges_btn, 10);
    await commons.click(this.saveChanges_btn);
  };

  verifyEditedProfile = async () => {
    const updatedProfileName = await commons.findElement(
      this.getCustomLocator(this.editCreatedProfile_icon, editedProfileName),
    );

    const updatedProfileImage = await commons.findElement(
      this.getCustomLocator(this.createdProfileImage, editedProfileName),
    );

    const fails = [];

    if (!(await commons.isDisplayed(updatedProfileName)))
      fails.push('profile name is not editted');
    if (
      editedProfileimage !==
      (await commons.getAttribute(updatedProfileImage, 'title'))
    )
      // fails.push('Avatar image is not updated');

      assert.equal(fails.length === 0, true, fails);
    newProfileName = editedProfileName;
  };

  moveToEditPage = async (profileName) => {
    if (await commons.isDisplayed(this.manageProfiles_btn))
      await commons.click(this.manageProfiles_btn);
    const editCreatedProfileBtn = await commons.findElement(
      this.getCustomLocator(this.editCreatedProfile_icon, profileName),
    );

    await commons.click(editCreatedProfileBtn);
  };

  createNewProfileAndMoveToEdit = async (profileType) => {
    await this.createNewProfile(profileType);
    await this.moveToEditPage(newProfileName);
  };

  verifyAddProfileButton = async () => {
    await this.verifyProfileScreen();
    assert(
      (await this.verifyAddProfile()) === false,
      `Add profile button visible for Kids Profile`,
    );
  };

  verifyUserProfileDeleted = async () => {
    assert(
      !(await this.getListOfProfiles()).includes(newProfileName),
      `Deletion of profiles is not successful`,
    );
  };
}

module.exports = new ProfilePage();
