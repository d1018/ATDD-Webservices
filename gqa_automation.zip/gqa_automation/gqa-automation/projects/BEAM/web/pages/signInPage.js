const { BasePage, browserActions } = require('./basePage');
const { desiredWebCapabilities } = require('../capabilities/bsCaps');
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');

const commons = browserActions;

const login = process.env.LOGIN_BEAM;
const passwordDTC = process.env.PASSWORD_BEAM;
const url = process.env.URL;
const serverURL = process.env.SERVER_URL
  ? process.env.SERVER_URL.toLowerCase()
  : '';
const localExecution = process.env.LOCAL_EXECUTION;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  username = '';

  password = '';

  focusedSignInPage = this.#getSelectorData('focusedSignInPage');

  signIn_btn = this.#getSelectorData('signIn_btn');

  root1 = this.#getSelectorData('loginForm');

  root2 = this.#getSelectorData('loginContainer');

  userName_txtBx = this.#getSelectorData('userName_txtBx');

  password_txtBx = this.#getSelectorData('password_txtBx');

  continue_btn = this.#getSelectorData('continue_btn');

  profilePickerContainer = this.getElementByPage(
    'profilePage',
    'profilePickerContainer',
  );

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  openApp = async () => {
    const deviceCaps = desiredWebCapabilities();

    commons.driverInit(serverURL, localExecution);
    commons.baseURL(login, passwordDTC, url);
    await commons.openApp(deviceCaps);
  };

  enterCredentials = async (credentialType) => {
    this.username = process.env[`${credentialType}_USERNAME`];
    this.password = process.env[`${credentialType}_PASSWORD`];
    await commons.waitUntil(this.focusedSignInPage, 40);
    const shadowRoot1 = await commons.getShadowRoot(this.root1);
    const root2 = await commons.getShadowElement(shadowRoot1, this.root2);
    const shadowRoot2 = await commons.getShadowRoot(root2);
    const usernameText = await commons.getShadowElement(
      shadowRoot2,
      this.userName_txtBx,
    );

    await commons.sendText(usernameText, this.username);
    const passwordText = await commons.getShadowElement(
      shadowRoot2,
      this.password_txtBx,
    );

    await commons.sendText(passwordText, this.password);
    const continueBtn = await commons.getShadowElement(
      shadowRoot2,
      this.continue_btn,
    );

    await commons.click(continueBtn);
  };

  loginToApplication = async (credentialType) => {
    if (!credentialType.includes('anonymous')) {
      if (!(await commons.isDisplayed(this.focusedSignInPage))) {
        await menuPage.navigateToPage('Signin');
      }
      await this.enterCredentials(credentialType);
      if (await commons.isDisplayed(this.profilePickerContainer, 30)) {
        await profilePage.selectDefaultProfile();
      } else {
        await commons.waitUntil(this.focusedHomePage, 10);
      }
    }
  };

  verifySignOut = async () => {
    await commons.assertDisplay(this.signIn_btn, true);
  };
}

module.exports = new SignInPage();
