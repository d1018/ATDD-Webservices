const assert = require('assert');

const logger = require('jake/lib/utils/logger');
const { BasePage, browserActions, testdataHelper } = require('./basePage');
const homePage = require('./homePage');

const commons = browserActions;

class OnboardingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('onboardingPage', locator);
  }

  root1 = this.#getSelectorData('createAccountForm');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  anonymousSignUp_btn = this.#getSelectorData('anonymousSignUp_btn');

  plan_btn = this.#getSelectorData('plan_btn');

  planSubmit_btn = this.#getSelectorData('planSubmit_btn');

  focusedSignUpPage = this.#getSelectorData('focusedSignUpPage');

  createAccountContainer_lbl = this.#getSelectorData(
    'createAccountContainer_lbl',
  );

  firstName_txtBx = this.#getSelectorData('firstName_txtBx');

  lastName_txtBx = this.#getSelectorData('lastName_txtBx');

  email_txtBx = this.#getSelectorData('email_txtBx');

  password_txtBx = this.#getSelectorData('password_txtBx');

  agreeContinue_btn = this.#getSelectorData('agreeContinue_btn');

  creditDebitPaymentType_btn = this.#getSelectorData(
    'creditDebitPaymentType_btn',
  );

  paypalPaymentType_btn = this.#getSelectorData('paypalPaymentType_btn');

  billingTitle_lbl = this.#getSelectorData('billingTitle_lbl');

  cardTypeForm_lbl = this.#getSelectorData('cardTypeForm_lbl');

  cardHolderName = this.#getSelectorData('cardHolderName');

  cardNumber = this.#getSelectorData('cardNumber');

  expiryDate = this.#getSelectorData('expiryDate');

  securityCode = this.#getSelectorData('securityCode');

  zipCode = this.#getSelectorData('zipCode');

  switchCardNumberIframe = this.#getSelectorData('switchCardNumberIframe');

  switchSecurityCodeIframe = this.#getSelectorData('switchSecurityCodeIframe');

  oneTrustClose_btn = this.#getSelectorData('oneTrustClose_btn');

  purchaseConfirmationScreen_lbl = this.#getSelectorData(
    'purchaseConfirmationScreen_lbl',
  );

  subscriptionSuccessHeader_txt = this.#getSelectorData(
    'subscriptionSuccessHeader_txt',
  );

  letsGoCta_btn = this.#getSelectorData('letsGoCta_btn');

  selectState_dropdown = this.#getSelectorData('selectState_dropdown');

  stateOption = this.#getSelectorData('stateOption');

  startSubscription_btn = this.#getSelectorData('startSubscription_btn');

  confirmEmailInput = this.#getSelectorData('confirmEmailInput');

  oneTrustFooterClose = this.#getSelectorData('oneTrustFooterClose');

  navigateToPlanPickerPage = async () => {
    await commons.waitUntil(this.anonymousSignUp_btn);
    await commons.click(this.anonymousSignUp_btn);
    await commons.waitUntil(this.oneTrustClose_btn);
    await commons.click(this.oneTrustClose_btn);
  };

  selectAnyPlan = async () => {
    await commons.waitUntil(this.focusedSignUpPage);
    await commons.waitUntil(this.plan_btn, 10);
    await commons.click(this.plan_btn);
    await commons.click(this.planSubmit_btn);
  };

  createAccount = async (
    confirmEmail = false,
    accountCreationEmail = null,
    accountCreationPassword = null,
  ) => {
    await commons.waitUntil(this.createAccountContainer_lbl, 40);
    const randomString = Math.random().toString(36).substring(2, 7);

    if (
      confirmEmail &&
      (await commons.isDisplayed(this.oneTrustFooterClose, 30))
    ) {
      await commons.click(this.oneTrustFooterClose);
    }

    const shadowRoot1 = await commons.getShadowRoot(this.root1);
    const emailText = await commons.getShadowElement(
      shadowRoot1,
      this.email_txtBx,
    );

    const email = confirmEmail
      ? accountCreationEmail
      : `dummy${randomString}@test.com`;

    await commons.sendText(emailText, email);

    const confirmEmailText = await commons.getShadowElement(
      shadowRoot1,
      this.confirmEmailInput,
    );

    await commons.sendText(confirmEmailText, email);

    const passwordText = await commons.getShadowElement(
      shadowRoot1,
      this.password_txtBx,
    );

    const password = confirmEmail
      ? accountCreationPassword
      : testdataHelper.getContent(`registrationPage.password`);

    await commons.sendText(passwordText, password);
    const firstNameText = await commons.getShadowElement(
      shadowRoot1,
      this.firstName_txtBx,
    );

    await commons.sendText(firstNameText, 'Test');
    const lastNameText = await commons.getShadowElement(
      shadowRoot1,
      this.lastName_txtBx,
    );

    await commons.sendText(lastNameText, 'Automation');
    const continueBtn = await commons.getShadowElement(
      shadowRoot1,
      this.agreeContinue_btn,
    );

    await commons.click(continueBtn);
  };

  selectSubscribeCta = async () => {};

  selectPaymentType = async (paymentType) => {
    await commons.waitUntil(this.billingTitle_lbl);
    if (paymentType === 'card') {
      await commons.waitUntil(this.creditDebitPaymentType_btn, 60);
      await commons.click(this.creditDebitPaymentType_btn);
    } else {
      await commons.waitUntil(this.paypalPaymentType_btn, 60);
      await commons.click(this.paypalPaymentType_btn);
    }
  };

  switchToBillingIframe = async (option) => {
    switch (option) {
      case 'card_number':
        await commons.waitUntil(this.switchCardNumberIframe);
        await commons.switchToIframe(this.switchCardNumberIframe);
        break;
      case 'cvv':
        await commons.waitUntil(this.switchSecurityCodeIframe);
        await commons.switchToIframe(this.switchSecurityCodeIframe);
        break;
      default:
        break;
    }
  };

  selectStateField = async (state) => {
    await commons.waitUntil(this.selectState_dropdown, 40);
    await commons.click(this.selectState_dropdown);
    const stateOption = await commons.findElement(
      this.getCustomLocator(this.stateOption, state),
    );

    await commons.waitUntil(stateOption, 20);
    await commons.click(stateOption);
  };

  submitPaymentDetails = async () => {
    await commons.waitUntil(this.cardTypeForm_lbl);
    await commons.sendText(this.cardHolderName, `Test`);
    await this.switchToBillingIframe('card_number');
    await commons.sendText(this.cardNumber, process.env.AMEX_CARD_NUMBER);
    await commons.switchToDefaultContent();
    await this.switchToBillingIframe('cvv');
    await commons.sendText(this.securityCode, process.env.AMEX_VALID_CVV);
    await commons.switchToDefaultContent();
    await commons.waitUntil(this.expiryDate);
    await commons.sendText(this.expiryDate, process.env.AMEX_EXPIRY_DATE);
    await commons.sendText(this.zipCode, process.env.AMEX_ZIP_CODE);
    await this.selectStateField('IN');
    await commons.waitUntil(this.startSubscription_btn);
    try {
      await commons.click(this.startSubscription_btn);
      await commons.waitUntil(this.purchaseConfirmationScreen_lbl);
    } catch (error) {
      await commons.click(this.startSubscription_btn);
    }
  };

  verifyPostPurchaseConfirmationScreen = async () => {
    assert(
      await commons.isDisplayed(this.purchaseConfirmationScreen_lbl, 30),
      'Success screen is not displayed',
    );
    assert(
      await commons.isDisplayed(this.subscriptionSuccessHeader_txt, 30),
      'subscription Success header text is not displayed',
    );
  };

  clickOnLetsGoCta = async () => {
    await commons.waitUntil(this.letsGoCta_btn);
    await commons.hover(this.letsGoCta_btn);
    await commons.click(this.letsGoCta_btn);
  };

  createAccountWithSubscription = async () => {
    const account = {
      startIndex: parseInt(process.env.START_INDEX, 10),
      endIndex: parseInt(process.env.END_INDEX, 10),
      email: process.env.ACCOUNT_CREATION_EMAIL,
      password: process.env.ACCOUNT_CREATION_PASSWORD,
      url: process.env.ACCOUNT_CREATION_URL,
    };

    logger.log(`${this.constructor.name} :: Starting Account Creation `);
    const createdAccount = [];

    try {
      for (let index = account.startIndex; index <= account.endIndex; index++) {
        const username = account.email.split('@')[0];
        const domain = account.email.split('@')[1];
        const accountCreationEmail = `${username}${index}@${domain}`;

        logger.log(
          `${this.constructor.name} :: Account Creation - ${index} is in progress`,
        );
        await commons.deepLinkTo(account.url);
        await this.createAccount(true, accountCreationEmail, account.password);
        await commons.waitUntil(this.focusedHomePage, 60);
        await homePage.signOut();
        createdAccount.push([accountCreationEmail, account.password]);
      }
    } catch (error) {
      if (this.createAccount.length < 1) {
        logger.log(`${this.constructor.name} :: No Accounts Created`);
      }
    }
    logger.log(
      `\n${this.constructor.name} :: Total Number of Accounts Created: ${createdAccount.length}\n\nAccount Details`,
    );
    createdAccount.forEach((value, index) => {
      logger.log(`${index + 1} | ${value[0]} | ${value[1]} |`);
    });
  };
}

module.exports = new OnboardingPage();
