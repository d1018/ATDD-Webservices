const assert = require('assert');

const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;

const { PROP, VRC, COMP } = commons;
const videoPlayerPage = require('./videoPlayerPage');

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  homeTab_lbl = this.#getSelectorData('homeTab_lbl');

  homeMenu_lbl = this.getElementByPage('basePage', 'homeMenu_lbl');

  myStuffMenu_lbl = this.getElementByPage('basePage', 'myStuffMenu_lbl');

  myListRail_lbl = this.#getSelectorData('myListRail_lbl');

  myListRailFirstThumbnail = this.#getSelectorData('myListRailFirstThumbnail');

  ratingLabel_txt = this.#getSelectorData('ratingLabel_txt');

  contentDescriptors_txt = this.#getSelectorData('contentDescriptors_txt');

  focusedHomePage = this.#getSelectorData('focusedHomePage');

  focusedSignOut_button = this.getElementByPage(
    'settingsPage',
    'focusedSignOut_button',
  );

  focusedShowDetailsPage = this.getElementByPage(
    'showDetailsPage',
    'focusedShowDetailsPage',
  );

  ratingShowDetailsPage_txt = this.getElementByPage(
    'showDetailsPage',
    'ratingShowDetailsPage_txt',
  );

  videoPlayerSceneRating_txt = this.getElementByPage(
    'videoPlayerPage',
    'videoPlayerSceneRating_txt',
  );

  episode_lbl = this.getElementByPage('episodeLandingPage', 'episode_lbl');

  episodeRating_txt = this.getElementByPage(
    'episodeLandingPage',
    'episodeRating_txt',
  );

  focusedRail = this.getElementByPage('basePage', 'focusedRail');

  startStreaming_text = this.getElementByPage(
    'welcomePage',
    'startStreaming_text',
  );

  ratingInformation_label = this.#getSelectorData('ratingInformation_label');

  immersiveHeroBadge_icon = this.#getSelectorData('immersiveHeroBadge_icon');

  watchNowCTA_label = this.#getSelectorData('watchNowCTA_label');

  clearSearch_button = this.#getSelectorData('clearSearch_button');

  focusedSearchPage_label = this.getElementByPage(
    'homePage',
    'focusedSearchPage_label',
  );

  showName_label = this.#getSelectorData('showName_label');

  navigateToHome = async () => {
    await this.navigateToPage('Home');
  };

  verifyMyListRailOnHomePage = async () => {
    await commons.userAction(VRC.LEFT);
    await commons.assertExists(this.myStuffMenu_lbl, 5);
    await commons.userAction(VRC.UP);
    await commons.assertExists(this.homeMenu_lbl, 5);
    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.homeTab_lbl, 10);
    await commons.userAction(VRC.DOWN, 2, 2);
    await commons.assertExists(this.myListRail_lbl, 5);
    await commons.assertExists(this.myListRailFirstThumbnail, true);
  };

  signOut = async () => {
    await this.openMenu();
    await this.navigateToSettingsMenu('Sign Out');
    await commons.userAction(VRC.RIGHT);
    await commons.assertExists(this.focusedSignOut_button, 5);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.startStreaming_text, 10);
  };

  verifyAgeRatingAndContentDescriptors = async (screensType) => {
    const ratings = testdataHelper.getContent('ratingList');
    const currentRating = await commons.fetchAttributeData(
      this.ratingLabel_txt,
      'text',
    );
    const results = ratings.includes(currentRating.trim());

    switch (screensType) {
      case 'Main Hero':
        await commons.assertExists(this.homeTab_lbl, 10);
        await commons.userAction(VRC.DOWN, 1, 10);
        await commons.assertExists(this.focusedHomePage, 5);
        await commons.assertExists(this.ratingLabel_txt, 5);
        await commons.checkProperty(
          this.contentDescriptors_txt,
          PROP.TEXT_CONTENT,
          '',
          COMP.NOT_EQUAL,
        );
        assert(results === true, 'Rating is not as per rating standards');
        break;
      case 'Show Details Page':
        await commons.userAction(VRC.ENTER, 1, 10);
        await commons.assertExists(this.focusedShowDetailsPage, 5);
        await commons.checkProperty(
          this.ratingShowDetailsPage_txt,
          PROP.TEXT_CONTENT,
          '',
          COMP.NOT_EQUAL,
        );
        break;
      case 'Currently Playing Episode':
        await commons.userAction(VRC.ENTER, 1, 5);
        await videoPlayerPage.isVideoPlaying();
        await commons.assertExists(this.videoPlayerSceneRating_txt, 10);
        break;
      case 'Next Episodes listed on Episode Landing Page':
        await commons.userAction(VRC.BACK, 1, 5);
        await commons.userAction(VRC.DOWN, 1, 5);
        await commons.assertExists(this.episode_lbl, 10);
        await commons.assertExists(this.episodeRating_txt, 10);
        break;
      case 'Episode Info Panel ':
        await commons.assertExists(this.episodeRating_txt, 10);
        break;
      default:
        break;
    }
  };

  validateNetworkRail = async () => {
    await commons.assertProperty(
      this.focusedRail,
      PROP.VISIBILITY,
      'invisible',
      COMP.EQUAL,
    );
  };

  verifyKidsContent = async (screens) => {
    if (screens === 'Home page') {
      await this.navigateToPage('Home');
      await commons.waitUntil(this.immersiveHeroBadge_icon);
      const currentRating = await commons.fetchAttributeData(
        this.ratingInformation_label,
        'text',
        10,
      );

      assert(
        testdataHelper.getContent('kidsRatingList').includes(currentRating),
        `Rating is not as per rating standards`,
      );
      await commons.userAction(VRC.DOWN);
      await commons.assertExists(this.watchNowCTA_label, 2);
      await commons.userAction(VRC.SELECT);
    } else if (screens === 'Show Details Page') {
      await commons.userAction(VRC.SELECT);
      await commons.waitUntil(this.episodes_button);
      const currentRating = await commons.fetchAttributeData(
        this.ratingInformation_label,
        'text',
        10,
      );

      assert(
        testdataHelper.getContent('kidsRatingList').includes(currentRating),
        `Rating is not as per rating standards`,
      );
      await commons.userAction(VRC.BACK);
    } else if (screens === 'Search') {
      await this.navigateToPage('Search');
      const isKidsContentDisplayed = await this.searchContent('kids');

      assert(
        isKidsContentDisplayed,
        `Kids content is not shown on the kids search screen`,
      );
      const isAdultContentDisplayed = await this.searchContent('adult');

      assert(
        !isAdultContentDisplayed,
        `A rated content is shown on the kids search screen`,
      );
    }
  };

  searchContent = async (contentType) => {
    let isContentDisplayed = true;

    if (await commons.elementExists(this.clearSearch_button)) {
      await commons.userAction(VRC.SELECT);
    }
    if (contentType === 'adult') {
      const adultContent = testdataHelper.getContent(
        `searchPage.adultShowName`,
      );

      await commons.sendText(this.focusedSearchPage_label, adultContent);
      const adultShow = this.getCustomLocator(
        this.showName_label,
        adultContent,
      );

      isContentDisplayed = await commons.elementExists(adultShow, 10);
    } else if (contentType === 'kids') {
      const kidsContent = testdataHelper.getContent(`searchPage.kidsShowName`);

      await commons.sendText(this.focusedSearchPage_label, kidsContent);
      const kidsShow = this.getCustomLocator(this.showName_label, kidsContent);

      isContentDisplayed = await commons.elementExists(kidsShow, 10);
    }
    return isContentDisplayed;
  };
}

module.exports = HomePage;
