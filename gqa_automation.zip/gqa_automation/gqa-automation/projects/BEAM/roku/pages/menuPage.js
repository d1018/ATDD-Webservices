const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;

// const { VRC, PROP, COMP } = commons;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  focusedProfilePage = this.getElementByPage(
    'selectProfilePage',
    'focusedProfilePage',
  );

  focusedSeries_tab = this.getElementByPage('primaryTab', 'focusedSeries_tab');

  focusedMovies_tab = this.getElementByPage('primaryTab', 'focusedMovies_tab');

  focusedHBO_tab = this.getElementByPage('primaryTab', 'focusedHBO_tab');

  focusedMyStuffPage = this.getElementByPage(
    'myStuffPage',
    'focusedMyStuffPage',
  );

  focusedSettingsPage = this.getElementByPage(
    'settingsPage',
    'focusedSettingsPage',
  );

  homePageTab = [
    this.focusedProfilePage,
    this.focusedHomePage,
    this.focusedSearchPage,
    this.focusedSeries_tab,
    this.focusedMovies_tab,
    this.focusedHBO_tab,
    this.focusedMyStuffPage,
    this.focusedSettingsPage,
  ];

  userMenuItem = [];

  /**
   * The below function will verify the tabs present in home page.
   */
  accessGlobalNavigationMenu = async () => {
    for (let i = 0; i < this.homePageTab.length; i++) {
      await commons.waitUntil(this.homePageTab[i], 5);
    }
  };

  /**
   * The below function will verify the navigation menu list.
   */
  verifyMenuList = async () => {
    this.getUserMenuItems();
    for (let i = 0; i < this.userMenuItem.length; i++) {
      await commons.waitUntil(this.menuItem[this.userMenuItem[i]], 15);
    }
  };

  /**
   * The below function will fetch the menu items from test data helper.
   */
  getUserMenuItems = () => {
    if (this.getCurrentProfileName() === 'Default') {
      this.userMenuItem = testdataHelper.getContent(
        'menuPage.rokuloggedInDefaultMenu',
      );
    } else if (this.getCurrentProfileName() === 'Kids') {
      this.userMenuItem = testdataHelper.getContent(
        'menuPage.rokuloggedInKidsMenu',
      );
    }
  };

  /**
   * The below function will verify the navigation menu pages
   */
  verifyGlobalNavigation = async () => {
    this.getUserMenuItems();
    for (let i = 0; i < this.userMenuItem.length; i++) {
      await commons.click(this.menuItem[this.userMenuItem[i]]);
      await commons.waitUntil(this.pageFocused[this.userMenuItem[i]]);
    }
  };
}

module.exports = MenuPage;
