const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;

const { PROP, VRC } = commons;

class NetworkLandingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('networkLandingPage', locator);
  }

  network_logo = this.#getSelectorData('network_logo');

  homeTab_lbl = this.getElementByPage('homePage', 'homeTab_lbl');

  focusedHeroTitle_txt = this.getElementByPage(
    'homePage',
    'focusedHeroTitle_txt',
  );

  selectAndValidateNetworkLandingPage = async (network) => {
    if (network === 'Entertainment') {
      await this.validateEntertainmentNetworkLandingPage();
    } else if (network === 'Sports') {
      await commons.tryUntil(this.homeTab_lbl, VRC.BACK, 5, 1);
      await this.scrollToRail('');
      await this.validateSportsNetworkLandingPage();
    }
  };

  validateEntertainmentNetworkLandingPage = async () => {
    await this.navigateToSelectNetwork('');
  };

  validateSportsNetworkLandingPage = async () => {
    await this.navigateToSelectNetwork('');
  };

  navigateToSelectNetwork = async (networkType) => {
    let i = 20;

    while (i > 0) {
      const heroTitleTxtFromScreen = await commons.fetchAttributeData(
        this.focusedHeroTitle_txt,
        PROP.TEXT_CONTENT,
      );

      if (heroTitleTxtFromScreen === networkType) {
        await commons.userAction(VRC.SELECT);
        break;
      } else {
        await commons.userAction(VRC.RIGHT);
        i -= 1;
      }
    }
  };
}

module.exports = NetworkLandingPage;
