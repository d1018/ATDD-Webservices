const assert = require('assert');

const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;

const { PROP } = commons;

let searchText = '';

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  search_txtBx = this.#getSelectorData('search_txtBx');

  showTitle_lbl = this.#getSelectorData('showTitle_lbl');

  showImage_img = this.#getSelectorData('showImage_img');

  showsTab_lbl = this.#getSelectorData('showsTab_lbl');

  searchPrompt_lbl = this.#getSelectorData('searchPrompt_lbl');

  firstThumbnailOnSearch = this.#getSelectorData('firstThumbnailOnSearch');

  searchResultsTabs_lbl = this.#getSelectorData('searchResultsTabs_lbl');

  recommendedForYou_lbl = this.#getSelectorData('recommendedForYou_lbl');

  noResultsLabel_lbl = this.#getSelectorData('noResultsLabel_lbl');

  keyboardDeleteKey = this.#getSelectorData('keyboardDeleteKey');

  focusedKeyboard = this.#getSelectorData('focusedKeyboard');

  keyboardClearKey = this.#getSelectorData('keyboardClearKey');

  firstStandardThumbnail = this.#getSelectorData('firstStandardThumbnail');

  focusedShow_lbl = this.#getSelectorData('focusedShow_lbl');

  episodeTitle = this.#getSelectorData('episodeTitle');

  verifySearchPage = async () => {
    await commons.assertExists(this.focusedSearchPage, 10);
    await commons.assertExists(this.search_txtBx, 10);
  };

  enterSearchQuery = async () => {
    await commons.assertExists(this.search_txtBx, 10);
    searchText = testdataHelper.getContent(`searchPage.query`);

    await commons.sendText(searchText);
  };

  verifySearchQuery = async () => {
    const searchShowName = await commons.fetchAttributeData(
      this.search_txtBx,
      PROP.TEXT_CONTENT,
    );

    assert(
      searchShowName === testdataHelper.getContent(`searchPage.query`),
      'Not able to view the Reflected show Name',
    );
  };

  verifySearchResult = async () => {
    await commons.assertExists(this.searchPrompt_lbl, 5);
    await commons.assertExists(this.showTitle_lbl, 5);
    await commons.assertExists(this.showImage_img);

    const searchShowTitle = await commons.fetchAttributeData(
      this.showTitle_lbl,
      PROP.TEXT_CONTENT,
    );

    assert(
      searchShowTitle === testdataHelper.getContent(`searchPage.query`),
      'Not able to view the Reflected show Title name',
    );
  };
}

module.exports = SearchPage;
