const assert = require('assert');
const { BasePage, testdataHelper, remoteActions } = require('./basePage');

const commons = remoteActions;

const { VRC } = commons;

class SportsContentPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('sportsContentPage', locator);
  }

  firstShow_label = this.#getSelectorData('firstShow_label');

  showTitle_label = this.#getSelectorData('showTitle_label');

  showDate_text = this.#getSelectorData('showDate_text');

  sportsCat_text = this.#getSelectorData('sportsCat_text');

  secTitle_text = this.#getSelectorData('secTitle_text');

  description_text = this.#getSelectorData('description_text');

  watchNow_button = this.#getSelectorData('watchNow_button');

  progressBar_text = this.#getSelectorData('progressBar_text');

  backImage_image = this.#getSelectorData('backImage_image');

  badge_text = this.#getSelectorData('badge_text');

  addToMyList_button = this.#getSelectorData('addToMyList_button');

  videoContent_lbl = this.#getSelectorData('videoContent_lbl');

  upcomingLiveText = this.#getSelectorData('upcomingLiveText');

  sportsMetaData = {
    Title: this.showTitle_label,
    Date: this.showDate_text,
    Image: this.backImage_image,
    Badge: this.badge_text,
    'Sports Category': this.sportsCat_text,
    'Secondary Title': this.secTitle_text,
    Description: this.description_text,
    'Watch Now': this.watchNow_button,
    'Progress Bar': this.progressBar_text,
    'Add to MyList': this.addToMyList_button,
  };

  selectContent = async (contentType) => {
    await this.scrollToRail(contentType);
    await commons.click(this.firstShow_label);
  };

  verifyContentDetails = async (contentType) => {
    await this.verifySportsMetaData(contentType);
  };

  verifySportsMetaData = async (contentType) => {
    this.getContentItems(contentType);
    for (let i = 0; i < this.contentItem.length; i++) {
      await commons.waitUntil(this.sportsMetaData[this.contentItem[i]]);
    }
  };

  getContentItems = (contentType) => {
    if (contentType === 'VOD') {
      this.contentItem = testdataHelper.getContent('sportsPage.contentOnVOD');
    } else if (contentType === 'Upcoming Live') {
      this.contentItem = testdataHelper.getContent(
        'sportsPage.contentOnUpcomingLive',
      );
    }
  };

  verifyVideoContent = async (contentType) => {
    this.selectContent(contentType);
    await commons.userAction(VRC.SELECT);
    await commons.waitUntil(this.videoContent_lbl, 5);
    const contentLabel = await commons.fetchAttributeData(
      this.videoContent_lbl,
      'text',
      10,
    );

    assert(
      testdataHelper
        .getContent('sportsPage.contentLabel')
        .includes(contentLabel),
      `Video Content Label is not available`,
    );
  };

  scrollToInlineHero = async (inlinehero) => {
    await this.scrollToRail(inlinehero);
    await commons.click(this.firstShow_label);
  };

  verifyUpcomingLiveEvent = async () => {
    await commons.waitUntil(this.upcomingLiveText, 10);
    const upcomingLiveContent = await commons.fetchAttributeData(
      this.upcomingLiveText,
      'text',
      10,
    );

    assert(
      testdataHelper
        .getContent('sportsPage.upcomingLiveText')
        .includes(upcomingLiveContent),
      `UpcomingLive text is not visible`,
    );
  };

  verifyInlineHeroMetaData = async (pageName) => {
    this.assertPage(pageName);
    await this.verifySportsMetaData('Upcoming Live');
  };
}

module.exports = SportsContentPage;
