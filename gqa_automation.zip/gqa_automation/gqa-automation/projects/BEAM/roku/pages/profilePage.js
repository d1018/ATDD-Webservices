const assert = require('assert');
const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;

const { VRC, PROP, COMP } = commons;

let profileLocalName;

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('selectProfilePage', locator);
  }

  add_profile_icon = this.getElementByPage(
    'selectProfilePage',
    'add_profile_icon',
  );

  whoWatching_Label = this.getElementByPage(
    'selectProfilePage',
    'whoWatching_Label',
  );

  skip_button = this.getElementByPage('selectAvatarPage', 'skip_button');

  name_field = this.getElementByPage('createNewProfilePage', 'name_field');

  focusedProfile = this.getElementByPage('selectProfilePage', 'focusedProfile');

  focusedProfilePage = this.getElementByPage(
    'selectProfilePage',
    'focusedProfilePage',
  );

  add_profile_avatar = this.getElementByPage(
    'selectProfilePage',
    'add_profile_avatar',
  );

  focusedAddProfileAvatar = this.getElementByPage(
    'selectProfilePage',
    'focusedAddProfileAvatar',
  );

  edit_profile_text = this.getElementByPage(
    'editExistingProfilePage',
    'edit_profile_text',
  );

  add_profile_text = this.getElementByPage(
    'createNewProfilePage',
    'add_profile_text',
  );

  done_button = this.getElementByPage('createNewProfilePage', 'done_button');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  homeMenu_lbl = this.getElementByPage('basePage', 'homeMenu_lbl');

  myStuffMenu_lbl = this.getElementByPage('basePage', 'myStuffMenu_lbl');

  focusedProfileName_lbl = this.getElementByPage(
    'profilePage',
    'focusedProfileName_lbl',
  );

  delete_profile_button = this.getElementByPage(
    'editExistingProfilePage',
    'delete_profile_button',
  );

  keyboard_backspace_key = this.getElementByPage(
    'editExistingProfilePage',
    'keyboard_backspace_key',
  );

  change_profileName_text = this.getElementByPage(
    'editExistingProfilePage',
    'change_profileName_text',
  );

  unfocused_delete_profile_button = this.getElementByPage(
    'editExistingProfilePage',
    'unfocused_delete_profile_button',
  );

  kidsMode_toggle = this.getElementByPage(
    'editExistingProfilePage',
    'kidsMode_toggle',
  );

  delete_profile_btn = this.getElementByPage(
    'deleteProfilePage',
    'delete_profile_btn',
  );

  dynamicPinPad_txtBx = this.getElementByPage(
    'profilePage',
    'dynamicPinPad_txtBx',
  );

  enterYourProfilePin_text = this.getElementByPage(
    'profilePage',
    'enterYourProfilePin_text',
  );

  primaryHome_tab = this.getElementByPage('primaryTab', 'primaryHome_tab');

  manageProfiles_button = this.getElementByPage(
    'profilePage',
    'manageProfiles_button',
  );

  profileExitConfirmationScreen = this.getElementByPage(
    'profilePage',
    'profileExitConfirmationScreen',
  );

  exitKidsProfile_btn = this.getElementByPage(
    'profilePage',
    'exitKidsProfile_btn',
  );

  enterPinInKidsProfile = async () => {
    await commons.assertExists(this.dynamicPinPad_txtBx, 3);
    await commons.sendText('1111');
  };

  moveToProfilePage = async () => {
    await this.openMenu();
    if (await commons.elementExists(this.homeMenu_lbl, 10)) {
      await commons.userAction(VRC.UP, 2, 1);
      await commons.userAction(VRC.ENTER);
    } else if (await commons.elementExists(this.myStuffMenu_lbl, 10)) {
      await commons.userAction(VRC.UP, 3, 1);
      await commons.userAction(VRC.ENTER);
    }

    if (await commons.elementExists(this.profileExitConfirmationScreen, 5)) {
      await commons.assertExists(this.exitKidsProfile_btn, 2);
      await commons.userAction(VRC.ENTER);
      if (await commons.elementExists(this.enterYourProfilePin_text, 5)) {
        await this.enterPinInKidsProfile();
      }
    }
    await commons.assertExists(this.whoWatching_Label, 2);
  };

  deleteProfileIfAddButtonNotShown = async () => {
    if (await commons.doesNotExist(this.add_profile_avatar)) {
      await this.moveToFirstProfile();
      await commons.userAction(VRC.DOWN);
      await commons.userAction(VRC.SELECT);
      await this.deleteProfileFromDeleteCta();
    }
  };

  moveToFirstProfile = async () => {
    await commons.assertExists(this.focusedProfilePage, 10);
    while (!(await commons.elementExists(this.focusedProfile, 2))) {
      await commons.userAction(VRC.LEFT);
    }
    await commons.assertExists(this.focusedProfile, 5);
    await commons.assertProperty(
      this.focusedProfile,
      PROP.INDEX,
      0,
      COMP.EQUAL,
    );
  };

  createNewProfile = async (profileName) => {
    this.setCurrentProfileName(profileName);
    const timerCheck = this.getCurrentTime();

    profileLocalName = String(`${profileName}${timerCheck}`);

    if (profileLocalName.length > 14) {
      profileLocalName = profileLocalName.substr(0, 14);
    }

    await this.deleteProfileIfAddButtonNotShown();

    await commons.tryUntil(this.focusedAddProfileAvatar, VRC.RIGHT, 5);
    await commons.userAction(VRC.SELECT, 2);

    await commons.assertExists(this.add_profile_text);
    await commons.userAction(VRC.ENTER);

    await commons.sendText(profileLocalName);
    await commons.userAction(VRC.BACK);
    if (profileLocalName.includes('Kids')) {
      await commons.userAction(VRC.DOWN);
      await commons.userAction(VRC.SELECT);
      await commons.userAction(VRC.DOWN);
    } else {
      await commons.userAction(VRC.DOWN, 2);
    }

    await commons.assertExists(this.done_button, 2);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.whoWatching_Label, 10);
    await commons.tryUntil(this.primaryHome_tab, VRC.ENTER, 5, 1);
  };

  profileCreation = async (profileName) => {
    await this.moveToProfilePage();
    await this.createNewProfile(profileName);
  };

  deleteProfileFromDeleteCta = async () => {
    await commons.assertExists(this.edit_profile_text, 5);
    let counter = 0;

    while (counter <= 5) {
      if (await commons.doesNotExist(this.unfocused_delete_profile_button, 3)) {
        if (await commons.elementExists(this.kidsMode_toggle, 3)) {
          await commons.userAction(VRC.DOWN);
        } else {
          await commons.userAction(VRC.DOWN, 2, 1);
        }

        await commons.tryUntil(this.delete_profile_button, VRC.RIGHT);
        await commons.waitUntil(this.delete_profile_button);
        await commons.userAction(VRC.ENTER);
        await commons.assertExists(this.delete_profile_btn, 2);
        await commons.userAction(VRC.ENTER);
        await commons.assertExists(this.whoWatching_Label, 2);
        break;
      } else {
        await commons.userAction(VRC.BACK, 1);
        await commons.assertExists(this.whoWatching_Label);
        await commons.userAction(VRC.RIGHT, 1);
        await commons.userAction(VRC.DOWN, 1);
        await commons.userAction(VRC.ENTER);
        counter++;
      }
    }
  };

  deleteExistingProfile = async () => {
    if (await commons.elementExists(this.focusedHomePage, 10)) {
      await this.moveToProfilePage();
    }
    await this.moveToFirstProfile();
    let i = 5;

    while (i > 0) {
      if (
        await commons.checkProperty(
          this.focusedProfileName_lbl,
          PROP.TEXT_CONTENT,
          profileLocalName,
          COMP.EQUAL,
        )
      ) {
        await commons.userAction(VRC.DOWN);
        await commons.userAction(VRC.SELECT);
        await commons.assertExists(this.edit_profile_text, 5);
        await this.deleteProfileFromDeleteCta();
        break;
      } else {
        await commons.userAction(VRC.RIGHT, 1);
        i -= 1;
      }
    }
  };

  createNewProfileAndMoveToEdit = async (profileType) => {
    await this.moveToProfilePage();
    await this.createNewProfile(profileType);
    await this.moveToProfilePage();
  };

  clearProfileTextBox = async () => {
    while (await commons.doesNotExist(this.keyboard_backspace_key)) {
      await commons.userAction(VRC.DOWN);
    }
    await commons.userAction(VRC.SELECT, 14, 1);
  };

  moveToEditPage = async () => {
    await commons.assertExists(this.whoWatching_Label, 2);
    await commons.userAction(VRC.DOWN, 1, 2);
    await commons.userAction(VRC.SELECT, 1, 2);
    await commons.assertExists(this.edit_profile_text, 5);
    await commons.userAction(VRC.ENTER, 1, 2);
    await this.clearProfileTextBox();
    const timerCheck = this.getCurrentTime();
    const profileName = this.getCurrentProfileName();

    profileLocalName = String(`${profileName}${timerCheck}`);
    await commons.sendText(profileLocalName);
    await commons.userAction(VRC.BACK, 1, 2);
    await commons.userAction(VRC.DOWN, 1, 2);
    await commons.userAction(VRC.ENTER, 1, 2);
  };

  verifyEditedProfile = async () => {
    await commons.userAction(VRC.RIGHT, 2, 2);
    await commons.userAction(VRC.LEFT, 2, 2);
    await commons.assertExists(this.change_profileName_text, 5);
    await commons.userAction(VRC.ENTER, 1, 2);
  };

  editUserProfile = async () => {
    await this.moveToEditPage();
  };

  verifyProfileScreen = async () => {
    await this.moveToProfilePage();
    await commons.assertExists(this.focusedProfilePage, 4);
  };

  selectDefaultProfile = async () => {
    let i = 5;

    while (i > 0) {
      await commons.userAction(VRC.DOWN);
      await commons.userAction(VRC.ENTER);
      if (await commons.elementExists(this.unfocused_delete_profile_button)) {
        await commons.userAction(VRC.BACK);
        await commons.assertExists(this.whoWatching_Label, 2);
        await commons.userAction(VRC.ENTER);
        await commons.assertExists(this.focusedHomePage, 10);
        break;
      } else {
        await commons.userAction(VRC.BACK);
        await commons.userAction(VRC.RIGHT);
        i -= 1;
      }
    }
  };

  selectProfile = async (profileName) => {
    if (profileName === 'any') {
      await this.setCurrentProfileName(profileName);
      await this.moveToFirstProfile();
      await commons.assertExists(this.whoWatching_Label, 5);
      await commons.userAction(VRC.ENTER);
    }
    if (profileName === 'Default') {
      await this.setCurrentProfileName(profileName);
      await this.moveToProfilePage();
      await this.moveToFirstProfile();
      await this.selectDefaultProfile();
    }
  };

  verifyAddProfileButton = async () => {
    if (!(await commons.elementExists(this.homeTab_lbl))) {
      await this.navigateToPage('Home');
    }
    await this.navigateToPage('My Profile');
    assert(
      !(await commons.elementExists(this.manageProfiles_button)),
      `Add profile button visible for Kids Profile`,
    );
  };
}

module.exports = ProfilePage;
