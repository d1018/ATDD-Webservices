const SignInPage = require('./signInPage');
const HomePage = require('./homePage');
const ProfilePage = require('./profilePage');
const MenuPage = require('./menuPage');
const MyStuffPage = require('./myStuffPage');
const SearchPage = require('./searchPage');
const VideoPlayerPage = require('./videoPlayerPage');
const NetworkLandingPage = require('./networkLandingPage');
const SportsContentPage = require('./sportsContentPage');

const signInPage = new SignInPage();
const homePage = new HomePage();
const profilePage = new ProfilePage();
const menuPage = new MenuPage();
const myStuffPage = new MyStuffPage();
const searchPage = new SearchPage();
const videoPlayerPage = new VideoPlayerPage();
const networkLandingPage = new NetworkLandingPage();
const sportsContentPage = new SportsContentPage();

module.exports = {
  signInPage,
  homePage,
  profilePage,
  menuPage,
  myStuffPage,
  searchPage,
  videoPlayerPage,
  networkLandingPage,
  sportsContentPage,
};
