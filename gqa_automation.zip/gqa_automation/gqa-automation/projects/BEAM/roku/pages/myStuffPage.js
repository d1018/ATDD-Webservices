const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;

const { VRC } = commons;

class MyStuffPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myStuffPage', locator);
  }

  focusedMyStuffBar_lbl = this.#getSelectorData('focusedMyStuffBar_lbl');

  myListTab_lbl = this.#getSelectorData('myListTab_lbl');

  focusedMyListPage = this.#getSelectorData('focusedMyListPage');

  noSavedTitles_txt = this.#getSelectorData('noSavedTitles_txt');

  myListTabShowAdded_lbl = this.#getSelectorData('myListTabShowAdded_lbl');

  homeTab_lbl = this.getElementByPage('homePage', 'homeTab_lbl');

  focusedWatchNow_btn = this.getElementByPage(
    'homePage',
    'focusedWatchNow_btn',
  );

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  addedToMyList_lbl = this.getElementByPage('homePage', 'addedToMyList_lbl');

  removedFromMyList_lbl = this.getElementByPage(
    'homePage',
    'removedFromMyList_lbl',
  );

  justAddedFirstThumbnail = this.getElementByPage(
    'homePage',
    'justAddedFirstThumbnail',
  );

  continueWatchingRailFirstThumbNail = this.getElementByPage(
    'homePage',
    'continueWatchingRailFirstThumbNail',
  );

  defaultProfileTile = this.getElementByPage('homePage', 'defaultProfileTile');

  continueWatching_lbl = this.getElementByPage(
    'homePage',
    'continueWatching_lbl',
  );

  justAdded_lbl = this.getElementByPage('homePage', 'justAdded_lbl');

  homeMenu_lbl = this.getElementByPage('basePage', 'homeMenu_lbl');

  myStuffMenu_lbl = this.getElementByPage('basePage', 'myStuffMenu_lbl');

  /**
   * Go to Home tab and select a show not yet in my list.
   */
  navigateToShowTileInHomePage = async () => {
    await this.scrollToRail('Just Added (2:3 medium)');
  };

  /**
   * For Roku, add to my list via * button on remote
   */
  addShowToMylistFromHomePage = async () => {
    await commons.assertExists(this.justAddedFirstThumbnail);
    await commons.userAction(VRC.SETTINGS);
    await this.verifyMyListShowAddedConfirmMessage();
  };

  /**
   * For Roku, remove from my list via * button on remote
   */
  selectRemoveButtonOnEditMode = async () => {
    await commons.assertExists(this.justAddedFirstThumbnail);
    await commons.userAction(VRC.SETTINGS);
    await this.verifyMyListShowRemovedConfirmMessage();
  };

  navigateToMyListTab = async () => {
    await commons.userAction(VRC.LEFT);
    await commons.assertExists(this.homeMenu_lbl, 5);
    await commons.userAction(VRC.DOWN);
    await commons.assertExists(this.myStuffMenu_lbl);
    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.myListTab_lbl, 5);
  };

  /**
   * Go to My Stuff Page then My List Tab
   * Verify show tile doesnot exists
   */
  verifyMyListShowRemoved = async () => {
    await this.navigateToMyListTab();
    await commons.assertExists(this.noSavedTitles_txt);
  };

  verifyMyListShowRemovedConfirmMessage = async () => {
    await commons.waitUntil(this.removedFromMyList_lbl, 5);
    await commons.assertExists(this.removedFromMyList_lbl, 5);
  };

  /**
   * Go to My Stuff Page then My List Tab
   * Verify show tile exists
   */
  verifyMyListShowAdded = async () => {
    await this.navigateToMyListTab();
    await commons.assertExists(this.myListTab_lbl);
    await commons.userAction(VRC.DOWN);
    await commons.assertExists(this.myListTabShowAdded_lbl);
  };

  verifyMyListShowAddedConfirmMessage = async () => {
    await commons.waitUntil(this.addedToMyList_lbl, 5);
    await commons.assertExists(this.addedToMyList_lbl, 5);
  };

  selectMyList = async () => {
    await commons.assertExists(this.myListTab_lbl, 5);
    await commons.userAction(VRC.SELECT);
  };

  /**
   * This function used to verify the MyList Content Before adding anything to MyList.
   */
  verifyMyListContent = async () => {
    await commons.assertExists(this.myListTab_lbl, 5);
    await commons.userAction(VRC.DOWN);
    await commons.assertExists(this.noSavedTitles_txt);
  };

  addShowsToMylist = async () => {
    await commons.userAction(VRC.LEFT);
    await commons.assertExists(this.myStuffMenu_lbl);
    await commons.userAction(VRC.UP);
    await commons.assertExists(this.homeMenu_lbl, 5);
    await commons.userAction(VRC.SELECT);
    await this.navigateToShowTileInHomePage();
    await this.addShowToMylistFromHomePage();
    await commons.assertExists(this.addedToMyList_lbl, 5);
  };

  /**
   * This function used to verify the MyList Content After adding the show
   */
  verifyMyListData = async () => {
    await this.navigateToMyListTab();
    await commons.assertExists(this.myListTab_lbl);
    await commons.userAction(VRC.DOWN);
    await commons.assertExists(this.myListTabShowAdded_lbl, true);
  };
}

module.exports = MyStuffPage;
