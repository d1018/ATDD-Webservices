const path = require('path');

const {
  remoteActions,
  customErrors,
  testdataHelper,
} = require('@wbd/gqa-core/support');

const ymlpath = path.resolve(__dirname);

const EnvBase = require('../../../support/env');

const { skipReason } = require('../../../support/skipReason');

const commons = remoteActions;

const { VRC, PROP } = commons;

let currentProfileName;

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }

  setCurrentProfileName(profileName) {
    currentProfileName = profileName;
  }

  getCurrentProfileName() {
    return currentProfileName;
  }

  #getSelectorData(locator) {
    return this.getElementByPage('basePage', locator);
  }

  returnRandomNumber = (len) => {
    const randomNumber = Math.floor(Math.random() * len);

    return `${randomNumber}`;
  };

  homeTab_lbl = this.getElementByPage('homePage', 'homeTab_lbl');

  homeMenu_lbl = this.#getSelectorData('homeMenu_lbl');

  myStuffMenu_lbl = this.#getSelectorData('myStuffMenu_lbl');

  searchMenu_lbl = this.#getSelectorData('searchMenu_lbl');

  settingsMenu_lbl = this.#getSelectorData('settingsMenu_lbl');

  focusedMenuBar = this.#getSelectorData('focusedMenuBar');

  focusedRail = this.#getSelectorData('focusedRail');

  focusedSearchPage = this.getElementByPage('searchPage', 'focusedSearchPage');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  focusedMyStuffPage = this.getElementByPage(
    'myStuffPage',
    'focusedMyStuffPage',
  );

  focusedSettingsPage = this.getElementByPage(
    'settingsPage',
    'focusedSettingsPage',
  );

  focusedMenuItem = this.#getSelectorData('focusedMenuItem');

  focusedSettingsMenuItem = this.getElementByPage(
    'settingsPage',
    'focusedSettingsMenuItem',
  );

  focusedSettingsMenuPlayback_text = this.getElementByPage(
    'settingsPage',
    'focusedSettingsMenuPlayback_text',
  );

  focusedSettingsMenuAccount_text = this.getElementByPage(
    'settingsPage',
    'focusedSettingsMenuAccount_text',
  );

  focusedSettingsMenuSubscription_text = this.getElementByPage(
    'settingsPage',
    'focusedSettingsMenuSubscription_text',
  );

  focusedSettingsMenuPrivacy_text = this.getElementByPage(
    'settingsPage',
    'focusedSettingsMenuPrivacy_text',
  );

  focusedSettingsMenuHelp_text = this.getElementByPage(
    'settingsPage',
    'focusedSettingsMenuHelp_text',
  );

  focusedSettingsMenuInfo_text = this.getElementByPage(
    'settingsPage',
    'focusedSettingsMenuInfo_text',
  );

  focusedSettingsMenuSignOut_text = this.getElementByPage(
    'settingsPage',
    'focusedSettingsMenuSignOut_text',
  );

  menuListLoggedIn = testdataHelper.getContent(
    'menuPage.rokuloggedInDefaultMenu',
  );

  settingsMenuList = testdataHelper.getContent(
    'settingsPage.rokuSettingsMenuList',
  );

  pageFocused = {
    Home: this.focusedHomePage,
    Search: this.focusedSearchPage,
    'My Stuff': this.focusedMyStuffPage,
    Settings: this.focusedSettingsPage,
  };

  menuItem = {
    Home: this.homeMenu_lbl,
    'My Stuff': this.myStuffMenu_lbl,
    Search: this.searchMenu_lbl,
    Settings: this.settingsMenu_lbl,
  };

  settingsMenuFocused = {
    Playback: this.focusedSettingsMenuPlayback_text,
    Account: this.focusedSettingsMenuAccount_text,
    Subscription: this.focusedSettingsMenuSubscription_text,
    'Privacy & Terms': this.focusedSettingsMenuPrivacy_text,
    Help: this.focusedSettingsMenuHelp_text,
    Info: this.focusedSettingsMenuInfo_text,
    'Sign Out': this.focusedSettingsMenuSignOut_text,
  };

  assertPage = async (pageValue) => {
    await commons.assertExists(this.pageFocused[pageValue], 10);
  };

  openMenu = async () => {
    await commons.tryUntil(this.focusedMenuBar, VRC.BACK, 10, 1);
    await commons.assertExists(this.focusedMenuBar, 10);
  };

  getMenuList = async () => {
    if ((await this.returnGeoLocation()) === 'america') {
      return this.menuListLoggedIn;
    }
    return [];
  };

  getSettingsMenuList = async () => {
    if ((await this.returnGeoLocation()) === 'america') {
      return this.settingsMenuList;
    }
    return [];
  };

  navigateToPage = async (pageValue) => {
    await this.openMenu();
    await commons.assertExists(this.focusedMenuBar, 10);

    const menuItemText = await commons.fetchAttributeData(
      this.focusedMenuItem,
      PROP.TEXT_CONTENT,
    );

    const menu = await this.getMenuList();

    const focusedIndex = menu.indexOf(menuItemText);
    const moveToIndex = menu.indexOf(pageValue);
    const difference = focusedIndex - moveToIndex;

    if (difference < 0) {
      await commons.userAction(VRC.DOWN, Math.abs(difference), 1);
    }
    if (difference > 0) {
      await commons.userAction(VRC.UP, difference, 1);
    }

    await commons.tryUntil(this.pageFocused[pageValue], VRC.SELECT, 3, 5);
    await commons.assertExists(this.pageFocused[pageValue], 10);
  };

  navigateToSettingsMenu = async (menuValue) => {
    await this.navigateToPage('Settings');
    await commons.assertExists(this.focusedSettingsPage, 10);

    const menuItemText = await commons.fetchAttributeData(
      this.focusedSettingsMenuItem,
      PROP.TEXT_CONTENT,
    );

    const menu = await this.getSettingsMenuList();

    const focusedIndex = menu.indexOf(menuItemText);
    const moveToIndex = menu.indexOf(menuValue);
    const difference = focusedIndex - moveToIndex;

    if (difference < 0) {
      await commons.userAction(VRC.DOWN, Math.abs(difference), 1);
    }
    if (difference > 0) {
      await commons.userAction(VRC.UP, difference, 1);
    }

    await commons.assertExists(this.settingsMenuFocused[menuValue], 10);
  };

  getCurrentTime = () => {
    const dateObject = new Date();
    const hour = dateObject.getHours();
    const min = dateObject.getMinutes();
    const secs = dateObject.getSeconds();
    const time = String(`${hour}${min}${secs}`);

    return time;
  };

  /**
   *
   * @param {number} min must be minimal integer range as per .env test accounts
   * @param {number} max must be maximum integer range as per .env test accounts
   * @returns {number} random number between min & max range
   */
  randomIntFromInterval(min, max) {
    // min and max included
    return Math.floor(Math.random() * (max - min + 1) + min);
  }

  verifyVideoPlayed = async () => {
    await this.selectShow();
    await this.selectAndPlayVideo();
    await commons.assertVideoIsPlaying();
  };

  resumeAndPlayVideo = async () => {
    await commons.userAction(VRC.SELECT);
    await commons.waitTillVideoIsPlaying();
  };

  moveToNextRail = async (direction = VRC.DOWN) => {
    do {
      await commons.userAction(direction, 1, 1);
    } while (await commons.doesNotExist(this.focusedRail));
  };

  scrollToRail = async (railName) => {
    let flag = false;
    const railList = [];

    while (!(await commons.elementExists(this.focusedRail, 5))) {
      await commons.userAction(VRC.DOWN, 1, 2);
    }

    while (flag !== true) {
      // await this.moveToNextRail();
      await commons.userAction(VRC.DOWN, 1, 2);
      const focusedRailName = String(
        await commons.fetchAttributeData(this.focusedRail, PROP.TEXT_CONTENT),
      ).trim();

      if (railList.includes(focusedRailName)) {
        if (!railList.includes(railName)) {
          break;
        }
      }

      railList.push(focusedRailName);

      if (focusedRailName === railName) {
        flag = true;
      }
    }

    if (flag === false) {
      throw new Error(`RailName: ${railName} does not present`);
    }
  };

  /**
   * Function to Navigate to Top of Home Page
   *
   */
  navigateToHome = async () => {
    if (await commons.elementExists(this.homeTab_lbl, 10)) {
      await this.navigateToPage('My Stuff');
      await this.navigateToPage('Home');
    } else {
      await this.navigateToPage('Home');
    }
    await commons.assertExists(this.homeTab_lbl, 10);
  };

  // TODO: Verify rail is present in th app
  verifyRailPresent = async () => {};

  // TODO: Select and play video
  selectAndPlayVideo = async () => {};

  // TODO: Sign out
  signOut = async () => {};

  // TODO: Close the global menu
  closeMenu = async () => {};

  // TODO: Verify exit confirmation screen
  verifyExitConfirmation = async () => {};

  // TODO: Select the primary tab like Home, Series, Movies
  selectPrimaryTab = async () => {};
}

module.exports = {
  remoteActions,
  customErrors,
  skipReason,
  testdataHelper,
  BasePage,
};
