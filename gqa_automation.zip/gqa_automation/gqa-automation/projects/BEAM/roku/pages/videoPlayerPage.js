const { ok } = require('assert');

const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;

const { PROP, VRC, COMP } = commons;

class VideoPlayerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('videoPlayerPage', locator);
  }

  videoPlayerScene = this.#getSelectorData('videoPlayerScene');

  currentTime = this.#getSelectorData('currentTime');

  videoProgressBar = this.#getSelectorData('videoProgressBar');

  play_Button = this.#getSelectorData('play_Button');

  pause_Button = this.#getSelectorData('pause_Button');

  adCounter_lbl = this.#getSelectorData('adCounter_lbl');

  adPlayback_lbl = this.#getSelectorData('adPlayback_lbl');

  adPods_lbl = this.#getSelectorData('adPods_lbl');

  closedCaption_lbl = this.#getSelectorData('closedCaption_lbl');

  watchNow_lbl = this.#getSelectorData('watchNow_lbl');

  playBackAutoPreview_lbl = this.getElementByPage(
    'settingsPage',
    'playBackAutoPreview_lbl',
  );

  playBackAutoNextEpisode_lbl = this.getElementByPage(
    'settingsPage',
    'playBackAutoNextEpisode_lbl',
  );

  playBackAutoNextEpisodeToggle_lbl = this.getElementByPage(
    'settingsPage',
    'playBackAutoNextEpisodeToggle_lbl',
  );

  focusedSettingsMenuPlayback_text = this.getElementByPage(
    'settingsPage',
    'focusedSettingsMenuPlayback_text',
  );

  search_txtBx = this.getElementByPage('searchPage', 'search_txtBx');

  firstThumbnailOnSearch = this.getElementByPage(
    'searchPage',
    'firstThumbnailOnSearch',
  );

  showTitle_lbl = this.getElementByPage('searchPage', 'focusedShowTitle_lbl');

  cwRail_lbl = this.getElementByPage('homePage', 'cwRail_lbl');

  videoAsset = {
    Movie: testdataHelper.getContent('videoPlayerPage.rokuMovie'),
    Series: testdataHelper.getContent('videoPlayerPage.rokuSeries'),
    'Mini Series': testdataHelper.getContent('videoPlayerPage.rokuMiniSeries'),
    'Topical Series': testdataHelper.getContent(
      'videoPlayerPage.rokuTopicalSeries',
    ),
    Episode: testdataHelper.getContent('videoPlayerPage.rokuEpisode'),
    Extra: testdataHelper.getContent('videoPlayerPage.rokuExtra'),
    Live: testdataHelper.getContent('videoPlayerPage.rokuLive'),
    'Sports VOD': testdataHelper.getContent('videoPlayerPage.rokuSportsVOD'),
    Podcast: testdataHelper.getContent('videoPlayerPage.rokuPodcast'),
  };

  scurbPercentage = 0;

  lastPlayedContent = '';

  upNextVideo_img = this.getElementByPage('searchPage', 'upNextVideo_img');

  verifyVideoPlayerAnchorDetails = async () => {
    await commons.assertVideoIsPlaying();
    await commons.assertExists(this.videoPlayerScene);
  };

  isVideoPlaying = async () => {
    await this.verifyVideoPlayerAnchorDetails();
  };

  scrubVideo = async (percentage) => {
    await commons.scrubVideo(this.currentTime, percentage);
    this.scurbPercentage = Number(percentage);
  };

  validateResumePoint = async (percentage) => {
    const refPercentage = percentage || this.scurbPercentage;
    const video = await commons.videoDetails();
    const newVideoPosition = video.videoPos / 1000;
    const videoLength = video.videoLength / 1000;
    const actualPercentage = (newVideoPosition * 100) / videoLength;

    ok(
      actualPercentage <= refPercentage + 2 &&
        actualPercentage >= refPercentage - 2,
      `Actual: ${actualPercentage}%, Expected: ${this.scurbPercentage}%`,
    );
  };

  /**
   * Function to Stop video playback and
   * Play it from the Continue Watching rail
   *
   */
  resumeAndPlayVideo = async () => {
    await commons.userAction(VRC.BACK, 1, 2);
    await this.navigateToHome();
    await this.scrollToRail('Continue Watching');
    await this.scrollToContent(this.lastPlayedContent);
    await commons.userAction(VRC.ENTER, 1, 1);
    await commons.waitTillVideoIsPlaying();
  };

  /**
   * Scroll to content in Continue Watching rail
   *
   * @param {'string'} content name of the content
   */
  scrollToContent = async (content) => {
    if (!content) {
      return;
    }
    const contentList = [];
    let flag = false;

    while (flag !== true) {
      const contentName = String(
        await commons.fetchAttributeData(this.cwRail_lbl, PROP.TEXT_CONTENT),
      ).trim();

      if (contentName === content) {
        flag = true;
        break;
      }
      if (contentList.includes(contentName)) {
        break;
      }
      contentList.push(contentName);
      await commons.userAction(VRC.RIGHT, 1, 2);
    }
    if (flag === false) {
      throw new Error(`${content} is not present in Continue Watching`);
    }
  };

  /**
   * Navigate to Search menu and Play the content
   *
   * @param {string} contentName Type of content to be played
   */
  searchAndPlay = async (contentName) => {
    await this.navigateToPage('Search');
    await commons.assertExists(this.search_txtBx, 10);
    await commons.sendText(contentName);
    await commons.tryUntil(this.showTitle_lbl, VRC.RIGHT, 10, 1);
  };

  /**
   * Navigate and play given content type
   *
   * @param {string} contentType Type of content to be played
   */
  navigateAndPlay = async (contentType) => {
    const contentName = this.videoAsset.contentType
      ? this.videoAsset[contentType]
      : this.videoAsset.Movie;

    this.lastPlayedContent = contentName;
    await this.searchAndPlay(contentName);
    const searchShowTitle = await commons.fetchAttributeData(
      this.showTitle_lbl,
      PROP.TEXT_CONTENT,
    );

    if (searchShowTitle === contentName) {
      await commons.userAction(VRC.ENTER, 1, 3);
      await commons.assertExists(this.watchNow_lbl);
      await commons.userAction(VRC.ENTER, 1, 3);
    }
    await commons.waitTillVideoIsPlaying();
  };

  switchToOrientation = async () => {
    // Not applicable to Roku
  };

  verifyVideoOrientation = async () => {
    await commons.assertVideoIsPlaying();
  };

  verifyAdPods = async () => {
    ok(
      await commons.assertExists(this.adPods_lbl, 5),
      'Not able to view the AdPods',
    );
  };

  verifyAdPlayBack = async () => {
    await commons.waitUntil(this.adPlayback_lbl);
    await commons.assertExists(this.adPlayback_lbl);
  };

  verifyCC = async () => {
    await commons.assertDoesNotExist(this.closedCaption_lbl, 10);
  };

  verifyProgressBar = async () => {
    await commons.assertExists(this.videoPlayerScene);
    await commons.assertExists(this.videoProgressBar);
  };

  verifyAdStreamElements = async (actionType) => {
    if (actionType === 'Play Button') {
      await commons.assertExists(this.play_Button, 5);
    } else if (actionType === 'Pause Button') {
      await commons.assertExists(this.pause_Button, 5);
    } else if (actionType === 'Ad counter') {
      await commons.assertExists(this.adCounter_lbl, 5);
    } else if (actionType === 'FullScreen Button') {
      await commons.assertExists(this.videoPlayerScene);
      // Not applicable to Roku
    }
  };

  setAutoPlayMode = async (autoplaySetting) => {
    await this.openMenu();
    await this.navigateToPage('Settings');
    await commons.assertExists(this.this.focusedSettingsMenuPlayback_text, 5);
    await commons.userAction(VRC.RIGHT);
    await commons.assertExists(this.playBackAutoPreview_lbl, 5);
    await commons.userAction(VRC.DOWN);
    switch (autoplaySetting) {
      case 'On':
        await commons.assertExists(this.playBackAutoNextEpisode_lbl, 5);
        await commons.assertExists(this.playBackAutoNextEpisodeToggle_lbl, 5);
        await commons.userAction(VRC.SELECT);
        await commons.assertProperty(
          this.playBackAutoNextEpisodeToggle_lbl,
          PROP.TEXT_CONTENT,
          'On',
          COMP.EQUAL,
        );
        break;
      case 'Off':
        await commons.assertExists(this.playBackAutoNextEpisode_lbl, 5);
        await commons.assertExists(this.playBackAutoNextEpisodeToggle_lbl, 5);
        await commons.userAction(VRC.SELECT);
        await commons.assertProperty(
          this.playBackAutoNextEpisodeToggle_lbl,
          PROP.TEXT_CONTENT,
          'Off',
          COMP.EQUAL,
        );
        break;
      default:
        break;
    }
    await this.openMenu();
    await this.navigateToPage('Search');
    await commons.assertExists(this.search_txtBx, 10);
    const searchShow = testdataHelper.getContent(`searchPage.showName1`);

    await commons.sendText(searchShow);
    await commons.tryUntil(this.firstThumbnailOnSearch, VRC.RIGHT, 10, 1);
    await commons.userAction(VRC.SELECT, 2, 2);
  };

  verifyPlayStatus = async (playStatus) => {
    if (playStatus === 'Start Playing') {
      await commons.assertExists(this.upNextVideo_img, 10);
      await commons.waitTillVideoIsPlaying();
      await commons.assertVideoIsPlaying();
    } else if (playStatus === 'Does Not Play') {
      await commons.assertDoesNotExists(this.upNextVideo_img, 10);
    }
  };
}

module.exports = VideoPlayerPage;
