const { BasePage, remoteActions } = require('./basePage');

const HomePage = require('./homePage');

const home = new HomePage();

const ProfilePage = require('./profilePage');

const profile = new ProfilePage();

const commons = remoteActions;
const { VRC, PROP } = commons;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  startStreaming_text = this.getElementByPage(
    'welcomePage',
    'startStreaming_text',
  );

  focusedSignIn_button = this.#getSelectorData('focusedSignIn_button');

  continue_btn = this.#getSelectorData('continue_btn');

  useYourRemote_button = this.getElementByPage(
    'signInPage',
    'useYourRemote_button',
  );

  sign_in_text = this.getElementByPage('signInPage', 'sign_in_text');

  email_field = this.getElementByPage('signInPage', 'email_field');

  password_field = this.getElementByPage('signInPage', 'password_field');

  signIn_button = this.getElementByPage('signInPage', 'signIn_button');

  whoWatching_Label = this.getElementByPage(
    'selectProfilePage',
    'whoWatching_Label',
  );

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  loadInvisible_img = this.#getSelectorData('loadInvisible_img');

  focusedProfilePage = this.getElementByPage(
    'selectProfilePage',
    'focusedProfilePage',
  );

  focusedProfileName_text = this.getElementByPage(
    'mainNavigationPage',
    'focusedProfileName_text',
  );

  moveToFirstProfileAndSignOut = async () => {
    await commons.assertExists(this.focusedProfilePage, 10);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.focusedHomePage, 10);
    await home.signOut();
  };

  signOutApplication = async () => {
    if (await commons.elementExists(this.whoWatching_Label, 2)) {
      await this.moveToFirstProfileAndSignOut();
    }
    if (await commons.elementExists(this.focusedHomePage, 5)) {
      await this.openMenu();
      let profileName = await commons.fetchAttributeData(
        this.focusedProfileName_text,
        PROP.TEXT_CONTENT,
      );

      profileName = profileName.toUpperCase();
      if (profileName.includes('KID')) {
        await profile.moveToProfilePage();
        await profile.moveToFirstProfile();
        await profile.selectDefaultProfile();
      } else {
        await commons.userAction(VRC.ENTER);
        await commons.assertExists(this.focusedHomePage, 10);
      }
      await home.signOut();
    }
  };

  openApp = async () => {
    await commons.openApp();
    await this.signOutApplication();
  };

  // TODO: This function required a @wbd/gqa-core update GQA-14349
  // async getCreds(credentialType) {
  //   let creds;
  //   const FeatureName = await globalHooks.getFeatureName();

  //   featureName = FeatureName.gherkinDocument.feature.name;
  //   // const scenarioName = FeatureName.gherkinDocument.feature.children[1].scenario.name;

  //   if (featureName === 'Member Feed') {
  //     creds = `${credentialType}${this.randomIntFromInterval(1, 3)}`;
  //   } else if (featureName === 'Account Page') {
  //     creds = `${credentialType}${this.randomIntFromInterval(1, 3)}`;
  //   } else if (featureName === 'User Profiles') {
  //     creds = `${credentialType}${this.randomIntFromInterval(1, 3)}`;
  //   }
  //   return creds;
  // }

  async enterCredentials(credentialType) {
    // TODO: This function required a @wbd/gqa-core update GQA-14349
    // const cred = await this.getCreds(credentialType);
    // const username = process.env[`${cred}_USERNAME`];
    // const password = process.env[`${cred}_PASSWORD`];

    const username = process.env[`${credentialType}-USERNAME`];
    const password = process.env[`${credentialType}-PASSWORD`];

    await commons.userAction(VRC.ENTER, 1, 2);
    await commons.sendText(username);
    await commons.userAction(VRC.BACK, 1, 3);
    await commons.userAction(VRC.DOWN, 1, 3);
    await commons.userAction(VRC.ENTER, 1, 3);
    await commons.sendText(password);
    await commons.userAction(VRC.BACK, 1, 3);
    await commons.tryUntil(this.signIn_button, VRC.DOWN, 5, 1);
    await commons.userAction(VRC.ENTER);
    if (await commons.elementExists(this.whoWatching_Label, 10)) {
      await commons.userAction(VRC.ENTER);
    }
    await commons.assertExists(this.focusedHomePage, 10);
    await this.openMenu();
    let profileName = await commons.fetchAttributeData(
      this.focusedProfileName_text,
      PROP.TEXT_CONTENT,
    );

    profileName = profileName.toUpperCase();
    if (profileName.includes('KID')) {
      await profile.moveToProfilePage();
      await profile.moveToFirstProfile();
      await profile.selectDefaultProfile();
    } else {
      await commons.userAction(VRC.ENTER);
      await commons.assertExists(this.focusedHomePage, 10);
    }
  }

  navigateToSignInScreen_US = async (userType) => {
    await commons.assertExists(this.startStreaming_text, 15);
    await commons.tryUntil(this.focusedSignIn_button, VRC.RIGHT, 3);
    await commons.userAction(VRC.ENTER);
    await commons.tryUntil(this.useYourRemote_button, VRC.DOWN, 2);
    await commons.userAction(VRC.ENTER);
    await commons.userAction(VRC.RIGHT);
    await commons.assertExists(this.continue_btn, 10);
    await commons.userAction(VRC.DOWN, 2, 3);
    await commons.userAction(VRC.ENTER, 1, 2);
    await this.enterCredentials(userType);
  };

  loginToApplication = async (credentialType) => {
    if (this.returnGeoLocation() === 'america') {
      await commons.assertExists(this.startStreaming_text, 20);
      await this.navigateToSignInScreen_US(credentialType);
    }
  };

  loadingInvisible = async () => {
    await commons.assertExists(this.loadInvisible_img, 10);
  };

  verifySignOut = async () => {
    await commons.assertExists(this.startStreaming_text, 5);
  };
}
module.exports = SignInPage;
