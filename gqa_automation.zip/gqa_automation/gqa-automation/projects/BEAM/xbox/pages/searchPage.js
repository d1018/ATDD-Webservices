const assert = require('assert');
const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const { VRC, PROP, COMP } = commons;

let searchBarDefaultTextLabel;

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  focusedKeyboard = this.#getSelectorData('focusedKeyboard');

  searchPlaceholderText_txt = this.#getSelectorData(
    'searchPlaceholderText_txt',
  );

  tileInfoTitle = this.#getSelectorData('tileInfoTitle_txt');

  searchResultsRail = this.#getSelectorData('searchResultsRail');

  searchResultTile = this.#getSelectorData('searchResultTile');

  userActionArray = [];

  /**
   * This function returns an array that determines how to navigate
   * the keyboard and the associated button presses.
   *
   * @param {string} contentType - content to search
   */
  enterSearchQuery = async (contentType) => {
    const searchString = await testdataHelper.getContent(
      `searchPage.${contentType}`,
    );

    searchBarDefaultTextLabel = await commons.fetchAttributeData(
      this.searchPlaceholderText_txt,
      PROP.TEXT_CONTENT,
    );

    await commons.waitUntil(this.focusedKeyboard, 3);
    await commons.assertExists(this.focusedKeyboard);

    /* The userActionArray is populated with the keyboard traversal
    logic which decides how to trigger movement across the keyboard and
    letter presses. */
    this.userActionArray = await this.prepareUserActionArray(searchString);
    await this.traverseKeyboard(this.userActionArray, 0.5, 0.5);
  };

  /**
   * This function verifies if the search field was populated
   * by the search string.
   *
   * @param {string} searchQuery - search query
   */
  verifySearchQuery = async (searchQuery) => {
    const showName = await testdataHelper.getContent(
      `searchPage.${searchQuery}`,
    );

    assert(
      searchBarDefaultTextLabel !== showName,
      'Search query is not replaced',
    );
  };

  /**
   * This function verifies if the search results contain
   * the search query and will throw error if not found.
   *
   * @param {string} searchQuery - search query
   */
  verifySearchResult = async (searchQuery) => {
    const showName = await testdataHelper.getContent(
      `searchPage.${searchQuery}`,
    );

    let trials = 0;

    await commons.assertExists(this.searchResultsRail, 5);
    await commons.tryUntil(this.searchResultTile, VRC.RIGHT, 10);

    while (trials <= 5) {
      if (
        await commons.checkProperty(
          this.getCustomLocator(this.tileInfoTitle, showName),
          PROP.TEXT_CONTENT,
          showName,
          COMP.EQUAL,
        )
      ) {
        break;
      } else {
        await commons.userAction(VRC.RIGHT);
        trials++;
      }
    }

    if (trials > 5) {
      throw new Error('Search query not found in results');
    }
  };
}

module.exports = new SearchPage();
