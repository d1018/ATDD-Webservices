const { BasePage, remoteActions } = require('./basePage');
const menuPage = require('./menuPage');

const commons = remoteActions;
const { VRC } = commons;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  useQRCode_button = this.#getSelectorData('useQRCode_button');

  useKeyboard_button = this.#getSelectorData('useKeyboard_button');

  focusedUseKeyboard_button = this.#getSelectorData(
    'focusedUseKeyboard_button',
  );

  emailTextBox_field = this.#getSelectorData('emailTextBox_field');

  focusedEmailTextBox_field = this.#getSelectorData(
    'focusedEmailTextBox_field',
  );

  passwordTextBox_field = this.#getSelectorData('passwordTextBox_field');

  focusedPasswordTextBox_field = this.#getSelectorData(
    'focusedPasswordTextBox_field',
  );

  focusedSignIn_button = this.#getSelectorData('focusedSignIn_button');

  focusedProfile = this.getElementByPage('profilePage', 'focusedProfile');

  startStreaming_title = this.getElementByPage(
    'welcomePage',
    'startStreaming_title',
  );

  signInFlow_button = this.getElementByPage('welcomePage', 'signInFlow_button');

  openApp = async () => {
    await commons.clearAppData();
    // For Headspin devices still logged in from previous sessions
    await commons.closeApp();
    await commons.openApp();
    await commons.assertExists(this.startStreaming_title, 120);
  };

  loginToApplication = async (credentialType) => {
    await menuPage.navigateToPage('Signin');
    await this.navigateToSignInScreen_US();
    await this.enterCredentials(credentialType);
    await commons.waitUntilVisible(this.focusedProfile, 20);
  };

  navigateToSignInScreen_US = async () => {
    await commons.waitUntil(this.useQRCode_button, 15);
    await commons.tryUntil(this.focusedUseKeyboard_button, VRC.DOWN, 2, 1);
    await commons.tryUntil(this.focusedEmailTextBox_field, VRC.RIGHT, 4, 1);
  };

  enterCredentials = async (credentialType) => {
    const username = process.env[`${credentialType}_USERNAME`];
    const password = process.env[`${credentialType}_PASSWORD`];

    await commons.assertExists(this.emailTextBox_field, 3);
    await commons.userAction(VRC.SELECT);
    await this.setTextForXbox(username);
    await commons.userAction(VRC.DOWN);
    await commons.userAction(VRC.SELECT);
    await this.setTextForXbox(password);
    await commons.tryUntil(this.focusedSignIn_button, VRC.DOWN, 3);
    await commons.userAction(VRC.ENTER);
  };

  verifySignOut = async () => {
    await commons.assertExists(this.signInFlow_button, 30);
  };
}

module.exports = new SignInPage();
