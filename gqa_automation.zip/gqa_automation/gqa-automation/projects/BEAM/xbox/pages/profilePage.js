const { BasePage, remoteActions } = require('./basePage');
const menuPage = require('./menuPage');

const commons = remoteActions;
const { VRC } = commons;
let newProfileName;
const editedProfileName = 'editedProfile';

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  focusedAddProfile_button = this.#getSelectorData('focusedAddProfile_button');

  focusedProfileName_field = this.#getSelectorData('focusedProfileName_field');

  focusedAvatar = this.#getSelectorData('focusedAvatar');

  focusedKidsMode = this.#getSelectorData('focusedKidsMode');

  focusedProfile = this.#getSelectorData('focusedProfile');

  focusedProfileName_txt = this.#getSelectorData('focusedProfileName_txt');

  whoIsWatching_label = this.#getSelectorData('whoIsWatching_label');

  done_button = this.#getSelectorData('done_button');

  delete_button = this.#getSelectorData('delete_button');

  focusedDone_button = this.#getSelectorData('focusedDone_button');

  focusedDelete_button = this.#getSelectorData('focusedDelete_button');

  focusedDeletePageDelete_button = this.#getSelectorData(
    'focusedDeletePageDelete_button',
  );

  addProfile_button = this.#getSelectorData('addProfile_button');

  edit_profileNameField_text = this.#getSelectorData(
    'edit_profileNameField_text',
  );

  focusedProfilePicker = this.#getSelectorData('focusedProfilePicker');

  focused_editProfile_button = this.#getSelectorData(
    'focused_editProfile_button',
  );

  editProfilePage_Title = this.#getSelectorData('editProfilePage_Title');

  deleteProfilePage_title = this.#getSelectorData('deleteProfilePage_title');

  focusedFirstProfile = this.#getSelectorData('focusedFirstProfile');

  customTexture_text = this.getElementByPage(
    'customLocators',
    'customTexture_text',
  );

  verifyProfileScreen = async () => {
    await commons.assertExists(this.focusedProfile, 20);
  };

  selectProfile = async (profileType) => {
    await commons.assertExists(this.whoIsWatching_label, 10);
    if (profileType.toLowerCase() !== 'any') {
      await this.navigateToProfile(profileType);
    }
    await commons.assertExists(this.focusedProfile, 5);
    await commons.userAction(VRC.ENTER);
  };

  createNewProfile = async (profileType) => {
    // // Profile name is only 14 chars
    newProfileName = String(`${profileType}${this.getCurrentTime()}`);

    if (newProfileName.length > 14) {
      newProfileName = newProfileName.substr(0, 13);
    }
    await commons.assertExists(this.whoIsWatching_label, 10);
    if (await commons.doesNotExist(this.addProfile_button)) {
      await this.deleteExistingProfile();
    }
    await commons.tryUntil(this.focusedAddProfile_button, VRC.RIGHT, 5);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.focusedAvatar, 20);
    await commons.userAction(VRC.ENTER);
    await commons.tryUntil(this.focusedProfileName_field, VRC.UP, 2);
    await commons.userAction(VRC.ENTER);
    await this.setTextForXbox(newProfileName);
    await commons.tryUntil(this.focusedDone_button, VRC.DOWN, 5);
    await commons.userAction(VRC.ENTER);
  };

  profileCreation = async (profileType) => {
    await this.createNewProfile(profileType);
    await this.selectProfile(newProfileName);
  };

  deleteExistingProfile = async () => {
    if (await commons.doesNotExist(this.editProfilePage_Title, 5)) {
      if (await commons.doesNotExist(this.focusedProfile)) {
        await menuPage.navigateToPage('Profile');
      }
      await this.moveToFirstProfile();
      await commons.assertExists(this.focusedProfile, 10);
      await commons.userAction(VRC.DOWN);
      await commons.userAction(VRC.ENTER);
      await commons.assertExists(this.done_button, 10);
      while (await commons.doesNotExist(this.delete_button)) {
        await commons.userAction(VRC.BACK);
        await commons.assertExists(this.focusedProfile, 10);
        await commons.userAction(VRC.RIGHT);
        await commons.userAction(VRC.DOWN);
        await commons.userAction(VRC.ENTER);
        try {
          await commons.assertExists(this.delete_button);
        } catch (error) {
          throw new Error('Delete button is missing in Edit profile ');
        }
      }
    }
    await this.deleteFromEditProfile();
  };

  createNewProfileAndMoveToEdit = async (profileType) => {
    await this.createNewProfile(profileType);
    await commons.waitUntil(this.focusedProfile, 10);
    await commons.tryUntil(this.focused_editProfile_button, VRC.DOWN, 2);
    await commons.userAction(VRC.ENTER);
  };

  editUserProfile = async () => {
    await commons.waitUntil(this.editProfilePage_Title, 10);
    if (await commons.doesNotExist(this.editProfilePage_Title, 5)) {
      await commons.assertExists(this.focusedProfile, 10);
      await commons.tryUntil(this.focused_editProfile_button, VRC.DOWN, 2);
      await commons.userAction(VRC.ENTER);
    }
    await commons.assertExists(this.editProfilePage_Title);
    await commons.tryUntil(this.focusedProfileName_field, VRC.UP, 2);
    await commons.userAction(VRC.ENTER);
    await this.setTextForXbox(editedProfileName);
    await commons.tryUntil(this.focusedDone_button, VRC.DOWN, 5);
    await commons.userAction(VRC.ENTER);
  };

  verifyEditedProfile = async () => {
    await commons.waitUntil(this.focusedProfile, 10);
    await commons.assertVisible(
      this.getCustomLocator(this.customTexture_text, editedProfileName),
      10,
    );
  };

  /**
   * This Method move the user focus to the first profile
   */
  moveToFirstProfile = async () => {
    await commons.assertExists(this.whoIsWatching_label, 10);
    await commons.tryUntil(this.focusedFirstProfile, VRC.LEFT, 5);
  };

  /**
   * This Method navigates the user focus to the Profile as per the name provided
   *
   * @param {string} profileName This parameters accepts the name of the profile to which we want to naviagate to
   */
  navigateToProfile = async (profileName) => {
    if (
      commons.doesNotExist(
        this.getCustomLocator(this.focusedProfileName_txt, profileName),
      )
    ) {
      await this.moveToFirstProfile();
      for (let i = 0; i < 5; i++) {
        if (
          await commons.elementExists(
            this.getCustomLocator(this.focusedProfileName_txt, profileName),
          )
        ) {
          break;
        } else if (i === 4) {
          throw new Error(`Profile: ${profileName} doesnot exist`);
        }
        await commons.userAction(VRC.RIGHT, 1);
      }
    }
  };

  /**
   * Navigate to delete option and deletes the profile from Delete Page
   * i.e Current page is Edit Profile
   */
  deleteFromEditProfile = async () => {
    await commons.tryUntil(this.focusedDone_button, VRC.DOWN, 5);
    await commons.tryUntil(this.focusedDelete_button, VRC.RIGHT, 5);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.deleteProfilePage_title, 10);
    await commons.tryUntil(this.focusedDeletePageDelete_button, VRC.RIGHT, 5);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.addProfile_button, 10);
  };
}

module.exports = new ProfilePage();
