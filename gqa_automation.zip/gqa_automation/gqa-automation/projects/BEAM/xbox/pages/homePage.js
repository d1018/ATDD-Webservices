const { BasePage, remoteActions } = require('./basePage');
const menuPage = require('./menuPage');
const settingsPage = require('./settingsPage');
const signInPage = require('./signInPage');

const commons = remoteActions;
const { VRC } = commons;

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  focusedRailVideo = this.#getSelectorData('focusedRailVideo');

  homeTab_lbl = this.#getSelectorData('homeTab_lbl');

  customTexture_text = this.getElementByPage(
    'customLocators',
    'customTexture_text',
  );

  signOut = async () => {
    await menuPage.navigateToPage('Settings');
    await settingsPage.signOut();
    await signInPage.verifySignOut();
  };

  scrollToFirstRailVideo = async () => {
    while (await commons.doesNotExist(this.focusedRailVideo)) {
      await commons.userAction(VRC.DOWN);
      if (await commons.elementExists(this.focusedRailVideo)) break;
    }
  };

  isRailPresent = async (railName) => {
    for (let count = 0; count < 20; count++) {
      if (
        await commons.elementExists(
          this.getCustomLocator(this.customTexture_text, railName),
        )
      )
        return true;
    }
    return false;
  };

  verifyMyListRailOnHomePage = async (railStatus) => {
    await menuPage.navigateToPage('Home');
    await commons.assertExists(this.homeTab_lbl, 10);
    await this.scrollToFirstRailVideo();
    if (railStatus) {
      await commons.assertExists(
        this.getCustomLocator(this.customTexture_text, 'My List'),
      );
    } else {
      await commons.assertDoesNotExist(
        this.getCustomLocator(this.customTexture_text, 'My List'),
      );
    }
  };
}

module.exports = new HomePage();
