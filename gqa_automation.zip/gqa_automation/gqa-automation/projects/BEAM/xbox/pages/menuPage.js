const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  focusedProfile_button = this.#getSelectorData('focusedProfile_button');

  focusedHome_button = this.#getSelectorData('focusedHome_button');

  signInFlow_button = this.getElementByPage('welcomePage', 'signInFlow_button');

  whoIsWatching_label = this.getElementByPage(
    'profilePage',
    'whoIsWatching_label',
  );

  focusedSignInFlow_button = this.getElementByPage(
    'welcomePage',
    'focusedSignInFlow_button',
  );

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  pageValue = this.getElementByPage(
    'customLocators',
    'focused_child_texture_text',
  );

  pageFocused = {
    Home: this.focusedHomePage,
  };

  openMenu = async () => {
    await commons.tryUntil(this.focusedHome_button, VRC.BACK, 4, 1);
  };

  navigateToPage = async (pageValue) => {
    switch (pageValue) {
      case 'Signin':
        await commons.assertExists(this.signInFlow_button, 60);
        await commons.tryUntil(this.focusedSignInFlow_button, VRC.RIGHT, 6);
        await commons.userAction(VRC.ENTER);
        break;
      default:
        if (await commons.elementExists(this.whoIsWatching_label, 2)) {
          await commons.userAction(VRC.ENTER);
          await commons.assertVisible(this.focusedHomePage, 20);
        }
        await this.openMenu();
        await commons.tryUntil(this.focusedProfile_button, VRC.UP, 6);
        if (pageValue !== 'Profile') {
          await commons.tryUntil(
            this.getCustomLocator(this.pageValue, pageValue),
            VRC.DOWN,
            6,
          );
        }
        await commons.userAction(VRC.ENTER);
        break;
    }
  };

  assertPage = async (pageValue) => {
    await commons.assertVisible(this.pageFocused[pageValue], 30);
  };
}

module.exports = new MenuPage();
