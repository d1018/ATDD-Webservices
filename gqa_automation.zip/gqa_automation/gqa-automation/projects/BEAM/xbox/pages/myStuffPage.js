const { remoteActions, BasePage, testdataHelper } = require('./basePage');
const homepage = require('./homePage');
const menuPage = require('./menuPage');

const commons = remoteActions;
const { VRC } = commons;

class MyStuffPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myStuffPage', locator);
  }

  noSavedTitles_txt = this.#getSelectorData('noSavedTitles_txt');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  homeTab_lbl = this.getElementByPage('homePage', 'homeTab_lbl');

  continueWatchingRail = this.getElementByPage(
    'homePage',
    'continueWatchingRail',
  );

  focusedRailVideo = this.getElementByPage('homePage', 'focusedRailVideo');

  focusedWatchNow_btn = this.getElementByPage(
    'searchPage',
    'focusedWatchNow_btn',
  );

  focusedMyListAdd_btn = this.getElementByPage(
    'searchPage',
    'focusedMyListAdd_btn',
  );

  focusedMyListRemove_btn = this.getElementByPage(
    'searchPage',
    'focusedMyListRemove_btn',
  );

  focusedSearchPage = this.getElementByPage('searchPage', 'focusedSearchPage');

  focused_child_texture_text = this.getElementByPage(
    'customLocators',
    'focused_child_texture_text',
  );

  customTexture_text = this.getElementByPage(
    'customLocators',
    'customTexture_text',
  );

  selectMyList = async () => {
    await commons.userAction(VRC.UP, 2);
    await commons.tryUntil(
      this.getCustomLocator(
        this.focused_child_texture_text,
        testdataHelper.getContent('myStuffPage.myList_tab'),
      ),
      VRC.DOWN,
      2,
    );
  };

  verifyMyListContent = async () => {
    await commons.assertExists(
      this.getCustomLocator(
        this.focused_child_texture_text,
        testdataHelper.getContent('myStuffPage.myList_tab'),
      ),
      5,
    );
    await commons.assertExists(this.noSavedTitles_txt, 5);
  };

  navigateToShowTileFromHomePageRail = async () => {
    await commons.assertExists(this.homeTab_lbl, 10);
    await homepage.scrollToFirstRailVideo();
    await commons.userAction(VRC.DOWN);
    await commons.assertExists(this.focusedRailVideo, 2);
    await commons.userAction(VRC.ENTER);
  };

  addShowToMylistFromHomePage = async () => {
    await commons.assertExists(this.focusedWatchNow_btn, 5);
    await commons.tryUntil(this.focusedMyListAdd_btn, VRC.RIGHT, 2);
    await commons.userAction(VRC.ENTER);
  };

  addShowsToMylist = async () => {
    await menuPage.navigateToPage('Home');
    await this.navigateToShowTileFromHomePageRail();
    await this.addShowToMylistFromHomePage();
    await commons.assertExists(this.focusedMyListRemove_btn, 5);
  };

  verifyMyListData = async (isShowPresent) => {
    await menuPage.navigateToPage('My Stuff');
    await commons.userAction(VRC.UP, 2);
    await commons.tryUntil(
      this.getCustomLocator(
        this.focused_child_texture_text,
        testdataHelper.getContent('myStuffPage.myList_tab'),
      ),
      VRC.DOWN,
      2,
    );
    await commons.userAction(VRC.DOWN);
    if (isShowPresent === true) {
      await commons.assertExists(this.focusedRailVideo, 5);
    } else {
      await commons.assertDoesNotExist(this.focusedRailVideo, 5);
    }
  };
}

module.exports = new MyStuffPage();
