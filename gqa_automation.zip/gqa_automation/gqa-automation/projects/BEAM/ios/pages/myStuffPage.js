// const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class MyStuffPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myStuffPage', locator);
  }

  myList_tab = this.#getSelectorData('myList_tab');

  myListTab_Focused = this.#getSelectorData('myListTab_Focused');

  /**
   * Select the MyList Tab in MyStuff page
   */
  selectMyList = async () => {
    await commons.click(this.myList_tab, 20);
    await commons.waitUntil(this.myListTab_Focused, 20);
  };

  /**
   * This function used to verify the MyList Content Before adding anything to MyList.
   */
  verifyMyListContent = async () => {
    // assert(
    //     await commons.elementExists(this.noSavedTitles_title),
    //     `No saved title is not visible`,
    // );
  };

  addShowsToMylist = async () => {};

  verifyMyListData = async () => {};
}

module.exports = MyStuffPage;
