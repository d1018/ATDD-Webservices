// const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  profileName = '';

  updatedProfName = '';

  profileName_text = this.getElementByPage(
    'myProfileSettings',
    'profileName_text',
  );

  profile_rail = this.getElementByPage('myProfileSettings', 'profile_rail');

  profileNameList = this.getElementByPage(
    'myProfileSettings',
    'profileNameList',
  );

  addProfile_btn = this.getElementByPage('myProfileSettings', 'addProfile_btn');

  manageProfiles_button = this.getElementByPage(
    'myProfileSettings',
    'manageProfiles_button',
  );

  createProfileTitle = this.getElementByPage(
    'addProfile',
    'createProfileTitle',
  );

  profileName_field = this.getElementByPage('addProfile', 'profileName_field');

  save_button = this.getElementByPage('addProfile', 'save_button');

  closeOrBack_button = this.getElementByPage(
    'myProfileSettings',
    'closeOrBack_button',
  );

  editProfile = this.getElementByPage('addProfile', 'editProfile');

  profilesList = {
    Default: this.getCustomLocator(this.profileName_text, 'Default'),
    Standard: this.getCustomLocator(this.profileName_text, 'Standard'),
  };

  #toggleKidsProfile = async () => {
    await commons.click(this.kidsProfileToggle_btn);
  };

  isProfileExist = async (profileName) => {
    const profileNames = await commons.findElements(this.profileNameList);

    return profileNames.includes(
      this.getCustomLocator(this.profileName_text, profileName),
    );
  };

  isAddProfileOptionVisible = async () => {
    const result = await commons.elementExists(this.addProfile_btn, 30);

    return result;
  };

  selectProfile = async () => {
    // if (await commons.elementExists(this.closeOrBack_button, 30)) {
    //   await commons.click(this.closeOrBack_button);
    // }
    // if (await commons.elementExists(this.home_button, 30)) {
    //   await this.navigateToPage('Home');
    //   await this.navigateToPage('Account');
    // }
    // if (profileType.length === 0 || profileType === 'Anonymous') {
    //   this.isUserAnonymousType = true;
    //   return;
    // }
    // if (profileType === 'Pin') {
    //   await this.navigateToPage('Account');
    // }
    // if (
    //   this.profilesList[profileType] !== undefined &&
    //   this.profilesList[profileType] !== null
    // ) {
    //   if (!(await commons.elementExists(this.profilesList[profileType], 10))) {
    //     await commons.swipeOnElement(this.profile_rail, 'left');
    //   }
    //   await this.isProfileExist(profileType);
    //   await commons.click(this.profilesList[profileType], 10);
    // } else {
    //   const profileLbl = this.getCustomLocator(
    //     this.profileName_text,
    //     this.profileName,
    //   );
    //   if (!(await commons.elementExists(profileLbl, 30))) {
    //     await commons.swipeOnElement(this.profile_rail, 'left');
    //   }
    //   await commons.waitUntil(profileLbl, 30);
    //   await commons.click(profileLbl, 10);
    // }
    // if (profileType === 'Pin') {
    //   await commons.sendPassKeys(process.env.PROFILE_PIN);
    // }
    // if (profileType === 'Kids') {
    //   this.isKidsProfile = true;
    // }
    // await commons.waitUntil(this.focusedHomePage, 30);
  };

  createNewProfile = async (profileType) => {
    if (profileType === 'Pin') {
      this.profileName = 'Pin';
      return;
    }
    // await this.selectProfile('Default');
    // await commons.waitUntil(this.focusedHomePage, 30);
    await this.navigateToPage('Account');
    if (!(await this.isAddProfileOptionVisible())) {
      await commons.swipeOnElement(this.profile_rail, 'left');
    }

    if (!(await commons.elementExists(this.addProfile_btn))) {
      // await this.deleteUserProfile('random');
    } else {
      await commons.click(this.addProfile_btn);
    }

    // if (await commons.isDisplayed(this.manageProfiles_button, 30)) {
    // await commons.click(this.manageProfiles_button, 30);
    // await commons.waitUntil(this.manageProfiles_lbl, 30);
    // }

    this.profileName = profileType + Math.floor(Date.now() / 1000);
    // await commons.click(this.addProfile_btn, 20);
    await commons.waitUntil(this.profileName_field, 30);
    await commons.click(this.profileName_field, 20);
    await commons.sendText(this.profileName_field, this.profileName);
    if (profileType === 'Kids') {
      await this.#toggleKidsProfile();
    }
    await commons.click(this.save_button);
    await this.isProfileExist(this.profileName);
  };

  profileCreation = async (profileType) => {
    await this.createNewProfile(profileType);
    await this.selectProfile(this.profileName);
  };

  verifyAddProfileButton = async () => {};

  createNewProfileAndMoveToEdit = async (profileType) => {
    await this.createNewProfile(profileType);
    await this.moveToEdit();
  };

  moveToEdit = async () => {
    await commons.click(this.manageProfiles_button);
    const targetProfile = await this.getCustomLocator(
      this.editProfile,
      this.profileName,
    );

    let retries = 2;

    while (retries-- > 0 && !(await commons.elementExists(targetProfile, 10))) {
      await commons.swipeOnElement(this.profile_rail, 'left');
    }

    await commons.waitUntil(targetProfile);
    await commons.click(targetProfile);
  };

  editUserProfile = async () => {
    this.updatedProfName =
      this.profileName.replace(/\d+/g, '') + Math.floor(Date.now() / 1000);

    await commons.waitUntil(this.profileName_field, 10);
    await commons.clearText(this.profileName_field);
    await commons.sendText(this.profileName_field, this.updatedProfName);
    await commons.click(this.save_button);
  };

  verifyEditedProfile = async () => {
    await this.isProfileExist(this.updatedProfName);
  };

  deleteProfile = async () => {
    // await this.selectProfile('Default');
    // await commons.waitUntil(menuPage.accountMenu_lbl, 30);
    // await commons.click(menuPage.accountMenu_lbl, 30);
    // await this.openManageProfiles();
    // if (!(await commons.elementExists(this.addProfile_btn))) {
    //   await commons.click(this.back_btn);
    //   await this.deleteUserProfile('random');
    // }
    // await this.createNewProfile('Standard');
    // await this.deleteUserProfile(profileType);
  };

  verifyUserProfileDeleted = async () => {
    // if (await commons.elementExists(this.manageProfiles_lbl)) {
    //   await commons.click(this.manageProfiles_lbl);
    // }
    // const nonDefaultProfilesPostDeletion =
    //   await this.getNonDefaultProfilesList();
    // assert.equal(
    //   Number(nonDefaultProfilesPostDeletion.length),
    //   Number(this.nonDefaultProfileList.length - 1),
    //   'Profile Deletion Validation Failed!!',
    // );
  };

  verifyProfileScreen = async () => {};

  deleteExistingProfile = async () => {};
}

module.exports = ProfilePage;
