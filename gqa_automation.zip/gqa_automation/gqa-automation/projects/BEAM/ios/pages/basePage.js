const path = require('path');

const {
  mobileActions,
  customErrors,
  testdataHelper,
} = require('@wbd/gqa-core/support');

const ymlpath = path.resolve(__dirname);

const EnvBase = require('../../../support/env');

const { skipReason } = require('../../../support/skipReason');

const commons = mobileActions;

let isUserAnonymousType;

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }

  home_button = this.getElementByPage('navigation', 'home_menu');

  myStuff_button = this.getElementByPage('navigation', 'myStuff_menu');

  download_button = this.getElementByPage('navigation', 'downloads_menu');

  search_button = this.getElementByPage('navigation', 'search_menu');

  profile_button = this.getElementByPage('navigation', 'profile_button');

  signIn_button = this.getElementByPage('welcomePage', 'signIn_button');

  signIn_button_temp = this.getElementByPage(
    'welcomePage',
    'signIn_button_temp',
  );

  focusedHomePage = this.getElementByPage('navigation', 'home_tab_focused');

  focusedMyStuffPage = this.getElementByPage(
    'myListWithoutUserData',
    'myStuff_title',
  );

  focusedSearchPage = this.getElementByPage(
    'searchPageWarmStart',
    'searchBar_field',
  );

  focusedDownloadsPage = this.getElementByPage(
    'downloadsPage',
    'focusedDownloadsPage',
  );

  focusedSignInPage = this.getElementByPage(
    'welcomePage',
    'signIn_button_temp',
  );

  focusedAccountPage = this.getElementByPage(
    'myProfileSettings',
    'manageProfiles_button',
  );

  menuItem = {
    Signin: this.signIn_button,
    Home: this.home_button,
    'My Stuff': this.myStuff_button,
    Search: this.search_button,
    Downloads: this.download_button,
    Account: this.profile_button,
  };

  pageFocused = {
    Signin: this.focusedSignInPage,
    Home: this.focusedHomePage,
    'My Stuff': this.focusedMyStuffPage,
    Downloads: this.focusedDownloadsPage,
    Search: this.focusedSearchPage,
    Account: this.focusedAccountPage,
  };

  getUserAnonymous() {
    return isUserAnonymousType;
  }

  navigateToPage = async (pageValue) => {
    let retries = 2;

    await commons.waitUntil(this.menuItem[pageValue], 80);

    while (
      retries-- > 0 &&
      !(await commons.elementExists(this.pageFocused[pageValue], 30))
    ) {
      await commons.click(this.menuItem[pageValue], 80);
      // if (this.getUserAnonymous()) {
      //   return;
      // }
    }
    await commons.waitUntil(this.pageFocused[pageValue], 50);
  };

  assertPage = async (pageValue) => {
    await commons.elementExists(this.signIn_button, 15);
    await commons.waitUntil(this.pageFocused[pageValue], 20);
  };
}

module.exports = {
  mobileActions,
  customErrors,
  skipReason,
  testdataHelper,
  BasePage,
};
