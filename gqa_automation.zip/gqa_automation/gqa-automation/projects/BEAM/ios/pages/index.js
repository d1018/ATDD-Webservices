const SignInPage = require('./signInPage');
// const MemberFeedPage = require('./memberFeedPage');
const MyStuffPage = require('./myStuffPage');
const ProfilePage = require('./profilePage');
const MenuPage = require('./menuPage');
const PreLaunchPage = require('./preLaunchPage');
const SearchPage = require('./searchPage');
const HomePage = require('./homePage');
const OnboardingPage = require('./onboardingPage');
const NetworkLandingPage = require('./networkLandingPage');
const VideoPlayerPage = require('./videoPlayerPage');

const signInPage = new SignInPage();
// const memberFeedPage = new MemberFeedPage();
const myStuffPage = new MyStuffPage();
const profilePage = new ProfilePage();
const menuPage = new MenuPage();
const preLaunchPage = new PreLaunchPage();
const searchPage = new SearchPage();
const homePage = new HomePage();
const onboardingPage = new OnboardingPage();
const networkLandingPage = new NetworkLandingPage();
const videoPlayerPage = new VideoPlayerPage();

module.exports = {
  signInPage,
  // memberFeedPage,
  myStuffPage,
  profilePage,
  menuPage,
  preLaunchPage,
  searchPage,
  homePage,
  onboardingPage,
  networkLandingPage,
  videoPlayerPage,
};
