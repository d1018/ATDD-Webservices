const { BasePage } = require('./basePage');

class NetworkLandingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('networkLandingPage', locator);
  }

  selectAndValidateNetworkLandingPage = async () => {
    // const networkName = testdataHelper.getContent(`networkPage.${network}`);
    // let networkList = await this.getListOfShows(this.networkTile_lbl);
    // if (
    //   (this.returnGeoLocation() === 'america' && network === 'Entertainment') ||
    //   (this.returnGeoLocation() === 'emea' &&
    //     network === ('Entertainment' || 'Sports'))
    // ) {
    //   while (!networkList.includes(networkName)) {
    //     await commons.swipeOnElement(this.networkRail_lbl, 'left', 5);
    //     networkList = await this.getListOfShows(this.networkTile_lbl);
    //   }
    //   await commons.waitUntil(this.listOfNetworks[network]);
    //   await commons.click(this.listOfNetworks[network]);
    //   await this.validateNetworkLandingPage(network);
    // }
  };
}

module.exports = NetworkLandingPage;
