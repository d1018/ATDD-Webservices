const assert = require('assert');
const { mobileActions, BasePage } = require('./basePage');

// const PreLaunchPage = require('./preLaunchPage');
// const HomePage = require('./homePage');
const { desiredIosCapabilities } = require('../capabilities/bsCaps');

const commons = mobileActions;
// const preLaunchPage = new PreLaunchPage();
// const homePage = new HomePage();

const serverURL = process.env.SERVER_URL
  ? process.env.SERVER_URL.toLowerCase()
  : '';

const localExecution = process.env.LOCAL_EXECUTION === 'true' || false;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  login_textbox = this.#getSelectorData('login_textbox');

  password_textbox = this.#getSelectorData('password_textbox');

  continue_button = this.#getSelectorData('signIn_button');

  signIn_button = this.getElementByPage('welcomePage', 'signIn_button');

  #isUserSignedIn = false;

  signIn_button_temp = this.getElementByPage(
    'welcomePage',
    'signIn_button_temp',
  );

  async openApp() {
    commons.driverInit(serverURL, localExecution);
    await commons.openApp(desiredIosCapabilities);
    // await preLaunchPage.acceptAllPopUp();
  }

  isSignedOut = async (time = 10) => {
    const result = await commons.elementExists(this.signIn_button, time);

    return result;
  };

  signOutHelper = async () => {
    // Clicking on default profile to bypass "Who's Watching" page on iPad
    if (
      (await commons.elementExists(this.whoIsWatching_lbl, 10)) &&
      (await commons.elementExists(this.defaultProfile, 10))
    ) {
      await commons.click(this.defaultProfile);
    }

    // OK button for 'How to cast to your TV' dialogue
    if (await commons.elementExists(this.ok_caps_btn)) {
      await commons.click(this.ok_caps_btn);
    }
  };

  enterCredentials = async (credentialType) => {
    const username = process.env[`${credentialType}_USERNAME`];
    const password = process.env[`${credentialType}_PASSWORD`];

    if (credentialType.includes('LAPSED')) {
      return;
    }
    await commons.waitUntil(this.signIn_button_temp);
    await commons.click(this.signIn_button_temp);
    await commons.click(this.login_textbox);
    await commons.sendText(this.login_textbox, username);
    await commons.click(this.password_textbox);
    await commons.sendText(this.password_textbox, password);
    await commons.click(this.continue_button);
  };

  loginToApplication = async (credentialType) => {
    // const signedOutValue = await this.isSignedOut();
    //
    // if (!signedOutValue) {
    //   await this.signOutHelper();
    //   await homePage.signOut();
    // }

    // Clicking on default profile to bypass the "Who's Watching" page for iPad
    // if (
    //   (await commons.elementExists(this.whoIsWatching_lbl, 10)) &&
    //   (await commons.elementExists(this.defaultProfile, 10))
    // ) {
    //   await commons.click(this.defaultProfile);
    // }
    await this.navigateToPage('Signin');
    await this.enterCredentials(credentialType);
    this.#isUserSignedIn = true;
  };

  /**
   * For IAP related scenarios,playstore credentials are needed to see the Plan picker screen.
   * This method will close the existing session and relaunch the app by passing the playstore creds through cababilities.
   */
  async reOpenApp() {
    // desiredAndroidCapabilities['browserstack.appStoreConfiguration'] = {
    //   username: process.env.PLAYSTORE_ACCOUNT_EMAIL,
    //   password: process.env.PLAYSTORE_ACCOUNT_PASSWORD,
    // };
    // const capability = {
    //   ios: desiredAndroidCapabilities,
    // }.ios;
    //
    // await commons.closeApp();
    // await commons.openApp(capability);
  }

  verifySignOut = async () => {
    assert.equal(
      await this.isSignedOut(20),
      true,
      'Application is still in signed in state!',
    );
  };
}

module.exports = SignInPage;
