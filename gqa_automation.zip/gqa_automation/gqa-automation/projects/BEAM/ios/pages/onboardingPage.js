// const assert = require('assert');
const { BasePage } = require('./basePage');
// const SignInPage = require('./signInPage');

// const commons = mobileActions;
// const signPage = new SignInPage();

class OnboardingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('onboardingPage', locator);
  }

  // signIn_button = this.getElementByPage('welcomePage', 'signIn_button');

  // subscribeNow_button = this.#getSelectorData('subscribeNow_button');

  // CTASignUpList = [
  //     this.getElementByPage('welcomePage', 'subscribe_button'),
  // ];

  /**
   * The below function will relaunch the app with playstore creds and wait for the welcome screen.
   * Navigates to plan picker screen by selecting subscribe now button.
   */
  navigateToPlanPickerPage = async () => {
    // await signPage.reOpenApp();
    // await commons.click(this.signIn_button);
    // await commons.waitUntil(this.CTASignUpList[0]);
    // await commons.click(this.subscribeNow_button);
  };

  /**
   * The below function will select any plan for subscription
   */
  selectAnyPlan = async () => {};

  /**
   * The below function will validate create account label is available or not.
   * If it is available then it will create a new account for subscription.
   */
  createAccount = async () => {};

  /**
   * The below function will select the subscribe button after creating account.
   */
  selectSubscribeCta = async () => {};

  selectPaymentType = async () => {};

  submitPaymentDetails = async () => {};

  verifyPostPurchaseConfirmationScreen = async () => {};

  clickOnLetsGoCta = async () => {};
}

module.exports = OnboardingPage;
