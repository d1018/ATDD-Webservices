const { BasePage } = require('./basePage');

class VideoPlayerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('videoPlaybackSettings', locator);
  }

  verifyPlayStatus = async () => {};

  navigateAndPlay = async () => {};

  scrubVideo = async () => {
    // await commons.waitUntil(this.playerMediaControl, 50);
    // videoShowTitle = await commons.fetchAttributeData(
    //   this.videoTitle_txt,
    //   'label',
    // );
    // await commons.click(this.videoContainerView, 50);
    // await commons.click(this.videoContainerView, 50);
    // await this.scrubVideoByPercentage(scrubPercentage);
    // if (scrubPercentage < '98') {
    //   playerPositionAfterScrub = await this.videoPlayerPosition();
    //   if (!(await commons.elementExists(this.close_btn))) {
    //     await commons.click(this.videoContainerView, 50);
    //     await commons.waitUntil(this.skipForward_btn);
    //   }
    //   await commons.click(this.close_btn);
    //   await commons.click(this.back_btn);
    // }
  };

  resumeAndPlayVideo = async () => {};

  verifyAdPods = async () => {};

  verifyAdPlayBack = async () => {};

  verifyCC = async () => {};

  verifyProgressBar = async () => {};

  verifyAdStreamElements = async () => {};

  setAutoPlayMode = async () => {};

  selectEpisode = async () => {};

  validateResumePoint = async () => {
    // const resumedVideoShowTitle = await commons.fetchAttributeData(
    //   this.videoTitle_txt,
    //   'label',
    // );
    // assert.equal(
    //   resumedVideoShowTitle,
    //   videoShowTitle,
    //   `Resumed video show ${resumedVideoShowTitle} is not equal to ${videoShowTitle}  `,
    // );
    // const playerPositionOnResume = await this.videoPlayerPosition();
    // const playerPositionStatus =
    //   playerPositionOnResume >= playerPositionAfterScrub;
    // assert(
    //   playerPositionStatus,
    //   true,
    //   `Resume video is not successful as the player position on resume is ${playerPositionOnResume} is less than after scrub ${playerPositionAfterScrub}`,
    // );
    // await this.closeShowPlayer();
  };

  switchToOrientation = async () => {};

  verifyVideoOrientation = async () => {};
}

module.exports = VideoPlayerPage;
