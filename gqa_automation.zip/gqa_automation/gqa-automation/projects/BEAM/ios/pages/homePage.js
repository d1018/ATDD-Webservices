// const assert = require('assert');
const { mobileActions, BasePage } = require('./basePage');
const ProfilePage = require('./profilePage');

const commons = mobileActions;

const profilePage = new ProfilePage();

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  signOut_label = this.getElementByPage('myProfileSettings', 'signOut_label');

  signOut_popup = this.getElementByPage('signOut', 'signOut_label');

  signOut_button = this.getElementByPage('signOut', 'signOut_button');

  signOut = async () => {
    await this.navigateToPage('Account');
    await commons.scrollOnPage('down');

    if (!(await commons.elementExists(this.signOut_label))) {
      await profilePage.selectProfile('Default');
      await commons.waitUntil(this.focusedHomePage, 30);
      await this.navigateToPage('Account');
      if (!(await commons.elementExists(this.signOut_label))) {
        await commons.scrollOnPage('down');
      }
      await commons.waitUntil(this.signOut_label, 30);
    }
    await commons.click(this.signOut_label);
    if (await commons.elementExists(this.signOut_popup, 10)) {
      await commons.click(this.signOut_button);
    }
  };

  verifyKidsContent = async () => {};

  verifyMyListRailOnHomePage = async () => {};

  validateNetworkRail = async () => {
    // await commons.waitUntil(this.networkTile_lbl);
    // await commons.waitUntil(this.network_img);
  };

  scrollToRail = async () => {
    // const actualFlag = await this.isRailPresent(
    //   this.railNames[railName],
    //   '40%',
    // );
    // assert.strictEqual(
    //   actualFlag,
    //   isPresent,
    //   new TypeError(
    //     `Validation Failed! , Actual: ${railName} rail is not present`,
    //   ),
    // );
  };

  verifyAgeRatingAndContentDescriptors = async () => {
    // switch (screensType) {
    //   case 'Main Hero':
    //     break;
    //   case 'Show Details Page':
    //     await menuPage.navigateToPage('Search');
    //     await searchPage.searchText('multiContentShow');
    //     await searchPage.selectFirstResult();
    //     break;
    //   case 'Currently Playing Episode':
    //     await commons.click(this.ctaButtons);
    //     break;
    //   case 'Next Episodes listed on Episode Landing Page':
    //     assert(
    //       await commons.elementExists(this.nextEpisodeRating),
    //       `Rating for the Next Episode is not displayed`,
    //     );
    //     commons.clickBack();
    //     break;
    //   case 'Episode Info Panel':
    //     await commons.click(this.ctaButtons);
    //     break;
    //   default:
    //     throw new Error(
    //       'Actual screenType provided is not as per the expectations',
    //     );
    // }
    // if (screensType !== 'Next Episodes listed on Episode Landing Page') {
    //   assert(
    //     await commons.elementExists(this.rating),
    //     `Rating for the show is not displayed`,
    //   );
    //   const ratingLabel = await commons.fetchAttributeData(
    //     this.rating,
    //     'label',
    //     10,
    //   );
    //   // Remove "Rated " from ratingLabel
    //   const currentRating = ratingLabel.split(' ')[1];
    //   const ratingList = testdataHelper.getContent('ratingList');
    //   assert(
    //     ratingList.includes(currentRating),
    //     `Rating is not as per rating standards`,
    //   );
    // }
  };
}

module.exports = HomePage;
