// const assert = require('assert');

const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  navigateToAccountMenu = async () => {
    await this.navigateToPage('Account');
    // TO DO
    // await this.navigateToPage('Account Menu');
  };

  verifySubnavigationItems = async () => {};

  accessGlobalNavigationMenu = async () => {
    await commons.waitUntil(this.focusedHomePage, 35);
  };

  verifyMenuList = async () => {
    await commons.waitUntil(this.home_button, 20);

    if (this.returnGeoLocation() === 'emea') {
      await commons.waitUntil(this.searchMenu_lbl, 5);
      await commons.waitUntil(this.sportsMenu_lbl, 5);
      if (!this.isKidsProfileSelected()) {
        await commons.waitUntil(this.tvGuideMenu_lbl, 5);
      }
    } else if (this.returnGeoLocation() === 'america') {
      await commons.waitUntil(this.myStuff_button, 5);
      await commons.waitUntil(this.download_button, 5);
      await commons.waitUntil(this.search_button, 5);
    }

    // await commons.click(this.profileButton);
    //
    // if (!(await this.getUserAnonymous())) {
    //   await commons.waitUntil(this.manageProfiles_btn, 25);
    //   if (!(this.returnGeoLocation() === 'america'))
    //     await commons.waitUntil(this.myList_btn, 5);
    // }
  };

  verifyGlobalNavigation = async () => {
    await this.navigateToPage('Home');
    await this.navigateToPage('Search');

    if (this.returnGeoLocation() === 'emea') {
      await this.navigateToPage('Sports');

      if (!this.isKidsProfileSelected()) {
        await this.navigateToPage('Tv Guide');
      }
    } else if (this.returnGeoLocation() === 'america') {
      await this.navigateToPage('My Stuff');
      await this.navigateToPage('Downloads');
    }
  };

  navigateToSubnavigationAndVerify = async () => {
    // const accountMenuList = this.getUserAccountMenuItems(profileName);
    // for (let i = 0; i < accountMenuList.length; i++) {
    //   if (
    //     this.returnGeoLocation() === 'america' &&
    //     accountMenuList[i] !== 'My List'
    //   ) {
    //     await commons.waitUntil(
    //       this.accountPageSubMenu[accountMenuList[i]],
    //       30,
    //     );
    //     await retry(
    //       async () => {
    //         await commons.click(this.accountPageSubMenu[accountMenuList[i]]);
    //         await commons.waitUntil(
    //           this.accountSubNavigationPageFocused[accountMenuList[i]],
    //           10,
    //         );
    //       },
    //       { retries: 3, minTimeout: 3000, maxTimeout: 5000 },
    //     );
    //     if (accountMenuList[i] === 'Sign Out') {
    //       await commons.click(await this.focusedCancelPopUp);
    //     } else {
    //       await commons.waitUntil(this.back_btn, 10);
    //       await commons.click(this.back_btn);
    //       try {
    //         await retry(
    //           async () => {
    //             await commons.waitUntil(this.manageProfiles_btn, 10);
    //           },
    //           { retries: 3, minTimeout: 3000, maxTimeout: 5000 },
    //         );
    //       } catch (error) {
    //         await commons.clickBack();
    //         await menuPage.navigateToPage('Home');
    //         await menuPage.navigateToPage('Account');
    //       }
    //     }
    //   }
    //   await commons.waitUntil(this.accountPageSubMenu.About, 10);
    // }
  };
}

module.exports = MenuPage;
