const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');
const { testdataHelper } = require('./basePage');

const commons = mobileActions;

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  search_button = this.getElementByPage(
    'myListWithoutUserData',
    'search_button',
  );

  search_txtBx = this.getElementByPage(
    'searchPageWarmStart',
    'searchBar_field',
  );

  searchBar_field = this.getElementByPage(
    'searchPageWarmStart',
    'searchBar_field',
  );

  searchResult_tile = this.getElementByPage(
    'searchResultsPage',
    'searchResult_tile',
  );

  searchResult_title = this.getElementByPage(
    'searchResultsPage',
    'searchResult_title',
  );

  focusedSearchPage = this.getElementByPage(
    'searchPageWarmStart',
    'searchBar_field',
  );

  recommendation_label = this.getElementByPage(
    'searchPageWarmStart',
    'recommendation_label',
  );

  searchShow = async (showName) => {
    await commons.sendText(this.searchBar_field, showName, 20);
  };

  selectShow = async () => {
    const searchThumbnailsList = await commons.findElements(
      this.searchResult_tile,
    );

    await commons.click(searchThumbnailsList[1]);
  };

  verifySearchPage = async () => {
    await commons.elementExists(this.search_txtBx, 15);
    await commons.click(this.search_button);
    await commons.elementExists(this.search_txtBx, 30);
    await this.assertPage('Search');
  };

  enterSearchQuery = async (contentType) => {
    await commons.waitUntil(this.search_txtBx, 10);
    const searchText = testdataHelper.getContent(`searchPage.${contentType}`);

    await commons.sendText(this.search_txtBx, searchText);
  };

  verifySearchQuery = async (contentType) => {
    const searchActVal = await commons.fetchAttributeData(
      await this.search_txtBx,
      'value',
    );

    const searchExpVal = testdataHelper.getContent(`searchPage.${contentType}`);

    assert.equal(
      searchActVal,
      searchExpVal,
      `Search parameter does not include '${this.searchExpVal}'. Actual: ${searchActVal}`,
    );
  };

  verifyIfSearchResultsLoaded = async () => {
    await commons.waitUntil(this.searchResult_tile, 30);
    await commons.waitUntil(this.searchResult_title, 30);
  };

  verifySearchResult = async (contentType) => {
    const recommendedForYouRail = await commons.elementExists(
      this.recommendation_label,
      10,
    );

    assert.strictEqual(
      recommendedForYouRail,
      false,
      'Recommended for You rail is still visible!',
    );

    this.verifyIfSearchResultsLoaded();

    const titleActValue = await commons.fetchAttributeData(
      await this.searchResult_title,
      'label',
    );
    const titleExpVal = testdataHelper.getContent(`searchPage.${contentType}`);

    assert.equal(
      titleActValue.trim(),
      titleExpVal,
      `Search result does not include '${titleExpVal}'. Actual: ${titleActValue}`,
    );
  };
}

module.exports = SearchPage;
