const AndroidSignInPage = require('../../android/pages/signInPage');

const { mobileActions } = require('./basePage');

const commons = mobileActions;
const serverURL = process.env.SERVER_URL
  ? process.env.SERVER_URL.toLowerCase()
  : '';
const localExecution = process.env.LOCAL_EXECUTION === 'true' || false;

const { desiredFireTabCapabilities } = require('../capabilities/headspinCaps');

// Example if you want to extend or modify a page for firetab
class SignInPage extends AndroidSignInPage {
  profileName_label = this.getElementByPage('profilePage', 'profileName_label');

  focusedHomePage_label = this.getElementByPage(
    'homePage',
    'focusedHomePage_label',
  );

  openApp = async () => {
    commons.driverInit(serverURL, localExecution);
    await commons.openApp(desiredFireTabCapabilities);
    await commons.waitUntil(this.signIn_button);
  };

  async enterCredentials(credentialType) {
    await AndroidSignInPage.prototype.enterCredentials.call(
      this,
      credentialType,
    );

    let profileName;

    if (credentialType !== 'authenticated-multi-profile') {
      profileName = 'Default';
    }

    if (profileName) {
      const profile = this.getCustomLocator(
        this.profileName_label,
        profileName,
      );

      if (await commons.elementExists(profile, 30))
        await commons.click(profile);
    }

    if (credentialType !== 'lapsed') {
      await commons.waitUntil(this.focusedHomePage_label, 75);
    }
  }
}

module.exports = new SignInPage();
