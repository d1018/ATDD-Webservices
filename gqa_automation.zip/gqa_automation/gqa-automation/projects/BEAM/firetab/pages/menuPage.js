const { BasePage } = require('./basePage');

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }
}

module.exports = MenuPage;
