const signInPage = require('./signInPage');
const MenuPage = require('../../android/pages/menuPage');
const ProfilePage = require('../../android/pages/profilePage');
const HomePage = require('../../android/pages/homePage');
const AccountPage = require('../../android/pages/accountPage');
const MemberFeedPage = require('../../android/pages/memberFeedPage');
const MyStuffPage = require('../../android/pages/myStuffPage');
const NetworkLandingPage = require('../../android/pages/networkLandingPage');
const OnboardingPage = require('../../android/pages/onboardingPage');
const SearchPage = require('../../android/pages/searchPage');
const VideoPlayerPage = require('../../android/pages/videoPlayerPage');

const menuPage = new MenuPage();
const profilePage = new ProfilePage();
const homePage = new HomePage();
const accountPage = new AccountPage();
const memberFeedPage = new MemberFeedPage();
const myStuffPage = new MyStuffPage();
const networkLandingPage = new NetworkLandingPage();
const onboardingPage = new OnboardingPage();
const searchPage = new SearchPage();
const videoPlayerPage = new VideoPlayerPage();

module.exports = {
  signInPage,
  menuPage,
  profilePage,
  homePage,
  accountPage,
  memberFeedPage,
  myStuffPage,
  networkLandingPage,
  onboardingPage,
  searchPage,
  videoPlayerPage,
};
