const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I have selected {string} user profile', async (profileType) => {
  await pageClass.profilePage.selectProfile(profileType);
});

Then(
  'I see the Member Feed icon show a new notifications indicator',
  async () => {
    await pageClass.memberFeedPage.verifyNotificationBadge();
  },
);

Then('I am in the edit mode of the Notifications screen', async () => {
  await pageClass.memberFeedPage.editNotifications();
});

Then(
  'I open kebab icon to select {string} on a specific notification',
  async (kebabActionType) => {
    await pageClass.memberFeedPage.openKebabMenuAndSelectCTA(kebabActionType);
  },
);

Then(
  'I see the content details page of the asset listed on the notification',
  async () => {
    await pageClass.memberFeedPage.verifyAssetContentDetails();
  },
);

Then(
  'I have viewed notifications for the {string} profile',
  async (profileType) => {
    await pageClass.memberFeedPage.viewNotifications(profileType);
  },
);

Then('I switch to {string} user profile', async (profileType) => {
  await pageClass.profilePage.selectProfile(profileType);
});

Then(
  'I do not see notifications from the previously selected adult profile',
  async () => {
    await pageClass.memberFeedPage.verifyNotificationsBetweenMultiProfiles();
  },
);
