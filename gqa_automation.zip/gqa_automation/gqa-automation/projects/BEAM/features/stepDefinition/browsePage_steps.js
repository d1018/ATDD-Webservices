const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

Then('I validate the browse page with networks', async () => {
  await pageClass.browsePage.verifyBrowsePage();
});

When('I select {string} network on browser page', async (networkType) => {
  await pageClass.browsePage.selectNetwork(networkType);
  await pageClass.browsePage.verifyShowOnSelectedNetwork();
});

When('I tap on {string} sub-nav option', async (subNavName) => {
  await pageClass.browsePage.selectSubNav(subNavName);
});

Then(
  'I verify the show cards on selecting {string} sub-nav on browse page',
  async (subNav) => {
    await pageClass.browsePage.selectSubNav(subNav);
    await pageClass.browsePage.verifyShowCard();
  },
);
