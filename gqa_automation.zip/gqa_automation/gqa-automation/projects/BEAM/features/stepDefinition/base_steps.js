/* eslint-disable global-require */
let pageObject;

const project = process.env.PROJECT;
const device = process.env.DEVICE;

if (project + device === 'BEAMweb') {
  pageObject = require('../../web/pages');
} else if (project + device === 'BEAMandroid') {
  pageObject = require('../../android/pages');
} else if (project + device === 'BEAMios') {
  pageObject = require('../../ios/pages');
} else if (project + device === 'BEAMxbox') {
  pageObject = require('../../xbox/pages');
} else if (project + device === 'BEAMlg') {
  pageObject = require('../../lg/pages');
} else if (project + device === 'BEAMsamsung') {
  pageObject = require('../../samsung/pages');
} else if (project + device === 'BEAMvizio') {
  pageObject = require('../../vizio/pages');
} else if (project + device === 'BEAMroku') {
  pageObject = require('../../roku/pages');
} else if (project + device === 'BEAMappletv') {
  pageObject = require('../../appletv/pages');
} else if (project + device === 'BEAMfiretab') {
  pageObject = require('../../firetab/pages');
}
// } else if (project + device === 'DTCandroidtv') {
//   pageObject = require('../../androidtv/pages');
// } else if (project + device === 'DTCfiretv') {
//   pageObject = require('../../firetv/pages');
// }
else {
  throw new Error(`unsupported project and device type: ${project + device}`);
}

const pageClass = pageObject;

module.exports = {
  pageClass,
};
