const { Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

Then(
  'I should see filtered content on all relevant screens',
  async (screens) => {
    const screenType = screens.raw();

    for (let i = 0; i < screenType.length; i++) {
      await pageClass.homePage.verifyKidsContent(screenType[i].toString());
    }
  },
);

Then(
  'I verify the Age Ratings and Content Descriptors on different screens',
  async (pages) => {
    const pageName = pages.raw();

    for (let i = 0; i < pageName.length; i++) {
      await pageClass.homePage.verifyAgeRatingAndContentDescriptors(
        pageName[i].toString(),
      );
    }
  },
);

Then(
  'I will have a Recommended For You Rail for {string}',
  async (assetType) => {
    await pageClass.homePage.verifyRecommendedForYou(assetType);
  },
);
