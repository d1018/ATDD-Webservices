const { Given, When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

Given('I have at least one asset added to My List', async () => {
  await pageClass.myStuffPage.verifyMyListAsset();
});

Given('I navigate to My Stuff > My List tab', async () => {
  await pageClass.myStuffPage.navigateToMyListTab();
});

When('I invoke the Info modal of an asset on My List tab', async () => {
  await pageClass.myStuffPage.invokeAsset();
});

Then('I observe the Info modal', async () => {
  await pageClass.myStuffPage.verifyInfoModal();
});

Then('I see expected infoModalElements', async (modalElements) => {
  const infoModalElements = modalElements.raw();

  await pageClass.myStuffPage.verifyInfoModalElement(infoModalElements);
});

Given('I have assets added to My List', async () => {
  await pageClass.myStuffPage.verifyMyListAsset();
});

When(
  'I remove the My List content from My List tab via the show cards',
  async () => {
    await pageClass.myStuffPage.removeMyListContent();
  },
);

Then(
  'I see that particular show is removed from My Stuff > My List tab',
  async () => {
    await pageClass.myStuffPage.verifyMyListTabContentRemoved();
  },
);

Then('I see that particular show is removed from My List rail', async () => {
  await pageClass.homePage.verifyMyListRailContentRemoved(true);
});
