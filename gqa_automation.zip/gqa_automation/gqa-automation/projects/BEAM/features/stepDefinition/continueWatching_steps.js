const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I watch a {string} for more than 15 seconds', async (showType) => {
  await pageClass.videoPlayerPage.navigateAndPlay(showType);
  await pageClass.videoPlayerPage.scrubVideo('20');
});

Then('I resume the same content from Continue Watching rail', async () => {
  await pageClass.videoPlayerPage.resumeAndPlayVideo();
});

Then('It should resume from same the point it left previously', async () => {
  await pageClass.videoPlayerPage.validateResumePoint();
});
