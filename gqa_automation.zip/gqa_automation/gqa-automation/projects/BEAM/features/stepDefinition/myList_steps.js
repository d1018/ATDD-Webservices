const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I select My Stuff from Global navigation', async () => {
  await pageClass.menuPage.navigateToPage('myStuff');
});

When('I select My List tab', async () => {
  await pageClass.myStuffPage.selectMyList();
});

When('I observe the text No Saved titles', async () => {
  await pageClass.myStuffPage.verifyMyListContent();
});

When('I Add to My List from any asset details page', async () => {
  await pageClass.myStuffPage.addShowsToMylist();
});

Then(
  'I should see show is added to my list and My list rail in home page',
  async () => {
    await pageClass.myStuffPage.verifyMyListData(true);
    await pageClass.homePage.verifyMyListRailOnHomePage(true);
  },
);
When('I focus on any Show tile on Homepage', async () => {
  await pageClass.myStuffPage.navigateToShowTileInHomePage();
});

Then('I add a show by performing CTA', async () => {
  await pageClass.myStuffPage.addShowToMylistFromHomePage();
});

When('I click on Remove CTA button on Edit mode', async () => {
  await pageClass.myStuffPage.selectRemoveButtonOnEditMode();
});

Then(
  'I Should see the show is removed from my list and a confirm message',
  async () => {
    await pageClass.myStuffPage.verifyMyListShowRemoved();
  },
);

Then(
  'I Should see the show is added to my list and a confirm message',
  async () => {
    await pageClass.myStuffPage.verifyMyListShowAdded();
  },
);
