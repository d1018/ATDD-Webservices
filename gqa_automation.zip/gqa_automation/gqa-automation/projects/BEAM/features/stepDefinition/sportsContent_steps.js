const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I select the {string} content on Sports Page', async (contentType) => {
  await pageClass.sportsContentPage.selectContent(contentType);
});

Then('I verify {string} content details', async (contentType) => {
  await pageClass.sportsContentPage.verifyContentDetails(contentType);
});

Then(
  'I see immersive hero component with a {string} video content',
  async (contentType) => {
    await pageClass.sportsContentPage.verifyVideoContent(contentType);
  },
);

Then(
  'I verify the metadata of {string} content on immersive hero',
  async (contentType) => {
    await pageClass.sportsContentPage.verifySportsMetaData(contentType);
  },
);

Then('I verify the metadata of {string}', async (contentType) => {
  await pageClass.sportsContentPage.verifySportsMetaData(contentType);
});

When('I scroll down to {string} component', async (inlinehero) => {
  await pageClass.sportsContentPage.scrollToInlineHero(inlinehero);
});

When('I see the Upcoming Live event', async () => {
  await pageClass.sportsContentPage.verifyUpcomingLiveEvent();
});

Then(
  'I verify inline hero component metadata on {string} page',
  async (pageName) => {
    await pageClass.sportsContentPage.verifyInlineHeroMetaData(pageName);
  },
);

When('I click on {string} CTA', async (CTAtype) => {
  await pageClass.basePage.selectCTA(CTAtype);
});

Then('I should see Sports themed rail collections', async () => {
  await pageClass.sportsContentPage.verifySportsThemeRail();
});
