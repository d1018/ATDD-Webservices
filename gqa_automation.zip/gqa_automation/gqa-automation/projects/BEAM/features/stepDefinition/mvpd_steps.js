const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When(
  'I navigate to the connect with provider option from sign in page',
  async () => {
    await pageClass.mvpdPage.navigateToConnectWithProvider();
  },
);

When('I validate the data at the connect with provider page', async () => {
  await pageClass.mvpdPage.verifyContentAtProviderPage();
});

Then('I see cant sign in screen with following data', async (rawData) => {
  await pageClass.mvpdPage.verifyMVPDScreen(rawData);
});

When('I should see TV provider info after download', async () => {
  await pageClass.mvpdPage.verifyTVProviderInfo();
});

When('I should choose TV provider', async () => {
  await pageClass.mvpdPage.selectTVProvider();
});

When('I should create a Password', async () => {
  await pageClass.mvpdPage.createPassworda();
});

When('I can see Renew Subscription paywall with {string}', async (ctaType) => {
  await pageClass.mvpdPage.renewSubription(ctaType);
});

When('I select “Subscribe”', async () => {
  await pageClass.mvpdPage.selectSubscribe();
});

Then('I will land on DTC flow', async () => {
  await pageClass.mvpdPage.verifyDTCflow();
});

Then('I should see MVPD sign in flow', async () => {
  await pageClass.mvpdPage.verifyMVPDSignInFlow();
});
