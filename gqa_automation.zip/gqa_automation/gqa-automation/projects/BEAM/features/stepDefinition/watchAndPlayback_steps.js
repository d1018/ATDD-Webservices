const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I select the content of {string}', async (showType) => {
  await pageClass.menuPage.navigateToPage('Search');
  await pageClass.searchPage.searchShow(showType);
  await pageClass.searchPage.selectShow();
});

Then('I am able to perform actions', async (actions) => {
  const actionType = actions.raw();

  for (let i = 0; i < actionType.length; i++) {
    await pageClass.videoPlayerPage.verifyVideoActions(
      actionType[i].toString(),
    );
  }
});

Then('I see the playback is initiated', async () => {
  await pageClass.videoPlayerPage.playShow();
  await pageClass.videoPlayerPage.isVideoPlaying();
});

Then('I am playing an {string} video', async (showType) => {
  await pageClass.videoPlayerPage.navigateAndPlay(showType);
});

Then(
  'I switch the player screen to {string} orientation',
  async (orientation) => {
    await pageClass.videoPlayerPage.switchToOrientation(orientation);
  },
);

Then('I see the playback continue in {string} orientation', async (mode) => {
  await pageClass.videoPlayerPage.verifyVideoOrientation(mode);
});

Then(
  'I see player screen expand to {string} and continue playback',
  async (mode) => {
    await pageClass.videoPlayerPage.verifyVideoOrientation(mode);
  },
);
When('I set Autoplay Episodes option to {string}', async (autoplaySetting) => {
  await pageClass.videoPlayerPage.setAutoPlayMode(autoplaySetting);
});

Then('I finish watching the episode', async () => {
  await pageClass.videoPlayerPage.scrubVideo('100');
});

Then(
  'I verify play status of the next episode as {string}',
  async (playStatus) => {
    await pageClass.videoPlayerPage.verifyPlayStatus(playStatus);
  },
);

Then('I see Ad streaming with following elements', async (elements) => {
  const actionType = elements.raw();

  for (let i = 0; i < actionType.length; i++) {
    await pageClass.videoPlayerPage.verifyAdStreamElements(
      actionType[i].toString(),
    );
  }
});

Then('I should not see any Progress bar and other player control', async () => {
  await pageClass.videoPlayerPage.verifyProgressBar();
});

When('I play a show with {string}', async (showType) => {
  await pageClass.videoPlayerPage.navigateAndPlay(showType);
});

When('I observe Ad Pods on the Progress bar', async () => {
  await pageClass.videoPlayerPage.verifyAdPods();
});

Then('I verify Ad playback and expected Ad counter experience', async () => {
  await pageClass.videoPlayerPage.verifyAdPlayBack();
});

Then('I do not see CC', async () => {
  await pageClass.videoPlayerPage.verifyCC();
});

When(
  'I set autoplay Episodes option sets to {string}',
  async (AutoplaySetting) => {
    await pageClass.videoPlayerPage.setAutoplaySetting(AutoplaySetting);
  },
);

When(
  'I select an episode of a show that have more unwatched episodes',
  async () => {
    await pageClass.videoPlayerPage.selectEpisode();
  },
);
