const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I enter a {string} in the search field', async (contentType) => {
  await pageClass.searchPage.enterSearchQuery(contentType);
});

Then(
  'I see the search prompt replaced with the {string}',
  async (contentType) => {
    await pageClass.searchPage.verifySearchQuery(contentType);
  },
);
Then(
  'I see the recommended content replaced with {string} search results',
  async (contentType) => {
    await pageClass.searchPage.verifySearchResult(contentType);
  },
);
