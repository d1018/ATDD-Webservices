const { Given, When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

const credentials = {
  'authenticated-multi-profile': 'multi-profile',
  lapsed: 'lapsed',
  'authenticated-single-profile': 'single-profile',
  anonymous: 'anonymous',
  'authenticated-new-profile': 'new-profile',
  'authenticated-ad-lite': 'multi-profile',
  'authenticated-ad-free': 'multi-profile',
};

Given('I launch BEAM app', async () => {
  await pageClass.signInPage.openApp();
});

Given('I access the application as {string} user', async (attribute) => {
  await pageClass.signInPage.loginToApplication(credentials[attribute]);
});

When('I navigate to SIGN IN and select Reset Password', async () => {
  await pageClass.menuPage.navigateToPage('Signin');
  await pageClass.signInPage.selectResetPassword();
});

When('I land on Reset Password screen', async () => {
  await pageClass.signInPage.verifyResetPasswordScreen();
});

When('I submit valid email', async () => {
  await pageClass.signInPage.submitValidEmail();
});

Then('An email to reset password will be sent', async () => {
  await pageClass.onboardingPage.interceptPasswordEmail();
});

Then('I reset the password and SIGN IN with new password', async () => {
  await pageClass.signInPage.resetPassword();
  await pageClass.signInPage.signInWithNewPassword();
});

Then('SIGN IN should be successful', async () => {
  await pageClass.signInPage.verifySuccessfulLogin();
});
