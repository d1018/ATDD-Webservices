const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

Then('I validate data is cleaned up by deleting profile', async () => {
  await pageClass.profilePage.deleteExistingProfile();
});

When(
  'I create and move to edit page for {string} user profile',
  async (profileType) => {
    await pageClass.profilePage.createNewProfileAndMoveToEdit(profileType);
  },
);

When('I change the profile name and save edit page', async () => {
  await pageClass.profilePage.editUserProfile();
});

Then(
  "I should see the changes and navigated to Who's Watching screen",
  async () => {
    await pageClass.profilePage.verifyEditedProfile();
  },
);

When('I create and select {string} user profile', async (profileType) => {
  await pageClass.profilePage.profileCreation(profileType);
});

When('I select {string} profile', async (profileName) => {
  await pageClass.profilePage.selectProfile(profileName);
});

Then('I should land on profile picker screen', async () => {
  await pageClass.profilePage.verifyProfileScreen();
});

Then('I verify the user profile should be deleted', async () => {
  await pageClass.profilePage.verifyUserProfileDeleted();
});

Then('I do not see the Add Profile button', async () => {
  await pageClass.profilePage.verifyAddProfileButton();
});
