const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I navigate to {string} Page', async (menuValue) => {
  await pageClass.menuPage.navigateToPage(menuValue);
});

Then('I verify user landed on {string} page', async (pageValue) => {
  await pageClass.menuPage.assertPage(pageValue);
});

When('I access the Global Navigation menu', async () => {
  await pageClass.menuPage.accessGlobalNavigationMenu();
});

Then(
  'I should be able to see the Menu items listed on the Global Navigation',
  async () => {
    await pageClass.menuPage.verifyMenuList();
  },
);

Then('I should navigate to global navigation pages', async () => {
  await pageClass.menuPage.verifyGlobalNavigation();
});

Then('I navigate to account menu', async () => {
  await pageClass.menuPage.navigateToAccountMenu();
});

Then('I verify sub-navigation items', async () => {
  await pageClass.menuPage.verifySubnavigationItems();
});

Then('I navigate to different sub-navigation items and verify', async () => {
  await pageClass.menuPage.navigateToSubnavigationAndVerify();
});
