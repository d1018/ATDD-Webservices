const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I sign out from the app', async () => {
  await pageClass.homePage.signOut();
});

Then('I should be signed out successfully', async () => {
  await pageClass.signInPage.verifySignOut();
});

When('I navigate to Plan Picker screen', async () => {
  await pageClass.onboardingPage.navigateToPlanPickerPage();
});

Then('I should see a Register CTA to create a free account', async () => {
  await pageClass.onboardingPage.verifyRegisterFreeCta();
});

Then('I select Register CTA', async () => {
  await pageClass.onboardingPage.selectRegisterFreeCta();
});

Then('I create free account', async () => {
  await pageClass.onboardingPage.createFreeAccount();
});

Then('I verify free account created', async () => {
  await pageClass.onboardingPage.verifyAccountCreation();
});

Then('I should see inactive subscription screen', async () => {
  await pageClass.onboardingPage.verifyInactiveSubscriptionScreen();
});

When('I select any plan from plan picker screen', async () => {
  await pageClass.onboardingPage.selectAnyPlan();
});

Then('I create an account in create account page', async () => {
  await pageClass.onboardingPage.createAccount();
});

Then('I select Subscribe CTA on Pre-purchase summary screen', async () => {
  await pageClass.onboardingPage.selectSubscribeCta();
});

Then('I select {string} as mode of payment', async (paymentType) => {
  await pageClass.onboardingPage.selectPaymentType(paymentType);
});

Then(
  'I submit {string} details on payment details page',
  async (paymentType) => {
    await pageClass.onboardingPage.submitPaymentDetails(paymentType);
  },
);

Then('I verify the Post Purchase Confirmation screen', async () => {
  await pageClass.onboardingPage.verifyPostPurchaseConfirmationScreen();
});

Then('I click on the Lets go CTA', async () => {
  await pageClass.onboardingPage.clickOnLetsGoCta();
});

Then('I create a account as a common user', async () => {
  await pageClass.onboardingPage.createAccountWithSubscription();
});
