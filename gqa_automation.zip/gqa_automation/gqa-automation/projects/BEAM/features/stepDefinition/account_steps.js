const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

Then('I validate the Suscription tab', async () => {
  await pageClass.accountPage.verifySubscriptionDetails();
});

When('I navigate to {string} tab', async (accountSubTab) => {
  await pageClass.accountPage.selectAccountSubTab(accountSubTab);
});
