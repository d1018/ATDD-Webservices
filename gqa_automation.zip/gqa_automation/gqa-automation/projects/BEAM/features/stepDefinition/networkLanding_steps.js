const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I navigate to Network rail on Home Page', async () => {
  await pageClass.homePage.scrollToRail('Network');
});

Then('I validate the Network rail', async () => {
  await pageClass.homePage.validateNetworkRail();
});

Then(
  'I select network and validate the items on network landing page',
  async (network) => {
    const networkType = network.raw();

    for (let i = 0; i < networkType.length; i++) {
      await pageClass.networkLandingPage.selectAndValidateNetworkLandingPage(
        networkType[i].toString(),
      );
    }
  },
);
