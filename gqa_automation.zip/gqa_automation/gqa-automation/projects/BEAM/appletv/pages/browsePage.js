const { BasePage } = require('./basePage');

class BrowsePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('browsePage', locator);
  }

  verifyBrowsePage = async () => {
    // const isAllLogoFocused = await commons.fetchAttributeData(
    //     this.#allNetworksLogo,
    //     'focused',
    // );
    //
    // assert(
    //     isAllLogoFocused,
    //     'Browse Page should load with the "All" icon in focus',
    // );
    // await commons.waitUntil(this.#networkLogoRail);
    // await commons.waitUntil(this.#trending_lbl);
  };

  selectNetwork = async () => {
    // const network = testdataHelper.getContent(`networkPage.${networkType}`);
    //
    // this.#currentNetworkType = network;
    // while (
    //     !(await commons.elementExists(
    //         this.getCustomLocator(this.#selectedNetworkLogo_lbl, network),
    //         5,
    //     ))
    //     ) {
    //   await commons.userAction('right');
    // }
  };

  verifyShowOnSelectedNetwork = async () => {
    // const listOfShows = await commons.findElements(
    //     this.#showCardCollection_view,
    // );
    //
    // // Validate the first 6 shows (top row) contain the Network being validated.
    // // The first element is the subnav bar, so we'll start on the second.
    // for (let i = 1; i < 7; i++) {
    //   const showDetails = await commons.fetchAttributeData(
    //       listOfShows[i],
    //       'name',
    //   );
    //
    //   assert(
    //       showDetails.includes(this.#currentNetworkType),
    //       `Show Details page assets should include network name. Network is ${
    //           this.#currentNetworkType
    //       }`,
    //   );
    // }
  };

  selectSubNav = async () => {
    // // Down to sub-navigation
    // await commons.userAction('down');
    //
    // // Scroll to the subNav passed in
    // const topic = testdataHelper.getContent(`networkPage.${subNav}`);
    // const selectedTab = this.getCustomLocator(this.#selectedTab_lbl, topic);
    //
    // while (!(await commons.elementExists(selectedTab))) {
    //   await commons.userAction('right');
    // }
  };

  verifyShowCard = async () => {
    // await commons.waitUntil(this.#showCardTitle);
    // await commons.waitUntil(this.#showCardBackgroundImage);
    // await commons.waitUntil(this.#showCardNetworkIcon);
  };
}

module.exports = BrowsePage;
