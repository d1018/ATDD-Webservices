const assert = require('assert');
const { testdataHelper, mobileActions, BasePage } = require('./basePage');

const commons = mobileActions;

let searchtxt;

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  search_txtBx = this.#getSelectorData('searchBar_field');

  signIn_button = this.getElementByPage('welcomePage', 'signIn_button');

  focusedSearchPage = this.#getSelectorData('search_keyboard');

  firstContentTitle = this.#getSelectorData('searchResult_title');

  verifySearchPage = async () => {
    await this.navigateToPage('Search');
    // await this.assertPage('Search');
    await commons.waitUntil(this.focusedSearchPage, 30);
    await commons.click(this.focusedSearchPage);
  };

  enterSearchQuery = async (contentType) => {
    await commons.waitUntil(this.search_txtBx, 10);

    const searchText = testdataHelper.getContent(`searchPage.${contentType}`);

    searchtxt = searchText;

    await commons.sendText(this.search_txtBx, searchText);
  };

  verifySearchQuery = async (contentType) => {
    const searchActVal = await commons.fetchAttributeData(
      await this.search_txtBx,
      'value',
    );

    const searchExpVal = testdataHelper.getContent(`searchPage.${contentType}`);

    assert.equal(
      searchActVal,
      searchExpVal,
      `Search parameter does not include '${searchExpVal}'. Actual: ${searchActVal}`,
    );
  };

  verifySearchResult = async (contentType) => {
    const showName = await testdataHelper.getContent(
      `searchPage.${contentType}`,
    );
    const titleValue = await commons.fetchAttributeData(
      this.firstContentTitle,
      'label',
    );

    if (titleValue.includes(showName)) return;
    throw new Error(`Search result does not includes '${searchtxt}'`);
  };
}

module.exports = SearchPage;
