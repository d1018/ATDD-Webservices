const { BasePage } = require('./basePage');

// const commons = mobileActions;

class AccountPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('accountPage', locator);
  }
}

module.exports = AccountPage;
