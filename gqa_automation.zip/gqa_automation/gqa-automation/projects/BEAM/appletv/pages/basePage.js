const path = require('path');

const { mobileActions, testdataHelper } = require('@wbd/gqa-core/support');

const ymlpath = path.resolve(__dirname);
const commons = mobileActions;
const EnvBase = require('../../../support/env');

const myListShows = [];
let myListCompareShow = '';

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }

  // Save a show from a Standard profile to compare to a show in a Kids profile
  getMyListCompareShow() {
    return myListCompareShow;
  }

  setMyListCompareShow(show) {
    myListCompareShow = show;
  }

  // Save the shows to verify order in verifyMyListRailShowOrder()
  getMyListShows() {
    return myListShows;
  }

  addToMyListShows(show) {
    myListShows.unshift(show);
  }

  getRandomNumber = (len) => {
    const randomNumber = Math.floor(Math.random() * len);

    return `${randomNumber}`;
  };

  #getSelectorData(locator) {
    return this.getElementByPage('commonUtilities', locator);
  }

  signIn_button = this.getElementByPage('welcomePage', 'signIn_button');

  focusedSignIn_button = this.getElementByPage(
    'welcomePage',
    'focusedSignIn_button',
  );

  focusedHomePage_lbl = this.getElementByPage(
    'homePage',
    'focusedHomePage_lbl',
  );

  searchMenu_lbl = this.getElementByPage('homePage', 'searchMenu_lbl');

  focusedSearchPage = this.getElementByPage('searchPage', 'search_keyboard');

  myStuff_lbl = this.getElementByPage('myListNoUserDataPage', 'myStuff_button');

  focusedMyStuffPage = this.getElementByPage(
    'myListNoUserDataPage',
    'myStuff_title',
  );

  menuItem = {
    Home: this.homeMenu_lbl,
    'My Stuff': this.myStuff_lbl,
    Search: this.searchMenu_lbl,
    Downloads: this.downloadsMenu_lbl,
    Account: this.accountMenu_lbl,
    Signin: this.signIn_button,
  };

  pageFocused = {
    Home: this.focusedHomePage_lbl,
    Search: this.focusedSearchPage,
    'My Stuff': this.focusedMyStuffPage,
    Signin: this.focusedSignIn_button,
  };

  navigateToPage = async (pageValue) => {
    await commons.waitUntil(this.menuItem[pageValue], 80);
    await commons.click(this.menuItem[pageValue], 80);
    await commons.userAction('right');
    await this.assertPage(pageValue);
  };

  assertPage = async (pageValue) => {
    await commons.waitUntil(this.pageFocused[pageValue]);
  };
}
module.exports = {
  mobileActions,
  testdataHelper,
  BasePage,
};
