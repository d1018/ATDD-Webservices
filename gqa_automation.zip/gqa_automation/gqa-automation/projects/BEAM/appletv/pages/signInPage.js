const { desiredAppleTVCapabilities } = require('../capabilities/headspinCaps');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

const serverURL = process.env.SERVER_URL
  ? process.env.SERVER_URL.toLowerCase()
  : '';

const localExecution = process.env.LOCAL_EXECUTION === 'true' || false;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  startStreaming_text = this.getElementByPage(
    'welcomePage',
    'startStreaming_text',
  );

  signIn_button = this.getElementByPage('welcomePage', 'signIn_button');

  useRemote_button = this.getElementByPage(
    'useYourRemoteSignInPage',
    'useRemote_button',
  );

  email_field = this.getElementByPage('useYourRemoteSignInPage', 'email_field');

  signin_text = this.getElementByPage('useYourRemoteSignInPage', 'signin_text');

  password_field = this.getElementByPage(
    'useYourRemoteSignInPage',
    'password_field',
  );

  signin_button = this.getElementByPage(
    'useYourRemoteSignInPage',
    'signin_button',
  );

  forgot_password_button = this.getElementByPage(
    'useYourRemoteSignInPage',
    'forgot_password_button',
  );

  pre_lbl = this.getElementByPage('useYourRemoteSignInPage', 'pre_lbl');

  userName_txtBx = this.getElementByPage(
    'useYourRemoteSignInPage',
    'userName_txtBx',
  );

  password_txtBx = this.getElementByPage(
    'useYourRemoteSignInPage',
    'password_txtBx',
  );

  openApp = async () => {
    commons.driverInit(serverURL, localExecution);
    await commons.openApp(desiredAppleTVCapabilities);
    // Ensure no system overlay is blocking the app
    // if (!(await commons.elementExists(this.discoPlusApp, 5))) {
    //     await commons.userAction('menu');
    // }
    // if (!(await this.isSignedOut())) {
    //     await this.handleSignOut();
    // }
  };

  // isSignedOut = async () => {
  //     const isSignedOut = await commons.elementExists(this.signIn_btn, 5);
  //
  //     return isSignedOut;
  // };
  //
  // handleSignOut = async () => {
  //     if (await commons.elementExists(this.inactiveSub_lbl, 5)) {
  //         await this.signOutHelper();
  //     }
  //
  //     await this.handleAdTracking();
  //
  //     if (!(await this.isSignedOut())) {
  //         await this.signOut();
  //     }
  // };
  //
  // signOutHelper = async () => {
  //     if (
  //         (await commons.elementExists(this.signOut_cta, 5)) ||
  //         (await commons.elementExists(accountPage.signOut_btn))
  //     ) {
  //         await commons.userAction('down');
  //         await commons.userAction('select');
  //     }
  //
  //     if (
  //         (await commons.elementExists(this.signOut_cta, 5)) ||
  //         (await commons.elementExists(accountPage.signOutPopUp_btn))
  //     ) {
  //         await commons.userAction('down');
  //         await commons.userAction('select');
  //     }
  // };
  //
  // handleAdTracking = async () => {
  //     if (await commons.elementExists(this.continue_btn, 5)) {
  //         await commons.userAction('down');
  //         await commons.userAction('select');
  //     }
  //     if (await commons.elementExists(this.noTracking_btn, 5)) {
  //         await commons.userAction('down');
  //         await commons.userAction('select');
  //     }
  // };
  pressNextOrDoneBtn = async () => {
    for (let i = 0; i < 3; i++) {
      await commons.userAction('down');
    }
    await commons.userAction('select');
  };

  enterNew = async () => {
    for (let i = 0; i < 15; i++) {
      await commons.userAction('down');
    }
    await commons.userAction('select');
  };

  enterCredentials = async (credentialType) => {
    const username = process.env[`${credentialType}_USERNAME`];
    const password = process.env[`${credentialType}_PASSWORD`];

    await commons.waitUntil(this.signin_text);
    if (await commons.elementExists(this.email_field, 10)) {
      await commons.userAction('select');
    }

    if (this.returnGeoLocation() === 'america') {
      if (await commons.elementExists(this.pre_lbl)) {
        await this.enterNew();
      }
    }

    await commons.sendText(this.userName_txtBx, username, 30);
    await this.pressNextOrDoneBtn();

    await commons.click(this.password_field);

    await commons.sendText(this.password_txtBx, password, 30);
    await this.pressNextOrDoneBtn();

    if (await commons.elementExists(this.signin_button, 10)) {
      await commons.userAction('down');
      await commons.userAction('select');
    }
  };

  loginToApplication = async (credentialType) => {
    if (this.returnGeoLocation() === 'america') {
      await this.signInUS(credentialType);
    }
    // if (this.returnGeoLocation() === 'emea') {
    //     await this.signIn(credentialType);
    // }

    // if (await profilePage.isManageProfileScreen()) {
    //     await profilePage.selectProfile('Default');
    // }
    //
    // await menuPage.assertPage('Home');
  };

  signInUS = async (credentialType) => {
    if (credentialType === 'anonymous') {
      return;
    }
    await commons.waitUntil(this.signIn_button);
    await commons.click(this.signIn_button);
    await commons.waitUntil(this.useRemote_button);
    await commons.click(this.useRemote_button);
    await commons.userAction('right');
    await this.enterCredentials(credentialType);
  };

  // signIn = async (credentialType) => {
  //     // if (await commons.elementExists(this.#startWatchingAnonymousUser_lbl)) {
  //     //     await commons.click(this.#signIn_btn);
  //     //     await this.enterCredentials(credentialType);
  //     //     return;
  //     // }
  //     if (credentialType === 'anonymous') {
  //         return;
  //     }
  //     if (!(await profilePage.isManageProfileScreen())) {
  //         await menuPage.assertPage('Home');
  //         await menuPage.navigateToPage('Account');
  //         await accountPage.navigateToSignIn();
  //         await this.enterCredentials(credentialType);
  //     }
  // };

  // signOut = async () => {
  //     if (await profilePage.isManageProfileScreen()) {
  //         const profile =
  //             this.returnGeoLocation() === 'america' ? 'Default' : 'Standard';
  //
  //         await profilePage.selectProfile(profile);
  //     }
  //     if (await homePage.isProfileAvatarVisible()) {
  //         if (await commons.elementExists(this.choosePlan_cta)) {
  //             await this.signOutHelper();
  //         } else {
  //             await menuPage.assertPage('Home');
  //             await menuPage.navigateToPage('Account');
  //             await accountPage.navigateToAccountPageTabs('Sign Out');
  //             await this.signOutHelper();
  //             if (this.returnGeoLocation() !== 'america') {
  //                 await menuPage.assertPage('Home');
  //             }
  //         }
  //     }
  // };
  //
  // verifySignOut = async () => {
  //     if (this.returnGeoLocation() === 'america') {
  //         await commons.waitUntil(this.welcome_txt);
  //         await commons.waitUntil(this.welcomeBody_lbl);
  //         await commons.waitUntil(this.welocmeFooter_lbl);
  //         await commons.waitUntil(this.subscribeNow_btn);
  //         //await commons.waitUntil(this.#signIn_btn);
  //     }
  // };
}

module.exports = SignInPage;
