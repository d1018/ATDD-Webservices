const { BasePage } = require('./basePage');

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  // #profileAvatar = this.#getSelectorData('profileAvatar');
  //
  isProfileAvatarVisible = async () => {
    //   const result = await commons.elementExists(this.#profileAvatar, 15);
    //
    //   return result;
  };

  verifyMyListRailOnHomePage = async () => {};

  verifyKidsContent = async () => {};

  scrollToNetworkRail = async () => {
    // let iteration = 0;
    // do {
    //   await commons.userAction('down');
    //   iteration++;
    // } while (
    //   !(await commons.elementExists(this.networkRail_lbl, 3)) &&
    //   iteration < 20
    // );
    // const isRailsFirstContentFocussed =
    //   (await commons.fetchAttributeData(
    //     this.networkRail_lbl,
    //     'focused',
    //     20,
    //   )) === 'true';
    // if (!isRailsFirstContentFocussed.to) {
    //   await commons.userAction('down');
    // }
  };

  validateNetworkRail = async () => {
    // await commons.waitUntil(this.networkRail_lbl);
  };

  verifyAgeRatingAndContentDescriptors = async () => {
    // switch (screenType) {
    //   case 'Main Hero':
    //     await commons.waitUntil(this.#contentRating_lbl);
    //     this.validateCurrentRating(
    //         await commons.fetchAttributeData(this.#contentRating_lbl, 'value'),
    //         screenType,
    //     );
    //     await commons.userAction('down');
    //     await commons.userAction('select');
    //     break;
    //   case 'Show Details Page':
    //     await commons.waitUntil(this.#showDetailsContentRating_lbl);
    //     this.validateCurrentRating(
    //         await commons.fetchAttributeData(
    //             this.#showDetailsContentRating_lbl,
    //             'value',
    //         ),
    //         screenType,
    //     );
    //     break;
    //   case 'Currently Playing Episode':
    //     this.validateCurrentRating(
    //         await commons.fetchAttributeData(
    //             this.#videoPlayerContentRating_lbl,
    //             'value',
    //         ),
    //         screenType,
    //     );
    //     while (
    //         !(await commons.elementExists(this.#showDetailsContentRating_lbl))
    //         ) {
    //       await commons.userAction('menu');
    //     }
    //     break;
    //   case 'Next Episodes listed on Episode Landing Page': {
    //     await commons.waitUntil(this.#showDetailsContentRating_lbl);
    //     await commons.userAction('down');
    //     const nextEpisodeList = await commons.findElements(
    //         this.#nextEpisodeContentRating_lbl,
    //     );
    //
    //     for (let i = 0; i < nextEpisodeList.length; i++) {
    //       this.validateCurrentRating(
    //           await commons.fetchAttributeData(nextEpisodeList[i], 'value'),
    //           screenType,
    //       );
    //     }
    //     break;
    //   }
    //   case 'Episode Info Panel':
    //     await commons.userAction('up');
    //     await commons.waitUntil(this.#showDetailsContentRating_lbl);
    //     await commons.userAction('select');
    //     await commons.userAction('up');
    //     await commons.waitUntil(this.#videoPlayerContentRating_lbl);
    //     await commons.userAction('down');
    //     // Info content rating is an image & contains no metadata about rating.
    //     await commons.waitUntil(this.#infoContentRating_lbl);
    //     break;
    //   default:
    //     break;
    // }
  };
}

module.exports = HomePage;
