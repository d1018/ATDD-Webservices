const SignInPage = require('./signInPage');
// const MemberFeedPage = require('./memberFeedPage');
// const MyStuffPage = require('./myStuffPage');
const ProfilePage = require('./profilePage');
const MenuPage = require('./menuPage');
const AccountPage = require('./accountPage');
// const PreLaunchPage = require('./preLaunchPage');
// const SearchPage = require('./searchPage');
const HomePage = require('./homePage');
const OnboardingPage = require('./onboardingPage');
const SearchPage = require('./searchPage');
const MyStuffPage = require('./myStuffPage');
const VideoPlayerPage = require('./videoPlayerPage');
const BrowsePage = require('./browsePage');

const signInPage = new SignInPage();
// const memberFeedPage = new MemberFeedPage();
// const myStuffPage = new MyStuffPage();
const profilePage = new ProfilePage();
const menuPage = new MenuPage();
// const preLaunchPage = new PreLaunchPage();
// const searchPage = new SearchPage();
const homePage = new HomePage();
const accountPage = new AccountPage();
const onboardingPage = new OnboardingPage();
const searchPage = new SearchPage();
const myStuffPage = new MyStuffPage();
const videoPlayerPage = new VideoPlayerPage();
const browsePage = new BrowsePage();

module.exports = {
  signInPage,
  // memberFeedPage,
  // myStuffPage,
  profilePage,
  menuPage,
  // preLaunchPage,
  // searchPage,
  homePage,
  accountPage,
  onboardingPage,
  searchPage,
  myStuffPage,
  videoPlayerPage,
  browsePage,
};
