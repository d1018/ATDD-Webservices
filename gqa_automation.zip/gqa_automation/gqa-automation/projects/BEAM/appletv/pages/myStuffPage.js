const { mobileActions, BasePage } = require('./basePage');

const commons = mobileActions;

class MyStuffPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myStuffPage', locator);
  }

  myList_tab = this.getElementByPage('myListNoUserDataPage', 'myList_tab');

  selectMyList = async () => {
    await this.navigateToPage('My Stuff');
    await commons.waitUntil(this.myList_tab);
    // await commons.click(this.myList_tab);
  };

  verifyMyListContent = async () => {
    // await menuPage.navigateToPage('My List');
    //
    // if (shouldHaveShows) {
    //   const titleRaw = await commons.fetchAttributeData(
    //       this.#myListPageAsset,
    //       'name',
    //   );
    //
    //   assert(
    //       titleRaw,
    //       `Within verifyShowsInMyList(), Current Show is ${titleRaw}`,
    //   );
    // } else {
    //   await commons.waitUntil(this.#myListEmptyStateTitle);
    // }
    //
    // await menuPage.navigateToPage('Home');
  };

  addShowsToMylist = async () => {
    // await menuPage.navigateToPage('My List');
    // await commons.waitUntil(this.#myListEmptyStateTitle);
    // await commons.waitUntil(this.#myListBrowseShows);
    //
    // await commons.userAction('select');
    // await commons.waitUntil(this.#discoveryOriginals_lbl);
    //
    // for (let i = 0; i < 4; i++) {
    //   await commons.userAction('down');
    // }
    // await commons.userAction('select');
    // await this.addToFavorites();
    //
    // const title = await commons.fetchAttributeData(
    //     this.#myListPageAssetLogo_lbl,
    //     'label',
    // );
    //
    // this.addToMyListShows(title);
    //
    // await commons.userAction('menu');
  };

  verifyMyListData = async () => {
    // await menuPage.navigateToPage('My List');
    //
    // if (shouldHaveShows) {
    //   const titleRaw = await commons.fetchAttributeData(
    //       this.#myListPageAsset,
    //       'name',
    //   );
    //
    //   assert(
    //       titleRaw,
    //       `Within verifyShowsInMyList(), Current Show is ${titleRaw}`,
    //   );
    // } else {
    //   await commons.waitUntil(this.#myListEmptyStateTitle);
    // }
    //
    // await menuPage.navigateToPage('Home');
  };

  verifyMyListAsset = async () => {};

  removeMyListContent = async () => {
    // await menuPage.navigateToPage('My List');
    // await commons.waitUntil(this.#myListPage_lbl);
    // await commons.userAction('select');
    // await commons.waitUntil(this.#favorite_btn);
    // await commons.userAction('right');
    // await commons.userAction('select');
    // await commons.userAction('menu');
  };

  verifyMyListTabContentRemoved = async () => {
    // await commons.waitUntil(this.#myListPage_lbl);
    // await commons.userAction('select');
    // await commons.waitUntil(
    //     this.getCustomLocator(this.#myListPageAsset_lbl, showName),
    // );
    // await commons.waitUntil(this.#favorite_btn);
    // await commons.userAction('right');
    // await commons.userAction('select');
  };
}

module.exports = MyStuffPage;
