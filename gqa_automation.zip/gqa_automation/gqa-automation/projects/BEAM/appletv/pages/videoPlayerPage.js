const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

let playerPositionAfter;
let currentPlayerTime;

class VideoPlayerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('videoPlayerPage', locator);
  }

  watch_button = this.#getSelectorData('watch_button');

  resume_button = this.#getSelectorData('resume_button');

  switchToOrientation = async () => {};

  verifyVideoOrientation = async () => {};

  navigateAndPlay = async () => {};

  scrubVideo = async () => {
    // await commons.waitUntil(this.#scrubNeedle);
    // await commons.userAction('select');
    // const elapsedTime = await commons.fetchAttributeData(
    //     this.#elapsedTime_lbl,
    //     'label',
    //     20,
    // );
    // const remainingTime = await commons.fetchAttributeData(
    //     this.#remainingTime_lbl,
    //     'label',
    //     20,
    // );
    // const totalTime =
    //     Math.abs(parseFloat(elapsedTime)) + Math.abs(parseFloat(remainingTime));
    // const percentage = percent / 10 ** 2;
    //
    // while (
    //     parseFloat(
    //         await commons.fetchAttributeData(this.#elapsedTime_lbl, 'label', 20),
    //     ) <
    //     totalTime * percentage
    //     ) {
    //   await commons.userAction('right');
    // }
    //
    // await this.backToHomePage();
  };

  // backToHomePage = async () => {
  //   for (let i = 0; i < 4; i++) {
  //     if (await commons.elementExists(this.#forYou_lbl, 3)) {
  //       return;
  //     }
  //     await commons.userAction('menu');
  //   }
  // };

  verifyAdPods = async () => {};

  verifyProgressBar = async () => {};

  verifyAdStreamElements = async () => {};

  resumeAndPlayVideo = async () => {
    // await commons.userAction('select');
  };

  validateResumePoint = async () => {
    // await commons.waitUntil(this.#remainingTime_lbl);
    // await commons.waitUntil(this.#scrubber_lbl);
    // await commons.waitUntil(this.#unifiedPlayer_lbl);
    // await commons.waitUntil(this.#captions_lbl);
    // await commons.waitUntil(this.#audioSettings_lbl);
    // await commons.waitUntil(this.#subtitlesSettings_lbl);
    // await commons.waitUntil(this.#mediaControls_lbl);
    //
    // // Pause to pull up media controls
    // await commons.userAction('select');
    //
    // const remainingTime = Math.abs(
    //     parseFloat(
    //         await commons.fetchAttributeData(this.#remainingTime_lbl, 'label', 20),
    //     ),
    // );
    // const elapsedTime = Math.abs(
    //     parseFloat(
    //         await commons.fetchAttributeData(this.#elapsedTime_lbl, 'label', 20),
    //     ),
    // );
    //
    // const totalTime = remainingTime + elapsedTime;
    // const percentage = percent / 10 ** 2;
    //
    // assert(
    //     elapsedTime + 2 >= totalTime * percentage &&
    //     elapsedTime - 2 <= totalTime * percentage,
    // );
  };

  verifyAdPlayBack = async () => {};

  verifyCC = async () => {};

  videoContainerView = this.#getSelectorData('videoContainerView');

  asset_title = this.#getSelectorData('asset_title');

  playPause_button = this.#getSelectorData('playPause_button');

  playerPlay_button = this.#getSelectorData('playerPlay_button');

  skipForward_button = this.#getSelectorData('skipForward_button');

  skipBack_button = this.#getSelectorData('skipBack_button');

  playerProgress_bar = this.#getSelectorData('playerProgress_bar');

  videoPlayerControls = {
    Pause: this.playPause_button,
    Resume: this.playerPlay_button,
    FFD: this.skipForward_button,
    RWD: this.skipBack_button,
  };

  /**
   * The below function will play the video and validate the watch now CTA
   */
  playShow = async () => {
    if (await commons.elementExists(this.watch_button)) {
      await commons.click(this.watch_button, 20);
    } else {
      await commons.click(this.resume_button, 20);
    }
  };

  /**
   * The below function will validate the player screen once the video will start playing.
   */
  isVideoPlaying = async () => {
    await commons.waitUntil(this.videoContainerView, 30);
    await commons.waitUntil(this.asset_title, 30);
  };

  /**
   * This function will validate video player actions like Pause, Resume, FFD and RWD
   *
   * @param {string} actions specifies player actions
   */
  verifyVideoActions = async (actions) => {
    if (actions === 'FFD' || actions === 'RWD') {
      currentPlayerTime = await this.videoPlayerPosition();
      await commons.elementExists(this.videoPlayerControls[actions]);
      await commons.click(this.videoPlayerControls[actions]);
      playerPositionAfter = await this.videoPlayerPosition();
      const timeGapBetweenPlayerBar = this.timeGap(
        currentPlayerTime,
        playerPositionAfter,
      );
      /* eslint-disable radix */

      assert(
        parseInt(timeGapBetweenPlayerBar) === 10,
        `Player action on video is not successful as the player position ${currentPlayerTime} is less than after position ${playerPositionAfter}`,
      );
    } else {
      await commons.elementExists(this.videoPlayerControls[actions]);
      await commons.click(this.videoPlayerControls[actions]);
    }
  };

  videoPlayerPosition = async () => {
    await commons.click(this.videoContainerView, 50);
    await commons.waitUntil(this.playerProgress_bar);
    const currentPlayerPosition = await commons.fetchAttributeData(
      this.playerProgress_bar,
      'Content-Desc',
    );

    return currentPlayerPosition;
  };

  // Function to find the time gap
  timeGap = (st, et) => {
    const t1 = this.getTimeInSeconds(st);
    const t2 = this.getTimeInSeconds(et);
    const timeDiff = t1 - t2 < 0 ? t2 - t1 : t1 - t2;
    let diff = this.convertSecToTime(timeDiff);

    diff = diff.split(':');
    return diff[1];
  };

  // Function to find the time difference
  getTimeInSeconds = (str) => {
    let currTime = [];

    currTime = str.split(':');
    /* eslint-disable radix */
    for (let i = 0; i < currTime.length; i++) {
      currTime[i] = parseInt(currTime[i]);
    }

    const t = currTime[0] * 60 + currTime[1];

    return t;
  };

  // Function to convert seconds back to mm:ss
  convertSecToTime = (t) => {
    const min = Math.floor((t % 3600) / 60);
    const mm = min < 10 ? `0${min.toString()}` : min.toString();
    const sec = (t % 3600) % 60;
    const ss = sec < 10 ? `0${sec.toString()}` : sec.toString();
    const ans = `${mm}:${ss}`;

    return ans;
  };
}

module.exports = VideoPlayerPage;
