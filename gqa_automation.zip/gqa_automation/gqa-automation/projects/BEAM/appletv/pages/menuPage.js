const { BasePage } = require('./basePage');

// const commons = mobileActions;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  // menuItem = {
  //   Home: this.#homeMenu_lbl,
  //   Browse: this.#browseMenu_lbl,
  //   Sports: this.#sportsMenu_lbl,
  //   Shows: this.#showsMenu_lbl,
  //   'Tv Guide': this.#tvGuideMenu_lbl,
  //   Search: this.#searchMenu_lbl,
  //   'My List': this.#myList_lbl,
  //   Account: this.#accountMenu_lbl,
  // };
  //
  // pageFocused = {
  //   Home: this.#forYou_lbl,
  //   Search: this.#searchPage_lbl,
  //   Sports: this.#sports_lbl,
  //   'Tv Guide': this.#timeBarCellTitle_txt,
  //   'My List': this.#myListPage_lbl,
  //   Account: this.#accountPage_lbl,
  //   Discovery: this.#discoveryOriginals_lbl,
  // };

  accessGlobalNavigationMenu = async () => {
    // await commons.userAction('left');
  };

  verifyMenuList = async () => {
    // await commons.waitUntil(this.menuItem.Home, 20);
    // await commons.waitUntil(this.menuItem.Browse, 20);
    // await commons.waitUntil(this.menuItem['My List'], 20);
    // await commons.waitUntil(this.menuItem.Search, 20);
    // await commons.waitUntil(this.menuItem.Account, 20);
  };

  verifyGlobalNavigation = async () => {
    // if (this.returnGeoLocation() === 'america') {
    //   await commons.userAction('select');
    //   await this.assertPage('Home');
    //   await this.navigateToPage('Browse');
    //   await this.assertPage('Discovery');
    //   await this.navigateToPage('My List');
    //   await this.assertPage('My List');
    //   await this.navigateToPage('Search');
    //   await this.assertPage('Search');
    //   await this.navigateToPage('Account');
    //   await this.assertPage('Account');
    // }
  };
}

module.exports = MenuPage;
