// const assert = require('assert');
const { BasePage } = require('./basePage');

// let newProfileName;
// let newProfileNameAfterEdited;
// let newEditedProfileName;

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  // profileName = '';
  //
  // profilesList = {
  //   Default: this.getCustomLocator(this.profileName_txt, 'Default'),
  //   Kids: this.getCustomLocator(this.profileName_txt, 'Kids'),
  //   Standard: this.getCustomLocator(this.profileName_txt, 'Standard'),
  //   Pin: this.#getSelectorData('pinProfileName'),
  //   Auto_Watch_Now: this.getCustomLocator(
  //     this.profileName_txt,
  //     'Auto_Watch_Now',
  //   ),
  //   Automation: this.getCustomLocator(this.profileName_txt, 'Automation'),
  //   'Empty MyList': this.getCustomLocator(this.profileName_txt, 'Empty MyList'),
  // };

  verifyProfileScreen = async () => {
    // await menuPage.navigateToPage('Home');
    // await commons.userAction('menu');
    // await commons.userAction('up');
    // await commons.userAction('select');
    // assert(
    //     await profilePage.isManageProfileScreen(),
    //     "User failed to navigate to Who's watching screen",
    // );
  };

  selectProfile = async () => {
    // if (
    //     profileName === 'Pin' ||
    //     (await commons.elementExists(this.#forYou_lbl, 10))
    // ) {
    //   await this.navigateToManageProfile();
    // }
    //
    // if (profileName.length === 0 || profileName === 'Anonymous') return;
    // assert(
    //     await this.isManageProfileScreen(),
    //     'User is not on Manage Profile Screen',
    // );
    //
    // await commons.waitUntil(this.profilesList[profileName], 20);
    // await this.hoverToProfile(profileName);
    // await commons.userAction('select');
    //
    // if (profileName === 'Pin') {
    //   const pinValue = process.env.PROFILE_PIN;
    //   const pinValues = pinValue.split('');
    //
    //   for (let i = 0; i < pinValues.length; i++) {
    //     await commons.click(
    //         await this.getCustomLocator(this.pinKeypad, pinValues[i]),
    //     );
    //   }
    // }
  };

  createNewProfile = async () => {
    //   if (profileType === 'Pin') {
    //     this.profileName = 'Pin';
    //     return;
    //   }
    //   await this.navigateToManageProfile();
    //   const isProfileExist = await this.isProfileExist(profileType);
    //
    //   if (isProfileExist) {
    //     await commons.userAction('down');
    //     await commons.click(this.manageProfiles_btn);
    //     await this.selectDeletingProfile(profileType);
    //     await commons.waitUntil(this.deleteProfile_btn, 5);
    //     await commons.click(this.deleteProfile_btn);
    //     await commons.waitUntil(this.deleteProfilePopup_btn, 5);
    //     await commons.click(this.deleteProfilePopup_btn, 15);
    //     await commons.waitUntil(this.manageProfiles_lbl, 20);
    //     await commons.userAction('menu');
    //     await commons.waitUntil(this.manageProfiles_btn);
    //   }
    //
    //   await commons.waitUntil(this.addProfile_btn, 10);
    //   await commons.click(this.addProfile_btn);
    //   await commons.waitUntil(this.createProfileName_btn);
    //   await commons.click(this.createProfileName_txtBx, 20);
    //   this.profileName = profileType + this.getRandomNumber(1000);
    //
    //   await commons.sendText(this.createProfileName_txtBx, this.profileName);
    //   for (let i = 0; i < 3; i++) {
    //     await commons.userAction('down');
    //   }
    //   await commons.userAction('select');
    //
    //   await commons.waitUntil(this.save_btn, 5);
    //   if (profileType === 'Kids') {
    //     await commons.userAction('up');
    //     await commons.userAction('select');
    //   }
    //   await commons.click(this.save_btn);
  };

  profileCreation = async () => {
    // await this.createNewProfile(profileType);
    // await this.selectProfile(profileType);
  };

  // deleteUserProfile = async (profileName = '') => {
  //   let profileNames = [];
  //   let profileToDelete;
  //
  //   if (profileName.length === 0 || profileName === 'random') {
  //     this.nonDefaultProfileList = await this.getNonDefaultProfilesList();
  //
  //     if (this.nonDefaultProfileList.length === 0) {
  //       throw new Error('There are no Non-Default profiles to delete');
  //     }
  //
  //     profileToDelete =
  //         this.nonDefaultProfileList[
  //         Number(this.nonDefaultProfileList.length) - 1
  //             ];
  //
  //     await commons.waitUntil(this.manageProfiles_btn);
  //     await commons.userAction('down');
  //     await commons.click(this.manageProfiles_btn);
  //
  //     profileToDelete = this.getCustomLocator(
  //         this.editProfile_btn,
  //         profileToDelete,
  //     );
  //
  //     await commons.waitUntil(profileToDelete, 5);
  //     await this.selectDeletingProfile(profileToDelete);
  //     await commons.waitUntil(this.deleteProfile_btn, 5);
  //     await commons.click(this.deleteProfile_btn);
  //     await commons.waitUntil(this.deleteProfilePopup_btn, 5);
  //     await commons.click(this.deleteProfilePopup_btn, 15);
  //     await commons.waitUntil(this.manageProfiles_lbl, 20);
  //     await commons.userAction('menu');
  //     await commons.waitUntil(this.manageProfiles_btn);
  //   }
  //
  //   if (profileName.includes('Kids')) {
  //     await this.selectProfile('Default');
  //     await this.navigateToManageProfile();
  //   }
  //   await commons.userAction('down');
  //   await commons.click(this.manageProfiles_btn);
  //
  //   profileNames = await this.getUserProfilesNamesList();
  //
  //   if (profileNames.includes(profileName)) {
  //     profileToDelete = this.getCustomLocator(
  //         this.editProfile_btn,
  //         profileName,
  //     );
  //
  //     const profileNameForDelete = await commons.fetchAttributeData(
  //         profileToDelete,
  //         'label',
  //         10,
  //     );
  //
  //     await commons.waitUntil(profileToDelete, 5);
  //     await this.selectDeletingProfile(profileNameForDelete);
  //     await commons.waitUntil(this.deleteProfile_btn, 5);
  //     await commons.click(this.deleteProfile_btn);
  //     await commons.waitUntil(this.deleteProfilePopup_btn, 5);
  //     await commons.click(this.deleteProfilePopup_btn, 15);
  //     await commons.waitUntil(this.manageProfiles_lbl, 20);
  //     await commons.userAction('menu');
  //   }
  // };

  // selectDeletingProfile = async (profileName) => {
  //   if (profileName === 'Pin') {
  //     return;
  //   }
  //
  //   const userProfileElementsList = await this.getUserProfilesNamesList();
  //
  //   await commons.userAction('up');
  //   for (let i = 0; i < userProfileElementsList.length; i++) {
  //     await commons.userAction('left');
  //   }
  //   for (let i = 0; i < userProfileElementsList.length - 1; i++) {
  //     if (!userProfileElementsList[i].includes(profileName)) {
  //       await commons.userAction('right');
  //     } else {
  //       break;
  //     }
  //   }
  //   await commons.userAction('select');
  // };
  //
  // hoverToProfile = async (profileName) => {
  //   if (!(await this.isProfileExist(profileName))) {
  //     throw new Error(`User Profile Doesn't exist!!! ${profileName}`);
  //   }
  //   const userProfileElementsList = await this.getUserProfilesNamesList();
  //
  //   await commons.userAction('up');
  //   for (let i = 0; i < userProfileElementsList.length; i++) {
  //     await commons.userAction('left');
  //   }
  //   for (let i = 0; i < userProfileElementsList.length; i++) {
  //     if (!userProfileElementsList[i].includes(profileName)) {
  //       await commons.userAction('right');
  //     } else {
  //       break;
  //     }
  //   }
  // };
  //
  // getNonDefaultProfilesList = async () => {
  //   const nonDefaultProfilesElementsList = await commons.findElements(
  //       this.nonDefaultProfilesList,
  //   );
  //   const profilesList = [];
  //
  //   for (let i = 0; i < nonDefaultProfilesElementsList.length; i++) {
  //     profilesList.push(
  //         await commons.fetchAttributeData(
  //             nonDefaultProfilesElementsList[i],
  //             'label',
  //             10,
  //         ),
  //     );
  //   }
  //
  //   return profilesList;
  // };
  //
  // getUserProfilesNamesList = async () => {
  //   const userProfileElementsList = await commons.findElements(
  //       this.userProfileList,
  //   );
  //   const profilesList = [];
  //
  //   for (let i = 0; i < userProfileElementsList.length; i++) {
  //     profilesList.push(
  //         await commons.fetchAttributeData(
  //             userProfileElementsList[i],
  //             'label',
  //             10,
  //         ),
  //     );
  //   }
  //   return profilesList;
  // };
  //
  // navigateToManageProfile = async () => {
  //   await menuPage.navigateToPage('Home');
  //   await commons.userAction('menu');
  //   await commons.userAction('up');
  //   await commons.userAction('select');
  // };
  moveToEdit = async () => {
    // await commons.waitUntil(this.profilesList[profileType], 20);
    // await this.hoverToProfile(profileType);
    //
    // const profileNameForEdit = this.getCustomLocator(
    //     this.focusedEdit_button,
    //     profileName,
    // );
    //
    // await commons.waitUntil(profileNameForEdit);
    // await commons.click(this.editProfiles_button);
    // await commons.click(profileNameForEdit);
  };

  // createNewProfileAndMoveToEdit = async (profileType) => {
  //   await this.createNewProfile(profileType);
  //   await this.moveToEdit(profileType);
  // };

  deleteProfile = async () => {};

  verifyUserProfileDeleted = async () => {};

  deleteExistingProfile = async () => {};

  verifyAddProfileButton = async () => {};

  pressNextOrDoneBtn = async () => {
    // for (let i = 0; i < 3; i++) {
    //   await commons.userAction('down');
    // }
    // await commons.userAction('select');
  };

  editUserProfile = async () => {
    // await commons.waitUntil(this.createProfileName_txtBx);
    // await commons.click(this.createProfileName_txtBx);
    // await commons.clearText(this.createProfileName_text);
    // await commons.sendText(this.createProfileName_txtBx, this.editProfileName);
    // await this.pressNextOrDoneBtn();
    // await commons.waitUntil(this.Done_btn);
    // await commons.click(this.Done_btn);
  };

  verifyEditedProfile = async () => {
    // await this.isProfileExist(this.editProfileName);
  };
}

module.exports = ProfilePage;
