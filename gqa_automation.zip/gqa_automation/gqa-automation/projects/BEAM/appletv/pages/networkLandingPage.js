const { BasePage } = require('./basePage');

class NetworkLandingPage extends BasePage {
  selectAndValidateNetworkLandingPage = async (network) => {
    if (network === 'Sports') {
      return;
    }
    if (network === 'Entertainment') {
      await this.validateEntertainmentNetworkLandingPage();
    }
  };
}
module.exports = NetworkLandingPage;
