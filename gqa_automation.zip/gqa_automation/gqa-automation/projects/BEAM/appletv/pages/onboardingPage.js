const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');
const { signInPage } = require('./signInPage');

const commons = mobileActions;

class OnboardingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('onboardingPage', locator);
  }

  subscribeNow_button = this.getElementByPage(
    'welcomePage',
    'subscribeNow_button',
  );

  planPickerScreen_lbl = this.#getSelectorData('planPickerScreen_lbl');

  adFree_plan = this.#getSelectorData('adFree_plan');

  continue_btn = this.#getSelectorData('continue_btn');

  createAccountScreen_lbl = this.#getSelectorData('createAccountScreen_lbl');

  email_txt = this.#getSelectorData('email_txt');

  password_txt = this.#getSelectorData('password_txt');

  show_btn = this.#getSelectorData('show_btn');

  next_btn = this.#getSelectorData('next_btn');

  userName_txtBx = this.getElementByPage(
    'useYourRemoteSignInPage',
    'userName_txtBx',
  );

  password_txtBx = this.getElementByPage(
    'useYourRemoteSignInPage',
    'password_txtBx',
  );

  pre_lbl = this.getElementByPage('useYourRemoteSignInPage', 'pre_lbl');

  firstName_txt = this.#getSelectorData('firstName_txt');

  lastName_txt = this.#getSelectorData('lastName_txt');

  continueAgree_btn = this.#getSelectorData('continueAgree_btn');

  //
  //   inactiveSub_lbl = this.#getSelectorData('inactiveSub_lbl');
  //
  //   choosePlan_cta = this.#getSelectorData('choosePlan_cta');
  //
  //   signOut_cta = this.#getSelectorData('signOut_cta');
  //
  //   /**
  //    * The below function will validate the Lapsed/Inactive Subscription screen whether the required elements are displayed
  //    */
  verifyInactiveSubscriptionScreen = async () => {
    //     assert(
    //       (await commons.elementExists(this.inactiveSub_lbl)) &&
    //         (await commons.elementExists(this.choosePlan_cta)),
    //       `View Passes is not showing on upgrade to watch screen`,
    //     );
    //     await commons.waitUntil(this.signOut_cta);
    //     await commons.click(this.signOut_cta);
    //     await commons.userAction('down');
    //     await commons.userAction('select');
  };

  navigateToPlanPickerPage = async () => {
    await commons.waitUntil(this.subscribeNow_button, 20);
    await commons.click(this.subscribeNow_button);
    const actualPlanPickerPageHeaderLabel = await commons.fetchAttributeData(
      this.planPickerScreen_lbl,
      'label',
      20,
    );
    const expectedPlanPickerPageHeaderLabel = 'Choose Your Plan';

    assert.equal(
      actualPlanPickerPageHeaderLabel,
      expectedPlanPickerPageHeaderLabel,
      'Failed to land on Plan Picker page!!',
    );
  };

  selectAnyPlan = async () => {
    await commons.click(this.adFree_plan);
    await commons.userAction('down');
    await commons.userAction('select');
    // await  commons.click(this.continue_btn,20);
  };

  createAccount = async () => {
    await this.enterCreateAccountDetails();
  };

  selectSubscribeCta() {}

  selectPaymentType(paymentType) {
    return paymentType;
  }

  submitPaymentDetails(paymentType) {
    return paymentType;
  }

  verifyPostPurchaseConfirmationScreen() {}

  clickOnLetsGoCta() {}

  verifyProfileScreen() {}

  enterCreateAccountDetails = async () => {
    const username = 'shiba.sahoo12@gmail.com';
    const password = 'TestPassword@12';

    await commons.click(this.email_txt, 10);
    if (await commons.elementExists(this.pre_lbl)) {
      await this.enterNew();
    }
    await commons.sendText(this.userName_txtBx, username, 30);
    await signInPage.pressNextOrDoneBtn();
    await commons.click(this.password_txt);
    await commons.sendText(this.password_txtBx, password, 30);
    await signInPage.pressNextOrDoneBtn();
    await commons.click(this.show_btn, 10);
    await commons.click(this.next_btn, 10);

    const firstName = 'shiba';
    const lastName = 'sahoo';

    await commons.click(this.firstName_txt);
    await commons.sendText(this.userName_txtBx, firstName, 30);
    await signInPage.pressNextOrDoneBtn();
    await commons.sendText(this.password_txtBx, lastName, 30);
    await signInPage.pressNextOrDoneBtn();
    await commons.click(this.continueAgree_btn);
  };

  // pressNextOrDoneBtn = async () => {
  //   for (let i = 0; i < 3; i++) {
  //     await commons.userAction('down');
  //   }
  //   await commons.userAction('select');
  // };

  enterNew = async () => {
    for (let i = 0; i < 15; i++) {
      await commons.userAction('down');
    }
    await commons.userAction('select');
  };
}

module.exports = OnboardingPage;
