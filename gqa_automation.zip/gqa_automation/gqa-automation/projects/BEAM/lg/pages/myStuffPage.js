const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class MyStuffPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myStuffPage', locator);
  }

  focusedMyStuffTabs = this.getElementByPage(
    'genericLocator',
    'focusedMyStuffTabs',
  );

  focusedMyListTab = this.getCustomLocator(this.focusedMyStuffTabs, 'My List');

  noSavedTitles_header = this.#getSelectorData('noSavedTitles_header');

  focusedMyStuffRecommended_tile = this.#getSelectorData(
    'focusedMyStuffRecommended_tile',
  );

  focusedAddRemove_button = this.getElementByPage(
    'genericLocator',
    'focusedAddRemove_button',
  );

  focusedAddToMyList_button = this.getCustomLocator(
    this.focusedAddRemove_button,
    'My List',
  );

  focusedRemoveFromMyList_button = this.getCustomLocator(
    this.focusedAddRemove_button,
    'Remove',
  );

  myList_tile = this.#getSelectorData('myList_tile');

  selectMyList = async () => {
    await commons.tryUntil(this.focusedMyListTab, VRC.DOWN, 2);
    await commons.assertExists(this.focusedMyListTab);
  };

  verifyMyListContent = async () => {
    await commons.waitUntil(this.noSavedTitles_header, 20);
    await commons.assertExists(this.noSavedTitles_header);
  };

  addShowsToMylist = async () => {
    await commons.tryUntil(this.focusedMyStuffRecommended_tile, VRC.DOWN, 5);
    await commons.assertExists(this.focusedMyStuffRecommended_tile);
    await commons.userAction(VRC.ENTER);
    await commons.tryUntil(this.focusedAddToMyList_button, VRC.RIGHT, 5);
    await commons.assertExists(this.focusedAddToMyList_button);
    await commons.userAction(VRC.ENTER);
    await commons.waitUntil(this.focusedRemoveFromMyList_button, 10);
    await commons.assertExists(this.focusedRemoveFromMyList_button);
    await commons.userAction(VRC.BACK);
  };

  verifyMyListData = async (hasShows) => {
    if (hasShows) {
      await commons.waitUntil(this.myList_tile, 20);
      await commons.assertExists(this.myList_tile);
    } else {
      await commons.waitUntil(this.noSavedTitles_header, 20);
      await commons.assertExists(this.noSavedTitles_header);
    }
  };
}

module.exports = new MyStuffPage();
