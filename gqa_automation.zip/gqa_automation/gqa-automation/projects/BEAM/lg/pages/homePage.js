const menuPage = require('./menuPage');
const settingsPage = require('./settingsPage');
const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  focusedHomeTab = this.#getSelectorData('focusedHomeTab');

  focusedMenuItem = this.getElementByPage('genericLocator', 'focusedMenuItem');

  focusedSettingMenuItem = this.getCustomLocator(
    this.focusedMenuItem,
    'Settings',
  );

  focusedHomeMenuItem = this.getElementByPage(
    'menuPage',
    'focusedHomeMenuItem',
  );

  focusedSignOutMenuItem = this.getElementByPage(
    'settingsPage',
    'focusedSignOutMenuItem',
  );

  focusedSignOutConfirmation_button = this.getElementByPage(
    'settingsPage',
    'focusedSignOutConfirmation_button',
  );

  signIn_btn = this.getElementByPage('welcomePage', 'signIn_btn');

  focusedMyList_tile = this.#getSelectorData('focusedMyList_tile');

  myListRail = this.#getSelectorData('myListRail');

  signOut = async () => {
    await menuPage.navigateToPage('Settings');
    await settingsPage.signOut();
  };

  verifyMyListRailOnHomePage = async (hasShows) => {
    await menuPage.navigateToPage('Home');
    if (hasShows) {
      await commons.tryUntil(this.focusedMyList_tile, VRC.DOWN, 10);
      await commons.assertExists(this.myListRail, 10);
    }
  };
}

module.exports = new HomePage();
