const path = require('path');
const { remoteActions, testdataHelper } = require('@wbd/gqa-core/support');

const commons = remoteActions;

const { VRC } = commons;

const ymlpath = path.resolve(__dirname);

const EnvBase = require('../../../support/env');

// These global variables are for the search screen keyboard
// navigation.
const rowIndexArray = [];
const columnIndexArray = [];
const leftRightArray = [];
const downUpArray = [];
const actionArray = [];
const spaceIndexArray = [];

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }

  // This is a map of the search screen keyboard.
  // The space character is translated to '$'
  // and delete is translated to '<'
  searchKeyboardLayout = {
    0: ['a', 'b', 'c', 'd', 'e', 'f'],
    1: ['g', 'h', 'i', 'j', 'k', 'l'],
    2: ['m', 'n', 'o', 'p', 'q', 'r'],
    3: ['s', 't', 'u', 'v', 'w', 'x'],
    4: ['y', 'z', '1', '2', '3', '4'],
    5: ['5', '6', '7', '8', '9', '0'],
    6: ['<', '$', '*', '*', '*', '*'],
  };

  /**
   * This function returns an array that determines how to navigate
   * the keyboard and the associated button presses.
   *
   * @param {string} searchContent - content to search
   */
  prepareUserActionArray = async (searchContent) => {
    const searchString = searchContent.toLowerCase().split(/[ ,]+/).join('$');

    await this.#getRowColumnIndices(searchString);
    this.#correctColumnArray();
    await this.#fillActionArray();
    return actionArray;
  };

  /**
   * This private function gets the row and column indices of the letters
   * in the search content from the class member searchKeyboardLayout.
   *
   * @param {string} searchString - content to search
   */
  #getRowColumnIndices = async (searchString) => {
    let rowIndex = 0;
    let columnIndex = 0;

    for (let i = 0; i < searchString.length; i++) {
      for (
        let j = 0;
        j < (await Object.keys(this.searchKeyboardLayout).length);
        j++
      ) {
        if (
          await Object.values(this.searchKeyboardLayout)[j].includes(
            searchString[i],
          )
        ) {
          columnIndex = await Object.values(this.searchKeyboardLayout)[
            j
          ].indexOf(searchString[i]);

          await columnIndexArray.push(columnIndex);
          rowIndex = j;
          await rowIndexArray.push(rowIndex);
        }
      }
      if (searchString[i] === '$') {
        await spaceIndexArray.push(i);
      } else {
        await spaceIndexArray.push('%');
      }
    }
  };

  /**
   * This private function is used to modify the column indices to allow
   * navigation to be consistent when the search string contains a space.
   * Because space is part of a different grid in the layout, this modification
   * becomes necessary.
   *
   */
  #correctColumnArray = () => {
    let isFirstSpaceInstance = true;

    for (let i = 0; i < columnIndexArray.length; i++) {
      if (spaceIndexArray[i] !== '%' && isFirstSpaceInstance) {
        isFirstSpaceInstance = false;
        columnIndexArray[i] = columnIndexArray[i - 1] + 1;
      } else if (spaceIndexArray[i] !== '%' && !isFirstSpaceInstance) {
        columnIndexArray[i] = columnIndexArray[i - 1];
      }
    }
  };

  /**
   * This private function populates a 2D action array which is what is
   * ultimately returned to perform the user actions.
   *
   */
  #fillActionArray = async () => {
    await leftRightArray.push(columnIndexArray[0]);
    await downUpArray.push(rowIndexArray[0]);
    for (let i = 1; i < columnIndexArray.length; i++) {
      if (spaceIndexArray[i - 1] !== '%') {
        await leftRightArray.push(
          columnIndexArray[i] - columnIndexArray[i - 2],
        );
      } else {
        await leftRightArray.push(
          columnIndexArray[i] - columnIndexArray[i - 1],
        );
      }
      await downUpArray.push(rowIndexArray[i] - rowIndexArray[i - 1]);
    }

    for (let i = 0; i < downUpArray.length; i++) {
      actionArray.push([downUpArray[i], leftRightArray[i]]);
    }
  };

  /**
   * This function returns an array that determines how to navigate
   * the keyboard and the associated button presses.
   *
   * @param {string} userActions - array containing user actions
   * @param {string} speedNav - array containing user actions
   * @param {string} speedPress - array containing user actions
   */
  traverseKeyboard = async (userActions, speedNav, speedPress) => {
    for (let i = 0; i < userActions.length; i++) {
      if (userActions[i][0] < 0) {
        await commons.userAction(
          VRC.UP,
          Math.abs(Number(userActions[i][0])),
          speedNav,
        );
      } else if (userActions[i][0] > 0) {
        await commons.userAction(
          VRC.DOWN,
          Math.abs(Number(userActions[i][0])),
          speedNav,
        );
      }
      if (userActions[i][1] < 0) {
        await commons.userAction(
          VRC.LEFT,
          Math.abs(Number(userActions[i][1])),
          speedNav,
        );
      } else if (userActions[i][1] > 0) {
        await commons.userAction(
          VRC.RIGHT,
          Math.abs(Number(userActions[i][1])),
          speedNav,
        );
      }
      await commons.userAction(VRC.SELECT, 1, speedPress);
    }
  };
}

module.exports = {
  remoteActions,
  testdataHelper,
  BasePage,
};
