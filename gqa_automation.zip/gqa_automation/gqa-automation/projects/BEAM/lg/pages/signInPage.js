const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  focusedUseRemote = this.#getSelectorData('focusedUseRemote');

  focusedScanQR = this.#getSelectorData('focusedScanQR');

  focusedWelcomePage_btn = this.getElementByPage(
    'genericLocator',
    'focusedWelcomePage_btn',
  );

  focusedSignIn_button = this.getCustomLocator(
    this.focusedWelcomePage_btn,
    'Sign In',
  );

  focusedConnect_button = this.getCustomLocator(
    this.focusedWelcomePage_btn,
    'Connect Your Provider',
  );

  focusedSubscribe_button = this.getCustomLocator(
    this.focusedWelcomePage_btn,
    'Subscribe Now',
  );

  focusedProfile = this.getElementByPage('profilePage', 'focusedProfile');

  signIn_btn = this.getElementByPage('welcomePage', 'signIn_btn');

  focusedSignIn_fields = this.getElementByPage(
    'genericLocator',
    'focusedSignIn_fields',
  );

  focusedEmailInput = this.getCustomLocator(
    this.focusedSignIn_fields,
    'EmailInput',
  );

  focusedPasswordInput = this.getCustomLocator(
    this.focusedSignIn_fields,
    'PasswordInput',
  );

  openApp = async () => {
    await commons.clearAppData();
    await commons.openApp();
    await commons.assertExists(this.signIn_btn, 60);
  };

  navigateToSignInScreen_US = async () => {
    await commons.tryUntil(this.focusedSignIn_button, VRC.RIGHT, 5, 1);
    await commons.userAction(VRC.ENTER, 1, 4);
    await commons.waitUntil(this.focusedScanQR, 15);
    await commons.tryUntil(this.focusedUseRemote, VRC.DOWN, 2, 5);
    await commons.tryUntil(this.focusedEmailInput, VRC.RIGHT, 2, 5);
  };

  verifySignOut = async () => {
    await commons.assertExists(this.signIn_btn, 10);
  };

  enterCredentials = async (credentialType) => {
    const username = process.env[`${credentialType}_USERNAME`];
    const password = process.env[`${credentialType}_PASSWORD`];

    await commons.assertExists(this.focusedEmailInput);
    await commons.userAction(VRC.RIGHT, 1, 5);
    await commons.userAction(VRC.ENTER, 1, 5);
    await commons.sendText(username);
    await commons.userAction(VRC.BACK);
    await commons.userAction(VRC.DOWN);
    await commons.userAction(VRC.ENTER, 1, 2);
    await commons.sendText(password);
    await commons.userAction(VRC.BACK);
    await commons.userAction(VRC.DOWN);
    await commons.userAction(VRC.ENTER);
  };

  loginToApplication = async (credentialType) => {
    await this.navigateToSignInScreen_US();
    await this.enterCredentials(credentialType);
    await commons.waitUntilVisible(this.focusedProfile, 20);
  };
}

module.exports = new SignInPage();
