const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  signIn_btn = this.getElementByPage('welcomePage', 'signIn_btn');

  focusedSignIn_btn = this.getElementByPage('welcomePage', 'focusedSignIn_btn');

  moreinfoHero_button = this.getElementByPage(
    'homePage',
    'moreinfoHero_button',
  );

  focusedHomeMenuItem = this.getElementByPage(
    'menuPage',
    'focusedHomeMenuItem',
  );

  focusedHomeTab = this.getElementByPage('homePage', 'focusedHomeTab');

  whoIsWatching_label = this.getElementByPage(
    'profilePage',
    'whoIsWatching_label',
  );

  focusedProfilePicker = this.#getSelectorData('focusedProfilePicker');

  pageFocused = {
    Home: this.moreinfoHero_button,
  };

  focusedMenuItem = this.getElementByPage('genericLocator', 'focusedMenuItem');

  focusedSettingMenuItem = this.getCustomLocator(
    this.focusedMenuItem,
    'Settings',
  );

  focusedMyStuffMenuItem = this.getCustomLocator(
    this.focusedMenuItem,
    'My Stuff',
  );

  focusedProfile = this.getElementByPage('profilePage', 'focusedProfile');

  openMenu = async () => {
    await commons.tryUntil(this.focusedHomeMenuItem, VRC.BACK, 3, 1);
    await commons.assertExists(this.focusedHomeMenuItem);
    await commons.userAction(VRC.UP, 5);
  };

  navigateToPage = async (pageValue) => {
    if (await commons.elementExists(this.whoIsWatching_label)) {
      // Select a profile by default
      await commons.assertExists(this.focusedProfile);
      await commons.userAction(VRC.SELECT);
      await commons.waitUntil(this.focusedHomeTab, 20);
      await commons.assertExists(this.focusedHomeTab);
    }

    switch (pageValue) {
      case 'Signin':
        await commons.waitUntil(this.signIn_btn, 20);
        await commons.tryUntil(this.focusedSignIn_btn, VRC.RIGHT, 6, 1);
        await commons.userAction(VRC.ENTER);
        break;
      case 'My Stuff':
      case 'Home':
      case 'Search':
      case 'Settings':
        await this.openMenu();
        await commons.tryUntil(
          this.getCustomLocator(this.focusedMenuItem, pageValue),
          VRC.DOWN,
          5,
          0.5,
        );
        await commons.userAction(VRC.ENTER);
        break;
      case 'Profile':
        await this.openMenu();
        await commons.tryUntil(this.focusedProfilePicker, VRC.UP, 5, 0.5);
        await commons.userAction(VRC.ENTER);
        await commons.assertExists(this.whoIsWatching_label, 10);
        break;
      default:
        throw new Error('Menu item not found!');
    }
  };

  assertPage = async (pageValue) => {
    await commons.waitUntil(this.pageFocused[pageValue], 20);
    await commons.assertExists(this.pageFocused[pageValue], 20);
  };
}

module.exports = new MenuPage();
