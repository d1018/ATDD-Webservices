const { BasePage, remoteActions } = require('./basePage');

const menuPage = require('./menuPage');

const commons = remoteActions;
const { VRC, COMP, PROP } = commons;

let isDeleteRandomProfile = false;
let createdProfileName = '';

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  focusedProfile = this.#getSelectorData('focusedProfile');

  whoIsWatching_label = this.#getSelectorData('whoIsWatching_label');

  addProfile_button = this.#getSelectorData('addProfile_button');

  focusedProfile_button = this.#getSelectorData('focusedProfile_button');

  profileAvatarPage_title = this.#getSelectorData('profileAvatarPage_title');

  focusedAvatarImage = this.#getSelectorData('focusedAvatarImage');

  focusedProfileName_field = this.#getSelectorData('focusedProfileName_field');

  focusedProfileCreationDone_button = this.#getSelectorData(
    'focusedProfileCreationDone_button',
  );

  focusedProfileCreationDelete_button = this.#getSelectorData(
    'focusedProfileCreationDelete_button',
  );

  deleteProfileButtons = this.#getSelectorData('deleteProfileButtons');

  focusedCancelDeleteProfile_button = this.getCustomLocator(
    this.deleteProfileButtons,
    'Cancel',
  );

  focusedProfileDelete_button = this.getCustomLocator(
    this.deleteProfileButtons,
    'Delete',
  );

  focusedProfileName = this.#getSelectorData('focusedProfileName');

  verifyProfileScreen = async () => {
    await commons.waitUntil(this.focusedProfile, 20);
    await commons.assertExists(this.focusedProfile);
  };

  selectProfile = async (profileType) => {
    if (profileType.includes('Default') || profileType.includes('any')) {
      await commons.userAction(VRC.ENTER);
    }
  };

  profileCreation = async (profileType) => {
    const profileRandom = String(Math.floor(Math.random() * 10000));

    createdProfileName = profileType + profileRandom;

    if (await commons.doesNotExist(this.addProfile_button, 2)) {
      isDeleteRandomProfile = true;
      await this.deleteExistingProfile();
    }

    await commons.tryUntil(
      this.getCustomLocator(this.focusedProfile_button, 'Add profile'),
      VRC.RIGHT,
      6,
      0.5,
    );
    await commons.assertExists(
      this.getCustomLocator(this.focusedProfile_button, 'Add profile'),
    );
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.profileAvatarPage_title);
    await commons.assertExists(this.focusedAvatarImage);
    await commons.userAction(VRC.ENTER);
    await commons.tryUntil(this.focusedProfileName_field, VRC.RIGHT, 2);
    await commons.assertExists(this.focusedProfileName_field);
    await commons.userAction(VRC.ENTER);
    await commons.sendText(createdProfileName);
    await commons.userAction(VRC.BACK);
    await commons.tryUntil(this.focusedProfileCreationDone_button, VRC.DOWN, 3);
    await commons.assertExists(this.focusedProfileCreationDone_button);
    await commons.userAction(VRC.ENTER);
    await this.verifyProfileScreen();

    // By default after profile creation, focus should be on the created profile
    await commons.assertExists(
      this.getCustomLocator(this.focusedProfile_button, createdProfileName),
    );
    await commons.userAction(VRC.ENTER);
  };

  deleteExistingProfile = async () => {
    if (isDeleteRandomProfile) {
      await this.deleteRandomProfile();
    } else {
      await menuPage.navigateToPage('Profile');
      await this.deleteProfileByName(createdProfileName);
    }
  };

  deleteRandomProfile = async () => {
    // This function will be written at a later stage.
    // The intent of this function is to delete a random
    // profile if the maximum number of profiles is hit
    // so as to allow a new profile to be created.
  };

  deleteProfileByName = async (profileName) => {
    await commons.waitUntil(this.focusedProfile, 10);
    await commons.assertExists(this.focusedProfile);

    if (
      await commons.checkProperty(
        this.focusedProfileName,
        PROP.TEXT_CONTENT,
        profileName,
        COMP.EQUAL,
      )
    ) {
      await commons.userAction(VRC.DOWN);
      await commons.userAction(VRC.ENTER);

      await commons.tryUntil(
        this.focusedProfileCreationDone_button,
        VRC.DOWN,
        5,
      );
      await commons.tryUntil(
        this.focusedProfileCreationDelete_button,
        VRC.RIGHT,
        5,
      );
      await commons.assertExists(this.focusedProfileCreationDelete_button);
      await commons.userAction(VRC.ENTER);
      await commons.tryUntil(this.focusedProfileDelete_button, VRC.RIGHT, 5);
      await commons.assertExists(this.focusedProfileDelete_button);
      await commons.userAction(VRC.ENTER);
      await commons.waitUntil(this.whoIsWatching_label);
      await commons.assertExists(this.whoIsWatching_label);
    }
  };
}

module.exports = new ProfilePage();
