const geo = ['US', 'Us', 'us'].includes(process.env.GEO) ? '' : process.env.GEO;
const project = process.env.BS_PROJECT || 'Android Project';
const name = process.env.NAME || 'Android UFW';
const build = process.env.BUILD || 'Android Exec';
const debug = process.env.DEBUG || true;
const osVersion = process.env.OS_VERSION || '9.0';
const device = process.env.DEVICE_NAME || 'Google Pixel 3a';
const app = process.env.APP || 'bs://2cb6dfc9bd5bb499155ad4ed97e340195d01217a';
const autoAcceptAlerts = process.env.AUTO_ACCEPT_ALERTS || false;
const localExecution = process.env.LOCAL_EXECUTION || false;

const androidCapabilities = {
  'browserstack.user': process.env.BS_USER,
  'browserstack.key': process.env.BS_KEY,
  'browserstack.debug': debug,
  'browserstack.geoLocation': geo,
  'browserstack.timezone': process.env.BS_TIME_ZONE,
  'browserstack.networkLogs': true,
  autoAcceptAlerts,
  project,
  build,
  name,
  device,
  os_version: osVersion,
  app,
};

const localAndroidCapabilities = {
  deviceName: process.env.DEVICE_NAME,
  platformName: 'Android',
  appPackage: process.env.DTC_ANDROID_APP_PACKAGE,
  appActivity: process.env.APP_ACTIVITY,
  automationName: 'Appium',
  uiautomator2ServerInstallTimeout: '5000',
  noReset: false,
  allowInvisibleElements: true,
  chromeOptions: {
    w3c: false,
  },
  newCommandtimeout: '3600',
};

const desiredAndroidCapabilities =
  localExecution === 'true' ? localAndroidCapabilities : androidCapabilities;

module.exports = {
  desiredAndroidCapabilities,
};
