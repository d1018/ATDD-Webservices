const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;
let newProfileName;
let profileCountBeforeDeletion = 0;
let newProfileNameAfterEdited;
let newEditedProfileName;
let requiredProfileName;
let profileCheck;

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  manageProfiles_button = this.#getSelectorData('manageProfiles_button');

  manageProfiles_label = this.#getSelectorData('manageProfiles_label');

  listOfAllProfiles_text = this.#getSelectorData('listOfAllProfiles_text');

  addProfile_button = this.#getSelectorData('addProfile_button');

  createProfileName_text = this.#getSelectorData('createProfileName_text');

  save_button = this.#getSelectorData('save_button');

  mode_toggle = this.#getSelectorData('mode_toggle');

  deleteProfile_button = this.#getSelectorData('deleteProfile_button');

  delete_button = this.#getSelectorData('delete_button');

  dynamicProfileName_label = this.#getSelectorData('dynamicProfileName_label');

  profileName_label = this.#getSelectorData('profileName_label');

  profileError_label = this.#getSelectorData('profileError_label');

  profileCancel_button = this.#getSelectorData('profileCancel_button');

  ok_button = this.#getSelectorData('ok_button');

  whoIsWatching_label = this.#getSelectorData('whoIsWatching_label');

  myProfiles_tab = this.#getSelectorData('myProfiles_tab');

  editProfiles_button = this.#getSelectorData('editProfiles_button');

  cancel_button = this.#getSelectorData('cancel_button');

  done_button = this.#getSelectorData('done_button');

  profileIconsView_image = this.#getSelectorData('profileIconsView_image');

  appSettings_label = this.getElementByPage('menuPage', 'appSettings_label');

  /**
   * Below function is used to check whether a profile is already existing in the profiles section:
   * 1) Post login, it navigates to account section
   * 2) If profile is displayed, it returns value as true
   * 3) If profile is not displayed, then it returns the value as false
   *
   *@param {string} profileType name of the profile to be checked on the app
   * @returns {boolean} availability status of the profile
   */
  checkProfileIfExists = async (profileType) => {
    requiredProfileName = this.getCustomLocator(
      this.profileName_label,
      profileType,
    );
    const profileExists = await commons.elementExists(requiredProfileName, 5);

    return profileExists;
  };

  /**
   *  Below function is used to check select a profile with name profileNames available in the profiles section:
   * 1) If profile is displayed, then the profile will be selected
   * 2) After selecting profiles it navigates to the HomePage.
   *
   * @param {string} profileName as Default, kids and Standard.
   */

  selectProfile = async (profileName) => {
    if (!(await commons.elementExists(this.appSettings_label))) {
      await this.navigateToPage('My Profile');
      // await commons.click(this.myProfiles_tab);
    }

    if (profileName === 'any') {
      /* eslint-disable no-param-reassign */
      profileName = 'My Profile';
    }

    profileCheck = await this.checkProfileIfExists(profileName);

    const isProfileDisplayed = await this.swipeOnProfiles(
      profileName,
      'left',
      profileCheck,
    );

    if (!isProfileDisplayed) {
      await this.swipeOnProfiles(profileName, 'right', profileCheck);
    }

    requiredProfileName = this.getCustomLocator(
      this.profileName_label,
      profileName,
    );

    await commons.click(requiredProfileName);
    await commons.waitUntil(this.pageFocused.Home, 30);
  };

  swipeOnProfiles = async (profileName, direction, isProfileDisplayed) => {
    let i = 0;

    if (!isProfileDisplayed) {
      while (!profileCheck && i <= 3) {
        await commons.swipeOnElement(this.profileIconsView_image, direction, 5);
        profileCheck = await this.checkProfileIfExists(profileName);
        i++;
      }
    }
    return profileCheck;
  };

  /**
   * Below function is used to create a new profile and calls createnewprofile and selectProfile function
   *
   * @param {string} profileType as Standard, Kids.
   */
  profileCreation = async (profileType) => {
    if (profileType === 'Standard') {
      /* eslint-disable no-param-reassign */
      profileType = 'Base';
    }
    await this.createNewProfile(profileType);
    await this.selectProfile(newProfileName);
  };

  /**
   * Post login, the below function clicks on Account menu and waits till manage profiles button is visible
   */
  openManageProfiles = async () => {
    if (!(await commons.elementExists(this.manageProfiles_button))) {
      await this.navigateToPage('My Profile');
      // await commons.click(this.myProfiles_tab);
    }
    await commons.click(this.manageProfiles_button);
    await commons.waitUntil(this.editProfiles_button, 15);
  };

  /** Below function is used to verify the Profile Screen is visible or not */

  verifyProfileScreen = async () => {
    await commons.click(this.profile_button);
    assert(
      await commons.elementExists(this.myProfiles_tab),
      `Profile screen is not visible`,
    );
  };

  /**
   * Below function is used to verify whether the Add Profile is exist or not.
   *
   * return the result as true or false.
   */
  verifyAddProfile = async () => {
    const isAddProfileDisplayed = await commons.elementExists(
      this.addProfile_button,
      30,
    );

    return isAddProfileDisplayed;
  };

  /**
   * Below function is used to create a new profile and it works in following way:
   * 1) Post login, it opens manage profiles screen and checks if Add profile option is available
   * 2) If Add profile is displayed, it adds a new profile prefixing with Standard, Kids
   * 3) If Add profile is not displayed, then it deletes any random profile and creates new profile
   *
   * @param {string} profileType as Standard, Kids
   */
  createNewProfile = async (profileType) => {
    await this.openManageProfiles();
    const isAddProfileDisplayed = await this.verifyAddProfile();
    // get timestamp (in millseconds)

    newProfileName = profileType + Math.floor(Date.now() / 1000);
    if (!isAddProfileDisplayed) {
      // await this.deleteProfile('anyprofile');
      await commons.click(this.manageProfiles_button, 10);
      await commons.waitUntil(this.manageProfiles_label, 15);
    }

    if (await commons.elementExists(this.addProfile_button, 10)) {
      await commons.scrollToElement(this.addProfile_button, 'down');
      await commons.click(this.addProfile_button);
    }
    if (profileType.includes('Kids')) {
      await this.#toggleKidsProfile('ON');
    }
    await commons.sendText(this.createProfileName_text, newProfileName);
    await commons.click(this.save_button);
    await commons.click(this.done_button);
  };

  /**
   * Below function is used to click the toggle icon which is present only for Kids
   *
   * @param {string}toggleStatus as ON,OFF.
   */
  #toggleKidsProfile = async (toggleStatus) => {
    if (toggleStatus.includes('ON')) {
      await commons.waitUntil(this.mode_toggle, 10);
      await commons.click(this.mode_toggle);
    }
  };

  /**
   * Below function will
   * 1) After Selecting Profiles ,it navigates to manageProfile page.
   * 2) It will check the newly created profile is standard or kids.
   * 3) Click the newly Created profile to edit.
   *
   * @param {string} profileType as Kids,Standard.
   */
  moveToEdit = async (profileType) => {
    if (profileType.includes('Kids')) {
      await this.selectProfile('My Profile');
    }
    await this.openManageProfiles();
    const profileNameForEdit = this.getCustomLocator(
      this.profileName_label,
      newProfileName,
    );

    await commons.waitUntil(profileNameForEdit, 15);
    await commons.click(profileNameForEdit);
  };

  /**
   * Below function will
   * 1) Verify whether we are in edit profile page or not.
   * 2) Fetch the Profile Name before edit.
   * 3) Edit the name of the profile
   */
  editUserProfile = async () => {
    // await commons.waitUntil(this.deleteProfile_button);
    await commons.clearText(this.createProfileName_text);
    if (newProfileName.includes('Base')) {
      await commons.sendText(
        this.createProfileName_text,
        `Base${this.returnRandomNumber('5000')}`,
      );
    } else {
      await commons.sendText(
        this.createProfileName_text,
        `Kids${this.returnRandomNumber('5000')}`,
      );
    }
    newEditedProfileName = await commons.fetchAttributeData(
      this.createProfileName_text,
      'Text',
    );
    await commons.click(this.save_button);
    await commons.click(this.done_button);
  };

  /**
   * Below function will
   * 1) Get the edited Profile details.
   * 2) Fetch the Profile Name after edit.
   * 3) Check whether the two profile names are similar or different.
   */
  verifyEditedProfile = async () => {
    await commons.click(this.manageProfiles_button);
    newProfileNameAfterEdited = this.getCustomLocator(
      this.profileName_label,
      newEditedProfileName,
    );

    const expectedProfileNameAfterEdit = await commons.fetchAttributeData(
      newProfileNameAfterEdited,
      'Text',
    );

    assert(
      newProfileName !== expectedProfileNameAfterEdit,
      `Profile details not updated successfully because profile name before editing is ${newProfileName} and profile Name after editing is ${expectedProfileNameAfterEdit} `,
    );

    newProfileName = newEditedProfileName;
  };

  /**
   * Below function will
   * 1) Create a new Profile
   * 2) Select the newly created profile
   * 3) Move to the edit profiles page
   *
   * @param {string} profileType as Standard, Kids
   */
  createNewProfileAndMoveToEdit = async (profileType) => {
    await this.profileCreation(profileType);
    await this.moveToEdit(profileType);
  };

  /**
   *The below function
   *  will delete the Standard, Kids or any random profile.
   *
   */
  deleteExistingProfile = async () => {
    // await this.deleteProfile(newProfileName);
  };

  /**
   *This delete profile function will -
   * 1) Delete existing profile that starts with Standard, Kids and if not found, any random profile, except default will be deleted.
   * 2) Fetch count of all profiles
   * 3) If in Kids profile, it will switch to Default and then deletes created kids profile
   *
   * @param {string} profileName as Kids,Standard.
   */
  deleteProfile = async (profileName) => {
    let profileNames = [];

    if (!(await commons.elementExists(this.manageProfiles_button))) {
      if (profileName.includes('Kids')) {
        await this.selectProfile('My Profile');
      }
      await this.openManageProfiles();
    } else {
      await commons.click(this.manageProfiles_button);
    }

    profileNames = await this.getListOfProfiles();
    const arraySize = profileNames.length;

    if (profileNames.includes(profileName)) {
      requiredProfileName = this.getCustomLocator(
        this.profileName_label,
        profileName,
      );
      await commons.waitUntil(requiredProfileName, 5);
      await commons.click(requiredProfileName, 5);
      await commons.click(this.deleteProfile_button, 5);
      await commons.waitUntil(this.delete_button, 5);
      await commons.click(this.delete_button, 5);
      await this.verifyUserProfileDeleted();
    } else {
      for (let i = 0; i < arraySize; i++) {
        if (typeof profileNames[0] !== 'undefined') {
          requiredProfileName = this.getCustomLocator(
            this.profileName_label,
            profileNames[0],
          );

          await commons.waitUntil(requiredProfileName, 5);
          await commons.click(requiredProfileName, 5);
          await commons.click(this.deleteProfile_button, 5);
          await commons.waitUntil(this.delete_button, 5);
          await commons.click(this.delete_button, 5);
          if (await commons.elementExists(this.profileError_label, 5)) {
            await commons.click(this.ok_button, 5);
            await commons.click(this.profileCancel_button, 5);
          }

          if (await commons.elementExists(this.manageProfiles_button, 5)) {
            await commons.click(this.manageProfiles_button, 5);
          }

          profileNames = await this.getListOfProfiles();
          if (await commons.elementExists(this.profileError_label, 5)) {
            await commons.click(this.ok_button, 5);
            await commons.click(this.profileCancel_button, 5);
          }
        }
      }
      await this.verifyUserProfileDeleted();
    }
  };

  /**
   *Below function will -
   * 1) Fetch the count of profiles available to delete.
   * 2) Return the counts.
   */
  getListOfProfiles = async () => {
    let individualProfileName;
    const profileNames = [];
    const elements = await commons.findElements(
      this.listOfAllProfiles_text,
      10,
    );

    profileCountBeforeDeletion = await elements.length;
    for (let i = 0; i < profileCountBeforeDeletion; i++) {
      individualProfileName = await commons.fetchAttributeData(
        elements[i],
        'text',
      );
      let oldProfile = true;
      let existingProfileRandomTime;

      // Split the individualProfileName and then compare the timestamp.
      // if <10 minutes, then do not delete that profile, else mark that profile as old profile.
      if (
        !individualProfileName.includes('Default') &&
        individualProfileName !== 'Add Profile' &&
        individualProfileName !== 'My Profile'
      ) {
        existingProfileRandomTime = individualProfileName.match(/[a-z]+|\d+/gi);
        if (existingProfileRandomTime.length > 1) {
          if (
            Math.round(
              Math.abs(
                Date.now() / 1000 -
                  existingProfileRandomTime[
                    existingProfileRandomTime.length - 1
                  ],
              ) / 60,
            ) <= 10
          ) {
            oldProfile = false;
          }
        }
      }

      if (
        !individualProfileName.includes('Default') &&
        individualProfileName !== 'Add Profile' &&
        oldProfile &&
        individualProfileName !== 'My Profile'
      ) {
        profileNames.push(individualProfileName);
      }
      // For Oldprofile == false, we need to delete the newly created profile each time. Hence we need below condition
      if (individualProfileName === newProfileName) {
        profileNames.push(individualProfileName);
      }
    }
    return profileNames;
  };

  /**
   *This function will used to check the Profile deletion successful or not.
   */
  verifyUserProfileDeleted = async () => {
    assert(
      (await commons.elementExists(this.manageProfiles_label, 20)) ||
        (await commons.elementExists(this.whoIsWatching_label, 20)) ||
        (await commons.elementExists(this.manageProfiles_button, 20)),
      `Deletion of profiles is not successful`,
    );
  };

  verifyAddProfileButton = async () => {
    if (!(await commons.elementExists(this.focusedHomePage_label))) {
      await this.navigateToPage('Home');
    }
    await this.navigateToPage('My Profile');
    assert(
      !(await commons.elementExists(this.manageProfiles_button)),
      `Add profile button visible for Kids Profile`,
    );
  };
}

module.exports = ProfilePage;
