const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;
let notificationForDefaultProfile;
let notificationForStandardProfile;

class MemberFeedPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('memberFeedPage', locator);
  }

  bellIcon_img = this.#getSelectorData('bellIcon_img');

  newNotificationBadge_img = this.#getSelectorData('newNotificationBadge_img');

  notifications_lbl = this.#getSelectorData('notifications_lbl');

  edit_btn = this.#getSelectorData('edit_btn');

  showName_lbl = this.#getSelectorData('showName_lbl');

  showDescription_lbl = this.#getSelectorData('showDescription_lbl');

  watchNowOrResumeCTA_btn = this.#getSelectorData('watchNowOrResumeCTA_btn');

  addShowToMyListCTA_btn = this.#getSelectorData('addShowToMyListCTA_btn');

  assetContentDetails = [
    this.showName_lbl,
    this.showDescription_lbl,
    this.watchNowOrResumeCTA_btn,
    this.addShowToMyListCTA_btn,
  ];

  firstNotificationDescription_lbl = this.#getSelectorData(
    'firstNotificationDescription_lbl',
  );

  verifyNotificationBadge = async () => {
    assert(
      await commons.elementExists(this.newNotificationBadge_img),
      `No new notifications found`,
    );
  };

  viewNotifications = async (profileType) => {
    await commons.click(this.bellIcon_img);
    assert(
      await commons.elementExists(this.notifications_lbl),
      `Notifications screen is not displayed`,
    );

    if (profileType === 'Default') {
      notificationForDefaultProfile = await commons.fetchAttributeData(
        this.firstNotificationDescription_lbl,
        'text',
        10,
      );
    }
    if (profileType === 'Standard') {
      notificationForStandardProfile = await commons.fetchAttributeData(
        this.firstNotificationDescription_lbl,
        'text',
        10,
      );
    }
  };

  verifyNotificationsBetweenMultiProfiles = () => {
    assert(
      notificationForStandardProfile !== notificationForDefaultProfile,
      `Notifications in Default profile ${notificationForDefaultProfile} are same as the notifications in Standard profile ${notificationForStandardProfile} after switching profiles`,
    );
  };

  editNotifications = async () => {
    await commons.click(this.edit_btn);
  };

  verifyAssetContentDetails = async () => {
    for (let i = 0; i < this.assetContentDetails.length; i++) {
      await commons.waitUntil(this.assetContentDetails[i]);
    }
  };
}

module.exports = MemberFeedPage;
