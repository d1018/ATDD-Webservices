const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class NetworkLandingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('networkLandingPage', locator);
  }

  network_image = this.getElementByPage('homePage', 'network_image');

  networkRail_label = this.getElementByPage('homePage', 'networkRail_label');

  featuredRail_label = this.#getSelectorData('featuredRail_label');

  recommendedForYou_label = this.#getSelectorData('recommendedForYou_label');

  networkLogo_image = this.#getSelectorData('networkLogo_image');

  liveRail_label = this.getElementByPage('sportsContentPage', 'liveRail_label');

  upcomingRail_label = this.getElementByPage(
    'sportsContentPage',
    'upcomingRail_label',
  );

  euroSports1Network_text = this.getElementByPage(
    'sportsContentPage',
    'euroSports1Network_text',
  );

  discoveryNetwork_text = this.getElementByPage(
    'homePage',
    'discoveryNetwork_text',
  );

  featuredShowName_image = this.#getSelectorData('featuredShowName_image');

  play_button = this.#getSelectorData('play_button');

  showRail_label = this.#getSelectorData('showRail_label');

  episodeRail_label = this.#getSelectorData('episodeRail_label');

  entertainmentnetworkLandingPage = [
    this.showRail_label,
    this.recommendedForYou_label,
    this.episodeRail_label,
    this.networkRail_label,
  ];

  networkLandingCTA = [
    this.featuredShowName_image,
    this.play_button,
    this.networkLogo_image,
  ];

  /**
   * The below function will validate discovery network channel
   *
   * @returns {boolean} will return true or false
   */
  isEntertainmentNetworkDisplayed = async () => {
    const result = await commons.elementExists(this.discoveryNetwork_text, 5);

    return result;
  };

  /**
   * The below function will select and  validate the Entertainment Network Landing Page
   */
  validateEntertainmentNetworkLandingPage = async () => {
    const networkRail = await commons.findElements(this.networkRail_label);
    let count = 0;

    while (!(await this.isEntertainmentNetworkDisplayed()) && count <= 5) {
      await commons.swipeOnElement(networkRail[1], 'left', 5);
      count++;
      if (await this.isEntertainmentNetworkDisplayed()) {
        break;
      }
    }
    await commons.click(this.discoveryNetwork_text);
    await commons.waitUntil(this.networkLogo_image);
    count = 1;
    let displayedCount = 0;

    for (let i = 0; i < this.entertainmentnetworkLandingPage.length; i++) {
      while (
        count <= 10 &&
        !(await commons.elementExists(
          this.entertainmentnetworkLandingPage[i],
          5,
        ))
      ) {
        await commons.scrollOnPageByPercentage('down', '50%');
        count++;
      }
      if (
        await commons.elementExists(this.entertainmentnetworkLandingPage[i], 5)
      ) {
        ++displayedCount;
      }
    }
    assert(
      displayedCount === 4,
      `Few of the entertainment network rails are not displayed`,
    );
    await commons.click(this.networkLandingCTA[0]);
    await this.verifyNetworkLandingCTA();
  };

  verifyNetworkLandingCTA = async () => {
    for (let i = 1; i < this.networkLandingCTA.length; i++) {
      await commons.waitUntil(this.networkLandingCTA[i]);
    }
  };

  /**
   * The below function will validate sports network channel
   *
   * @returns {boolean} will return true or false
   */
  isSportsNetworkDisplayed = async () => {
    const result = await commons.elementExists(this.euroSports1Network_txt, 5);

    return result;
  };

  /**
   * The below function will validate the sports Network Landing Page
   */
  validateSportsNetworkLandingPage = async () => {
    const networkRail = await commons.findElements(this.networkRail_label);

    while (!(await this.isSportsNetworkDisplayed())) {
      await commons.swipeOnElement(networkRail[1], 'left', 5);
      if (await this.isSportsNetworkDisplayed()) {
        await commons.click(this.euroSports1Network_text);
        break;
      }
    }
    await commons.waitUntil(this.networkLogo_image);
    await commons.scrollOnPage('down');
    if (await commons.elementExists(this.liveRail_label)) {
      await commons.waitUntil(this.liveRail_label, 10);
    }
    await commons.waitUntil(this.upcomingRail_label, 10);
    await this.verifyNetworkLandingCTA();
  };

  /**
   * The below function will switch on Entertainment and Sports network channel
   *
   * @param {*} network will select Entertainment and Sports Network
   */
  selectAndValidateNetworkLandingPage = async (network) => {
    if (network === 'Entertainment') {
      await this.validateEntertainmentNetworkLandingPage();
    } else if (network === 'Sports') {
      await this.validateSportsNetworkLandingPage();
    }
  };

  /**
   * The below function will validate Network Rail
   *
   * @returns {boolean} will return true or false
   */
  isNetworkRailDisplayed = async () => {
    const result = await commons.elementExists(this.network_img, 2);

    return result;
  };
}

module.exports = NetworkLandingPage;
