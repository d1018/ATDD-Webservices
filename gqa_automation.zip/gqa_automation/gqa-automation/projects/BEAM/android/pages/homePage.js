const assert = require('assert');
const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const SearchPage = require('./searchPage');
const MyStuffPage = require('./myStuffPage');

const commons = mobileActions;
let myListShowName;

const searchPage = new SearchPage();
const myStuffPage = new MyStuffPage();

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  signOut_button = this.#getSelectorData('signOut_button');

  confirmSignOut_btn = this.#getSelectorData('confirmSignOut_btn');

  focusedHomePage_label = this.#getSelectorData('focusedHomePage_label');

  focusedSearchPage_label = this.getElementByPage(
    'searchPage',
    'focusedSearchPage_label',
  );

  immersiveHeroBadge_icon = this.#getSelectorData('immersiveHeroBadge_icon');

  ratingInformation_label = this.#getSelectorData('ratingInformation_label');

  rail_tile = this.#getSelectorData('rail_tile');

  episodes_button = this.#getSelectorData('episodes_button');

  clearSearch_button = this.#getSelectorData('clearSearch_button');

  showName_label = this.#getSelectorData('showName_label');

  myListTile_title = this.getElementByPage('myStuffPage', 'myListTile_title');

  network_image = this.#getSelectorData('network_image');

  seasons_label = this.getElementByPage('seriesPage', 'seasons_label');

  navigateToHome = async () => {
    await this.navigateToPage('Home');
  };

  /**
   * verify Show is present in the My List rail
   *
   * @param {displayTrue} displayTrue as true
   */
  verifyMyListRailContentRemoved = async (displayTrue) => {
    const listOfItems = await this.getTheShowNamesInRail('My List');

    for (let i = 0; i < listOfItems.length; i++) {
      if (listOfItems[i] === myListShowName && displayTrue === true) {
        break;
      }
    }
  };

  /**
   * The below function will validate Network rail
   */
  validateNetworkRail = async () => {
    await commons.waitUntil(this.network_image);
  };

  /**
   * verify MyList Rail is present in home page. Compare the MyList Tiles.
   *
   * @param {string}  availability as true and false.
   */
  verifyMyListRailOnHomePage = async (availability) => {
    if (availability) {
      await this.navigateToPage('Home');
      const showNameDisplayedInMyListRail = await this.getTheShowNamesInRail(
        'My List',
      );
      const showNameAddedToMyList = await myStuffPage.addedShowName();

      assert(
        showNameAddedToMyList === showNameDisplayedInMyListRail.toString(),
        `Show name added to MyList is ${showNameAddedToMyList} is not matched with Show name in MyList Rail in Home page ${showNameDisplayedInMyListRail.toString()}`,
      );
    }
  };

  signOut = async () => {
    await this.navigateToPage('My Profile');
    if (!(await commons.elementExists(this.signOut_button))) {
      await this.navigateToPage('My Profile');
    }
    await commons.click(this.signOut_button);
    await commons.click(this.confirmSignOut_btn);
  };

  verifyKidsContent = async (screens) => {
    if (screens === 'Home page') {
      await this.navigateToPage('Home');
      await commons.waitUntil(this.immersiveHeroBadge_icon);
      const currentRating = await commons.fetchAttributeData(
        this.ratingInformation_label,
        'text',
        10,
      );

      assert(
        testdataHelper.getContent('ratingList').includes(currentRating),
        `Rating is not as per rating standards`,
      );
    } else if (screens === 'Show Details Page') {
      await commons.click(this.rail_tile);
      await commons.waitUntil(this.episodes_button);
      const currentRating = await commons.fetchAttributeData(
        this.ratingInformation_label,
        'text',
        10,
      );

      assert(
        testdataHelper.getContent('ratingList').includes(currentRating),
        `Rating is not as per rating standards`,
      );
      await commons.clickBack();
    } else {
      await this.navigateToPage('Search');
      const isKidsContentDisplayed = await this.searchContent('kids');

      assert(
        isKidsContentDisplayed,
        `Kids content is not shown on the kids search screen`,
      );
      const isAdultContentDisplayed = await this.searchContent('adult');

      assert(
        !isAdultContentDisplayed,
        `A rated content is shown on the kids search screen`,
      );
    }
  };

  searchContent = async (contentType) => {
    let isContentDisplayed = true;

    if (await commons.elementExists(this.clearSearch_button)) {
      await commons.click(this.clearSearch_button);
    }
    if (contentType === 'adult') {
      const adultContent = testdataHelper.getContent(
        `searchPage.adultShowName`,
      );

      await commons.sendText(this.focusedSearchPage_label, adultContent);
      const adultShow = this.getCustomLocator(
        this.showName_label,
        adultContent,
      );

      isContentDisplayed = await commons.elementExists(adultShow, 10);
    } else if (contentType === 'kids') {
      const kidsContent = testdataHelper.getContent(`searchPage.kidsShowName`);

      await commons.sendText(this.focusedSearchPage_label, kidsContent);
      const kidsShow = this.getCustomLocator(this.showName_label, kidsContent);

      isContentDisplayed = await commons.elementExists(kidsShow, 10);
    }
    return isContentDisplayed;
  };

  /**
   * This function will validate ageRating and Content on multiple Screens
   */

  verifyAgeRatingAndContentDescriptors = async (screensType) => {
    switch (screensType) {
      case 'Main Hero':
        break;

      case 'Show Details Page':
        await this.navigateToPage('Search');
        await searchPage.searchText('multiContentShow');
        await searchPage.clickOnSearchResultsImage('multiContentShow');
        break;

      case 'Currently Playing Episode':
        await commons.click(this.startWatching_btn);
        break;

      case 'Next Episodes listed on Episode Landing Page':
        assert(
          await commons.elementExists(this.nextEpisodeRating),
          `Rating for the Next Episode is not displayed`,
        );
        commons.clickBack();
        break;

      case 'Episode Info Panel':
        await commons.click(this.startWatching_btn);
        break;

      default:
        throw new Error(
          'Actual screenType provided is not as per the expectations',
        );
    }

    if (screensType !== 'Next Episodes listed on Episode Landing Page') {
      assert(
        await commons.elementExists(this.rating, 30),
        `Rating for the show is not displayed`,
      );

      const currentRating = await commons.fetchAttributeData(
        this.rating,
        'text',
        10,
      );

      assert(
        testdataHelper.getContent('ratingList').includes(currentRating),
        `Rating is not as per rating standards`,
      );
    }
  };

  /**
   * This function will validate RecommendedForYou Rail for Movies and Series
   *
   * @param {string}  assetType is Movies and Series.
   */
  verifyRecommendedForYou = async (assetType) => {
    const listOfItems = await this.getTheShowNamesInRail('Recommended For You');

    await commons.click(listOfItems[0]);

    if (assetType === 'Movie') {
      assert(
        !(await commons.elementExists(this.seasons_label, 10)),
        `Movie Genre is not recommended`,
      );
    } else {
      assert(
        await commons.elementExists(this.seasons_label, 10),
        `Series Genre is not recommended`,
      );
    }
  };
}
module.exports = HomePage;
