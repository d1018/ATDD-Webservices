const assert = require('assert');
const SearchPage = require('./searchPage');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

const searchPage = new SearchPage();
let playerPositionAfter;
let currentPlayerTime;

class VideoPlayerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('videoPlayerPage', locator);
  }

  videoContainerView = this.#getSelectorData('videoContainerView');

  playPause_button = this.#getSelectorData('playPause_button');

  back_button = this.#getSelectorData('back_button');

  asset_title = this.#getSelectorData('asset_title');

  skipBack_button = this.#getSelectorData('skipBack_button');

  skipForward_button = this.#getSelectorData('skipForward_button');

  playerPlay_button = this.#getSelectorData('playerPlay_button');

  fullscreen_button = this.#getSelectorData('fullscreen_button');

  watch_button = this.#getSelectorData('watch_button');

  resume_button = this.#getSelectorData('resume_button');

  playerContainer_img = this.#getSelectorData('playerContainer_img');

  playerProgress_bar = this.#getSelectorData('playerProgress_bar');

  ad_label = this.#getSelectorData('ad_label');

  ad_countdown = this.#getSelectorData('ad_countdown');

  contentRatingTitle_lbl = this.#getSelectorData('contentRatingTitle_lbl');

  cc_button = this.#getSelectorData('cc_button');

  moreEpisodes_label = this.#getSelectorData('moreEpisodes_label');

  player_title = this.#getSelectorData('player_title');

  /**
   * The below function will validate the player screen once the video will start playing.
   */
  /* commented few lines of code since locators not available */
  isVideoPlaying = async () => {
    await commons.waitUntil(this.videoContainerView, 60);
    if (!(await commons.elementExists(this.skipForward_button))) {
      await commons.click(this.videoContainerView);
    }
    // await commons.waitUntil(this.asset_title, 30);
    // await commons.waitUntil(this.fullscreen_button, 30);
    await commons.waitUntil(this.skipForward_button, 30);
  };

  /**
   * The below function will play the video and validate the watch now CTA
   */
  playShow = async () => {
    if (await commons.elementExists(this.watch_button)) {
      await commons.click(this.watch_button, 20);
    } else {
      await commons.click(this.resume_button, 20);
    }
  };

  videoPlayerControls = {
    Pause: this.playPause_button,
    Resume: this.playerPlay_button,
    FFD: this.skipForward_button,
    RWD: this.skipBack_button,
  };

  adStreamElements = {
    'Play Button': this.playerPlay_button,
    'Pause Button': this.playPause_button,
    'Ad counter': this.ad_countdown,
    'FullScreen Button': this.fullscreen_button,
  };

  videoPlayerPosition = async () => {
    await commons.elementExists(this.playerContainer_img, 20);
    await commons.click(this.videoContainerView, 50);
    await commons.waitUntil(this.playerProgress_bar);
    const currentPlayerPosition = await commons.fetchAttributeData(
      this.playerProgress_bar,
      'Content-Desc',
    );

    return currentPlayerPosition;
  };

  // Function to find the time difference
  getTimeInSeconds = (str) => {
    let currTime = [];

    currTime = str.split(':');
    /* eslint-disable radix */
    for (let i = 0; i < currTime.length; i++) {
      currTime[i] = parseInt(currTime[i]);
    }

    const t = currTime[0] * 60 + currTime[1];

    return t;
  };

  // Function to convert seconds back to mm:ss
  convertSecToTime = (t) => {
    const min = Math.floor((t % 3600) / 60);
    const mm = min < 10 ? `0${min.toString()}` : min.toString();
    const sec = (t % 3600) % 60;
    const ss = sec < 10 ? `0${sec.toString()}` : sec.toString();
    const ans = `${mm}:${ss}`;

    return ans;
  };

  // Function to find the time gap
  timeGap = (st, et) => {
    const t1 = this.getTimeInSeconds(st);
    const t2 = this.getTimeInSeconds(et);
    const timeDiff = t1 - t2 < 0 ? t2 - t1 : t1 - t2;
    let diff = this.convertSecToTime(timeDiff);

    diff = diff.split(':');
    return diff[1];
  };

  /**
   * This function will validate video player actions like Pause, Resume, FFD and RWD
   *
   * @param {string} actions specifies player actions
   */
  verifyVideoActions = async (actions) => {
    if (!(await commons.elementExists(this.back_button))) {
      await commons.click(this.videoContainerView, 50);
    }
    if (actions === 'FFD' || actions === 'RWD') {
      currentPlayerTime = await this.videoPlayerPosition();
      await commons.elementExists(this.videoPlayerControls[actions]);
      await commons.click(this.videoPlayerControls[actions]);
      playerPositionAfter = await this.videoPlayerPosition();
      const timeGapbetweenPlayerBar = this.timeGap(
        currentPlayerTime,
        playerPositionAfter,
      );
      /* eslint-disable radix */

      assert(
        parseInt(timeGapbetweenPlayerBar) === 10,
        `Player action on video is not successful as the player position ${currentPlayerTime} is less than after position ${playerPositionAfter}`,
      );
    } else {
      await commons.elementExists(this.videoPlayerControls[actions]);
      await commons.click(this.videoPlayerControls[actions]);
    }
  };

  /**
   *
   * @param {*} percentageValue seeks the player from 00:00 to % of seek bar length. This function scrolls to coordinates by taking inputs as startX, startY, endX & endY positions.
   */
  scrub_video = async (percentageValue) => {
    let endXPosition;

    if (!(await commons.elementExists(this.skipForward_button, 7))) {
      await commons.click(this.videoContainerView);
    }
    const progressBarLocation = await commons.getElementLocation(
      this.playerProgress_bar,
      5,
    );

    if (!(await commons.elementExists(this.skipForward_button, 8))) {
      await commons.click(this.videoContainerView);
    }
    const progressBarDimensions = await commons.getElementSize(
      this.playerProgress_bar,
      5,
    );
    const startXPosition = progressBarLocation.startXValue;

    if (percentageValue < '98') {
      endXPosition =
        startXPosition + percentageValue * 0.01 * progressBarDimensions.width;
    } else {
      endXPosition =
        startXPosition +
        percentageValue * 0.01 * progressBarDimensions.width -
        7;
    }
    const startYPosition =
      progressBarLocation.startYValue + progressBarDimensions.height / 2;
    const endYPosition = startYPosition;

    if (!(await commons.elementExists(this.skipForward_button, 6))) {
      await commons.click(this.videoContainerView);
    }

    await commons.scrollByCoordinates(
      startXPosition,
      startYPosition,
      endXPosition,
      endYPosition,
    );

    if (!(await commons.elementExists(this.signIn_button, 6))) {
      await commons.click(this.videoContainerView);
    }
  };

  scrubBack = async () => {
    await this.scrub_video(1);
  };

  adPlaying = async () => {
    assert(
      (await commons.elementExists(this.ad_label, 30)) &&
        (await commons.elementExists(this.ad_countdown, 30)),
      'Ad not played',
    );
  };

  playAdFull = async () => {
    await commons.waitUntil(this.contentRatingTitle_lbl, 120);
    assert(
      await commons.isDisplayed(this.contentRatingTitle_lbl, 120),
      `Ad not played entirely`,
    );
  };

  navigateAndPlay = async (showType) => {
    await this.navigateToPage('Search');
    await searchPage.searchShow(showType);
    await searchPage.selectShow();
    // await this.playShow();
    await this.isVideoPlaying();
  };

  verifyAdPlayBack = async () => {
    await this.scrubBack();
    await this.scrub_video(90);
    await this.adPlaying();
  };

  verifyCC = async () => {
    assert(
      !(await commons.elementExists(this.cc_button, 10)),
      'CC button displayed',
    );
    await this.playAdFull();
  };

  verifyAdPods = async () => {};

  /**
   * This function will switch the video player to fullscreen
   *
   * @param {string} orientation specifies player mode fullscreen, landscape
   */
  /* commented this function since by default video is playing in landscape mode */
  switchToOrientation = async (orientation) => {
    if (orientation === 'landscape' || orientation === 'fullscreen') {
      if (await commons.elementExists(this.moreEpisodes_label, 1)) {
        // await commons.waitUntil(this.fullscreen_button, 30);
        // await commons.click(this.fullscreen_button, 50);
      }
    }
  };

  /**
   * This function used to check the video played in landscape
   *
   * @param {string} mode specifies video play mode as landscape
   */
  verifyVideoOrientation = async (mode) => {
    if (mode === 'landscape' || mode === 'fullscreen') {
      const videoSizeInLandscape = await commons.getElementSize(
        this.videoContainerView,
        5,
      );
      const videoHeightInLandscape = videoSizeInLandscape.height;
      const windowSize = await commons.getwindowSize();
      const deviceHeight = windowSize.height;

      assert(
        deviceHeight - videoHeightInLandscape <= 100,
        `The video is not playing in ${mode} as the video size in landscape is ${videoHeightInLandscape} and the devices height is ${deviceHeight}`,
      );
    }
  };

  /** This function used to validate AdPlay and PlayerProgressbar during AdPlay */

  verifyProgressBar = async () => {
    await this.verifyAdPlayBack();
    assert(
      !(await commons.elementExists(this.playerProgress_bar, 10)),
      'ProgressBar is displayed',
    );
  };

  /**
   * This function will validate elements like play,pause,AdCounter and FullScreen
   *
   * @param {string} element specifies elements present during Adplay
   */
  verifyAdStreamElements = async (element) => {
    if (!(await commons.elementExists(this.back_button, 10))) {
      await commons.click(this.videoContainerView, 10);
    }
    if (element === 'FullScreen Button') {
      await commons.waitUntil(this.adStreamElements[element]);
      await commons.click(this.videoContainerView, 10);
      await this.playAdFull();
    } else {
      await commons.click(this.videoContainerView, 10);
      await commons.waitUntil(this.adStreamElements[element], 10);
    }
  };
}
module.exports = VideoPlayerPage;
