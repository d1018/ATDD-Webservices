const assert = require('assert');
const { BasePage, mobileActions, testdataHelper } = require('./basePage');

const commons = mobileActions;
let searchBarDefaultTextLabel;

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  focusedSearchPage_label = this.#getSelectorData('focusedSearchPage_label');

  searchBar_field = this.#getSelectorData('searchBar_field');

  showName_lbl = this.#getSelectorData('showName_lbl');

  search_button = this.#getSelectorData('search_button');

  showTitle_label = this.#getSelectorData('showTitle_label');

  showImage_image = this.#getSelectorData('showImage_image');

  search_icon = this.#getSelectorData('search_icon');

  showNetworkIcon_image = this.#getSelectorData('showNetworkIcon_image');

  showName_label = this.#getSelectorData('showName_label');

  selectShow = async () => {
    await commons.waitUntil(this.showName_lbl);
    await commons.click(this.showName_lbl);
  };

  /**
   * This search method will be used when we have show name available
   *
   * @param {string} showType specifies the show to be searched
   */
  searchShow = async (showType) => {
    const requiredShowName =
      showType.charAt(0).toLowerCase() + showType.slice(1);

    const showName = testdataHelper.getContent(
      `searchPage.${requiredShowName}`,
    );

    await commons.sendText(this.searchBar_field, showName);
    await commons.click(this.search_icon);
    return showName;
  };

  /**
   * Below function is used to search for content from the search screen
   *
   */

  enterSearchQuery = async (searchQuery) => {
    searchBarDefaultTextLabel = await commons.fetchAttributeData(
      this.searchBar_field,
      'Text',
    );
    const showName = testdataHelper.getContent(`searchPage.${searchQuery}`);

    await commons.sendText(this.searchBar_field, showName);
    await commons.click(this.search_icon);
  };

  verifySearchQuery = async (searchQuery) => {
    const showName = await testdataHelper.getContent(
      `searchPage.${searchQuery}`,
    );

    assert(
      searchBarDefaultTextLabel !== showName,
      'Search query is not replaced',
    );

    await commons.click(this.search_icon);
  };

  verifySearchResult = async (searchQuery) => {
    const showName = await testdataHelper.getContent(
      `searchPage.${searchQuery}`,
    );
    const searchResult = await this.getCustomLocator(
      this.showName_label,
      showName,
    );

    assert(
      await commons.elementExists(searchResult, 50),
      'Search Result not found',
    );
  };
}

module.exports = SearchPage;
