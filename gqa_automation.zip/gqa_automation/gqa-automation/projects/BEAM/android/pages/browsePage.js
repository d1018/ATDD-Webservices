const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;
let showName;

class BrowsePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('browsePage', locator);
  }

  focusedNetwork_label = this.#getSelectorData('focusedNetwork_label');

  focusedSubNav_label = this.#getSelectorData('focusedSubNav_label');

  networkLogoRail_image = this.#getSelectorData('networkLogoRail_image');

  showName_label = this.#getSelectorData('showName_label');

  subNav_label = this.#getSelectorData('subNav_label');

  networkIcon_image = this.#getSelectorData('networkIcon_image');

  networkImage = this.#getSelectorData('networkImage');

  showCard_image = this.#getSelectorData('showCard_image');

  watchNow_button = this.getElementByPage('videoPlayerPage', 'watch_button');

  listIcon_button = this.getElementByPage('homePage', 'listIcon_button');

  verifyBrowsePage = async () => {
    await commons.waitUntil(this.focusedNetwork_label);
    assert(
      (await commons.fetchAttributeData(
        this.focusedNetwork_label,
        'selected',
      )) &&
        (await commons.fetchAttributeData(
          this.focusedSubNav_label,
          'selected',
        )),
      'All and Trending subNav are not slected by default',
    );
    showName = await commons.fetchAttributeData(this.showName_label, 'text');
  };

  /**
   * The below function will select a network from the network rail in browse page
   *
   * @param {string} networkType will select a network
   */
  selectNetwork = async (networkType) => {
    if (networkType === 'any') {
      await commons.waitUntil(this.networkLogoRail_image);
      await commons.click(this.networkLogoRail_image);
      assert(
        await commons.fetchAttributeData(
          this.networkLogoRail_image,
          'selected',
        ),
        'Network is not selected',
      );
    }
  };

  /**
   * The below function will verify show on selected network
   */
  verifyShowOnSelectedNetwork = async () => {
    await commons.waitUntil(this.showName_label, 15);
    const actualShowName = await commons.fetchAttributeData(
      this.showName_label,
      'text',
    );

    assert.notEqual(
      showName,
      actualShowName,
      'Show not available on selected Network',
    );
  };

  /**
   * The below function will select a subNavigation menu item and validate the title , image and networkIcon are displayed
   *
   * @param {string} subNav will select subNav menu item
   */
  selectSubNav = async (subNav) => {
    if (subNav === 'any') {
      await commons.click(this.subNav_label);
      const subNavElements = [
        this.showName_label,
        this.networkIcon_image,
        this.networkImage,
      ];

      for (let i = 0; i < subNavElements.length; i++) {
        await commons.waitUntil(subNavElements[i]);
      }
    }
  };

  /**
   * The below function will open a show from Browse page and validate the CTAs
   */
  verifyShowCard = async () => {
    await commons.waitUntil(this.showCard_image);
    await commons.click(this.showCard_image);
    assert(
      (await commons.elementExists(this.watchNow_button)) &&
        (await commons.elementExists(this.listIcon_button)),
      'Watch Now button and Add to List Icon are not present',
    );
  };
}
module.exports = BrowsePage;
