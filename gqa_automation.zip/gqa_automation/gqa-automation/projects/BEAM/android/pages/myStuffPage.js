const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');
const SearchPage = require('./searchPage');

const commons = mobileActions;
const searchPage = new SearchPage();
let myListShowName;
let showInMyList;
let addedShowName;

class MyStuffPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myStuffPage', locator);
  }

  myList_tab = this.#getSelectorData('myList_tab');

  myListTile_title = this.#getSelectorData('myListTile_title');

  recentlyAdded_dropdown = this.#getSelectorData('recentlyAdded_dropdown');

  noSavedTitles_title = this.#getSelectorData('noSavedTitles_title');

  edit_btn = this.#getSelectorData('edit_btn');

  myListItem_kebab = this.#getSelectorData('myListItem_kebab');

  remove_btn = this.#getSelectorData('remove_btn');

  myListItem_image = this.#getSelectorData('myListItem_image');

  showName_label = this.getElementByPage('homePage', 'showName_label');

  verifyMyListAsset = async () => {
    assert(
      (await commons.elementExists(this.edit_btn)) &&
        (await commons.elementExists(this.recentlyAdded_dropdown)),
      `Items are not added to My List `,
    );
  };

  navigateToMyListTab = async () => {
    await this.navigateToPage('My Stuff');
    await commons.click(this.myList_tab, 20);
  };

  removeMyListContent = async () => {
    myListShowName = await commons.fetchAttributeData(
      this.myListItem_image,
      'text',
      10,
    );
    await commons.click(this.myListItem_kebab, 20);
    await commons.click(this.remove_Btn, 20);
  };

  verifyMyListTabContentRemoved = async () => {
    assert(
      (await commons.fetchAttributeData(this.myListItem_image, 'text', 10)) ===
        myListShowName,
      `My List item is not removed`,
    );
  };

  invokeAsset = async () => {};

  verifyInfoModal = async () => {};

  verifyInfoModalElement = async () => {};

  /**
   * Select the MyList Tab in MyStuff page
   */
  selectMyList = async () => {
    await commons.click(this.myList_tab, 20);
  };

  /**
   * This function used to verify the MyList Content Before adding anything to MyList.
   */
  verifyMyListContent = async () => {
    assert(
      await commons.elementExists(this.noSavedTitles_title),
      `No saved title is not visible`,
    );
  };

  /**
   * This function used to verify the MyList Content After adding and
   * fetch the added showName and compare that with the Mylist details from Mystuff page.
   *
   *  @param {string} availability as true and false.
   */
  verifyMyListData = async (availability) => {
    if (availability) {
      await this.navigateToPage('My Stuff');
      await this.selectMyList();
      addedShowName = await this.addedShowName();
      const exepectedShowName = await this.getCustomLocator(
        this.showName_label,
        addedShowName,
      );

      showInMyList = await commons.fetchAttributeData(
        exepectedShowName,
        'text',
        10,
      );
      assert(
        addedShowName === showInMyList,
        `Show name ${addedShowName} displayed in My List screen is not matched with the Show name ${showInMyList} that is via added to my list CTA`,
      );
    }
  };

  /**
   * This function used to add a show to the MyList from HomePage.
   */
  addShowsToMylist = async () => {
    await this.navigateToPage('Search');
    addedShowName = await searchPage.searchShow('showName1');
    await commons.waitUntil(this.showName_lbl);
    await commons.click(this.infoModal_button);
    await commons.waitUntil(this.infoModalAddToMyList_button, 60);
    await commons.click(this.infoModalAddToMyList_button);
  };

  /**
   * Returns added show name to My List
   */

  addedShowName = () => addedShowName;
}

module.exports = MyStuffPage;
