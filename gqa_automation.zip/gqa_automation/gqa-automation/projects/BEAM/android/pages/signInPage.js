const assert = require('assert');
let { desiredAndroidCapabilities } = require('../capabilities/bsCaps');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

const serverURL = process.env.SERVER_URL
  ? process.env.SERVER_URL.toLowerCase()
  : '';

const localExecution = process.env.LOCAL_EXECUTION === 'true' || false;

/**
 *
 * @param {number} min must be minimal integer range as per .env test accounts
 * @param {number} max must be maximum integer range as per .env test accounts
 * @returns {number} random number between min & max range
 */
function randomIntFromInterval(min, max) {
  // min and max included
  return Math.floor(Math.random() * (max - min + 1) + min);
}

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  signIn_button = this.getElementByPage('welcomePage', 'signIn_button');

  beamSignIn_button = this.getElementByPage('welcomePage', 'beamSignIn_button');

  welcomeToBeam_label = this.getElementByPage(
    'welcomePage',
    'welcomeToBeam_label',
  );

  continue_button = this.#getSelectorData('continue_button');

  login_textbox = this.#getSelectorData('login_textbox');

  password_textbox = this.#getSelectorData('password_textbox');

  subscribe_button = this.getElementByPage('welcomePage', 'subscribe_button');

  playStoreCaps = {
    'browserstack.appStoreConfiguration': {
      username: process.env.PLAYSTORE_ACCOUNT_EMAIL,
      password: process.env.PLAYSTORE_ACCOUNT_PASSWORD,
    },
  };

  async openApp() {
    await commons.driverInit(serverURL, localExecution);

    if (await this.isCucumberTagPresent('@IAP')) {
      desiredAndroidCapabilities = Object.assign(
        desiredAndroidCapabilities,
        this.playStoreCaps,
      );
    }
    await commons.openApp(desiredAndroidCapabilities);
  }

  loginToApplication = async (userType) => {
    if (!userType.includes('anonymous')) {
      await this.#accessSignInScreen();
      await this.enterCredentials(userType);
    }
  };

  async #accessSignInScreen() {
    await commons.click(this.signIn_button);
    await commons.click(this.signIn_button);
    if (await commons.elementExists(this.beamSignIn_button)) {
      await commons.click(this.beamSignIn_button);
    }
    await commons.elementExists(this.login_textbox, 20);
  }

  async getCreds(credentialType) {
    let creds;

    const featureName = await this.getFeatureName();
    // const scenarioName =
    //   FeatureName.gherkinDocument.feature.children[1].scenario.name;

    if (featureName === 'Member Feed') {
      creds = `${credentialType}${randomIntFromInterval(1, 3)}`;
    } else if (featureName === 'Account Page') {
      creds = `${credentialType}${randomIntFromInterval(1, 3)}`;
    } else if (featureName === 'User Profiles Functionality') {
      creds = `${credentialType}${randomIntFromInterval(1, 3)}`;
    } else if (featureName === 'Video Playback') {
      creds = `${credentialType}${randomIntFromInterval(1, 3)}`;
    } else if (featureName === 'Onboarding, Registration and Sign in') {
      creds = `${credentialType}${randomIntFromInterval(1, 3)}`;
    } else if (featureName === 'Search') {
      creds = `${credentialType}${randomIntFromInterval(1, 3)}`;
    } else if (featureName === 'Age Ratings & Content Descriptors') {
      creds = `${credentialType}${randomIntFromInterval(1, 3)}`;
    } else if (featureName === 'My List') {
      creds = `${credentialType}${randomIntFromInterval(1, 3)}`;
    } else if (featureName === 'Global Navigation') {
      creds = `${credentialType}${randomIntFromInterval(1, 3)}`;
    } else {
      creds = credentialType;
    }
    return creds;
  }

  verifySignOut = async () => {
    assert(
      (await commons.elementExists(this.subscribe_button, 30)) &&
        (await commons.elementExists(this.signIn_button, 30)),
      `Sign out is not successful`,
    );
  };

  async enterCredentials(credentialType) {
    const cred = await this.getCreds(credentialType);
    const username = process.env[`${cred}_USERNAME`];
    const password = process.env[`${cred}_PASSWORD`];

    await commons.sendText(this.login_textbox, username);
    await commons.sendText(this.password_textbox, password);
    await commons.click(this.continue_button);
  }

  /**
   * For IAP related scenarios,playstore credentials are needed to see the Plan picker screen.
   * This method will close the existing session and relaunch the app by passing the playstore creds through cababilities.
   */
  async reOpenApp() {
    desiredAndroidCapabilities['browserstack.appStoreConfiguration'] = {
      username: process.env.PLAYSTORE_ACCOUNT_EMAIL,
      password: process.env.PLAYSTORE_ACCOUNT_PASSWORD,
    };
    const capability = {
      android: desiredAndroidCapabilities,
    }.android;

    await commons.closeApp();
    await commons.openApp(capability);
  }
}
module.exports = SignInPage;
