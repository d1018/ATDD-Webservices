const SignInPage = require('./signInPage');
const MemberFeedPage = require('./memberFeedPage');
const MyStuffPage = require('./myStuffPage');
const ProfilePage = require('./profilePage');
const AccountPage = require('./accountPage');
const MenuPage = require('./menuPage');
const SearchPage = require('./searchPage');
const VideoPlayerPage = require('./videoPlayerPage');
const OnboardingPage = require('./onboardingPage');
const HomePage = require('./homePage');
const NetworkLandingPage = require('./networkLandingPage');
const BrowsePage = require('./browsePage');
const SportsContentPage = require('./sportsContentPage');

const signInPage = new SignInPage();
const memberFeedPage = new MemberFeedPage();
const myStuffPage = new MyStuffPage();
const profilePage = new ProfilePage();
const accountPage = new AccountPage();
const menuPage = new MenuPage();
const searchPage = new SearchPage();
const videoPlayerPage = new VideoPlayerPage();
const onboardingPage = new OnboardingPage();
const homePage = new HomePage();
const browsePage = new BrowsePage();
const networkLandingPage = new NetworkLandingPage();
const sportsContentPage = new SportsContentPage();

module.exports = {
  signInPage,
  memberFeedPage,
  myStuffPage,
  profilePage,
  accountPage,
  menuPage,
  searchPage,
  videoPlayerPage,
  onboardingPage,
  homePage,
  browsePage,
  networkLandingPage,
  sportsContentPage,
};
