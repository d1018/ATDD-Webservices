const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class AccountPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('accountPage', locator);
  }

  currentPlanDetails_label = this.#getSelectorData('currentPlanDetails_label');

  changePlan_button = this.#getSelectorData('changePlan_button');

  updatePaymentMethod_button = this.#getSelectorData(
    'updatePaymentMethod_button',
  );

  viewBilling_label = this.#getSelectorData('viewBilling_label');

  redeemCode_button = this.#getSelectorData('redeemCode_button');

  cancelSubscription_button = this.#getSelectorData(
    'cancelSubscription_button',
  );

  subscription_button = this.#getSelectorData('subscription_button');

  subscriptionContentDetails = [
    this.currentPlanDetails_label,
    this.changePlan_button,
    this.updatePaymentMethod_button,
    this.viewBilling_label,
    this.redeemCode_button,
    this.cancelSubscription_button,
  ];

  accountPageItem = {
    Subscription: this.subscription_button,
  };

  /**
   * Below function is used to verify the subscription detail items is exist or not.
   */
  verifySubscriptionDetails = async () => {
    for (let i = 0; i < this.subscriptionContentDetails.length; i++) {
      await commons.waitUntil(this.subscriptionContentDetails[i]);
    }
  };

  /**
   * Below function is used select tab elements on Account screen
   *
   * @param {TabOptions} TabOptions for App Settings, Account tab, Subscription, Legal doc page, Help, Sign out tabs.
   */
  selectAccountSubTab = async (TabOptions) => {
    await commons.click(this.accountPageItem[TabOptions], 30);
  };
}

module.exports = AccountPage;
