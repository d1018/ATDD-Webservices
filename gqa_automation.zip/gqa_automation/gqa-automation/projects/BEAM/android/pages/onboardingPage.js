const assert = require('assert');
const { BasePage, testdataHelper, mobileActions } = require('./basePage');

const commons = mobileActions;

class OnboardingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('onboardingPage', locator);
  }

  signIn_button = this.getElementByPage('welcomePage', 'signIn_button');

  inactiveSub_lbl = this.#getSelectorData('inactiveSub_lbl');

  choosePlan_button = this.getElementByPage(
    'onboardingPage',
    'choosePlan_button',
  );

  firstName_textbox = this.#getSelectorData('firstName_textbox');

  lastName_textbox = this.#getSelectorData('lastName_textbox');

  emailAddress_textbox = this.#getSelectorData('emailAddress_textbox');

  password_textbox = this.#getSelectorData('password_textbox');

  subscribeAndPay_button = this.#getSelectorData('subscribeAndPay_button');

  createAccount_button = this.#getSelectorData('createAccount_button');

  adLitePlan_text = this.#getSelectorData('adLitePlan_text');

  continueToBeam_button = this.#getSelectorData('continueToBeam_button');

  subscribeNow_button = this.#getSelectorData('subscribeNow_button');

  subscribe_button = this.#getSelectorData('subscribe_button');

  paymentSuccessful_text = this.#getSelectorData('paymentSuccessful_text');

  noThanksRadio_button = this.#getSelectorData('noThanksRadio_button');

  ok_button = this.#getSelectorData('ok_button');

  continue_button = this.#getSelectorData('continue_button');

  selectPlan_text = this.#getSelectorData('selectPlan_text');

  createYourBeamAccount_text = this.#getSelectorData(
    'createYourBeamAccount_text',
  );

  focusedHomePage_label = this.getElementByPage(
    'homePage',
    'focusedHomePage_label',
  );

  CTASignUpList = [
    this.getElementByPage('welcomePage', 'subscribe_button'),
    this.getElementByPage('signInPage', 'noPassAvailable_lbl'),
    this.getElementByPage('signInPage', 'chooseYourPass_lbl'),
  ];

  /**
   * The below function will relaunch the app with playstore creds and wait for the welcome screen.
   * Navigates to plan picker screen by selecting subscribe now button.
   */
  navigateToPlanPickerPage = async () => {
    await commons.click(this.signIn_button);
    await commons.click(this.choosePlan_button);
  };

  verifyRegisterFreeCta = async () => {
    await commons.click(this.CTASignUpList[0]);
  };

  selectRegisterFreeCta = async () => {};

  createFreeAccount = async () => {
    const chars = 'abcdefghijklmnopqrstuvwxyz1234567890';
    let email = '';
    let firstName = 'Automation';
    let lastName = 'Lastname';

    for (let i = 0; i < 15; i++) {
      email += chars[Math.floor(Math.random() * chars.length)];
      firstName += chars[Math.floor(Math.random() * chars.length)];
      lastName += chars[Math.floor(Math.random() * chars.length)];
    }

    await commons.waitUntil(this.firstName_textbox);
    await commons.sendText(this.firstName_textbox, firstName);
    await commons.waitUntil(this.lastName_textbox);
    await commons.sendText(this.lastName_textbox, lastName);
    await commons.sendText(this.emailAddress_textbox, `${email}@beamwbd.com`);
    await commons.sendText(
      this.password_textbox,
      testdataHelper.getContent(`registrationPage.password`),
    );
    await commons.click(this.createAccount_button);
  };

  verifyAccountCreation = async () => {
    await this.assertPage('My Profile');
    await this.navigateToPage('Home');
  };

  /**
   * The below function will validate the Lapsed/Inactive Subscription screen whether the required elements are displayed
   */
  verifyInactiveSubscriptionScreen = async () => {
    assert(
      (await commons.elementExists(this.inactiveSub_lbl), 30) &&
        (await commons.elementExists(this.choosePlan_button), 30),
      `Inactive Subscription Screen is not visible`,
    );
  };

  /**
   * The below function will select any plan for subscription
   */
  selectAnyPlan = async () => {
    await commons.waitUntil(this.selectPlan_text);
    await commons.click(this.adLitePlan_text);
    await commons.scrollToElement(this.continue_button, 'down');
    await commons.click(this.continue_button);
  };

  /**
   * The below function will validate create account label is available or not.
   * If it is available then it will create a new account for subscription.
   */
  createAccount = async () => {
    await commons.waitUntil(this.createYourBeamAccount_text);
    await this.createFreeAccount();
  };

  /**
   * The below function will select the subscribe button after creating account.
   */
  selectSubscribeCta = async () => {
    await commons.waitUntil(this.subscribeAndPay_button);
    await commons.clickCoordinates(450, 1650);
    await commons.waitUntil(this.subscribe_button);
    await commons.click(this.subscribe_button);
  };

  /**
   * This method used to select the payment type whether it is credit or debit card.
   * This method is not applicable for android.
   */
  selectPaymentType = async () => {};

  /**
   * The below method used to give the card details and process the payment.
   * This method is not applicable for android.
   */

  submitPaymentDetails = async () => {};

  /**
   * The below function will verify the subscription confirmation message
   */
  verifyPostPurchaseConfirmationScreen = async () => {
    if (await commons.elementExists(this.subscription_text)) {
      await commons.click(this.noThanksRadio_button);
      await commons.click(this.ok_button);
    }
    assert(
      await commons.elementExists(this.subscription_text, 30),
      'Subscription status is not displayed',
    );
  };

  /**
   * The below function will select continue to beam button after successful subscription text.
   * It waits for the home page to be visible.
   */
  clickOnLetsGoCta = async () => {
    await commons.click(this.continueToBeam_button);
    await commons.waitUntil(this.focusedHomePage_label);
  };
}

module.exports = OnboardingPage;
