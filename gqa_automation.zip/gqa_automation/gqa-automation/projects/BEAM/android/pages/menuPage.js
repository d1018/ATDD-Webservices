const { BasePage, mobileActions, testdataHelper } = require('./basePage');

const commons = mobileActions;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  focusedHomePage_label = this.getElementByPage(
    'homePage',
    'focusedHomePage_label',
  );

  shows_tab = this.getElementByPage('homePage', 'shows_tab');

  movies_tab = this.getElementByPage('homePage', 'movies_tab');

  hbo_tab = this.getElementByPage('homePage', 'hbo_tab');

  account_label = this.#getSelectorData('account_label');

  signInOnVOD_btn = this.#getSelectorData('signInOnVOD_btn');

  signUpOnVOD_btn = this.getElementByPage('onboardingPage', 'signUpOnVOD_btn');

  appSettings_label = this.#getSelectorData('appSettings_label');

  help_label = this.#getSelectorData('help_label');

  focusedHelpPage = this.#getSelectorData('focusedHelpPage');

  subscription_label = this.#getSelectorData('subscription_label');

  privacyTerms_label = this.#getSelectorData('privacyTerms_label');

  signOut_label = this.#getSelectorData('signOut_label');

  focusedSettingsPage = this.#getSelectorData('focusedSettingsPage');

  focusedSusbscriptionPage = this.#getSelectorData('focusedSusbscriptionPage');

  focusedSignOutPopUp = this.#getSelectorData('focusedSignOutPopUp');

  focusedManageAccountPage = this.#getSelectorData('focusedManageAccountPage');

  myProfiles_tab = this.getElementByPage('profilePage', 'myProfiles_tab');

  userMenuItem = [];

  accountMenuItem = [];

  homePageTab = [
    this.focusedHomePage_label,
    this.shows_tab,
    this.movies_tab,
    this.hbo_tab,
  ];

  accountPageSubMenu = {
    Account: this.account_label,
    Settings: this.appSettings_label,
    Help: this.help_label,
    Subscription: this.subscription_label,
    'Privacy & Terms': this.privacyTerms_label,
    'Sign Out': this.signOut_label,
  };

  accountSubNavigationPageFocused = {
    Account: this.focusedManageAccountPage,
    Settings: this.focusedSettingsPage,
    Help: this.focusedHelpPage,
    Subscription: this.focusedSusbscriptionPage,
    'Privacy & Terms': this.focusedPrivacyTerms,
    'Sign Out': this.focusedSignOutPopUp,
  };

  navigateToAccountMenu = async () => {
    await this.navigateToPage('My Profile');
  };

  /**
   * The below function will fetch the menu items from test data helper.
   */
  getAccountMenuItems = () => {
    this.accountMenuItem = testdataHelper.getContent('menuPage.accountItems');
  };

  /**
   * The below function will verify the tabs present in account page.
   */
  verifySubnavigationItems = async () => {
    this.getAccountMenuItems();
    for (let i = 0; i < this.accountMenuItem.length; i++) {
      await commons.waitUntil(
        this.accountPageSubMenu[this.accountMenuItem[i]],
        15,
      );
    }
  };

  /**
   * The below function will navigate to the account sub menu pages and verify
   
   */
  navigateToSubnavigationAndVerify = async () => {
    this.getAccountMenuItems();
    for (let i = 0; i < this.accountMenuItem.length; i++) {
      await commons.click(this.accountPageSubMenu[this.accountMenuItem[i]]);
      await commons.waitUntil(
        this.accountSubNavigationPageFocused[this.accountMenuItem[i]],
        30,
      );
      await commons.clickBack();
    }
  };

  /**
   * The below function will verify the tabs present in home page.
   */
  accessGlobalNavigationMenu = async () => {
    for (let i = 0; i < this.homePageTab.length; i++) {
      await commons.waitUntil(this.homePageTab[i], 5);
    }
  };

  /**
   * The below function will fetch the menu items from test data helper.
   */
  getUserMenuItems = () => {
    this.userMenuItem = testdataHelper.getContent('menuPage.menuItems');
  };

  /**
   * The below function will verify the navigation menu list.
   */
  verifyMenuList = async () => {
    await this.getUserMenuItems();
    for (let i = 0; i < this.userMenuItem.length; i++) {
      await commons.waitUntil(this.menuItem[this.userMenuItem[i]], 15);
    }
  };

  /**
   * The below function will verify the navigation menu pages
   */
  verifyGlobalNavigation = async () => {
    this.getUserMenuItems();
    for (let i = 0; i < this.userMenuItem.length; i++) {
      await commons.click(this.menuItem[this.userMenuItem[i]]);
      await commons.waitUntil(this.pageFocused[this.userMenuItem[i]]);
    }
  };
}

module.exports = MenuPage;
