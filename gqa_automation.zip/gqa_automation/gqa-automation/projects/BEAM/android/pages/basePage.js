const path = require('path');
const assert = require('assert');

const showNameTitles = [];

const {
  mobileActions,
  customErrors,
  testdataHelper,
} = require('@wbd/gqa-core/support');

const commons = mobileActions;
const ymlpath = path.resolve(__dirname);

const EnvBase = require('../../../support/env');

const { skipReason } = require('../../../support/skipReason');

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }

  #getSelectorData(locator) {
    return this.getElementByPage('basePage', locator);
  }

  home_menu = this.#getSelectorData('home_menu');

  myStuff_menu = this.#getSelectorData('myStuff_menu');

  downloads_menu = this.#getSelectorData('downloads_menu');

  search_menu = this.#getSelectorData('search_menu');

  browse_menu = this.#getSelectorData('browse_menu');

  profile_button = this.#getSelectorData('profile_button');

  focusedBrowsePage = this.getElementByPage('browsePage', 'focusedBrowsePage');

  focusedSearchPage_label = this.getElementByPage(
    'searchPage',
    'focusedSearchPage_label',
  );

  focusedHomePage_label = this.getElementByPage(
    'homePage',
    'focusedHomePage_label',
  );

  kebabIcon_btn = this.getElementByPage('memberFeedPage', 'kebabIcon_btn');

  moreInfoCTA_btn = this.getElementByPage('memberFeedPage', 'moreInfoCTA_btn');

  playCTA_btn = this.getElementByPage('memberFeedPage', 'playCTA_btn');

  title_label = this.getElementByPage('myStuffPage', 'title_label');

  railTitle_label = this.getElementByPage('myStuffPage', 'railTitle_label');

  infoModal_button = this.getElementByPage('myStuffPage', 'infoModal_button');

  infoModalAddToMyList_button = this.getElementByPage(
    'myStuffPage',
    'infoModalAddToMyList_button',
  );

  myList_link = this.#getSelectorData('myList_link');

  signIn_button = this.getElementByPage('welcomePage', 'signIn_button');

  focusedDownloadsPage_label = this.getElementByPage(
    'downloadsPage',
    'focusedDownloadsPage_label',
  );

  focusedProfilePage_label = this.getElementByPage(
    'accountPage',
    'focusedProfilePage_label',
  );

  focusedMyStuffPage = this.getElementByPage('myStuffPage', 'myList_tab');

  welcomeToBeam_label = this.getElementByPage(
    'welcomePage',
    'welcomeToBeam_label',
  );

  themedRailCTA_button = this.getElementByPage(
    'sportsContentPage',
    'themedRailCTA_button',
  );

  menuItem = {
    Home: this.home_menu,
    'My Stuff': this.myStuff_menu,
    Search: this.search_menu,
    Browse: this.browse_menu,
    Downloads: this.downloads_menu,
    Signin: this.signIn_button,
    'My Profile': this.profile_button,
    Sports: this.sports_menu,
  };

  pageFocused = {
    Home: this.focusedHomePage_label,
    Search: this.focusedSearchPage_label,
    Downloads: this.focusedDownloadsPage_label,
    Browse: this.focusedBrowsePage,
    'My Stuff': this.focusedMyStuffPage,
    Signin: this.welcomeToBeam_label,
    'My Profile': this.focusedProfilePage_label,
    Sports: this.focusedSportsPage_label,
  };

  buttonsCTA = {
    'More Info': this.moreInfoCTA_btn,
    Play: this.playCTA_btn,
    primary: this.themedRailCTA_button,
  };

  railsList = {
    'My List': this.#getSelectorData('myList_link'),
    Featured: this.#getSelectorData('featuredRail_lbl'),
    'Continue Watching': this.#getSelectorData('continueWatchingRail_lbl'),
    Network: this.getElementByPage('homePage', 'network_image'),
    VOD: this.getElementByPage('sportsContentPage', 'vodRail_label'),
    'Upcoming Live': this.getElementByPage(
      'sportsContentPage',
      'upcomingRail_label',
    ),
  };

  dynamicRailName_lbl = this.#getSelectorData('dynamicRailName_lbl');

  openKebabMenuAndSelectCTA = async (kebabActionType) => {
    await commons.waitUntil(this.kebabIcon_btn);
    await commons.click(this.kebabIcon_btn);
    await commons.click(this.buttonsCTA[kebabActionType]);
  };

  showName_lbl = this.getElementByPage('searchPage', 'showName_lbl');

  navigateToPage = async (pageValue) => {
    let retries = 2;

    while (
      retries-- > 0 &&
      !(await commons.elementExists(this.pageFocused[pageValue], 30))
    ) {
      await commons.click(this.menuItem[pageValue], 30);
    }
    await this.assertPage(pageValue);
  };

  /**
   *This assertPage function will -
   * 1) Check whether it navigates to the correct page or not.
   * 2)If it is not present it will throw an error.
   *
   * @param {string} pageValue for HomePage,AccountPage,SearchPage,Downloads and MyStuff Page.
   */
  assertPage = async (pageValue) => {
    assert(await commons.elementExists(this.pageFocused[pageValue], 30));
  };

  scrollToRail = async (railName, railStatus = true) => {
    await this.verifyRailPresent(railName, railStatus);
  };

  /**
   * Below function is used to check rail availability
   * 1) Scroll to the rail mentioned in the railName parameter
   * 2) Validate the rail presence based on the value passed to railStatus field
   *
   * @param {string} railName specifies the rail name to be validated
   * @param {boolean} railStatus is the expected rail availability(true/false) on home page
   */
  verifyRailPresent = async (railName, railStatus) => {
    const railCheck = await this.scrollAndVerifyRailPresent(railName);

    assert.deepStrictEqual(
      railCheck,
      railStatus,
      `Rail availability status mismatch as ${railName} is not present`,
    );
  };

  /**
   * Below function is used to scroll to a
   * 1) Break the loop and return true value if rail is already displayed
   * 2) If rail is not displayed then scroll down on the home page upto 15 tries
   * 3) If the rail is still not displayed then return false else return true
   *
   * @param {string} railName is the header text of the rail available on the app
   */
  scrollAndVerifyRailPresent = async (railName) => {
    for (let count = 0; count < 15; count++) {
      if (await commons.elementExists(this.railsList[railName], 5)) return true;
      await commons.scrollOnPageByPercentage('down', '50%');
    }
    const myListRailDisplayed = await commons.findElements(
      this.railsList[railName],
    );

    return myListRailDisplayed.length > 0;
  };

  getTheShowNamesInRail = async (railName) => {
    const isRailDisplayed = await this.scrollAndVerifyRailPresent(railName);

    assert(
      isRailDisplayed,
      `${railName} is Not displayed even after scrolling`,
    );
    const requiredRailName = this.getCustomLocator(
      this.dynamicRailName_lbl,
      railName,
    );

    // below scrollOnPageByPercentage is required to enable the show names visible on the screen; else they will be not displayed

    await commons.scrollOnPageByPercentage('down', '20%');
    const showNames = await commons.findElements(requiredRailName);

    for (let i = 0; i < showNames.length; i++) {
      const showNameTitle = await commons.fetchAttributeData(
        showNames[i],
        'text',
      );

      showNameTitles.push(showNameTitle);
    }
    /**
     * Below 3 lines can be deleted. This is just as reference.
     */
    // const b = ['Death by Fame', '1000-lb Sisters'];
    // const k = await this.compareShows(showNameTitles, b);
    // console.log(k);
    return showNameTitles;
  };

  /**
   *
   * @param {Array} a - first array that contains show names from any rail
   * @param {Array} b - second array that contains show names from another rail
   * @returns {boolean} true - if both the arrays a & b are of same length && having same values; else false
   */
  compareShows = async (a, b) => {
    const isArrayEqual = await (a.length === b.length &&
      a.every((element, index) => element === b[index]));

    return isArrayEqual;
  };

  getRailItemsCount = async (railName) => {
    const railItemsCount = await this.getTheShowNamesInRail(railName);

    return railItemsCount.length;
  };

  returnBuildType = () => {
    const buildType = process.env.DTC_ANDROID_APP_PACKAGE.toLowerCase();

    if (['enterprise'].includes(buildType)) {
      return 'enterprise';
    }
    return 'release';
  };

  returnRandomNumber = (len) => {
    const randomNumber = Math.floor(Math.random() * len);

    return `${randomNumber}`;
  };

  /**
   * Below function is used to click the CTA button
   *
   * @param {string} CTAtype as primary,more info and play.
   */
  selectCTA = async (CTAtype) => {
    await commons.click(this.buttonsCTA[CTAtype]);
  };
}

module.exports = {
  mobileActions,
  customErrors,
  skipReason,
  testdataHelper,
  BasePage,
};
