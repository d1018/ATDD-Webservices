const { BasePage, testdataHelper, mobileActions } = require('./basePage');

const commons = mobileActions;

class SportsContentPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('sportsContentPage', locator);
  }

  firstShow_label = this.#getSelectorData('firstShow_label');

  showTitle_label = this.#getSelectorData('showTitle_label');

  showDate_text = this.#getSelectorData('showDate_text');

  showTime_text = this.#getSelectorData('showTime_text');

  sportsCat_text = this.#getSelectorData('sportsCat_text');

  secTitle_text = this.#getSelectorData('secTitle_text');

  description_text = this.#getSelectorData('description_text');

  watchNow_button = this.#getSelectorData('watchNow_button');

  progressBar_text = this.#getSelectorData('progressBar_text');

  backImage_image = this.#getSelectorData('backImage_image');

  badge_text = this.#getSelectorData('badge_text');

  addToMyList_button = this.#getSelectorData('addToMyList_button');

  themedRailCTA_button = this.#getSelectorData('themedRailCTA_button');

  immersiveHero_header = this.#getSelectorData('immersiveHero_header');

  rail_tile = this.getElementByPage('homePage', 'rail_tile');

  sportsMetaData = {
    Title: this.showTitle_label,
    Date: this.showDate_text,
    Time: this.showTime_text,
    Image: this.backImage_image,
    Badge: this.badge_text,
    'Sports Category': this.sportsCat_text,
    'Secondary Title': this.secTitle_text,
    Description: this.description_text,
    'Watch Now': this.watchNow_button,
    'Progress Bar': this.progressBar_text,
    'Add to MyList': this.addToMyList_button,
    'Primary CTA': this.themedRailCTA_button,
  };

  /**
   * Below function is used to check the particular rail is present or not
   * If present it will select the first show based on the content type.
   *
   * @param {string} contentType as live,upcoming live and vod..
   */
  selectContent = async (contentType) => {
    await this.scrollToRail(contentType);
    await commons.click(this.firstShow_label);
  };

  /**
   * Below function is used to fetch the meta data items from us.yml
   * based on the content type
   * If present it will select the first show based on the content type.
   *
   * @param {string} contentType as live,upcoming live,vod and sports themed rail.
   */
  getContentItems = (contentType) => {
    if (contentType === 'VOD') {
      this.contentItem = testdataHelper.getContent('sportsPage.contentOnVOD');
    } else if (contentType === 'Upcoming Live') {
      this.contentItem = testdataHelper.getContent(
        'sportsPage.contentOnUpcomingLive',
      );
    } else if (contentType === 'Upcoming Badge') {
      this.contentItem = testdataHelper.getContent(
        'sportsPage.contentOnUpcomingBadge',
      );
    } else if (contentType === 'sports themed rail') {
      this.contentItem = testdataHelper.getContent(
        'sportsPage.contentOnSportsThemedRail',
      );
    }
  };

  /**
   * Below function is used to fetch the meta data items from us.yml
   * based on the content type
   * If present it will select the first show based on the content type.
   *
   * @param {string} contentType as live,upcoming live,vod and sports themed rail.
   */
  verifyContentDetails = async (contentType) => {
    await this.verifySportsMetaData(contentType);
  };

  /**
   * Below function is used to fetch the meta data items from us.yml and
   * verify the metadata for the pariticular content is visible or not.
   *
   * @param {string} contentType as live,upcoming live,vod and sports themed rail.
   */
  verifySportsMetaData = async (contentType) => {
    this.getContentItems(contentType);
    for (let i = 0; i < this.contentItem.length; i++) {
      await commons.waitUntil(this.sportsMetaData[this.contentItem[i]]);
    }
  };

  /**
   * Below function is used to verify the immersive hero and
   * rail tile components are present in the sport themed rail or not.
   */
  verifySportsThemeRail = async () => {
    await commons.waitUntil(this.immersiveHero_header);
    await commons.waitUntil(this.rail_tile);
  };
}

module.exports = SportsContentPage;
