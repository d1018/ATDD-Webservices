const signInPage = require('./signInPage');
const homePage = require('./homePage');
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');
const settingsPage = require('./settingsPage');
const myStuffPage = require('./myStuffPage');
const searchPage = require('./searchPage');

module.exports = {
  signInPage,
  homePage,
  menuPage,
  profilePage,
  settingsPage,
  myStuffPage,
  searchPage,
};
