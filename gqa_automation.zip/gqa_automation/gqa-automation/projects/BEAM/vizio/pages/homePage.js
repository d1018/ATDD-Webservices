const { BasePage, remoteActions } = require('./basePage');
const menuPage = require('./menuPage');
const settingsPage = require('./settingsPage');

const commons = remoteActions;
const { VRC } = commons;

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  focusedMyList_tile = this.#getSelectorData('focusedMyList_tile');

  myListRail = this.#getSelectorData('myListRail');

  verifyMyListRailOnHomePage = async (hasShows) => {
    await menuPage.navigateToPage('Home');
    if (hasShows) {
      await commons.tryUntil(this.focusedMyList_tile, VRC.DOWN, 10);
      await commons.assertExists(this.focusedMyList_tile);
      await commons.waitUntil(this.myListRail, 10);
      await commons.assertExists(this.myListRail);
    }
  };

  signOut = async () => {
    await menuPage.navigateToPage('Settings');
    await settingsPage.signOut();
  };
}

module.exports = new HomePage();
