const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  focusedHome_button = this.#getSelectorData('focusedHome_button');

  signInFlow_button = this.getElementByPage('welcomePage', 'signInFlow_button');

  focusedSignInFlow_button = this.getElementByPage(
    'welcomePage',
    'focusedSignInFlow_button',
  );

  whoIsWatching_label = this.getElementByPage(
    'profilePage',
    'whoIsWatching_label',
  );

  focusedMenuButton = this.#getSelectorData('focusedMenuButton');

  pageFocused = {
    Home: this.immersiveHero_button,
  };

  focusedProfileIcon = this.#getSelectorData('focusedProfileIcon');

  playBack_lbl = this.getElementByPage('settingsPage', 'playBack_lbl');

  subtitles_lbl = this.getElementByPage('settingsPage', 'subtitles_lbl');

  account_lbl = this.getElementByPage('settingsPage', 'account_lbl');

  subscription_lbl = this.getElementByPage('settingsPage', 'subscription_lbl');

  privacyTerms_lbl = this.getElementByPage('settingsPage', 'privacyTerms_lbl');

  help_lbl = this.getElementByPage('settingsPage', 'help_lbl');

  info_lbl = this.getElementByPage('settingsPage', 'info_lbl');

  signOut_lbl = this.getElementByPage('settingsPage', 'signOut_lbl');

  immersiveHero_header = this.getElementByPage(
    'homePage',
    'immersiveHero_header',
  );

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  focusedPlayBack_lbl = this.getElementByPage(
    'settingsPage',
    'focusedPlayBack_lbl',
  );

  focusedSubtitles_lbl = this.getElementByPage(
    'settingsPage',
    'focusedSubtitles_lbl',
  );

  focusedAccount_lbl = this.getElementByPage(
    'settingsPage',
    'focusedAccount_lbl',
  );

  focusedSubscription_lbl = this.getElementByPage(
    'settingsPage',
    'focusedSubscription_lbl',
  );

  focusedPrivacyTerms_lbl = this.getElementByPage(
    'settingsPage',
    'focusedPrivacyTerms_lbl',
  );

  focusedHelp_lbl = this.getElementByPage('settingsPage', 'focusedHelp_lbl');

  focusedInfo_lbl = this.getElementByPage('settingsPage', 'focusedInfo_lbl');

  focusedSignOut_lbl = this.getElementByPage(
    'settingsPage',
    'focusedSignOut_lbl',
  );

  focusedSettings_button = this.getElementByPage(
    'settingsPage',
    'focusedSettings_button',
  );

  settingMenuItem = {
    Playback: this.focusedPlayBack_lbl,
    Subtitles: this.focusedSubtitles_lbl,
    Account: this.focusedAccount_lbl,
    Subscription: this.focusedSubscription_lbl,
    'Privacy & Terms': this.focusedPrivacyTerms_lbl,
    Help: this.focusedHelp_lbl,
    Info: this.focusedInfo_lbl,
    'Sign Out': this.focusedSignOut_lbl,
  };

  settingMenuItemPage = {
    Playback: this.playBack_lbl,
    Subtitles: this.subtitles_lbl,
    Account: this.account_lbl,
    Subscription: this.subscription_lbl,
    'Privacy & Terms': this.privacyTerms_lbl,
    Help: this.help_lbl,
    Info: this.info_lbl,
    'Sign Out': this.signOut_lbl,
  };

  openMenu = async () => {
    await commons.tryUntil(this.focusedHome_button, VRC.BACK, 3, 1);
    await commons.assertExists(this.focusedHome_button, 5);
  };

  assertPage = async (pageValue) => {
    await commons.waitUntil(this.pageFocused[pageValue], 30);
    await commons.assertExists(this.pageFocused[pageValue], 30);
  };

  navigateToPage = async (pageValue) => {
    if (pageValue === 'Signin') {
      await commons.waitUntil(this.signInFlow_button, 60);
      await commons.tryUntil(this.focusedSignInFlow_button, VRC.RIGHT, 6, 1);
      await commons.assertExists(this.focusedSignInFlow_button);
      await commons.userAction(VRC.ENTER);
    } else if (pageValue === 'Settings') {
      await this.openMenu();
      await commons.tryUntil(this.focusedSettings_button, VRC.DOWN, 5, 2);
      await commons.assertExists(this.focusedSettings_button);
      await commons.userAction(VRC.ENTER, 5);
    } else {
      if (await commons.elementExists(this.whoIsWatching_label, 2)) {
        await commons.userAction(VRC.ENTER);
        await commons.assertVisible(this.focusedHomePage, 20);
      }
      await this.openMenu();
      await commons.userAction(VRC.UP, 5);
      if (pageValue === 'Profile') {
        await commons.waitUntil(this.homeTab_lbl, 20);
        await commons.assertExists(this.focusedProfileIcon);
      } else {
        await commons.tryUntil(
          this.getCustomLocator(this.focusedMenuButton, pageValue),
          VRC.DOWN,
          5,
          0.5,
        );
        await commons.assertExists(
          this.getCustomLocator(this.focusedMenuButton, pageValue),
        );
      }
      await commons.userAction(VRC.ENTER);
    }
  };

  navigateToAccountMenu = async () => {
    await this.navigateToPage('Settings');
  };

  getUserMenuItems = async () => {
    let userMenu = [];

    userMenu = await testdataHelper.getContent(
      'settingsPage.vizioSettingsMenuList',
    );
    return userMenu;
  };

  verifySubnavigationItems = async () => {
    const userMenu = await this.getUserMenuItems();

    for (let i = 0; i < userMenu.length; i++) {
      await commons.assertExists(this.settingMenuItem[userMenu[i]], 5);
      await commons.userAction(VRC.DOWN);
    }
    await commons.tryUntil(this.focusedPlayBack_lbl, VRC.UP, 10, 1);
  };

  navigateToSubnavigationAndVerify = async () => {
    const userMenu = await this.getUserMenuItems();

    await commons.assertExists(this.playBack_lbl, 5);

    for (let i = 0; i < userMenu.length; i++) {
      await commons.assertExists(this.settingMenuItemPage[userMenu[i]], 5);
      await commons.userAction(VRC.DOWN);
    }
  };
}

module.exports = new MenuPage();
