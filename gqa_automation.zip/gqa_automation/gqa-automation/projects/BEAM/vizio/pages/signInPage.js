const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  useQRCode_button = this.#getSelectorData('useQRCode_button');

  useKeyboard_button = this.#getSelectorData('useKeyboard_button');

  focusedUseKeyboard_button = this.#getSelectorData(
    'focusedUseKeyboard_button',
  );

  emailTextBox_field = this.#getSelectorData('emailTextBox_field');

  focusedEmailTextBox_field = this.#getSelectorData(
    'focusedEmailTextBox_field',
  );

  passwordTextBox_field = this.#getSelectorData('passwordTextBox_field');

  focusedPasswordTextBox_field = this.#getSelectorData(
    'focusedPasswordTextBox_field',
  );

  focusedProfile = this.getElementByPage('profilePage', 'focusedProfile');

  signInFlow_button = this.getElementByPage('welcomePage', 'signInFlow_button');

  startStreaming_text = this.#getSelectorData('startStreaming_text');

  streamingSignin_btn = this.#getSelectorData('streamingSignin_btn');

  openApp = async () => {
    await commons.clearAppData();
    // For Headspin devices still logged in from previous sessions
    await commons.closeApp();
    // Reopen App again to reflect the clearAppData();
    await commons.openApp();
    await commons.assertExists(this.startStreaming_text, 40);
  };

  loginToApplication = async (credentialType) => {
    await this.navigateToSignInScreen_US();
    await this.enterCredentials(credentialType);
    await commons.waitUntilVisible(this.focusedProfile, 20);
  };

  navigateToSignInScreen_US = async () => {
    await commons.waitUntil(this.startStreaming_text);
    await commons.userAction(VRC.RIGHT, 2, 2);
    await commons.assertExists(this.streamingSignin_btn);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.signInFlow_button, 5);
    await commons.tryUntil(this.useQRCode_button, VRC.ENTER, 5);
    await commons.assertExists(this.useQRCode_button);
    await commons.tryUntil(this.focusedUseKeyboard_button, VRC.DOWN, 2, 1);
    await commons.tryUntil(this.focusedEmailTextBox_field, VRC.RIGHT, 2, 1);
  };

  enterCredentials = async (credentialType) => {
    const username = process.env[`${credentialType}_USERNAME`];
    const password = process.env[`${credentialType}_PASSWORD`];

    // selecting the email field and entering email
    await commons.assertExists(this.emailTextBox_field, 3);
    await commons.userAction(VRC.SELECT);
    await this.setTextForVizio(username);
    await commons.userAction(VRC.UP);
    // selecting the password field and entering password
    await commons.userAction(VRC.DOWN);
    await commons.userAction(VRC.ENTER);
    await this.setTextForVizio(password);
    await commons.userAction(VRC.DOWN);
    await commons.userAction(VRC.ENTER);
  };

  verifySignOut = async () => {
    await commons.waitUntil(this.signInFlow_button, 30);
    await commons.assertExists(this.signInFlow_button);
  };
}
module.exports = new SignInPage();
