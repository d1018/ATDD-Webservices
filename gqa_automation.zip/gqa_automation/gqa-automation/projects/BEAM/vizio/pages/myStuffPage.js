const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class MyStuffPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myStuffPage', locator);
  }

  focusedMyListTab = this.#getSelectorData('focusedMyListTab');

  noSavedTitles_header = this.#getSelectorData('noSavedTitles_header');

  focusedMyStuffRecommended_tile = this.#getSelectorData(
    'focusedMyStuffRecommended_tile',
  );

  focusedAddToMyList_button = this.getElementByPage(
    'showPage',
    'focusedAddToMyList_button',
  );

  focusedRemoveFromMyList_button = this.getElementByPage(
    'showPage',
    'focusedRemoveFromMyList_button',
  );

  myList_tile = this.#getSelectorData('myList_tile');

  selectMyList = async () => {
    await commons.waitUntil(this.focusedMyListTab, 10);
    await commons.assertExists(this.focusedMyListTab);
  };

  verifyMyListContent = async () => {
    await commons.waitUntil(this.noSavedTitles_header, 20);
    await commons.assertExists(this.noSavedTitles_header);
  };

  addShowsToMylist = async () => {
    await commons.tryUntil(this.focusedMyStuffRecommended_tile, VRC.DOWN, 5);
    await commons.assertExists(this.focusedMyStuffRecommended_tile);
    await commons.userAction(VRC.ENTER);
    await commons.tryUntil(this.focusedAddToMyList_button, VRC.RIGHT, 5);
    await commons.assertExists(this.focusedAddToMyList_button);
    await commons.userAction(VRC.ENTER);
    await commons.waitUntil(this.focusedRemoveFromMyList_button, 10);
    await commons.assertExists(this.focusedRemoveFromMyList_button);
    await commons.userAction(VRC.BACK);
  };

  verifyMyListData = async (hasShows) => {
    if (hasShows) {
      await commons.waitUntil(this.myList_tile, 20);
      await commons.assertExists(this.myList_tile);
    } else {
      await commons.waitUntil(this.noSavedTitles_header, 20);
      await commons.assertExists(this.noSavedTitles_header);
    }
  };
}

module.exports = new MyStuffPage();
