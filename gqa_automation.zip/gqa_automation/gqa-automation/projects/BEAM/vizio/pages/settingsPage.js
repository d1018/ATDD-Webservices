const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class SettingsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('settingsPage', locator);
  }

  focusedSignOutMenuItem = this.#getSelectorData('focusedSignOutMenuItem');

  focusedSignOutConfirmation_button = this.#getSelectorData(
    'focusedSignOutConfirmation_button',
  );

  signOut = async () => {
    await commons.tryUntil(this.focusedSignOutMenuItem, VRC.DOWN, 10);
    await remoteActions.assertExists(this.focusedSignOutMenuItem);
    await commons.tryUntil(
      this.focusedSignOutConfirmation_button,
      VRC.RIGHT,
      10,
    );
    await remoteActions.assertExists(this.focusedSignOutConfirmation_button);
    await commons.userAction(VRC.ENTER);
  };
}

module.exports = new SettingsPage();
