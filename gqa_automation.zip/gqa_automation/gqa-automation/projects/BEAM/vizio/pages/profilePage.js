const { BasePage, remoteActions } = require('./basePage');
const menuPage = require('./menuPage');

const commons = remoteActions;
const { VRC } = commons;

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  focusedProfile = this.#getSelectorData('focusedProfile');

  edit_profile_text = this.#getSelectorData('edit_profile_text');

  whoIsWatching_label = this.#getSelectorData('whoIsWatching_label');

  immersiveHero_button = this.getElementByPage(
    'homePage',
    'immersiveHero_button',
  );

  focusedAddProfile_button = this.#getSelectorData('focusedAddProfile_button');

  addProfile_button = this.#getSelectorData('addProfile_button');

  focusedAvatar = this.#getSelectorData('focusedAvatar');

  focusedKidsMode = this.#getSelectorData('focusedKidsMode');

  focusedDone_button = this.#getSelectorData('focusedDone_button');

  focusedDeleteProfile_button = this.#getSelectorData(
    'focusedDeleteProfile_button',
  );

  focusedDelete_button = this.#getSelectorData('focusedDelete_button');

  standardProfileText = this.#getSelectorData('standardProfileText');

  kidsProfileText = this.#getSelectorData('kidsProfileText');

  focusedProfileName_field = this.#getSelectorData('focusedProfileName_field');

  verifyProfileScreen = async () => {
    await commons.waitUntil(this.focusedProfile, 20);
    await commons.assertExists(this.focusedProfile);
    await commons.assertExists(this.whoIsWatching_label);
  };

  selectProfile = async (profileType) => {
    if (
      profileType.includes('Default') ||
      profileType.includes('any') ||
      profileType.includes('Standard')
    ) {
      await commons.userAction(VRC.ENTER);
    }
    await commons.waitUntil(this.immersiveHero_button, 30);
    await commons.assertExists(this.immersiveHero_button);
  };

  profileCreation = async (profileType) => {
    await commons.tryUntil(this.focusedAddProfile_button, VRC.RIGHT, 5);
    await commons.assertExists(this.focusedAddProfile_button);
    await commons.userAction(VRC.ENTER);
    await commons.waitUntil(this.focusedAvatar, 20);
    await commons.assertExists(this.focusedAvatar);
    await commons.tryUntil(this.focusedProfileName_field, VRC.ENTER, 5);
    await commons.userAction(VRC.ENTER);
    await this.setTextForVizio(profileType);

    if (profileType === 'Kids') {
      await commons.tryUntil(this.focusedKidsMode, VRC.DOWN, 5);
      await commons.assertExists(this.focusedKidsMode);
      await commons.userAction(VRC.ENTER);
    }

    await commons.tryUntil(this.focusedDone_button, VRC.DOWN, 5);
    await commons.assertExists(this.focusedDone_button);
    await commons.userAction(VRC.ENTER);

    if (profileType === 'Standard') {
      await commons.waitUntil(this.standardProfileText, 20);
      await commons.assertExists(this.standardProfileText);
    } else if (profileType === 'Kids') {
      await commons.waitUntil(this.kidsProfileText, 20);
      await commons.assertExists(this.kidsProfileText);
    }
    await commons.userAction(VRC.ENTER);
  };

  deleteExistingProfile = async () => {
    await menuPage.navigateToPage('Profile');
    await commons.waitUntil(this.focusedProfile, 10);
    await commons.assertExists(this.focusedProfile);
    await commons.userAction(VRC.DOWN);
    await commons.userAction(VRC.ENTER);
    await commons.tryUntil(this.focusedDone_button, VRC.DOWN, 5);
    await commons.tryUntil(this.focusedDeleteProfile_button, VRC.RIGHT, 5);
    await commons.assertExists(this.focusedDeleteProfile_button);
    await commons.userAction(VRC.ENTER);
    await commons.tryUntil(this.focusedDelete_button, VRC.RIGHT, 5);
    await commons.assertExists(this.focusedDelete_button);
    await commons.userAction(VRC.ENTER);
    await commons.waitUntil(this.addProfile_button);
    await commons.assertExists(this.addProfile_button);
  };

  createNewProfileAndMoveToEdit = async (profileType) => {
    await commons.tryUntil(this.focusedAddProfile_button, VRC.RIGHT, 5);
    await commons.assertExists(this.focusedAddProfile_button);
    await commons.userAction(VRC.ENTER);
    await commons.waitUntil(this.focusedAvatar, 20);
    await commons.assertExists(this.focusedAvatar);
    await commons.tryUntil(this.focusedProfileName_field, VRC.ENTER, 5);
    await commons.userAction(VRC.ENTER);
    await this.setTextForVizio(profileType);
    await commons.tryUntil(this.focusedDone_button, VRC.DOWN, 5);
    await commons.assertExists(this.focusedDone_button);
    await commons.userAction(VRC.ENTER, 1, 5);
  };

  editUserProfile = async () => {
    await commons.assertExists(this.whoIsWatching_label, 2);
    await commons.userAction(VRC.DOWN, 1, 2);
    await commons.userAction(VRC.ENTER, 1, 2);
    await commons.assertExists(this.edit_profile_text, 5);
    await commons.userAction(VRC.ENTER, 1, 2);
    await commons.userAction(VRC.DOWN, 2, 2);
    await commons.userAction(VRC.LEFT, 2, 2);
    await commons.userAction(VRC.ENTER, 1, 2);
    await commons.userAction(VRC.UP, 2, 2);
    await commons.userAction(VRC.ENTER, 2, 2);
    await this.setTextForVizio('newuser');
    await commons.userAction(VRC.DOWN, 2, 2);
    await commons.userAction(VRC.ENTER, 1, 2);
  };

  verifyEditedProfile = async () => {
    await commons.assertExists(this.whoIsWatching_label, 2);
    await commons.userAction(VRC.ENTER, 1, 2);
  };
}

module.exports = new ProfilePage();
