const path = require('path');
const suitest = require('suitest-js-api');
const { remoteActions, testdataHelper } = require('@wbd/gqa-core/support');

const commons = remoteActions;
const { VRC } = commons;

const ymlpath = path.resolve(__dirname);

const EnvBase = require('../../../support/env');

// These global variables are for the search screen keyboard
// navigation.
const rowIndexArray = [];
const columnIndexArray = [];
const leftRightArray = [];
const downUpArray = [];
const actionArray = [];
const spaceIndexArray = [];

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }

  // This is a map of the search screen keyboard.
  // The space character is translated to '$'
  // and delete is translated to '<'
  searchKeyboardLayout = {
    0: ['a', 'b', 'c', 'd', 'e', 'f'],
    1: ['g', 'h', 'i', 'j', 'k', 'l'],
    2: ['m', 'n', 'o', 'p', 'q', 'r'],
    3: ['s', 't', 'u', 'v', 'w', 'x'],
    4: ['y', 'z', '1', '2', '3', '4'],
    5: ['5', '6', '7', '8', '9', '0'],
    6: ['<', '$', '*', '*', '*', '*'],
  };

  setTextForVizio = async (text) => {
    await suitest.assert.element({ active: true }).setText(text);
    await commons.userAction(VRC.UP);
  };

  typeTextVizioCustomKeyboard = async (text) => {
    let currentXIndex = 1;
    let currentYIndex = 0;
    let currentKeyboard = 0;
    let uppercase = false;
    const keyboardZeroIndices = {
      upperCase: [0, 0],
      q: [1, 0],
      w: [2, 0],
      e: [3, 0],
      r: [4, 0],
      t: [5, 0],
      y: [6, 0],
      u: [7, 0],
      i: [8, 0],
      o: [9, 0],
      p: [10, 0],
      done: [11, 0],
      keyboardOne: [0, 1],
      a: [1, 1],
      s: [2, 1],
      d: [3, 1],
      f: [4, 1],
      g: [5, 1],
      h: [6, 1],
      j: [7, 1],
      k: [8, 1],
      l: [9, 1],
      backspace: [11, 1],
      keyboardTwo: [0, 2],
      z: [1, 2],
      x: [2, 2],
      c: [3, 2],
      v: [4, 2],
      b: [5, 2],
      n: [6, 2],
      m: [7, 2],
      clear: [11, 2],
      keyboardThree: [0, 3],
      ',': [1, 3],
      ' ': [5, 3],
      '.': [10, 3],
      close: [11, 3],
    };
    const keyboardTwoIndices = {
      upperCase: [0, 0],
      1: [1, 0],
      2: [2, 0],
      3: [3, 0],
      4: [4, 0],
      5: [5, 0],
      6: [6, 0],
      7: [7, 0],
      8: [8, 0],
      9: [9, 0],
      0: [10, 0],
      done: [11, 0],
      keyboardZero: [0, 1],
      '@': [1, 1],
      '#': [2, 1],
      $: [3, 1],
      '%': [4, 1],
      '&': [5, 1],
      '-': [6, 1],
      '+': [7, 1],
      '(': [8, 1],
      ')': [9, 1],
      backspace: [11, 1],
      keyboardTwoExtras: [0, 2],
      '*': [1, 2],
      '"': [2, 2],
      "'": [3, 2],
      ':': [4, 2],
      ';': [5, 2],
      '!': [6, 2],
      '?': [7, 2],
      clear: [11, 2],
      keyboardFour: [0, 3],
      _: [1, 3],
      '/': [2, 3],
      ' ': [5, 3],
      ',': [9, 3],
      '.': [10, 3],
      close: [11, 3],
    };
    const keyboardZeroGrid = [
      ['upperCase', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'done'],
      [
        'keyboardOne',
        'a',
        's',
        'd',
        'f',
        'g',
        'h',
        'j',
        'k',
        'l',
        'blank',
        'backspace',
      ],
      [
        'keyboardTwo',
        'z',
        'x',
        'c',
        'v',
        'b',
        'n',
        'm',
        'blank',
        'blank',
        'blank',
        'clear',
      ],
      [
        'keyboardThree',
        ',',
        'space',
        'space',
        'space',
        'space',
        'space',
        'space',
        'space',
        'space',
        '.',
        'close',
      ],
    ];
    const keyboardTwoGrid = [
      ['upperCase', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'done'],
      [
        'keyboardZero',
        '@',
        '#',
        '$',
        '%',
        '&',
        '-',
        '+',
        '(',
        ')',
        'blank',
        'backspace',
      ],
      [
        'keyboardTwoExtras',
        '*',
        '"',
        "'",
        ':',
        ';',
        '!',
        '?',
        'blank',
        'blank',
        'blank',
        'clear',
      ],
      [
        'keyboardThree',
        '_',
        '/',
        'space',
        'space',
        'space',
        'space',
        'space',
        'space',
        ',',
        '.',
        'close',
      ],
    ];

    for (let i = 0; i < text.length; i++) {
      const letter = text.charAt(i);

      if (letter.toLowerCase() in keyboardZeroIndices) {
        if (currentKeyboard === 2) {
          await this.traverseKeyboard(
            keyboardTwoGrid,
            keyboardTwoIndices.keyboardZero[0],
            keyboardTwoIndices.keyboardZero[1],
            currentXIndex,
            currentYIndex,
            currentKeyboard,
          );
          await commons.userAction(VRC.ENTER);
          currentXIndex = 0;
          currentYIndex = 1;
          currentKeyboard = 0;
        }

        const targetXIndex = keyboardZeroIndices[letter.toLowerCase()][0];
        const targetYIndex = keyboardZeroIndices[letter.toLowerCase()][1];

        if (letter.toLowerCase() !== letter && uppercase === false) {
          await this.traverseKeyboard(
            keyboardZeroGrid,
            keyboardZeroIndices.upperCase[0],
            keyboardZeroIndices.upperCase[1],
            currentXIndex,
            currentYIndex,
            currentKeyboard,
          );
          await commons.userAction(VRC.ENTER);
          currentXIndex = 0;
          currentYIndex = 0;
          uppercase = true;
        } else if (
          letter.toLowerCase() === letter &&
          uppercase === true &&
          letter.match(/[a-z]/i)
        ) {
          await this.traverseKeyboard(
            keyboardZeroGrid,
            keyboardZeroIndices.upperCase[0],
            keyboardZeroIndices.upperCase[1],
            currentXIndex,
            currentYIndex,
            currentKeyboard,
          );
          await commons.userAction(VRC.ENTER);
          currentXIndex = 0;
          currentYIndex = 0;
          uppercase = false;
        }

        await this.traverseKeyboard(
          keyboardZeroGrid,
          targetXIndex,
          targetYIndex,
          currentXIndex,
          currentYIndex,
          currentKeyboard,
        );

        currentXIndex = targetXIndex;
        currentYIndex = targetYIndex;
      } else if (letter in keyboardTwoIndices) {
        if (currentKeyboard === 0) {
          await this.traverseKeyboard(
            keyboardZeroGrid,
            keyboardZeroIndices.keyboardTwo[0],
            keyboardZeroIndices.keyboardTwo[1],
            currentXIndex,
            currentYIndex,
            currentKeyboard,
          );
          await commons.userAction(VRC.ENTER);
          currentXIndex = 0;
          currentYIndex = 2;
          currentKeyboard = 2;
        }

        const targetXIndex = keyboardTwoIndices[letter][0];
        const targetYIndex = keyboardTwoIndices[letter][1];

        await this.traverseKeyboard(
          keyboardTwoGrid,
          targetXIndex,
          targetYIndex,
          currentXIndex,
          currentYIndex,
          currentKeyboard,
        );

        currentXIndex = targetXIndex;
        currentYIndex = targetYIndex;
      }

      await commons.userAction(VRC.ENTER);
    }

    if (currentKeyboard === 0) {
      await this.traverseKeyboard(
        keyboardZeroGrid,
        keyboardZeroIndices.done[0],
        keyboardZeroIndices.done[1],
        currentXIndex,
        currentYIndex,
        currentKeyboard,
      );
    } else if (currentKeyboard === 2) {
      await this.traverseKeyboard(
        keyboardTwoGrid,
        keyboardTwoIndices.done[0],
        keyboardTwoIndices.done[1],
        currentXIndex,
        currentYIndex,
        currentKeyboard,
      );
    }
    await commons.userAction(VRC.ENTER);
  };

  traverseKeyboard = async (
    keyboardGrid,
    targetXIndex,
    targetYIndex,
    xIndex,
    yIndex,
    currentKeyboard,
  ) => {
    let currentXIndex = xIndex;
    let currentYIndex = yIndex;

    while (targetYIndex < currentYIndex) {
      const currentKey = keyboardGrid[currentYIndex][currentXIndex];

      if (currentKey === 'space') {
        currentXIndex = 5;
      } else if (currentKey === ',') {
        if (currentKeyboard === 0) {
          currentXIndex = 1;
        } else if (currentKeyboard === 2) {
          currentXIndex = 7;
        }
      } else if (currentKey === '.') {
        currentXIndex = 7;
      } else if (currentKey === '_') {
        currentXIndex = 1;
      } else if (currentKey === '/') {
        currentXIndex = 2;
      }

      currentYIndex--;
      await commons.userAction(VRC.UP, 1, 0.05);
    }
    while (targetYIndex > currentYIndex) {
      currentYIndex++;
      await commons.userAction(VRC.DOWN, 1, 0.05);

      let currentKey = keyboardGrid[currentYIndex][currentXIndex];

      while (currentKey === 'blank') {
        currentXIndex--;
        currentKey = keyboardGrid[currentYIndex][currentXIndex];
      }
    }
    while (targetXIndex < currentXIndex) {
      let currentKey = keyboardGrid[currentYIndex][currentXIndex];

      if (currentKey === 'space') {
        if (currentKeyboard === 0) {
          currentXIndex = 2;
        } else if (currentKeyboard === 2) {
          currentXIndex = 3;
        }
      }

      currentXIndex--;
      await commons.userAction(VRC.LEFT, 1, 0.05);

      while (currentKey === 'blank') {
        currentXIndex--;
        currentKey = keyboardGrid[currentYIndex][currentXIndex];
      }
    }
    while (targetXIndex > currentXIndex) {
      let currentKey = keyboardGrid[currentYIndex][currentXIndex];

      if (currentKey === 'space') {
        if (currentKeyboard === 0) {
          currentXIndex = 9;
        } else if (currentKeyboard === 2) {
          currentXIndex = 8;
        }
      }

      currentXIndex++;
      await commons.userAction(VRC.RIGHT, 1, 0.05);

      while (currentKey === 'blank') {
        currentXIndex++;
        currentKey = keyboardGrid[currentYIndex][currentXIndex];
      }
    }
  };

  /**
   * This function returns an array that determines how to navigate
   * the keyboard and the associated button presses.
   *
   * @param {string} searchContent - content to search
   */
  prepareUserActionArray = async (searchContent) => {
    const searchString = searchContent.toLowerCase().split(/[ ,]+/).join('$');

    await this.#getRowColumnIndices(searchString);
    this.#correctColumnArray();
    await this.#fillActionArray();
    return actionArray;
  };

  /**
   * This private function gets the row and column indices of the letters
   * in the search content from the class member searchKeyboardLayout.
   *
   * @param {string} searchString - content to search
   */
  #getRowColumnIndices = async (searchString) => {
    let rowIndex = 0;
    let columnIndex = 0;

    for (let i = 0; i < searchString.length; i++) {
      for (
        let j = 0;
        j < (await Object.keys(this.searchKeyboardLayout).length);
        j++
      ) {
        if (
          await Object.values(this.searchKeyboardLayout)[j].includes(
            searchString[i],
          )
        ) {
          columnIndex = await Object.values(this.searchKeyboardLayout)[
            j
          ].indexOf(searchString[i]);

          await columnIndexArray.push(columnIndex);
          rowIndex = j;
          await rowIndexArray.push(rowIndex);
        }
      }
      if (searchString[i] === '$') {
        await spaceIndexArray.push(i);
      } else {
        await spaceIndexArray.push('%');
      }
    }
  };

  /**
   * This private function is used to modify the column indices to allow
   * navigation to be consistent when the search string contains a space.
   * Because space is part of a different grid in the layout, this modification
   * becomes necessary.
   *
   */
  #correctColumnArray = () => {
    let isFirstSpaceInstance = true;

    for (let i = 0; i < columnIndexArray.length; i++) {
      if (spaceIndexArray[i] !== '%' && isFirstSpaceInstance) {
        isFirstSpaceInstance = false;
        columnIndexArray[i] = columnIndexArray[i - 1] + 1;
      } else if (spaceIndexArray[i] !== '%' && !isFirstSpaceInstance) {
        columnIndexArray[i] = columnIndexArray[i - 1];
      }
    }
  };

  /**
   * This private function populates a 2D action array which is what is
   * ultimately returned to perform the user actions.
   *
   */
  #fillActionArray = async () => {
    await leftRightArray.push(columnIndexArray[0]);
    await downUpArray.push(rowIndexArray[0]);
    for (let i = 1; i < columnIndexArray.length; i++) {
      if (spaceIndexArray[i - 1] !== '%') {
        await leftRightArray.push(
          columnIndexArray[i] - columnIndexArray[i - 2],
        );
      } else {
        await leftRightArray.push(
          columnIndexArray[i] - columnIndexArray[i - 1],
        );
      }
      await downUpArray.push(rowIndexArray[i] - rowIndexArray[i - 1]);
    }

    for (let i = 0; i < downUpArray.length; i++) {
      actionArray.push([downUpArray[i], leftRightArray[i]]);
    }
  };

  /**
   * This function returns an array that determines how to navigate
   * the keyboard and the associated button presses.
   *
   * @param {string} userActions - array containing user actions
   * @param {string} speedNav - array containing user actions
   * @param {string} speedPress - array containing user actions
   */
  traverseSearchKeyboard = async (userActions, speedNav, speedPress) => {
    for (let i = 0; i < userActions.length; i++) {
      if (userActions[i][0] < 0) {
        await commons.userAction(
          VRC.UP,
          Math.abs(Number(userActions[i][0])),
          speedNav,
        );
      } else if (userActions[i][0] > 0) {
        await commons.userAction(
          VRC.DOWN,
          Math.abs(Number(userActions[i][0])),
          speedNav,
        );
      }
      if (userActions[i][1] < 0) {
        await commons.userAction(
          VRC.LEFT,
          Math.abs(Number(userActions[i][1])),
          speedNav,
        );
      } else if (userActions[i][1] > 0) {
        await commons.userAction(
          VRC.RIGHT,
          Math.abs(Number(userActions[i][1])),
          speedNav,
        );
      }
      await commons.userAction(VRC.SELECT, 1, speedPress);
    }
  };
}

module.exports = {
  remoteActions,
  testdataHelper,
  BasePage,
};
