const path = require('path');

const {
  remoteActions,
  customErrors,
  testdataHelper,
} = require('@wbd/gqa-core/support');

const ymlpath = path.resolve(__dirname);

const EnvBase = require('../../../support/env');

const { skipReason } = require('../../../support/skipReason');

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }
}

module.exports = {
  remoteActions,
  customErrors,
  skipReason,
  testdataHelper,
  BasePage,
};
