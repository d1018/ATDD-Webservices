const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  focusedSettingMenuItem = this.#getSelectorData('focusedSettingMenuItem');

  signIn_btn = this.getElementByPage('signInPage', 'signIn_btn');

  focusedSignIn_btn = this.getElementByPage('signInPage', 'focusedSignIn_btn');

  focusedHomeTab = this.getElementByPage('homePage', 'focusedHomeTab');

  homeTab_lbl = this.getElementByPage('homePage', 'homeTab_lbl');

  whoIsWatching_label = this.getElementByPage(
    'profilePage',
    'whoIsWatching_label',
  );

  focusedProfile = this.getElementByPage('profilePage', 'focusedProfile');

  focusedProfilePicker = this.getElementByPage(
    'profilePage',
    'focusedProfilePicker',
  );

  focused_child_texture_text = this.getElementByPage(
    'genericLocator',
    'focused_child_texture_text',
  );

  focusedMyStuffPage = this.getElementByPage(
    'myStuffPage',
    'focusedMyStuffPage',
  );

  focusedHomeMenuItem = this.getElementByPage(
    'menuPage',
    'focusedHomeMenuItem',
  );

  pageFocused = {
    Home: this.focusedHomeTab,
  };

  assertPage = async (pageValue) => {
    await commons.assertExists(this.pageFocused[pageValue], 20);
  };

  openMenu = async () => {
    await commons.tryUntil(this.focusedHomeMenuItem, VRC.BACK, 3, 1);
    await commons.assertExists(this.focusedHomeMenuItem);
  };

  navigateToPage = async (pageValue) => {
    switch (pageValue) {
      case 'Signin':
        await commons.waitUntil(this.signIn_btn, 20);
        await commons.tryUntil(this.focusedSignIn_btn, VRC.RIGHT, 6, 1);
        await commons.userAction(VRC.ENTER);
        break;
      default:
        if (await commons.elementExists(this.whoIsWatching_label, 10)) {
          await commons.userAction(VRC.ENTER);
        }
        await this.openMenu();
        await commons.tryUntil(this.focusedProfilePicker, VRC.UP, 5);
        if (pageValue !== 'Profile') {
          await commons.tryUntil(
            this.getCustomLocator(this.focused_child_texture_text, pageValue),
            VRC.DOWN,
            5,
          );
        }
        await commons.userAction(VRC.ENTER);
        break;
    }
  };
}

module.exports = new MenuPage();
