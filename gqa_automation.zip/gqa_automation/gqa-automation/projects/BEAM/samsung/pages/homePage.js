const { remoteActions, BasePage } = require('./basePage');
const menuPage = require('./menuPage');
const settingsPage = require('./settingsPage');

const commons = remoteActions;

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  myListRail_lbl = this.#getSelectorData('myListRail_lbl');

  verifyMyListRailOnHomePage = async (railStatus) => {
    await menuPage.navigateToPage('Home');
    if (railStatus) {
      await commons.assertExists(this.myListRail_lbl);
    } else {
      await commons.assertDoesNotExist(this.myListRail_lbl);
    }
  };

  signOut = async () => {
    await menuPage.navigateToPage('Settings');
    await settingsPage.signOut();
  };
}

module.exports = new HomePage();
