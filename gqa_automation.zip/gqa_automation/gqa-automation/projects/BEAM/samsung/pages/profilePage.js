const { remoteActions, BasePage } = require('./basePage');

const menuPage = require('./menuPage');

const commons = remoteActions;

const { VRC } = commons;

let ProfileTypeName;

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  focusedProfile_button = this.#getSelectorData('focusedProfile_button');

  profileAvatarPage_title = this.#getSelectorData('profileAvatarPage_title');

  focusedAvatarImage = this.#getSelectorData('focusedAvatarImage');

  focusedProfileName_field = this.#getSelectorData('focusedProfileName_field');

  focusedFirstProfile = this.#getSelectorData('focusedFirstProfile');

  addProfile_button = this.#getSelectorData('addProfile_button');

  whoIsWatching_label = this.#getSelectorData('whoIsWatching_label');

  focusedAddProfile_button = this.#getSelectorData('focusedAddProfile_button');

  focusedAvatar = this.#getSelectorData('focusedAvatar');

  edit_profile_text = this.#getSelectorData('edit_profile_text');

  focusedDone_button = this.#getSelectorData('focusedDone_button');

  focusedProfilePicker = this.#getSelectorData('focusedProfilePicker');

  focusedHomeTab = this.getElementByPage('homePage', 'focusedHomeTab');

  delete_button = this.#getSelectorData('delete_button');

  done_button = this.#getSelectorData('done_button');

  deleteProfilePage_title = this.#getSelectorData('deleteProfilePage_title');

  focusedEditProfileName_field = this.#getSelectorData(
    'focusedEditProfileName_field',
  );

  focusedDeletePageDelete_button = this.#getSelectorData(
    'focusedDeletePageDelete_button',
  );

  focusedDeleteProfile_button = this.#getSelectorData(
    'focusedDeleteProfile_button',
  );

  focusedDelete_button = this.#getSelectorData('focusedDelete_button');

  focusedProfile = this.#getSelectorData('focusedProfile');

  focusedProfileCreationDone_button = this.#getSelectorData(
    'focusedProfileCreationDone_button',
  );

  moveToFirstProfile = async () => {
    await commons.assertExists(this.focusedProfile, 25);
    await commons.tryUntil(this.focusedFirstProfile, VRC.LEFT, 4, 2);
    await commons.assertExists(this.focusedFirstProfile, 5);
  };

  verifyProfileScreen = async () => {
    await commons.assertExists(this.focusedProfile, 25);
    await commons.assertExists(this.whoIsWatching_label, 20);
  };

  selectProfile = async () => {
    await this.moveToFirstProfile();
    await commons.userAction(VRC.ENTER);
  };

  createNewProfileAndMoveToEdit = async (profileType) => {
    await commons.assertExists(this.whoIsWatching_label, 20);
    await commons.tryUntil(this.focusedAddProfile_button, VRC.RIGHT, 6, 2);
    await commons.assertExists(this.focusedAddProfile_button);
    await commons.userAction(VRC.ENTER);
    await commons.waitUntil(this.focusedAvatar, 10);
    await commons.assertExists(this.focusedAvatar);
    await commons.tryUntil(this.edit_profile_text, VRC.ENTER, 5);
    await commons.userAction(VRC.ENTER, 2, 5);
    await commons.sendText(profileType);
    await commons.userAction(VRC.BACK, 1, 5);
    await commons.tryUntil(this.focusedDone_button, VRC.DOWN, 5, 5);
    await commons.assertExists(this.focusedDone_button);
    await commons.userAction(VRC.ENTER, 1, 5);
  };

  editUserProfile = async () => {
    await commons.assertExists(this.whoIsWatching_label, 2);
    await commons.userAction(VRC.DOWN, 1, 2);
    await commons.userAction(VRC.ENTER, 1, 2);
    await commons.assertExists(this.edit_profile_text, 5);
    await commons.userAction(VRC.ENTER, 1, 5);
    await commons.userAction(VRC.LEFT, 1, 5);
    await commons.userAction(VRC.UP, 1, 5);
    await commons.userAction(VRC.ENTER, 3, 3);
    await commons.userAction(VRC.BACK, 1, 5);
    await commons.tryUntil(this.focusedDone_button, VRC.DOWN, 5, 5);
    await commons.assertExists(this.focusedDone_button);
    await commons.userAction(VRC.ENTER, 1, 2);
  };

  verifyEditedProfile = async () => {
    await commons.assertExists(this.whoIsWatching_label, 2);
    await commons.userAction(VRC.ENTER, 1, 2);
  };

  createNewProfile = async (newProfileName) => {
    await commons.assertExists(this.whoIsWatching_label, 20);
    await commons.tryUntil(this.focusedAddProfile_button, VRC.RIGHT, 6, 2);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.focusedAvatar, 20);
    await commons.userAction(VRC.ENTER);
    await commons.tryUntil(this.focusedEditProfileName_field, VRC.UP, 2, 2);
    await commons.userAction(VRC.ENTER);
    await commons.sendText(newProfileName);
    await commons.userAction(VRC.BACK);
    await commons.tryUntil(this.focusedDone_button, VRC.DOWN, 5, 3);
    await commons.userAction(VRC.ENTER);
  };

  profileCreation = async (profileType) => {
    const timeStamp = Math.floor(Date.now() / 10);

    ProfileTypeName = profileType.charAt(0) + timeStamp;

    await commons.assertExists(this.whoIsWatching_label, 20);

    if (await commons.doesNotExist(this.addProfile_button, 10)) {
      await this.deleteExistingProfile();
    }
    await commons.assertExists(this.addProfile_button, 5);
    await this.createNewProfile(ProfileTypeName);
    await commons.assertExists(this.focusedProfile, 10);

    // By default after profile creation, focus should be on the created profile
    await commons.assertExists(
      this.getCustomLocator(this.focusedProfile_button, ProfileTypeName),
    );
    await commons.assertExists(this.focusedProfile, 6);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.focusedHomeTab, 30);
  };

  deleteExistingProfile = async () => {
    if (await commons.doesNotExist(this.focusedProfile, 10)) {
      await menuPage.navigateToPage('Profile');
    }

    await commons.assertExists(this.focusedProfile, 5);
    await commons.tryUntil(this.focusedFirstProfile, VRC.LEFT, 6);
    await commons.userAction(VRC.DOWN);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.done_button, 10);

    for (let i = 0; i < 3; i++) {
      if (await commons.doesNotExist(this.delete_button, 4)) {
        await commons.userAction(VRC.BACK);
        await commons.assertExists(this.focusedProfile, 10);
        await commons.userAction(VRC.RIGHT);
        await commons.userAction(VRC.DOWN);
        await commons.userAction(VRC.ENTER);
      } else {
        break;
      }
    }
    await commons.tryUntil(this.focusedDone_button, VRC.DOWN, 5);
    await commons.tryUntil(this.focusedDelete_button, VRC.RIGHT, 1);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.deleteProfilePage_title, 10);
    await commons.tryUntil(this.focusedDeletePageDelete_button, VRC.RIGHT, 5);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.addProfile_button);
  };
}

module.exports = new ProfilePage();
