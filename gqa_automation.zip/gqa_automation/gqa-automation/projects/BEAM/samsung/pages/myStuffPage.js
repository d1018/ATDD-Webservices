const { remoteActions, BasePage } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class MyStuffPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myStuffPage', locator);
  }

  myListTab_lbl = this.#getSelectorData('myListTab_lbl');

  noSavedTitles_txt = this.#getSelectorData('noSavedTitles_txt');

  focusedMyStuffPage = this.#getSelectorData('focusedMyStuffPage');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  homeTab_lbl = this.getElementByPage('homePage', 'homeTab_lbl');

  continueWatchingRail = this.getElementByPage(
    'homePage',
    'continueWatchingRail',
  );

  focusedRail = this.getElementByPage('homePage', 'focusedRail');

  focusedWatchNow_btn = this.getElementByPage(
    'searchPage',
    'focusedWatchNow_btn',
  );

  focusedMyListAdd_btn = this.getElementByPage(
    'searchPage',
    'focusedMyListAdd_btn',
  );

  focusedMyListRemove_btn = this.getElementByPage(
    'searchPage',
    'focusedMyListRemove_btn',
  );

  focusedSearchPage = this.getElementByPage('searchPage', 'focusedSearchPage');

  myListTabShowAdded_lbl = this.#getSelectorData('myListTabShowAdded_lbl');

  selectMyList = async () => {
    await commons.assertExists(this.myListTab_lbl, 5);
    await commons.userAction(VRC.ENTER);
  };

  verifyMyListContent = async () => {
    await commons.assertExists(this.myListTab_lbl, 5);
    await commons.userAction(VRC.DOWN);
    await commons.assertExists(this.noSavedTitles_txt);
  };

  navigateToShowTileInHomePage = async () => {
    await commons.assertExists(this.homeTab_lbl, 10);
    await commons.userAction(VRC.DOWN, 2, 2);
    await commons.assertExists(this.continueWatchingRail, 5);
    await commons.userAction(VRC.DOWN);
    await commons.assertExists(this.focusedRail, 2);
    await commons.userAction(VRC.ENTER);
  };

  addShowToMylistFromHomePage = async () => {
    await commons.assertExists(this.focusedWatchNow_btn, 5);
    await commons.userAction(VRC.RIGHT);
    await commons.assertExists(this.focusedMyListAdd_btn, 5);
    await commons.userAction(VRC.ENTER);
  };

  addShowsToMylist = async () => {
    await commons.userAction(VRC.BACK);
    await commons.assertExists(this.focusedHomePage, 5);
    await commons.userAction(VRC.ENTER);
    await this.navigateToShowTileInHomePage();
    await this.addShowToMylistFromHomePage();
    await commons.assertExists(this.focusedMyListRemove_btn, 5);
  };

  verifyMyListData = async (isShowPresent) => {
    await commons.userAction(VRC.LEFT, 3, 2);
    await commons.assertExists(this.focusedSearchPage, 5);
    await commons.tryUntil(this.focusedMyStuffPage, VRC.DOWN, 3, 2);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.myListTab_lbl, 5);
    await commons.userAction(VRC.DOWN);
    if (isShowPresent) {
      await commons.assertExists(this.myListTabShowAdded_lbl, 5);
    } else {
      await commons.assertDoesNotExist(this.myListTabShowAdded_lbl, 5);
    }
    await commons.userAction(VRC.BACK);
  };
}

module.exports = new MyStuffPage();
