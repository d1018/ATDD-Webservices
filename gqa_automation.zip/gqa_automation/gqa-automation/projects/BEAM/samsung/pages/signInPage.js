const { remoteActions, BasePage } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

let featureName;

/**
 *
 * @param {number} min must be minimal integer range as per .env test accounts
 * @param {number} max must be maximum integer range as per .env test accounts
 * @returns {number} random number between min & max range
 */
function randomIntFromInterval(min, max) {
  // min and max included
  return Math.floor(Math.random() * (max - min + 1) + min);
}

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  focusedSignIn_btn = this.#getSelectorData('focusedSignIn_btn');

  signInContainer = this.#getSelectorData('signInContainer');

  focusedScanQR = this.#getSelectorData('focusedScanQR');

  focusedUseRemote = this.#getSelectorData('focusedUseRemote');

  userName_txtBx = this.#getSelectorData('userName_txtBx');

  focusedUserName_txtBx = this.#getSelectorData('focusedUserName_txtBx');

  password_txtBx = this.#getSelectorData('password_txtBx');

  focusedPassword_txtBx = this.#getSelectorData('focusedPassword_txtBx');

  focusedHomeTab = this.getElementByPage('homePage', 'focusedHomeTab');

  focusedSideBar = this.getElementByPage('menuPage', 'focusedSideBar');

  focusedProfile = this.getElementByPage('menuPage', 'focusedProfile');

  startStreaming_text = this.getElementByPage(
    'welcomePage',
    'startStreaming_text',
  );

  streamingSignin_btn = this.getElementByPage(
    'welcomePage',
    'streamingSignin_btn',
  );

  openApp = async () => {
    await commons.clearAppData();
    // For Headspin devices still logged in from previous sessions
    await commons.closeApp();
    await commons.openApp();
    await commons.assertExists(this.startStreaming_text, 60);
  };

  async getCreds(credentialType) {
    let creds;
    const feature = await this.getFeatureName();

    featureName = feature.gherkinDocument.feature.name;
    if (featureName === 'Member Feed') {
      creds = `${credentialType}${randomIntFromInterval(1, 3)}`;
    } else if (featureName === 'Account Page') {
      creds = `${credentialType}${randomIntFromInterval(1, 3)}`;
    } else if (featureName === 'User Profiles Functionality') {
      creds = `${credentialType}${randomIntFromInterval(1, 3)}`;
    }
    return creds;
  }

  navigateToSignInScreen_US = async () => {
    if (await commons.doesNotExist(this.startStreaming_text, 40)) {
      await commons.closeApp();
      await commons.openApp();
    }

    await commons.waitUntil(this.startStreaming_text);
    await commons.userAction(VRC.RIGHT, 2, 2);
    await commons.assertExists(this.streamingSignin_btn);
    await commons.userAction(VRC.ENTER);
    await commons.assertVisible(this.focusedScanQR, 20);
    await commons.tryUntil(this.focusedUseRemote, VRC.DOWN, 4, 5);
    await commons.assertVisible(this.signInContainer, 10);
  };

  enterCredentials = async (credentialType) => {
    const username = process.env[`${credentialType}_USERNAME`];
    const password = process.env[`${credentialType}_PASSWORD`];

    // selecting the password field and entering password
    await commons.assertExists(this.userName_txtBx);
    await commons.tryUntil(this.focusedUserName_txtBx, VRC.RIGHT, 2, 2);
    await commons.assertExists(this.focusedUserName_txtBx);
    await commons.userAction(VRC.ENTER, 1, 5);
    await commons.sendText(username);
    await commons.userAction(VRC.BACK, 1, 2);
    await commons.tryUntil(this.focusedPassword_txtBx, VRC.DOWN, 2, 2);
    await commons.assertExists(this.focusedPassword_txtBx);
    await commons.userAction(VRC.ENTER, 1, 2);
    await commons.sendText(password);
    await commons.userAction(VRC.BACK, 1, 2);
    await commons.userAction(VRC.DOWN);
    await commons.assertExists(this.focusedSignIn_btn);
  };

  verifySignOut = async () => {
    await commons.assertExists(this.signIn_btn, 10);
  };

  loginToApplication = async (credentialType) => {
    await this.navigateToSignInScreen_US();
    await this.enterCredentials(credentialType);
    await commons.userAction(VRC.ENTER, 1, 2);
  };
}
module.exports = new SignInPage();
