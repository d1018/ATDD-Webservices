const signInPage = require('./signInPage');
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');
const homePage = require('./homePage');
const settingsPage = require('./settingsPage');
const myStuffPage = require('./myStuffPage');
const searchPage = require('./searchPage');

module.exports = {
  signInPage,
  menuPage,
  profilePage,
  homePage,
  settingsPage,
  myStuffPage,
  searchPage,
};
