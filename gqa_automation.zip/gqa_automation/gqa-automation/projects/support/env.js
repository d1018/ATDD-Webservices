const yaml = require('js-yaml');
const path = require('path');
const fs = require('fs');
const {
  After,
  BeforeAll,
  Before,
  AfterAll,
  AfterStep,
  Status,
  setDefaultTimeout,
} = require('@wbd/gqa-core');

const { globalHooks } = require('@wbd/gqa-core/support');
const projectsTestrailConfig = require('./testrail_config.json');
const { skipReason } = require('./skipReason');

const projectValue = process.env.PROJECT;
const testrailConfig = projectsTestrailConfig[projectValue];
let properties = {};
let gherkinDocumentObject;

setDefaultTimeout(6 * 60 * 1000);

BeforeAll({ timeout: -1 }, async function beforeAll() {
  await globalHooks.beforeAll(this, testrailConfig);
});

Before({ timeout: 5 * 60 * 1000 }, async function before(scenario) {
  await globalHooks.before(this, testrailConfig, scenario);
  gherkinDocumentObject = scenario;
});

AfterAll({ timeout: 1.5 * 60 * 1000 }, async () => {
  await globalHooks.afterAll(this, testrailConfig);
});

After({ timeout: 3 * 60 * 1000 }, async function handler(scenario) {
  await globalHooks.after(testrailConfig, scenario, this, Status);
});

AfterStep({ timeout: 3 * 60 * 1000 }, async function handler(scenario) {
  await globalHooks.afterStep(this, scenario, Status, skipReason);
});

class EnvBase {
  constructor(ymlpath) {
    this.#objectInitialization(ymlpath);
  }

  countryCode = (process.env.GEO || 'us').toLowerCase();

  #objectInitialization(ymlpath) {
    properties = JSON.parse(
      JSON.stringify(
        yaml.load(
          fs.readFileSync(path.join(ymlpath, '..', `objects.yml`), {
            encoding: 'utf-8',
          }),
        ),
      ),
    );
  }

  getFeatureName = async () => {
    const featureName = await gherkinDocumentObject.gherkinDocument.feature
      .name;

    return featureName;
  };

  isCucumberTagPresent = async (tagName) => {
    const cucumberTags = [];
    const tags = await gherkinDocumentObject.pickle.tags;

    await tags.forEach((arrayItem) => {
      const listOfTags = arrayItem.name;

      cucumberTags.push(listOfTags);
    });
    return cucumberTags.includes(tagName);
  };

  getElementByPage = (pageName, locator) => {
    let selector = properties[pageName][locator];

    if (Array.isArray(selector)) {
      if (selector[0][this.countryCode]) {
        selector = selector[0][this.countryCode];
      } else {
        selector = selector[0].default;
      }
    }
    if (typeof selector === 'undefined') {
      throw new Error(`Locator not found: ${locator}`);
    }
    return selector;
  };

  getSelectorType = async (locator) => {
    const type = await Object.getOwnPropertyNames(locator).toString();

    return type;
  };

  getLocatorValue = async (locator) => {
    const value = await locator[`${this.getSelectorType(locator)}`].toString();

    return value;
  };

  returnGeoLocation = () => {
    if (['us', 'ca', 'br'].includes(this.countryCode)) {
      return 'america';
    }
    if (
      [
        'se',
        'dk',
        'fi',
        'no',
        'nl',
        'es',
        'gb',
        'it',
        'ie',
        'de',
        'at',
      ].includes(this.countryCode)
    ) {
      return 'emea';
    }
    if (['ph'].includes(this.countryCode)) {
      return 'apac';
    }
    throw new Error('GEO location is not recognized!!!', this.countryCode);
  };

  /**
   * This method will require locator and replaceValue as inputs.
   * The locator should have placeholder as $#$ which will be replaced by the text passed as replaceValue - parameter
   *
   * @param {object} locator locator object with special char $#$ (i.e) { xpath: "//CustomButton[@id='$#$']" }
   * @param {*} replaceValue value to replace
   * @returns {object} custom locator object.
   */
  getCustomLocator = (locator, replaceValue) =>
    JSON.parse(JSON.stringify(locator).replace('$#$', replaceValue));
}

module.exports = EnvBase;
