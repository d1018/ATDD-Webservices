const path = require('path');
const fs = require('fs');
const logger = require('jake/lib/utils/logger');

let responseData;
const events = [];
const parent = '.';
const failArray = [];

class AdtechHelper {
  extractTrackingBeaconData = async (
    response,
    methodType,
    urlRegex,
    beaconType,
    adType,
  ) => {
    let beaconsData = [];

    await response.log.entries.forEach((req) => {
      if (
        req.request.method.toString().includes(methodType) &&
        req.request.url.toString().includes(urlRegex)
      ) {
        responseData = JSON.parse(req.response.content.text);

        beaconsData = this.storeTrackingbeaconData(
          responseData,
          beaconType,
          adType,
        ).then((data) => data);

        this.verifyBeaconsArchival(beaconsData);

        /**
         * URL validation part is pending. Needs to be coded here
         * this.validateUrls(beaconsData);
         */
      }
    });
    return beaconsData;
  };

  /* eslint-disable no-continue, require-await */
  storeTrackingbeaconData = async (response, beaconType, adType) => {
    const beaconsData = [];
    const { breaks } = response.data.attributes.ssaiInfo.vendorAttributes;

    const breaksLength = Object.keys(breaks).length;

    for (let i = 0; i < breaksLength; i++) {
      const brk = breaks[i];

      if (adType === 'preroll') {
        if (brk.duration === 0 || brk.timeOffset !== 0) {
          continue;
        }
      } else if (adType === 'first') {
        if (brk.duration === 0 || brk.timeOffset === 0) {
          continue;
        }
      } else if (adType === 'second') {
        if (brk.duration === 0 || brk.position !== 'mid1') {
          continue;
        }
      }

      switch (beaconType) {
        case 'impressions':
          brk.ads.forEach((value) => {
            beaconsData.push(value.events.impressions);
          });
          break;
        case 'slot_impressions':
          beaconsData.push(brk.events.impressions);
          break;
        default:
          logger.error('Please enter valid beacon type.');
          break;
      }
      break;
    }
    return beaconsData.flat();
  };
  /* eslint-disable no-continue, require-await */

  verifyBeaconsArchival = async (beaconsData) => {
    if ((await beaconsData.length) === 0) {
      logger.log('Beacons are empty, please check the Logs for more Info');
    }
  };

  /* URL validation needs to be coded here */
  // validateUrls = async (beaconsData) => {
  //   if (beaconsData.length === 0) { console.log("Array is empty!") }
  // };

  extractAndCompareData = async (response, videoPlaybackInfoData) => {
    await response.log.entries.forEach((req) => {
      if (videoPlaybackInfoData.includes(req.request.url)) {
        events.push(req.request.url);
      }
    });

    return events;
  };

  fetchCsvName = async (csvName) => {
    // eslint-disable-next-line no-param-reassign
    csvName = (csvName + Date.now()).toString();
    const logsPath = path.resolve(path.join(parent, 'results', 'logs'));
    let csvPath = path.join(logsPath, 'csv');

    if (!fs.existsSync(logsPath)) {
      await fs.promises.mkdir(logsPath, { recursive: true });
    }

    if (!fs.existsSync(csvPath)) {
      await fs.promises.mkdir(csvPath, { recursive: true });
    }

    csvPath = path.join(csvPath, `${csvName}.csv`);

    logger.log(`Final csv path : ${csvPath}`);

    return csvPath;
  };

  /* eslint-disable no-param-reassign */
  copyInteractionDataToCSV = async (
    beaconsData,
    videoPlaybackInfoData,
    beacons,
    adType,
  ) => {
    const csvName = this.fetchCsvName(
      `${adType.trim().replaceAll(' ', '_')}_${beacons
        .trim()
        .replaceAll(' ', '_')}`,
    );

    // Beacons fired & Impressions from VideoPlaybackInfo API copying to CSV file
    let rows = [
      [`${beacons} from VideoPlaybackInfo API`, 'Beacons Fired during Ad PLay'],
    ];

    let columns;

    if (beaconsData.length >= videoPlaybackInfoData.length)
      columns = beaconsData.length;
    else columns = videoPlaybackInfoData.length;
    rows = await this.composeRowsForCsv(
      rows,
      columns,
      videoPlaybackInfoData,
      beaconsData,
    );
    let csvContent = '';

    rows.forEach((rowArray) => {
      rowArray[0] = rowArray[0].toString().replaceAll(',', '.');
      rowArray[1] = rowArray[1].toString().replaceAll(',', '.');
      const row = rowArray.join(',');

      csvContent += `${row}\r\n`;
    });

    fs.writeFile((await csvName).toString(), csvContent, (err) => {
      if (err) throw err;
      logger.log('CSV Saved!');
    });
  };

  /* eslint-disable no-param-reassign */
  composeRowsForCsv = async (
    rows,
    columns,
    videoPlaybackInfoData,
    beaconsData,
  ) => {
    for (let i = 0; i < columns; i++) {
      if (
        videoPlaybackInfoData[i] === '' ||
        typeof videoPlaybackInfoData[i] === 'undefined'
      ) {
        videoPlaybackInfoData[i] = 'null';
        failArray.push(beaconsData[i]);
      }
      rows.push([videoPlaybackInfoData[i]]);
    }

    await beaconsData.forEach((beacon, index) => {
      if (beacon === '' || typeof beacon === 'undefined') {
        beacon = 'null';
      }
      rows[index + 1].push(beacon);
    });

    return rows;
  };
  /* eslint-disable no-param-reassign */

  beaconsNotFiredData = async () => failArray;
}

module.exports = new AdtechHelper();
