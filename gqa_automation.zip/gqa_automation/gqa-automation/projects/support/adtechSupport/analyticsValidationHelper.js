const assert = require('assert');
const logger = require('jake/lib/utils/logger');
const { testdataHelper } = require('@wbd/gqa-core/support');
const adtechHelper = require('./adtechHelper');
const browserstack = require('./browserStack');
const splunkHelper = require('./splunkHelper');

let response;
let videoPlaybackInfoData = [];
let streamProviderSessionId;

class AnalyticsValidationHelper {
  fetchTrackingbeaconFromVideoplaybackinfo = async (beaconType, adType) => {
    videoPlaybackInfoData = await adtechHelper
      .extractTrackingBeaconData(
        response,
        'POST',
        'videoPlaybackInfo',
        beaconType,
        adType,
      )
      .then((data) => data);

    return videoPlaybackInfoData;
  };

  fetchBrowserstackAnalytics = async (bsSessionId) => {
    response = await browserstack.fetchNetworkLogUrls(bsSessionId);

    if (response.log.entries.length > 0) {
      return response;
    }
    return 'No response to return';
  };

  getStreamProviderSessionId = async (browserStackResponse) => {
    await browserStackResponse.log.entries.forEach((req) => {
      if (
        req.request.method.toString() === 'POST' &&
        req.request.url.toString().includes('videoPlaybackInfo')
      ) {
        const responseData = JSON.parse(req.response.content.text);

        streamProviderSessionId =
          responseData.data.attributes.ssaiInfo.vendorAttributes.sessionId.toString();

        logger.log(`streamProviderSessionId: ${streamProviderSessionId}`);
      }
    });
    return streamProviderSessionId;
  };

  getSessionIdFromBrowserStack = async (bsSessionId) => {
    response = await this.fetchBrowserstackAnalytics(bsSessionId);
    return this.getStreamProviderSessionId(response).then(
      (sessionId) => sessionId,
    );
  };

  fetchFiredImpressionUrls = async () =>
    // eslint-disable-next-line no-return-await
    await adtechHelper.extractAndCompareData(response, videoPlaybackInfoData);

  bsBeaconsValidation = async (bsSessionId, beaconType, adType) => {
    let definedImpressions = [];
    let firedImpressions = [];
    let fails = [];

    await this.getSessionIdFromBrowserStack(bsSessionId);

    definedImpressions = await this.fetchTrackingbeaconFromVideoplaybackinfo(
      beaconType,
      adType,
    );

    firedImpressions = await this.fetchFiredImpressionUrls();

    adtechHelper.copyInteractionDataToCSV(
      definedImpressions.sort(),
      firedImpressions.sort(),
      beaconType,
      adType,
    );

    fails = await adtechHelper.beaconsNotFiredData().then((data) => data);
    if (fails.length > 0) {
      logger.log(`The following beacons are not fired : ${fails}`);
      fails.forEach((beacon) => {
        if (!beacon.includes('visitanalytics')) {
          throw new Error(`The following beacons are not fired : ${fails}`);
        }
      });
    } else {
      logger.log('In else part assert');
      assert(
        JSON.stringify(definedImpressions.sort()) ===
          JSON.stringify(firedImpressions.sort()),
        `Some beacons are not fired`,
      );
    }
  };

  validate_gdpr = (
    splunkResults,
    clientProperties,
    adrequestParam,
    expectedParam,
  ) => {
    const fails = [];
    const expected = [clientProperties, adrequestParam];

    for (let index = 0; index < expected.length; index++) {
      const expectedArray = expected[index];

      if (splunkResults[expectedArray] !== expectedParam) {
        fails.push(
          `Expected ${expectedArray} value: ${expectedParam}
          Actual ${expectedArray} value: ${splunkResults[expectedArray]}`,
        );
      }
    }

    return fails;
  };

  validate_gdpr_consent = (
    geoLocation,
    splunkResults,
    clientProperties,
    adrequestParam,
  ) => {
    const fails = [];

    if (
      geoLocation === 'emea' &&
      splunkResults[clientProperties] !== splunkResults[adrequestParam]
    ) {
      fails.push(`
      Expected gdpr consent value: the value of fw_gdpr_consent should be equal to the value specified in clientProperties
      Actual gdpr consent value: the value of fw_gdpr_consent is not equal to the value specified in clientProperties
      `);
    } else if (
      (geoLocation === 'america' || geoLocation === 'apac') &&
      ((splunkResults[clientProperties] !== undefined &&
        splunkResults[clientProperties] !== '') ||
        (splunkResults[adrequestParam] !== undefined &&
          splunkResults[adrequestParam] !== ''))
    ) {
      fails.push(`
        Expected ${clientProperties} and ${adrequestParam} value: empty or undefined
        Actual ${clientProperties} value:  ${splunkResults[clientProperties]}
        Actual ${adrequestParam} value: ${splunkResults[adrequestParam]}
      `);
    }

    return fails;
  };

  validate_fwdid_and_gpaln = (
    splunkResults,
    clientProperties,
    adrequestParam,
  ) => {
    const fails = [];

    if (
      splunkResults[clientProperties] !== undefined &&
      splunkResults[clientProperties] !== ''
    ) {
      logger.log(
        `^^^WARNING^^^ Expected value of ${clientProperties} should be empty or undefined and actual value is : ${splunkResults[clientProperties]}`,
      );
    }
    if (
      splunkResults[adrequestParam] !== undefined &&
      splunkResults[adrequestParam] !== ''
    ) {
      fails.push(`
       Expected ${adrequestParam} value: empty or undefined
       Actual ${adrequestParam} value: ${splunkResults[adrequestParam]}
      `);
    }

    return fails;
  };

  validate_fwislat = (
    splunkResults,
    clientProperties,
    adrequestParam,
    expectedParam,
  ) => {
    const fails = [];

    if (splunkResults[clientProperties] !== expectedParam) {
      logger.log(
        `^^^WARNING^^^ Expected value of CP_fwIsLat Value is ${expectedParam} and actual value: ${splunkResults[clientProperties]}`,
      );
    }
    if (splunkResults[adrequestParam] !== expectedParam) {
      fails.push(`
       Expected ${adrequestParam} value: ${expectedParam}
       Actual ${adrequestParam} value: ${splunkResults[adrequestParam]}
      `);
    }

    return fails;
  };

  verifyAdRequestParameters = async (parameters, bsSessionId, geoLocation) => {
    const serverType = 'pbapi';
    const streamProviderSID = await this.getSessionIdFromBrowserStack(
      bsSessionId,
    );
    const splunkQuery = testdataHelper.getContent(`splunkQuery.searchQuery`);
    const searchQuery = splunkQuery.replace(/session_id/g, streamProviderSID);
    const splunkResults = await splunkHelper.fetchSplunkResults(
      serverType,
      searchQuery,
    );

    let fails = [];
    const passedParams = [];
    const adRequestParamsArray = parameters.raw().flat();

    for (let index = 0; index < adRequestParamsArray.length; index++) {
      const adrequestParam = adRequestParamsArray[index];
      const expectedParam = testdataHelper.getContent(
        `expectedAdRequestParams.${adrequestParam}`,
      );

      switch (adrequestParam) {
        case 'fw_gdpr':
          fails += this.validate_gdpr(
            splunkResults,
            'CP_gdpr',
            adrequestParam,
            expectedParam,
          );
          break;
        case 'fw_gdpr_consent':
          fails += this.validate_gdpr_consent(
            geoLocation,
            splunkResults,
            'CP_fwGdprConsent',
            adrequestParam,
          );
          break;
        case 'fw_did':
          fails += this.validate_fwdid_and_gpaln(
            splunkResults,
            'CP_fwDid',
            adrequestParam,
          );
          break;
        case 'fw_is_lat':
          fails += this.validate_fwislat(
            splunkResults,
            'CP_fwIsLat',
            adrequestParam,
            expectedParam,
          );
          break;
        case 'paln':
          fails += this.validate_fwdid_and_gpaln(
            splunkResults,
            'CP_gpaln',
            adrequestParam,
          );
          break;
        default:
          throw new Error('Ad request parameter not found');
      }
      passedParams.push(`${adrequestParam} : ${splunkResults[adrequestParam]}`);
    }

    assert.equal(
      fails.length === 0,
      true,
      `\nFailed Ad request Parameters are: ${fails}`,
    );

    logger.log(
      `Passed Ad request parameters are: \n${passedParams.join('\n')}`,
    );
  };
}

module.exports = new AnalyticsValidationHelper();
