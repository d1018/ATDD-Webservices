const fetch = require('node-fetch');
const retry = require('async-retry');
const logger = require('jake/lib/utils/logger');

const BS_VIDEO_API = 'https://api.browserstack.com/';

const authenticate = Object.freeze({
  url: BS_VIDEO_API,
  userName: process.env.BS_USER,
  password: process.env.BS_KEY,
});

const fetchGETcall = async (url) => {
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Basic ${Buffer.from(
        `${authenticate.userName}:${authenticate.password}`,
      ).toString('base64')}`,
    },
  })
    .then((resp) => resp.json())
    .then((responseJson) => responseJson);

  return response;
};

const fetchJSONResponse = async (sessionId, bsAuto) => {
  const url = `${authenticate.url}/${bsAuto}/sessions/${sessionId}.json`;

  const resp = await fetchGETcall(url);

  return resp;
};

const fetchNetworkLogUrls = async (sessionId) => {
  let response;
  let jsonResponse;
  let networkLogsUrl;

  if (process.env.DEVICE === 'web') {
    jsonResponse = await fetchJSONResponse(sessionId, 'automate');
    networkLogsUrl = jsonResponse.automation_session.logs.replaceAll(
      'logs',
      'networklogs',
    );
  } else {
    jsonResponse = await fetchJSONResponse(sessionId, 'app-automate');
    networkLogsUrl = jsonResponse.automation_session.device_logs_url.replaceAll(
      'devicelogs',
      'networklogs',
    );
  }

  logger.log(networkLogsUrl);

  try {
    await retry(
      async () => {
        response = await fetchGETcall(networkLogsUrl);
      },
      { retries: 20 },
    );
  } catch (e) {
    logger.error(`Error while fetching the reponse:`, e);
  }
  return response;
};

module.exports = {
  fetchGETcall,
  fetchJSONResponse,
  fetchNetworkLogUrls,
};
