const fetch = require('node-fetch');
const retry = require('async-retry');

const splunkCredential = Object.freeze({
  url: process.env.SPLUNK_URL,
  userName: process.env.SPLUNK_USERNAME,
  password: process.env.SPLUNK_PASSWORD,
});

/**
 * Fetches the Splunk sessionID using a supplied endpoint.
 *
 * @param {string} serverType based on different geo location.
 * @param {string} searchQuery splunk query to fetch the splunkSessionId.
 * @returns {object} SplunksessionID for a provided session.
 */
const fetchSplunkSid = async (serverType, searchQuery) => {
  const bodyString = `search index=${serverType} ${searchQuery}`;
  let splunkSessionId;

  try {
    const response = await fetch(
      `${splunkCredential.url}/services/search/jobs?output_mode=json`,
      {
        method: 'POST',
        headers: {
          Authorization: `Basic ${Buffer.from(
            `${splunkCredential.userName}:${splunkCredential.password}`,
          ).toString('base64')}`,
          Accept: 'application/json',
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({ search: bodyString }),
      },
    );

    splunkSessionId = await response.json();
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error(
      `Error in finding Splunk SessionID for streamProviderSessionId`,
      e,
    );
  }
  return splunkSessionId;
};

/**
 * Fetches the Adrequest parameters using the SplunksessionID
 *
 * @param {object} sessionId SplunksessionID for a particual session.
 * @returns {Promise<*>} Promise of API response formatted in JSON.
 */
const searchWithSid = async (sessionId) => {
  let requestParams;

  try {
    const response = await fetch(
      `${splunkCredential.url}/services/search/jobs/${sessionId}/results?output_mode=json`,
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Basic ${Buffer.from(
            `${splunkCredential.userName}:${splunkCredential.password}`,
          ).toString('base64')}`,
        },
      },
    );

    requestParams = response.json();
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error(
      `Error in fetching  Adrequest parameters using the SplunksessionID "${sessionId}":`,
      e,
    );
  }
  return requestParams;
};

/**
 * Fetches the Splunk query results using searchQuery,servertype & streamProviderSessionId.
 *
 * @param {string} serverType based on different geo location i.e wisteria or pbapi.
 * @param {string} searchQuery splunk query to fetch the splunkSessionId.
 * @returns {Promise<*>} Promise of API response formatted in JSON.
 */
const fetchSplunkResults = async (serverType, searchQuery) => {
  let response;
  const splunkSessionId = await fetchSplunkSid(serverType, searchQuery);

  if (splunkSessionId) {
    try {
      await retry(
        async () => {
          response = await searchWithSid(splunkSessionId.sid);
        },
        { retries: 5 },
      );
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error(`Error while fetching the requestUriparams:`, e);
    }

    if (response.results) {
      return response.results[0];
    }
    throw new Error(
      `Unable to search with sessiond id: ${splunkSessionId.sid}`,
    );
  } else {
    throw new Error('Unable to fetch sessionId');
  }
};

/**
 * Fetches the streamProviderSessionId by using Userid.
 *
 * @param {string} serverType based on different geo location i.e wisteria or pbapi.
 * @param {string} searchQueryWithUserId splunk query with userId appended.
 * @returns {object} streamprovierSessionId for a particular asset played.
 */
const fetchSessionIDUsingUserid = async (serverType, searchQueryWithUserId) => {
  let responseWithStreamproviderSid;
  const sessionID = await fetchSplunkSid(serverType, searchQueryWithUserId);

  try {
    await retry(
      async () => {
        responseWithStreamproviderSid = await searchWithSid(sessionID.sid);
      },
      { retries: 5 },
    );
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error(`Error while fetching the responseWithStreamproviderSid:`, e);
  }
  const streamProviderSessionid =
    responseWithStreamproviderSid.results[0].StreamProviderSessionId;

  return streamProviderSessionid;
};

module.exports = {
  fetchSplunkSid,
  searchWithSid,
  fetchSplunkResults,
  fetchSessionIDUsingUserid,
};
