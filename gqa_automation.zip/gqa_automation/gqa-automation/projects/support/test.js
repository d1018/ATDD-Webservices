const elementExists = async (selector) => {
    const test = selector;
    return false;
};

timeoutWrapper = async (timeoutMs, throwOnTimeout, fn) => {
    const wait = async (ms) => {
      await new Promise((resolve) => setTimeout(() => resolve(), ms));
      return 'TIMEOUT';
    };

    const promises = [wait(timeoutMs), fn()];
    const result = await Promise.race(promises);

    if (result === 'TIMEOUT' && throwOnTimeout) {
      throw new Error(`Function did not complete within (${timeoutMs}ms).`);
    }

    return result;
  };

  waitByFunc = async (fn, timeoutMs = 20000) => {
    const interval = 250;

    let exception;
    let success = false;

    await timeoutWrapper(timeoutMs, false, async () => {
      while (!success) {
        try {
          exception = undefined;
          success = !(await elementExists()) ;

          if (success) {
            break;
          }
        } catch (err) {
          exception = err;
        }

        await new Promise((resolve) => setTimeout(resolve, interval));
      }
    });

    if (success === false) {
      throw new Error(
        `Unable to complete function within timeout (${timeoutMs}ms): ${
          typeof exception === 'object'
            ? JSON.stringify(exception, null, 2)
            : exception
        }`,
      );
    }
  };


console.log(waitByFunc('testingDinesh', 30000))
