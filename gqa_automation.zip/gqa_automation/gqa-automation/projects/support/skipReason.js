const skipReason = {
  noLiveEvent: 'noLiveEvent',
  noLatestEventsRail: 'noLatestEventsRail',
  eventTypeUnavaiable: 'eventTypeUnavaiable',
  sportSonicDataUnavailable:
    'Proper data is not configured on sonic to show on application',
  sportsHomeCtaMismatch: 'sportsHomeCtaMismatch',
  sportsHomeLiveLabelPresent: 'sportsHomeLiveLabelPresent',
  noEpisodeRailFound: 'noEpisodeRailFound',
  noNextEpisode: 'noNextEpisode',
  noTVChannelShowDetails: 'noTVChannelShowDetails',
  noPrerollAd: 'prerollAd is not available',
  noClockIconInShowDetails: 'No Clock Icon Present In Show Details Screen',
  liveEventPresent: 'Live event is present',
  noSecondaryTitle: 'Secondary Title is not available',
  noWelcomePageforPROD: 'Welcome screen is not displayed for PROD',
  maxProfilesLimitReached:
    'Maximum profiles limit reached and Unable to create profile',
  noProfilesAvailableToDelete:
    'No profiles available to delete as maximum profiles count is reached',
  planPickerNotDisplayed:
    'Plan picker is not visible for firetab because the build is not LAT',
};

module.exports = {
  skipReason,
};
