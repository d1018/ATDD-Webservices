const { Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

/**
 * Need to increase the timeout from default 6minute to 15minute for Firetab since headspin is too slow and it takes ~10minute to execute this step.
 */

Then(
  'I verify the JIP playback on selecting JIP content',
  { timeout: 15 * 60 * 1000 },
  async (pageType) => {
    const jipContentPage = pageType.raw();

    for (let i = 0; i < jipContentPage.length; i++) {
      await pageClass.homePage.verifyJipContentPlayback(
        jipContentPage[i].toString(),
      );
    }
  },
);
