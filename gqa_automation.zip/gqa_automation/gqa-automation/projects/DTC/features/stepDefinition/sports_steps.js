const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

Then('I verify the sports landing page after CTA is clicked', async () => {
  await pageClass.homePage.selectInlineHeroCTA();
  await pageClass.sportsPage.verifySportsDetailsPage();
});

Then(
  'I verify user gets to sports detail page after sports card is selected',
  async () => {
    await pageClass.homePage.selectSportsCard();
    await pageClass.sportsPage.verifySportsDetailsPage();
  },
);

Then(
  'I verify rail tile and interactive hero metadata for below rails',
  async (railName) => {
    const railNameList = railName.raw().flat();

    for (let i = 0; i < railNameList.length; i++) {
      await pageClass.homePage.scrollToRail(railNameList[i]);
      await pageClass.sportsPage.verifyRailTileAndInteractiveHeroMetadata(
        railNameList[i],
      );
    }
  },
);

Then(
  'I verify rail tile and interactive hero metadata for {string}',
  async (railName) => {
    await pageClass.homePage.scrollToRail(railName);
    await pageClass.sportsPage.verifyRailTileAndInteractiveHeroMetadata(
      railName,
    );
  },
);

When('I navigate to {string} secondary tab', async (genreName) => {
  await pageClass.sportsPage.selectSecondaryGenreTab(genreName);
});

When(
  'I navigate to category {string} page by selecting it',
  async (categoryName) => {
    await pageClass.sportsPage.selectSportsCategoryPage(categoryName);
  },
);

Then('I verify all the metadata is present under the tile', async () => {
  await pageClass.sportsPage.verifySecondarySportsMetadata();
});
