const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When(
  'I scrub the video upto {string} percentage after playing video',
  async (percent) => {
    this.percent = percent;
    await pageClass.showDetailsPage.selectAndPlayVideo(1);
    await pageClass.videoPlayerPage.scrubVideo(percent);
  },
);

When('I verify the video resumes from previous point when played', async () => {
  await pageClass.homePage.resumeAndPlayVideo();
  await pageClass.videoPlayerPage.validateResumePoint(this.percent);
});

When('I remove episode from Continue Watching Rail', async () => {
  await pageClass.homePage.removeTileFromRail();
});

When('I verify episode is removed from Continue Watching Rail', async () => {
  await pageClass.homePage.verifyTileRemoved();
});

Then('I verify the metadata on Continue Watching rail', async () => {
  await pageClass.homePage.verifyContinueWatchingMetadata();
});

When('I navigate to profile page', async () => {
  await pageClass.profilePage.navigateToManageProfiles();
});

Then('I should not see Continue watching rail', async () => {
  await pageClass.homePage.verifyContinueWatchingNotVisible();
});
