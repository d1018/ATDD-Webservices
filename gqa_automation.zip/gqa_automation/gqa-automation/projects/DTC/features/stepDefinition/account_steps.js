const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

Then(
  'I validate sub item of account page for {string} profile',
  async (profileName) => {
    await pageClass.accountPage.verifyAccountPage(profileName);
  },
);

Then(
  'I validate the account sub menu page for {string} profile',
  async (profileName) => {
    await pageClass.accountPage.verifyAccountSubNavigationPage(profileName);
  },
);

When('I navigate to Account page', async () => {
  await pageClass.menuPage.navigateToPage('Account');
});

When('I navigate to Account Tab Menu', async () => {
  await pageClass.menuPage.navigateToAccountTabMenu('Account');
});

When('I change active user profile', async () => {
  await pageClass.accountPage.changeActiveProfile();
});

Then('I verify switching of active user profile', async () => {
  await pageClass.accountPage.verifyActiveProfileSwitch();
});

When('I select subscribe option on my account page', async () => {
  await pageClass.accountPage.selectSubscribe();
});

When('I select Change Password CTA', async () => {
  await pageClass.accountPage.selectChangePassword();
});

Then('I submit wrong credentials on change password popup', async () => {
  await pageClass.accountPage.submitCredentialsOnChangePassword();
});

Then('I verify the error message for change password', async () => {
  await pageClass.accountPage.verifyErrorMessageOnChangePassword();
});

Then('I should be provided an option to manage account settings', async () => {
  await pageClass.accountPage.verifyManageAccountSettings();
});

Then(
  'I verify billing section for credit card account details page',
  async () => {
    await pageClass.accountPage.verifyMyAccountDetailsForCreditCard();
  },
);

When('I select an Adult Profile', async () => {
  await pageClass.accountPage.selectAdultProfile();
});

When('select the Help Tab', async () => {
  await pageClass.accountPage.selectFooter('Help');
});

Then('I should navigate to the help url', async () => {
  await pageClass.accountPage.verifyHelpPage();
});

When('I select Manage Profile CTA', async () => {
  await pageClass.accountPage.selectManageProfileCTA();
});

Then('I am navigated to manage profile screen', async () => {
  await pageClass.profilePage.verifyManageProfiles();
});

When(
  'I select the Subscribe Now or Free Trial or Choose You plan CTA',
  async () => {
    await pageClass.accountPage.validateInactiveSubscriptionPage();
    await pageClass.accountPage.selectSubscribe();
  },
);

Then('I am taken to the plan picker screen', async () => {
  await pageClass.accountPage.validateProductPickerPage();
});

When('I select the Sign Out tab menu', async () => {
  await pageClass.accountPage.selectFooter('Sign Out');
});

When('I select the cancel CTA from the sign out notification', async () => {
  await pageClass.accountPage.selectCancelCTA();
});

Then('I am taken back to sign out screen notification', async () => {
  await pageClass.accountPage.verifySignOutPage();
});
