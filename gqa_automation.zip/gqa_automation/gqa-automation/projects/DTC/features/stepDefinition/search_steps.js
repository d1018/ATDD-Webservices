const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When(/^I search for a show name (.*)$/, async (text) => {
  await pageClass.searchPage.searchText(text);
});

Then('I am able to see show details for searched show name', async () => {
  await pageClass.searchPage.verifyIfSearchResultsLoaded();
  await pageClass.searchPage.verifyResultsIncludeSearchText();
});

When(
  'I navigate to search page and search for a {string}',
  async (showName) => {
    await pageClass.menuPage.navigateToPage('Search');
    await pageClass.searchPage.searchText(showName);
  },
);

Then('I am able to see search result for {string}', async (showName) => {
  await pageClass.searchPage.verifyIfSearchResultsLoaded();
  await pageClass.searchPage.verifyResultsIncludeSpecificText(showName);
});

Then(
  'I validate search result for the content type and its navigation',
  { timeout: 15 * 60 * 1000 },
  async () => {
    await pageClass.searchPage.verifySearchedContentAndItsLandingPage();
  },
);

Then(
  'I should see "No Results Found" and the "Recommended For You" section',
  async () => {
    await pageClass.searchPage.verifyNoResultFound();
    await pageClass.searchPage.verifyRecommendedForYou();
  },
);

When('I navigate to the search page', async () => {
  await pageClass.menuPage.navigateToPage('Search');
});

When('I see the "Recommended For You" section', async () => {
  await pageClass.searchPage.verifyRecommendedForYou();
});

When(
  'I select the first tile in the "Recommended For You" Section',
  async () => {
    await pageClass.searchPage.selectFirstRecommendedForYou();
  },
);

Then('the app should navigate to the series detail page', async () => {
  await pageClass.searchPage.verifyLandedOnSeriesDetail();
});

When('I clear the search query', async () => {
  await pageClass.searchPage.clearSearchBox();
});

Then('the search box becomes empty of any characters', async () => {
  await pageClass.searchPage.verifyEmptySearchBox();
});

Then('I should not see {string} in the results', async (showName) => {
  await pageClass.searchPage.verifyIfSearchResultsLoaded();
  await pageClass.searchPage.verifyResultsDoNotInclude(showName);
});

When('I remove {string}', async (num) => {
  await pageClass.searchPage.removeCharFromSearchText(num);
});

Then('I see the characters removed', async () => {
  await pageClass.searchPage.verifyUpdatedSearchText();
});

Then('I see {string}', async (result) => {
  await pageClass.searchPage.verifySearchResultAfterRemoving(result);
});

When('I add more to the query in the search field', async () => {
  await pageClass.searchPage.addToExistingQuery();
});

Then('I see the search results continue to update', async () => {
  await pageClass.searchPage.validateUpdatedSearchResult();
});
