const { Given, When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I select {string} profile', async (profileName) => {
  await pageClass.profilePage.selectProfile(profileName);
});

When('I am a first time user with {string} profile', async (profileName) => {
  await pageClass.profilePage.createNewProfileandSelect(profileName);
});

Then('I create a new {string} profile', async (profileName) => {
  await pageClass.profilePage.createNewProfileandSelect(profileName);
});

When('I create and select {string} user profile', async (profileType) => {
  await pageClass.profilePage.profileCreation(profileType);
});

When("I delete any user profile via who's watching screen", async () => {
  await pageClass.profilePage.deleteProfile('random');
});

Then('I verify the user profile should be deleted', async () => {
  await pageClass.profilePage.verifyUserProfileDeleted();
});

Then('I validate data is cleaned up by deleting profile', async () => {
  await pageClass.profilePage.deleteExistingProfile();
});

When(
  'I create and move to edit page for {string} user profile',
  async (profileType) => {
    await pageClass.profilePage.createNewProfileAndMoveToEdit(profileType);
  },
);

When('I remove pin for user profile', async () => {
  await pageClass.profilePage.removePin();
});

Then('I should be able to remove pin from user profile', async () => {
  await pageClass.profilePage.verifyPinDeleted();
});

When('I move to delete profile Page', async () => {
  await pageClass.profilePage.moveToDeleteProfilePage();
});

Then('I verify metadata on delete user profile page', async () => {
  await pageClass.profilePage.verifyDeleteProfileMetadata();
});

Then('I verify metadata on edit user profile page', async () => {
  await pageClass.profilePage.verifyEditProfileMetadata();
});

When('I edit user profile details', async () => {
  await pageClass.profilePage.editUserProfile();
});

Then('I verify user profile details updated successfully', async () => {
  await pageClass.profilePage.verifyEditedProfile();
});

When('I move to change rating page', async () => {
  await pageClass.profilePage.moveToChangeRatingPage();
});

Then('I verify metadata on profile rating page', async () => {
  await pageClass.profilePage.verifyProfileRatingMetadata();
});

When('I change kids profile rating', async () => {
  await pageClass.profilePage.setKidsProfileRating();
});

Then('I verify kids profile rating updated successfully', async () => {
  await pageClass.profilePage.verifyRatingUpdated();
});

Given('I am on the manage profile lander', async () => {
  await pageClass.profilePage.navigateToManageProfiles();
});

When('I select a profile', async () => {
  await pageClass.profilePage.selectProfileToManage();
});

When('I am on the Edit Profile lander', async () => {
  await pageClass.profilePage.verifyEditProfilePage();
});

When('I add a {string} and save it', async (name) => {
  await pageClass.profilePage.changeProfileName(name);
});

Then('I am prompted with an {string} message', async (err) => {
  await pageClass.profilePage.verifyErrorMessage(err);
});

When('I create a {string} profile', async (profileName) => {
  await pageClass.profilePage.adTechCreateNewProfileandSelect(profileName);
});
