const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I access the {string} Page', async (pageType) => {
  await pageClass.browsePage.selectPage(pageType);
});

Then('I validate the browse page', async () => {
  await pageClass.browsePage.verifyBrowsePage();
});

Then('I select Browse Shows on My List page', async () => {
  await pageClass.myListPage.selectBrowseShows();
});

When('I select {string} sub-nav on browse page', async (subNav) => {
  await pageClass.browsePage.selectSubNav(subNav);
});

When('I select {string} network on browser page', async (networkType) => {
  await pageClass.browsePage.selectNetwork(networkType);
  await pageClass.browsePage.verifyShowOnSelectedNetwork();
});

Then(
  'I verify the show cards on selecting {string} sub-nav on browse page',
  async (subNav) => {
    await pageClass.browsePage.selectSubNav(subNav);
    await pageClass.browsePage.verifyShowCard();
  },
);

Then('I select a show', async () => {
  await pageClass.browsePage.selectAsset();
});

Then('I verify respective component on show detail page', async (cta) => {
  const ctaType = cta.raw();

  for (let i = 0; i < ctaType.length; i++) {
    await pageClass.showDetailsPage.verifyShowLandingPage(
      ctaType[i].toString(),
    );
  }
});
