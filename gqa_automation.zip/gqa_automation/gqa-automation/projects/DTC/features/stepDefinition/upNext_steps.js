const { Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

Then(
  'I verify Up Next banner is displayed at last 30 secs of current video',
  async () => {
    await pageClass.upNextPage.verifyUpNextBanner();
  },
);

Then('I verify metadata for Up Next banner', async () => {
  await pageClass.upNextPage.verifyMetaDataForUpNext();
});

Then('I verify next episode plays as soon as current video ends', async () => {
  await pageClass.upNextPage.verifyNextEpisode();
});

Then('I click {string} on the Up Next Banner', async (CTAType) => {
  await pageClass.upNextPage.clickOnUpNextCTA(CTAType);
});

Then('I verify next episode starts to play', async () => {
  await pageClass.upNextPage.verifyNextEpisode();
});

Then('I verify the landing screen upon cancellation of Up Next', async () => {
  await pageClass.upNextPage.verifyScreenOnUpNextCancel();
});
