const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

Then('I see Signin and Signup on Account or Home screen', async () => {
  await pageClass.accountPage.validateCtaAccountPage();
});

Then('I select CTA and verify the landing Page', async (CTA) => {
  const ctaType = CTA.raw();

  for (let i = 0; i < ctaType.length; i++) {
    await pageClass.onboardingPage.selectCTAAndVerify(ctaType[i].toString());
  }
});

When('I navigate to Plan Picker screen', async () => {
  await pageClass.onboardingPage.navigateToPlanPickerPage();
});

Then('I should see a Register CTA to create a free account', async () => {
  await pageClass.onboardingPage.verifyRegisterFreeCta();
});

Then('I select Register CTA and complete the registration', async () => {
  await pageClass.onboardingPage.selectAndCompleteRegistration();
});

Then('I verify free account created', async () => {
  await pageClass.onboardingPage.verifyAccountCreation();
});

When(
  'I play {string} from Home Page as {string} user',
  async (contentType, userType) => {
    await pageClass.onboardingPage.navigateAndSelectContent(
      contentType,
      userType,
    );
  },
);

Then('I validate CTA on subscribe to watch screen', async () => {
  await pageClass.onboardingPage.verifySubscribeToWatchScreen();
});

Then(
  'I should land on Upgrade to watch screen with View Passes CTA',
  async () => {
    await pageClass.onboardingPage.validateUpgradeToWatchScreen();
  },
);

When(
  'I play {string} from Sports Page as {string} user',
  async (contentType, userType) => {
    await pageClass.onboardingPage.navigateAndSelectContent(
      contentType,
      userType,
    );
  },
);

Then('I should see inactive subscription screen', async () => {
  await pageClass.onboardingPage.verifyInactiveSubscriptionScreen();
});

When('I select Register CTA', async () => {
  await pageClass.onboardingPage.selectRegisterFreeCta();
});

When('I submit {string} in create account page', async (credentialType) => {
  await pageClass.onboardingPage.submitAccountDetails(credentialType);
});

Then('I verify error message for {string} details', async (credentialType) => {
  await pageClass.onboardingPage.verifyErrorMessage(credentialType);
});

When('I select any plan from plan picker', async () => {
  await pageClass.onboardingPage.selectAnyPlan();
});

Then('I verify create account page details', async () => {
  await pageClass.onboardingPage.verifyCreateAccountDetails();
});

Then('I select payment and validate page details', async (payment) => {
  const paymentType = payment.raw();

  for (let i = 0; i < paymentType.length; i++) {
    await pageClass.onboardingPage.selectPaymentAndVerify(
      paymentType[i].toString(),
    );
  }
});

When('I sign out from the app', async () => {
  await pageClass.homePage.signOut();
});

Then('I should be signed out successfully', async () => {
  await pageClass.signInPage.verifySignOut();
});

When('I navigate to SIGN IN and select Reset Password', async () => {
  await pageClass.onboardingPage.navigateToSignInPage();
  await pageClass.onboardingPage.selectResetPassword();
});

When('I land on Reset Password screen', async () => {
  await pageClass.onboardingPage.verifyResetPasswordScreen();
});

When('I submit valid email', async () => {
  await pageClass.onboardingPage.submitValidEmail();
});

Then('an email to reset password will be sent', async () => {
  await pageClass.onboardingPage.interceptPasswordEmail();
});

Then('I reset the password and SIGN IN with new password', async () => {
  await pageClass.onboardingPage.resetPassword();
  await pageClass.onboardingPage.signInWithNewPassword();
});

Then('SIGN IN should be successful', async () => {
  await pageClass.onboardingPage.verifySuccessfulLogin();
});

Then('Land on the Home Page skipping profile picker page', async () => {
  await pageClass.homePage.verifyHomepage();
});

When('I navigate to SIGN IN screen', async () => {
  await pageClass.signInPage.navigateToSignInFromWelcomeScreen();
});
