const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

Then('I verify content for kids user', async () => {
  await pageClass.homePage.verifyKidsContentPopulated();
});

Then('I should not see the JIP content', async () => {
  await pageClass.homePage.verifyJIPContent();
});

When('I navigate to {string} genre tab', async (genreName) => {
  await pageClass.homePage.selectGenreTab(genreName);
});

Then('I scroll to {string} rail', async (railName) => {
  await pageClass.homePage.scrollToRail(railName);
});

Then(/^I should be able to play videos$/, async () => {
  await pageClass.homePage.verifyVideoPlayed();
});

Then(
  'I validate {string} rail is not present in the Home Page',
  async (railName) => {
    await pageClass.homePage.scrollToRail(railName, false);
  },
);

Then('I add {string} shows to My List', async (showCount) => {
  await pageClass.homePage.addShowToMyList(showCount);
});

Then(
  'I view My List rail on the Home Screen with more than {string} shows added',
  async (showCount) => {
    await pageClass.homePage.verifyMyListRailMetadata(showCount);
    await pageClass.homePage.verifyMyListRailShowOrder();
  },
);

Then('I remove {string} show from My List', async (showName) => {
  await pageClass.homePage.removeFromMyList(showName);
});

When('I go back to {string} rail on home', async (railName) => {
  await pageClass.menuPage.navigateToPage('Home');
  await pageClass.homePage.scrollToRail(railName);
});

When(
  'I scroll down to {string} poster rail on For You page',
  async (sportsRailType) => {
    await pageClass.homePage.verifySportsRail(sportsRailType);
  },
);

Then(
  'I verify highlighted {string} sports card metadata',
  async (sportsRailType) => {
    await pageClass.homePage.verifySportsCardMetadata(sportsRailType);
  },
);

When('I navigate to sports inline hero in For You page', async () => {
  await pageClass.homePage.navigateToSportsInLineHero();
});

Then('I verify sports inline hero metadata', async () => {
  await pageClass.homePage.verifySportsInLineHeroMetadata();
});

Then(
  'I verify the Age Ratings and Content Descriptors on different screens',
  async (screens) => {
    const screensType = screens.raw();

    for (let i = 0; i < screensType.length; i++) {
      await pageClass.homePage.verifyAgeRatingAndContentDescriptors(
        screensType[i].toString(),
      );
    }
  },
);

When('I select the logo from the primary navigation', async () => {
  await pageClass.menuPage.navigateToPage('Home');
});

Then('I am taken to the default page', async () => {
  await pageClass.homePage.verifyHomepage();
});

When('I verify video is playing', async () => {
  await pageClass.videoPlayerPage.isVideoPlaying();
});
