const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I navigate to Network rail', async () => {
  await pageClass.homePage.scrollToNetworkRail();
});

Then('I validate the Network rail', async () => {
  await pageClass.homePage.validateNetworkRail();
});

Then('I validate network rail for a kids profile user', async () => {
  await pageClass.networkLandingPage.verifyNetworkRailForKidsProfile();
});

Then(
  'I select network and validate the network landing page',
  async (network) => {
    const networkType = network.raw();

    for (let i = 0; i < networkType.length; i++) {
      await pageClass.networkLandingPage.selectAndValidateNetworkLandingPage(
        networkType[i].toString(),
      );
    }
  },
);

Then(
  'I verify the simulcast playback for {string} user',
  async (userType, network) => {
    const networkType = network.raw();

    for (let i = 0; i < networkType.length; i++) {
      await pageClass.networkLandingPage.verifySimulcastPlaybackOnNetworkPage(
        userType,
        networkType[i].toString(),
      );
    }
  },
);

When('I select a network from the network rail', async () => {
  await pageClass.networkLandingPage.selectNetworkLogo();
});

When(
  'I scroll down from the network landing page and select another network',
  async () => {
    await pageClass.networkLandingPage.scrollToNetworkRailAndSelectNetwork();
  },
);

Then('I should be navigated to the network landing page', async () => {
  await pageClass.networkLandingPage.validateNetworkPage();
});
