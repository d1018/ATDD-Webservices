const { Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

Then('I verify the metadata of welcome screen', async () => {
  await pageClass.welcomePage.verifyWelcomeScreen();
});

Then('I verify Planpicker or Signin screen by selecting cta', async (cta) => {
  const welcomeScreenCta = cta.raw();

  for (let i = 0; i < welcomeScreenCta.length; i++) {
    await pageClass.welcomePage.verifyLandingPageOfWelcomeScreen(
      welcomeScreenCta[i].toString(),
    );
  }
});
