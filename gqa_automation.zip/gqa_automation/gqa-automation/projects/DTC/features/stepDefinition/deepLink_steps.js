const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I background the app', async () => {
  await pageClass.deepLinkPage.backgroundApp();
});

When('I select a manage account deep link from external source', async () => {
  await pageClass.deepLinkPage.deepLinkTo('manageAccount');
});

Then('the discovery+ app should be opened', async () => {
  await pageClass.deepLinkPage.verifyAppOpened();
});

Then('I should be taken to Manage Account Screen', async () => {
  await pageClass.deepLinkPage.verifyAccountScreen();
});
