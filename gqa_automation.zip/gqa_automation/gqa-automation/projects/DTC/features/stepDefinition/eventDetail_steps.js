const { When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

const credentials = {
  'fully-entitled': 'DTC_VALID',
};

When('I select the Upcoming Live event on Sport page', async () => {
  await pageClass.eventDetailPage.selectUpcomingRailFirstEvent();
});

Then('I should land on Event page with Sign-in and Signup CTA', async () => {
  await pageClass.eventDetailPage.verifyCTAonPlayer();
});

When(
  'I select Sign-in CTA and complete Sign-in as {string} user',
  async (attribute) => {
    await pageClass.signInPage.loginToApplication(credentials[attribute]);
  },
);

Then(
  'I should land on the Event detail page without any CTA button',
  async () => {
    await pageClass.eventDetailPage.validateEventDeatilPage();
    await pageClass.eventDetailPage.verifyCTAonPlayer();
  },
);

When('I select the Live event on Sport page', async () => {
  await pageClass.eventDetailPage.checkLiveEventRailAvailability();
  await pageClass.eventDetailPage.selectLiveRailFirstEvent();
});

Then('I should land on Live Event page and validate CTA button', async () => {
  await pageClass.eventDetailPage.validateLiveEventDeatilPage();
});

Then(
  'I verify video starts from Live point on selecting Watch Live CTA',
  async () => {
    await pageClass.eventDetailPage.selectLiveCtaAndValidateVOD();
  },
);

Then(
  'I verify video starts from beginning on selecting Watch From Start CTA',
  async () => {
    await pageClass.eventDetailPage.selectStartCtaAndValidateVOD();
  },
);

Then('I select View Passes CTA', async () => {
  await pageClass.eventDetailPage.clickOnViewPassesCta();
});

Then('I validate Plan Picker Screen', async () => {
  await pageClass.eventDetailPage.validatePlanPickerScreen();
});
