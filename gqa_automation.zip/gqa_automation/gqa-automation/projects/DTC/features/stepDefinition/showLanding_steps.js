const { Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

Then(
  'I validate the CTA on the page as {string} user',
  async (userType, pageName) => {
    await pageClass.homePage.validateCTAonPages(userType, pageName);
  },
);

Then(
  'I validate the CTA on genres for {string} user',
  async (userType, genreName) => {
    await pageClass.showDetailsPage.validateCTAonGenres(userType, genreName);
  },
);
