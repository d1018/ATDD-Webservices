const { Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

Then(
  'I should see {string} is selected by default in EPG page',
  async (day) => {
    await pageClass.epgTVGuidePage.verifyDaySelection(day);
  },
);

Then('I should see 7 days when I navigate on the day bar', async (table) => {
  const direction = table.raw();

  for (let i = 0; i < direction.length; i++) {
    await pageClass.epgTVGuidePage.validateNavigationOnEPG(
      direction[i].toString(),
    );
  }
});

Then('I see correct content listing for {string} date', async (date) => {
  await pageClass.epgTVGuidePage.verifyDisplayedContentMetaData(date);
});

Then('I stay on the {string} Guide', async (pageValue) => {
  await pageClass.menuPage.assertPage(pageValue);
});

Then('I select {string} on EPG Page', async (day) => {
  await pageClass.epgTVGuidePage.selectDay(day);
});

Then('I see live content is displayed', async () => {
  await pageClass.epgTVGuidePage.isLiveContentDisplayed();
});

Then('I verify correct content is displayed', async () => {
  await pageClass.epgTVGuidePage.verifyDisplayedContentMetaData('live');
});

Then('I click on Live content', async () => {
  await pageClass.epgTVGuidePage.clickOnLiveContent();
});

Then('I see Live Event details page', async () => {
  await pageClass.eventDetailPage.validateLiveEventDeatilPage();
});

Then('I select a currently broadcasted content', async () => {
  await pageClass.epgTVGuidePage.selectBroadcastingContent();
});

Then('I see {string} CTA on Linear channel page', async (CTA) => {
  await pageClass.menuPage.isCTAPresent(CTA);
});

Then('I select {string} CTA on the Network Hero', async (CTA) => {
  await pageClass.onboardingPage.selectCTA(CTA);
});

Then('I verify linear channel playback', async () => {
  await pageClass.videoPlayerPage.isVideoPlaying();
});
