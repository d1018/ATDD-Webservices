/* eslint-disable global-require */
let pageObject;

const project = process.env.PROJECT;
const device = process.env.DEVICE;

if (project + device === 'DTCsamsung') {
  pageObject = require('../../samsung/pages');
} else if (project + device === 'DTCroku') {
  pageObject = require('../../roku/pages');
} else if (project + device === 'DTCweb') {
  pageObject = require('../../web/pages');
} else if (project + device === 'DTCandroid') {
  pageObject = require('../../android/pages');
} else if (project + device === 'DTCios') {
  pageObject = require('../../ios/pages');
} else if (project + device === 'DTCipad') {
  pageObject = require('../../ipad/pages');
} else if (project + device === 'DTCxbox') {
  pageObject = require('../../xbox/pages');
} else if (project + device === 'DTCappletv') {
  pageObject = require('../../appletv/pages');
} else if (project + device === 'DTCandroidtv') {
  pageObject = require('../../androidtv/pages');
} else if (project + device === 'DTCfiretab') {
  pageObject = require('../../firetab/pages');
} else if (project + device === 'DTCfiretv') {
  pageObject = require('../../firetv/pages');
} else if (project + device === 'DTClg') {
  pageObject = require('../../lg/pages');
} else {
  throw new Error(`unsupported project and device type: ${project + device}`);
}

const pageClass = pageObject;

module.exports = {
  pageClass,
};
