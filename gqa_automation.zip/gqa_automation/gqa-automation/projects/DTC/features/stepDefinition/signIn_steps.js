const { Given, When, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

const credentials = {
  'fully-entitled': 'DTC_VALID',
  'multi-profile': 'DTC_MULTI_PROFILE',
  'non-entitled': 'DTC_NON_ENTITLED',
  anonymous: 'anonymous',
  'new-profile': 'DTC_NEW_PROFILE',
  'pin-profile': 'DTC_PIN_PROFILE',
  'kids-profile': 'DTC_KIDS_PROFILE',
  'sports-entitled': 'DTC_SPORTS_ENTITLED',
  'limited-entitled': 'DTC_LIMITED_ENTITLEMENT',
  lapsed: 'DTC_LAPSED',
  'myList-entitled': 'DTC_MYLIST_ENTITLED',
  'single-profile': 'DTC_SINGLE_PROFILE',
  InvalidUsername: 'InvalidUsername',
  InvalidPassword: 'InvalidPassword',
  InvalidUserName_InvalidPassword: 'InvalidUserName_InvalidPassword',
};

Given('I launch Discovery app', async () => {
  await pageClass.signInPage.openApp();
});

When('I login with {string} user credentials', async (attribute) => {
  await pageClass.signInPage.loginToApplication(credentials[attribute]);
});

Given('I access the application as {string} user', async (attribute) => {
  await pageClass.signInPage.loginToApplication(credentials[attribute]);
});

When('I Sign In using {string}', async (attribute) => {
  await pageClass.signInPage.enterCredentials(credentials[attribute]);
});

Then('I should be displayed with error message on sign in page', async () => {
  await pageClass.signInPage.verifyIncorrectCredentialError();
});

When('I login with valid {string} credentials', async (attribute) => {
  await pageClass.signInPage.loginToApplication(attribute);
});

Given(
  'I have toggled Advertising to {string} in One-Trust pop-up',
  async (settings) => {
    await pageClass.signInPage.toggleOneTrustPopup(settings);
  },
);
