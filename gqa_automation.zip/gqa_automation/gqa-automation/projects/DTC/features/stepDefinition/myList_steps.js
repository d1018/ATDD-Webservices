const { When, And, Then } = require('@wbd/gqa-core');
const { pageClass } = require('./base_steps');

When('I add a show to Mylist from Browse screen', async () => {
  await pageClass.myListPage.addShowsToMylistFromBrowse();
});

When(
  'I focus on any show tile in For You page to check the tooltip message',
  async () => {
    await pageClass.myListPage.navigateToShowTileInHomePage();
  },
);

When('I press and hold on a show', async () => {
  await pageClass.myListPage.pressAndHoldOnShow();
});

Then(
  /^I see show is (.*) my list with a confirmation message$/,
  async (action) => {
    await pageClass.myListPage.verifyAddRemoveMyListInHomePage(action);
  },
);

Then(
  'I see tooltip message for focused show already added to my list',
  async () => {
    await pageClass.myListPage.verifyRemoveShowTooltip();
  },
);

Then('I see show is added to My List rail', async () => {
  await pageClass.homePage.verifyShowsInMyListRail(true);
});

Then('I see show is added to My List page', async () => {
  await pageClass.myListPage.verifyShowsInMyList(true);
});

When(
  'I add a show from Home Hero as {string} user profile',
  async (profileName) => {
    await pageClass.profilePage.selectProfile(profileName);
    await pageClass.homePage.addShowToMylistFromHomeHero();
  },
);

And(
  'I navigate to the asset Content Details Page via My List page',
  async () => {
    await pageClass.myListPage.navigateToDetailPageFromMyList();
    await pageClass.showDetailsPage.validateShowDetailPage();
  },
);

When('I navigate back', async () => {
  await pageClass.myListPage.navigateBack();
});

Then('I am taken to My list page', async () => {
  await pageClass.myListPage.validateMyListPage();
});

Then('I see show is added to My List rail and My List page', async () => {
  await pageClass.homePage.verifyShowsInMyListRail(true);
  await pageClass.myListPage.verifyShowsInMyList(true);
});

Then(
  'I should not see former show in current profile My list rail and Mylist page',
  async () => {
    await pageClass.homePage.verifyShowsInMyListRail(false);
    await pageClass.myListPage.verifyShowsInMyList(false);
  },
);

Then('I see show is removed from My List rail and My List page', async () => {
  await pageClass.homePage.verifyMyListRailOnHomePage('My List', false);
  await pageClass.myListPage.verifyShowsInMyList(false);
});

Then('I remove show from My List page', async () => {
  await pageClass.myListPage.removeShowFromMyListPage();
});

Then(
  'I see {string} option is not present in global nav or Account menu',
  async (menuOption) => {
    await pageClass.menuPage.isMenuOptionPresent(menuOption, false);
  },
);

Then('I validate {string} CTA is not present on Home Hero', async (CTA) => {
  await pageClass.menuPage.isCTAPresent(CTA, false);
});

Then(
  'I validate My List button is not present on any selected show card',
  async () => {
    await pageClass.homePage.verifyMyListCtaForShow();
  },
);

Then(
  'I see no former show in current profile My list rail and Mylist page',
  async () => {
    await pageClass.homePage.verifyMyListShowAvailability();
  },
);

When('I Add to My List from any asset details page', async () => {
  await pageClass.showDetailsPage.selectHeroItemFromHome();
  await pageClass.showDetailsPage.addShowToMylistFromContentDetailPage();
  await pageClass.showDetailsPage.verifyHeroMyListCtaIsCheckmarkIcon();
});

When('I perform an action to add asset to My List', async () => {
  await pageClass.homePage.addShowToMylistFromHomeRail();
});

When('I Remove from My List from any asset details page', async () => {
  await pageClass.showDetailsPage.removeShowFromMyList();
});

Then('I see the Add to My List CTA changes to a Plus icon', async () => {
  await pageClass.showDetailsPage.verifyHeroMyListCtaIsPlusIcon();
});

Then('I select Remove from My List button from a Hero component', async () => {
  await pageClass.homePage.removedShowFromMylistFromHomeHero();
});

When('I navigate to the My List {string}', async (myListype) => {
  await pageClass.homePage.navigateToMyList(myListype);
});

When('I observe the asset tile {string}', async (myListype) => {
  await pageClass.myListPage.verifyAssetTile(myListype);
});

Then('I verify tile metadata on My List {string}', async (myListype) => {
  await pageClass.myListPage.verifyMyListMetadata(myListype);
});

Then('I should see {string} shows added to My List page', async (showNum) => {
  await pageClass.menuPage.navigateToPage('My List');
  await pageClass.myListPage.verifyShowsOnMyListPage(showNum);
});

Then('My List page is sorted by most recently added first', async () => {
  await pageClass.myListPage.verifyMyListSorting();
});

When(
  'I Add to My List from any asset details page on {string}',
  async (pageName) => {
    await pageClass.myListPage.addShowsToMyList(pageName);
  },
);

When(
  'I Remove from My List from any asset details page on {string}',
  async (pageName) => {
    await pageClass.myListPage.removeShowFromMyList(pageName);
  },
);

When('I again add removed asset to My List', async () => {
  await pageClass.showDetailsPage.selectHeroItemFromHome();
  await pageClass.showDetailsPage.addShowToMylistFromContentDetailPage();
  await pageClass.showDetailsPage.verifyHeroMyListCtaIsCheckmarkIcon();
});

Then('I see the toast {string}', async (toastType) => {
  await pageClass.showDetailsPage.verifyMLToast(toastType);
});
