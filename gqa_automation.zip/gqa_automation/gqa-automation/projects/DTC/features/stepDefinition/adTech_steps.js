const { Given, When, Then } = require('@wbd/gqa-core');
const logger = require('jake/lib/utils/logger');
const { pageClass } = require('./base_steps');

const shows = {
  'drm show with ads': 'drm_show_with_ads',
  'show with midroll': 'show_with_midroll',
  'show with multiple midroll': 'show_with_multiple_midroll',
  'show with adverts': 'show_with_adverts',
  'show with ad params': 'show_with_ad_params',
  'show for anonymous playback': 'show_for_anonymous_playback',
  'show with prerolls': 'show_with_prerolls',
};

When('I am watching a {string}', async (attribute) => {
  await pageClass.adTechPage.searchShow(shows[attribute]);
});

When(
  'mp4 ad-break has finished and transitioned into main content',
  async () => {
    await pageClass.adTechPage.adPlaying();
  },
);

When('I scrub over the first ad break', async () => {
  await pageClass.adTechPage.scrubOverFirstMidroll();
});

When('I am scrubbing past multiple non-empty mid-roll ad breaks', async () => {
  await pageClass.adTechPage.scrubOverMultipleMidroll();
});

Then(
  'all {string} for mp4 ads within {string} adbreak are fired',
  { timeout: 900 * 1000 },
  async (beaconType, adType) => {
    await pageClass.adTechPage.trackBeacons(beaconType, adType);
  },
);

When(
  'I scrub to a position before the first non-empty mid-roll ad break',
  async () => {
    await pageClass.adTechPage.scrubBeforeFirstNonEmptyMidroll();
  },
);

When('I wait for the playback to fall into ad break', async () => {
  await pageClass.adTechPage.waitForFallIntoAdbreak();
});

Given('I have toggled LAT to {string} on the device', async (adTrackingReq) => {
  if (process.env.DEVICE !== 'android') {
    await pageClass.adTechPage.adTrackingSetting(adTrackingReq);
  } else {
    logger.log(`Skipped the step for ${process.env.DEVICE} device`);
  }
});

When('I scrub past multiple mid-roll ad breaks', async () => {
  await pageClass.adTechPage.scrubPastMultipleMidroll();
});

Then('I validate ad request parameters', async (parameters) => {
  await pageClass.adTechPage.validateAdRequestParameters(parameters);
});

When(
  'I scrub to position just before the second non-empty mid-roll adbreak',
  async () => {
    await pageClass.adTechPage.scrubBeforeSecondNonEmptyMidroll();
  },
);

When(
  'I am watching a {string} from chapter {string}',
  async (attribute, chapter) => {
    await pageClass.adTechPage.scrubToSpecificChapter(
      shows[attribute],
      chapter,
    );
  },
);

When('I scrub over the second ad break', async () => {
  await pageClass.adTechPage.scrubOverSecondMidroll();
});

When('I continue watching a {string}', async (attribute) => {
  await pageClass.adTechPage.searchShow(shows[attribute]);
});
