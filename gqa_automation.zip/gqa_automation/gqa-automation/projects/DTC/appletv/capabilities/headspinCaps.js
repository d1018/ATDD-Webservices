const { mapGeoLocation } = require('@wbd/gqa-regional-routing/src/maplocation');

const platformVersion = process.env.OS_VERSION || '15.6';
const udid = process.env.UDID;
const autoAcceptAlerts = process.env.AUTO_ACCEPT_ALERTS === 'true';
const localExecution = process.env.LOCAL_EXECUTION === 'true';
const app = process.env.APP || '6df4d181-76ce-4088-8642-dac68f2e0331';
const bundleId = process.env.BUNDLE_ID;
const geo = process.env.GEO || 'us';

const hsAppleTVCapabilities = {
  'headspin:selector': 'device_skus:"Apple TV 4K"',
  'headspin:waitForDeviceOnlineTimeout': '600',
  'headspin:capture.video': 'true',
  'headspin:network.regionalRouting': mapGeoLocation(geo, 'headspin'),
  'headspin:app.id': app,
  'headspin:app.resign': 'true',
  'headspin:appiumVersion': '1.22.3',
  bundleId,
};

const appleTvCapabilities = {
  deviceName: 'Apple TV 4K',
  automationName: 'Appium',
  platformVersion,
  platformName: 'tvos',
  autoAcceptAlerts,
  app,
  bundleId,
  udid,
};

const desiredAppleTVCapabilities = localExecution
  ? appleTvCapabilities
  : Object.assign(appleTvCapabilities, hsAppleTVCapabilities);

module.exports = { desiredAppleTVCapabilities };
