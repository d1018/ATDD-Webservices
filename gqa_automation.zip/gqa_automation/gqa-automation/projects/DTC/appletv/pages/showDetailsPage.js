const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class ShowDetailsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('showPage', locator);
  }

  contentByIndex = this.getElementByPage('searchPage', 'contentByIndex');

  actionPlay_btn = this.getElementByPage('homePage', 'actionPlay_btn');

  showImage_img = this.getElementByPage('searchPage', 'showImage_img');

  ctaButtons = this.#getSelectorData('ctaButtons');

  showHeroImage = this.#getSelectorData('showHeroImage');

  myList_btn = this.#getSelectorData('myList_btn');

  startWatching_txt = this.#getSelectorData('startWatching_txt');

  startWatching_btn = this.#getSelectorData('startWatching_btn');

  watchNow_btn = this.#getSelectorData('watchNow_btn');

  TrueCrime_lbl = this.#getSelectorData('TrueCrime_lbl');

  videoTitle_lbl = this.getElementByPage('videoPlayerPage', 'videoTitle_lbl');

  info_lbl = this.getElementByPage('searchPage', 'info_lbl');

  #forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  genreTabItems = {
    Crime: this.TrueCrime_lbl,
  };

  selectAndPlayVideo = async (index) => {
    const searchResults = await commons.findElements(this.contentByIndex, 20);

    await commons.click(searchResults[index], 30);
    await commons.waitUntil(this.actionPlay_btn);
    await commons.click(this.actionPlay_btn);
  };

  verifyShowLandingAnchorDetails = async () => {
    assert.equal(
      await commons.elementExists(this.showHeroImage, 60),
      true,
      'showHeroImage metadata validation failed',
    );
    assert.equal(
      await commons.elementExists(this.ctaButtons, 60),
      true,
      'ctaButtons metadata validation failed',
    );
  };

  validateCTAonGenres = async (userType, genreName) => {
    const genreArr = genreName.raw();

    for (let i = 0; i < genreArr.length; i++) {
      const genre = genreArr[i].toString();

      switch (genre) {
        case 'For You':
          await commons.waitUntil(this.#forYou_lbl);
          await commons.click(this.#forYou_lbl);
          break;
        case 'Crime':
          await commons.waitUntil(this.genreTabItems[genre], 60);
          await commons.click(this.genreTabItems[genre]);
          break;
        default:
      }
      assert(
        (await commons.elementExists(this.startWatching_txt, 20)) &&
          (await commons.elementExists(this.myList_btn, 5)),
        `Start Watching CTA and My list icon are not displayed`,
      );
      await commons.click(this.startWatching_btn, 5);
      assert(
        await commons.elementExists(this.ctaButtons, 10),
        `Watch Now CTA is not displayed`,
      );
      await commons.click(this.ctaButtons, 5);
      await commons.userAction('down');
      await commons.elementExists(this.info_lbl, 20);
      await commons.userAction('menu');
      await commons.elementExists(this.videoTitle_lbl, 20);
      await commons.userAction('menu');
      await commons.userAction('menu');
    }
  };
}

module.exports = new ShowDetailsPage();
