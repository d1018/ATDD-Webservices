const path = require('path');
const { mobileActions, testdataHelper } = require('@wbd/gqa-core/support');

const ymlpath = path.resolve(__dirname);

const EnvBase = require('../../../support/env');

const myListShows = [];

let myListCompareShow = '';

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }

  // Save a show from a Standard profile to compare to a show in a Kids profile
  getMyListCompareShow() {
    return myListCompareShow;
  }

  setMyListCompareShow(show) {
    myListCompareShow = show;
  }

  // Save the shows to verify order in verifyMyListRailShowOrder()
  getMyListShows() {
    return myListShows;
  }

  addToMyListShows(show) {
    myListShows.unshift(show);
  }

  getRandomNumber = (len) => {
    const randomNumber = Math.floor(Math.random() * len);

    return `${randomNumber}`;
  };
}

module.exports = {
  mobileActions,
  testdataHelper,
  BasePage,
};
