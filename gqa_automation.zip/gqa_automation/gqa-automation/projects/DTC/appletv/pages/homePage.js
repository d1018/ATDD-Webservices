const assert = require('assert');
const retry = require('async-retry');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');

const commons = mobileActions;
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');
const videoPlayerPage = require('./videoPlayerPage');
const showDetailsPage = require('./showDetailsPage');
const searchPage = require('./searchPage');
const myListPage = require('./myListPage');

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  #forYou_lbl = this.#getSelectorData('forYou_lbl');

  crime_lbl = this.#getSelectorData('crime_lbl');

  genre_tab = this.#getSelectorData('genre_tab');

  showsTab = this.getElementByPage('searchPage', 'showsTab');

  genreTabItems = {
    Crime: this.crime_lbl,
  };

  primaryEnlargedBackgroundImage = this.#getSelectorData(
    'primaryEnlargedBackgroundImage',
  );

  primaryEnlargedHeroImage = this.#getSelectorData('primaryEnlargedHeroImage');

  primaryEnlargedDescriptionLabel = this.#getSelectorData(
    'primaryEnlargedDescriptionLabel',
  );

  primaryEnlargedChannelImage = this.#getSelectorData(
    'primaryEnlargedChannelImage',
  );

  primaryPoster = this.#getSelectorData('primaryPosterShow');

  enlargedPoster = this.#getSelectorData('enlargedPosterShow');

  standardPoster = this.#getSelectorData('standardPosterShow');

  sportsPosterTitle = this.#getSelectorData('sportsPosterTitle');

  posterChannelLogo = this.#getSelectorData('channelLogo');

  railContentTitle = this.#getSelectorData('railContentTitle');

  railContentFocused = this.#getSelectorData('railContentFocused');

  sportsPosterShowName = testdataHelper.getContent(
    'homePage.sportsPosterShowName',
  );

  sportsInlineHero = this.#getSelectorData('sportsInlineHero');

  sportsInlineHeroTitle = this.#getSelectorData('sportsInlineHeroTitle');

  networkRail_lbl = this.#getSelectorData('networkRail_lbl');

  #profileAvatar = this.#getSelectorData('profileAvatar');

  inlineHeroDescription_lbl = this.#getSelectorData(
    'inlineHeroDescription_lbl',
  );

  inlineHeroCTA_btn = this.#getSelectorData('inlineHeroCTA_btn');

  inlineHeroNetworkImage = this.#getSelectorData('inlineHeroNetworkImage');

  sportsStandardShowName = testdataHelper.getContent(
    'homePage.sportsStandardShowName',
  );

  watchNow_btn = this.getElementByPage('showPage', 'watchNow_btn');

  browseTrendingTab = this.#getSelectorData('browseTrendingTab');

  assertCTAButton = {
    'fully-entitled': this.watchNow_btn,
  };

  primaryPosterShow = this.getCustomLocator(
    this.primaryPoster,
    this.sportsPosterShowName,
  );

  enlargedPosterShow = this.getCustomLocator(
    this.enlargedPoster,
    this.sportsPosterShowName,
  );

  primaryPosterTitle = this.getCustomLocator(
    this.sportsPosterTitle,
    this.sportsPosterShowName,
  );

  channelLogo = this.getCustomLocator(
    this.posterChannelLogo,
    this.sportsPosterShowName,
  );

  standardPosterShow = this.getCustomLocator(
    this.standardPoster,
    this.sportsStandardShowName,
  );

  standardPosterTitle = this.getCustomLocator(
    this.sportsPosterTitle,
    this.sportsStandardShowName,
  );

  rail_lbl = this.#getSelectorData('rail_lbl');

  myListIcon = this.getElementByPage('myListPage', 'favorite_btn');

  #search_txtBx = this.getElementByPage('searchPage', 'search_txtBx');

  #homeMenu_lbl = this.getElementByPage('menuPage', 'homeMenu_lbl');

  /**
   *  This button has a child element with a label that changes dynamically
   *  to either 'Resume' or 'Play Now'
   */
  #actionPlay_btn = this.#getSelectorData('actionPlay_btn');

  #firstContent = this.getElementByPage('searchPage', 'contentByIndex');

  #myListAssets = this.#getSelectorData('myListAssets');

  #contentGridHero = this.#getSelectorData('contentGridHero');

  #logoTitle_lbl = this.#getSelectorData('logoTitle_lbl');

  #contentRating_lbl = this.#getSelectorData('contentRating_lbl');

  #myList_btn = this.#getSelectorData('myList_btn');

  #myListPageAsset = this.getElementByPage('myListPage', 'myListPageAsset');

  #myListCollection = this.#getSelectorData('myListCollection');

  #showDetailsContentRating_lbl = this.getElementByPage(
    'showPage',
    'contentRating_lbl',
  );

  #nextEpisodeContentRating_lbl = this.getElementByPage(
    'showPage',
    'nextEpisodeContentRating_lbl',
  );

  #videoPlayerContentRating_lbl = this.getElementByPage(
    'videoPlayerPage',
    'contentRating_lbl',
  );

  #infoContentRating_lbl = this.getElementByPage(
    'videoPlayerPage',
    'infoContentRating_lbl',
  );

  accountPageTabsList = this.getElementByPage(
    'accountPage',
    'accountPageTabsList',
  );

  signOut_btn = this.getElementByPage('accountPage', 'signOut_btn');

  signOutPopUp_btn = this.getElementByPage('accountPage', 'signOutPopUp_btn');

  accountPageTabs = {
    Settings: this.getCustomLocator(
      this.getElementByPage('accountPage', 'getAccountPageTab'),
      'Settings',
    ),
    Help: this.getCustomLocator(
      this.getElementByPage('accountPage', 'getAccountPageTab'),
      'Help',
    ),
    About: this.getCustomLocator(
      this.getElementByPage('accountPage', 'getAccountPageTab'),
      'About',
    ),
    DebugSettings: this.getCustomLocator(
      this.getElementByPage('accountPage', 'getAccountPageTab'),
      'Debug Settings',
    ),
    'Sign Out': this.getCustomLocator(
      this.getElementByPage('accountPage', 'getAccountPageTab'),
      'Sign Out',
    ),
  };

  railNamesList = {
    postEnlargedRail: 'Link testing - Poster-Enlarged',
    primaryPosterRail: 'Link testing - poster primary',
    standardPosterRail: 'link testing standard primary',
    'Live events': 'Live events',
    Upcoming: 'Upcoming',
    Latest: 'Latest',
    Featured: testdataHelper.getContent('homePage.featured'),
    'Free episodes': testdataHelper.getContent('homePage.freeEpisode'),
    'Continue Watching': testdataHelper.getContent('homePage.continueWatching'),
    'My List': testdataHelper.getContent('homePage.myList'),
    'discovery+ Channels': testdataHelper.getContent(
      'homePage.discoveryPlusChannels',
    ),
    'Recommended for You': testdataHelper.getContent(
      'networkPage.PopularShowsRail',
    ),
    'Every Episode Ever': testdataHelper.getContent(
      'networkPage.JustAddedRail',
    ),
  };

  railNames = {
    postEnlargedRail: this.getCustomLocator(
      this.rail_lbl,
      'Link testing - Poster-Enlarged',
    ),
    primaryPosterRail: this.getCustomLocator(
      this.rail_lbl,
      'Link testing - poster primary',
    ),
    standardPosterRail: this.getCustomLocator(
      this.rail_lbl,
      'link testing standard primary',
    ),
    'Live events': this.getCustomLocator(this.rail_lbl, 'Live events'),
    Upcoming: this.getCustomLocator(this.rail_lbl, 'Upcoming'),
    Latest: this.getCustomLocator(this.rail_lbl, 'Latest'),
    Featured: this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('homePage.featured'),
    ),
    'Free episodes': this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('homePage.freeEpisode'),
    ),
    'Continue Watching': this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('homePage.continueWatching'),
    ),
    'My List': this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('homePage.myList'),
    ),
    'Recommended for You': this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('networkPage.PopularShowsRail'),
    ),
    'Every Episode Ever': this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('networkPage.JustAddedRail'),
    ),
    'discovery+ Channels': this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('homePage.discoveryPlusChannels'),
    ),
  };

  scrollToNetworkRail = async () => {
    let iteration = 0;

    do {
      await commons.userAction('down');
      iteration++;
    } while (
      !(await commons.elementExists(this.networkRail_lbl, 3)) &&
      iteration < 20
    );

    const isRailsFirstContentFocussed =
      (await commons.fetchAttributeData(
        this.networkRail_lbl,
        'focused',
        20,
      )) === 'true';

    if (!isRailsFirstContentFocussed.to) {
      await commons.userAction('down');
    }
  };

  validateNetworkRail = async () => {
    await commons.waitUntil(this.networkRail_lbl);
  };

  selectGenreTab = async (genreName) => {
    if (await profilePage.isManageProfileScreen())
      await commons.userAction('select');
    await commons.waitUntil(this.#forYou_lbl, 30);

    const totalGenres = testdataHelper.getContent('homePage.totalGenres');

    for (let i = 0; i < totalGenres; i++) {
      if (
        await commons.elementExists(
          this.getCustomLocator(this.genre_tab, genreName),
        )
      ) {
        return;
      }
      await commons.userAction('right');
    }
    throw new Error(`Genre name: '${genreName}' not found!`);
  };

  /**
   *
   * @param {string} railName The Name of the Rail to be evaluated
   * @param {boolean} railStatus Whether the Rail should be present
   */
  scrollToRail = async (railName, railStatus = true) => {
    const isPresent = await this.isRailPresent(railName);

    assert.strictEqual(isPresent, railStatus);

    if (isPresent) {
      const railFirstContent = this.getCustomLocator(
        this.railContentTitle,
        this.railNamesList[railName],
      );
      const isRailsFirstContentFocussed =
        (await commons.fetchAttributeData(railFirstContent, 'focused', 20)) ===
        'true';

      if (!isRailsFirstContentFocussed) {
        await commons.userAction('down');
      }
    }
  };

  showTiles = {
    FirstTileOnFeaturedRail: this.#getSelectorData(
      'firstTileOnFeaturedRail_lbl',
    ),
    FirstShow: this.firstShow_tile,
  };

  selectShow = async (index) => {
    await commons.click(this.showTiles[index], 10);
  };

  isRailPresent = async (railName) => {
    for (let count = 0; count < 17; count++) {
      await commons.userAction('down');
      if (await commons.elementExists(this.railNames[railName], 5)) {
        return true;
      }
    }
    return false;
  };

  verifySportsRail = async (sportsRailType) => {
    await menuPage.assertPage('Home');
    const sportsRail = {
      primary: 'primaryPosterRail',
      enlarged: 'postEnlargedRail',
      'standard primary': 'standardPosterRail',
    };

    await this.scrollToRail(sportsRail[sportsRailType]);
  };

  assertPrimaryPosterMetadata = async () => {
    await commons.waitUntil(this.primaryPosterShow);
    await commons.waitUntil(this.primaryPosterTitle);
    const isChannelLogoDisplayed = await commons.elementExists(
      this.channelLogo,
      5,
    );

    assert(
      !isChannelLogoDisplayed,
      `A Channel Logo is being displayed below Primary Poster`,
    );
  };

  assertEnlargedPosterMetadata = async () => {
    await commons.waitUntil(this.primaryEnlargedBackgroundImage);
    await commons.waitUntil(this.primaryEnlargedHeroImage);
    await commons.waitUntil(this.primaryEnlargedDescriptionLabel);
    const primaryEnlargedPosterDescription = await commons.fetchAttributeData(
      this.primaryEnlargedDescriptionLabel,
      'label',
      15,
    );

    assert.equal(primaryEnlargedPosterDescription, 'This is a link asset.');
    /* TODO: Uncomment below validation once the bug is fixed
        https://discoveryinc.atlassian.net/browse/LIU-15769 */
    // const isChannelLogoDisplayed = await commons.elementExists(
    //   this.primaryEnlargedChannelImage,
    //   5,
    // );
    //
    // assert(
    //   !isChannelLogoDisplayed,
    //   `A Channel Logo is being displayed below Primary Poster`,
    // );
  };

  assertStandardPosterMetadata = async () => {
    await commons.waitUntil(this.standardPosterTitle);
    const isChannelLogoDisplayed = await commons.elementExists(
      this.channelLogo,
      5,
    );

    assert(
      !isChannelLogoDisplayed,
      `A Channel Logo is being displayed below Primary Poster`,
    );
  };

  verifySportsCardMetadata = async (sportsRailType) => {
    switch (sportsRailType) {
      case 'primary':
        await this.scrollToContent(this.sportsPosterShowName);
        await this.assertPrimaryPosterMetadata();
        break;
      case 'enlarged':
        await commons.userAction('right');
        await this.assertEnlargedPosterMetadata();
        break;
      case 'standard primary':
        await this.assertStandardPosterMetadata();
        break;
      default:
        break;
    }
  };

  scrollToContent = async (contentName, maxScrollRightCount = 10) => {
    const railTitle = this.getCustomLocator(
      this.railContentFocused,
      contentName,
    );
    let iteration = 1;

    while (
      !(await commons.elementExists(railTitle, 3)) &&
      iteration <= maxScrollRightCount
    ) {
      await commons.userAction('right');
      iteration++;
    }
  };

  selectSportsCard = async () => {
    await commons.userAction('select');
  };

  navigateToSportsInLineHero = async () => {
    let iteration = 0;

    while (
      !(await commons.elementExists(this.sportsInlineHero, 3)) &&
      iteration < 20
    ) {
      await commons.userAction('down');
      iteration++;
    }
  };

  verifySportsInLineHeroMetadata = async () => {
    await commons.waitUntil(this.sportsInlineHero, 20);
    await commons.waitUntil(this.sportsInlineHeroTitle, 15);
    await commons.waitUntil(this.inlineHeroCTA_btn, 15);
    await commons.waitUntil(this.inlineHeroDescription_lbl, 15);
    const actualSportsTitle = await commons.fetchAttributeData(
      this.sportsInlineHeroTitle,
      'label',
      10,
    );

    assert.equal(actualSportsTitle, this.sportsPosterShowName);
    /*   TODO: Uncomment validation once bug fixed
         https://discoveryinc.atlassian.net/browse/LIU-15769 */
    //   const actualInLineHeroCTALabel = await commons.fetchAttributeData(this.inlineHeroCTA_btn,'label',10);
    //   assert.equal(actualInLineHeroCTALabel,'Explore Now');
    //   const networkImageExist= await commons.elementExists(this.inlineHeroNetworkImage,15);
    //
    //  assert(!networkImageExist,"Validation Failed for Sports Inline Hero Network Image. Network Image is present!!");
  };

  selectInlineHeroCTA = async () => {
    await commons.click(this.inlineHeroCTA_btn);
  };

  isProfileAvatarVisible = async () => {
    const result = await commons.elementExists(this.#profileAvatar, 15);

    return result;
  };

  navigateToManagaeProfile = async () => {
    await menuPage.navigateToPage('Home');
    await commons.userAction('menu');
    await commons.userAction('up');
    await commons.userAction('select');
    assert(
      await profilePage.isManageProfileScreen(),
      "User failed to navigate to Who's watching screen",
    );
  };

  verifyVideoPlayed = async () => {
    await this.selectAndPlayVideo();
    await videoPlayerPage.validatePlayerOpened();
  };

  selectAndPlayVideo = async () => {
    await commons.userAction('select');
    await commons.click(this.#actionPlay_btn);
  };

  verifyContinueWatchingMetadata = async () => {
    await commons.waitUntil(this.#contentGridHero);
    await commons.waitUntil(this.#logoTitle_lbl);
    await commons.waitUntil(this.#contentRating_lbl);
  };

  resumeAndPlayVideo = async () => {
    await commons.userAction('select');
  };

  validateCTAonPages = async (userType, pageName) => {
    const pageArr = pageName.raw();

    for (let i = 0; i < pageArr.length; i++) {
      const page = pageArr[i].toString().toLowerCase();

      switch (page) {
        case 'home':
          await this.scrollToRail('Featured');
          await commons.userAction('select');
          break;
        case 'search':
          await menuPage.navigateToPage('Search');
          await searchPage.searchText('multiContentShow');
          await commons.click(searchPage.searchResultTabs.Shows, 30);
          await commons.waitUntil(searchPage.firstContentTitle);
          await commons.userAction('down');
          await commons.userAction('select');
          break;
        case 'browse':
          if (this.returnGeoLocation() === 'america') {
            await menuPage.navigateToPage('Browse');
            await commons.waitUntil(this.browseTrendingTab, 30);
            await commons.waitUntil(searchPage.firstContentTitle);
            await commons.userAction('down');
            await commons.userAction('down');
            await commons.userAction('select');
          }
          break;
        case 'sports':
          if (this.returnGeoLocation() === 'america') {
            return;
          }
          break;
        default:
      }
      if (page !== 'sports') {
        await showDetailsPage.verifyShowLandingAnchorDetails();
        await this.validateCTAForUser(userType);
      }
      await commons.userAction('menu');
    }
  };

  validateCTAForUser = async (userType) => {
    await commons.waitUntil(this.assertCTAButton[userType.toLowerCase()]);
  };

  verifyKidsContentPopulated = async () => {
    await menuPage.navigateToPage('Search');
    await searchPage.searchText('kidsShowName');
    await commons.waitUntil(searchPage.firstContentTitle, 20);
    const kidsShowTitle = await commons.fetchAttributeData(
      searchPage.firstContentTitle,
      'label',
    );
    const expectedKidsShowTitle = searchPage.searchedContent;

    assert.equal(kidsShowTitle, expectedKidsShowTitle);
    await searchPage.clearSearchTextBox();
    await searchPage.searchText('adultShowName');
    const adultShowTitle = await commons.fetchAttributeData(
      searchPage.firstContentTitle,
      'label',
    );
    const expectedAdultShowTitle = searchPage.searchedContent;

    assert.notEqual(
      adultShowTitle,
      expectedAdultShowTitle,
      'Adult Rated Content visible in Kids User Profile',
    );
  };

  verifyJIPContent = async () => {
    await searchPage.clearSearchTextBox();
    await searchPage.searchText('JIPShowName');
    if (await commons.elementExists(this.showsTab)) {
      await commons.click(this.showsTab);
    }
    const jipShowTitle = await commons.fetchAttributeData(
      searchPage.firstContentTitle,
      'label',
    );
    const expectedJIPShowTitle = searchPage.searchedContent;

    assert.notEqual(
      jipShowTitle,
      expectedJIPShowTitle,
      'JIP Content visible in Kids User Profile',
    );
    await commons.userAction('menu');
  };

  addShowToMyList = async (showCount) => {
    const showList = testdataHelper.getContent('searchPage.myListShows');

    for (let i = 0; i < showCount; i++) {
      await menuPage.navigateToPage('Search');
      await commons.sendText(this.#search_txtBx, showList[i], 20);
      const searchResults = await commons.findElements(this.#firstContent, 20);

      await commons.click(searchResults[1], 30);
      await myListPage.addToFavorites();

      while (!(await commons.elementExists(this.#homeMenu_lbl))) {
        await commons.userAction('menu');
      }
      await commons.click(this.#homeMenu_lbl);
    }
  };

  /**
   *
   * @param {number} showCount Number of shows added to My List
   */
  verifyMyListRailMetadata = async (showCount) => {
    await this.scrollToRail('My List', true);

    for (let i = 0; i < showCount; i++) {
      // Validate there are items in the My List rail with 'Remove from My List' present in 'name'.
      await commons.elementExists(this.#myListAssets, 5);

      // Go to the next item in My List
      await commons.userAction('right');
    }
  };

  // I shall see my saved shows ordered by Most Recently Saved to Oldest
  verifyMyListRailShowOrder = () => {
    const showList = testdataHelper.getContent('searchPage.myListShows');

    for (let i = 0; i < this.getMyListShows().length; i++) {
      if (!this.getMyListShows().includes(showList[i])) {
        throw new Error(
          `Show order doesn't match! On tvOS : ${this.getMyListShows()} from data ${showList}`,
        );
      }
    }
  };

  removeFromMyList = async (showName) => {
    await menuPage.navigateToPage('My List');
    const show = testdataHelper.getContent(`searchPage.${showName}`);

    await myListPage.removeFromMyList(show);
    await commons.userAction('menu');
  };

  navigateToAccountPageTabs = async (tabName) => {
    const accountTabsElementsList = await commons.findElements(
      this.accountPageTabsList,
    );
    const isFirstTabFocussed = await commons.fetchAttributeData(
      accountTabsElementsList[0],
      'focused',
    );

    if (isFirstTabFocussed === 'false') await commons.userAction('menu');
    await commons.click(this.accountPageTabs[tabName]);
  };

  signOut = async () => {
    await menuPage.assertPage('Home');
    await menuPage.navigateToPage('Account');
    await this.navigateToAccountPageTabs('Sign Out');
    await commons.userAction('down');
    await commons.click(this.signOut_btn);
    await commons.click(this.signOutPopUp_btn);
    if (this.returnGeoLocation() !== 'america') {
      await menuPage.assertPage('Home');
    }
  };

  /**
   * Verifies if the shows added to My List are present in the rail.
   *
   * @param {boolean} shouldSeeShow Whether or not the rail should be present with a show or shows.
   */
  verifyShowsInMyListRail = async (shouldSeeShow) => {
    await menuPage.navigateToPage('Home');
    await this.scrollToRail('My List', shouldSeeShow);

    if (shouldSeeShow) {
      await this.verifyMyListRailMetadata(
        await commons.findElements(this.#myListCollection, 5).length,
      );
    }
  };

  verifyJipContentPlayback = async (pageType) => {
    switch (pageType) {
      case 'Home Page':
        await this.scrollToRail('discovery+ Channels');
        await commons.userAction('select');
        await videoPlayerPage.verifyJIPVideoPlayback();
        await retry(
          async () => {
            await commons.userAction('menu');
          },
          { retries: 3, minTimeout: 3000, maxTimeout: 5000 },
        );

        break;
      case 'Show Details Page':
        if (!(await commons.elementExists(this.#forYou_lbl))) {
          await commons.userAction('menu');
        }
        await menuPage.navigateToPage('Search');
        await searchPage.scrollToChannel('JIPShowName');
        await videoPlayerPage.verifyJIPVideoPlayback();
        break;
      default:
        break;
    }
  };

  verifyAgeRatingAndContentDescriptors = async (screenType) => {
    switch (screenType) {
      case 'Main Hero':
        await commons.waitUntil(this.#contentRating_lbl);
        this.validateCurrentRating(
          await commons.fetchAttributeData(this.#contentRating_lbl, 'value'),
          screenType,
        );
        await commons.userAction('down');
        await commons.userAction('select');
        break;
      case 'Show Details Page':
        await commons.waitUntil(this.#showDetailsContentRating_lbl);
        this.validateCurrentRating(
          await commons.fetchAttributeData(
            this.#showDetailsContentRating_lbl,
            'value',
          ),
          screenType,
        );
        break;
      case 'Currently Playing Episode':
        this.validateCurrentRating(
          await commons.fetchAttributeData(
            this.#videoPlayerContentRating_lbl,
            'value',
          ),
          screenType,
        );
        while (
          !(await commons.elementExists(this.#showDetailsContentRating_lbl))
        ) {
          await commons.userAction('menu');
        }
        break;
      case 'Next Episodes listed on Episode Landing Page': {
        await commons.waitUntil(this.#showDetailsContentRating_lbl);
        await commons.userAction('down');
        const nextEpisodeList = await commons.findElements(
          this.#nextEpisodeContentRating_lbl,
        );

        for (let i = 0; i < nextEpisodeList.length; i++) {
          this.validateCurrentRating(
            await commons.fetchAttributeData(nextEpisodeList[i], 'value'),
            screenType,
          );
        }
        break;
      }
      case 'Episode Info Panel':
        await commons.userAction('up');
        await commons.waitUntil(this.#showDetailsContentRating_lbl);
        await commons.userAction('select');
        await commons.userAction('up');
        await commons.waitUntil(this.#videoPlayerContentRating_lbl);
        await commons.userAction('down');
        // Info content rating is an image & contains no metadata about rating.
        await commons.waitUntil(this.#infoContentRating_lbl);
        break;
      default:
        break;
    }
  };

  validateCurrentRating = (rating, screenType) => {
    const trimmedRating = rating.includes('Rated')
      ? rating.split('Rated ')[1]
      : rating;

    assert(
      testdataHelper.getContent('ratingList').includes(trimmedRating),
      `Content Rating value with '${trimmedRating}' at ${screenType} is not included in the Ratings List`,
    );
  };

  addShowToMylistFromHomeHero = async () => {
    await commons.waitUntil(this.#contentRating_lbl);
    await commons.userAction('down');
    await commons.userAction('right');

    if (
      (await commons.fetchAttributeData(this.#myList_btn, 'label', 5)) ===
      'Add to My List'
    ) {
      await commons.userAction('select');
    }

    const myListMetaData = await commons.fetchAttributeData(
      this.#logoTitle_lbl,
      'label',
      5,
    );

    this.addToMyListShows(myListMetaData);
    if (this.getMyListCompareShow() === '') {
      this.setMyListCompareShow(myListMetaData);
    }
  };

  verifyMyListRailOnHomePage = async (railName, railStatus) => {
    await menuPage.navigateToPage('Home');
    await this.scrollToRail(railName, railStatus);
  };

  verifyMyListShowAvailability = async () => {
    await this.scrollToRail('My List', true);

    if (!(await commons.elementExists(this.#myListAssets))) {
      await commons.userAction('down');
    }
    const kidsMyListMetadata = await commons.fetchAttributeData(
      this.#myListAssets,
      'name',
      5,
    );

    assert(
      this.getMyListCompareShow() !== kidsMyListMetadata,
      `Standard profile saved My List metadata as: ${kidsMyListMetadata}. Kids profile shows My List metadata as: ${this.getMyListCompareShow()}`,
    );
    await menuPage.navigateToPage('My List');
    const kidsMyListPageMetadata = await commons.fetchAttributeData(
      this.#myListPageAsset,
      'name',
    );

    assert(
      this.getMyListCompareShow() !== kidsMyListPageMetadata,
      `Standard profile saved My List metadata as: ${kidsMyListPageMetadata}. Kids profile shows My List metadata as: ${this.getMyListCompareShow()}`,
    );
  };
}

module.exports = new HomePage();
