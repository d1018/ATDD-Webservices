const assert = require('assert');

const { BasePage, mobileActions } = require('./basePage');
const homePage = require('./homePage');
const menuPage = require('./menuPage');
const searchPage = require('./searchPage');

const commons = mobileActions;

class NetworkLandingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('networkLandingPage', locator);
  }

  networkRail_lbl = this.getElementByPage('homePage', 'networkRail_lbl');

  networkRail_Title = this.#getSelectorData('networkRail_Title');

  network_logo = this.#getSelectorData('network_logo');

  networkRail = this.#getSelectorData('networkRail');

  navigateToSelectNetwork = async (networkType) => {
    let i = 20;

    while (i > 0) {
      const heroTitleTxtFromScreen = await commons.fetchAttributeData(
        this.networkRail_Title,
        'label',
      );

      if (heroTitleTxtFromScreen === networkType) {
        await commons.userAction('select');
        break;
      } else {
        await commons.userAction('right');
        i -= 1;
      }
    }
  };

  selectAndValidateNetworkLandingPage = async (network) => {
    if (network === 'Sports') {
      return;
    }
    if (network === 'Entertainment') {
      await this.validateEntertainmentNetworkLandingPage();
    }
  };

  validateAuthenticatedEntertainmentContent = async () => {
    await commons.waitUntil(this.network_logo);
    await homePage.scrollToRail('Recommended for You');
    await homePage.scrollToRail('Every Episode Ever');
    await homePage.scrollToNetworkRail();
  };

  validateEntertainmentNetworkLandingPage = async () => {
    await this.navigateToSelectNetwork('Food Network');
    await this.validateAuthenticatedEntertainmentContent();
  };

  verifyNetworkRailForKidsProfile = async () => {
    await homePage.scrollToNetworkRail();
    if (this.countryCode === 'us') {
      assert(
        await commons.elementExists(this.networkRail_lbl, 3),
        `A network rail is not shown for the kids user`,
      );
    }
    await this.navigateToSelectNetwork('Food Network');
    await commons.waitUntil(this.network_logo);
    await commons.userAction('menu');
    await menuPage.navigateToPage('Search');

    const isAdultContentDisplayed = await searchPage.searchText(
      'adultShowName',
    );

    assert(
      !isAdultContentDisplayed,
      `A rated content is shown on the kids search screen`,
    );
  };
}
module.exports = NetworkLandingPage;
