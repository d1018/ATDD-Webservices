const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class VideoPlayerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('videoPlayerPage', locator);
  }

  videoTitle_lbl = this.#getSelectorData('videoTitle_lbl');

  info_lbl = this.getElementByPage('searchPage', 'info_lbl');

  #unifiedPlayer_lbl = this.#getSelectorData('unifiedPlayer_lbl');

  #scrubber_lbl = this.#getSelectorData('scrubber_lbl');

  #captions_lbl = this.#getSelectorData('captions_lbl');

  #subtitlesSettings_lbl = this.#getSelectorData('subtitlesSettings_lbl');

  #mediaControls_lbl = this.#getSelectorData('mediaControls_lbl');

  #audioSettings_lbl = this.#getSelectorData('audioSettings_lbl');

  #scrubNeedle = this.#getSelectorData('scrubNeedle');

  #elapsedTime_lbl = this.#getSelectorData('elapsedTime_lbl');

  #remainingTime_lbl = this.#getSelectorData('remainingTime_lbl');

  #forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  #livePage_lbl = this.#getSelectorData('livePage_lbl');

  #livePage_img = this.#getSelectorData('livePage_img');

  #livePageSecondary_lbl = this.#getSelectorData('livePageSecondary_lbl');

  validatePlayerOpened = async () => {
    // Validate a few player-specific elements exist
    await commons.waitUntil(this.#scrubber_lbl);
    await commons.waitUntil(this.#unifiedPlayer_lbl);
    await commons.waitUntil(this.#captions_lbl);
    await commons.waitUntil(this.#audioSettings_lbl);
    await commons.waitUntil(this.#subtitlesSettings_lbl);
    await commons.waitUntil(this.#mediaControls_lbl);
  };

  scrubVideo = async (percent) => {
    await commons.waitUntil(this.#scrubNeedle);
    await commons.userAction('select');
    const elapsedTime = await commons.fetchAttributeData(
      this.#elapsedTime_lbl,
      'label',
      20,
    );
    const remainingTime = await commons.fetchAttributeData(
      this.#remainingTime_lbl,
      'label',
      20,
    );
    const totalTime =
      Math.abs(parseFloat(elapsedTime)) + Math.abs(parseFloat(remainingTime));
    const percentage = percent / 10 ** 2;

    while (
      parseFloat(
        await commons.fetchAttributeData(this.#elapsedTime_lbl, 'label', 20),
      ) <
      totalTime * percentage
    ) {
      await commons.userAction('right');
    }

    await this.backToHomePage();
  };

  backToHomePage = async () => {
    for (let i = 0; i < 4; i++) {
      if (await commons.elementExists(this.#forYou_lbl, 3)) {
        return;
      }
      await commons.userAction('menu');
    }
  };

  validateResumePoint = async (percent) => {
    await commons.waitUntil(this.#remainingTime_lbl);
    await commons.waitUntil(this.#scrubber_lbl);
    await commons.waitUntil(this.#unifiedPlayer_lbl);
    await commons.waitUntil(this.#captions_lbl);
    await commons.waitUntil(this.#audioSettings_lbl);
    await commons.waitUntil(this.#subtitlesSettings_lbl);
    await commons.waitUntil(this.#mediaControls_lbl);

    // Pause to pull up media controls
    await commons.userAction('select');

    const remainingTime = Math.abs(
      parseFloat(
        await commons.fetchAttributeData(this.#remainingTime_lbl, 'label', 20),
      ),
    );
    const elapsedTime = Math.abs(
      parseFloat(
        await commons.fetchAttributeData(this.#elapsedTime_lbl, 'label', 20),
      ),
    );

    const totalTime = remainingTime + elapsedTime;
    const percentage = percent / 10 ** 2;

    assert(
      elapsedTime + 2 >= totalTime * percentage &&
        elapsedTime - 2 <= totalTime * percentage,
    );
  };

  verifyVideoPlayerAnchorDetails = async () => {
    await commons.userAction('down');
    await commons.elementExists(this.info_lbl, 20);
    await commons.userAction('menu');
    await commons.elementExists(this.videoTitle_lbl, 20);
  };

  verifyJIPVideoPlayback = async () => {
    await this.validatePlayerOpened();
    await commons.userAction('up');
    await commons.waitUntil(this.#livePage_lbl);
    await commons.waitUntil(this.#livePageSecondary_lbl);
  };
}

module.exports = new VideoPlayerPage();
