const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class SportsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('sportsPage', locator);
  }

  posterShowNameTitle = this.#getSelectorData('posterShowNameTitle');

  sportsHeroLive_lbl = this.#getSelectorData('sportsHeroLive_lbl');

  focusedHeroPoster_img = this.#getSelectorData('focusedHeroPoster_img');

  sportsHeroTitle_lbl = this.#getSelectorData('sportsHeroTitle_lbl');

  sportsHeroTimeStamp_lbl = this.#getSelectorData('sportsHeroTimeStamp_lbl');

  verifySportsDetailsPage = async () => {
    await commons.waitUntil(this.posterShowNameTitle, 30);
  };

  verifyRailTileAndInteractiveHeroMetadata = async (railName) => {
    switch (railName) {
      case 'Upcoming':
      case 'Latest':
        await this.assertSportsHeroMetadata();
        break;
      case 'Live events':
        await this.assertLiveSportsRailMetadata();
        break;
      default:
        break;
    }
    await commons.userAction('menu');
  };

  assertSportsHeroMetadata = async () => {
    const metadata = [
      this.focusedHeroPoster_img,
      this.sportsHeroTitle_lbl,
      //    this.sportsHeroDescription_lbl, Blocked by LIU-15769
      this.sportsHeroTimeStamp_lbl,
    ];

    for (let i = 0; i < metadata.length; i++) {
      await commons.waitUntil(metadata[i], 2);
    }
  };

  assertLiveSportsRailMetadata = async () => {
    await commons.waitUntil(this.sportsHeroLive_lbl);
    await this.assertSportsHeroMetadata();
  };
}

module.exports = new SportsPage();
