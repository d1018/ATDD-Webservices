const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  #accountMenu_lbl = this.#getSelectorData('accountMenu_lbl');

  #searchMenu_lbl = this.#getSelectorData('searchMenu_lbl');

  #browseMenu_lbl = this.#getSelectorData('browseMenu_lbl');

  #myListPage_lbl = this.getElementByPage('myListPage', 'myListPage_lbl');

  #searchPage_lbl = this.getElementByPage('searchPage', 'searchPage_lbl');

  #accountPage_lbl = this.getElementByPage('accountPage', 'accountPage_lbl');

  #homeMenu_lbl = this.#getSelectorData('homeMenu_lbl');

  #myList_lbl = this.#getSelectorData('myList_lbl');

  #sportsMenu_lbl = this.#getSelectorData('sportsMenu_lbl');

  #tvGuideMenu_lbl = this.#getSelectorData('tvGuideMenu_lbl');

  #showsMenu_lbl = this.#getSelectorData('showsMenu_lbl');

  #forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  #search_txtBx = this.getElementByPage('searchPage', 'search_txtBx');

  #discoveryOriginals_lbl = this.getElementByPage(
    'browsePage',
    'discoveryOriginals_lbl',
  );

  #sports_lbl = this.getElementByPage('allSportsPage', 'sports_lbl');

  #timeBarCellTitle_txt = this.getElementByPage(
    'tvGuidePage',
    'timeBarCellTitle_txt',
  );

  menuItem = {
    Home: this.#homeMenu_lbl,
    Browse: this.#browseMenu_lbl,
    Sports: this.#sportsMenu_lbl,
    Shows: this.#showsMenu_lbl,
    'Tv Guide': this.#tvGuideMenu_lbl,
    Search: this.#searchMenu_lbl,
    'My List': this.#myList_lbl,
    Account: this.#accountMenu_lbl,
  };

  pageFocused = {
    Home: this.#forYou_lbl,
    Search: this.#searchPage_lbl,
    Sports: this.#sports_lbl,
    'Tv Guide': this.#timeBarCellTitle_txt,
    'My List': this.#myListPage_lbl,
    Account: this.#accountPage_lbl,
    Discovery: this.#discoveryOriginals_lbl,
  };

  navigateToPage = async (pageValue) => {
    await commons.userAction('menu');
    await commons.click(this.menuItem[pageValue], 60);
  };

  assertPage = async (pageValue) => {
    await commons.waitUntil(this.pageFocused[pageValue]);
  };

  accessGlobalNavigationMenu = async () => {
    await commons.userAction('left');
  };

  verifyMenuList = async () => {
    await commons.waitUntil(this.menuItem.Home, 20);
    await commons.waitUntil(this.menuItem.Browse, 20);
    await commons.waitUntil(this.menuItem['My List'], 20);
    await commons.waitUntil(this.menuItem.Search, 20);
    await commons.waitUntil(this.menuItem.Account, 20);
  };

  verifyGlobalNavigation = async () => {
    if (this.returnGeoLocation() === 'america') {
      await commons.userAction('select');
      await this.assertPage('Home');
      await this.navigateToPage('Browse');
      await this.assertPage('Discovery');
      await this.navigateToPage('My List');
      await this.assertPage('My List');
      await this.navigateToPage('Search');
      await this.assertPage('Search');
      await this.navigateToPage('Account');
      await this.assertPage('Account');
    }
  };
}

module.exports = new MenuPage();
