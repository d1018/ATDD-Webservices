const assert = require('assert');
const { BasePage, mobileActions, testdataHelper } = require('./basePage');

const commons = mobileActions;

const menuPage = require('./menuPage');

class BrowsePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('browsePage', locator);
  }

  #allNetworksLogo = this.#getSelectorData('allNetworksLogo');

  #networkLogoRail = this.#getSelectorData('networkLogoRail');

  #selectedNetworkLogo_lbl = this.#getSelectorData('selectedNetworkLogo_lbl');

  #trending_lbl = this.#getSelectorData('trending_lbl');

  #selectedTab_lbl = this.#getSelectorData('selectedTab_lbl');

  #showCardCollection_view = this.#getSelectorData('showCardCollection_view');

  #showCardTitle = this.#getSelectorData('showCardTitle');

  #showCardBackgroundImage = this.#getSelectorData('showCardBackgroundImage');

  #showCardNetworkIcon = this.#getSelectorData('showCardNetworkIcon');

  /**
   * The Step Definition doesn't pass network type to the Validation function
   * Using a class variable to hold the value passed in from the selectNetwork() function
   */
  #currentNetworkType = '';

  selectPage = async (pageType) => {
    await menuPage.navigateToPage(pageType);
  };

  verifyBrowsePage = async () => {
    const isAllLogoFocused = await commons.fetchAttributeData(
      this.#allNetworksLogo,
      'focused',
    );

    assert(
      isAllLogoFocused,
      'Browse Page should load with the "All" icon in focus',
    );
    await commons.waitUntil(this.#networkLogoRail);
    await commons.waitUntil(this.#trending_lbl);
  };

  selectNetwork = async (networkType) => {
    const network = testdataHelper.getContent(`networkPage.${networkType}`);

    this.#currentNetworkType = network;
    while (
      !(await commons.elementExists(
        this.getCustomLocator(this.#selectedNetworkLogo_lbl, network),
        5,
      ))
    ) {
      await commons.userAction('right');
    }
  };

  /**
   * The Step definition does not pass the necessary Network to be validated in as a parameter.
   * We will use a class variable to store that value from the `selectNetwork` function.
   */
  verifyShowOnSelectedNetwork = async () => {
    const listOfShows = await commons.findElements(
      this.#showCardCollection_view,
    );

    // Validate the first 6 shows (top row) contain the Network being validated.
    // The first element is the subnav bar, so we'll start on the second.
    for (let i = 1; i < 7; i++) {
      const showDetails = await commons.fetchAttributeData(
        listOfShows[i],
        'name',
      );

      assert(
        showDetails.includes(this.#currentNetworkType),
        `Show Details page assets should include network name. Network is ${
          this.#currentNetworkType
        }`,
      );
    }
  };

  selectSubNav = async (subNav) => {
    // Down to sub-navigation
    await commons.userAction('down');

    // Scroll to the subNav passed in
    const topic = testdataHelper.getContent(`networkPage.${subNav}`);
    const selectedTab = this.getCustomLocator(this.#selectedTab_lbl, topic);

    while (!(await commons.elementExists(selectedTab))) {
      await commons.userAction('right');
    }
  };

  // Validate there is a show card with the appropriate attributes.
  verifyShowCard = async () => {
    await commons.waitUntil(this.#showCardTitle);
    await commons.waitUntil(this.#showCardBackgroundImage);
    await commons.waitUntil(this.#showCardNetworkIcon);
  };
}

module.exports = new BrowsePage();
