const { BasePage, mobileActions } = require('./basePage');
const { desiredAppleTVCapabilities } = require('../capabilities/headspinCaps');

const commons = mobileActions;
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');
const homePage = require('./homePage');
const accountPage = require('./accountPage');

const serverURL = process.env.SERVER_URL
  ? process.env.SERVER_URL.toLowerCase()
  : '';
const localExecution = process.env.LOCAL_EXECUTION === 'true' || false;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  #userName_txtBx = this.#getSelectorData('userName_txtBx');

  #password_txtBx = this.#getSelectorData('password_txtBx');

  #signInToApp_btn = this.#getSelectorData('signInToApp_btn');

  #signIn_btn = this.#getSelectorData('signIn_btn');

  #continue_btn = this.#getSelectorData('continue_btn');

  #noTracking_btn = this.getElementByPage('preLaunchPage', 'noTracking_btn');

  #startWatchingAnonymousUser_lbl = this.getElementByPage(
    'onboardingPage',
    'startWatchingAnonymousUser_lbl',
  );

  #subscribeNow_cta = this.#getSelectorData('subscribeNow_cta');

  #pre_lbl = this.#getSelectorData('pre_lbl');

  welcome_txt = this.getElementByPage('welcomePage', 'welcome_txt');

  welcomeBody_lbl = this.getElementByPage('welcomePage', 'welcomeBody_lbl');

  welocmeFooter_lbl = this.getElementByPage('welcomePage', 'welocmeFooter_lbl');

  subscribeNow_btn = this.getElementByPage('welcomePage', 'subscribeNow_btn');

  choosePlan_cta = this.getElementByPage('onboardingPage', 'choosePlan_cta');

  signOut_cta = this.getElementByPage('onboardingPage', 'signOut_cta');

  inactiveSub_lbl = this.getElementByPage('onboardingPage', 'inactiveSub_lbl');

  discoPlusApp = this.getElementByPage('basePage', 'discoPlusApp');

  openApp = async () => {
    commons.driverInit(serverURL, localExecution);
    await commons.openApp(desiredAppleTVCapabilities);
    // Ensure no system overlay is blocking the app
    if (!(await commons.elementExists(this.discoPlusApp, 5))) {
      await commons.userAction('menu');
    }
    if (!(await this.isSignedOut())) {
      await this.handleSignOut();
    }
  };

  isSignedOut = async () => {
    const isSignedOut = await commons.elementExists(this.#signIn_btn, 5);

    return isSignedOut;
  };

  handleSignOut = async () => {
    if (await commons.elementExists(this.inactiveSub_lbl, 5)) {
      await this.signOutHelper();
    }

    await this.handleAdTracking();

    if (!(await this.isSignedOut())) {
      await this.signOut();
    }
  };

  signOutHelper = async () => {
    if (
      (await commons.elementExists(this.signOut_cta, 5)) ||
      (await commons.elementExists(accountPage.signOut_btn))
    ) {
      await commons.userAction('down');
      await commons.userAction('select');
    }

    if (
      (await commons.elementExists(this.signOut_cta, 5)) ||
      (await commons.elementExists(accountPage.signOutPopUp_btn))
    ) {
      await commons.userAction('down');
      await commons.userAction('select');
    }
  };

  handleAdTracking = async () => {
    if (await commons.elementExists(this.#continue_btn, 5)) {
      await commons.userAction('down');
      await commons.userAction('select');
    }
    if (await commons.elementExists(this.#noTracking_btn, 5)) {
      await commons.userAction('down');
      await commons.userAction('select');
    }
  };

  pressNextOrDoneBtn = async () => {
    for (let i = 0; i < 3; i++) {
      await commons.userAction('down');
    }
    await commons.userAction('select');
  };

  /**
   * The below function will select the enter new when we have the previous used emails
   */
  enterNew = async () => {
    for (let i = 0; i < 15; i++) {
      await commons.userAction('down');
    }
    await commons.userAction('select');
  };

  enterCredentials = async (credentialType) => {
    const username = process.env[`${credentialType}_USERNAME`];
    const password = process.env[`${credentialType}_PASSWORD`];

    if (await commons.elementExists(this.#userName_txtBx, 10)) {
      await commons.userAction('select');
    }

    if (this.returnGeoLocation() === 'america') {
      if (await commons.elementExists(this.#pre_lbl)) {
        await this.enterNew();
      }
    }

    await commons.sendText(this.#userName_txtBx, username, 30);
    await this.pressNextOrDoneBtn();
    await commons.sendText(this.#password_txtBx, password, 30);
    await this.pressNextOrDoneBtn();

    if (await commons.elementExists(this.#signInToApp_btn, 10)) {
      await commons.userAction('select');
    }
  };

  loginToApplication = async (credentialType) => {
    if (this.returnGeoLocation() === 'america') {
      await this.signInUS(credentialType);
      if (credentialType.includes('LAPSED')) {
        return;
      }
    }

    if (this.returnGeoLocation() === 'emea') {
      await this.signIn(credentialType);
    }

    if (await profilePage.isManageProfileScreen()) {
      await profilePage.selectProfile('Default');
    }

    await menuPage.assertPage('Home');
  };

  signInUS = async (credentialType) => {
    await commons.waitUntil(this.#subscribeNow_cta);
    await commons.waitUntil(this.#signIn_btn);
    await commons.userAction('down');
    await commons.userAction('select');
    await this.enterCredentials(credentialType);
  };

  signIn = async (credentialType) => {
    if (await commons.elementExists(this.#startWatchingAnonymousUser_lbl)) {
      await commons.click(this.#signIn_btn);
      await this.enterCredentials(credentialType);
      return;
    }
    if (credentialType === 'anonymous') {
      return;
    }
    if (!(await profilePage.isManageProfileScreen())) {
      await menuPage.assertPage('Home');
      await menuPage.navigateToPage('Account');
      await accountPage.navigateToSignIn();
      await this.enterCredentials(credentialType);
    }
  };

  signOut = async () => {
    if (await profilePage.isManageProfileScreen()) {
      const profile =
        this.returnGeoLocation() === 'america' ? 'Default' : 'Standard';

      await profilePage.selectProfile(profile);
    }
    if (await homePage.isProfileAvatarVisible()) {
      if (await commons.elementExists(this.choosePlan_cta)) {
        await this.signOutHelper();
      } else {
        await menuPage.assertPage('Home');
        await menuPage.navigateToPage('Account');
        await accountPage.navigateToAccountPageTabs('Sign Out');
        await this.signOutHelper();
        if (this.returnGeoLocation() !== 'america') {
          await menuPage.assertPage('Home');
        }
      }
    }
  };

  verifySignOut = async () => {
    if (this.returnGeoLocation() === 'america') {
      await commons.waitUntil(this.welcome_txt);
      await commons.waitUntil(this.welcomeBody_lbl);
      await commons.waitUntil(this.welocmeFooter_lbl);
      await commons.waitUntil(this.subscribeNow_btn);
      await commons.waitUntil(this.#signIn_btn);
    }
  };
}

module.exports = new SignInPage();
