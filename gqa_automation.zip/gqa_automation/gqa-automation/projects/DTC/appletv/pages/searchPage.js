const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const showDetailsPage = require('./showDetailsPage');
const videoPlayerPage = require('./videoPlayerPage');

const commons = mobileActions;
let searchText;

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  search_txtBx = this.#getSelectorData('search_txtBx');

  searchPage_lbl = this.getElementByPage('searchPage', 'searchPage_lbl');

  showTitle_lbl = this.#getSelectorData('showTitle_lbl');

  showNetworkIcon_img = this.#getSelectorData('showNetworkIcon_img');

  firstContentTitle = this.#getSelectorData('firstContentTitle');

  getSearchPageTab = this.#getSelectorData('getSearchPageTab');

  myList_cta = this.#getSelectorData('myList_cta');

  showImage_img = this.#getSelectorData('showImage_img');

  searchedContent = '';

  focusedChannel_lbl = this.#getSelectorData('focusedChannel_lbl');

  contentByIndex = this.#getSelectorData('contentByIndex');

  searchResultTabs = {
    Shows: this.getCustomLocator(this.getSearchPageTab, 'Shows'),
    Episodes: this.getCustomLocator(this.getSearchPageTab, 'Episodes'),
    Specials: this.getCustomLocator(this.getSearchPageTab, 'Specials'),
    Collections: this.getCustomLocator(this.getSearchPageTab, 'Collections'),
    Extras: this.getCustomLocator(this.getSearchPageTab, 'Extras'),
  };

  clearSearchTextBox = async () => {
    await commons.clearText(this.search_txtBx, 15);
  };

  searchText = async (text) => {
    const showName = testdataHelper.getContent(`searchPage.${text}`);

    this.searchedContent = showName;
    searchText = showName;
    await commons.sendText(this.search_txtBx, searchText, 20);
  };

  verifyIfSearchResultsLoaded = async () => {
    await commons.waitUntil(this.firstContentTitle, 30);
    await commons.waitUntil(this.showNetworkIcon_img, 30);
  };

  verifyResultsIncludeSearchText = async () => {
    const titleValue = await commons.fetchAttributeData(
      this.firstContentTitle,
      'label',
    );

    if (titleValue.includes(searchText)) return;
    throw new Error(`Search result does not includes '${searchText}'`);
  };

  getSearchResultsTab = () => {
    const expectedSearchTabs = new Set(
      testdataHelper.getContent('searchPage.searchResultTabs'),
    );

    return expectedSearchTabs;
  };

  verifySearchTabsDisplayed = async () => {
    const searchTabs = this.getSearchResultsTab();

    for (let i = 0; i < searchTabs.length; i++) {
      await commons.waitUntil(await this.searchResultTabs[searchTabs[i]], 60);
    }
  };

  verifySearchTabsLanding = async (tabName) => {
    switch (tabName) {
      case 'Shows':
        await showDetailsPage.verifyShowLandingAnchorDetails();
        break;
      case 'Episodes':
      case 'Extras':
        await videoPlayerPage.verifyVideoPlayerAnchorDetails();
        break;
      default:
        break;
    }
  };

  verifyLandingPageBasedOnContent = async () => {
    const searchTabs = testdataHelper.getContent('searchPage.searchResultTabs');

    for (let i = 0; i < searchTabs.length; i++) {
      await commons.waitUntil(this.searchResultTabs[searchTabs[i]]);
      await commons.click(this.searchResultTabs.Shows);
      const showResultsTab = await commons.fetchAttributeData(
        this.searchResultTabs[searchTabs[i]],
        'label',
      );

      if (
        showResultsTab.includes('Shows') ||
        showResultsTab.includes('Episodes') ||
        showResultsTab.includes('Extras')
      ) {
        let showTabClick = await commons.fetchAttributeData(
          this.searchResultTabs[searchTabs[i]],
          'selected',
        );

        while (showTabClick !== 'true') {
          await commons.userAction('right');
          showTabClick = await commons.fetchAttributeData(
            this.searchResultTabs[searchTabs[i]],
            'selected',
          );
        }
        await commons.waitUntil(this.firstContentTitle, 80);
        await commons.userAction('down');
        await commons.userAction('select');
        await this.verifySearchTabsLanding(searchTabs[i], 60);
        await commons.userAction('menu');
        await commons.waitUntil(this.searchResultTabs[searchTabs[i]]);
      }
    }
  };

  verifySearchedContentAndItsLandingPage = async () => {
    await this.verifyIfSearchResultsLoaded();
    await this.verifyResultsIncludeSearchText();
    await this.verifySearchTabsDisplayed();
    await this.verifyLandingPageBasedOnContent();
  };

  scrollToChannel = async (searchTerm) => {
    const showName = testdataHelper.getContent(`searchPage.${searchTerm}`);

    await commons.sendText(this.search_txtBx, showName, 20);
    const searchResults = await commons.findElements(this.contentByIndex, 20);

    await commons.click(searchResults[1], 30);
    while (!(await commons.elementExists(this.focusedChannel_lbl, 5))) {
      await commons.userAction('down');
    }
    await commons.userAction('select');
  };
}

module.exports = new SearchPage();
