const { BasePage, mobileActions, testdataHelper } = require('./basePage');

const menuPage = require('./menuPage');
const homePage = require('./homePage');
const profilePage = require('./profilePage');

const commons = mobileActions;

class AccountPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('accountPage', locator);
  }

  #signIn_btn = this.#getSelectorData('signIn_btn');

  #getAccountPageTab = this.#getSelectorData('getAccountPageTab');

  signUp_btn = this.getElementByPage('signInPage', 'signUp_btn');

  signOut_btn = this.#getSelectorData('signOut_btn');

  signedInEmail_txt = this.#getSelectorData('signedInEmail_txt');

  signOutPopUp_btn = this.#getSelectorData('signOutPopUp_btn');

  accountPageTabsList = this.#getSelectorData('accountPageTabsList');

  focusedSettingsPage = this.#getSelectorData('focusedSettingsPage');

  focusedHelpPage = this.#getSelectorData('focusedHelpPage');

  focusedAboutPage = this.#getSelectorData('focusedAboutPage');

  focusedAboutSignOutPage = this.#getSelectorData('focusedAboutSignOutPage');

  accountPageTabs = {
    Settings: this.getCustomLocator(this.#getAccountPageTab, 'Settings'),
    Help: this.getCustomLocator(this.#getAccountPageTab, 'Help'),
    About: this.getCustomLocator(this.#getAccountPageTab, 'About'),
    DebugSettings: this.getCustomLocator(
      this.#getAccountPageTab,
      'Debug Settings',
    ),
    'Sign Out': this.getCustomLocator(this.#getAccountPageTab, 'Sign Out'),
  };

  accountPageTabsFocused = {
    Settings: this.focusedSettingsPage,
    Help: this.focusedHelpPage,
    About: this.focusedAboutPage,
    'Sign Out': this.focusedAboutSignOutPage,
  };

  navigateToAccountPageTabs = async (tabName) => {
    const accountTabsElementsList = await commons.findElements(
      this.accountPageTabsList,
    );
    const isFirstTabFocused = await commons.fetchAttributeData(
      accountTabsElementsList[0],
      'focused',
    );

    if (isFirstTabFocused === 'false') {
      await commons.userAction('menu');
    }

    for (let i = 0; i < accountTabsElementsList.length; i++) {
      const element = accountTabsElementsList[i];
      const label = await commons.fetchAttributeData(element, 'label');
      const isFocused = await commons.fetchAttributeData(element, 'focused');

      if (label === tabName && isFocused === 'true') {
        break;
      }

      await commons.userAction('right');
    }
  };

  navigateToSignIn = async () => {
    // click on setting Button
    await commons.click(this.#signIn_btn);
  };

  validateCtaAccountPage = async () => {
    await menuPage.navigateToPage('Account');
    await commons.waitUntil(this.#signIn_btn, 30);
    await commons.waitUntil(this.signUp_btn, 30);
  };

  setDebugEnvironment = async () => {
    await menuPage.navigateToPage('Account');
    await commons.waitUntil(this.accountPageTabs.Settings, 10);
    const isSettingTabFocussed = await commons.fetchAttributeData(
      this.accountPageTabs.Settings,
      'focused',
    );

    if (!isSettingTabFocussed) await commons.userAction('menu'); // focus shifts to setting tab
    await commons.click(this.accountPageTabs.DebugSettings, 10);
    await commons.userAction('down');
    await commons.userAction('right');
    for (let i = 0; i <= 10; i++) {
      await commons.userAction('down');
    }
    await commons.userAction('select');
  };

  /**
   * On the basis of user type( Default, Kids), the below function will confirm Account Sub Menu list length accordingly.
   */

  getUserAccountMenuItems = (profileName) => {
    const accountType = {
      Default: 'defaultUserAccountItemListTvos',
      Kids: 'kidsUserAccountItemListTvos',
    };

    return testdataHelper.getContent(`accountPage.${accountType[profileName]}`);
  };

  /**
   * The below function will verify the Account sub menu list based on user type (Default, Kids).
   *
   * @param profileName
   */
  verifyAccountPage = async (profileName) => {
    await homePage.navigateToManagaeProfile();
    await profilePage.selectProfile(profileName);
    await menuPage.navigateToPage('Account');
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      await commons.waitUntil(
        await this.accountPageTabs[accountMenuList[i]],
        60,
      );
    }
  };

  /**
   * The below function will navigate to the account sub menu pages and verify based on user type (Default, Kids).
   *
   * @param profileName
   */
  verifyAccountSubNavigationPage = async (profileName) => {
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      await commons.waitUntil(
        await this.accountPageTabs[accountMenuList[i]],
        60,
      );

      await commons.click(await this.accountPageTabs[accountMenuList[i]]);
      await commons.waitUntil(
        await this.accountPageTabsFocused[accountMenuList[i]],
      );
    }
  };
}

module.exports = new AccountPage();
