const signInPage = require('./signInPage');
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');
const searchPage = require('./searchPage');
const videoPlayerPage = require('./videoPlayerPage');
const showDetailsPage = require('./showDetailsPage');
const sportsPage = require('./sportsPage');
const onboardingPage = require('./onboardingPage');
const WelcomePage = require('./welcomePage');

const welcomePage = new WelcomePage();
const homePage = require('./homePage');
const accountPage = require('./accountPage');
const myListPage = require('./myListPage');
const browsePage = require('./browsePage');
const NetworkLandingPage = require('./networkLandingPage');

const networkLandingPage = new NetworkLandingPage();

module.exports = {
  accountPage,
  homePage,
  signInPage,
  menuPage,
  profilePage,
  sportsPage,
  onboardingPage,
  searchPage,
  showDetailsPage,
  videoPlayerPage,
  welcomePage,
  myListPage,
  browsePage,
  networkLandingPage,
};
