const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class WelcomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('welcomePage', locator);
  }

  logoImageView = this.#getSelectorData('logoImageView');

  signIn_btn = this.getElementByPage('signInPage', 'signIn_btn');

  welcome_txt = this.#getSelectorData('welcome_txt');

  welcomeBody_lbl = this.#getSelectorData('welcomeBody_lbl');

  welocmeFooter_lbl = this.#getSelectorData('welocmeFooter_lbl');

  subscribeNow_btn = this.#getSelectorData('subscribeNow_btn');

  userName_txtBx = this.getElementByPage('signInPage', 'userName_txtBx');

  cancel_btn = this.getElementByPage('basePage', 'cancel_btn');

  password_txtBx = this.getElementByPage('signInPage', 'password_txtBx');

  continue_btn = this.getElementByPage('preLaunchPage', 'continue_btn');

  verifyWelcomeScreen = async () => {
    await commons.waitUntil(this.logoImageView);
    await commons.waitUntil(this.signIn_btn);
    await commons.waitUntil(this.welcome_txt);
    await commons.waitUntil(this.welcomeBody_lbl);
    await commons.waitUntil(this.welocmeFooter_lbl);
    await commons.waitUntil(this.subscribeNow_btn);
  };

  verifyLandingPageOfWelcomeScreen = async (CTAName) => {
    await commons.waitUntil(this.welcome_txt);
    if (CTAName === 'Subscribe Now') {
      await commons.click(this.subscribeNow_btn);
      await commons.isEnabled(this.continue_btn);
    } else if (CTAName === 'Sign In') {
      await commons.waitUntil(this.signIn_btn, 20);
      await commons.click(this.signIn_btn);
      await commons.waitUntil(this.userName_txtBx);
      await commons.waitUntil(this.password_txtBx);
    }
    await commons.userAction('menu');
    if (!(await commons.elementExists(this.welcome_txt))) {
      await commons.userAction('menu');
    }
    await commons.waitUntil(this.welcome_txt, 20);
  };
}

module.exports = WelcomePage;
