const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;
const menuPage = require('./menuPage');

class MyListPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myListPage', locator);
  }

  #favorite_btn = this.#getSelectorData('favorite_btn');

  #myListPage_lbl = this.#getSelectorData('myListPage_lbl');

  #myListPageAsset_lbl = this.#getSelectorData('myListPageAsset_lbl');

  #myListPageAssetLogo_lbl = this.#getSelectorData('myListPageAssetLogo_lbl');

  #myListPageAsset = this.#getSelectorData('myListPageAsset');

  #myListEmptyStateTitle = this.#getSelectorData('myListEmptyStateTitle');

  #myListBrowseShows = this.#getSelectorData('myListBrowseShows');

  #discoveryOriginals_lbl = this.getElementByPage(
    'browsePage',
    'discoveryOriginals_lbl',
  );

  addToFavorites = async () => {
    await commons.waitUntil(this.#favorite_btn);
    await commons.userAction('right');
    await commons.userAction('select');
    const title = await commons.fetchAttributeData(
      this.#myListPageAssetLogo_lbl,
      'label',
    );

    this.addToMyListShows(title);
  };

  removeFromMyList = async (showName) => {
    await commons.waitUntil(this.#myListPage_lbl);
    await commons.userAction('select');
    await commons.waitUntil(
      this.getCustomLocator(this.#myListPageAsset_lbl, showName),
    );
    await commons.waitUntil(this.#favorite_btn);
    await commons.userAction('right');
    await commons.userAction('select');
  };

  addShowsToMylistFromBrowse = async () => {
    await menuPage.navigateToPage('My List');
    await commons.waitUntil(this.#myListEmptyStateTitle);
    await commons.waitUntil(this.#myListBrowseShows);

    await commons.userAction('select');
    await commons.waitUntil(this.#discoveryOriginals_lbl);

    for (let i = 0; i < 4; i++) {
      await commons.userAction('down');
    }
    await commons.userAction('select');
    await this.addToFavorites();

    const title = await commons.fetchAttributeData(
      this.#myListPageAssetLogo_lbl,
      'label',
    );

    this.addToMyListShows(title);

    await commons.userAction('menu');
  };

  /**
   * There is ambiguity between how the Feature vs Steps are written.
   * There exists language of 'shows' but also uses language of 'a show'.
   * Also, it does not pass in a 'showCount' parameter.
   * This function will verify 1 show.
   *
   * @param {boolean} shouldHaveShows Whether or not My List page should have a show or shows.
   */
  verifyShowsInMyList = async (shouldHaveShows) => {
    await menuPage.navigateToPage('My List');

    if (shouldHaveShows) {
      const titleRaw = await commons.fetchAttributeData(
        this.#myListPageAsset,
        'name',
      );

      assert(
        titleRaw,
        `Within verifyShowsInMyList(), Current Show is ${titleRaw}`,
      );
    } else {
      await commons.waitUntil(this.#myListEmptyStateTitle);
    }

    await menuPage.navigateToPage('Home');
  };

  removeShowFromMyListPage = async () => {
    await menuPage.navigateToPage('My List');
    await commons.waitUntil(this.#myListPage_lbl);
    await commons.userAction('select');
    await commons.waitUntil(this.#favorite_btn);
    await commons.userAction('right');
    await commons.userAction('select');
    await commons.userAction('menu');
  };
}

module.exports = new MyListPage();
