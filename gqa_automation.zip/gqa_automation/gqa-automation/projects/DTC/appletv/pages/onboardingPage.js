const assert = require('assert');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const menuPage = require('./menuPage');
const accountPage = require('./accountPage');
const homePage = require('./homePage');
const signInPage = require('./signInPage');

const commons = mobileActions;

class OnboardingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('onboardingPage', locator);
  }

  upgradePass_lbl = this.getElementByPage('videoPlayerPage', 'upgradePass_lbl');

  viewPasses_lbl = this.getElementByPage('videoPlayerPage', 'viewPasses_lbl');

  signIn_btn = this.getElementByPage('signInPage', 'signIn_btn');

  signUp_btn = this.getElementByPage('signInPage', 'signUp_btn');

  focusedSignInPage = this.#getSelectorData('focusedSignInPage');

  chosePlan_txt = this.#getSelectorData('chosePlan_txt');

  registerFree_lbl = this.#getSelectorData('registerFree_lbl');

  register_btn = this.#getSelectorData('register_btn');

  firstName_txtBx = this.#getSelectorData('firstName_txtBx');

  password_txtBx = this.#getSelectorData('password_txtBx');

  selectGender = this.#getSelectorData('selectGender');

  genderType = this.#getSelectorData('genderType');

  continue_btn = this.#getSelectorData('continue_btn');

  firstTileOnFeaturedRail_lbl = this.getElementByPage(
    'homePage',
    'firstTileOnFeaturedRail_lbl',
  );

  startWatchingAnonymousUser_lbl = this.#getSelectorData(
    'startWatchingAnonymousUser_lbl',
  );

  network_img = this.#getSelectorData('network_img');

  firstName_lbl = this.#getSelectorData('firstName_lbl');

  firstNameSend_txt = this.#getSelectorData('firstNameSend_txt');

  email_lbl = this.#getSelectorData('email_lbl');

  pass_lbl = this.#getSelectorData('pass_lbl');

  gender_txtBx = this.#getSelectorData('gender_txtBx');

  gender_lbl = this.#getSelectorData('gender_lbl');

  close_btn = this.#getSelectorData('close_btn');

  inactiveSub_lbl = this.#getSelectorData('inactiveSub_lbl');

  signOut_cta = this.#getSelectorData('signOut_cta');

  choosePlan_cta = this.#getSelectorData('choosePlan_cta');

  selectCTAAndVerify = async (CTA) => {
    switch (CTA) {
      case 'Sign Up': {
        await this.navigateToSignUpLandingPage();
        break;
      }
      case 'Sign In': {
        await commons.click(this.signIn_btn);
        await commons.elementExists(this.focusedSignInPage);
        await commons.userAction('menu');
        break;
      }
      default:
        break;
    }
  };

  /**
   * The below function used to navigate to signup landing page
   */

  navigateToSignUpLandingPage = async () => {
    if (await commons.elementExists(this.startWatchingAnonymousUser_lbl)) {
      await commons.click(this.signUp_btn);
      await commons.userAction('menu');
      await commons.waitUntil(this.chosePlan_txt);
      return;
    }

    await commons.waitUntil(accountPage.accountPageTabs.settings, 20);
    await commons.userAction('select');
    await commons.userAction('down');
    await commons.userAction('down');
    await commons.userAction('select');
    await commons.userAction('menu');
    await commons.waitUntil(this.chosePlan_txt);
  };

  navigateToPlanPickerPage = async () => {
    await menuPage.navigateToPage('Account');
    await commons.click(this.signUp_btn);
    await commons.userAction('menu');
    await commons.waitUntil(this.chosePlan_txt);
  };

  verifyRegisterFreeCta = async () => {
    await commons.waitUntil(this.registerFree_lbl);
    await commons.waitUntil(this.register_btn);
  };

  selectAndCompleteRegistration = async () => {
    await commons.click(this.register_btn);
    await this.createFreeAccount();
  };

  verifyAccountCreation = async () => {
    await commons.click(this.close_btn);
    await menuPage.assertPage('Home');
  };

  /**
   * This function is used to create a new account from register screen. This will generate random email, first name and reads password, DoB from testData.yml.
   */

  createFreeAccount = async () => {
    const email = `${Math.random().toString(36).substring(2)}@disco.com`;

    const firstName = `Automation_${Math.random().toString(36).substring(2)}`;

    await commons.click(this.firstName_txtBx, 10);
    await commons.waitUntil(this.firstName_lbl);
    await commons.sendText(this.firstNameSend_txt, firstName, 10);
    await signInPage.pressNextOrDoneBtn();

    await commons.waitUntil(this.email_lbl);
    await commons.sendText(this.firstNameSend_txt, email, 10);
    await signInPage.pressNextOrDoneBtn();

    await commons.waitUntil(this.pass_lbl);
    await commons.sendText(
      this.firstNameSend_txt,
      testdataHelper.getContent(`registrationPage.password`),
    );

    await signInPage.pressNextOrDoneBtn();

    await signInPage.pressNextOrDoneBtn();

    await commons.click(this.gender_txtBx, 10);

    await commons.waitUntil(this.gender_lbl);

    await commons.sendText(
      this.firstNameSend_txt,
      testdataHelper.getContent(`registrationPage.yearOfBirth`),
    );
    await signInPage.pressNextOrDoneBtn();

    await commons.click(this.selectGender);

    await commons.click(this.genderType);
    await commons.userAction('down');
    await commons.userAction('down');
    await commons.userAction('select');

    await commons.userAction('down');
    await commons.userAction('select');

    await commons.click(this.continue_btn);
  };

  /**
   *
   * @param {string} contentType - whether the content type if VOD/Linear
   * @param {string} userType  - whether the user type is anonymous/lapsed
   * This function will navigate and select the shows/content based on the contentType & userType
   */

  navigateAndSelectContent = async (contentType, userType) => {
    if (contentType.includes('Sports VOD') && userType.includes('anonymous')) {
      await menuPage.navigateToPage('Sports');
      await homePage.scrollToRail('Upcoming');
      await commons.userAction('select');
    } else if (
      contentType.includes('Entertainment VOD') &&
      userType.includes('anonymous')
    ) {
      await homePage.scrollToRail('Free episodes');
      await commons.userAction('select');
    } else if (
      contentType.includes('Entertainment VOD') &&
      userType.includes('lapsed')
    ) {
      await homePage.scrollToRail('Featured');
      await commons.userAction('select');
      await this.selectFirstEpisode();
    } else if (
      contentType.includes('Entertainment Linear') &&
      userType.includes('lapsed')
    ) {
      await homePage.scrollToNetworkRail();
      await commons.userAction('select');
      await commons.waitUntil(this.network_img);
      await commons.userAction('select');
      await this.selectFirstEpisode();
    }
  };

  selectFirstEpisode = async () => {
    await commons.waitUntil(this.signUp_btn);
    await commons.userAction('down');
    await commons.userAction('down');
    await commons.userAction('select');
  };

  /**
   * The below function will validate the subscribe to watch screen whether the required elements are displayed
   */
  verifySubscribeToWatchScreen = async () => {
    await commons.elementExists(this.startWatchingAnonymousUser_lbl);
    await commons.elementExists(this.signIn_btn);
    await commons.elementExists(this.signUp_btn);
  };

  /**
   * The below function will validate the upgrade to watch screen whether the required elements are displayed
   */
  validateUpgradeToWatchScreen = async () => {
    assert(
      (await commons.elementExists(this.viewPasses_lbl)) &&
        (await commons.elementExists(this.upgradePass_lbl)),
      `View Passes is not showing on upgrade to watch screen`,
    );
  };

  /**
   * The below function will validate the Lapsed/Inactive Subscription screen whether the required elements are displayed
   */
  verifyInactiveSubscriptionScreen = async () => {
    assert(
      (await commons.elementExists(this.inactiveSub_lbl)) &&
        (await commons.elementExists(this.choosePlan_cta)),
      `View Passes is not showing on upgrade to watch screen`,
    );
    await commons.waitUntil(this.signOut_cta);
    await commons.click(this.signOut_cta);
    await commons.userAction('down');
    await commons.userAction('select');
  };
}

module.exports = new OnboardingPage();
