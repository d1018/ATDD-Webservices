const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const homePage = require('./homePage');
const menuPage = require('./menuPage');

const { VRC, PROP } = commons;

class NetworkLandingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('networkLandingPage', locator);
  }

  network_logo = this.#getSelectorData('network_logo');

  signUp_btn = this.#getSelectorData('network_logo');

  watchNow_cta = this.#getSelectorData('network_logo');

  focusedThumbnail = this.getElementByPage('homePage', 'focusedThumbnail');

  networkLogo_img = this.getElementByPage('homePage', 'networkLogo_img');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  focusedHeroTitle_txt = this.getElementByPage(
    'homePage',
    'focusedHeroTitle_txt',
  );

  navigateToSelectNetwork = async (networkType) => {
    let i = 20;

    while (i > 0) {
      const heroTitleTxtFromScreen = await commons.fetchAttributeData(
        this.focusedHeroTitle_txt,
        PROP.TEXT_CONTENT,
      );

      if (heroTitleTxtFromScreen === networkType) {
        await commons.userAction(VRC.SELECT);
        break;
      } else {
        await commons.userAction(VRC.RIGHT);
        i -= 1;
      }
    }
  };

  // Checking for the Show Rail whose height is more than 300
  verifyShowRailIsPresent = async () => {
    let railHeight;
    const i = 10;

    await commons.userAction(VRC.DOWN);

    if (this.returnGeoLocation() === 'america') {
      await commons.userAction(VRC.DOWN, 2, 1);
    } else {
      await commons.userAction(VRC.DOWN);
    }
    while (i > 0) {
      railHeight = await commons.fetchAttributeData(
        this.focusedThumbnail,
        PROP.HEIGHT,
      );
      if (railHeight > 300) {
        break;
      } else {
        await homePage.moveToNextRail();
      }
    }

    if (railHeight < 300) {
      throw new Error('Show Rail did not found');
    }
  };

  // Checking for the Episode Rail whose height is less than 300
  verifyEpisodeRailIsPresent = async () => {
    let railHeight;
    const i = 10;

    await commons.tryUntil(this.watchNow_cta, VRC.UP, 10, 0.5);

    await commons.userAction(VRC.DOWN);
    while (i > 0) {
      railHeight = await commons.fetchAttributeData(
        this.focusedThumbnail,
        PROP.HEIGHT,
      );
      if (railHeight < 300) {
        break;
      } else {
        await homePage.moveToNextRail();
      }
    }

    if (railHeight > 300) {
      throw new Error('Episode Rail did not found');
    }
  };

  validateEntertainmentContent = async () => {
    // Checking for the Show Rail whose height is more than 300
    await this.verifyShowRailIsPresent();
    // Checking for the Episode Rail whose height is less than 300
    await this.verifyEpisodeRailIsPresent();
    await menuPage.navigateToPage('Home');
    await homePage.scrollToRail('', true);
  };

  validateAuthenticatedEntertainmentContent = async () => {
    await commons.assertExists(this.watchNow_cta, 1);
    // checking for the Recommended For You Rail
    await homePage.verifyRailPresent('Recommended for You', true);
    await this.validateEntertainmentContent();
  };

  validateSportContent = async () => {
    await commons.assertExists(this.network_logo, 1);

    await homePage.scrollToRail('Live', true);
    await homePage.scrollToRail('Upcoming', true);
  };

  validateAuthenticatedSportsContent = async () => {
    await commons.assertExists(this.watchNow_cta, 1);
    await this.validateSportContent();
  };

  validateAnonymousEntertainmentContent = async () => {
    await commons.assertExists(this.signUp_btn, 1);
    await this.validateEntertainmentContent();
  };

  validateAnonymousSportsContent = async () => {
    await commons.assertExists(this.signUp_btn, 1);
    await this.validateSportContent();
  };

  validateEntertainmentNetworkLandingPage = async () => {
    await this.navigateToSelectNetwork('TLC');
    if (this.getAnonymousUserValue()) {
      await this.validateAnonymousEntertainmentContent();
    } else {
      await this.validateAuthenticatedEntertainmentContent();
    }
  };

  validateSportsNetworkLandingPage = async () => {
    await this.navigateToSelectNetwork('Eurosport 1 UK');
    if (this.getAnonymousUserValue()) {
      await this.validateAnonymousSportsContent();
    } else {
      await this.validateAuthenticatedSportsContent();
    }
  };

  /**
   * The below function will switch on Entertainment and Sports network channel
   *
   * @param {*} network will select Entertainment and Sports Network
   */
  selectAndValidateNetworkLandingPage = async (network) => {
    if (network === 'Entertainment') {
      await this.validateEntertainmentNetworkLandingPage();
    } else if (network === 'Sports' && this.returnGeoLocation() !== 'america') {
      await commons.tryUntil(this.forYou_lbl, VRC.BACK, 5, 1);
      await homePage.scrollToRail('');
      await this.validateSportsNetworkLandingPage();
    }
  };

  verifyNetworkRailForKidsProfile = async () => {
    await homePage.scrollToRail('', this.returnGeoLocation() === 'america');
  };
}

module.exports = new NetworkLandingPage();
