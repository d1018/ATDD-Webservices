const {
  BasePage,
  remoteActions,
  customErrors,
  skipReason,
} = require('./basePage');

const commons = remoteActions;
const menuPage = require('./menuPage');
const homePage = require('./homePage');

const { SkipError } = customErrors;
const { PROP, VRC } = commons;

let watchLiveCurrentTime;
let watchFromStartCurrentTime;

class EventDetailPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('eventDetailPage', locator);
  }

  upgrade_lbl = this.#getSelectorData('upgrade_lbl');

  signIn_btn = this.#getSelectorData('signIn_btn');

  signUp_btn = this.#getSelectorData('signUp_btn');

  sportType_lbl = this.#getSelectorData('sportType_lbl');

  title_lbl = this.#getSelectorData('title_lbl');

  subtitle_lbl = this.#getSelectorData('subtitle_lbl');

  eventStartsIn_lbl = this.#getSelectorData('eventStartsIn_lbl');

  eventCountdownTimer_lbl = this.#getSelectorData('eventCountdownTimer_lbl');

  eventCountdownMins_lbl = this.#getSelectorData('eventCountdownMins_lbl');

  eventCountdownSecs_lbl = this.#getSelectorData('eventCountdownSecs_lbl');

  focusedEventDetailPage = this.#getSelectorData('focusedEventDetailPage');

  sportsLiveRail_lbl = this.getElementByPage(
    'sportsPage',
    'sportsLiveRail_lbl',
  );

  watchLive_btn = this.#getSelectorData('watchLive_btn');

  watchFromStart_btn = this.#getSelectorData('watchFromStart_btn');

  focusedWatchLive_btn = this.#getSelectorData('focusedWatchLive_btn');

  currentTime_lbl = this.#getSelectorData('currentTime_lbl');

  focusedWatchFromStart_btn = this.#getSelectorData(
    'focusedWatchFromStart_btn',
  );

  /**
   * The below function will navigate to sports page and scroll to first tile upcoming rail
   *
   */
  selectUpcomingRailFirstEvent = async () => {
    await menuPage.navigateToPage('Sports');
    await homePage.scrollToRail('Upcoming', true);
    await commons.userAction(VRC.ENTER, 1, 5);
  };

  /**
   * The below function will verify cta button on event landing page
   */
  verifyCTAonPlayer = async () => {
    await commons.assertExists(this.upgrade_lbl);
    if (this.getLoggedInUser()) {
      await commons.assertDoesNotExist(this.signIn_btn);
      await commons.assertDoesNotExist(this.signUp_btn);
    } else {
      await commons.assertExists(this.signIn_btn);
      await commons.assertExists(this.signUp_btn);
    }
  };

  /**
   * The below function will verify the element on Event landing page
   */
  validateEventDeatilPage = async () => {
    const items = [
      this.sportType_lbl,
      this.title_lbl,
      this.subtitle_lbl,
      this.eventStartsIn_lbl,
      this.eventCountdownTimer_lbl,
      this.eventCountdownMins_lbl,
      this.eventCountdownSecs_lbl,
    ];

    for (let i = 0; i < items.length; i++) {
      await commons.assertExists(items[i], 3);
    }
  };

  /**
   * The below function will verify live lable
   */
  checkLiveEventRailAvailability = async () => {
    if (!(await commons.elementExists(this.sportsLiveRail_lbl, 5))) {
      throw new SkipError(skipReason.noLiveEvent);
    }
  };

  /**
   * The below function will select the live rail first event
   */
  selectLiveRailFirstEvent = async () => {
    await homePage.scrollToRail('Live', true);
    await commons.userAction(VRC.SELECT, 1, 5);
  };

  /**
   * The below function will verify the cta and element on live Event page
   */
  validateLiveEventDeatilPage = async () => {
    await commons.assertExists(this.watchLive_btn, 5);
    await commons.assertExists(this.watchFromStart_btn, 5);
  };

  /**
   * The below function will verify CTA Watch Live button On VOD player
   */
  selectLiveCtaAndValidateVOD = async () => {
    await commons.assertExists(this.watchLive_btn, 5);
    await commons.userAction(VRC.RIGHT, 1, 5);
    await commons.userAction(VRC.SELECT, 1, 5);
    await commons.assertVideoIsPlaying();
    watchLiveCurrentTime = await this.progressTimeText();
  };

  /**
   * The below function will show the VOD player controls
   */
  showPlayerControls = async () => {
    await commons.userAction(VRC.UP, 1, 2);
  };

  /**
   * The below function will show the video progress current time
   */
  progressTimeText = async () => {
    await this.showPlayerControls();
    return commons.fetchAttributeData(this.currentTime_lbl, PROP.TEXT_CONTENT);
  };

  /**
   * The below function will verify CTA Watch from start button On VOD player
   */
  selectStartCtaAndValidateVOD = async () => {
    await commons.userAction(VRC.BACK, 1, 5);
    await commons.userAction(VRC.DOWN, 1, 5);
    await commons.userAction(VRC.SELECT, 1, 5);
    await commons.assertVideoIsPlaying();
    watchFromStartCurrentTime = await this.progressTimeText();

    if (!(watchLiveCurrentTime > watchFromStartCurrentTime)) {
      throw new Error(
        'Watch from start CTA is not started from starting position',
      );
    }
  };
}

module.exports = new EventDetailPage();
