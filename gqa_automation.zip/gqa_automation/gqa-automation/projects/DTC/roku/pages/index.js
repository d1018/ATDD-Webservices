const accountPage = require('./accountPage');
const homePage = require('./homePage');
const searchPage = require('./searchPage');
const signInPage = require('./signInPage');
const menuPage = require('./menuPage');
const myListPage = require('./myListPage');
const profilePage = require('./profilePage');
const sportsPage = require('./sportsPage');
const showDetailsPage = require('./showDetailsPage');
const videoPlayerPage = require('./videoPlayerPage');
const networkLandingPage = require('./networkLandingPage');
const onboardingPage = require('./onboardingPage');
const eventDetailPage = require('./eventDetailPage');
const epgTVGuidePage = require('./epgTVGuidePage');
const upNextPage = require('./upNextPage');
const welcomePage = require('./welcomePage');
const browsePage = require('./browsePage');

module.exports = {
  accountPage,
  homePage,
  searchPage,
  signInPage,
  menuPage,
  myListPage,
  profilePage,
  sportsPage,
  showDetailsPage,
  videoPlayerPage,
  networkLandingPage,
  onboardingPage,
  eventDetailPage,
  epgTVGuidePage,
  upNextPage,
  welcomePage,
  browsePage,
};
