const { ok } = require('assert');

const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;

class VideoPlayerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('videoPlayerPage', locator);
  }

  videoPlayerScene = this.#getSelectorData('videoPlayerScene');

  currentTime = this.#getSelectorData('currentTime_lbl');

  verifyVideoPlayerAnchorDetails = async () => {
    await commons.assertVideoIsPlaying();
    await commons.assertExists(this.videoPlayerScene);
  };

  isVideoPlaying = async () => {
    await this.verifyVideoPlayerAnchorDetails();
  };

  scrubVideo = async (percentage) => {
    await commons.scrubVideo(this.currentTime, percentage);
  };

  validateResumePoint = async (percentage) => {
    const video = await commons.videoDetails();
    const newVideoPosition = video.videoPos / 1000;
    const videoLength = video.videoLength / 1000;
    const actualPercentage = (newVideoPosition * 100) / videoLength;

    ok(
      actualPercentage <= percentage + 2 && actualPercentage >= percentage - 2,
      `Actual: ${actualPercentage}%, Expected: ${percentage}%`,
    );
  };
}

module.exports = new VideoPlayerPage();
