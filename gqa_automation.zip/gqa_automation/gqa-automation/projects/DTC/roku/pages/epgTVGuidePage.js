const assert = require('assert');

const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;

const { VRC, PROP, COMP } = commons;

class EpgTVGuidePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('epgTVGuidePage', locator);
  }

  today_label = this.#getSelectorData('today_label');

  focusedToday_lbl = this.#getSelectorData('focusedToday_lbl');

  focusedOtherDate_lbl = this.#getSelectorData('focusedOtherDate_lbl');

  showTiming_lbl = this.#getSelectorData('showTiming_lbl');

  showTitle_lbl = this.#getSelectorData('showTitle_lbl');

  showSubTitle_lbl = this.#getSelectorData('showSubTitle_lbl');

  signIn_btn = this.getElementByPage('eventDetailPage', 'signIn_btn');

  signUp_btn = this.getElementByPage('eventDetailPage', 'signUp_btn');

  getDay = (requiredDay, numberOfDays = 0) => {
    const date = new Date();
    const options = { weekday: 'short' };
    let requiredDate;
    let num;

    if (requiredDay.toLowerCase() === 'previous') {
      date.setDate(date.getDate() - 1);
      requiredDate = date.getDate();
      num = new Date().setDate(new Date().getDate() - 1);
    } else if (requiredDay.toLowerCase() === 'tomorrow') {
      date.setDate(date.getDate() + 1);
      requiredDate = date.getDate();
      num = new Date().setDate(new Date().getDate() + 1);
    } else if (requiredDay.includes('last')) {
      date.setDate(date.getDate() + numberOfDays);
      requiredDate = date.getDate();
      num = new Date().setDate(new Date().getDate() + numberOfDays);
    } else if (requiredDay.includes('backward')) {
      date.setDate(date.getDate() + 7 - numberOfDays);
      requiredDate = date.getDate();
      num = new Date().setDate(new Date().getDate() + 7 - numberOfDays);
    } else if (requiredDay === 'today') {
      date.setDate(date.getDate());
      requiredDate = date.getDate();
      num = new Date().setDate(new Date().getDate());
    }

    return `${new Intl.DateTimeFormat('en-US', options).format(
      num,
    )} ${requiredDate}`;
  };

  verifyEpgMetaData = async () => {
    await commons.assertExists(this.showTiming_lbl, 10);
    await commons.checkProperty(
      this.showTiming_lbl,
      PROP.TEXT_CONTENT,
      '',
      COMP.NOT_EQUAL,
    );
    await commons.checkProperty(
      this.showTitle_lbl,
      PROP.TEXT_CONTENT,
      '',
      COMP.NOT_EQUAL,
    );
    await commons.checkProperty(
      this.showSubTitle_lbl,
      PROP.TEXT_CONTENT,
      '',
      COMP.NOT_EQUAL,
    );
  };

  verifyDisplayedContentMetaData = async (currentDate) => {
    if (
      currentDate === 'today' ||
      currentDate === 'tomorrow' ||
      currentDate === 'last' ||
      currentDate === 'live'
    ) {
      await this.verifyEpgMetaData();
    }
  };

  moveToToday = async () => {
    const todayIndex = await commons.fetchAttributeData(
      this.focusedToday_lbl,
      'index',
    );
    const focusedOtherDateIndex = await commons.fetchAttributeData(
      this.focusedOtherDate_lbl,
      'index',
    );

    const positionDifference = focusedOtherDateIndex - todayIndex;

    if (positionDifference > 0) {
      await commons.tryUntil(this.today_label, VRC.LEFT, 10, 1);
    } else if (positionDifference < 0) {
      await commons.tryUntil(this.today_label, VRC.RIGHT, 10, 1);
    } else if (positionDifference === 0) {
      await commons.assertExists(this.showTiming_lbl, 10);
    }
  };

  selectDay = async (day) => {
    if (day.toLowerCase() === 'last day') {
      await this.moveToToday();
      await commons.userAction(VRC.LEFT, 2, 2);
    } else if (day.toLowerCase() === 'tomorrow') {
      await commons.userAction(VRC.RIGHT, 2, 2);
    } else if (day.toLowerCase() === 'backward') {
      await commons.userAction(VRC.LEFT, 7, 2);
    } else if (day.toLowerCase() === 'forword') {
      await commons.userAction(VRC.RIGHT, 7, 2);
    }
  };

  verifyDaySelection = async (day) => {
    const selectedDate = await commons.fetchAttributeData(
      this.today_label,
      'text',
    );

    assert(
      selectedDate === day,
      'Today is not selected by default on the EPG screen',
    );
  };

  /**
   *
   * @param {string} direction - specify right or left based on navigation in EPG Day bar and pass that param to selectDay() function.
   */
  validateNavigationOnEPG = async (direction) => {
    const day = direction === 'right' ? 'forword' : 'backword';

    await this.selectDay(day);
  };

  isLiveContentDisplayed = async () => {
    await commons.userAction(VRC.DOWN, 15, 2);
    await this.verifyEpgMetaData();
  };

  clickOnLiveContent = async () => {
    await commons.userAction(VRC.ENTER);
  };

  selectBroadcastingContent = async () => {
    await commons.userAction(VRC.DOWN, 3, 2);
    await commons.userAction(VRC.ENTER);
  };
}

module.exports = new EpgTVGuidePage();
