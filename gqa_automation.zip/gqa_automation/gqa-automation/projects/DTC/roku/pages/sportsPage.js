const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const menuPage = require('./menuPage');

const { VRC, PROP, COMP } = commons;

class SportsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('sportsPage', locator);
  }

  eventDetailPage = this.#getSelectorData('eventDetailPage');

  sportsHeroTitle_lbl = this.#getSelectorData('sportsHeroTitle_lbl');

  sportsHeroDescription_lbl = this.#getSelectorData(
    'sportsHeroDescription_lbl',
  );

  sportsHeroTimeStamp_lbl = this.#getSelectorData('sportsHeroTimeStamp_lbl');

  sportsShowTitle_lbl = this.#getSelectorData('sportsShowTitle_lbl');

  sportsHeroLive_lbl = this.#getSelectorData('sportsHeroLive_lbl');

  focusedHeroPoster_img = this.getElementByPage(
    'homePage',
    'focusedHeroPoster_img',
  );

  videoPlayerScene = this.getElementByPage(
    'videoPlayerPage',
    'videoPlayerScene',
  );

  genreTab_lbl = this.getElementByPage('homePage', 'genreTab_lbl');

  allSportsLoaded_lbl = this.#getSelectorData('allSportsLoaded_lbl');

  allSportsFocused_lbl = this.#getSelectorData('allSportsFocused_lbl');

  secondarySportsPage_img = this.#getSelectorData('secondarySportsPage_img');

  verifySportsScreenAnchorDetails = async () => {
    if (await commons.waitTillVideoIsPlaying(20)) {
      await commons.assertExists(this.videoPlayerScene);
    } else {
      await commons.assertExists(this.eventDetailPage);
    }
  };

  verifySportsDetailsPage = async () => {
    await menuPage.assertPage('Sports', 5);
  };

  assertSportsHeroMetadata = async () => {
    const metadata = [
      this.focusedHeroPoster_img,
      this.sportsHeroTitle_lbl,
      this.sportsHeroDescription_lbl,
      this.sportsHeroTimeStamp_lbl,
      this.sportsShowTitle_lbl,
    ];

    for (let i = 0; i < metadata.length; i++) {
      await commons.assertExists(metadata[i], 2);
    }
  };

  assertLiveSportsRailMetadata = async () => {
    await commons.assertExists(this.sportsHeroLive_lbl);
    await this.assertSportsHeroMetadata();
  };

  verifyRailTileAndInteractiveHeroMetadata = async (railName) => {
    switch (railName) {
      case 'Upcoming':
      case 'Latest':
        await this.assertSportsHeroMetadata();
        break;
      case 'Live events':
        await this.assertLiveSportsRailMetadata();
        break;

      default:
        break;
    }
    await commons.userAction(VRC.BACK, 1, 2);
  };

  selectSecondaryGenreTab = async (genreName) => {
    await menuPage.assertPage('Sports', 10);
    await commons.waitUntil(this.genreTab_lbl, 10);
    while (
      await commons.checkProperty(
        this.genreTab_lbl,
        PROP.TEXT_CONTENT,
        genreName,
        COMP.NOT_EQUAL,
      )
    ) {
      await commons.userAction(VRC.RIGHT, 1);
    }
  };

  selectSportsCategoryPage = async (categoryName) => {
    await commons.assertExists(this.allSportsLoaded_lbl, 3);
    await commons.assertExists(this.allSportsFocused_lbl, 3);
    await commons.userAction(VRC.DOWN, 1, 2);
    let fetchedSportCategory;

    for (let i = 1; i <= 8; i++) {
      for (let j = 1; j < 5; j++) {
        fetchedSportCategory = String(
          await commons.fetchAttributeData(
            this.allSportsFocused_lbl,
            PROP.TEXT_CONTENT,
          ),
        ).trim();

        if (fetchedSportCategory === categoryName) {
          await commons.userAction(VRC.SELECT, 1, 2);
          return;
        }
        if (i % 2 === 0) {
          await commons.userAction(VRC.LEFT, 1, 2);
        } else {
          await commons.userAction(VRC.RIGHT, 1, 2);
        }
      }
      await commons.userAction(VRC.DOWN, 1, 2);
    }
    throw new Error(`could not find: ${categoryName} on All Sports page`);
  };

  verifySecondarySportsMetadata = async () => {
    await commons.assertExists(this.secondarySportsPage_img, 5);
    const secondaryMetadata = [
      this.sportsHeroTitle_lbl,
      this.sportsHeroDescription_lbl,
      this.sportsShowTitle_lbl,
    ];

    for (let i = 0; i < secondaryMetadata.length; i++) {
      await commons.assertDoesNotExist(secondaryMetadata[i], 2);
    }
  };
}
module.exports = new SportsPage();
