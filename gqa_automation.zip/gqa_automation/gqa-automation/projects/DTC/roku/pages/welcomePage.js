const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const { VRC, PROP, COMP } = commons;

class WelcomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('welcomePage', locator);
  }

  focusedWelcomePage = this.#getSelectorData('focusedWelcomePage');

  titleWelcomePage_lbl = this.#getSelectorData('titleWelcomePage_lbl');

  descriptionWelcomePage_txt = this.#getSelectorData(
    'descriptionWelcomePage_txt',
  );

  shortDescriptionWelcomePage_txt = this.#getSelectorData(
    'shortDescriptionWelcomePage_txt',
  );

  background_img = this.#getSelectorData('background_img');

  logo_img = this.#getSelectorData('logo_img');

  subscribeNow_btn = this.#getSelectorData('subscribeNow_btn');

  signIn_btn = this.#getSelectorData('signIn_btn');

  planPickerTitle_lbl = this.getElementByPage(
    'productPickerScene',
    'planPickerTitle_lbl',
  );

  signInDifferent_btn = this.getElementByPage(
    'signInPage',
    'signInDifferent_btn',
  );

  continue_btn = this.getElementByPage('signInPage', 'continue_btn');

  focusedSignInPage = this.getElementByPage('signInPage', 'focusedSignInPage');

  signInPageLogo_img = this.getElementByPage(
    'signInPage',
    'signInPageLogo_img',
  );

  signInPageTitle_lbl = this.getElementByPage(
    'signInPage',
    'signInPageTitle_lbl',
  );

  signInPageDesc_txt = this.getElementByPage(
    'signInPage',
    'signInPageDesc_txt',
  );

  userName_txtBx = this.getElementByPage('signInPage', 'userName_txtBx');

  password_txtBx = this.getElementByPage('signInPage', 'password_txtBx');

  showPassword_btn = this.getElementByPage('signInPage', 'showPassword_btn');

  signInCred_btn = this.getElementByPage('signInPage', 'signInCred_btn');

  forgotPassword_btn = this.getElementByPage(
    'signInPage',
    'forgotPassword_btn',
  );

  verifyWelcomeScreen = async () => {
    await commons.assertExists(this.focusedWelcomePage, 10);
    await commons.assertProperty(
      this.background_img,
      PROP.IMAGE,
      '',
      COMP.NOT_EQUAL,
    );
    await commons.assertProperty(this.logo_img, PROP.IMAGE, '', COMP.NOT_EQUAL);

    const title = testdataHelper.getContent('welcomePage.welcomeTitle');

    const title2 = testdataHelper.getContent('welcomePage.welcomeTitle2');

    const textFromScreen = await commons.fetchAttributeData(
      this.titleWelcomePage_lbl,
      'text',
      5,
    );

    if (!(textFromScreen === title || textFromScreen === title2)) {
      throw new Error(`Text is not matching: ${textFromScreen}`);
    }

    const descriptionTitle = testdataHelper.getContent(
      'welcomePage.descriptionTitle',
    );

    await commons.assertProperty(
      this.descriptionWelcomePage_txt,
      PROP.TEXT_CONTENT,
      descriptionTitle,
      COMP.EQUAL,
    );

    const shortDescriptionTitle = testdataHelper.getContent(
      'welcomePage.shortDescriptionTitle',
    );

    await commons.assertProperty(
      this.shortDescriptionWelcomePage_txt,
      PROP.TEXT_CONTENT,
      shortDescriptionTitle,
      COMP.EQUAL,
    );

    await commons.assertExists(this.subscribeNow_btn);
    const subscribeNowBtn = testdataHelper.getContent(
      'welcomePage.subscribeNowBtn',
    );

    await commons.assertProperty(
      this.subscribeNow_btn,
      PROP.TEXT_CONTENT,
      subscribeNowBtn,
      COMP.EQUAL,
    );

    await commons.assertExists(this.signIn_btn);
    const signInBtn = testdataHelper.getContent('welcomePage.signInBtn');

    await commons.assertProperty(
      this.signIn_btn,
      PROP.TEXT_CONTENT,
      signInBtn,
      COMP.EQUAL,
    );
  };

  verifyLandingPageOfWelcomeScreen = async (welcomeScreenCta) => {
    const title = testdataHelper.getContent('signInPage.signInTitle');
    const descriptionTitle = testdataHelper.getContent(
      'signInPage.descriptionTitle',
    );

    switch (welcomeScreenCta) {
      case 'Subscribe Now':
        await commons.assertExists(this.subscribeNow_btn, 5);
        await commons.userAction(VRC.ENTER);
        await commons.assertExists(this.planPickerTitle_lbl, 10);
        await commons.userAction(VRC.BACK);
        await commons.assertExists(this.focusedWelcomePage);
        break;
      case 'Sign In':
        await commons.userAction(VRC.DOWN, 1, 3);
        await commons.assertExists(this.signIn_btn);
        await commons.userAction(VRC.ENTER, 1, 4);
        await commons.waitUntil(this.continue_btn, 10);
        await commons.userAction(VRC.DOWN, 1, 3);
        await commons.assertExists(this.signInDifferent_btn, 5);
        await commons.userAction(VRC.ENTER, 1, 3);
        await commons.assertExists(this.focusedSignInPage, 5);
        await commons.assertProperty(
          this.signInPageLogo_img,
          PROP.IMAGE,
          '',
          COMP.NOT_EQUAL,
        );

        await commons.assertProperty(
          this.signInPageTitle_lbl,
          PROP.TEXT_CONTENT,
          title,
          COMP.EQUAL,
        );

        await commons.assertProperty(
          this.signInPageDesc_txt,
          PROP.TEXT_CONTENT,
          descriptionTitle,
          COMP.EQUAL,
        );

        await commons.assertExists(this.showPassword_btn, 5);
        await commons.assertExists(this.forgotPassword_btn, 5);
        await commons.assertExists(this.userName_txtBx, 5);
        await commons.userAction(VRC.ENTER);
        await commons.sendText('roku@gmail.com');
        await commons.userAction(VRC.BACK);
        await commons.userAction(VRC.DOWN, 1, 3);
        await commons.assertExists(this.password_txtBx, 5);
        await commons.userAction(VRC.ENTER);
        await commons.sendText('roku123');
        await commons.userAction(VRC.BACK);
        await commons.assertExists(this.signInCred_btn, 5);
        await commons.userAction(VRC.BACK);
        await commons.assertExists(this.focusedWelcomePage, 5);
        break;
      default:
        break;
    }
  };
}

module.exports = new WelcomePage();
