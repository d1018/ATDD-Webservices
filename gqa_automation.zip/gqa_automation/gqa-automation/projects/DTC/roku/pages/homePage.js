const { ok } = require('assert');
const assert = require('assert');
const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');
const searchPage = require('./searchPage');
const videoPlayerPage = require('./videoPlayerPage');

const { PROP, VRC, COMP } = commons;
const myListShowsOrder = [];

let numberOfRails = 0;

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  focusedHomePage = this.#getSelectorData('focusedHomePage');

  focusedShowDetailPage = this.getElementByPage(
    'showDetailPage',
    'focusedShowDetailPage',
  );

  showPageFirstCta_lbl = this.getElementByPage(
    'showDetailPage',
    'showPageFirstCta_lbl',
  );

  addedToMyList_lbl = this.#getSelectorData('addedToMyList_lbl');

  heroMyListIcon = this.#getSelectorData('heroMyListIcon');

  removedFromMyList_lbl = this.#getSelectorData('removedFromMyList_lbl');

  focusedRail = this.#getSelectorData('focusedRail');

  focusedCta = this.#getSelectorData('focusedCta');

  forYou_lbl = this.#getSelectorData('forYou_lbl');

  genreTab_lbl = this.#getSelectorData('genreTab_lbl');

  hero_btn = this.#getSelectorData('hero_btn');

  focusedKeyboard = this.getElementByPage('searchPage', 'focusedKeyboard');

  focusedThumbnail = this.#getSelectorData('focusedThumbnail');

  heroShowTitle = this.#getSelectorData('heroShowTitle');

  ratingLabel_txt = this.#getSelectorData('ratingLabel_txt');

  contentDescriptors_txt = this.#getSelectorData('contentDescriptors_txt');

  networkLogo_img = this.#getSelectorData('networkLogo_img');

  showPageShowTitle_img = this.getElementByPage(
    'showDetailPage',
    'showPageShowTitle_img',
  );

  firstThumbnailOnSearch = this.getElementByPage(
    'searchPage',
    'firstThumbnailOnSearch',
  );

  firstStandardThumbnail = this.getElementByPage(
    'searchPage',
    'firstStandardThumbnail',
  );

  showPageFocusedThumbnail = this.getElementByPage(
    'showDetailPage',
    'showPageFocusedThumbnail',
  );

  ratingShowDetailsPage_txt = this.getElementByPage(
    'showDetailPage',
    'ratingShowDetailsPage_txt',
  );

  videoPlayerSceneRating_txt = this.getElementByPage(
    'videoPlayerPage',
    'videoPlayerSceneRating_txt',
  );

  episode_lbl = this.getElementByPage('episodeLandingPage', 'episode_lbl');

  episodeRating_txt = this.getElementByPage(
    'episodeLandingPage',
    'episodeRating_txt',
  );

  signUpCta_lbl = this.getElementByPage('showDetailPage', 'signUpCta_lbl');

  signIn_btn = this.getElementByPage('sportsPage', 'signIn_btn');

  logIn_lbl = this.getElementByPage('accountPage', 'logIn_lbl');

  signOut_lbl = this.getElementByPage('accountPage', 'signOut_lbl');

  focusedRailMarkup = this.#getSelectorData('focusedRailMarkup');

  cancelBtn_lbl = this.getElementByPage('accountPage', 'cancelBtn_lbl');

  confirmBtn_lbl = this.getElementByPage('accountPage', 'confirmBtn_lbl');

  signOutBtn_lbl = this.getElementByPage('accountPage', 'signOutBtn_lbl');

  showsList = [
    testdataHelper.getContent('searchPage.multiContentShow'),
    testdataHelper.getContent('searchPage.myListShow1'),
    testdataHelper.getContent('searchPage.myListShow2'),
  ];

  myListToolTipInvisible_lbl = this.#getSelectorData(
    'myListToolTipInvisible_lbl',
  );

  focusedChannelLogo_img = this.#getSelectorData('focusedChannelLogo_img');

  focusedHeroTitle_txt = this.#getSelectorData('focusedHeroTitle_txt');

  focusedSportsPage = this.getElementByPage('sportsPage', 'focusedSportsPage');

  focusedHeroPoster_img = this.#getSelectorData('focusedHeroPoster_img');

  focusedHeroShowName_img = this.#getSelectorData('focusedHeroShowName_img');

  enlargedFocusedTitle_txt = this.#getSelectorData('enlargedFocusedTitle_txt');

  enlargedFocusedShowPoster_img = this.#getSelectorData(
    'enlargedFocusedShowPoster_img',
  );

  enlargedFocusedNetworkLogo_img = this.#getSelectorData(
    'enlargedFocusedNetworkLogo_img',
  );

  continueWatching_lbl = this.#getSelectorData('continueWatching_lbl');

  eventDetailPage = this.getElementByPage('sportsPage', 'eventDetailPage');

  myListCta_lbl = this.getElementByPage('showDetailPage', 'myListCta_lbl');

  upgradeTitle_lbl = this.getElementByPage(
    'upgradeToWatchPage',
    'upgradeTitle_lbl',
  );

  viewPasses_btn = this.getElementByPage(
    'upgradeToWatchPage',
    'viewPasses_btn',
  );

  sports_lbl = this.getElementByPage('sportsPage', 'sports_lbl');

  heroShowDescription_lbl = this.#getSelectorData('heroShowDescription_lbl');

  heroShowRating_lbl = this.#getSelectorData('heroShowRating_lbl');

  focusedHeroAddShow_btn = this.#getSelectorData('focusedHeroAddShow_btn');

  firstSavedShowTile = this.getElementByPage(
    'myListPage',
    'firstSavedShowTile',
  );

  focusedInLineHero_btn = this.#getSelectorData('focusedInLineHero_btn');

  focusedHeroDesc_txt = this.#getSelectorData('focusedHeroDesc_txt');

  selectGenreTab = async (genreName) => {
    const genreList = [];

    await commons.waitUntil(this.genreTab_lbl, 10);
    let assignGenreName = genreName;

    if (assignGenreName === 'Crime' && this.returnGeoLocation() === 'america') {
      // For roku US region genre name is True Crime instead of Crime
      assignGenreName = 'True Crime';
    }
    while (
      await commons.checkProperty(
        this.genreTab_lbl,
        PROP.TEXT_CONTENT,
        assignGenreName,
        COMP.NOT_EQUAL,
      )
    ) {
      const genre = await commons.fetchAttributeData(
        this.genreTab_lbl,
        PROP.TEXT_CONTENT,
      );

      if (genreList.includes(genre)) {
        throw new Error(`${genreName} is not present`);
      } else {
        genreList.push(genre);
      }
      await commons.userAction(VRC.RIGHT, 1, 2);
    }
    await commons.assertExists(this.hero_btn, 5);
  };

  moveToNextRail = async (direction = VRC.DOWN) => {
    do {
      await commons.userAction(direction, 1, 1);
    } while (await commons.doesNotExist(this.focusedRail));
  };

  moveToFirstRail = async () => {
    await this.moveToNextRail();
    const episodeRail = await commons.checkProperty(
      this.focusedRail,
      PROP.TEXT_CONTENT,
      'Episodes',
      COMP.EQUAL,
    );

    const networkRail = await commons.checkProperty(
      this.focusedRail,
      PROP.TEXT_CONTENT,
      '',
      COMP.EQUAL,
    );

    if (episodeRail || networkRail) {
      await commons.userAction(VRC.DOWN);
    }
  };

  scrollToRail = async (railName, railPresent = true) => {
    let flag = false;
    const railList = [];

    while (flag !== true) {
      await this.moveToNextRail();
      const focusedRailName = String(
        await commons.fetchAttributeData(this.focusedRail, PROP.TEXT_CONTENT),
      ).trim();

      if (railList.includes(focusedRailName)) {
        if (!railList.includes(railName)) {
          break;
        }
      }
      railList.push(focusedRailName);
      numberOfRails++;
      if (focusedRailName === railName) {
        flag = true;
      }
    }

    if (flag === false && railPresent === true) {
      throw new Error(`RailName: ${railName} does not present`);
    } else if (flag === true && railPresent === false) {
      throw new Error(`RailName: ${railName} present in the page`);
    }
  };

  verifyRailPresent = async (railName, railPresent = true) => {
    if (
      await commons.checkProperty(
        this.focusedRail,
        PROP.TEXT_CONTENT,
        railName,
        COMP.EQUAL,
      )
    ) {
      ok(railPresent === true);
    } else {
      while (await commons.elementExists(this.focusedRail)) {
        await commons.userAction(VRC.BACK);
      }

      await this.scrollToRail(railName, railPresent);
      await commons.userAction(VRC.UP, numberOfRails + 2, 1);
    }
  };

  selectShow = async () => {
    await commons.userAction(VRC.SELECT, 1, 5);
    await commons.assertExists(this.focusedShowDetailPage, 10);
  };

  selectAndPlayVideo = async () => {
    await commons.assertExists(this.showPageFirstCta_lbl);
    await commons.userAction(VRC.SELECT);
  };

  verifyVideoPlayed = async () => {
    await this.selectShow();
    await this.selectAndPlayVideo();
    await commons.assertVideoIsPlaying();
  };

  saveShowToMyList = async () => {
    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.focusedShowDetailPage);
    const showName = await commons.fetchAttributeData(
      this.showPageShowTitle_img,
      PROP.IMAGE,
    );

    myListShowsOrder.push(showName);
    await commons.userAction(VRC.BACK);
  };

  addFirstShowToMyList = async (showName) => {
    await searchPage.searchAndAddToMyList(showName);
    await this.saveShowToMyList();
    await menuPage.navigateToPage('Home');
    await this.scrollToRail('My List', true);
    await commons.assertExists(this.focusedRailMarkup, 5);
  };

  addShowToMyList = async (count) => {
    for (let i = 0; i < count; i++) {
      await searchPage.searchAndAddToMyList(this.showsList[i]);
      await this.saveShowToMyList();
    }
    await menuPage.navigateToPage('Home');
  };

  verifyMyListRailMetadata = async (showCount) => {
    await this.scrollToRail('My List', true);
    await commons.assertProperty(
      this.focusedRailMarkup,
      PROP.CHILDREN,
      Number(showCount),
      COMP.EQUAL_GREATER,
    );
    for (let i = 0; i < showCount; i++) {
      await commons.assertExists(this.focusedThumbnail);
      await commons.assertExists(this.heroShowTitle);
      await commons.userAction(VRC.RIGHT);
    }
    await commons.userAction(VRC.LEFT, Number(showCount));
    if (await commons.elementExists(menuPage.focusedMenuBar)) {
      await commons.userAction(VRC.RIGHT);
      await commons.assertExists(this.focusedThumbnail);
    }
  };

  verifyMyListRailShowOrder = async () => {
    const reverseMyListShowsOrder = myListShowsOrder.reverse();

    for (let i = 0; i < reverseMyListShowsOrder.length; i++) {
      await commons.userAction(VRC.SELECT);
      await commons.waitUntil(this.focusedShowDetailPage, 10);
      await commons.assertProperty(
        this.showPageShowTitle_img,
        PROP.IMAGE,
        reverseMyListShowsOrder[i],
        COMP.EQUAL,
      );
      await commons.userAction(VRC.BACK);
      await commons.waitUntil(this.focusedHomePage, 10);
      await commons.userAction(VRC.RIGHT);
    }
  };

  removeFromMyList = async (showName) => {
    await menuPage.navigateToPage('Search');
    await searchPage.clearSearchTextBox();
    await commons.sendText(
      `${testdataHelper.getContent(`searchPage.${showName}`)}`,
    );
    await commons.tryUntil(this.firstThumbnailOnSearch, VRC.RIGHT, 8, 1);
    await commons.userAction(VRC.SETTINGS);
    await commons.assertExists(this.removedFromMyList_lbl);
  };

  verifyJIPContent = () => {
    if (process.env.GEO.toLowerCase() === 'us') {
      /* To Do Implementation  */
      // Not applicable for UK - applicable only for US region
    }
  };

  verifyNetworkRailNotPresentForKids = async () => {
    await commons.userAction(VRC.DOWN, 3, 1);
    await commons.doesNotExist(this.networkLogo_img);
  };

  verifyKidsContentPopulated = async () => {
    await commons.assertExists(this.ratingLabel_txt, 10);
    await this.verifyNetworkRailNotPresentForKids();
    await commons.tryUntil(this.forYou_lbl, VRC.UP, 3, 1);
  };

  verifySportsRail = async (sportsRailType) => {
    await menuPage.assertPage('Home');
    switch (sportsRailType) {
      case 'primary':
        await this.scrollToRail('Link testing - poster primary', true);
        break;
      case 'enlarged':
        await this.scrollToRail('Link testing - Poster-Enlarged', true);
        break;
      case 'standard primary':
        await this.scrollToRail('link testing standard primary', true);
        break;
      default:
        break;
    }
  };

  assertPrimaryandStandardPosterMetadata = async () => {
    await commons.assertExists(this.focusedThumbnail);
    await commons.assertExists(this.focusedHeroTitle_txt);
    await commons.assertExists(this.focusedHeroPoster_img);
    await commons.assertDoesNotExist(this.focusedChannelLogo_img);
  };

  assertEnlargedPosterMetadata = async () => {
    await commons.assertExists(this.enlargedFocusedShowPoster_img);
    await commons.assertExists(this.enlargedFocusedTitle_txt);
    await commons.assertDoesNotExist(this.enlargedFocusedNetworkLogo_img);
  };

  verifySportsCardMetadata = async (sportsRailType) => {
    await commons.tryUntil(this.myListToolTipInvisible_lbl, VRC.RIGHT, 20, 1);
    await commons.assertExists(this.myListToolTipInvisible_lbl);
    switch (sportsRailType) {
      case 'primary':
        await this.assertPrimaryandStandardPosterMetadata();
        break;
      case 'enlarged':
        await this.assertEnlargedPosterMetadata();
        break;
      case 'standard primary':
        while (await commons.elementExists(this.sports_lbl)) {
          await commons.userAction(VRC.RIGHT);
        }
        await this.assertPrimaryandStandardPosterMetadata();
        break;
      default:
        break;
    }
  };

  /**
   * The below function will add shows from home hero using Mylist Button
   */
  addShowToMylistFromHomeHero = async () => {
    await commons.waitUntil(this.focusedHomePage, 10);
    await commons.waitUntil(this.heroShowTitle, 10);
    await commons.assertExists(this.focusedHeroShowName_img, 10);
    await commons.userAction(VRC.DOWN, 1, 1);
    await commons.userAction(VRC.RIGHT, 1, 1);
    let currentMyListIcon = await commons.fetchAttributeData(
      this.heroMyListIcon,
      PROP.IMAGE,
    );

    if (currentMyListIcon.includes('added') === true) {
      await commons.userAction(VRC.OK, 1, 2);
      currentMyListIcon = await commons.fetchAttributeData(
        this.heroMyListIcon,
        PROP.IMAGE,
      );
    }
    await commons.userAction(VRC.OK, 1, 2);
    await commons.assertProperty(
      this.heroMyListIcon,
      PROP.IMAGE,
      currentMyListIcon,
      COMP.NOT_EQUAL,
    );
  };

  selectSportsCard = async () => {
    await commons.assertExists(this.focusedThumbnail);
    await commons.userAction(VRC.SELECT, 1, 5);
  };

  moveFocusAwayFromSearchKeyboard = async () => {
    while (await commons.elementExists(this.focusedKeyboard, 3)) {
      await commons.userAction(VRC.RIGHT);
    }
  };

  validateCTAonShowPage = async () => {
    await commons.assertExists(this.showPageFirstCta_lbl, 10);
    await commons.userAction(VRC.RIGHT);
    await commons.assertExists(this.myListCta_lbl);
    await commons.userAction(VRC.LEFT);
    await commons.userAction(VRC.SELECT);
  };

  validateCTAonPages = async (userType, pageName) => {
    const page = pageName.raw();

    for (let i = 0; i < page.length; i++) {
      let pageToBe = page[i].toString();

      if (this.returnGeoLocation() === 'america' && pageToBe === 'Sports') {
        return;
      }
      if (this.returnGeoLocation() === 'emea' && pageToBe === 'Browse') {
        pageToBe = 'Shows';
      }

      await menuPage.navigateToPage(pageToBe);

      if (pageToBe === 'Browse') {
        pageToBe = 'Shows';
      }

      if (pageToBe === 'Home') {
        await this.moveToFirstRail();
      } else if (pageToBe === 'Shows') {
        do {
          await commons.userAction(VRC.DOWN);
        } while (await commons.doesNotExist(this.showPageFocusedThumbnail));
      } else if (pageToBe === 'Search') {
        await this.moveFocusAwayFromSearchKeyboard();
        while (await commons.doesNotExist(this.firstStandardThumbnail)) {
          await commons.userAction(VRC.DOWN);
        }
      } else if (pageToBe === 'Sports') {
        await this.moveToFirstRail();
      }
      switch (userType) {
        case 'anonymous':
          await commons.userAction(VRC.SELECT);
          if (pageToBe === 'Sports') {
            await commons.assertExists(this.eventDetailPage);
            await commons.assertExists(this.signIn_btn);
          } else {
            await commons.assertExists(this.focusedShowDetailPage);
            await commons.assertExists(this.signUpCta_lbl);
          }
          break;
        case 'fully-entitled':
          if (pageToBe === 'Sports') {
            await this.scrollToRail('Sports Documentaries', true);
          }
          await commons.userAction(VRC.SELECT);
          await this.validateCTAonShowPage();
          await commons.assertVideoIsPlaying();
          break;
        case 'non-entitled':
          if (pageToBe === 'Sports') {
            await this.scrollToRail('Sports Documentaries', true);
          }
          await commons.userAction(VRC.SELECT);
          await this.validateCTAonShowPage();
          await commons.assertExists(this.upgradeTitle_lbl, 10);
          await commons.assertExists(this.viewPasses_btn);
          break;
        default:
          break;
      }
    }
  };

  scrollToNetworkRail = async () => {
    await commons.assertExists(this.forYou_lbl, 2);
    await this.scrollToRail('', true);
  };

  validateNetworkRail = async () => {
    await commons.assertProperty(
      this.focusedRail,
      PROP.VISIBILITY,
      'invisible',
      COMP.EQUAL,
    );
  };

  verifyContinueWatchingMetadata = async () => {
    const currentEpisodeTitle = (
      await commons.fetchAttributeData(
        this.focusedHeroTitle_txt,
        PROP.TEXT_CONTENT,
      )
    ).replace(/ /g, '');

    const heroTitle = (
      await commons.fetchAttributeData(this.heroShowTitle, PROP.IMAGE)
    )
      .replace(/ /g, '')
      .split('?')[0];

    const showPageDetail = await this.getShowPageDetail();

    ok(
      showPageDetail.get('episodeName') === currentEpisodeTitle,
      `Values are not matching: '${showPageDetail.get(
        'episodeName',
      )}' & '${currentEpisodeTitle}'`,
    );

    ok(
      showPageDetail.get('showName') === heroTitle,
      `Values are not matching: '${showPageDetail.get(
        'showName',
      )}' & '${heroTitle}'`,
    );
  };

  resumeAndPlayVideo = async () => {
    await commons.userAction(VRC.SELECT);
    await commons.waitTillVideoIsPlaying();
  };

  verifyShowsInMyListRail = async () => {
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.forYou_lbl);
    await this.verifyRailPresent('My List', true);
    await this.verifyMyListRailMetadata(1);
  };

  verifyMyListShowAvailability = async () => {
    await profilePage.selectProfile('Default');
    await menuPage.navigateToPage('My List');
    const standardProfileShow = await commons.fetchAttributeData(
      this.firstSavedShowTile,
      PROP.IMAGE,
    );

    await profilePage.selectProfile('Kids');
    await menuPage.navigateToPage('My List');
    const kidsProfileShow = await commons.fetchAttributeData(
      this.firstSavedShowTile,
      PROP.IMAGE,
    );

    ok(standardProfileShow !== kidsProfileShow, `same show on both profiles`);
  };

  /**
   * The below function will verify Mylist rail present on Home Page
   *
   * @param {string} railName - rail name
   * @param {boolean} railStatus - rail status true or false
   */
  verifyMyListRailOnHomePage = async (railName, railStatus) => {
    await menuPage.navigateToPage('Home');
    await this.verifyRailPresent(railName, railStatus);
  };

  navigateToSportsInLineHero = async () => {
    await commons.tryUntil(this.focusedInLineHero_btn, VRC.DOWN, 30, 1);
  };

  verifySportsInLineHeroMetadata = async () => {
    await commons.assertExists(this.focusedHeroTitle_txt, 2);
    await commons.assertExists(this.focusedHeroDesc_txt, 2);
    await commons.assertExists(this.focusedInLineHero_btn, 2);
    await commons.assertDoesNotExist(this.focusedChannelLogo_img);
  };

  selectInlineHeroCTA = async () => {
    await commons.assertExists(this.focusedInLineHero_btn);
    await commons.userAction(VRC.ENTER, 1, 5);
  };

  verifyJipContentPlayback = async (pageName) => {
    if (pageName === 'Home Page') {
      await commons.assertExists(this.forYou_lbl, 2);
      await this.scrollToRail('discovery+ Channels', true);
      await commons.userAction(VRC.ENTER);
      await videoPlayerPage.isVideoPlaying();
    } else if (pageName === 'Channel Page') {
      await menuPage.navigateToPage('Channels');
      await commons.userAction(VRC.ENTER);
      await videoPlayerPage.isVideoPlaying();
    } else if (pageName === 'Show Details Page') {
      await menuPage.navigateToPage('Search');
      await this.clearSearchTextBox();
      await commons.sendText('Ghost Adventures');
      await commons.tryUntil(this.firstThumbnailOnSearch, VRC.RIGHT, 8, 1);
      await commons.userAction(VRC.SELECT);
      await commons.userAction(VRC.DOWN, 3, 1);
      await commons.userAction(VRC.SELECT);
      await videoPlayerPage.isVideoPlaying();
    }
  };

  verifyAgeRatingAndContentDescriptors = async (screensType) => {
    const ratings = testdataHelper.getContent('ratingList');
    const currentRating = await commons.fetchAttributeData(
      this.ratingLabel_txt,
      'text',
    );
    const results = ratings.includes(currentRating.trim());

    switch (screensType) {
      case 'Main Hero':
        await commons.assertExists(this.forYou_lbl, 10);
        await commons.userAction(VRC.DOWN, 1, 10);
        await commons.assertExists(this.focusedHomePage, 5);
        await commons.assertExists(this.ratingLabel_txt, 5);
        await commons.checkProperty(
          this.contentDescriptors_txt,
          PROP.TEXT_CONTENT,
          '',
          COMP.NOT_EQUAL,
        );
        assert(results === true, 'Rating is not as per rating standards');
        break;
      case 'Show Details Page':
        await commons.userAction(VRC.ENTER, 1, 10);
        await commons.assertExists(this.focusedShowDetailPage, 5);
        await commons.checkProperty(
          this.ratingShowDetailsPage_txt,
          PROP.TEXT_CONTENT,
          '',
          COMP.NOT_EQUAL,
        );
        break;
      case 'Currently Playing Episode':
        await commons.userAction(VRC.ENTER, 1, 5);
        await videoPlayerPage.isVideoPlaying();
        await commons.assertExists(this.videoPlayerSceneRating_txt, 10);
        break;
      case 'Next Episodes listed on Episode Landing Page':
        await commons.userAction(VRC.BACK, 1, 5);
        await commons.userAction(VRC.DOWN, 1, 5);
        await commons.assertExists(this.episode_lbl, 10);
        await commons.assertExists(this.episodeRating_txt, 10);
        break;
      case 'Episode Info Panel ':
        await commons.assertExists(this.episodeRating_txt, 10);
        break;
      default:
        break;
    }
  };

  signOut = async () => {
    await menuPage.navigateToPage('Account');
    await commons.assertExists(this.signOut_lbl, 10);
    await commons.userAction(VRC.RIGHT, 3, 2);
    await commons.assertExists(this.logIn_lbl, 10);
    await commons.userAction(VRC.DOWN);
    await commons.userAction(VRC.OK);
    await commons.assertExists(this.cancelBtn_lbl, 10);
    await commons.assertExists(this.confirmBtn_lbl, 10);
    await commons.userAction(VRC.UP);
    await commons.userAction(VRC.OK);
  };

  removedShowFromMylistFromHomeHero = async () => {
    await menuPage.openMenu();
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.focusedHomePage, 10);
    await commons.waitUntil(this.heroShowTitle, 10);
    await commons.assertExists(this.focusedHeroShowName_img, 10);
    await commons.userAction(VRC.DOWN, 1, 1);
    await commons.userAction(VRC.RIGHT, 1, 1);
    let currentMyListIcon = await commons.fetchAttributeData(
      this.heroMyListIcon,
      PROP.IMAGE,
    );

    if (currentMyListIcon.includes('added') === true) {
      await commons.userAction(VRC.OK, 1, 2);
      currentMyListIcon = await commons.fetchAttributeData(
        this.heroMyListIcon,
        PROP.IMAGE,
      );
    }

    await commons.assertProperty(
      this.heroMyListIcon,
      PROP.IMAGE,
      currentMyListIcon,
      COMP.EQUAL,
    );
  };

  verifyHomepage = async () => {
    await commons.waitUntil(this.focusedHomePage, 10);
    await commons.waitUntil(this.heroShowTitle, 10);
    await commons.assertExists(this.focusedHeroShowName_img, 10);
    await commons.assertExists(this.focusedHeroPoster_img, 10);
  };

  verifyContinueWatchingNotVisible = async () => {
    await commons.assertDoesNotExist(this.continueWatching_lbl);
  };
}

module.exports = HomePage;
