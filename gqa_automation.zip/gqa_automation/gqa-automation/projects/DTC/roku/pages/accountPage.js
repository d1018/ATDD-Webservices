const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');

const { VRC } = commons;

class AccountPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('accountPage', locator);
  }

  accountTitle_lbl = this.#getSelectorData('accountTitle_lbl');

  accountTab_lbl = this.#getSelectorData('accountTab_lbl');

  signIn_btn = this.#getSelectorData('signIn_btn');

  signUp_btn = this.#getSelectorData('signUp_btn');

  account_lbl = this.#getSelectorData('account_lbl');

  helpCentre_lbl = this.#getSelectorData('helpCentre_lbl');

  help_lbl = this.#getSelectorData('help_lbl');

  about_lbl = this.#getSelectorData('about_lbl');

  signOut_lbl = this.#getSelectorData('signOut_lbl');

  signOutBtn_lbl = this.#getSelectorData('signOutBtn_lbl');

  signOutFocused_btn = this.#getSelectorData('signOutFocused_btn');

  cancelBtn_lbl = this.#getSelectorData('cancelBtn_lbl');

  helpTabNonScrollingText_lbl = this.#getSelectorData(
    'helpTabNonScrollingText_lbl',
  );

  aboutTabScrollableText_lbl = this.#getSelectorData(
    'aboutTabScrollableText_lbl',
  );

  anonymousUserTitle_lbl = this.#getSelectorData('anonymousUserTitle_lbl');

  accountTabTitleDesc_lbl = this.#getSelectorData('accountTabTitleDesc_lbl');

  focusedInactivePage = this.getElementByPage(
    'inactivePage',
    'focusedInactivePage',
  );

  inactiveSubscription_txt = this.getElementByPage(
    'inactivePage',
    'inactiveSubscription_txt',
  );

  focusedProductPickerPage = this.getElementByPage(
    'productPickerScene',
    'focusedProductPickerPage',
  );

  planPickerTitle_lbl = this.getElementByPage(
    'productPickerScene',
    'planPickerTitle_lbl',
  );

  focusedChooseYourPlan_btn = this.getElementByPage(
    'inactivePage',
    'focusedChooseYourPlan_btn',
  );

  accountPageSubMenu = {
    Account: this.account_lbl,
    'Help Centre': this.helpCentre_lbl,
    Help: this.help_lbl,
    About: this.about_lbl,
    'Sign Out': this.signOut_lbl,
  };

  verifyAccountPage = async (profileName) => {
    if (profileName === 'Kids') {
      await profilePage.selectProfile(profileName);
    }

    await menuPage.navigateToPage('Account');
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      await commons.assertExists(this.accountPageSubMenu[accountMenuList[i]]);
    }
  };

  getUserAccountMenuItems = (profileName) => {
    const accountType = {
      Anonymous: 'anonymousUserAccountItemListRoku',
      Default: 'defaultUserAccountItemListRoku',
      Kids: 'kidsUserAccountItemListRoku',
    };

    return testdataHelper.getContent(`accountPage.${accountType[profileName]}`);
  };

  verifyAccountSubNavigationPage = async (profileName) => {
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      await commons.waitUntil(this.accountPageSubMenu[accountMenuList[i]]);
      await this.accountSubNavigationPage(accountMenuList[i]);
      await commons.userAction(VRC.RIGHT, 1, 2);
    }
  };

  accountSubNavigationPage = async (tabName) => {
    switch (tabName) {
      case 'Account':
        if (this.getAnonymousUserValue()) {
          await commons.assertExists(this.anonymousUserTitle_lbl);
          await commons.assertExists(this.signIn_btn);
        } else await commons.assertExists(this.accountTabTitleDesc_lbl);
        break;
      case 'Help Centre':
        await commons.assertExists(this.helpTabNonScrollingText_lbl);
        break;
      case 'About':
        await commons.assertExists(this.aboutTabScrollableText_lbl);
        break;
      case 'Sign Out':
        await commons.assertExists(this.signOutBtn_lbl);
        break;
      default:
        break;
    }
  };

  validateCtaAccountPage = async () => {
    await menuPage.navigateToPage('Account');
    await commons.assertExists(this.signIn_btn);
    await commons.assertExists(this.signUp_btn);
  };

  /*
   * To validate Inactive Subscription Page
   */
  validateInactiveSubscriptionPage = async () => {
    await commons.assertExists(this.focusedInactivePage, 10);
    await commons.assertExists(this.inactiveSubscription_txt, 10);
  };

  /*
   * To select Choose Your Plan button from Inactive Subscription Page
   */
  selectSubscribe = async () => {
    await commons.tryUntil(this.focusedChooseYourPlan_btn, VRC.DOWN, 1);
    await commons.userAction(VRC.ENTER, 1);
  };

  /*
   * To validate Product Picker Page
   */
  validateProductPickerPage = async () => {
    await commons.assertExists(this.focusedProductPickerPage, 10);
    await commons.assertExists(this.planPickerTitle_lbl, 10);
  };

  selectAdultProfile = async () => {};

  selectFooter = async (tabName) => {
    if (tabName === 'Help') {
      await commons.assertExists(this.account_lbl, 5);
      await commons.assertExists(this.accountTabTitleDesc_lbl);
      await commons.userAction(VRC.RIGHT);
      await commons.assertExists(this.help_lbl, 5);
      await commons.userAction(VRC.SELECT);
    } else if (tabName === 'Sign Out') {
      await commons.assertExists(this.account_lbl, 5);
      await commons.userAction(VRC.RIGHT, 3, 2);
      await commons.assertExists(this.signOut_lbl);
      await commons.userAction(VRC.SELECT);
    }
  };

  verifyHelpPage = async () => {
    await commons.assertExists(this.help_lbl, 5);
    await commons.assertExists(this.helpTabNonScrollingText_lbl, 5);
  };

  selectCancelCTA = async () => {
    await commons.tryUntil(this.signOutFocused_btn, VRC.DOWN);
    await commons.assertExists(this.signOutBtn_lbl, 5);
    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.cancelBtn_lbl, 5);
    await commons.userAction(VRC.SELECT);
  };

  verifySignOutPage = async () => {
    await commons.assertExists(this.signOutFocused_btn, 5);
    await commons.assertExists(this.signOutBtn_lbl, 5);
  };
}

module.exports = new AccountPage();
