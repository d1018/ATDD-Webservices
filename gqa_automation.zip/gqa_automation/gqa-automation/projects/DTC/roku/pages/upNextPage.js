const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const { PROP, COMP, VRC } = commons;

class UpNextPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('upNext', locator);
  }

  upNext_banner = this.#getSelectorData('upNext_banner');

  upNext_lbl = this.#getSelectorData('upNext_lbl');

  upNextTitle_lbl = this.#getSelectorData('upNextTitle_lbl');

  upNextEpisode_lbl = this.#getSelectorData('upNextEpisode_lbl');

  upNextRating_lbl = this.#getSelectorData('upNextRating_lbl');

  episodeTwo_lbl = this.#getSelectorData('episodeTwo_lbl');

  showTitle_lbl = this.#getSelectorData('showTitle_lbl');

  episodeTitle_lbl = this.#getSelectorData('episodeTitle_lbl');

  upNextCancel_lbl = this.#getSelectorData('upNextCancel_lbl');

  upNextPlayer_video = this.#getSelectorData('upNextPlayer_video');

  firstThumbnailOnSearch = this.getElementByPage(
    'searchPage',
    'firstThumbnailOnSearch',
  );

  multiEpisodeShow = testdataHelper.getContent('searchPage.multiEpisodeShow');

  videoPlayerScene = this.getElementByPage(
    'videoPlayerPage',
    'videoPlayerScene',
  );

  verifyUpNextBanner = async () => {
    await commons.assertExists(this.upNext_banner);
    await commons.assertExists(this.upNextTitle_lbl);
    await commons.assertExists(this.upNextEpisode_lbl);
    await commons.assertExists(this.upNextRating_lbl);
    await commons.assertExists(this.upNextCancel_lbl);
    await commons.assertExists(this.upNextPlayer_video);
  };

  verifyMetaDataForUpNext = async () => {
    await commons.checkProperty(
      this.upNextTitle_lbl,
      PROP.TEXT_CONTENT,
      this.multiEpisodeShow,
      COMP.EQUAL,
    );
    await commons.checkProperty(
      this.upNextRating_lbl,
      PROP.TEXT_CONTENT,
      'TV-G',
      COMP.EQUAL,
    );
    await commons.checkProperty(
      this.upNextRating_lbl,
      PROP.TEXT_CONTENT,
      'S1 E2',
      COMP.CONTAIN,
    );
  };

  clickOnUpNextCTA = async (CTAType) => {
    if (CTAType === 'Play') {
      await commons.assertExists(this.upNextPlayer_video);
      await commons.userAction(VRC.OK);
    } else if (CTAType === 'cancel') {
      await commons.assertExists(this.upNextCancel_lbl);
      await commons.userAction(VRC.RIGHT);
      await commons.userAction(VRC.OK);
    }
  };

  verifyNextEpisode = async () => {
    await commons.waitTillVideoIsPlaying();
    await commons.waitUntil(this.episodeTwo_lbl);
    await commons.checkProperty(
      this.episodeTitle_lbl,
      PROP.TEXT_CONTENT,
      'S1 E2',
      COMP.CONTAIN,
    );
    await commons.checkProperty(
      this.showTitle_lbl,
      PROP.TEXT_CONTENT,
      this.multiEpisodeShow,
      COMP.EQUAL,
    );
    await commons.assertExists(this.videoPlayerScene);
  };

  verifyScreenOnUpNextCancel = async () => {
    await commons.assertExists(this.videoPlayerScene);
  };
}

module.exports = new UpNextPage();
