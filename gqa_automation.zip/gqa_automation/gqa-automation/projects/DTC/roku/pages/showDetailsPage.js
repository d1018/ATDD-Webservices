const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const homePage = require('./homePage');
const menuPage = require('./menuPage');

const { PROP, VRC, COMP } = commons;

class ShowDetailsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('showDetailPage', locator);
  }

  focusedShowDetailPage = this.#getSelectorData('focusedShowDetailPage');

  showTitle_img = this.#getSelectorData('showTitle_img');

  showMyListIcon = this.#getSelectorData('showMyListIcon');

  heroEpisodeName_lbl = this.#getSelectorData('heroEpisodeName_lbl');

  heroEpisodeDesc_lbl = this.#getSelectorData('heroEpisodeDesc_lbl');

  heroEpisodeRating_lbl = this.#getSelectorData('heroEpisodeRating_lbl');

  heroBackground_img = this.#getSelectorData('heroBackground_img');

  heroMyListIconAdded_img = this.#getSelectorData('heroMyListIconAdded_img');

  heroMyListIconRemoved_img = this.#getSelectorData(
    'heroMyListIconRemoved_img',
  );

  hero_btn = this.getElementByPage('homePage', 'hero_btn');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  heroShowTitle = this.getElementByPage('homePage', 'heroShowTitle');

  focusedCta = this.getElementByPage('homePage', 'focusedCta');

  heroMyListIcon = this.getElementByPage('homePage', 'heroMyListIcon');

  signUpCta_lbl = this.#getSelectorData('signUpCta_lbl');

  showPageFirstCta_lbl = this.#getSelectorData('showPageFirstCta_lbl');

  genreTab_lbl = this.getElementByPage('homePage', 'genreTab_lbl');

  firstThumbnailOnSearch = this.getElementByPage(
    'searchPage',
    'firstThumbnailOnSearch',
  );

  upgradeTitle_lbl = this.getElementByPage(
    'upgradeToWatchPage',
    'upgradeTitle_lbl',
  );

  viewPasses_btn = this.getElementByPage(
    'upgradeToWatchPage',
    'viewPasses_btn',
  );

  videoEpisodeTitle = this.getElementByPage(
    'videoPlayerPage',
    'episodeTitle_lbl',
  );

  verifyShowLandingAnchorDetails = async () => {
    await commons.assertExists(this.focusedShowDetailPage);
  };

  validateCTAonGenres = async (userType, genreNames) => {
    await commons.assertExists(this.focusedHomePage);
    const genreNameList = genreNames.raw();

    for (let i = 0; i < genreNameList.length; i++) {
      while (await commons.doesNotExist(this.genreTab_lbl)) {
        await commons.userAction(VRC.BACK);
      }

      while (
        await commons.checkProperty(
          this.genreTab_lbl,
          PROP.TEXT_CONTENT,
          'For You',
          COMP.NOT_EQUAL,
        )
      ) {
        await commons.userAction(VRC.LEFT, 1, 2);
      }
      const genreName = genreNameList[i].toString();

      await homePage.selectGenreTab(genreName);
      while (await commons.doesNotExist(this.focusedCta)) {
        await commons.userAction(VRC.DOWN);
      }
      await commons.userAction(VRC.SELECT);
      switch (userType) {
        case 'anonymous':
          await commons.assertExists(this.focusedShowDetailPage);
          await commons.assertExists(this.signUpCta_lbl);
          break;
        case 'fully-entitled':
          await homePage.validateCTAonShowPage();
          await commons.assertVideoIsPlaying();
          break;
        case 'non-entitled':
          await homePage.validateCTAonShowPage();
          await commons.assertExists(this.upgradeTitle_lbl, 10);
          await commons.assertExists(this.viewPasses_btn);
          break;
        default:
          break;
      }
      await menuPage.openMenu();
      await menuPage.closeMenu();
    }
  };

  saveDetailForContinueWatching = async () => {
    const showName = (
      await commons.fetchAttributeData(this.showTitle_img, PROP.IMAGE)
    )
      .replace(/ /g, '')
      .split('?')[0];

    const episodeName = (
      await commons.fetchAttributeData(
        this.heroEpisodeName_lbl,
        PROP.TEXT_CONTENT,
      )
    ).replace(/ /g, '');

    const heroImage = (
      await commons.fetchAttributeData(this.heroBackground_img, PROP.IMAGE)
    )
      .replace(/ /g, '')
      .split('?')[0];

    await this.setShowPageDetail(showName, episodeName, heroImage);
  };

  selectAndPlayVideo = async () => {
    while (await commons.doesNotExist(this.firstThumbnailOnSearch, 5)) {
      await commons.userAction(VRC.RIGHT);
    }
    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.focusedShowDetailPage);
    await commons.assertExists(this.showPageFirstCta_lbl, 10);

    const ctaName = await commons.fetchAttributeData(
      this.showPageFirstCta_lbl,
      PROP.TEXT_CONTENT,
    );

    if (ctaName !== 'Resume') {
      await commons.userAction(VRC.SELECT);
      await commons.assertVideoIsPlaying();
      await commons.userAction(VRC.BACK);
      await commons.assertExists(this.focusedShowDetailPage);
      await commons.assertExists(this.showPageFirstCta_lbl, 10);
    }

    await this.saveDetailForContinueWatching();
    await commons.userAction(VRC.SELECT);
    await commons.assertVideoIsPlaying();
  };

  /**
   * The below function will select the hero item from Home to open Content Detail page
   */
  selectHeroItemFromHome = async () => {
    await commons.waitUntil(this.focusedHomePage, 10);
    await commons.waitUntil(this.heroShowTitle, 10);
    await commons.userAction(VRC.DOWN, 1, 1);
    await commons.userAction(VRC.OK, 1, 2);
    await commons.waitUntil(this.focusedShowDetailPage, 10);
    await commons.waitUntil(this.showPageFirstCta_lbl, 10);
  };

  /**
   * The below function will add a show using Mylist Button
   */
  addShowToMylistFromContentDetailPage = async () => {
    await commons.assertExists(this.focusedShowDetailPage);
    await commons.userAction(VRC.RIGHT, 1, 1);
    let currentMyListIcon = await commons.fetchAttributeData(
      this.heroMyListIcon,
      PROP.IMAGE,
    );

    if (currentMyListIcon.includes('added') === true) {
      await commons.userAction(VRC.OK, 1, 2);
      currentMyListIcon = await commons.fetchAttributeData(
        this.heroMyListIcon,
        PROP.IMAGE,
      );
    }

    await commons.userAction(VRC.OK, 1, 2);
    await commons.assertProperty(
      this.heroMyListIcon,
      PROP.IMAGE,
      currentMyListIcon,
      COMP.NOT_EQUAL,
    );
  };

  /**
   * The below function will remove show using Mylist Button
   */
  removeShowFromMyList = async () => {
    const currentMyListIcon = await commons.fetchAttributeData(
      this.heroMyListIcon,
      PROP.IMAGE,
    );

    if (currentMyListIcon.includes('added') === true) {
      await commons.userAction(VRC.OK, 1, 2);
      await commons.assertProperty(
        this.heroMyListIcon,
        PROP.IMAGE,
        currentMyListIcon,
        COMP.NOT_EQUAL,
      );
    }
  };

  /**
   * The below function will check the hero CTA is a Checkmark icon
   */
  verifyHeroMyListCtaIsCheckmarkIcon = async () => {
    await commons.assertExists(this.heroMyListIconAdded_img);
  };

  /**
   * The below function will check the hero CTA is a Plus icon
   */
  verifyHeroMyListCtaIsPlusIcon = async () => {
    await commons.assertExists(this.heroMyListIconRemoved_img);
  };

  /**
   * Validate show detail Page
   */
  validateShowDetailPage = async () => {
    await commons.waitUntil(this.focusedShowDetailPage, 10);
    await commons.waitUntil(this.showPageFirstCta_lbl, 10);
    await commons.assertExists(this.showPageFirstCta_lbl);
    await commons.assertExists(this.focusedShowDetailPage);
  };

  verifyShowLandingPage = async (ctaType) => {
    if (ctaType === 'Watch NowCTA ') {
      await commons.assertExists(this.focusedShowDetailPage, 10);
      await commons.userAction(VRC.LEFT);
      await commons.userAction(VRC.SELECT);
      await commons.assertVideoIsPlaying();
      await commons.userAction(VRC.BACK, 1, 3);
    } else if (ctaType === 'My List CTA') {
      await commons.waitUntil(this.focusedShowDetailPage, 10);
      await commons.waitUntil(this.showTitle_img, 10);
      await commons.userAction(VRC.RIGHT, 1, 1);
      const currentMyListIcon = await commons.fetchAttributeData(
        this.showMyListIcon,
        PROP.IMAGE,
      );

      await commons.userAction(VRC.OK, 1, 2);
      await commons.assertProperty(
        this.showMyListIcon,
        PROP.IMAGE,
        currentMyListIcon,
        COMP.NOT_EQUAL,
      );
    }
  };
}

module.exports = new ShowDetailsPage();
