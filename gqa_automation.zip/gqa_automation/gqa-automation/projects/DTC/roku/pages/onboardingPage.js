const assert = require('assert');

const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const menuPage = require('./menuPage');
const homePage = require('./homePage');
const networkLandingPage = require('./networkLandingPage');

const { VRC } = commons;

class OnboardingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('onboardingPage', locator);
  }

  focusedSignIn_btn = this.getElementByPage('accountPage', 'focusedSignIn_btn');

  focusedSignUp_btn = this.getElementByPage('accountPage', 'focusedSignUp_btn');

  needHelp_txt = this.getElementByPage('accountPage', 'needHelp_txt');

  goBack_btn = this.getElementByPage('accountPage', 'goBack_btn');

  focusedSignInPage = this.getElementByPage('signInPage', 'focusedSignInPage');

  continue_btn = this.getElementByPage('signInPage', 'continue_btn');

  signUp_btn = this.getElementByPage('subscribeToWatchPage', 'signUp_btn');

  focusedInactivePage = this.getElementByPage(
    'inactivePage',
    'focusedInactivePage',
  );

  inactiveSubscription_txt = this.getElementByPage(
    'inactivePage',
    'inactiveSubscription_txt',
  );

  signOut_btn = this.getElementByPage('inactivePage', 'signOut_btn');

  signInDifferent_btn = this.getElementByPage(
    'signInPage',
    'signInDifferent_btn',
  );

  userName_txtBx = this.getElementByPage('signInPage', 'userName_txtBx');

  subscribeToWatchList = [
    this.getElementByPage('subscribeToWatchPage', 'signUp_btn'),
    this.getElementByPage('subscribeToWatchPage', 'signIn_btn'),
    this.getElementByPage('subscribeToWatchPage', 'upgradeTitle_lbl'),
    this.getElementByPage('subscribeToWatchPage', 'upgradeDesc_lbl'),
  ];

  upgradeTitle_lbl = this.getElementByPage(
    'upgradeToWatchPage',
    'upgradeTitle_lbl',
  );

  viewPasses_btn = this.getElementByPage(
    'upgradeToWatchPage',
    'viewPasses_btn',
  );

  watchNow_cta = this.getElementByPage('networkLandingPage', 'watchNow_cta');

  focusedShowTitleSDS = this.getElementByPage(
    'showDetailPage',
    'focusedShowTitleSDS',
  );

  focusedShowDetailPage = this.getElementByPage(
    'showDetailPage',
    'focusedShowDetailPage',
  );

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  selectCTA = async (CTAType) => {
    if (CTAType === 'Sign In') {
      await commons.tryUntil(this.focusedSignIn_btn, VRC.DOWN, 2, 1);
      await commons.userAction(VRC.ENTER);
    } else if (CTAType === 'Sign Up') {
      await commons.tryUntil(this.focusedSignUp_btn, VRC.DOWN, 2, 1);
      await commons.userAction(VRC.ENTER);
    } else if (CTAType === 'Back') {
      await commons.userAction(VRC.BACK, 2, 2);
    }
  };

  verifyCTAScreen = async (CTAType) => {
    if (CTAType === 'Sign In') {
      await commons.waitUntil(this.continue_btn, 10);
      await commons.tryUntil(this.signInDifferent_btn, VRC.DOWN, 2, 1);
      await commons.userAction(VRC.ENTER, 1);
      await commons.waitUntil(this.userName_txtBx, 10);
      await commons.userAction(VRC.BACK, 1, 1);
      await commons.userAction(VRC.UP);
    } else if (CTAType === 'Sign Up') {
      await commons.assertExists(this.needHelp_txt, 10);
      await commons.assertExists(this.goBack_btn, 10);
    }
  };

  selectCTAAndVerify = async (CTA) => {
    await this.selectCTA(CTA);
    await this.verifyCTAScreen(CTA);
  };

  selectContentEntertainmentVOD = async () => {
    await homePage.scrollToRail('Featured');
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.focusedShowDetailPage, 10);
    await commons.tryUntil(this.focusedShowTitleSDS, VRC.DOWN, 4, 3);
    await commons.userAction(VRC.ENTER);
  };

  selectContentEntertainmentLinear = async () => {
    await homePage.scrollToRail('');
    await networkLandingPage.navigateToSelectNetwork('TLC');
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.signUp_btn, 10);
  };

  selectContentSportsVOD = async () => {
    await menuPage.navigateToPage('Sports');
    await homePage.scrollToRail('Sports Documentaries');
    await commons.userAction(VRC.ENTER);
    await homePage.scrollToRail('Episodes');
    await commons.userAction(VRC.ENTER);
  };

  /**
   *
   * @param {string} contentType - whether the content type if VOD/Linear/Live
   * @param {string} userType  - whether the user type is anonymous/lapsed
   * This function will navigate and select the shows/content based on the contentType & userType
   */

  navigateAndSelectContent = async (contentType, userType) => {
    await menuPage.navigateToPage('Home');
    if (
      contentType.includes('Entertainment VOD') &&
      (userType.includes('anonymous') || userType.includes('lapsed'))
    ) {
      await this.selectContentEntertainmentVOD();
    } else if (
      contentType.includes('Entertainment Linear') &&
      userType.includes('lapsed')
    ) {
      await this.selectContentEntertainmentLinear();
    } else if (
      contentType.includes('Sports VOD') &&
      userType.includes('anonymous')
    ) {
      await this.selectContentSportsVOD();
    }
  };

  /**
   * The below function will validate the subscribe to watch screen whether the required elements are displayed
   */

  verifySubscribeToWatchScreen = async () => {
    for (let i = 0; i < this.subscribeToWatchList.length; i++) {
      assert(
        await commons.elementExists(this.subscribeToWatchList[i]),
        `${this.subscribeToWatchList[i]} is not displayed on the page`,
      );
    }
  };

  validateUpgradeToWatchScreen = async () => {
    await menuPage.navigateToPage('Home');
    await homePage.scrollToRail('');
    await networkLandingPage.navigateToSelectNetwork('TLC');
    await commons.assertExists(this.watchNow_cta, 10);
    await homePage.scrollToRail('Recommended for You');
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.watchNow_cta, 10);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.upgradeTitle_lbl, 10);
    await commons.assertExists(this.viewPasses_btn, 10);
  };

  verifyInactiveSubscriptionScreen = async () => {
    await commons.assertExists(this.focusedInactivePage, 10);
    await commons.assertExists(this.inactiveSubscription_txt, 10);
    await commons.tryUntil(this.signUp_btn, VRC.DOWN, 1);
    await commons.userAction(VRC.SELECT);
  };

  verifySuccessfulLogin = async () => {
    await commons.assertExists(this.focusedHomePage, 10);
  };
}

module.exports = new OnboardingPage();
