const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;

const { PROP, VRC } = commons;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  menuListLoggedIn = testdataHelper.getContent('menuItem.loggedInMenu');

  menuListLoggedOut = testdataHelper.getContent('menuItem.loggedOutMenu');

  kidsMenuList = testdataHelper.getContent('menuItem.kidsMenu');

  tvGuideMenuListItem = this.#getSelectorData('tvGuideMenuListItem');

  focusedMenuBar = this.#getSelectorData('focusedMenuBar');

  unfocusedMenuBar = this.#getSelectorData('unfocusedMenuBar');

  focusedMenuItem = this.#getSelectorData('focusedMenuItem');

  homeMenu_lbl = this.#getSelectorData('homeMenu_lbl');

  sportsMenu_lbl = this.#getSelectorData('sportsMenu_lbl');

  showsMenu_lbl = this.#getSelectorData('showsMenu_lbl');

  channels_lbl = this.#getSelectorData('channels_lbl');

  browse_lbl = this.#getSelectorData('browse_lbl');

  tvGuideMenu_lbl = this.#getSelectorData('tvGuideMenu_lbl');

  myListMenu_lbl = this.#getSelectorData('myListMenu_lbl');

  searchMenu_lbl = this.#getSelectorData('searchMenu_lbl');

  accountMenu_lbl = this.#getSelectorData('accountMenu_lbl');

  myListMenuListItem = this.#getSelectorData('myListMenuListItem');

  channelsMenuListItem = this.#getSelectorData('channelsMenuListItem');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  signOut_lbl = this.getElementByPage('accountPage', 'signOut_lbl');

  focusedSportsPage = this.getElementByPage('sportsPage', 'focusedSportsPage');

  focusedShowsPage = this.getElementByPage('showPage', 'focusedShowsPage');

  focusedChannelsPage = this.getElementByPage(
    'channels',
    'focusedChannelsPage',
  );

  signUp_btn = this.getElementByPage('subscribeToWatchPage', 'signUp_btn');

  focusedTvGuidePage = this.getElementByPage(
    'tvGuidePage',
    'focusedTvGuidePage',
  );

  focusedMyListPage = this.getElementByPage('myListPage', 'focusedMyListPage');

  focusedSearchPage = this.getElementByPage('searchPage', 'focusedSearchPage');

  focusedAccountPage = this.getElementByPage(
    'accountPage',
    'focusedAccountPage',
  );

  exitPage_txt = this.getElementByPage('exitPage', 'exitPage_txt');

  focusedCancel_btn = this.getElementByPage('exitPage', 'focusedCancel_btn');

  focusedConfirmation_btn = this.getElementByPage(
    'exitPage',
    'focusedConfirmation_btn',
  );

  menuItem = {
    Home: this.homeMenu_lbl,
    Sports: this.sportsMenu_lbl,
    Shows: this.showsMenu_lbl,
    Browse: this.browse_lbl,
    Channels: this.channels_lbl,
    'TV Guide': this.tvGuideMenu_lbl,
    'My List': this.myListMenu_lbl,
    Search: this.searchMenu_lbl,
    Account: this.accountMenu_lbl,
  };

  pageFocused = {
    Home: this.focusedHomePage,
    Sports: this.focusedSportsPage,
    Shows: this.focusedShowsPage,
    Browse: this.focusedShowsPage,
    Channels: this.focusedChannelsPage,
    'TV Guide': this.focusedTvGuidePage,
    'My List': this.focusedMyListPage,
    Search: this.focusedSearchPage,
    Account: this.focusedAccountPage,
  };

  loggedIn = async () => {
    const result = await commons.elementExists(this.myListMenuListItem);

    return result;
  };

  noTvGuide = async () => {
    const result = await commons.doesNotExist(this.tvGuideMenuListItem);

    return result;
  };

  noChannels = async () => {
    const result = await commons.doesNotExist(this.channelsMenuListItem);

    return result;
  };

  openMenu = async () => {
    await commons.tryUntil(this.focusedMenuBar, VRC.BACK, 10, 1);
  };

  closeMenu = async () => {
    await commons.tryUntil(this.unfocusedMenuBar, VRC.RIGHT, 3, 1);
  };

  hasSignOut = async () => {
    const result = await commons.elementExists(this.signOut_lbl, 10);

    return result;
  };

  navigateToPage = async (pageValue) => {
    await this.openMenu();
    await commons.assertExists(this.focusedMenuBar, 10);
    const menuItemText = await commons.fetchAttributeData(
      this.focusedMenuItem,
      PROP.TEXT_CONTENT,
    );
    const menu = await this.getMenuList();
    const focusedIndex = menu.indexOf(menuItemText);
    const moveToIndex = menu.indexOf(pageValue);
    const difference = focusedIndex - moveToIndex;

    if (difference < 0) {
      await commons.userAction(VRC.DOWN, Math.abs(difference), 1);
    }
    if (difference > 0) {
      await commons.userAction(VRC.UP, difference, 1);
    }

    await commons.tryUntil(this.pageFocused[pageValue], VRC.SELECT, 3, 5);
    await commons.assertExists(this.pageFocused[pageValue], 10);
  };

  getMenuList = async () => {
    if ((await this.returnGeoLocation()) === 'america') {
      if (await this.noChannels()) {
        return this.kidsMenuList;
      }
      return this.menuListLoggedIn;
    }
    if ((await this.returnGeoLocation()) === 'emea') {
      if (await this.loggedIn()) {
        if (await this.noTvGuide()) {
          return this.kidsMenuList;
        }
        return this.menuListLoggedIn;
      }
      return this.menuListLoggedOut;
    }
    return [];
  };

  verifyMenuList = async () => {
    await this.openMenu();
    const menuList = await this.getMenuList();

    for (let i = 0; i < menuList.length; i++) {
      await commons.assertExists(this.menuItem[menuList[i]]);
      await commons.userAction(VRC.DOWN);
    }
    await this.closeMenu();
  };

  accessGlobalNavigationMenu = async () => {
    await this.openMenu();
  };

  verifyGlobalNavigation = async () => {
    await this.openMenu();
    const menuList = await this.getMenuList();

    for (let i = 0; i < menuList.length; i++) {
      await this.navigateToPage(menuList[i]);
    }
  };

  assertPage = async (pageValue) => {
    await commons.assertExists(this.pageFocused[pageValue]);
  };

  isCTAPresent = async (CTA) => {
    if (CTA === 'Sign Up') {
      await commons.assertExists(this.signUp_btn, 10);
    }
  };

  verifyExitConfirmation = async () => {
    await commons.assertExists(this.exitPage_txt, 10);
  };

  verifyAppBehavior = async (ctaType) => {
    if (ctaType === 'Back') {
      await commons.userAction(VRC.BACK);
      await commons.assertExists(this.focusedHomePage, 10);
    } else if (ctaType === 'Cancel') {
      await commons.userAction(VRC.BACK, 2, 2);
      await commons.assertExists(this.focusedCancel_btn, 5);
      await commons.userAction(VRC.SELECT);
      await commons.assertExists(this.focusedHomePage, 5);
    } else if (ctaType === 'Exit') {
      await commons.userAction(VRC.BACK, 2, 2);
      await commons.assertExists(this.focusedCancel_btn, 5);
      await commons.userAction(VRC.UP);
      await commons.assertExists(this.focusedConfirmation_btn, 5);
      await commons.userAction(VRC.SELECT);
    }
  };
}

module.exports = new MenuPage();
