const assert = require('assert');

const { BasePage, remoteActions } = require('./basePage');
const menuPage = require('./menuPage');
const showDetailsPage = require('./showDetailsPage');

const commons = remoteActions;
const { VRC } = commons;

class BrowsePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('browserPage', locator);
  }

  focusedBrowsePage = this.#getSelectorData('focusedBrowsePage');

  focusedAll_lbl = this.#getSelectorData('focusedAll_lbl');

  focusedTrending_lbl = this.#getSelectorData('focusedTrending_lbl');

  focusedAZ_lbl = this.#getSelectorData('focusedAZ_lbl');

  channel_logo = this.#getSelectorData('channel_logo');

  showTitle_txt = this.#getSelectorData('showTitle_txt');

  backGround_img = this.#getSelectorData('backGround_img');

  firstShowTile = this.#getSelectorData('firstShowTile');

  browserAddedToMyList_lbl = this.#getSelectorData('addedToMyList_lbl');

  browserRemovedFromMyList_lbl = this.#getSelectorData('removedFromMyList_lbl');

  showPageFirstCta_lbl = this.getElementByPage(
    'showDetailPage',
    'showPageFirstCta_lbl',
  );

  myListCta_lbl = this.getElementByPage('showDetailPage', 'myListCta_lbl');

  selectPage = async (pageType) => {
    await menuPage.navigateToPage(pageType);
  };

  verifyBrowsePage = async () => {
    await commons.assertExists(this.focusedBrowsePage, 4);
    await commons.assertExists(this.focusedAll_lbl);
  };

  selectNetwork = async (networkType) => {
    if (networkType === 'Entertainment') {
      await commons.userAction(VRC.RIGHT, 7, 2);
      await commons.userAction(VRC.DOWN, 1, 3);
      await commons.assertExists(this.focusedTrending_lbl, 10);
      await commons.userAction(VRC.RIGHT);
      await commons.assertExists(this.focusedAZ_lbl, 2);
    }
  };

  verifyShowMetaData = async () => {
    await commons.assertExists(this.showTitle_txt, 2);
    await commons.assertExists(this.channel_logo, 2);
    await commons.assertExists(this.backGround_img, 2);
  };

  verifyShowOnSelectedNetwork = async () => {
    await commons.userAction(VRC.DOWN, 2, 2);
    await commons.userAction(VRC.RIGHT);
    await commons.userAction(VRC.UP);
    await commons.userAction(VRC.LEFT);
    await this.verifyShowMetaData();
  };

  selectSubNav = async (subNav) => {
    if (subNav === 'first') {
      await commons.userAction(VRC.RIGHT);
      await this.verifyShowMetaData();
      await commons.userAction(VRC.SELECT);
    }
  };

  /**
   * The below function will open a show from Browse page and validate the CTAs
   */

  verifyShowCard = async () => {
    assert(
      (await commons.elementExists(this.showPageFirstCta_lbl, 5)) &&
        (await commons.elementExists(this.myListCta_lbl, 5)),
      'Watch Now button and Add to List Icon are not present',
    );
  };

  selectAsset = async () => {
    await commons.userAction(VRC.OK, 1, 10);
    await showDetailsPage.verifyShowLandingAnchorDetails();
  };

  addRemoveShowsFromMyList = async (action) => {
    await commons.waitUntil(this.firstShowTile);
    await commons.userAction(VRC.DOWN, 2, 1);
    await commons.userAction(VRC.SETTINGS);
    if (action === 'add') {
      await commons.assertExists(this.browserAddedToMyList_lbl);
    } else if (action === 'remove') {
      await commons.assertExists(this.browserRemovedFromMyList_lbl);
    }
  };
}

module.exports = new BrowsePage();
