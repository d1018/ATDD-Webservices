const assert = require('assert');
const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const menuPage = require('./menuPage');
const homePage = require('./homePage');
const browsePage = require('./browsePage');
const searchPage = require('./searchPage');

const { PROP, VRC, COMP } = commons;

class MyListPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myListPage', locator);
  }

  focusedMyListPage = this.#getSelectorData('focusedMyListPage');

  noSavedShow_txt = this.#getSelectorData('noSavedShow_txt');

  browserShows_btn = this.#getSelectorData('browserShows_btn');

  myListShowsMarkup = this.#getSelectorData('myListShowsMarkup');

  firstShowTile = this.getElementByPage('browserPage', 'firstShowTile');

  startWatching_btn = this.getElementByPage('homePage', 'startWatching_btn');

  addedToMyList_lbl = this.getElementByPage('homePage', 'addedToMyList_lbl');

  removedFromMyList_lbl = this.getElementByPage(
    'homePage',
    'removedFromMyList_lbl',
  );

  browserAddedToMyList_lbl = this.getElementByPage(
    'browserPage',
    'addedToMyList_lbl',
  );

  browserRemovedFromMyList_lbl = this.getElementByPage(
    'browserPage',
    'removedFromMyList_lbl',
  );

  focusedStartWatching_btn = this.getElementByPage(
    'homePage',
    'focusedStartWatching_btn',
  );

  focusedTopLeftShowTile = this.getElementByPage(
    'homePage',
    'focusedTopLeftShowTile',
  );

  tooltipComponentAddShows_lbl = this.getElementByPage(
    'browserPage',
    'tooltipComponentAddShows_lbl',
  );

  tooltipComponentRemoveShows_lbl = this.getElementByPage(
    'myListPage',
    'tooltipComponentRemoveShows_lbl',
  );

  focusedShowDetailPage = this.getElementByPage(
    'showDetailPage',
    'focusedShowDetailPage',
  );

  firstSavedShowTile = this.getElementByPage(
    'myListPage',
    'firstSavedShowTile',
  );

  showPageFirstCta_lbl = this.getElementByPage(
    'showDetailPage',
    'showPageFirstCta_lbl',
  );

  focusedShowTile = this.getElementByPage('searchPage', 'focusedShowTile');

  /**
   * Go to My list page then browse page
   * Select first show, go to show details page
   * click +My list button
   * Back to browse page and page to my list screen
   */
  addShowsToMylistFromBrowse = async () => {
    await menuPage.navigateToPage('My List');
    await commons.waitUntil(this.noSavedShow_txt);
    await commons.waitUntil(this.browserShows_btn);
    await commons.userAction(VRC.OK, 1, 3);

    await commons.waitUntil(this.firstShowTile);
    await commons.userAction(VRC.DOWN, 2, 1);
    await commons.userAction(VRC.OK);

    await commons.waitUntil(this.focusedShowDetailPage);
    await commons.assertExists(this.showPageFirstCta_lbl);
    await commons.userAction(VRC.RIGHT);
    await commons.userAction(VRC.OK);
    await commons.userAction(VRC.BACK);
  };

  /**
   * Go to For You tab and select a show not yet in my list.
   */
  navigateToShowTileInHomePage = async () => {
    await commons.waitUntil(this.startWatching_btn);
    await commons.userAction(VRC.DOWN);
    await commons.waitUntil(this.focusedStartWatching_btn);
    await commons.assertExists(this.focusedStartWatching_btn);
    await commons.tryUntil(this.focusedTopLeftShowTile, VRC.DOWN, 2, 1);
    // A maximum of 6 shows should be enough to have at least one show not be in my list
    await commons.tryUntil(this.tooltipComponentAddShows_lbl, VRC.RIGHT, 6, 1);
    await commons.assertExists(this.tooltipComponentAddShows_lbl);
  };

  /**
   * For Roku, add to my list via * button on remote
   */
  pressAndHoldOnShow = async () => {
    await commons.userAction(VRC.SETTINGS);
  };

  /**
   * Go to My list page then browse page
   * Verify show tile exists
   * The below function will verify the MyList Rail
   *
   * @param {boolean} isRailPresent - MyList Rail status true or false
   */
  verifyShowsInMyList = async (isRailPresent) => {
    await menuPage.navigateToPage('My List');
    if (isRailPresent) {
      await commons.elementExists(this.firstSavedShowTile);
    } else {
      await commons.doesNotExist(this.firstSavedShowTile);
    }
  };

  /**
   * Go to My list page
   * Remove ALL shows from my list
   * Verify no shows are on my list page
   */
  removeShowFromMyListPage = async () => {
    await menuPage.navigateToPage('My List');
    while (await commons.elementExists(this.firstSavedShowTile)) {
      await commons.userAction(VRC.SETTINGS, 1, 2);
      await commons.assertExists(this.removedFromMyList_lbl);
    }
    await commons.assertExists(this.noSavedShow_txt);
    await commons.assertExists(this.browserShows_btn);
  };

  verifyAddRemoveMyListInHomePage = async (action) => {
    if (action === 'added to') {
      await commons.assertExists(this.addedToMyList_lbl);
      await this.verifyRemoveShowTooltip();
    } else if (action === 'removed from') {
      await commons.assertExists(this.removedFromMyList_lbl);
      await this.verifyAddShowTooltip();
    } else {
      throw new Error(`Unsupported action: ${action}`);
    }
  };

  /*
   * Verify add show tool tip is present when a show is highlighted
   */
  verifyAddShowTooltip = async () => {
    await commons.waitUntil(this.tooltipComponentAddShows_lbl);
    await commons.assertExists(this.tooltipComponentAddShows_lbl);
  };

  /**
   * Navigate to Detail Page from My List Page
   */
  navigateToDetailPageFromMyList = async () => {
    await menuPage.navigateToPage('My List');
    await commons.waitUntil(this.focusedMyListPage);
    await commons.userAction(VRC.SELECT);
  };

  /**
   * Navigating back using remote on Roku
   */
  navigateBack = async () => {
    await commons.userAction(VRC.BACK);
  };

  /**
   * For Roku, validate my list page
   */
  validateMyListPage = async () => {
    await commons.waitUntil(this.focusedMyListPage);
  };

  /**
   * Verify remove show tool tip is present when a show is highlighted
   */
  verifyRemoveShowTooltip = async () => {
    await commons.waitUntil(this.tooltipComponentRemoveShows_lbl);
    await commons.assertExists(this.tooltipComponentRemoveShows_lbl);
  };

  verifyShowsOnMyListPage = async (showNum) => {
    await commons.assertProperty(
      this.myListShowsMarkup,
      PROP.CHILDREN,
      Number(showNum),
      COMP.EQUAL,
    );
    await homePage.verifyMyListRailShowOrder();
  };

  /**
   * Verify My List sorting, newest first
   */
  verifyMyListSorting = async () => {
    await menuPage.navigateToPage('Search');
    await commons.userAction(VRC.RIGHT, 6, 1);
    await this.pressAndHoldOnShow();

    const showImage = await commons.fetchAttributeData(
      this.focusedShowTile,
      PROP.IMAGE,
    );
    const regex = '^[^?]*'; // url has sizing that needs to be striped
    const savedShow = RegExp(regex, 'gm').exec(showImage);

    await menuPage.navigateToPage('My List');
    const firstMyListShow = await commons.fetchAttributeData(
      this.firstSavedShowTile,
      PROP.IMAGE,
    );
    const myListShow = new RegExp(regex, 'gm').exec(firstMyListShow);

    assert(
      savedShow[0] === myListShow[0],
      'My List is not in ascending order!',
    );
  };

  selectBrowseShows = async () => {
    await commons.assertExists(this.browserShows_btn);
    await commons.userAction(VRC.OK, 1, 3);
  };

  addShowsToMyList = async (pageName) => {
    await menuPage.navigateToPage(pageName);
    if (pageName === 'Home') {
      await homePage.addShowToMylistFromHomeHero();
    } else if (pageName === 'Browse') {
      await browsePage.addRemoveShowsFromMyList('add');
    } else if (pageName === 'Search') {
      await searchPage.addShowsToMylistFromSearch();
    }
  };

  removeShowFromMyList = async (pageName) => {
    await menuPage.navigateToPage(pageName);
    if (pageName === 'Home') {
      await homePage.removedShowFromMylistFromHomeHero();
    } else if (pageName === 'Browse') {
      await browsePage.addRemoveShowsFromMyList('remove');
    } else if (pageName === 'Search') {
      await searchPage.removeShowsFromMylistFromSearch();
    }
  };
}

module.exports = new MyListPage();
