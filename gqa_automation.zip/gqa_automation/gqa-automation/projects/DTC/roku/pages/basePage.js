const path = require('path');
const {
  remoteActions,
  customErrors,
  testdataHelper,
} = require('@wbd/gqa-core/support');

const ymlpath = path.resolve(__dirname);

const EnvBase = require('../../../support/env');

const { skipReason } = require('../../../support/skipReason');

let isUserAnonymousType;

let isUserKidsType;

let isUserLoggedIn;

const showPageDetail = new Map();

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }

  setAnonymousUserValue(boolVal) {
    isUserAnonymousType = boolVal;
  }

  getAnonymousUserValue() {
    return isUserAnonymousType;
  }

  setKidsUserValue(boolVal) {
    isUserKidsType = boolVal;
  }

  getKidsUserValue() {
    return isUserKidsType;
  }

  setLoggedInUser(boolVal) {
    isUserLoggedIn = boolVal;
  }

  getLoggedInUser() {
    return isUserLoggedIn;
  }

  setShowPageDetail(
    showName,
    episodeName,
    episodeDescription,
    episodeRating,
    heroImage,
  ) {
    showPageDetail.set('showName', showName);
    showPageDetail.set('episodeName', episodeName);
    showPageDetail.set('episodeDescription', episodeDescription);
    showPageDetail.set('episodeRating', episodeRating);
    showPageDetail.set('heroImage', heroImage);
  }

  getShowPageDetail() {
    return showPageDetail;
  }
}

module.exports = {
  remoteActions,
  customErrors,
  skipReason,
  testdataHelper,
  BasePage,
};
