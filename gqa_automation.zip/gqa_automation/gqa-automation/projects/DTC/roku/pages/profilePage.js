const assert = require('assert');
const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const menuPage = require('./menuPage');

const { VRC, PROP, COMP } = commons;
let profileLocalName;
let pinProfile = false;
let numberofProfilesPreDeletion;

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  delete_btn = this.#getSelectorData('delete_btn');

  profileList = this.#getSelectorData('profileList');

  kidsToggle = this.#getSelectorData('kidsToggle');

  kidsToggle_lbl = this.#getSelectorData('kidsToggle_lbl');

  addProfile_lbl = this.#getSelectorData('addProfile_lbl');

  profileAddEdit = this.#getSelectorData('profileAddEdit');

  focusedProfile = this.#getSelectorData('focusedProfile');

  addProfile_btn = this.#getSelectorData('addProfile_btn');

  deleteCtaFocused_btn = this.#getSelectorData('deleteCtaFocused_btn');

  focusedProfilePage = this.#getSelectorData('focusedProfilePage');

  deleteModalFocused_btn = this.#getSelectorData('deleteModalFocused_btn');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  focusedAddProfile_lbl = this.#getSelectorData('focusedAddProfile_lbl');

  focusedProfile_txtBx = this.#getSelectorData('focusedProfile_txtBx');

  cancelEditProfile_btn = this.#getSelectorData('cancelEditProfile_btn');

  editProfile_lbl = this.#getSelectorData('editProfile_lbl');

  editProfileError_txt = this.#getSelectorData('editProfileError_txt');

  newProfileName_txt = this.#getSelectorData('newProfileName_txt');

  profileNameContent_txt = this.#getSelectorData('profileNameContent_txt');

  profileName_txt = this.#getSelectorData('profileName_txt');

  profileLock_img = this.#getSelectorData('profileLock_img');

  dynamicPinPad_txtBx = this.#getSelectorData('dynamicPinPad_txtBx');

  ageRestrictionAttribute = this.#getSelectorData('ageRestrictionAttribute');

  focusedProfileTextBox_lbl = this.#getSelectorData(
    'focusedProfileTextBox_lbl',
  );

  focusedProfileLabelInMenu = this.getElementByPage(
    'homePage',
    'focusedProfileLabelInMenu',
  );

  focusedMenuBar = this.getElementByPage('menuPage', 'focusedMenuBar');

  deleteProfileFromDeleteCta = async () => {
    await commons.userAction(VRC.UP);
    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.deleteModalFocused_btn, 4);
    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.focusedProfilePage, 5);
  };

  moveToProfilePage = async () => {
    if (await commons.doesNotExist(this.focusedProfilePage, 5)) {
      await menuPage.openMenu();
      await commons.assertExists(this.focusedMenuBar, 5);
      await commons.tryUntil(this.focusedProfileLabelInMenu, VRC.UP, 8, 1);
      await commons.userAction(VRC.SELECT);
      await commons.assertExists(this.focusedProfilePage, 3);
    }
  };

  moveToFirstProfile = async () => {
    await commons.assertExists(this.focusedProfilePage, 10);
    while (
      await commons.checkProperty(
        this.focusedProfile,
        PROP.INDEX,
        0,
        COMP.NOT_EQUAL,
      )
    ) {
      await commons.userAction(VRC.LEFT);
    }
    await commons.assertProperty(
      this.focusedProfile,
      PROP.INDEX,
      0,
      COMP.EQUAL,
    );
  };

  moveToAddProfileLabelAndSelect = async () => {
    await commons.assertExists(this.focusedProfilePage, 5);
    await commons.assertExists(this.addProfile_lbl);
    while (await commons.doesNotExist(this.focusedAddProfile_lbl)) {
      await commons.userAction(VRC.RIGHT);
    }
    await commons.assertExists(this.focusedAddProfile_lbl);
    await commons.userAction(VRC.SELECT);
  };

  deleteProfileIfAddButtonNotShown = async () => {
    if (await commons.doesNotExist(this.addProfile_lbl)) {
      do {
        await commons.userAction(VRC.DOWN);
        await commons.userAction(VRC.SELECT);
        await commons.assertExists(this.profileAddEdit, 5);
        await commons.userAction(VRC.UP);
        if (await commons.elementExists(this.deleteCtaFocused_btn)) {
          await this.deleteProfileFromDeleteCta();
          break;
        } else {
          await commons.userAction(VRC.BACK);
          await commons.assertExists(this.focusedProfilePage);
          await commons.userAction(VRC.UP);
          await commons.userAction(VRC.RIGHT);
        }
      } while (
        await commons.checkProperty(
          this.focusedProfile,
          PROP.INDEX,
          4,
          COMP.LESSER,
        )
      );
    }
  };

  clearTextBoxAndEnterData = async (text) => {
    const len = await commons.fetchAttributeData(
      this.focusedProfileTextBox_lbl,
      PROP.TEXT_CONTENT,
    );

    await commons.userAction(VRC.SELECT);
    if (len > 0) {
      await commons.userAction(VRC.DOWN, 2, 1);
      await commons.userAction(VRC.SELECT, len, 1);
    }
    await commons.sendText(text);
    await commons.userAction(VRC.BACK);
  };

  createNewProfile = async (profileName) => {
    const dateObject = new Date();
    const localeDate = dateObject.toLocaleDateString();
    const localeTime = dateObject.toLocaleTimeString();

    profileLocalName = String(`${profileName}_${localeDate}_${localeTime}`);

    if (profileLocalName.length > 30) {
      profileLocalName = profileLocalName.substr(0, 30);
    }

    await this.moveToFirstProfile();
    await this.deleteProfileIfAddButtonNotShown();
    await this.moveToAddProfileLabelAndSelect();
    await commons.assertExists(this.profileAddEdit);
    await commons.tryUntil(this.focusedProfile_txtBx, VRC.UP, 2, 1);
    await this.clearTextBoxAndEnterData(profileLocalName);
    if (profileName === 'Kids') {
      await commons.tryUntil(this.kidsToggle, VRC.DOWN, 2, 1);
      await commons.userAction(VRC.SELECT);
      await commons.assertProperty(
        this.kidsToggle_lbl,
        PROP.TEXT_CONTENT,
        'ON',
        COMP.EQUAL,
      );
    }
    await commons.tryUntil(this.addProfile_btn, VRC.DOWN, 2, 1);
    await commons.userAction(VRC.SELECT);
  };

  moveToHomePageFromProfilePage = async () => {
    await commons.assertExists(this.focusedProfilePage, 10);
    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.focusedHomePage, 10);
  };

  createNewProfileandSelect = async (profileName) => {
    if (this.getAnonymousUserValue()) {
      return;
    }
    await this.moveToProfilePage();
    await this.createNewProfile(profileName);
    await this.moveToHomePageFromProfilePage();
  };

  selectDefaultProfile = async () => {
    await this.moveToFirstProfile();
    const numberofProfiles = await commons.fetchAttributeData(
      this.profileList,
      PROP.CHILDREN,
    );

    let defaultProfile = false;

    while (
      await commons.checkProperty(
        this.focusedProfile,
        PROP.INDEX,
        Number(numberofProfiles) - 1,
        COMP.EQUAL_LESSER,
      )
    ) {
      await commons.userAction(VRC.DOWN, 1, 3);
      await commons.userAction(VRC.SELECT, 1, 3);
      await commons.assertExists(this.profileAddEdit, 5);
      await commons.assertExists(this.focusedProfileTextBox_lbl);
      if (
        (await commons.doesNotExist(this.ageRestrictionAttribute)) &&
        (await commons.doesNotExist(this.delete_btn))
      ) {
        await commons.assertDoesNotExist(this.ageRestrictionAttribute, 5);
        defaultProfile = true;
      }

      await commons.tryUntil(this.focusedProfilePage, VRC.BACK, 3, 3);
      await commons.assertExists(this.focusedProfilePage);
      await commons.userAction(VRC.UP, 3, 2);

      if (defaultProfile) {
        await commons.tryUntil(this.focusedHomePage, VRC.SELECT, 3, 3);
        if (await commons.elementExists(this.dynamicPinPad_txtBx)) {
          const profilePin = testdataHelper.getContent('profilePin.profilePin');

          await commons.assertExists(this.dynamicPinPad_txtBx, 3);
          await commons.sendText(profilePin);
        }
        await commons.assertExists(this.focusedHomePage, 20);
        break;
      } else {
        await commons.userAction(VRC.RIGHT);
      }
    }
  };

  selectPinProfile = async () => {
    const profilePin = testdataHelper.getContent('profilePin.profilePin');

    await this.moveToFirstProfile();
    await commons.tryUntil(this.profileLock_img, VRC.RIGHT, 5, 1);
    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.dynamicPinPad_txtBx, 3);
    await commons.sendText(profilePin);
    await commons.assertExists(this.forYou_lbl, 10);
  };

  profileCreation = async (profileName) => {
    await this.moveToProfilePage();
    if (profileName === 'Pin') {
      pinProfile = true;
      // Creation of pin profile is applicable in Web Only
      // Select Pin Profile
      await this.selectPinProfile();
    } else {
      await this.createNewProfile(profileName);
      await this.moveToHomePageFromProfilePage();
    }
  };

  deleteExistingProfile = async () => {
    if (pinProfile === true) {
      // Do nothing and not delete the profile
    } else {
      if (profileLocalName.includes('Kids')) {
        await this.moveToProfilePage();
        await this.selectDefaultProfile();
      }
      await this.moveToProfilePage();
      await this.moveToFirstProfile();
      let i = 5;

      while (i > 0) {
        if (
          await commons.checkProperty(
            this.profileName_txt,
            PROP.TEXT_CONTENT,
            profileLocalName,
            COMP.EQUAL,
          )
        ) {
          await commons.userAction(VRC.DOWN);
          await commons.userAction(VRC.SELECT);
          await commons.assertExists(this.profileAddEdit, 5);
          await this.deleteProfileFromDeleteCta();
          break;
        } else {
          await commons.userAction(VRC.RIGHT, 1);
          i -= 1;
        }
      }
    }
  };

  selectExistingKidsProfile = async (profileName) => {
    await this.moveToProfilePage();
    await this.moveToFirstProfile();
    let i = 5;

    while (i > 0) {
      const profileNamefromScreen = await commons.fetchAttributeData(
        this.profileName_txt,
        PROP.TEXT_CONTENT,
      );

      if (profileNamefromScreen.includes(profileName)) {
        await commons.userAction(VRC.SELECT);
        await commons.assertExists(this.forYou_lbl, 10);
        return true;
      }

      await commons.userAction(VRC.RIGHT);
      if (
        await commons.checkProperty(
          this.profileName_txt,
          PROP.TEXT_CONTENT,
          'Add Profile',
          COMP.EQUAL,
        )
      ) {
        return false;
      }
      i -= 1;
    }
    return false;
  };

  selectProfile = async (profileName) => {
    if (profileName !== 'Anonymous') {
      if (profileName === 'Default') {
        await this.moveToProfilePage();
        await this.selectDefaultProfile();
      } else if (profileName === 'Kids') {
        this.setKidsUserValue(true);
        if (!(await this.selectExistingKidsProfile(profileName))) {
          await this.createNewProfileandSelect(profileName);
        }
      }
    }
  };

  deleteProfile = async () => {
    await this.moveToProfilePage();
    await this.moveToFirstProfile();
    numberofProfilesPreDeletion = await commons.fetchAttributeData(
      this.profileList,
      PROP.CHILDREN,
    );
    let i = 5;

    while (i > 0) {
      await commons.userAction(VRC.DOWN);
      await commons.userAction(VRC.SELECT);
      if (await commons.elementExists(this.delete_btn, 2)) {
        await this.deleteProfileFromDeleteCta();
        break;
      } else {
        await commons.userAction(VRC.UP);
        await commons.userAction(VRC.RIGHT);
        if (
          await commons.checkProperty(
            this.profileName_txt,
            PROP.TEXT_CONTENT,
            'Add Profile',
            COMP.EQUAL,
          )
        ) {
          break;
        } else {
          i -= 1;
        }
      }
    }
  };

  verifyUserProfileDeleted = async () => {
    const numberofProfilesPostDeletion = await commons.fetchAttributeData(
      this.profileList,
      PROP.CHILDREN,
    );

    if (numberofProfilesPostDeletion > numberofProfilesPreDeletion) {
      throw new Error('Profile has not been deleted');
    }
  };

  navigateToManageProfiles = async () => {
    if (this.getAnonymousUserValue()) {
      return;
    }
    await this.moveToProfilePage();
  };

  selectProfileToManage = async () => {
    await this.navigateToManageProfiles();
    await this.moveToFirstProfile();
    await this.deleteProfileIfAddButtonNotShown();
    await this.moveToAddProfileLabelAndSelect();
  };

  verifyEditProfilePage = async () => {
    await commons.assertExists(this.profileAddEdit);
    await commons.assertExists(this.addProfile_btn);
    await commons.userAction(VRC.LEFT);
    await commons.assertExists(this.cancelEditProfile_btn);
    await commons.userAction(VRC.UP);
    await commons.assertExists(this.kidsToggle_lbl);
    await commons.assertExists(this.kidsToggle);
    await commons.userAction(VRC.UP);
    await commons.assertExists(this.focusedProfile_txtBx);
    await commons.assertExists(this.editProfile_lbl, 5);
    await commons.assertExists(this.focusedProfileTextBox_lbl);
  };

  changeProfileName = async (name) => {
    if (name === '') {
      await commons.assertExists(this.focusedProfile_txtBx);
      await commons.userAction(VRC.SELECT);
      await commons.sendText('');
      await this.verifyErrorMessage('Error');
      await commons.userAction(VRC.BACK, 2, 4);
      await commons.userAction(VRC.LEFT, 4, 5);
      await commons.assertExists(this.focusedProfilePage, 5);
    } else if (name === 'ThisIsANameThatIsLongerThanThirtyCharacters') {
      await commons.assertExists(this.focusedProfile_txtBx);
      await commons.userAction(VRC.SELECT);
      await commons.sendText(
        `${testdataHelper.getContent(`editProfileLander.inValidProfileName`)}`,
      );
      await this.verifyErrorMessage('Error');
      await commons.userAction(VRC.BACK, 2, 4);
      await commons.userAction(VRC.LEFT, 4, 5);
      await commons.assertExists(this.focusedProfilePage, 5);
    } else if (name === 'Default') {
      await commons.assertExists(this.focusedProfile_txtBx);
      await commons.userAction(VRC.SELECT);
      await commons.sendText(
        `${testdataHelper.getContent(`editProfileLander.validProfileName`)}`,
      );

      await this.verifyErrorMessage('NoError');
      await commons.userAction(VRC.BACK);
      await commons.userAction(VRC.DOWN, 2, 3);
      await commons.userAction(VRC.ENTER, 1, 4);
      await commons.assertExists(this.focusedProfilePage, 5);
      await commons.assertExists(this.newProfileName_txt, 5);

      const currentProfileName = await commons.fetchAttributeData(
        this.newProfileName_txt,
        PROP.TEXT_CONTENT,
      );

      assert(
        currentProfileName ===
          testdataHelper.getContent(`editProfileLander.validProfileName`),
        'Not able to view the Reflected Profile Name',
      );

      await commons.userAction(VRC.DOWN);
      await commons.assertExists(this.editProfile_lbl, 5);
      await commons.userAction(VRC.SELECT);
      await commons.assertExists(this.profileAddEdit, 5);
      await commons.userAction(VRC.UP);
      await commons.assertExists(this.deleteCtaFocused_btn);
      await this.deleteProfileFromDeleteCta();
    }
  };

  verifyErrorMessage = async (err) => {
    const errorMsg = testdataHelper.getContent('editProfileLander.inLineError');

    switch (err) {
      case 'Error':
        await commons.assertProperty(
          this.editProfileError_txt,
          PROP.TEXT_CONTENT,
          errorMsg,
          COMP.EQUAL,
        );
        break;
      case 'NoError':
        if (await commons.doesNotExist(this.editProfileError_txt)) {
          await commons.assertDoesNotExist(this.editProfileError_txt);
        }
        break;
      default:
        break;
    }
  };
}

module.exports = new ProfilePage();
