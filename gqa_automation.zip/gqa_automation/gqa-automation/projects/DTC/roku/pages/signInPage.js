const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const { VRC, PROP, COMP } = commons;
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');
const welcomePage = require('./welcomePage');

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  focusedProfilePage = this.getElementByPage(
    'profilePage',
    'focusedProfilePage',
  );

  accountPage = this.getElementByPage('accountPage', 'focusedAccountPage');

  focusedSignInPage = this.#getSelectorData('focusedSignInPage');

  continue_btn = this.#getSelectorData('continue_btn');

  signInDifferent_btn = this.#getSelectorData('signInDifferent_btn');

  signIn_btn = this.#getSelectorData('signIn_btn');

  userName_txtBx = this.#getSelectorData('userName_txtBx');

  password_txtBx = this.#getSelectorData('password_txtBx');

  loadInvisible_img = this.#getSelectorData('loadInvisible_img');

  signInError_lbl = this.#getSelectorData('signInError_lbl');

  focusedExitPage = this.getElementByPage('exitPage', 'focusedExitPage');

  focusedNavTab_lbl = this.getElementByPage('accountPage', 'focusedNavTab_lbl');

  profileLabel_lbl = this.getElementByPage('profilePage', 'profileLabel_lbl');

  dynamicPinPad_txtBx = this.getElementByPage(
    'profilePage',
    'dynamicPinPad_txtBx',
  );

  signOutFocused_btn = this.getElementByPage(
    'accountPage',
    'signOutFocused_btn',
  );

  focusedConfirmation_btn = this.getElementByPage(
    'exitPage',
    'focusedConfirmation_btn',
  );

  focusedWelcomePage = this.getElementByPage(
    'welcomePage',
    'focusedWelcomePage',
  );

  focusedAccountPage = this.getElementByPage(
    'accountPage',
    'focusedAccountPage',
  );

  focusedRokuHomePage = this.getElementByPage(
    'rokuHomePage',
    'focusedRokuHomePage',
  );

  focusedEventDetailPage = this.getElementByPage(
    'sportsPage',
    'eventDetailPage',
  );

  focusedInactivePage = this.getElementByPage(
    'inactivePage',
    'focusedInactivePage',
  );

  inactiveSubscription_txt = this.getElementByPage(
    'inactivePage',
    'inactiveSubscription_txt',
  );

  inactiveSubscriptionUK_txt = this.getElementByPage(
    'inactivePage',
    'inactiveSubscriptionUK_txt',
  );

  signOut_btn = this.getElementByPage('inactivePage', 'signOut_btn');

  openApp = async () => {
    await commons.openApp();
    if (await commons.elementExists(this.focusedRokuHomePage, 2)) {
      await commons.openApp();
    }
    await this.signOutApplication();
  };

  navigateToSignInScreen_US = async () => {
    await this.loadingInvisible();
    await commons.tryUntil(this.signIn_btn, VRC.DOWN, 2, 1);
    await commons.userAction(VRC.ENTER, 1, 4);
    await commons.waitUntil(this.continue_btn, 10);
    await commons.userAction(VRC.DOWN, 1, 3);
    await commons.assertExists(this.signInDifferent_btn);
    await commons.userAction(VRC.ENTER, 1, 3);
  };

  navigateToSignInScreen_EMEA = async () => {
    await commons.tryUntil(this.signIn_btn, VRC.DOWN, 2, 1);
    await commons.userAction(VRC.ENTER, 1);
    await commons.waitUntil(this.continue_btn, 10);
    await commons.tryUntil(this.signInDifferent_btn, VRC.DOWN, 2, 1);
    await commons.userAction(VRC.ENTER, 1);
    await commons.waitUntil(this.userName_txtBx, 10);
  };

  enterCredentials = async (credentialType) => {
    const credentials = this.setCredentials(credentialType);
    const { username } = credentials;
    const { password } = credentials;

    // selecting the password field and entering password
    await commons.assertExists(this.userName_txtBx);
    await commons.userAction(VRC.ENTER);
    await commons.sendText(username);
    await commons.userAction(VRC.BACK);
    await commons.userAction(VRC.DOWN);
    // selecting the password field and entering password
    await commons.assertExists(this.password_txtBx, 10);
    await commons.userAction(VRC.ENTER);
    await commons.sendText(password);
    await commons.userAction(VRC.BACK);
    await commons.userAction(VRC.DOWN);
    // Selecting signin Button
    await commons.userAction(VRC.ENTER);
  };

  /*
   * setting credentials for enterCredentials method.
   * testing incorrect credentials test cases are added.
   */
  setCredentials = (credentialType) => {
    const invalidUsername = testdataHelper.getContent(
      'signInPage.incorrectUser',
    );
    const invalidPassword = testdataHelper.getContent(
      'signInPage.incorrectPass',
    );

    let username;
    let password;
    // for testing incorrect credentials test cases
    const correctCredentialType = 'DTC_VALID';

    switch (credentialType) {
      case 'InvalidPassword':
        username = process.env[`${correctCredentialType}_USERNAME`];
        password = invalidPassword;
        break;

      case 'InvalidUsername':
        username = invalidUsername;
        password = process.env[`${correctCredentialType}_PASSWORD`];
        break;

      case 'InvalidUserName_InvalidPassword':
        username = invalidUsername;
        password = invalidPassword;
        break;

      // default is to use credentials from .env
      default:
        username = process.env[`${credentialType}_USERNAME`];
        password = process.env[`${credentialType}_PASSWORD`];
        break;
    }

    return { username, password };
  };

  moveToHomePage = async () => {
    if (await commons.elementExists(this.focusedProfilePage, 10)) {
      await commons.userAction(VRC.SELECT);
      if (await commons.elementExists(this.dynamicPinPad_txtBx)) {
        await commons.userAction(VRC.BACK);
        await commons.assertExists(this.focusedProfilePage);
        await profilePage.selectDefaultProfile();
      }
    } else if (await commons.elementExists(this.accountPage, 20)) {
      await menuPage.navigateToPage('Home');
    }
    if (await commons.doesNotExist(this.focusedInactivePage, 10)) {
      await commons.assertExists(this.focusedHomePage, 10);
    }
  };

  loadingInvisible = async () => {
    await commons.assertExists(this.loadInvisible_img, 10);
  };

  loginToApplication = async (credentialType) => {
    if (this.returnGeoLocation() === 'america') {
      if (credentialType.toLowerCase() === 'anonymous') {
        this.setAnonymousUserValue(true);
        return;
      }
      this.setAnonymousUserValue(false);
      await commons.assertExists(this.focusedWelcomePage);
      await this.navigateToSignInScreen_US();
    } else {
      if (credentialType.toLowerCase() === 'anonymous') {
        this.setAnonymousUserValue(true);
        return;
      }
      this.setAnonymousUserValue(false);
      if (await commons.elementExists(this.focusedEventDetailPage, 5)) {
        await commons.userAction(VRC.ENTER, 1, 5);
        await commons.waitUntil(this.continue_btn, 10);
        await commons.userAction(VRC.DOWN, 1, 3);
        await commons.userAction(VRC.ENTER, 1, 3);
      } else {
        await menuPage.navigateToPage('Account');
        await this.navigateToSignInScreen_EMEA();
      }
    }
    await commons.assertExists(this.focusedSignInPage);
    await this.enterCredentials(credentialType);
    if (
      credentialType.toLowerCase().includes('lapsed') &&
      this.returnGeoLocation() === 'america'
    ) {
      await commons.assertExists(this.focusedInactivePage, 10);
    }
    if (!(await commons.elementExists(this.focusedEventDetailPage, 5))) {
      await this.moveToHomePage();
    }
    this.setLoggedInUser(true);
  };

  switchKidsToDefaultProfile = async () => {
    const profileName = await commons.fetchAttributeData(
      this.profileLabel_lbl,
      PROP.TEXT_CONTENT,
    );

    if (profileName.includes('Kids')) {
      await profilePage.moveToProfilePage();
      await profilePage.selectDefaultProfile();
    }
  };

  signOutApplication = async () => {
    await this.loadingInvisible();
    if (this.returnGeoLocation() === 'emea') {
      if (await commons.elementExists(this.focusedProfilePage, 10)) {
        await profilePage.selectDefaultProfile();
        await commons.assertExists(this.focusedHomePage);
      }
      await menuPage.openMenu();
      if (await menuPage.loggedIn()) {
        await this.switchKidsToDefaultProfile();
        await menuPage.navigateToPage('Account');
        await this.checkAndSignOut();
        await commons.assertExists(this.focusedAccountPage, 10);
      }
      await menuPage.closeMenu();
      await menuPage.navigateToPage('Home');
    } else if (this.returnGeoLocation() === 'america') {
      let delay = 0;

      if (await commons.elementExists(this.focusedInactivePage, 10)) {
        await commons.assertExists(this.inactiveSubscription_txt, 10);
        await commons.tryUntil(this.signOut_btn, VRC.DOWN, 5, 5);
        await commons.userAction(VRC.DOWN, 3, 3);
        await commons.userAction(VRC.SELECT);
      }

      if (await commons.elementExists(this.focusedProfilePage, 5)) {
        await commons.assertExists(this.focusedProfilePage, 5);
        await commons.userAction(VRC.UP, 3, 3);
        await commons.assertExists(this.focusedProfilePage, 5);
        await commons.tryUntil(this.focusedHomePage, VRC.SELECT, 3, 5);
        await commons.assertExists(this.focusedHomePage, 10);
        delay = 10;
      }
      if (await commons.doesNotExist(this.focusedWelcomePage, delay + 5)) {
        await commons.assertDoesNotExist(this.focusedWelcomePage, delay + 5);
        await this.loadingInvisible();
        await menuPage.openMenu();
        await this.switchKidsToDefaultProfile();
        await menuPage.navigateToPage('Account');
        await commons.assertExists(this.focusedAccountPage, 10);
        await this.checkAndSignOut();
      }
      await commons.assertExists(this.focusedWelcomePage);
    }
    this.setKidsUserValue(false);
    this.setLoggedInUser(false);
  };

  checkAndSignOut = async () => {
    if (await menuPage.hasSignOut()) {
      while (
        await commons.checkProperty(
          this.focusedNavTab_lbl,
          PROP.TEXT_CONTENT,
          'Sign Out',
          COMP.NOT_EQUAL,
        )
      ) {
        await commons.userAction(VRC.RIGHT);
      }
      await commons.tryUntil(this.signOutFocused_btn, VRC.DOWN, 3, 5);
      await commons.assertExists(this.signOutFocused_btn, 10);
      await commons.tryUntil(this.focusedExitPage, VRC.SELECT, 3, 5);
      await commons.assertExists(this.focusedExitPage, 10);
      await commons.userAction(VRC.UP);
      await commons.assertExists(this.focusedConfirmation_btn, 5);
      await commons.userAction(VRC.SELECT);
    }
  };

  verifySignOut = async () => {
    await commons.assertExists(this.focusedWelcomePage, 10);
    await commons.assertExists(welcomePage.signIn_btn, 3);
    await commons.assertExists(welcomePage.subscribeNow_btn, 3);
  };

  /*
   * to verify sign in error message:
   * Email or password entered incorrectly. Please try again.
   */
  verifyIncorrectCredentialError = async () => {
    await commons.assertExists(this.signInError_lbl);

    const errorMsg = testdataHelper.getContent('signInPage.signInError');

    await commons.assertProperty(
      this.signInError_lbl,
      PROP.TEXT_CONTENT,
      errorMsg,
      COMP.EQUAL,
    );
  };

  navigateToSignInFromWelcomeScreen = async () => {
    if (this.returnGeoLocation() === 'america') {
      await this.navigateToSignInScreen_US();
    } else {
      throw new Error(
        `geolocation not supported : ${this.returnGeoLocation()}`,
      );
    }
  };
}

module.exports = new SignInPage();
