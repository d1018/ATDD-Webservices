const assert = require('assert');
const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const menuPage = require('./menuPage');

const { VRC, PROP } = commons;
let searchText = '';

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  search_txtBx = this.#getSelectorData('search_txtBx');

  showTitle_lbl = this.#getSelectorData('showTitle_lbl');

  showImage_img = this.#getSelectorData('showImage_img');

  showNetworkIcon_img = this.#getSelectorData('showNetworkIcon_img');

  showsTab_lbl = this.#getSelectorData('showsTab_lbl');

  episodesTab_lbl = this.#getSelectorData('episodesTab_lbl');

  firstThumbnailOnSearch = this.#getSelectorData('firstThumbnailOnSearch');

  searchResultsTabs_lbl = this.#getSelectorData('searchResultsTabs_lbl');

  recommendedForYou_lbl = this.#getSelectorData('recommendedForYou_lbl');

  noResultsLabel_lbl = this.#getSelectorData('noResultsLabel_lbl');

  keyboardDeleteKey = this.#getSelectorData('keyboardDeleteKey');

  focusedKeyboard = this.#getSelectorData('focusedKeyboard');

  keyboardClearKey = this.#getSelectorData('keyboardClearKey');

  firstStandardThumbnail = this.#getSelectorData('firstStandardThumbnail');

  focusedShow_lbl = this.#getSelectorData('focusedShow_lbl');

  episodeTitle = this.#getSelectorData('episodeTitle');

  focusedEpisodeTitle = this.#getSelectorData('focusedEpisodeTitle');

  focusedEpisodeTile = this.#getSelectorData('focusedEpisodeTile');

  removedFromMyList_lbl = this.getElementByPage(
    'browserPage',
    'removedFromMyList_lbl',
  );

  addedToMyList_lbl = this.getElementByPage('homePage', 'addedToMyList_lbl');

  searchResultTabs = {
    Shows: this.#getSelectorData('showsTab_lbl'),
    Sports: this.#getSelectorData('sportsTab_lbl'),
    Episodes: this.#getSelectorData('episodesTab_lbl'),
    Extras: this.#getSelectorData('extrasTab_lbl'),
    Collections: this.#getSelectorData('collectionsTab_lbl'),
    Specials: this.#getSelectorData('specialsTab_lbl'),
    'Ultra HD': this.#getSelectorData('ultraHDTab_lbl'),
  };

  videoPlayerScene = this.getElementByPage(
    'videoPlayerPage',
    'videoPlayerScene',
  );

  eventDetailPage = this.getElementByPage('sportsPage', 'eventDetailPage');

  signUp_btn = this.getElementByPage('subscribeToWatchPage', 'signUp_btn');

  signIn_btn = this.getElementByPage('subscribeToWatchPage', 'signIn_btn');

  upgradeTitle_lbl = this.getElementByPage(
    'subscribeToWatchPage',
    'upgradeTitle_lbl',
  );

  upgradeDesc_lbl = this.getElementByPage(
    'subscribeToWatchPage',
    'upgradeDesc_lbl',
  );

  focusedShowDetailPage = this.getElementByPage(
    'showDetailPage',
    'focusedShowDetailPage',
  );

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  focusedKeyboardSpaceKey = this.#getSelectorData('focusedKeyboardSpaceKey');

  focusedKeyboardCKey = this.#getSelectorData('focusedKeyboardCKey');

  firstShowPriorToSearchUpdate = '';

  searchText = async (text) => {
    searchText = testdataHelper.getContent(`searchPage.${text}`);
    if (this.getKidsUserValue()) {
      if (
        searchText === 'The Last Alaskans' &&
        this.returnGeoLocation() === 'america'
      ) {
        // For roku 'The Last Alaskans' show is not available for kids profile in US region
        searchText = 'The ';
      }
    }
    await commons.sendText(searchText);
    await commons.userAction(VRC.BACK);
  };

  verifyIfSearchResultsLoaded = async () => {
    if (await commons.elementExists(this.showsTab_lbl)) {
      await commons.assertExists(this.showTitle_lbl, 10);
      await commons.assertExists(this.showImage_img);
      await commons.assertExists(this.showNetworkIcon_img);
    } else if (await commons.elementExists(this.episodesTab_lbl)) {
      // if no shows are returned in results then valid episodes returned
      await commons.assertExists(this.episodeTitle);
    }
  };

  verifyResultsIncludeSearchText = async () => {
    const titleValue = await commons.fetchAttributeData(
      this.showTitle_lbl,
      PROP.TEXT_CONTENT,
    );

    if (titleValue.includes(searchText)) return;
    throw new Error(`Search result does not includes '${searchText}'`);
  };

  doesSearchResultsInclude = async (showName, showPresent = true) => {
    let index = 1;
    const resultsTitle = [];
    const searchResult = testdataHelper.getContent(`searchPage.${showName}`);
    let foundInSearchFlag = false;
    let rowCount = 0;
    let showTitlePath = '';

    if (await commons.elementExists(this.showsTab_lbl)) {
      // shows tab present
      rowCount = 4;
      showTitlePath = this.focusedShow_lbl;
      await commons.tryUntil(this.firstThumbnailOnSearch, VRC.RIGHT, 8, 1);
    } else if (await commons.elementExists(this.episodesTab_lbl)) {
      // episodes tab is present
      rowCount = 3;
      showTitlePath = this.focusedEpisodeTitle;
      await commons.tryUntil(this.focusedEpisodeTile, VRC.RIGHT, 8, 1);
    }

    while (index !== 13) {
      const showTitle = await commons.fetchAttributeData(
        showTitlePath,
        PROP.TEXT_CONTENT,
      );

      resultsTitle.push(showTitle);

      const rowPosition = index / rowCount;

      if (Number.isInteger(rowPosition)) {
        // If end of row then move to next row
        await commons.userAction(VRC.LEFT, rowCount - 1, 1);
        await commons.userAction(VRC.DOWN, 1, 1);
      } else {
        // move to next tile
        await commons.userAction(VRC.RIGHT, 1, 1);
      }

      index++;
    }

    for (let i = 0; i < resultsTitle.length; i++) {
      if (resultsTitle[i].includes(searchResult)) {
        foundInSearchFlag = true;
      }
    }
    assert(
      foundInSearchFlag === showPresent,
      `Values not matching: Should be'${showPresent}' but returned '${foundInSearchFlag}'`,
    );
  };

  verifyResultsIncludeSpecificText = async (showName) => {
    await this.doesSearchResultsInclude(showName, true);
  };

  moveToSearchShowTabs = async () => {
    while (!(await commons.elementExists(this.firstThumbnailOnSearch))) {
      await commons.userAction(VRC.RIGHT);
    }
    await commons.userAction(VRC.UP);
    await commons.assertExists(this.showsTab_lbl);
  };

  verifyLandingPageBasedOnContent = async () => {
    await this.moveToSearchShowTabs();
    const searchTabs = testdataHelper.getContent('searchPage.searchResultTabs');

    for (let i = 0; i < searchTabs.length; i++) {
      await commons.waitUntil(this.searchResultTabs[searchTabs[i]]);
      await commons.userAction(VRC.DOWN, 1, 1);
      await commons.assertExists(this.firstThumbnailOnSearch, 60);
      await commons.userAction(VRC.SELECT);
      await this.verifySearchTabsLanding(searchTabs[i], 60);
      await commons.userAction(VRC.BACK, 1, 5);
      await commons.userAction(VRC.UP, 3, 3);

      /* Verify search tabs displayed */
      await commons.assertExists(this.searchResultTabs[searchTabs[i]]);
      await commons.userAction(VRC.RIGHT, 1, 1);
    }
  };

  verifySearchTabsLanding = async (tabName) => {
    switch (tabName) {
      case 'Shows':
        await commons.assertExists(this.focusedShowDetailPage);
        break;
      case 'Sports':
        await this.verifySportsDetailsFromSearch();
        break;
      case 'Episodes':
        await this.verifySubscribeDetailsFromSearch();
        break;
      case 'Extras':
        await this.verifySubscribeDetailsFromSearch();
        break;
      case 'Specials':
        await this.verifySubscribeDetailsFromSearch();
        break;
      case 'Ultra HD':
        await this.verifySubscribeDetailsFromSearch();
        break;
      case 'Collections':
        await commons.assertExists(this.focusedHomePage);
        break;
      default:
        break;
    }
  };

  verifySportsDetailsFromSearch = async () => {
    if (!(await commons.elementExists(this.videoPlayerScene, 20))) {
      await commons.assertExists(this.eventDetailPage);
    }
  };

  verifySubscribeDetailsFromSearch = async () => {
    if (this.getAnonymousUserValue()) {
      const items = [
        this.signUp_btn,
        this.signIn_btn,
        this.upgradeTitle_lbl,
        this.upgradeDesc_lbl,
      ];

      for (let i = 0; i < items.length; i++) {
        await commons.assertExists(items[i], 3);
      }
    } else {
      await commons.waitTillVideoIsPlaying();
      await commons.assertExists(this.videoPlayerScene, 20);
    }
  };

  verifySearchedContentAndItsLandingPage = async () => {
    await this.verifyResultsIncludeSearchText();
    await this.verifyLandingPageBasedOnContent();
  };

  verifyRecommendedForYou = async () => {
    await commons.assertExists(this.recommendedForYou_lbl, 10);
    const recommendForYouTitle = await commons.fetchAttributeData(
      this.recommendedForYou_lbl,
      PROP.TEXT_CONTENT,
    );

    if (recommendForYouTitle.includes('Recommended for You')) return;
    throw new Error(`Search result does not include "Recommended for You"`);
  };

  verifyNoResultFound = async () => {
    await commons.assertExists(this.noResultsLabel_lbl, 10);
    const noResultFoundlbl = await commons.fetchAttributeData(
      this.noResultsLabel_lbl,
      PROP.TEXT_CONTENT,
    );
    const searchResult = `No results found for "${searchText}"`;

    if (noResultFoundlbl.includes(searchResult)) return;
    throw new Error(`Search result does not include '${searchResult}'`);
  };

  addShowsToMylistFromSearch = async () => {
    this.searchText('myListShow1');
    await commons.tryUntil(this.firstThumbnailOnSearch, VRC.RIGHT, 8, 1);
    await commons.userAction(VRC.SETTINGS);
    if (await commons.elementExists(this.removedFromMyList_lbl, 3)) {
      await commons.userAction(VRC.SETTINGS);
    }
    await commons.assertExists(this.addedToMyList_lbl);
  };

  removeShowsFromMylistFromSearch = async () => {
    this.searchText('myListShow1');
    await commons.tryUntil(this.firstThumbnailOnSearch, VRC.RIGHT, 8, 1);
    await commons.userAction(VRC.SETTINGS);
    if (await commons.elementExists(this.addedToMyList_lbl, 3)) {
      await commons.userAction(VRC.SETTINGS);
    }
    await commons.assertExists(this.removedFromMyList_lbl);
  };

  clearSearchTextBox = async () => {
    while (
      (await commons.doesNotExist(this.keyboardClearKey)) &&
      (await commons.doesNotExist(this.keyboardDeleteKey))
    ) {
      await commons.userAction(VRC.DOWN);
    }
    if (await commons.elementExists(this.keyboardDeleteKey)) {
      await commons.userAction(VRC.RIGHT);
    }
    await commons.assertExists(this.keyboardClearKey);
    await commons.userAction(VRC.SELECT);
    if (await commons.elementExists(this.firstStandardThumbnail, 5)) {
      await commons.userAction(VRC.LEFT);
    }
  };

  searchAndAddToMyList = async (showName) => {
    await menuPage.navigateToPage('Search');
    await this.clearSearchTextBox();
    await commons.sendText(showName);
    await commons.tryUntil(this.firstThumbnailOnSearch, VRC.RIGHT, 8, 1);
    await commons.userAction(VRC.SETTINGS);
    if (await commons.elementExists(this.removedFromMyList_lbl, 3)) {
      await commons.userAction(VRC.SETTINGS);
    }
    await commons.assertExists(this.addedToMyList_lbl);
  };

  /*
   * Removing characters from initial search
   */
  removeCharFromSearchText = async (numberOfChar) => {
    // initial search text is Cake Wars
    searchText = await commons.fetchAttributeData(
      this.search_txtBx,
      PROP.TEXT_CONTENT,
    );

    // move to Delete key
    while (
      (await commons.doesNotExist(this.keyboardClearKey)) &&
      (await commons.doesNotExist(this.keyboardDeleteKey))
    ) {
      await commons.userAction(VRC.DOWN);
    }
    if (await commons.elementExists(this.keyboardClearKey)) {
      await commons.userAction(VRC.LEFT);
    }
    await commons.assertExists(this.keyboardDeleteKey);

    let index = 0;

    // select Delete key to remove 'Wars' - searchText.lengh/2
    if (numberOfChar === 'some') {
      index = searchText.length / 2;
    }
    // delete all
    else if (numberOfChar === 'all') {
      index = searchText.length;
    }

    for (let i = 0; i < index; i++) {
      await commons.waitUntil(this.firstThumbnailOnSearch);
      await commons.userAction(VRC.SELECT);
    }
  };

  /*
   * Validating updated search text after removing characters
   */
  verifyUpdatedSearchText = async () => {
    searchText = await commons.fetchAttributeData(
      this.search_txtBx,
      PROP.TEXT_CONTENT,
    );

    // check characters are removed from initial search text - cake wars
    assert.notEqual(
      searchText,
      testdataHelper.getContent(`searchPage.kidsShowName`),
    );
  };

  /*
   * Validating updated search result after removing characters
   */
  verifySearchResultAfterRemoving = async (result) => {
    searchText = await commons.fetchAttributeData(
      this.search_txtBx,
      PROP.TEXT_CONTENT,
    );

    // search text is now Cake
    if (result === 'updatedSearchResults') {
      await this.verifyResultsIncludeSearchText();
    }
    // search text is empty and shows recommended for you
    else if (result === 'recommendationsReappear') {
      await this.verifyRecommendedForYou();
    }
  };

  addToExistingQuery = async () => {
    // Retrieve the original first show name before making search update.
    this.firstShowPriorToSearchUpdate = await commons.fetchAttributeData(
      this.showTitle_lbl,
      PROP.TEXT_CONTENT,
    );

    // We will add a letter 'c' to the original query
    await commons.tryUntil(this.focusedKeyboardSpaceKey, VRC.DOWN, 8, 1);
    await commons.userAction(VRC.SELECT);
    await commons.tryUntil(this.focusedKeyboardCKey, VRC.UP, 8, 1);
    await commons.userAction(VRC.SELECT);

    await commons.waitUntil(this.showTitle_lbl);
  };

  validateUpdatedSearchResult = async () => {
    const titleValue = await commons.fetchAttributeData(
      this.showTitle_lbl,
      PROP.TEXT_CONTENT,
    );

    // We use the first show result to indicate that the results have been updated.
    assert.notEqual(
      titleValue,
      this.firstShowPriorToSearchUpdate,
      'Search query addition did not update search result.',
    );
  };

  verifyResultsDoNotInclude = async (showName) => {
    await this.doesSearchResultsInclude(showName, false);
  };
}

module.exports = new SearchPage();
