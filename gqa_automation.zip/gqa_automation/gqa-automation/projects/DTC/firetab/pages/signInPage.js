const AndroidSignInPage = require('../../android/pages/signInPage');

const { mobileActions } = require('./basePage');

const commons = mobileActions;
const serverURL = process.env.SERVER_URL
  ? process.env.SERVER_URL.toLowerCase()
  : '';
const localExecution = process.env.LOCAL_EXECUTION === 'true' || false;

const { desiredFireTabCapabilities } = require('../capabilities/headspinCaps');

// Example if you want to extend or modify a page for firetab
class SignInPage extends AndroidSignInPage {
  profileName_lbl = this.getElementByPage('profilePage', 'profileName_lbl');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  openApp = async () => {
    commons.driverInit(serverURL, localExecution);
    await commons.openApp(desiredFireTabCapabilities);
    await commons.waitUntil(this.signIn_btn);
  };

  async enterCredentials(credentialType) {
    await AndroidSignInPage.prototype.enterCredentials.call(
      this,
      credentialType,
    );

    let profileName;

    if (credentialType === 'DTC_MYLIST_ENTITLED') {
      profileName = 'Standard';
    } else if (credentialType !== 'DTC_VALID') {
      profileName = 'Default';
    }

    if (profileName) {
      const profile = this.getCustomLocator(this.profileName_lbl, profileName);

      if (await commons.elementExists(profile, 30))
        await commons.click(profile);
    }

    if (credentialType !== 'DTC_LAPSED') {
      await commons.waitUntil(this.focusedHomePage, 75);
    }
  }
}

module.exports = new SignInPage();
