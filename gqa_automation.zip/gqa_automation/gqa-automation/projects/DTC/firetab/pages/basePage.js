const path = require('path');
const { mobileActions } = require('@wbd/gqa-core/support');

const ymlpath = path.resolve(__dirname);

const EnvBase = require('../../../support/env');

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }
}

module.exports = {
  mobileActions,
  BasePage,
};
