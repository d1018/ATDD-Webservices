const signInPage = require('./signInPage');
const AccountPage = require('../../android/pages/accountPage');
const HomePage = require('../../android/pages/homePage');
const SearchPage = require('../../android/pages/searchPage');
const MenuPage = require('../../android/pages/menuPage');
const PreLaunchPage = require('../../android/pages/prelaunchPage');
const ProfilePage = require('../../android/pages/profilePage');
const ShowDetailsPage = require('../../android/pages/showDetailsPage');
const VideoPlayerPage = require('../../android/pages/videoPlayerPage');
const SportsPage = require('../../android/pages/sportsPage');
const NetworkLandingPage = require('../../android/pages/networkLandingPage');
const EventDetailPage = require('../../android/pages/eventDetailPage');
const OnboardingPage = require('../../android/pages/onboardingPage');
const MyListPage = require('../../android/pages/myListPage');
const EpgTVGuidePage = require('../../android/pages/epgTVGuidePage');
const BrowsePage = require('../../android/pages/browsePage');
const WelcomePage = require('../../android/pages/welcomePage');
const UpNextPage = require('../../android/pages/upNextPage');

const accountPage = new AccountPage();
const homePage = new HomePage();
const searchPage = new SearchPage();
const menuPage = new MenuPage();
const preLaunchPage = new PreLaunchPage();
const profilePage = new ProfilePage();
const showDetailsPage = new ShowDetailsPage();
const videoPlayerPage = new VideoPlayerPage();
const sportsPage = new SportsPage();
const networkLandingPage = new NetworkLandingPage();
const eventDetailPage = new EventDetailPage();
const onboardingPage = new OnboardingPage();
const myListPage = new MyListPage();
const epgTVGuidePage = new EpgTVGuidePage();
const browsePage = new BrowsePage();
const welcomePage = new WelcomePage();
const upNextPage = new UpNextPage();

module.exports = {
  accountPage,
  homePage,
  searchPage,
  signInPage,
  menuPage,
  preLaunchPage,
  profilePage,
  showDetailsPage,
  videoPlayerPage,
  sportsPage,
  networkLandingPage,
  eventDetailPage,
  onboardingPage,
  myListPage,
  epgTVGuidePage,
  browsePage,
  welcomePage,
  upNextPage,
};
