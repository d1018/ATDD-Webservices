const { mapGeoLocation } = require('@wbd/gqa-regional-routing/src/maplocation');

const localExecution = process.env.LOCAL_EXECUTION === 'true';
const autoAcceptAlerts = process.env.AUTO_ACCEPT_ALERTS === 'true';
const udid = process.env.UDID;
const geo = process.env.GEO || 'us';
const appPackage =
  process.env.DTC_ANDROID_APP_PACKAGE ||
  'com.discovery.discoveryplus.firemobile';
const appActivity =
  process.env.APP_ACTIVITY ||
  'com.discovery.plus.presentation.activities.LaunchActivity';

const hsFireTabCapabilities = {
  'headspin:capture.video': true,
  'headspin:selector': 'device_skus:"Fire HD Tab"',
  'headspin:newCommandTimeout': 300,
  'headspin:network.regionalRouting': mapGeoLocation(geo, 'headspin'),
};

const fireTabCapabilities = {
  deviceName: 'Fire Tab',
  automationName: 'Appium',
  platformName: 'Android',
  appPackage,
  appActivity,
  udid,
  newCommandTimeout: 300,
  autoAcceptAlerts,
};

const desiredFireTabCapabilities = localExecution
  ? fireTabCapabilities
  : Object.assign(fireTabCapabilities, hsFireTabCapabilities);

module.exports = { desiredFireTabCapabilities };
