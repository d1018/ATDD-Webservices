const { BasePage, browserActions } = require('./basePage');

const commons = browserActions;

const deepLinkUrls = {
  manageAccount: `https://discoveryplus.com/${process.env.GEO}/my-account`,
};

class DeepLinkPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('deepLinkPage', locator);
  }

  manageAccount_txt = this.#getSelectorData('manageAccount_txt');

  backgroundApp = async () => {};

  verifyAppOpened = async () => {};

  deepLinkTo = async (linkType) => {
    if (deepLinkUrls[linkType] !== undefined) {
      await commons.deepLinkTo(deepLinkUrls[linkType]);
    }
  };

  verifyAccountScreen = async () => {
    await commons.waitUntil(this.manageAccount_txt, 10);
  };
}

module.exports = new DeepLinkPage();
