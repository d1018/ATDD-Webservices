const accountPage = require('./accountPage');
const homePage = require('./homePage');
const searchPage = require('./searchPage');
const signInPage = require('./signInPage');
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');
const showDetailsPage = require('./showDetailsPage');
const videoPlayerPage = require('./videoPlayerPage');
const sportsPage = require('./sportsPage');
const onboardingPage = require('./onboardingPage');
const networkLandingPage = require('./networkLandingPage');
const upNextPage = require('./upNextPage');
const myListPage = require('./myListPage');
const browsePage = require('./browsePage');
const deepLinkPage = require('./deepLinkPage');
const welcomePage = require('./welcomePage');
const adTechPage = require('./adTechPage');

module.exports = {
  accountPage,
  homePage,
  menuPage,
  searchPage,
  signInPage,
  profilePage,
  showDetailsPage,
  videoPlayerPage,
  sportsPage,
  onboardingPage,
  networkLandingPage,
  upNextPage,
  myListPage,
  browsePage,
  deepLinkPage,
  welcomePage,
  adTechPage,
};
