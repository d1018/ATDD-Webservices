const { BasePage, browserActions, testdataHelper } = require('./basePage');

const showDetailsPage = require('./showDetailsPage');
const videoPlayerPage = require('./videoPlayerPage');
const sportsPage = require('./sportsPage');
const homePage = require('./homePage');

const commons = browserActions;

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  search_txtBx = this.#getSelectorData('search_txtBx');

  showTitle_lbl = this.#getSelectorData('showTitle_lbl');

  showImage_img = this.#getSelectorData('showImage_img');

  showNetworkIcon_img = this.#getSelectorData('showNetworkIcon_img');

  searchResultContent = this.#getSelectorData('searchResultContent');

  resultsTab = this.#getSelectorData('resultsTab');

  noResultsBanner = this.#getSelectorData('noResultsBanner');

  recommendedForYouBanner = this.#getSelectorData('recommendedForYouBanner');

  recommendedForYouContent = this.#getSelectorData('recommendedForYouContent');

  visibleresultCardContent = this.#getSelectorData('visibleresultCardContent');

  myListplusIcon = this.#getSelectorData('myListplusIcon');

  myListTickIcon = this.#getSelectorData('myListTickIcon');

  myListCrossIcon = this.#getSelectorData('myListCrossIcon');

  clearSearch = this.#getSelectorData('clearSearch_Btn');

  episodeTab = this.#getSelectorData('showEpisodesTab');

  contentSearchText = '';

  searchText = async (text) => {
    this.contentSearchText = testdataHelper.getContent(`searchPage.${text}`);
    await commons.waitUntil(this.search_txtBx, 20);
    await commons.click(this.search_txtBx);
    await commons.sendText(this.search_txtBx, this.contentSearchText);
  };

  verifyIfSearchResultsLoaded = async () => {
    await commons.pageDown();
    await commons.pageUp();
    await commons.assertEnable(this.showTitle_lbl, true);
    await commons.arrowDown();
    await commons.arrowDown();
  };

  verifyResultsIncludeSearchText = async () => {
    const showTitle = await commons.getText(this.showTitle_lbl);

    if (!showTitle.includes(this.contentSearchText))
      throw new Error(
        `Search result does not includes '${this.contentSearchText}'`,
      );
  };

  verifyResultsIncludeSpecificText = async (showName) => {
    const showTitle = await commons.getText(this.showTitle_lbl);
    const searchResult = testdataHelper.getContent(`searchPage.${showName}`);

    if (!showTitle.includes(searchResult))
      throw new Error(
        `Search result '${showTitle}' does not include '${searchResult}'`,
      );
  };

  verifyNoResultFound = async () => {
    await commons.waitUntil(this.noResultsBanner);
  };

  verifyRecommendedForYou = async () => {
    await commons.waitUntil(this.recommendedForYouBanner);
  };

  /* clicking on each tab and verifying the landing page */
  verifySearchedContentAndItsLandingPage = async () => {
    await commons.waitUntil(this.searchResultContent, 30);
    let tabSize = await commons.findElements(this.resultsTab);

    const tabText = [];

    for (let i = 0; i < tabSize.length; i++) {
      tabText[i] = await commons.getText(tabSize[i]);
    }

    for (let i = 0; i < tabSize.length; i++) {
      await commons.click(tabSize[i]);
      await commons.click(this.visibleresultCardContent);
      await this.verifySearchTabsLanding(tabText[i]);
      await commons.clickBack();
      tabSize = await commons.findElements(this.resultsTab);
    }
  };

  /* verifying the landing page */
  verifySearchTabsLanding = async (tabName) => {
    switch (tabName) {
      case 'Shows':
        await showDetailsPage.verifyShowLandingPage();
        break;
      case 'Sports':
        await sportsPage.verifySportLandingPage();
        break;
      case 'Episodes':
        await videoPlayerPage.verifyVideoPlayerPage();
        break;
      case 'Extras':
        await videoPlayerPage.verifyVideoPlayerPage();
        break;
      default:
        break;
    }
  };

  selectFirstRecommendedForYou = async () => {
    await commons.click(this.recommendedForYouContent);
  };

  verifyLandedOnSeriesDetail = async () => {
    await showDetailsPage.verifyShowLandingPage();
  };

  clearSearchBox = async () => {
    await commons.click(this.clearSearch);
  };

  verifyEmptySearchBox = async () => {
    const searchBoxContent = await commons.getAttribute(
      this.search_txtBx,
      'value',
    );

    if (searchBoxContent) throw new Error('Search box did not clear');
  };

  verifyResultsDoNotInclude = async (showName) => {
    const showTitle = await commons.getText(this.showTitle_lbl);
    const searchResult = testdataHelper.getContent(`searchPage.${showName}`);

    if (showTitle.includes(searchResult))
      throw new Error(
        `Search result '${showTitle}' shows age restricted content '${searchResult}'`,
      );
  };

  navigateToEpisodeTab = async () => {
    await commons.waitUntil(this.episodeTab, 15);
    await commons.click(this.episodeTab, 15);
    await commons.assertDisplay(this.episodeTab, true, 10);
  };

  addShowsToMylistFromSearch = async () => {
    await this.searchText('myListShow1');
    await homePage.addToMyList();
  };

  removeShowsFromMylistFromSearch = async () => {
    await this.searchText('myListShow1');
    await homePage.removeFromMyList('myListShow1');
  };
}

module.exports = new SearchPage();
