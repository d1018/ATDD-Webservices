const path = require('path');
const {
  browserActions,
  customErrors,
  testdataHelper,
} = require('@wbd/gqa-core/support');

const ymlpath = path.resolve(__dirname);

const EnvBase = require('../../../support/env');

const { skipReason } = require('../../../support/skipReason');

const analyticsValidationHelper = require('../../../support/adtechSupport/analyticsValidationHelper');

let episodeNameText;

let showNameText;

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }

  returnRandomNumber = (len) => {
    const randomNumber = Math.floor(Math.random() * len);

    return `${randomNumber}`;
  };

  getShowNameText() {
    return showNameText;
  }

  setShowNameText(showName) {
    showNameText = showName;
  }

  getEpisodeNameText() {
    return episodeNameText;
  }

  setEpisodeNameText(episodeName) {
    episodeNameText = episodeName;
  }
}

module.exports = {
  browserActions,
  testdataHelper,
  customErrors,
  skipReason,
  BasePage,
  analyticsValidationHelper,
};
