const assert = require('assert');

const { BasePage, browserActions } = require('./basePage');

const commons = browserActions;
const homePage = require('./homePage');
const videoPlayerPage = require('./videoPlayerPage');
const menuPage = require('./menuPage');

class NetworkLandingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('networkLandingPage', locator);
  }

  network_rail = this.getElementByPage('homePage', 'network_rail');

  bottomPageNetworkRail = this.#getSelectorData('bottom_network_rail');

  network_img = this.#getSelectorData('network_img');

  network_logo = this.#getSelectorData('network_logo');

  showRail_lbl = this.#getSelectorData('showRail_lbl');

  episodeRail_lbl = this.#getSelectorData('episodeRail_lbl');

  nextArrow_btn = this.#getSelectorData('nextArrow_btn');

  euroSports1Network_txt = this.#getSelectorData('euroSports1Network_txt');

  liveRail_lbl = this.#getSelectorData('liveRail_lbl');

  liveRail = this.#getSelectorData('liveRail');

  upcomingRail = this.#getSelectorData('upcomingRail');

  featuredRail = this.#getSelectorData('featuredRail');

  signUp_btn = this.#getSelectorData('signUp_btn');

  tlcEntertainmentNetwork_txt = this.#getSelectorData(
    'tlcEntertainmentNetwork_txt',
  );

  watchNow_btn = this.#getSelectorData('watchNow_btn');

  featuredRailContentRating = this.#getSelectorData(
    'featuredRailContentRating',
  );

  featuredRailCards = this.#getSelectorData('featuredRailCards');

  entertainmentNetworkLandingPage = [
    this.showRail_lbl,
    this.episodeRail_lbl,
    this.network_img,
  ];

  selectAndValidateNetworkLandingPage = async (network) => {
    if (network === 'Entertainment') {
      await this.validateEntertainmentNetworkLandingPage();
    } else if (network === 'Sports' && this.returnGeoLocation() !== 'america') {
      await commons.clickBack();
      await homePage.scrollToNetworkRail();
      await this.validateSportsNetworkLandingPage();
    }
  };

  selectNetworkLogo = async () => {
    const networkList = await commons.findElements(this.network_img);

    await commons.click(networkList[3]);
    await commons.waitUntil(this.network_logo, 20);
  };

  validateEntertainmentSimulcastNetworkLandingPage = async () => {
    if (await commons.isDisplayed(this.tlcEntertainmentNetwork_txt, 10)) {
      await commons.click(this.tlcEntertainmentNetwork_txt);
    } else {
      while (
        !(await commons.isDisplayed(this.tlcEntertainmentNetwork_txt, 10))
      ) {
        await commons.hover(this.network_rail);
        await commons.click(this.nextArrow_btn);
        if (await commons.isDisplayed(this.tlcEntertainmentNetwork_txt, 10)) {
          await commons.click(this.tlcEntertainmentNetwork_txt);
          break;
        }
      }
    }
  };

  verifySimulcastPlaybackOnNetworkPage = async (userType, network) => {
    if (network === 'Entertainment') {
      await this.validateEntertainmentSimulcastNetworkLandingPage();
    } else if (network === 'Sports') {
      await commons.clickBack();
      await menuPage.navigateToPage('Home');
      await homePage.scrollToNetworkRail();
      await this.validateSportsNetworkLandingPage();
    }
    await this.validateSimulcastPlaybackOnNetworkPage(userType);
  };

  validateSimulcastPlaybackOnNetworkPage = async (userType) => {
    if (userType === 'anonymous') {
      await commons.waitUntil(this.signUp_btn);
    } else {
      await commons.waitUntil(this.watchNow_btn);
      await commons.click(this.watchNow_btn);
      await commons.isDisplayed(videoPlayerPage.videoContainer);
    }
  };

  validateEntertainmentNetworkLandingPage = async () => {
    const networkList = await commons.findElements(this.network_img);

    await commons.click(networkList[3]);
    await commons.waitUntil(this.network_logo, 20);
    for (let i = 0; i < this.entertainmentNetworkLandingPage.length; i++) {
      await commons.scrollToElement(
        this.entertainmentNetworkLandingPage[i],
        10,
      );
      await commons.waitUntil(this.entertainmentNetworkLandingPage[i]);
    }
  };

  validateSportsNetworkLandingPage = async () => {
    if (this.euroSports1Network_txt) {
      await commons.click(this.euroSports1Network_txt);
    } else {
      while (!(await commons.isDisplayed(this.euroSports1Network_txt, 10))) {
        await commons.hover(this.network_rail);
        await commons.click(this.nextArrow_btn);
        if (this.euroSports1Network_txt) {
          await commons.click(this.euroSports1Network_txt);
          break;
        }
      }
    }
    await commons.waitUntil(this.network_logo);
    if (await commons.isDisplayed(this.liveRail_lbl, 10)) {
      await commons.waitUntil(this.liveRail);
    }
    await commons.scrollToElement(this.upcomingRail, 5);
    await commons.waitUntil(this.upcomingRail);
  };

  verifyNetworkRailForKidsProfile = async () => {
    const geoLocation = process.env.GEO.toLowerCase();

    if (geoLocation === ('gb' || 'ie' || 'de')) {
      assert(
        !(await this.isNetworkRailDisplayed()),
        `A network rail is not shown for the kids user`,
      );
    } else if (geoLocation === ('us' || 'it' || 'br')) {
      assert(
        await this.isNetworkRailDisplayed(),
        `A network rail is shown for the kids user`,
      );
    }
  };

  isNetworkRailDisplayed = async () => {
    await commons.arrowDown();
    await commons.arrowDown();
    const result = await commons.isDisplayed(this.network_img);

    return result;
  };

  scrollToNetworkRailAndSelectNetwork = async () => {
    await commons.scrollIntoView(
      JSON.stringify(this.bottomPageNetworkRail).split('"')[3],
    );

    const networkList = await commons.findElements(this.network_img);

    await commons.click(networkList[5]);
    await commons.waitUntil(this.network_logo, 20);
  };

  validateNetworkPage = async () => {
    await commons.waitUntil(this.network_logo, 20);
    for (let i = 0; i < this.entertainmentNetworkLandingPage.length; i++) {
      await commons.scrollToElement(
        this.entertainmentNetworkLandingPage[i],
        10,
      );
      await commons.waitUntil(this.entertainmentNetworkLandingPage[i]);
    }
  };
}

module.exports = new NetworkLandingPage();
