const { BasePage, browserActions } = require('./basePage');

const commons = browserActions;

class SportsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('sportsPage', locator);
  }

  eventDetails = this.#getSelectorData('eventDetails');

  upcomingRail_lbl = this.#getSelectorData('upcomingRail_lbl');

  episodeOnUpcomingRail_lbl = this.#getSelectorData(
    'episodeOnUpcomingRail_lbl',
  );

  /* verifying the sport landing page */
  verifySportLandingPage = async () => {
    await commons.waitUntil(this.eventDetails, 30);
  };

  verifySportsDetailsPage = async () => {
    const pageCurrentURL = await commons.getCurrentUrl();

    if (!pageCurrentURL.includes('/sport/'))
      throw new Error(`Not redirected to sports page`);
  };
}

module.exports = new SportsPage();
