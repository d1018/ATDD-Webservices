const { SkipError } = require('@wbd/gqa-core/support/customErrors');
const assert = require('assert');

const { BasePage, skipReason, browserActions } = require('./basePage');

const commons = browserActions;
const menuPage = require('./menuPage');

let newProfileName = '';
let editedProfileimage = '';
let editedProfileName = '';
let selectedRating = '';
let profileCountBeforeDeletion = 0;
let pinInputsCount = 0;
let deletedProfile = '';

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  defaultProfile = this.getElementByPage('signInPage', 'defaultProfile');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  defaultProfile_txt = this.#getSelectorData('defaultProfile_txt');

  kidsProfile_txt = this.#getSelectorData('kidsProfile_txt');

  userMenu_dropdown = this.getElementByPage('menuPage', 'userMenu_dropdown');

  anonymous_navBar = this.#getSelectorData('anonymous_navBar');

  profilePickerContainer = this.getElementByPage(
    'signInPage',
    'profilePickerContainer',
  );

  manageProfiles_btn = this.#getSelectorData('manageProfiles_btn');

  addProfile_btn = this.#getSelectorData('addProfile_btn');

  manageMode = this.#getSelectorData('manageMode');

  kidsProfileToggle_btn = this.#getSelectorData('kidsProfileToggle_btn');

  createProfileName_txtBx = this.#getSelectorData('createProfileName_txtBx');

  save_btn = this.#getSelectorData('save_btn');

  done_btn = this.#getSelectorData('done_btn');

  createPin_btn = this.#getSelectorData('createPin_btn');

  managePin_btn = this.#getSelectorData('managePin_btn');

  removePin_btn = this.#getSelectorData('removePin_btn');

  removePin1_btn = this.#getSelectorData('removePin1_btn');

  pinPassword_txtBx = this.#getSelectorData('pinPassword_txtBx');

  continue_btn = this.#getSelectorData('continue_btn');

  standardProfile_txt = this.#getSelectorData('standardProfile_txt');

  deleteProfile_btn = this.#getSelectorData('deleteProfile_btn');

  deleteProfilePopup_btn = this.#getSelectorData('deleteProfilePopup_btn');

  contentRatingBadge = this.#getSelectorData('contentRatingBadge');

  listOfAllProfiles = this.#getSelectorData('listOfAllProfiles');

  pinProfile_txt = this.#getSelectorData('pinProfile_txt');

  profileIconsView_img = this.#getSelectorData('profileIconsView_img');

  pinField = this.#getSelectorData('pinField');

  pinInputs = this.#getSelectorData('pinInputs');

  editIcon = this.#getSelectorData('editIcon');

  editCreatedProfile_icon = this.#getSelectorData('editCreatedProfile_icon');

  createdProfileImage = this.#getSelectorData('createdProfileImage');

  selectCreatedProfile_txt = this.#getSelectorData('selectCreatedProfile_txt');

  deleteProfileModal_title = this.#getSelectorData('deleteProfileModal_title');

  avatarImage = this.#getSelectorData('avatarImage');

  avatarImageList = this.#getSelectorData('avatarImageList');

  deleteProfileDescription = this.#getSelectorData('deleteProfileDescription');

  deleteProfileConfirmation = this.#getSelectorData(
    'deleteProfileConfirmation',
  );

  keepProfile_btn = this.#getSelectorData('keepProfile_btn');

  discoveryLogo = this.#getSelectorData('discoveryLogo');

  surveyPopup = this.#getSelectorData('surveyPopup');

  noSurvery_btn = this.#getSelectorData('noSurvery_btn');

  changeRating_btn = this.#getSelectorData('changeRating_btn');

  contentRating_title = this.#getSelectorData('contentRating_title');

  contentRatingRadio_btn = this.#getSelectorData('contentRatingRadio_btn');

  contentRatingDescription = this.#getSelectorData('contentRatingDescription');

  cancel_btn = this.#getSelectorData('cancel_btn');

  save1_btn = this.#getSelectorData('save1_btn');

  close_btn = this.#getSelectorData('close_btn');

  ratingLabel = this.#getSelectorData('ratingLabel');

  selectedContentRating = this.#getSelectorData('selectedContentRating');

  contentRatingList = this.#getSelectorData('contentRatingList');

  notificationErrorMessage_lbl = this.#getSelectorData(
    'notificationErrorMessage_lbl',
  );

  saveChanges_btn = this.#getSelectorData('saveChanges_btn');

  profileNameErr_txt = this.#getSelectorData('profileNameErr_txt');

  editProfile_txt = this.#getSelectorData('editProfile_txt');

  clearProfileName_btn = this.#getSelectorData('clearProfileName_btn');

  allProfilesExceptDefault_txt = this.#getSelectorData(
    'allProfilesExceptDefault_txt',
  );

  dynamicProfileName_lbl = this.#getSelectorData('dynamicProfileName_lbl');

  cancelProfile_btn = this.#getSelectorData('cancelProfile_btn');

  chevronDropdown_lbl = this.#getSelectorData('chevronDropdown_lbl');

  selectCreatedChevronProfile_txt = this.#getSelectorData(
    'selectCreatedChevronProfile_txt',
  );

  chevronDefaultProfile_txt = this.#getSelectorData(
    'chevronDefaultProfile_txt',
  );

  profilesList = {
    Default: this.#getSelectorData('defaultProfile_txt'),
    Kids: this.#getSelectorData('kidsProfile_txt'),
    Standard: this.#getSelectorData('standardProfile_txt'),
    Pin: this.#getSelectorData('pinProfile_txt'),
    AutoWatchNow: this.#getSelectorData('autoWatchNow_txt'),
  };

  surveyPopupHandler = async () => {
    if (await commons.isDisplayed(this.surveyPopup))
      await commons.refreshPage();
  };

  selectDefaultProfile = async () => {
    await commons.waitUntil(this.profilePickerContainer, 10);
    if (await commons.isDisplayed(this.defaultProfile)) {
      await commons.click(this.defaultProfile);
    } else {
      await commons.click(this.chevronDropdown_lbl);
      await commons.click(this.chevronDefaultProfile_txt);
    }
    try {
      await commons.waitUntil(this.focusedHomePage, 10);
    } catch (error) {
      await commons.refreshPage();
      await commons.waitUntil(this.focusedHomePage, 30);
    }
  };

  selectProfile = async (profileType) => {
    if (!profileType.includes('Anonymous')) {
      if (!(await commons.isDisplayed(this.profilePickerContainer))) {
        await this.navigateToManageProfiles();
      }
      if (await commons.isDisplayed(this.done_btn, 10)) {
        await commons.click(this.done_btn);
      }
      if (
        profileType.includes('Default') ||
        profileType.includes('Empty MyList')
      ) {
        await this.selectDefaultProfile();
      } else if (profileType.includes('Kids')) {
        await commons.waitUntil(this.kidsProfile_txt, 10);
        await commons.click(this.kidsProfile_txt);
      } else if (profileType === 'Standard') {
        await commons.waitUntil(this.standardProfile_txt, 10);
        await commons.click(this.standardProfile_txt);
      } else {
        const selectCreatedProfile = await commons.findElement(
          this.getCustomLocator(this.selectCreatedProfile_txt, newProfileName),
        );

        if (await commons.isDisplayed(selectCreatedProfile, 15)) {
          await commons.click(selectCreatedProfile);
        } else {
          await commons.click(this.chevronDropdown_lbl);
          const selectCreatedChevronProfile = await commons.findElement(
            this.getCustomLocator(
              this.selectCreatedChevronProfile_txt,
              newProfileName,
            ),
          );

          await commons.click(selectCreatedChevronProfile);
        }
        if (profileType.includes('Pin')) {
          await commons.waitUntil(this.pinInputs, 10);
          const pinElements = await commons.findElements(this.pinInputs, 30);

          for (let i = 0; i < pinInputsCount; i++) {
            await commons.sendText(pinElements[i], i);
          }
        }
      }
      await commons.waitUntil(this.focusedHomePage, 10);
    }
  };

  verifyAddProfile = async () => {
    const isAddProfileDisplayed = await commons.isDisplayed(
      this.addProfile_btn,
    );

    return isAddProfileDisplayed;
  };

  /**
   * Below function is used to create a new profile and calls createnewprofile function
   *
   * @param {string} profileType as Standard, Kids, Pin
   */
  profileCreation = async (profileType) => {
    await this.createNewProfile(profileType);
    await this.selectProfile(newProfileName);
  };

  /**
   * Below function is used to create a new profile and it works in following way:
   * 1) Post login, it opens manage profiles screen and checks if Add profile option is available
   * 2) If Add profile is displayed, it adds a new profile prefixing with Standard, Kids
   * 3) If Add profile is not displayed, then it deletes any random profile and creates new profile
   *
   * @param {string} profileType as Standard, Kids
   */
  createNewProfile = async (profileType) => {
    if (!(await commons.isDisplayed(this.manageMode, 10))) {
      await this.navigateToManageProfiles();
    }
    const isAddProfileDisplayed = await this.verifyAddProfile();
    // get timestamp (in millseconds)

    newProfileName = profileType + Math.floor(Date.now() / 1000);
    if (!isAddProfileDisplayed) {
      await this.deleteProfile('anyprofile');
      await commons.click(this.done_btn, 20);
      await commons.waitUntil(this.manageProfiles_btn, 30);
    }
    await this.surveyPopupHandler();
    await commons.refreshPage();
    await commons.waitUntil(this.addProfile_btn);
    await commons.click(this.addProfile_btn);
    if (profileType.includes('Kids')) {
      await commons.isDisplayed(this.kidsProfileToggle_btn, 10);
      await commons.click(this.kidsProfileToggle_btn);
      await commons.waitUntil(this.contentRatingBadge, 10);
    }
    await commons.sendText(this.createProfileName_txtBx, newProfileName);
    await commons.click(this.save_btn);

    if (profileType.includes('Pin')) {
      const selectCreatedProfile = await commons.findElement(
        this.getCustomLocator(this.selectCreatedProfile_txt, newProfileName),
      );

      await commons.click(selectCreatedProfile);
      await commons.waitUntil(this.createPin_btn, 10);
      await commons.click(this.createPin_btn);
      await commons.waitUntil(this.pinPassword_txtBx, 10);
      await commons.sendText(
        this.pinPassword_txtBx,
        process.env.DTC_PIN_PROFILE_PASSWORD,
      );
      await commons.click(this.continue_btn);
      await commons.waitUntil(this.pinField, 30);
      const elements = await commons.findElements(this.pinInputs, 30);

      pinInputsCount = await elements.length;
      for (let i = 0; i < pinInputsCount; i++) {
        await commons.sendText(elements[i], i);
      }
      await commons.click(this.save_btn);
      await commons.waitUntil(this.saveChanges_btn);
      try {
        await commons.click(this.saveChanges_btn);
      } catch (error) {
        if (await commons.isDisplayed(this.notificationErrorMessage_lbl)) {
          await commons.refreshPage();
          await commons.waitUntil(this.saveChanges_btn, 30);
        }
        await commons.click(this.saveChanges_btn);
      }
      await commons.waitUntil(this.done_btn, 10);
    }
    await commons.click(this.done_btn);
    if (await commons.isDisplayed(this.done_btn, 10)) {
      await commons.click(this.done_btn);
    }
  };

  getListOfProfiles = async () => {
    let individualProfileName;
    const profileNames = [];
    let elements = await commons.findElements(this.listOfAllProfiles, 10);

    profileCountBeforeDeletion = await elements.length;
    for (let i = 0; i < profileCountBeforeDeletion; i++) {
      elements = await commons.findElements(this.listOfAllProfiles, 10);

      individualProfileName = await commons.getText(elements[i]);
      let oldProfile = true;

      // Split the individualProfileName and then compare the timestamp.
      // if <4 minutes, then do not delete that profile, else mark that profile as old profile.
      if (!individualProfileName.includes('Default')) {
        const existingProfileRandomTime =
          individualProfileName.match(/[a-z]+|\d+/gi);

        if (existingProfileRandomTime.length > 1) {
          if (
            Math.round(
              Math.abs(
                Date.now() / 1000 -
                  existingProfileRandomTime[
                    existingProfileRandomTime.length - 1
                  ],
              ) / 60,
            ) <= 4
          ) {
            oldProfile = false;
          }
        }
      }

      if (!individualProfileName.includes('Default') && oldProfile) {
        profileNames.push(individualProfileName);
      }
      // For Oldprofile == false, we need to delete the newly created profile each time. Hence we need below condition
      if (individualProfileName === newProfileName) {
        profileNames.push(individualProfileName);
      }
    }
    return profileNames;
  };

  /**
   * Post login, the below function clicks on Account menu and waits till manage profiles button is visible
   */
  navigateToManageProfiles = async () => {
    if (await commons.isDisplayed(this.userMenu_dropdown)) {
      await commons.click(this.userMenu_dropdown);
      await menuPage.navigateToPage('Manage Profile');
      await commons.waitUntil(this.manageMode, 30);
      await this.surveyPopupHandler();
    }
  };

  deleteExistingProfile = async () => {
    await this.deleteProfile(newProfileName);
  };

  /**
   *This delete profile function will -
   1) Delete existing profile that starts with Standard, Kids and if not found, any profile, except default will be deleted.
   2) Fetch count of all profiles
   3) If in Kids profile, it will switch to Default and then deletes created kids profile
   *
   * @param {string} profileName as Automation
   */
  deleteProfile = async (profileName) => {
    if (profileName === 'random') {
      await this.createNewProfile(profileName);
    }
    let profileNames = [];

    if (!(await commons.isDisplayed(this.manageMode)))
      await this.navigateToManageProfiles();
    if (await profileName.includes('Kids')) {
      await this.selectDefaultProfile();
      await this.navigateToManageProfiles();
    }
    if (await commons.isDisplayed(this.manageProfiles_btn, 30))
      await commons.click(this.manageProfiles_btn);
    profileNames = await this.getListOfProfiles();
    const arraySize = profileNames.length;

    if (arraySize === 0) {
      throw new SkipError(skipReason.noProfilesAvailableToDelete);
    }
    let requiredProfileName;

    if (profileNames.includes(profileName)) {
      requiredProfileName = this.getCustomLocator(
        this.dynamicProfileName_lbl,
        profileName,
      );
      await commons.waitUntil(requiredProfileName, 5);
      deletedProfile = requiredProfileName;
      await commons.click(requiredProfileName);
      await commons.click(this.deleteProfile_btn);
      await commons.waitUntil(this.deleteProfilePopup_btn, 5);
      await commons.click(this.deleteProfilePopup_btn);
      if (await commons.isDisplayed(this.profileError_lbl, 10)) {
        await commons.click(this.cancelProfile_btn);
        await commons.clickBack();
        await commons.clickBack();
      }
    } else {
      for (let i = 0; i < arraySize; i++) {
        if (typeof profileNames[0] !== 'undefined') {
          requiredProfileName = this.getCustomLocator(
            this.dynamicProfileName_lbl,
            profileNames[0],
          );

          await commons.waitUntil(requiredProfileName, 5);
          deletedProfile = requiredProfileName;
          await commons.click(requiredProfileName);
          await commons.click(this.deleteProfile_btn);
          await commons.waitUntil(this.deleteProfilePopup_btn, 5);
          await commons.click(this.deleteProfilePopup_btn);
          if (await commons.isDisplayed(this.profileError_lbl, 10)) {
            await commons.click(this.cancelProfile_btn);
            await commons.clickBack();
            await commons.clickBack();
          }

          if (await commons.isDisplayed(this.manageProfiles_btn, 5)) {
            await commons.click(this.manageProfiles_btn, 5);
          }

          await commons.refreshPage();
          profileNames = await this.getListOfProfiles();
          if (await commons.isDisplayed(this.profileError_lbl, 10)) {
            await commons.click(this.cancelProfile_btn);
            await commons.clickBack();
            await commons.clickBack();
          }
        }
      }
    }
  };

  /**
   * The profile count fetched from above function will be used here as comparision pre & post delete to ensure deletion is successful
   */
  verifyUserProfileDeleted = async () => {
    if (!(await commons.isDisplayed(this.manageMode)))
      await this.navigateToManageProfiles();
    await commons.waitUntil(this.listOfAllProfiles);
    assert(
      !(await commons.isDisplayed(deletedProfile)),
      `Delete profile is not successful`,
    );
  };

  checkProfileIfExists = async (profileName) => {
    await this.navigateToManageProfiles();
    if (await commons.isDisplayed(this.profilesList[profileName])) return true;
    await commons.clickAndRelease(this.profileIconsView_img);
    return commons.isDisplayed(this.profilesList[profileName]);
  };

  moveToEditPage = async (profileName) => {
    if (await commons.isDisplayed(this.manageProfiles_btn))
      await commons.click(this.manageProfiles_btn);
    const editCreatedProfileBtn = await commons.findElement(
      this.getCustomLocator(this.editCreatedProfile_icon, profileName),
    );

    await commons.click(editCreatedProfileBtn);
  };

  createNewProfileAndMoveToEdit = async (profileType) => {
    await this.createNewProfile(profileType);
    await this.moveToEditPage(newProfileName);
  };

  removePin = async () => {
    if (!(await commons.isDisplayed(this.manageMode)))
      await this.navigateToManageProfiles();
    if (await commons.isDisplayed(this.manageProfiles_btn))
      await commons.click(this.manageProfiles_btn);
    const editCreatedProfileBtn = await commons.findElement(
      this.getCustomLocator(this.editCreatedProfile_icon, newProfileName),
    );

    await commons.click(editCreatedProfileBtn);
    await commons.waitUntil(this.managePin_btn, 10);
    await commons.click(this.managePin_btn);
    await commons.waitUntil(this.pinPassword_txtBx, 10);
    await commons.sendText(
      this.pinPassword_txtBx,
      process.env.DTC_PIN_PROFILE_PASSWORD,
    );
    await commons.click(this.continue_btn);
    await commons.waitUntil(this.removePin_btn, 30);
    await commons.click(this.removePin_btn);
    await commons.waitUntil(this.removePin1_btn, 30);
    await commons.click(this.removePin1_btn);
  };

  verifyPinDeleted = async () => {
    await commons.assertDisplay(this.createPin_btn, true);
    await commons.waitUntil(this.save_btn, 30);
    await commons.click(this.save_btn);
  };

  moveToDeleteProfilePage = async () => {
    if (!(await commons.isDisplayed(this.manageMode)))
      await this.navigateToManageProfiles();
    await commons.waitUntil(this.manageMode, 30);
    await this.moveToEditPage(newProfileName);
    await commons.waitUntil(this.deleteProfile_btn, 10);
    await commons.click(this.deleteProfile_btn);
  };

  verifyDeleteProfileMetadata = async () => {
    const fails = [];

    if (!(await commons.isEnabled(this.deleteProfileModal_title)))
      fails.push('Delete profile title is not displayed');
    if (!(await commons.isEnabled(this.avatarImage)))
      fails.push('Avatar image is not displayed');
    if (!(await commons.isEnabled(this.deleteProfileDescription)))
      fails.push('Delete profile description is not displayed');
    if (!(await commons.isEnabled(this.deleteProfileConfirmation)))
      fails.push('Delete profile confirmation is not displayed');
    if (!(await commons.isEnabled(this.keepProfile_btn)))
      fails.push('Keep profile button is not displayed');
    if (!(await commons.isEnabled(this.deleteProfile_btn)))
      fails.push('Delete profile button is not displayed');

    assert.equal(fails.length === 0, true, fails);
    await commons.waitUntil(this.deleteProfilePopup_btn, 10);
    await commons.click(this.deleteProfilePopup_btn);
    await commons.isDisplayed(this.profilePickerContainer);
  };

  verifyEditProfileMetadata = async () => {
    const fails = [];

    if (!(await commons.isEnabled(this.discoveryLogo)))
      fails.push('Discovery Logo is not displayed');
    if (!(await commons.isEnabled(this.avatarImage)))
      fails.push('Avatar image is not displayed');
    if (!(await commons.isEnabled(this.createProfileName_txtBx)))
      fails.push('Create profile textbox is not displayed');
    if (!(await commons.isEnabled(this.createPin_btn)))
      fails.push('Create profile button is not displayed');
    if (!(await commons.isEnabled(this.save_btn)))
      fails.push('Save profile button is not displayed');
    if (!(await commons.isEnabled(this.deleteProfile_btn)))
      fails.push('Delete profile button is not displayed');

    assert.equal(fails.length === 0, true, fails);
    await commons.waitUntil(this.save_btn, 10);
    await commons.click(this.save_btn);
    await commons.isDisplayed(this.done_btn);
  };

  editUserProfile = async () => {
    editedProfileName = `${newProfileName}edit`;
    await commons.sendText(this.createProfileName_txtBx, editedProfileName);
    await commons.click(this.avatarImage);
    const avatarImageList = await commons.findElements(this.avatarImageList);

    await commons.waitUntil(avatarImageList[2], 10);
    editedProfileimage = await commons.getAttribute(
      avatarImageList[2],
      'title',
    );
    await commons.click(avatarImageList[2]);
    await commons.waitUntil(this.save_btn, 10);
    await commons.click(this.save_btn);
  };

  verifyEditedProfile = async () => {
    const updatedProfileName = await commons.findElement(
      this.getCustomLocator(this.editCreatedProfile_icon, editedProfileName),
    );

    const updatedProfileImage = await commons.findElement(
      this.getCustomLocator(this.createdProfileImage, editedProfileName),
    );

    const fails = [];

    if (!(await commons.isDisplayed(updatedProfileName)))
      fails.push('profile name is not editted');
    if (
      editedProfileimage !==
      (await commons.getAttribute(updatedProfileImage, 'title'))
    )
      fails.push('Avatar image is not updated');

    assert.equal(fails.length === 0, true, fails);
    newProfileName = editedProfileName;
  };

  /**
   * Below function is used to create a new profile and calls createnewprofile function
   *
   * @param {string} profileType as Automation
   */
  createNewProfileandSelect = async (profileType) => {
    if (!(await commons.isDisplayed(this.anonymous_navBar))) {
      await this.createNewProfile(profileType);
      await this.selectProfile(profileType);
    }
  };

  moveToChangeRatingPage = async () => {
    selectedRating = await commons.findElement(this.selectedContentRating);
    selectedRating = await commons.getText(selectedRating);
    await commons.waitUntil(this.changeRating_btn, 10);
    await commons.click(this.changeRating_btn);
  };

  verifyProfileRatingMetadata = async () => {
    const fails = [];

    if (!(await commons.isEnabled(this.discoveryLogo)))
      fails.push('Discovery Logo is not displayed');
    if (!(await commons.isEnabled(this.contentRating_title)))
      fails.push('Content rating title is not displayed');
    if (!(await commons.isEnabled(this.contentRatingRadio_btn)))
      fails.push('Content rating button is not displayed');
    if (!(await commons.isEnabled(this.contentRatingDescription)))
      fails.push('Content rating description is not displayed');
    if (!(await commons.isEnabled(this.save1_btn)))
      fails.push('Save button is not displayed');
    if (!(await commons.isEnabled(this.cancel_btn)))
      fails.push('cancel button is not displayed');
    if (!(await commons.isEnabled(this.close_btn)))
      fails.push('close button is not displayed');
    if (!(await commons.isEnabled(this.ratingLabel)))
      fails.push('Rating label is not displayed');

    assert.equal(fails.length === 0, true, fails);
    await commons.click(this.save1_btn);
    await commons.waitUntil(this.save_btn, 10);
    await commons.click(this.save_btn);
    await commons.waitUntil(this.done_btn, 10);
    await commons.click(this.done_btn);
  };

  setKidsProfileRating = async () => {
    const ratings = await commons.findElements(this.contentRatingList, 10);

    await commons.click(ratings[1]);
    await commons.click(this.save1_btn);
  };

  verifyRatingUpdated = async () => {
    assert(
      selectedRating !==
        (await commons.getText(
          await commons.findElement(this.selectedContentRating),
        )),
      `Kids rating is not updated`,
    );
    await commons.waitUntil(this.save_btn, 10);
    await commons.click(this.save_btn);
    await commons.waitUntil(this.done_btn, 10);
    await commons.click(this.done_btn);
  };

  verifyManageProfiles = async () => {
    await commons.isDisplayed(this.profilePickerContainer, 30);
  };

  selectProfileToManage = async () => {
    await commons.click(this.manageProfiles_btn);
    await commons.click(this.defaultProfile_txt);
  };

  verifyEditProfilePage = async () => {
    await commons.waitUntil(this.editProfile_txt);
  };

  changeProfileName = async (name) => {
    await commons.click(this.clearProfileName_btn);
    await commons.sendText(this.createProfileName_txtBx, name);
    await commons.click(this.saveChanges_btn);
  };

  verifyErrorMessage = async (err) => {
    if (err) {
      const profileErrorMsg = await commons.findElement(
        this.getCustomLocator(this.profileNameErr_txt, err),
      );

      await commons.waitUntil(profileErrorMsg);
    }
  };

  adTechCreateNewProfileandSelect = async (profileName) => {
    await this.createNewProfileandSelect(profileName);
  };
}

module.exports = new ProfilePage();
