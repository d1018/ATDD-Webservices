const { BasePage, browserActions } = require('./basePage');
const {
  desiredWebCapabilities,
  desiredWebCapabilitiesForAdtech,
} = require('../capabilities/bsCaps');

const menuPage = require('./menuPage');
const profilePage = require('./profilePage');

const commons = browserActions;

const login = process.env.LOGIN_DTC;
const passwordDTC = process.env.PASSWORD_DTC;
const url = process.env.URL;
const serverURL = process.env.SERVER_URL
  ? process.env.SERVER_URL.toLowerCase()
  : '';
const localExecution = process.env.LOCAL_EXECUTION;
let oneTrustPopUp;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  username = '';

  password = '';

  privacyAccept_btn = this.getElementByPage('homePage', 'privacyAccept_btn');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  signIn_btn = this.#getSelectorData('signIn_btn');

  userName_txtBx = this.#getSelectorData('userName_txtBx');

  password_txtBx = this.#getSelectorData('password_txtBx');

  continue_btn = this.#getSelectorData('continue_btn');

  defaultProfile = this.#getSelectorData('defaultProfile');

  profilePickerContainer = this.#getSelectorData('profilePickerContainer');

  focusedSignInPage = this.#getSelectorData('focusedSignInPage');

  proceedLink = this.#getSelectorData('proceedLink');

  advanced_btn = this.#getSelectorData('advanced_btn');

  moreChoices_btn = this.#getSelectorData('moreChoices');

  confirmMyChoices_btn = this.#getSelectorData('confirmMyChoices');

  advertising_checked = this.#getSelectorData('advertising_checked');

  advertising_uncheck = this.#getSelectorData('advertising_uncheck');

  upgradeWatch_txt = this.getElementByPage(
    'onboardingPage',
    'upgradeWatch_txt',
  );

  openApp = async () => {
    let deviceCaps;

    if (process.env.CUCUMBER_TAG.toLowerCase().includes('adtech')) {
      deviceCaps = desiredWebCapabilitiesForAdtech();
    } else {
      deviceCaps = desiredWebCapabilities();
    }

    commons.driverInit(serverURL, localExecution);
    commons.baseURL(login, passwordDTC, url);
    await commons.openApp(deviceCaps);
    if (
      this.returnGeoLocation() === 'emea' &&
      !process.env.CUCUMBER_TAG.toLowerCase().includes('adtech')
    ) {
      await commons.click(this.privacyAccept_btn);
    }
  };

  enterCredentials = async (credentialType) => {
    this.username = process.env[`${credentialType}_USERNAME`];
    this.password = process.env[`${credentialType}_PASSWORD`];
    await commons.waitUntil(this.focusedSignInPage, 40);
    await commons.click(this.userName_txtBx);
    await commons.sendText(this.userName_txtBx, this.username);
    await commons.click(this.password_txtBx);
    await commons.sendText(this.password_txtBx, this.password);
    await commons.click(this.continue_btn);
  };

  loginToApplication = async (credentialType) => {
    await commons.refreshPage();
    if (!credentialType.includes('anonymous')) {
      await commons.waitUntil(this.signIn_btn);
      await commons.click(this.signIn_btn);
      await commons.getAuthURL();
      await menuPage.errorHandler();
      if (
        this.returnGeoLocation() === 'emea' &&
        !process.env.CUCUMBER_TAG.toLowerCase().includes('adtech')
      ) {
        await commons.click(this.privacyAccept_btn);
      }
      await this.performOneTrustPopUpActions();
      await this.enterCredentials(credentialType);
      if (await commons.isDisplayed(this.profilePickerContainer)) {
        await profilePage.selectDefaultProfile();
      } else if (credentialType.includes('DTC_LAPSED')) {
        if (this.returnGeoLocation() !== 'america') {
          await commons.waitUntil(this.upgradeWatch_txt);
        }
      } else {
        try {
          await commons.waitUntil(this.focusedHomePage, 10);
        } catch (error) {
          await commons.refreshPage();
          await commons.waitUntil(this.focusedHomePage, 30);
        }
      }
    }
  };

  verifySignOut = async () => {
    await commons.assertDisplay(this.signIn_btn, true);
  };

  toggleOneTrustPopup = async (settings) => {
    oneTrustPopUp = settings;
    await this.performOneTrustPopUpActions();
  };

  performOneTrustPopUpActions = async () => {
    if (this.returnGeoLocation() === 'emea') {
      if (oneTrustPopUp === 'OFF') {
        await this.declineOneTrustPopup();
      } else if (oneTrustPopUp === 'ON') {
        await this.acceptOneTrustPopup();
      }
    }
  };

  acceptOneTrustPopup = async () => {
    await commons.click(this.privacyAccept_btn);
  };

  declineOneTrustPopup = async () => {
    await commons.click(this.moreChoices_btn);
    const advertisingChecked = await commons.getAttribute(
      this.advertising_checked,
      'aria-checked',
    );

    if (advertisingChecked === 'true') {
      await commons.click(this.advertising_uncheck);
    }
    await commons.click(this.confirmMyChoices_btn);
  };
}

module.exports = new SignInPage();
