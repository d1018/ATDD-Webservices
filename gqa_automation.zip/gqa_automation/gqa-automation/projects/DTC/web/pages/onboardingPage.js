const assert = require('assert');

const mailParser = require('mailparser').simpleParser;

const Imap = require('imap');

const { BasePage, browserActions, testdataHelper } = require('./basePage');

const commons = browserActions;

const menuPage = require('./menuPage');
const homePage = require('./homePage');
const showDetailsPage = require('./showDetailsPage');
const signInPage = require('./signInPage');

const resetAccount = 'RESET_ACCOUNT';
const login = process.env.LOGIN_DTC;
const passwordDTC = process.env.PASSWORD_DTC;
const url = process.env.URL;

let resetPwdUrl = '';

class OnboardingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('onboardingPage', locator);
  }

  privacyAccept_btn = this.getElementByPage('homePage', 'privacyAccept_btn');

  focusedSignInPage = this.getElementByPage('signInPage', 'focusedSignInPage');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  signIn_btn = this.#getSelectorData('signIn_btn');

  anonymousSignUp_btn = this.#getSelectorData('anonymousSignUp_btn');

  playerSignUp_btn = this.#getSelectorData('playerSignUp_btn');

  focusedSignUpPage = this.#getSelectorData('focusedSignUpPage');

  registerFreeCta_btn = this.#getSelectorData('registerFreeCta_btn');

  createAccountContainer_lbl = this.#getSelectorData(
    'createAccountContainer_lbl',
  );

  firstName_txtBx = this.#getSelectorData('firstName_txtBx');

  email_txtBx = this.#getSelectorData('email_txtBx');

  confirmEmail_txtBx = this.#getSelectorData('confirmEmail_txtBx');

  password_txtBx = this.getElementByPage('signInPage', 'password_txtBx');

  birthYear_txtBx = this.#getSelectorData('birthYear_txtBx');

  gender_dropDwn = this.#getSelectorData('gender_dropDwn');

  genderType_option = this.#getSelectorData('genderType_option');

  termsOfUse_chckBx = this.#getSelectorData('termsOfUse_chckBx');

  agreeContinue_btn = this.#getSelectorData('agreeContinue_btn');

  episodeOnUpcomingRail_lbl = this.getElementByPage(
    'sportsPage',
    'episodeOnUpcomingRail_lbl',
  );

  signInOrSignUp_txt = this.#getSelectorData('signInOrSignUp_txt');

  upgradeWatch_txt = this.#getSelectorData('upgradeWatch_txt');

  viewPassesCta_btn = this.#getSelectorData('viewPassesCta_btn');

  invalidMailError_txt = this.#getSelectorData('invalidMailError_txt');

  invalidPasswordError_txt = this.#getSelectorData('invalidPasswordError_txt');

  usernameExistsError_txt = this.#getSelectorData('usernameExistsError_txt');

  passwordBreachedError_txt = this.#getSelectorData(
    'passwordBreachedError_txt',
  );

  mainHeading_txt = this.#getSelectorData('mainHeading_txt');

  indicateRequired_txt = this.#getSelectorData('indicateRequired_txt');

  showPassword_btn = this.#getSelectorData('showPassword_btn');

  registerViaProvider_btn = this.#getSelectorData('registerViaProvider_btn');

  privacyPolicy = this.#getSelectorData('privacyPolicy');

  footer = this.#getSelectorData('footer');

  header = this.#getSelectorData('header');

  productTitle_txt = this.#getSelectorData('productTitle_txt');

  pricePlan_txt = this.#getSelectorData('pricePlan_txt');

  pricingTerms = this.#getSelectorData('pricingTerms');

  pricingExpandCollapse_btn = this.#getSelectorData(
    'pricingExpandCollapse_btn',
  );

  pricingContentContainer = this.#getSelectorData('pricingContentContainer');

  pricingContent_txt = this.#getSelectorData('pricingContent_txt');

  selectPaymentType_dropdown = this.#getSelectorData(
    'selectPaymentType_dropdown',
  );

  paymentOption = this.#getSelectorData('paymentOption');

  plan_btn = this.#getSelectorData('plan_btn');

  billingInfo_txt = this.#getSelectorData('billingInfo_txt');

  pricePlanBreakdown_txt = this.#getSelectorData('pricePlanBreakdown_txt');

  cardHolderName = this.#getSelectorData('cardHolderName');

  cardNumber = this.#getSelectorData('cardNumber');

  expiryDate = this.#getSelectorData('expiryDate');

  securityCode = this.#getSelectorData('securityCode');

  securityCodeToolTip = this.#getSelectorData('securityCodeToolTip');

  termsOfUse_link = this.#getSelectorData('termsOfUse_link');

  encryptedInfo_txt = this.#getSelectorData('encryptedInfo_txt');

  encryptedInfo_icon = this.#getSelectorData('encryptedInfo_icon');

  paypal_btn = this.#getSelectorData('paypal_btn');

  videoContainer = this.getElementByPage('videoPlayerPage', 'videoContainer');

  forgotPassword_btn = this.#getSelectorData('forgotPassword_btn');

  forgotPassword_txt = this.#getSelectorData('forgotPassword_txt');

  reset_password_email_txt_box = this.#getSelectorData(
    'reset_password_email_txt_box',
  );

  email_me_btn = this.#getSelectorData('email_me_btn');

  new_password_txtBx = this.getElementByPage('signInPage', 'password_txtBx');

  confirm_password_txtBx = this.#getSelectorData('confirm_password_txtBx');

  save_password_btn = this.#getSelectorData('save_password_btn');

  subscribeToWatchList = [
    this.#getSelectorData('signIn_btn'),
    this.#getSelectorData('playerSignUp_btn'),
    this.#getSelectorData('signInOrSignUp_txt'),
  ];

  #getPasswordResetUrl = () => {
    const imap = new Imap({
      user: process.env.RESET_ACCOUNT_USERNAME,
      password: process.env.RESET_APP_PASSWORD,
      host: 'imap.gmail.com',
      port: 993,
      tls: true,
      tlsOptions: {
        servername: 'imap.gmail.com',
      },
    });

    /**
     * @param {Function} cb - callback function used to begin openBox(). This callback is defined in imap package.
     */
    function openInbox(cb) {
      imap.openBox('INBOX', true, cb);
    }

    imap.once('ready', async () => {
      await openInbox((err, box) => {
        if (err || !box) throw err;
        imap.search([['SUBJECT', 'Reset your password']], (error, results) => {
          if (error) throw error;
          const f = imap.fetch(
            results[results.length - 1],
            { bodies: '' },
            { struct: true },
          );

          f.on('message', (msg, seqno) => {
            if (err || !seqno) throw err;
            msg.on('body', (stream, info) => {
              if (err || !info) throw err;
              mailParser(stream, (e, mail) => {
                const mailText = mail.text.substring(
                  mail.text.indexOf(
                    'https://auth.discoveryplus.com/set-new-password?',
                  ),
                );

                resetPwdUrl = mailText.substring(0, mailText.indexOf('\n'));
              });
            });
          });
          f.once('end', () => {
            imap.end();
          });
        });
      });
    });

    imap.connect();
    return new Promise((resolve) => {
      imap.once('end', () => {
        resolve(resetPwdUrl);
        imap.end();
      });
    });
  };

  selectTermsOfUse = async () => {
    const terms = await commons.findElements(this.termsOfUse_chckBx);

    for (let i = 0; i < terms.length; i++) {
      await commons.click(terms[i]);
    }
  };

  selectCTAAndVerify = async (CTA) => {
    await this.selectCTA(CTA);
    await this.verifyCTAScreen(CTA);
  };

  selectCTA = async (CTAType) => {
    if (CTAType === 'Sign In') {
      await commons.click(this.signIn_btn);
    } else if (CTAType === 'Sign Up') {
      if (await commons.isDisplayed(this.videoContainer)) {
        await commons.click(this.playerSignUp_btn);
      } else {
        await commons.click(this.anonymousSignUp_btn);
      }
    }
    await commons.getAuthURL();
    if (await commons.isDisplayed(this.privacyAccept_btn)) {
      await commons.click(this.privacyAccept_btn);
    }
  };

  verifyCTAScreen = async (CTAType) => {
    if (CTAType === 'Sign In') {
      await menuPage.errorHandler();
      await commons.waitUntil(this.focusedSignInPage, 10);
      if (await commons.isDisplayed(this.privacyAccept_btn)) {
        await commons.click(this.privacyAccept_btn);
      }
      await commons.clickBack();
      await commons.clickBack();
    } else {
      await commons.waitUntil(this.focusedSignUpPage, 10);
    }
  };

  navigateToPlanPickerPage = async () => {
    await commons.waitUntil(this.anonymousSignUp_btn);
    await commons.click(this.anonymousSignUp_btn);
    await commons.getAuthURL();
    if (await commons.isDisplayed(this.privacyAccept_btn)) {
      await commons.click(this.privacyAccept_btn);
    }
    await commons.waitUntil(this.focusedSignUpPage, 10);
  };

  verifyRegisterFreeCta = async () => {
    await commons.waitUntil(this.registerFreeCta_btn, 10);
  };

  selectRegisterFreeCta = async () => {
    await commons.click(this.registerFreeCta_btn);
  };

  createFreeAccount = async () => {
    await commons.waitUntil(this.createAccountContainer_lbl, 10);
    const randomString = Math.random().toString(36).substring(2, 7);

    await commons.sendText(this.firstName_txtBx, 'TestAutomation');
    await commons.sendText(this.email_txtBx, `dummy${randomString}@test.com`);
    await commons.sendText(
      this.confirmEmail_txtBx,
      `dummy${randomString}@test.com`,
    );
    await commons.sendText(
      this.password_txtBx,
      testdataHelper.getContent(`registrationPage.password`),
    );
    await commons.sendText(
      this.birthYear_txtBx,
      testdataHelper.getContent(`registrationPage.yearOfBirth`),
    );
    await this.selectTermsOfUse();
    await commons.click(this.gender_dropDwn);
    await commons.click(this.genderType_option);
    await commons.waitUntil(this.agreeContinue_btn, 10);
    await commons.click(this.agreeContinue_btn);
    await commons.waitUntil(this.focusedHomePage, 50);
  };

  selectAndCompleteRegistration = async () => {
    await this.selectRegisterFreeCta();
    await this.createFreeAccount();
  };

  verifyAccountCreation = async () => {
    await commons.click(menuPage.userMenu_dropdown);
    await menuPage.navigateToPage('Account');
    await menuPage.assertPage('Account');
  };

  navigateAndSelectContent = async (contentType, userType) => {
    await menuPage.assertPage('Home');
    if (
      contentType.includes('Entertainment VOD') &&
      userType.includes('anonymous')
    ) {
      await homePage.scrollToRail('FreeEpisodeRail');
      await commons.click(homePage.firstCardOnFreeEpisodeRail_lbl);
    } else if (
      contentType.includes('Entertainment VOD') &&
      userType.includes('lapsed')
    ) {
      await homePage.scrollToRail('TrendingRail');
      await homePage.selectShow('FirstShowOntrendingRail');
      await showDetailsPage.selectEpisode(0);
    } else if (contentType.includes('Entertainment Linear')) {
      await commons.pageDown();
      await homePage.selectNetwork('TLC');
      await homePage.selectShow('FirstPopularShowOnTLC');
      await showDetailsPage.selectEpisode(0);
    } else if (
      contentType.includes('Sports VOD') &&
      userType.includes('anonymous')
    ) {
      await menuPage.navigateToPage('Sports');
      await homePage.scrollToRail('UpcomingSportsRail');
      await commons.click(this.episodeOnUpcomingRail_lbl);
    }
  };

  verifySubscribeToWatchScreen = async () => {
    await commons.waitUntil(this.signInOrSignUp_txt, 20);
    await commons.refreshPage();
    await commons.waitUntil(this.signInOrSignUp_txt, 20);
    for (let i = 0; i < this.subscribeToWatchList.length; i++) {
      assert(
        await commons.isDisplayed(this.subscribeToWatchList[i]),
        `${[i]}th position is not displayed on the page`,
      );
    }
  };

  validateUpgradeToWatchScreen = async () => {
    assert(
      (await commons.isDisplayed(this.upgradeWatch_txt)) &&
        (await commons.isDisplayed(this.viewPassesCta_btn)),
      `View Passes is not showing on upgrade to watch screen`,
    );
  };

  submitAccountDetails = async (credentialType) => {
    await commons.waitUntil(this.createAccountContainer_lbl, 10);
    if (credentialType === 'invalid') {
      await commons.sendText(this.email_txtBx, `dummytest.com`);
      await commons.sendText(this.confirmEmail_txtBx, `dummytest.com`);
    } else if (credentialType === 'alreadyRegisteredUser') {
      await commons.sendText(this.email_txtBx, process.env.DTC_VALID_USERNAME);
      await commons.sendText(
        this.confirmEmail_txtBx,
        process.env.DTC_VALID_USERNAME,
      );
      await commons.sendText(
        this.password_txtBx,
        process.env.DTC_VALID_PASSWORD,
      );
    } else if (credentialType === 'breachedPassword') {
      const randomString = Math.random().toString(36).substring(2, 7);

      await commons.sendText(this.email_txtBx, `dummy${randomString}@test.com`);
      await commons.sendText(
        this.confirmEmail_txtBx,
        `dummy${randomString}@test.com`,
      );
      await commons.sendText(this.password_txtBx, 'Password123');
    }
    if (
      credentialType === 'invalid' ||
      credentialType === 'alreadyRegisteredUser' ||
      credentialType === 'breachedPassword'
    ) {
      await commons.sendText(this.firstName_txtBx, 'TestAutomation');
      await commons.sendText(
        this.birthYear_txtBx,
        testdataHelper.getContent(`registrationPage.yearOfBirth`),
      );
      await this.selectTermsOfUse();
      await commons.click(this.gender_dropDwn);
      await commons.click(this.genderType_option);
    }
    await commons.waitUntil(this.agreeContinue_btn, 10);
    await commons.click(this.agreeContinue_btn);
  };

  verifyErrorMessage = async (credentialType) => {
    if (credentialType === 'empty') {
      assert(
        testdataHelper.getContent(`onboardingPage.usernameRequiredError`) ===
          (await commons.getText(
            await commons.findElement(this.invalidMailError_txt),
          )),
        `username required error is not displayed`,
      );
      assert(
        testdataHelper.getContent(`onboardingPage.invalidPasswordError`) ===
          (await commons.getText(
            await commons.findElement(this.invalidPasswordError_txt),
          )),
        `password required error is not displayed`,
      );
    }
    if (credentialType === 'invalid') {
      assert(
        testdataHelper.getContent(`onboardingPage.invalidUsernameError`) ===
          (await commons.getText(
            await commons.findElement(this.invalidMailError_txt),
          )),
        `invalid username error is not displayed`,
      );
      assert(
        testdataHelper.getContent(`onboardingPage.invalidPasswordError`) ===
          (await commons.getText(
            await commons.findElement(this.invalidPasswordError_txt),
          )),
        `invalid password error is not displayed`,
      );
    }
    if (credentialType === 'alreadyRegisteredUser') {
      assert(
        testdataHelper.getContent(`onboardingPage.existingUserError`) ===
          (await commons.getText(
            await commons.findElement(this.usernameExistsError_txt),
          )),
        `already existing user error is not displayed`,
      );
    }
    if (credentialType === 'breachedPassword') {
      assert(
        testdataHelper.getContent(`onboardingPage.passwordBreachedError`) ===
          (await commons.getText(
            await commons.findElement(this.passwordBreachedError_txt),
          )),
        `Password Breached error is not displayed`,
      );
    }
  };

  selectAnyPlan = async () => {
    await commons.waitUntil(this.plan_btn, 10);
    await commons.click(this.plan_btn);
  };

  verifyCreateAccountDetails = async () => {
    const fails = [];

    if (
      !(await commons.getText(await commons.findElement(this.mainHeading_txt)))
    )
      fails.push('Main heading title is not displayed');
    if (
      !(await commons.getText(
        await commons.findElement(this.indicateRequired_txt),
      ))
    )
      fails.push('field required indicator is not displayed');
    if (!(await commons.getText(await commons.findElement(this.privacyPolicy))))
      fails.push('privacy policy is not displayed');
    if (!(await commons.isDisplayed(this.firstName_txtBx)))
      fails.push('First name textbox is not displayed');
    if (!(await commons.isDisplayed(this.email_txtBx)))
      fails.push('email textbox is not displayed');
    if (!(await commons.isDisplayed(this.confirmEmail_txtBx)))
      fails.push('confirm email textbox is not displayed');
    if (!(await commons.isDisplayed(this.password_txtBx)))
      fails.push('password textbox is not displayed');
    await commons.sendText(this.password_txtBx, 'Password123');
    if (!(await commons.isDisplayed(this.showPassword_btn)))
      fails.push('show password button is not displayed');
    if (!(await commons.isDisplayed(this.birthYear_txtBx)))
      fails.push('Birth year textbox is not displayed');
    if (!(await commons.isDisplayed(this.gender_dropDwn)))
      fails.push('gender dropdown is not displayed');
    if (!(await commons.isDisplayed(this.termsOfUse_chckBx)))
      fails.push('terms of use button is not displayed');
    if (!(await commons.isDisplayed(this.agreeContinue_btn)))
      fails.push('agree and continue button is not displayed');
    if (!(await commons.isDisplayed(this.registerViaProvider_btn)))
      fails.push('register via provider button is not displayed');
    if (!(await commons.isDisplayed(this.header)))
      fails.push('header is not displayed');
    if (!(await commons.isDisplayed(this.footer)))
      fails.push('footer is not displayed');
    if (
      !(await commons.getText(await commons.findElement(this.productTitle_txt)))
    )
      fails.push('product title is not displayed');
    if (!(await commons.getText(await commons.findElement(this.pricePlan_txt))))
      fails.push('price plan text is not displayed');
    if (!(await commons.isDisplayed(this.pricingTerms)))
      fails.push('pricing terms is not displayed');
    if (!(await commons.isDisplayed(this.pricingExpandCollapse_btn)))
      fails.push('pricing content expand-collapse button is not displayed');
    if (
      (
        await commons.getAttribute(
          await commons.findElement(this.pricingContentContainer),
          'class',
        )
      ).includes('hidden')
    ) {
      if (await commons.isDisplayed(this.pricingContent_txt))
        fails.push('pricing content should be displayed');
    } else if (!(await commons.isDisplayed(this.pricingContent_txt)))
      fails.push('pricing content should not be displayed');

    assert.equal(fails.length === 0, true, fails);
  };

  selectPaymentType = async (paymentType) => {
    let paymentMethod = '';

    if (paymentType === 'card') paymentMethod = 'scheme';
    else if (paymentType === 'paypal') paymentMethod = paymentType;
    await commons.waitUntil(this.selectPaymentType_dropdown, 20);
    await commons.click(this.selectPaymentType_dropdown);
    const paymentOption = await commons.findElement(
      this.getCustomLocator(this.paymentOption, paymentMethod),
    );

    await commons.waitUntil(paymentOption, 20);
    await commons.click(paymentOption);
  };

  verifyPaymentDetails = async (paymentType) => {
    const fails = [];

    if (
      !(await commons.getText(await commons.findElement(this.billingInfo_txt)))
    )
      fails.push('Billing information text is not displayed');
    if (
      !(await commons.getText(
        await commons.findElement(this.pricePlanBreakdown_txt),
      ))
    )
      fails.push('price plan breakdown text is not displayed');
    if (!(await commons.isDisplayed(this.termsOfUse_link)))
      fails.push('terms of use link is not displayed');
    if (paymentType === 'card') {
      if (!(await commons.isDisplayed(this.cardHolderName)))
        fails.push('Card holdername textbox is not displayed');
      if (!(await commons.isDisplayed(this.cardNumber)))
        fails.push('Card number textbox is not displayed');
      if (!(await commons.isDisplayed(this.expiryDate)))
        fails.push('expiry Date textbox is not displayed');
      if (!(await commons.isDisplayed(this.securityCode)))
        fails.push('security code textbox is not displayed');
      if (!(await commons.isDisplayed(this.securityCodeToolTip)))
        fails.push('security code tool tip is not displayed');
      if (!(await commons.isDisplayed(this.agreeContinue_btn)))
        fails.push('buy now button is not displayed');
      if (
        !(await commons.getText(
          await commons.findElement(this.encryptedInfo_txt),
        ))
      )
        fails.push('encryoted info text is not displayed');
      if (!(await commons.isDisplayed(this.encryptedInfo_icon)))
        fails.push('encrypted info icon is not displayed');
    } else if (paymentType === 'paypal') {
      if (!(await commons.isDisplayed(this.paypal_btn)))
        fails.push('paypal button is not displayed');
    }
    assert.equal(fails.length === 0, true, fails);
  };

  selectPaymentAndVerify = async (paymentType) => {
    await this.selectPaymentType(paymentType);
    await this.verifyPaymentDetails(paymentType);
  };

  verifyInactiveSubscriptionScreen = async () => {
    const pageCurrentURL = await commons.getCurrentUrl();

    assert(pageCurrentURL.includes('lapsed'), `lapsed screen is not displayed`);
  };

  navigateToSignInPage = async () => {
    await commons.click(this.signIn_btn);
    await commons.getAuthURL();
  };

  selectResetPassword = async () => {
    await commons.click(this.forgotPassword_btn);
  };

  verifyResetPasswordScreen = async () => {
    await commons.switchTab(1);
    await commons.waitUntil(this.forgotPassword_txt, 60);
  };

  submitValidEmail = async () => {
    const username = process.env[`${resetAccount}_USERNAME`];

    await commons.click(this.reset_password_email_txt_box);

    await commons.sendText(this.reset_password_email_txt_box, username);

    await commons.click(this.email_me_btn);
  };

  interceptPasswordEmail = async () => {
    const passwordResetUrl = await this.#getPasswordResetUrl();

    await commons.deepLinkTo(passwordResetUrl);
  };

  resetPassword = async () => {
    const newPassword = process.env[`${resetAccount}_PASSWORD`];

    await commons.click(this.new_password_txtBx);
    await commons.sendText(this.new_password_txtBx, newPassword);
    await commons.click(this.confirm_password_txtBx);

    await commons.sendText(this.confirm_password_txtBx, newPassword);

    await commons.click(this.save_password_btn);
  };

  signInWithNewPassword = async () => {
    const baseURL = `https://${login}:${passwordDTC}@${url}`;

    await commons.deepLinkTo(baseURL);
    await signInPage.loginToApplication('RESET_ACCOUNT');
  };

  verifySuccessfulLogin = async () => {
    await commons.waitUntil(this.focusedHomePage, 10);
  };
}

module.exports = new OnboardingPage();
