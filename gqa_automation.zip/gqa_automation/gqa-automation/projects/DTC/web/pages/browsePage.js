/* eslint no-console: "off" */
const { BasePage, browserActions, testdataHelper } = require('./basePage');

const commons = browserActions;

class BrowsePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('browserPage', locator);
  }

  browseMenu = this.#getSelectorData('browseMenu');

  myListMenu = this.#getSelectorData('myListMenu');

  browse_btn = this.#getSelectorData('browse_btn');

  showTile = this.#getSelectorData('showTile');

  networkSelector = this.#getSelectorData('networkSelector');

  networkSelectorRadio = this.#getSelectorData('networkSelectorRadio');

  subNav_lbl = this.#getSelectorData('subNav_lbl');

  networkContainer = this.#getSelectorData('networkContainer');

  networklogo = this.#getSelectorData('networklogo');

  title_lbl = this.#getSelectorData('title_lbl');

  metadata_img = this.#getSelectorData('metadata_img');

  showCardsOnBrowse_lbl = this.#getSelectorData('showCardsOnBrowse_lbl');

  myListplusIcon = this.getElementByPage('searchPage', 'myListplusIcon');

  removeMyListFromBrowse_btn = this.#getSelectorData(
    'removeMyListFromBrowse_btn',
  );

  selectPage = async (pageType) => {
    if (pageType.includes('Browse')) {
      await commons.waitUntil(this.browseMenu, 30);
      await commons.click(this.browseMenu, 30);
    } else if (pageType.includes('My List')) {
      await commons.waitUntil(this.myListMenu, 30);
      await commons.click(this.myListMenu, 30);
    }
  };

  verifyBrowsePage = async () => {
    await commons.waitUntil(this.networkSelector, 30);
  };

  selectNetwork = async (networkType) => {
    const networkSelectorRadiobtn = this.getCustomLocator(
      this.networkSelectorRadio,
      testdataHelper.getContent(`networkPage.${networkType}`),
    );

    await commons.waitUntil(networkSelectorRadiobtn);
    await commons.clickAndRelease(networkSelectorRadiobtn, 10);
  };

  verifyShowOnSelectedNetwork = async () => {
    const container = await commons.findElements(this.networkContainer);

    await commons.isDisplayed(container, 15);
  };

  verifyShowCard = async () => {
    const containers = await commons.findElements(this.networkContainer);

    await commons.isDisplayed(containers, 15);
    await commons.hover(this.networklogo, 30);
    await commons.isDisplayed(this.networklogo, 15);
    await commons.isDisplayed(this.title_lbl, 15);
    await commons.isDisplayed(this.metadata_img, 15);
  };

  selectSubNav = async (subNav) => {
    const subNavlbl = this.getCustomLocator(
      this.subNav_lbl,
      testdataHelper.getContent(`networkPage.${subNav}`),
    );

    await commons.waitUntil(subNavlbl);
    await commons.click(subNavlbl, 10);
  };

  selectAsset = async () => {
    await commons.click(this.showTile);
  };

  addRemoveShowsFromMyList = async (action) => {
    await commons.waitUntil(this.showCardsOnBrowse_lbl);
    await commons.hover(this.showCardsOnBrowse_lbl);
    if (action === 'add') {
      await commons.waitUntil(this.myListplusIcon);
      await commons.click(this.myListplusIcon);
    } else if (action === 'remove') {
      await commons.waitUntil(this.removeMyListFromBrowse_btn);
      await commons.click(this.removeMyListFromBrowse_btn);
    }
  };
}

module.exports = new BrowsePage();
