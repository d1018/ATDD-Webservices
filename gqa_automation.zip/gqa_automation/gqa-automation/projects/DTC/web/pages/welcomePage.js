const {
  BasePage,
  browserActions,
  skipReason,
  customErrors,
} = require('./basePage');

const commons = browserActions;

const { SkipError } = customErrors;

class WelcomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('welcomePage', locator);
  }

  focusedWelcomePageSignIn_btn = this.#getSelectorData('focusedSignIn_btn');

  welcomePageSignIn_btn = this.#getSelectorData('signIn_btn');

  focusedSubscribeNow_btn = this.#getSelectorData('focusedSubscribeNow_btn');

  subscribeNow_btn = this.#getSelectorData('subscribeNow_btn');

  welcomepage = this.#getSelectorData('welcomeScreen');

  welcomeTitle_lbl = this.#getSelectorData('welcomeTitle_lbl');

  chooseYourPlan_lbl = this.#getSelectorData('chooseYourPlan_lbl');

  userName_txtBx = this.getElementByPage('signInPage', 'userName_txtBx');

  password_txtBx = this.getElementByPage('signInPage', 'password_txtBx');

  signIn_btn = this.getElementByPage('signInPage', 'signIn_btn');

  verifyWelcomeScreen = async () => {
    const pageCurrentURL = await commons.getCurrentUrl();

    if (pageCurrentURL.includes('prod')) {
      throw new SkipError(skipReason.noWelcomePageforPROD);
    } else {
      await commons.assertDisplay(this.welcomepage, true, 10);
      await this.verifyWelcomeScreenLocalizedMetadata();
    }
  };

  verifyWelcomeScreenLocalizedMetadata = async () => {
    await commons.assertDisplay(this.focusedSubscribeNow_btn, true, 10);
    await commons.assertDisplay(this.welcomeTitle_lbl, true, 10);
    await commons.assertDisplay(this.subscribeNow_btn, true, 10);
    await commons.assertDisplay(this.welcomePageSignIn_btn, true, 10);
  };

  verifyLandingPageOfWelcomeScreen = async (ctaName) => {
    await commons.assertDisplay(this.welcomepage, true);
    if (ctaName === 'Subscribe Now') {
      await commons.click(this.subscribeNow_btn, 2);
      await commons.getAuthURL();
      await commons.assertDisplay(this.chooseYourPlan_lbl, true, 10);
    } else if (ctaName === 'Sign In') {
      await commons.click(this.welcomePageSignIn_btn, true, 10);
      await commons.assertDisplay(this.userName_txtBx, true, 2);
      await commons.assertDisplay(this.password_txtBx, true, 2);
      await commons.assertDisplay(this.signIn_btn, true, 2);
    }
    await commons.clickBack();
    if (await commons.isDisplayed(this.chooseYourPlan_lbl, 10)) {
      await commons.clickBack();
    }
    await commons.assertDisplay(this.welcomepage, true, 20);
  };
}
module.exports = new WelcomePage();
