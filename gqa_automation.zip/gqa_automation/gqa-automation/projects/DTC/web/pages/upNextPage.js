const assert = require('assert');

const { BasePage, browserActions } = require('./basePage');
const searchPage = require('./searchPage');
const videoPlayerPage = require('./videoPlayerPage');

const commons = browserActions;

class UpNextPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('upNextPage', locator);
  }

  upNext_banner = this.#getSelectorData('upNextBanner');

  upNext_header = this.#getSelectorData('upNextHeader');

  upNext_thumbnail = this.#getSelectorData('upNextThumbnail');

  close_button = this.#getSelectorData('closeButton');

  nextEpisodeCountdown = this.#getSelectorData('nextEpisodeCountdown');

  playNext_button = this.#getSelectorData('playNextButton');

  seriesTitle = this.#getSelectorData('seriesTitleAndEpisodeName');

  episodeRating = this.#getSelectorData('episodeRating');

  play_icon = this.getElementByPage('videoPlayerPage', 'play_icon');

  verifyUpNextBanner = async () => {
    await commons.waitUntil(this.upNext_banner, 30);
  };

  verifyMetaDataForUpNext = async () => {
    await commons.waitUntil(this.upNext_banner, 30);
    await commons.waitUntil(this.upNext_thumbnail, 30);
    await commons.waitUntil(this.close_button, 30);
    await commons.waitUntil(this.nextEpisodeCountdown, 30);
    await commons.waitUntil(this.playNext_button, 30);
    await commons.waitUntil(this.episodeRating, 30);
    await commons.waitUntil(this.seriesTitle, 30);
    const seriesTextElement = await commons.findElement(this.seriesTitle);
    const expectedSeriesTitle = searchPage.contentSearchText;
    const seriesText = (await commons.getText(seriesTextElement)).split('|');

    assert(seriesText[0].includes('E2'));
    assert.equal(expectedSeriesTitle.trim(), seriesText[1].trim());
  };

  clickOnUpNextCTA = async (ctaType) => {
    if (ctaType === 'cancel') {
      await commons.waitUntil(this.close_button, 30);
      await commons.click(this.close_button);
    } else if (ctaType === 'Play') {
      const playIcon = await commons.findElement(this.play_icon);

      await commons.waitUntil(playIcon, 30);
      await commons.click(playIcon);
    }
  };

  verifyScreenOnUpNextCancel = async () => {
    await commons.waitUntil(videoPlayerPage.play_icon, 50);
  };

  verifyNextEpisode = async () => {
    await videoPlayerPage.isVideoPlaying();
  };
}

module.exports = new UpNextPage();
