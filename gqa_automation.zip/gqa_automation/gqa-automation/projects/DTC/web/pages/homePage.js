const assert = require('assert');
const retry = require('async-retry');

const { BasePage, browserActions, testdataHelper } = require('./basePage');

const commons = browserActions;

const showDetailsPage = require('./showDetailsPage');
const videoPlayerPage = require('./videoPlayerPage');
const menuPage = require('./menuPage');
const searchPage = require('./searchPage');
const signInPage = require('./signInPage');

const mylistShowOrder = [];

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  standardShowTiltle = '';

  kidsShowTiltle = '';

  static flag = true;

  forYou_lbl = this.#getSelectorData('forYou_lbl');

  privacyAccept_btn = this.#getSelectorData('privacyAccept_btn');

  focusedHomePage = this.#getSelectorData('focusedHomePage');

  hero_img = this.#getSelectorData('hero_img');

  firstShowCard = this.#getSelectorData('firstShowCard');

  startWatching_btn = this.#getSelectorData('startWatching_btn');

  signUpWatchNow_btn = this.#getSelectorData('signUpWatchNow_btn');

  firstShowCardSearchPage = this.#getSelectorData('firstShowCardSearchPage');

  addToMyList_btn = this.#getSelectorData('addToMyList_btn');

  addToMyListRail_btn = this.#getSelectorData('addToMyListRail_btn');

  back_btn = this.#getSelectorData('back_btn');

  viewPasses_cta = this.#getSelectorData('viewPasses_cta');

  mylistCards_lbl = this.#getSelectorData('mylistCards_lbl');

  kidsContent_title = this.#getSelectorData('kidsContent_title');

  contentTitleMetadata_lbl = this.#getSelectorData('contentTitleMetadata_lbl');

  clearSearch_Btn = this.getElementByPage('searchPage', 'clearSearch_Btn');

  jipRail_lbl = this.#getSelectorData('jipRail_lbl');

  jipShowName_img = this.#getSelectorData('jipShowName_img');

  search_txtBx = this.getElementByPage('searchPage', 'search_txtBx');

  episode_lbl = this.#getSelectorData('episode_lbl');

  jipContentName_img = this.getElementByPage(
    'videoPlayerPage',
    'jipContentName_img',
  );

  videoContainerview = this.getElementByPage(
    'videoPlayerPage',
    'videoContainerview',
  );

  playerProgress_bar = this.getElementByPage(
    'videoPlayerPage',
    'playerProgress_bar',
  );

  playerBack_btn = this.getElementByPage('videoPlayerPage', 'playerBack_btn');

  playPause_btn = this.getElementByPage('videoPlayerPage', 'playPause_btn');

  fullScreen_btn = this.getElementByPage('videoPlayerPage', 'fullScreen_btn');

  livebadge_btn = this.getElementByPage('videoPlayerPage', 'livebadge_btn');

  primaryRail_lbl = this.#getSelectorData('primaryRail_lbl');

  enlargedRail_lbl = this.#getSelectorData('enlargedRail_lbl');

  watchNow_btn = this.#getSelectorData('watchNow_btn');

  searchresults_btn = this.getElementByPage('browserPage', 'metadata_img');

  nextEpisodeRating = this.getElementByPage(
    'showPage',
    'nextEpisodeRating_txt',
  );

  episodeInfo_lbl = this.getElementByPage('showPage', 'episodeInfo_lbl');

  animatedata = this.getElementByPage('showPage', 'animatedata');

  primarySportsCard = this.#getSelectorData('primarySportsCard');

  primarySportsCard_img = this.#getSelectorData('primarySportsCard_img');

  primarySportsCardTitle_lbl = this.#getSelectorData(
    'primarySportsCardTitle_lbl',
  );

  primarySportsCardLogo_img = this.#getSelectorData(
    'primarySportsCardLogo_img',
  );

  primarySportsCardExpanded_img = this.#getSelectorData(
    'primarySportsCardExpanded_img',
  );

  primarySportsCardExpandedTitle_lbl = this.#getSelectorData(
    'primarySportsCardExpandedTitle_lbl',
  );

  primarySportsCardExpandedDescription_lbl = this.#getSelectorData(
    'primarySportsCardExpandedDescription_lbl',
  );

  primarySportsCardExpandedMyList_btn = this.#getSelectorData(
    'primarySportsCardExpandedMyList_btn',
  );

  enlargedSportsCard = this.#getSelectorData('enlargedSportsCard');

  enlargedSportsCard_img = this.#getSelectorData('enlargedSportsCard_img');

  enlargedSportsCardLogo_img = this.#getSelectorData(
    'enlargedSportsCardLogo_img',
  );

  enlargedSportsCardExpanded_img = this.#getSelectorData(
    'enlargedSportsCardExpanded_img',
  );

  enlargedSportsCardExpandedTitle_lbl = this.#getSelectorData(
    'enlargedSportsCardExpandedTitle_lbl',
  );

  enlargedSportsCardExpandedDescription_lbl = this.#getSelectorData(
    'enlargedSportsCardExpandedDescription_lbl',
  );

  enlargedSportsCardExpandedMyList_btn = this.#getSelectorData(
    'enlargedSportsCardExpandedMyList_btn',
  );

  heroCoverHeading = this.#getSelectorData('heroCoverHeading');

  myListRail_lbl = this.#getSelectorData('myListRail_lbl');

  showsCardName = this.#getSelectorData('showsCardName');

  removeMylistIcon_lbl = this.#getSelectorData('removeMylistIcon_lbl');

  network_rail = this.#getSelectorData('network_rail');

  removeMylistToastMessage_txt = this.#getSelectorData(
    'removeMylistToastMessage_txt',
  );

  standardPrimaryRail_lbl = this.#getSelectorData('standardPrimaryRail_lbl');

  standardPrimarySportsCard = this.#getSelectorData(
    'standardPrimarySportsCard',
  );

  standardPrimarySportsCard_img = this.#getSelectorData(
    'standardPrimarySportsCard_img',
  );

  standardPrimarySportsCardTitle_lbl = this.#getSelectorData(
    'standardPrimarySportsCardTitle_lbl',
  );

  standardPrimarySportsCardLogo_img = this.#getSelectorData(
    'standardPrimarySportsCardLogo_img',
  );

  standardPrimarySportsCardExpanded_img = this.#getSelectorData(
    'standardPrimarySportsCardExpanded_img',
  );

  standardPrimarySportsCardExpandedTitle_lbl = this.#getSelectorData(
    'standardPrimarySportsCardExpandedTitle_lbl',
  );

  standardPrimarySportsCardExpandedDescription_lbl = this.#getSelectorData(
    'standardPrimarySportsCardExpandedDescription_lbl',
  );

  standardPrimarySportsCardExpandedMylist_btn = this.#getSelectorData(
    'standardPrimarySportsCardExpandedMylist_btn',
  );

  firstCardOnFreeEpisodeRail_lbl = this.#getSelectorData(
    'firstCardOnFreeEpisodeRail_lbl',
  );

  myListCTA_btn = this.#getSelectorData('myListCTA_btn');

  myListCTARail_btn = this.#getSelectorData('myListCTARail_btn');

  homeHeroTitle = this.#getSelectorData('homeHeroTitle');

  rating = this.#getSelectorData('rating_txt');

  playrating_txt = this.#getSelectorData('playrating_txt');

  removeFromMylist_btn = this.#getSelectorData('removeFromMylist_btn');

  removeFromRailMylist_btn = this.#getSelectorData('removeFromRailMylist_btn');

  addedToMyList_txt = this.#getSelectorData('addedToMyList_txt');

  userMenu = this.getElementByPage('menuPage', 'userMenu');

  signOut_btn = this.getElementByPage('signInPage', 'signOut_btn');

  cwRailFirstShow_txt = this.#getSelectorData('cwRailFirstShow_txt');

  cwRailFirstEpisodeCard = this.#getSelectorData('cwRailFirstEpisodeCard');

  genreTabItems = {
    'For You': this.#getSelectorData('forYou_lbl'),
    Crime: this.#getSelectorData('crime_lbl'),
    'Paranormal and Unexplained': this.#getSelectorData('paranormal_lbl'),
  };

  selectGenreTab = async (genreName) => {
    await commons.click(this.genreTabItems[genreName]);
    await commons.waitUntil(this.hero_img, 10);
  };

  railsList = {
    Featured: this.#getSelectorData('featuredRail_lbl'),
    'My List': this.#getSelectorData('myListRail_lbl'),
    Primary: this.#getSelectorData('primaryRail_lbl'),
    Enlarged: this.#getSelectorData('enlargedRail_lbl'),
    'Standard Primary': this.#getSelectorData('standardPrimaryRail_lbl'),
    FreeEpisodeRail: this.#getSelectorData('freeEpisodeRail_lbl'),
    TrendingRail: this.#getSelectorData('trendingRail_lbl'),
    NetworkRail: this.#getSelectorData('network_rail'),
    UpcomingSportsRail: this.getElementByPage('sportsPage', 'upcomingRail_lbl'),
    JipRail: this.#getSelectorData('jipRail_lbl'),
  };

  showTiles = {
    FirstTileOnFeaturedRail: this.#getSelectorData(
      'firstTileOnFeaturedRail_lbl',
    ),
    FirstShowOntrendingRail: this.#getSelectorData(
      'firstShowOntrendingRail_lbl',
    ),
    FirstPopularShowOnTLC: this.#getSelectorData('firstPopularShowOnTLC_lbl'),
    FirstShowCard: this.#getSelectorData('firstShowCard'),
    ThirdTileOnShowCard_lbl: this.#getSelectorData('ThirdTileOnShowCard_lbl'),
  };

  networkChannelsList = {
    TLC: this.#getSelectorData('tlc_lbl'),
  };

  scrollToRail = async (railName, railStatus = true) => {
    let flag;

    for (let i = 0; i < 12; i++) {
      await commons.pageDown();
    }
    if ((await commons.isDisplayed(this.railsList[railName])) === true) {
      await commons.scrollIntoView(
        JSON.stringify(this.railsList[railName]).split('"')[3],
      );
      flag = true;
    } else {
      flag = false;
    }
    assert.equal(railStatus, flag);
  };

  verifyVideoPlayed = async () => {
    await this.selectAndPlayVideo();
    await videoPlayerPage.isVideoPlaying();
  };

  selectShow = async (show) => {
    await commons.hover(this.showTiles[show]);
    await commons.click(this.showTiles[show]);
  };

  selectAndPlayVideo = async () => {
    await this.selectShow('FirstTileOnFeaturedRail');
    await commons.waitUntil(showDetailsPage.showHero_img, 30);
    await commons.waitUntil(showDetailsPage.watchNow_btn, 10);
    await commons.click(showDetailsPage.watchNow_btn);
  };

  getUserMenuItems = async (userType, pageValue) => {
    const pageItems = ['Home', 'Browse', 'Search', 'Sports'];

    if (pageItems.includes(pageValue)) {
      if (userType === 'anonymous') {
        await commons.scrollToElement(this.firstShowCard, 6);
        await commons.click(this.firstShowCard);
        await commons.waitUntil(this.signUpWatchNow_btn, 20);
      } else if (userType === 'fully-entitled') {
        await commons.scrollToElement(this.firstShowCard, 6);
        await commons.waitUntil(this.firstShowCard);
        await this.selectShow('FirstShowCard');
        await commons.waitUntil(this.myListCTA_btn, 20);
        await commons.waitUntil(this.signUpWatchNow_btn, 20);
        await commons.click(this.signUpWatchNow_btn);
        await videoPlayerPage.isVideoPlaying();
        await commons.clickBack();
      } else if (userType === 'non-entitled') {
        await commons.scrollToElement(this.firstShowCard, 10);
        await commons.waitUntil(this.firstShowCard);
        await this.selectShow('ThirdTileOnShowCard_lbl');
        await commons.waitUntil(this.myListCTA_btn, 20);
        await commons.waitUntil(this.signUpWatchNow_btn, 20);
        await commons.click(this.signUpWatchNow_btn);
        await commons.waitUntil(this.viewPasses_cta, 20);
        await commons.clickBack();
      }
    }
  };

  validateCTAonPages = async (userType, pageName) => {
    const pages = pageName.raw();

    for (let i = 0; i < pages.length; i++) {
      if (
        this.returnGeoLocation() === 'america' &&
        pages[i].toString() !== 'Sports'
      ) {
        await menuPage.navigateToPage(pages[i].toString());
        await this.getUserMenuItems(userType, pages[i].toString());
      }
    }
  };

  /**
   * This function will switch to Kids profile and searches for UK-U label on Home rail. Also, this searches for A rated content and if shown, the validation fails
   */
  verifyKidsContentPopulated = async () => {
    const contentTitle = await this.searchContent('kids');

    assert(
      testdataHelper.getContent('searchPage.adultShowName') !== contentTitle,
      `A rated content is shown on the kids search screen`,
    );
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.focusedHomePage, 10);
  };

  verifyJipContentPlayback = async (pageName) => {
    if (pageName === 'Home Page') {
      await commons.waitUntil(this.focusedHomePage, 80);
      await this.scrollToRail('JipRail');
      await commons.waitUntil(this.jipRail_lbl, 25);
      await commons.clickAndRelease(this.jipShowName_img);

      await this.verifyJIPVideoPlayback();
    } else if (pageName === 'Show Details Page') {
      await commons.clickBack();
      await menuPage.navigateToPage('Search');
      const searchtxt = await commons.findElement(this.search_txtBx);

      await commons.sendText(searchtxt, 'Ghost Adventures Channel |', 20);
      await commons.waitUntil(searchPage.searchResultContent);
      await commons.click(this.episode_lbl, 20);
      await commons.isDisplayed(this.jipContentName_img, 120);
      await commons.click(this.jipContentName_img, 80);
      await commons.waitUntil(this.videoContainerview, 60);
      await commons.refreshPage();
      await commons.click(this.videoContainerview, 60);

      await this.verifyJIPVideoPlayback();
    }
  };

  verifyJIPVideoPlayback = async () => {
    if (!(await commons.isDisplayed(this.playerProgress_bar, 15))) {
      await commons.isDisplayed(this.videoContainerview, 30);
    }
    assert.equal(
      await commons.isDisplayed(this.videoContainerview),
      true,
      'Video Container is present',
      await commons.click(this.videoContainerview, 15),
      await commons.isDisplayed(this.playPause_btn),
      true,
      'Play Pause button is present',
      await commons.isDisplayed(this.playerBack_btn),
      true,
      'Play Back button is present',
      await commons.isDisplayed(this.livebadge_btn),
      true,
      'live Badge button is present',
      await commons.isDisplayed(this.fullScreen_btn),
      true,
      'live Badge button is present',
    );
    const fullscreen = await commons.isDisplayed(this.fullScreen_btn);

    return fullscreen;
  };

  verifyJIPContent = async () => {
    if (process.env.GEO.toLowerCase() === 'us') {
      const isContentDisplayed = await this.searchContent('JIP');

      assert(
        !isContentDisplayed,
        `JIP content is shown on the kids search screen for non-US regions`,
      );
    }
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.focusedHomePage, 10);
  };

  searchContent = async (contentType) => {
    let isContentDisplayed = false;

    if (contentType === 'kids') {
      await commons.isDisplayed(this.kidsContent_title, 30);
      await menuPage.navigateToPage('Search');
      await searchPage.searchText('kidsShowName');
      await commons.waitUntil(searchPage.searchResultContent);
      const contentTitle = await commons.getText(this.contentTitleMetadata_lbl);

      return contentTitle;
    }
    if (contentType === 'JIP') {
      await menuPage.navigateToPage('Search');
      if (await commons.isDisplayed(this.clearSearch_Btn)) {
        await commons.click(this.clearSearch_Btn);
      }
      await searchPage.searchText('JIPShowName');
      isContentDisplayed = await commons.isDisplayed(this.JIPContent, 20);
    }
    return isContentDisplayed;
  };

  verifySportsRail = async (sportsRailType) => {
    switch (sportsRailType) {
      case 'primary':
        await this.scrollToRail('Primary');
        break;
      case 'enlarged':
        await this.scrollToRail('Enlarged');
        break;
      case 'standard primary':
        await this.scrollToRail('Standard Primary');
        break;
      default:
        break;
    }
  };

  verifySportsCardMetadata = async (sportsRail) => {
    switch (sportsRail) {
      case 'primary':
        await commons.waitUntil(this.primarySportsCard_img);
        await commons.waitUntil(this.primarySportsCardTitle_lbl);
        assert.notEqual(
          await commons.isDisplayed(this.primarySportsCardLogo_img),
          true,
          'Logo is present',
        );
        await commons.hover(this.primarySportsCard);
        await commons.waitUntil(this.primarySportsCardExpanded_img);
        await commons.waitUntil(this.primarySportsCardExpandedTitle_lbl);
        await commons.waitUntil(this.primarySportsCardExpandedDescription_lbl);
        assert.notEqual(
          await commons.isDisplayed(this.primarySportsCardExpandedMyList_btn),
          true,
          'MyList is present',
        );
        await commons.click(this.primarySportsCard);
        break;
      case 'enlarged':
        await commons.waitUntil(this.enlargedSportsCard_img);
        assert.notEqual(
          await commons.isDisplayed(this.enlargedSportsCardLogo_img),
          true,
          'Logo is present',
        );
        await commons.hover(this.enlargedSportsCard);
        await commons.waitUntil(this.enlargedSportsCardExpanded_img);
        await commons.waitUntil(this.enlargedSportsCardExpandedTitle_lbl);
        await commons.waitUntil(this.enlargedSportsCardExpandedDescription_lbl);
        assert.notEqual(
          await commons.isDisplayed(this.enlargedSportsCardExpandedMyList_btn),
          true,
          'MyList is present',
        );
        await commons.click(this.enlargedSportsCard);
        break;
      case 'standard primary':
        await commons.waitUntil(this.standardPrimarySportsCard_img);
        await commons.waitUntil(this.standardPrimarySportsCardTitle_lbl);
        assert.notEqual(
          await commons.isDisplayed(this.standardPrimarySportsCardLogo_img),
          true,
          'Logo is present',
        );
        await commons.hover(this.standardPrimarySportsCard);
        await commons.waitUntil(this.standardPrimarySportsCardExpanded_img);
        await commons.waitUntil(
          this.standardPrimarySportsCardExpandedTitle_lbl,
        );
        await commons.waitUntil(
          this.standardPrimarySportsCardExpandedDescription_lbl,
        );
        assert.notEqual(
          await commons.isDisplayed(
            this.standardPrimarySportsCardExpandedMylist_btn,
          ),
          true,
          'MyList is present',
        );
        await commons.click(this.standardPrimarySportsCard);
        break;
      default:
        break;
    }
  };

  selectSportsCard = async () => {
    await commons.waitUntil(this.heroCoverHeading, 30);
  };

  addShowToMyList = async (index) => {
    await menuPage.navigateToPage('Search');
    await searchPage.searchText('multiContentShow');
    await this.addToMyList(index);
  };

  addToMyList = async (index) => {
    await commons.waitUntil(searchPage.visibleresultCardContent, 20);
    const showCards = await commons.findElements(
      searchPage.visibleresultCardContent,
    );
    const plusIcon = await commons.findElements(searchPage.myListplusIcon);
    const mylistShowsCardName = await commons.findElements(
      searchPage.showTitle_lbl,
    );

    for (let i = 0; i < index; i++) {
      await commons.waitUntil(showCards[i], 20);
      await commons.hover(showCards[i]);
      mylistShowOrder.push(await commons.getText(mylistShowsCardName[i]));
      await commons.waitUntil(plusIcon[i]);
      await commons.click(plusIcon[i]);
    }
  };

  verifyMyListRailMetadata = async (count) => {
    await menuPage.navigateToPage('Home');
    await commons.refreshPage();
    await commons.waitUntil(this.hero_img, 20);
    await this.scrollToRail('My List');
    const myListCards = await commons.findElements(this.myListRail_lbl);
    const totalMylistCards = myListCards.length;

    assert(
      totalMylistCards + 1 > count,
      `More than 2 shows are not added to My list rail`,
    );
    await commons.hover(myListCards[count - 1]);
    await commons.isDisplayed(this.mylistShowThumbnail_img);
    await commons.isDisplayed(this.mylistShowNetworkLogo_img);
  };

  verifyMyListRailShowOrder = async () => {
    const mylistShowstitle = await commons.findElements(this.showsCardName);
    const count = mylistShowOrder.length;
    const myListshowName = [];

    for (let i = 0; i < count; i++) {
      myListshowName[i] = await commons.getText(mylistShowstitle[i]);
      await commons.hover(mylistShowstitle[i]);
    }
    myListshowName.reverse();
    assert(
      JSON.stringify(mylistShowOrder) === JSON.stringify(myListshowName),
      `mylist shows are not matching`,
    );
  };

  removeFromMyList = async (showName) => {
    const count = mylistShowOrder.length;
    const mylistShow = await commons.findElements(this.mylistCards_lbl);
    const removeIcon = await commons.findElements(this.removeMylistIcon_lbl);
    const showList = mylistShowOrder.reverse();

    for (let i = 0; i < count; i++) {
      if (showList[i] === testdataHelper.getContent(`searchPage.${showName}`)) {
        await commons.hover(mylistShow[i]);
        await commons.waitUntil(removeIcon[i]);
        await commons.hover(removeIcon[i]);
        await commons.click(removeIcon[i]);
        try {
          await retry(
            async () => {
              await commons.isDisplayed(this.removeMylistToastMessage_txt, 10);
            },
            { retries: 3 },
          );
        } catch (error) {
          throw new Error('remove to my list is not displayed');
        }
      }
    }
    await this.verifyMylistShowCountAfterRemoving();
  };

  verifyMylistShowCountAfterRemoving = async () => {
    await commons.refreshPage();
    await commons.waitUntil(this.hero_img, 20);
    await this.scrollToRail('My List');
    const count = mylistShowOrder.length;
    const mylistShow = await commons.findElements(this.mylistCards_lbl);
    const recentMylistCount = mylistShow.length;

    assert(recentMylistCount < count, `mylist show is not removed`);
  };

  scrollToNetworkRail = async () => {
    await commons.waitUntil(this.focusedHomePage, 20);
    await commons.arrowDown();
    await commons.arrowDown();
    if (!(await commons.isDisplayed(this.network_rail, 5))) {
      await this.scrollToRail('NetworkRail');
    }
    await commons.waitUntil(this.network_rail, 20);
  };

  validateNetworkRail = async () => {
    await commons.waitUntil(this.network_rail, 20);
  };

  selectNetwork = async (channelName) => {
    await commons.waitUntil(this.networkChannelsList[channelName]);
    await commons.click(this.networkChannelsList[channelName]);
  };

  verifyMyListRailOnHomePage = async (railName, railStatus) => {
    await menuPage.navigateToPage('Home');
    await this.scrollToRail(railName, railStatus);
  };

  verifyShowsInMyListRail = async (railStatus) => {
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.hero_img);
    if (railStatus === true) {
      await commons.scrollToElement(this.myListRail_lbl, 8, 5);
    } else {
      await this.scrollToRail('My List', railStatus);
    }
  };

  verifyMyListCtaForShow = async () => {
    await commons.hover(this.showTiles.FirstTileOnFeaturedRail);
    assert(
      !(await commons.isDisplayed(searchPage.myListplusIcon)),
      `Mylist cta button displayed`,
    );
  };

  addShowToMylistFromHomeHero = async () => {
    await commons.waitUntil(this.myListCTA_btn, 5);
    await commons.hover(this.myListCTA_btn);
    if (await commons.isDisplayed(this.removeFromMylist_btn, 5)) {
      await commons.click(this.removeFromMylist_btn);
    }
    await commons.waitUntil(this.addToMyList_btn, 5);
    if (this.flag) {
      this.standardShowTiltle = await commons.getAttribute(
        this.homeHeroTitle,
        'alt',
      );
      this.flag = false;
    }
    await commons.click(this.myListCTA_btn);
    await commons.waitUntil(this.addedToMyList_txt);
  };

  verifyAgeRatingAndContentDescriptors = async (screensType) => {
    switch (screensType) {
      case 'Main Hero':
        await commons.waitUntil(this.hero_img, 60);
        break;

      case 'Show Details Page': {
        await menuPage.navigateToPage('Search');
        await searchPage.searchText('multiContentShow');
        await commons.waitUntil(searchPage.searchResultContent);
        const searchResults = await commons.findElement(this.searchresults_btn);

        await commons.clickAndRelease(searchResults, 60);
        await commons.waitUntil(this.animatedata, 60);
        break;
      }

      case 'Currently Playing Episode': {
        const watchNowbtn = await commons.findElement(this.watchNow_btn);

        await commons.click(watchNowbtn, 30);
        await commons.clickBack();
        await commons.waitUntil(this.animatedata, 60);
        break;
      }

      case 'Next Episodes listed on Episode Landing Page': {
        const ratingsize = await commons.findElements(this.rating);

        await commons.pageDown();
        await commons.hover(this.nextEpisodeRating, 20);
        for (let i = 0; i < ratingsize.length; i++) {
          await commons.isDisplayed(ratingsize[2]);
        }
        break;
      }

      case 'Episode Info Panel':
        await commons.isDisplayed(this.episodeInfo_lbl);
        break;

      default:
        throw new Error(
          'Actual screenType provided is not as per the expectations',
        );
    }

    if (screensType !== 'Next Episodes listed on Episode Landing Page') {
      const ratinglabel = await commons.findElement(this.rating);

      assert(
        await commons.isDisplayed(ratinglabel, 120),
        `Rating for the show is not displayed`,
      );

      const currentRating = await commons.getAttribute(
        this.rating,
        'innerText',
        10,
      );

      assert(
        testdataHelper.getContent('ratingList').includes(currentRating),
        `Rating is not as per rating standards`,
      );
    }
  };

  signOut = async () => {
    await commons.hover(this.userMenu);
    await commons.click(this.signOut_btn);
    await commons.waitUntil(signInPage.signIn_btn, 30);
  };

  verifyMyListShowAvailability = async () => {
    this.kidsShowTiltle = await commons.getAttribute(this.homeHeroTitle, 'alt');
    assert(
      this.standardShowTiltle !== this.kidsShowTiltle,
      `show title is duplicated`,
    );
  };

  navigateToMyList = async (myListype) => {
    if (myListype === 'Rail') {
      await commons.pageDown();
      await commons.waitUntil(this.focusedHomePage, 25);
      await this.scrollToRail('My List', true);
    } else if (myListype === 'Page') {
      await commons.waitUntil(this.focusedHomePage, 25);
    }
  };

  removedShowFromMylistFromHomeHero = async () => {
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.myListCTA_btn, 5);
    await commons.hover(this.myListCTA_btn);
    await commons.waitUntil(this.removeFromMylist_btn, 5);
    await commons.click(this.removeFromMylist_btn);
    await commons.waitUntil(this.addToMyList_btn);
  };

  resumeAndPlayVideo = async () => {
    await commons.click(this.cwRailFirstEpisodeCard);
    await videoPlayerPage.isVideoPlaying();
  };

  addShowToMylistFromHomeRail = async () => {
    await commons.waitUntil(this.myListCTA_btn, 5);
    await commons.pageDown();
    await commons.hover(this.myListCTARail_btn);
    if (await commons.isDisplayed(this.removeFromRailMylist_btn, 5)) {
      await commons.click(this.removeFromRailMylist_btn);
    }
    await commons.waitUntil(this.addToMyListRail_btn, 35);
    await commons.click(this.addToMyListRail_btn);
  };

  verifyContinueWatchingMetadata = async () => {
    const showDetails = ['thumbnailImage', 'progressBar'];

    // await commons.scrollOnPageByPercentage('down', '30%');
    await this.scrollToRail('Continue Watching');

    for (let i = 0; i < showDetails.length; i++) {
      await commons.waitUntil(this.metadataForShow[showDetails[i]]);
    }

    assert(
      (await commons.elementExists(await this.cwFirstShow())) &&
        (await commons.elementExists(await this.cwFirstEpisode())),
      `continue watching first show & episode names are not matching `,
    );
  };

  cwFirstShow = async () => {
    let showName = await this.getShowNameText();

    showName = this.getCustomLocator(this.cwRailFirstShow_txt, showName);

    return showName;
  };

  cwFirstEpisode = async () => {
    let episodeName = await this.getEpisodeNameText();

    episodeName = this.getCustomLocator(this.cwRailFirstShow_txt, episodeName);

    return episodeName;
  };

  verifyContinueWatchingNotVisible = async () => {
    await this.scrollToRail('Continue Watching', false);
  };
}

module.exports = new HomePage();
