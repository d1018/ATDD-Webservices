const assert = require('assert');
const {
  BasePage,
  browserActions,
  testdataHelper,
  analyticsValidationHelper,
} = require('./basePage');
const menuPage = require('./menuPage');
const searchPage = require('./searchPage');
const videoPlayerPage = require('./videoPlayerPage');

const commons = browserActions;

let showName = '';

class AdTechPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('adTechPage', locator);
  }

  episode_card = this.getElementByPage('showPage', 'episodeVisibleCardContent');

  episode_title = this.getElementByPage('searchPage', 'episode_title');

  search_txtBx = this.getElementByPage('searchPage', 'search_txtBx');

  time_slots = this.#getSelectorData('time_slots');

  ad_label = this.#getSelectorData('ad_label');

  ad_time_indicator = this.#getSelectorData('ad_time_indicator');

  age_rating = this.#getSelectorData('age_rating');

  ads_container = this.#getSelectorData('ads_container');

  videoContainer_view = this.getElementByPage(
    'videoPlayerPage',
    'videoContainerview',
  );

  searchShow = async (show) => {
    await menuPage.navigateToPage('Search');
    await this.searchText(show);
    await searchPage.navigateToEpisodeTab();
    const episodeTitle = await commons.getText(this.episode_title);

    assert(await episodeTitle.includes(showName), `Show not displayed`);
    await commons.waitUntil(this.episode_card, 30);
    await commons.click(this.episode_card, 30);
  };

  adPlaying = async () => {
    await commons.waitUntil(this.ad_label, 10);
    if (commons.isDisplayed(this.ad_label, 30)) {
      assert(
        await commons.isDisplayed(this.ad_time_indicator, 30),
        `Ad not played`,
      );
    }
    await this.adCompletes();
  };

  getShowName = async (show) => {
    showName = await testdataHelper.getContent(`adtech.${show}`);
    return showName;
  };

  searchText = async (show) => {
    const searchText = await this.getShowName(show);

    showName = searchText;
    await commons.sendText(this.search_txtBx, showName);
  };

  fetchAdquePoints = async () => {
    const quePoints = [];
    const timeSlots = await commons.getAttribute(this.time_slots, 'style');
    const quePoint = new Set(timeSlots.match(/calc\(\d+.\d+/gi));

    quePoint.forEach((element) => {
      quePoints.push(parseFloat(element.replace(/calc\(/, '')));
    });
    return quePoints;
  };

  fetchFinalAdquePoints = (quePoints, value) => {
    if (quePoints.length === value) {
      return 100;
    }

    return quePoints[value];
  };

  scrubOverFirstMidroll = async () => {
    await videoPlayerPage.isVideoPlaying();
    await this.scrubOverAdbreak('two');
  };

  scrubOverAdbreak = async (adbreakPosition) => {
    let quePoint;
    let finalquePoint;
    const quePoints = await this.fetchAdquePoints();

    switch (adbreakPosition) {
      case 'one':
        quePoint = quePoints[0] / 2;
        break;

      case 'two':
        finalquePoint = await this.fetchFinalAdquePoints(quePoints, 1);
        quePoint = (quePoints[0] + finalquePoint) / 2;
        break;

      case 'three':
        finalquePoint = await this.fetchFinalAdquePoints(quePoints, 2);
        quePoint = (quePoints[1] + finalquePoint) / 2;
        break;

      case 'four':
        finalquePoint = await this.fetchFinalAdquePoints(quePoints, 3);
        quePoint = (quePoints[2] + finalquePoint) / 2;
        break;

      default:
        throw new Error('The specified ad break condition does not exist');
    }
    await commons.hover(this.videoContainer_view);
    await videoPlayerPage.scrubVideo(quePoint);
  };

  adCompletes = async () => {
    const timer = (await commons.getText(this.ad_time_indicator)).split(':');
    const adTime = parseInt(timer[0], 10) * 60 + parseInt(timer[1], 10);

    await commons.waitUntil(this.age_rating, adTime);
  };

  waitForFallIntoAdbreak = async () => {
    await commons.waitUntil(this.ad_label, 20);
  };

  scrubBeforeFirstNonEmptyMidroll = async () => {
    await videoPlayerPage.isVideoPlaying();
    const quePoints = await this.fetchAdquePoints();

    if (quePoints.length < 1) {
      throw new Error('Mid-roll ad breaks not found');
    }
    const quePoint = quePoints[0] + 5.5;

    await videoPlayerPage.scrubVideo(quePoint);
  };

  adTrackingSetting = async (adTrackingReq) => {
    const driver = commons.getDriver();

    await driver.switchTo().newWindow('tab');
    await driver.get('chrome://settings/cookies');

    const doNotTrackBtn = driver.executeScript(
      "return document.querySelector('settings-ui').shadowRoot.querySelector('settings-main')" +
        ".shadowRoot.querySelector('settings-basic-page').shadowRoot.querySelector('settings-section > settings-privacy-page')" +
        ".shadowRoot.querySelector('settings-animated-pages > settings-subpage > settings-cookies-page')" +
        ".shadowRoot.querySelector('settings-do-not-track-toggle').shadowRoot.querySelector('settings-toggle-button').shadowRoot.querySelector('cr-toggle')",
    );

    if (adTrackingReq === 'OFF') {
      assert.equal(
        await commons.getAttribute(doNotTrackBtn, 'aria-pressed'),
        'false',
        'Ad Tracking is not enabled',
      );
    } else if (adTrackingReq === 'ON') {
      await commons.click(doNotTrackBtn);
      const confirmBtn = driver.executeScript(
        "return document.querySelector('settings-ui')" +
          ".shadowRoot.querySelector('settings-main').shadowRoot.querySelector('settings-basic-page')" +
          ".shadowRoot.querySelector('settings-section > settings-privacy-page')" +
          ".shadowRoot.querySelector('settings-animated-pages > settings-subpage > settings-cookies-page')" +
          ".shadowRoot.querySelector('settings-do-not-track-toggle').shadowRoot.querySelector('cr-dialog')" +
          ".querySelector('.action-button')",
      );

      await commons.waitUntil(confirmBtn, 10);
      await commons.click(confirmBtn);
      assert.equal(
        await commons.getAttribute(doNotTrackBtn, 'aria-pressed'),
        'true',
        'Ad Tracking is not disabled',
      );
    }

    await driver.close();
    await commons.switchTab(0);
  };

  trackBeacons = async (beaconType, adType) => {
    await commons.clickBack();
    await commons.closeApp();
    const bsSessionId = commons.getBsSessionId();

    await analyticsValidationHelper.bsBeaconsValidation(
      bsSessionId,
      beaconType,
      adType,
    );
  };

  scrubPastMultipleMidroll = async () => {
    await videoPlayerPage.isVideoPlaying();
    let lastQuePoint;
    const quePoints = await this.fetchAdquePoints();

    if (quePoints.length < 2) {
      throw new Error('Multiple mid-roll ad breaks not found');
    } else {
      lastQuePoint = quePoints[quePoints.length - 1];
      lastQuePoint += 92 - lastQuePoint;
    }
    await videoPlayerPage.scrubVideo(lastQuePoint);
  };

  validateAdRequestParameters = async (parameters) => {
    await videoPlayerPage.isVideoPlaying();
    const geoLocation = this.returnGeoLocation();
    const bsSessionId = await commons.getBsSessionId();

    await commons.closeApp();
    await analyticsValidationHelper.verifyAdRequestParameters(
      parameters,
      bsSessionId,
      geoLocation,
    );
  };

  scrubBeforeSecondNonEmptyMidroll = async () => {
    await videoPlayerPage.isVideoPlaying();
    let secondMidRoll;
    const quePoints = await this.fetchAdquePoints();

    if (quePoints.length < 2) {
      throw new Error('Multiple mid-roll ad breaks not found');
    } else {
      secondMidRoll = quePoints[1] + 5.5;
      await videoPlayerPage.scrubVideo(secondMidRoll);
    }
  };

  scrubToSpecificChapter = async (attribute, chapter) => {
    await this.searchShow(attribute);
    await videoPlayerPage.isVideoPlaying();
    if (chapter === 'one') {
      await this.scrubOverAdbreak('two');
    }
  };

  scrubOverSecondMidroll = async () => {
    await videoPlayerPage.isVideoPlaying();
    const quePoints = await this.fetchAdquePoints();

    if (quePoints.length < 2) {
      throw new Error('Multiple mid-roll ad breaks not found');
    } else {
      await this.scrubOverAdbreak('two');
      await commons.hover(this.videoContainer_view);
      await this.scrubOverAdbreak('three');
    }
  };
}

module.exports = new AdTechPage();
