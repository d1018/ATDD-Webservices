const assert = require('assert');

const { BasePage, browserActions } = require('./basePage');

const commons = browserActions;
const menuPage = require('./menuPage');
const searchPage = require('./searchPage');
const browsePage = require('./browsePage');
const homePage = require('./homePage');

class MyListPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myListPage', locator);
  }

  myList_lbl = this.#getSelectorData('myList_lbl');

  showCards = this.#getSelectorData('showCards');

  browseShows = this.#getSelectorData('browseShows_btn');

  mLPageCards_lbl = this.#getSelectorData('mLPageCards_lbl');

  mLPageTitle_lbl = this.#getSelectorData('mLPageTitle_lbl');

  mLPageNetworkLogo_lbl = this.#getSelectorData('mLPageNetworkLogo_lbl');

  homeHeroTitle = this.getElementByPage('homePage', 'homeHeroTitle');

  myListCrossIcon = this.getElementByPage('searchPage', 'myListCrossIcon');

  myListplusIcon = this.getElementByPage('searchPage', 'myListplusIcon');

  showImage_img = this.getElementByPage('searchPage', 'showImage_img');

  mylistCards_lbl = this.getElementByPage('homePage', 'mylistCards_lbl');

  myListTitle_lbl = this.getElementByPage('homePage', 'myListTitle_lbl');

  myListNetworl_lbl = this.getElementByPage(
    'homePage',
    'myListNetworkLogo_lbl',
  );

  noSavedShow_txt = this.#getSelectorData('noSavedShow_txt');

  removeMyList_txt = this.#getSelectorData('removeMyList_txt');

  removeMylistToastMessage_txt = this.getElementByPage(
    'homePage',
    'removeMylistToastMessage_txt',
  );

  showCardsOnBrowse_lbl = this.getElementByPage(
    'browserPage',
    'showCardsOnBrowse_lbl',
  );

  removeMyListFromBrowse_btn = this.getElementByPage(
    'browserPage',
    'removeMyListFromBrowse_btn',
  );

  addShowsToMylistFromBrowse = async () => {
    await menuPage.navigateToPage('Browse');
    await commons.waitUntil(this.showCardsOnBrowse_lbl);
    await commons.hover(this.showCardsOnBrowse_lbl);
    if (await commons.isDisplayed(this.removeMyListFromBrowse_btn)) {
      await commons.click(this.removeMyListFromBrowse_btn);
    }
    await commons.waitUntil(this.myListplusIcon);
    await commons.click(this.myListplusIcon);
  };

  verifyShowsInMyList = async (railStatus) => {
    await menuPage.navigateToPage('My List');
    await commons.refreshPage();
    if (railStatus) {
      await commons.waitUntil(this.showImage_img);
      assert(
        await commons.isDisplayed(this.showCards),
        `No Show displayed in Mylist Screen`,
      );
    } else {
      assert(
        !(await commons.isDisplayed(this.showCards)),
        `Show displayed in Mylist Screen`,
      );
    }
    await menuPage.navigateToPage('Home');
  };

  selectBrowseShows = async () => {
    await commons.isDisplayed(this.browseShows, 10);
    await commons.click(this.browseShows, 10);
  };

  removeShowFromMyListPage = async () => {
    await menuPage.navigateToPage('My List');
    let totalShows = await commons.findElements(this.showCards);

    while (totalShows.length !== 0) {
      await commons.waitUntil(this.showCards);
      await commons.hover(this.showCards);
      await commons.hover(this.myListCrossIcon);
      await commons.click(this.myListCrossIcon);
      try {
        await commons.isDisplayed(this.removeMylistToastMessage_txt, 10);
      } catch (error) {
        await commons.isDisplayed(this.removeMylistToastMessage_txt, 10);
      }
      await commons.waitUntil(this.myList_lbl, 40);
      totalShows = await commons.findElements(this.showCards);
    }
    await commons.isDisplayed(this.noSavedShow_txt, 10);
  };

  verifyMyListMetadata = async (myListype) => {
    const myListCards = await commons.findElements(this.mylistCards_lbl);

    if (myListype === 'Rail') {
      await commons.hover(myListCards[1]);
      await commons.isDisplayed(this.myListTitle_lbl, 10);
      await commons.isDisplayed(this.myListNetworkLogo_lbl, 10);
    } else if (myListype === 'Page') {
      const myListPageCards = await commons.findElements(this.mLPageCards_lbl);

      await commons.hover(myListPageCards[1]);
      await commons.isDisplayed(this.mLPageTitle_lbl, 10);
      await commons.isDisplayed(this.mLPageNetworkLogo_lbl, 10);
    }
  };

  verifyAssetTile = async (myListype) => {
    const heroTitleElement = await commons.findElement(this.homeHeroTitle);
    const heroTitleElementText = await commons.getAttribute(
      heroTitleElement,
      'alt',
    );

    if (myListype === 'Rail') {
      const myListTitleElement = await commons.findElement(
        this.myListTitle_lbl,
      );
      const myListTitletText = await commons.getText(myListTitleElement);

      assert.equal(heroTitleElementText, myListTitletText);
    } else if (myListype === 'Page') {
      await menuPage.navigateToPage('My List');
      const mlPageElementText = await commons.getText(this.mLPageTitle_lbl);

      assert.equal(heroTitleElementText, mlPageElementText);
    }
  };

  navigateToDetailPageFromMyList = async () => {
    await menuPage.navigateToPage('My List');
    await commons.waitUntil(this.myList_lbl);
    await commons.click(this.showCards);
  };

  navigateBack = async () => {
    await commons.clickBack();
  };

  validateMyListPage = async () => {
    assert.equal(
      await commons.isDisplayed(this.myList_lbl, 30),
      true,
      'My list page did not display',
    );
  };

  addShowsToMyList = async (pageName) => {
    await menuPage.navigateToPage(pageName);
    if (pageName === 'Home') {
      await homePage.addShowToMylistFromHomeHero();
    } else if (pageName === 'Browse') {
      await browsePage.addRemoveShowsFromMyList('add');
    } else if (pageName === 'Search') {
      await searchPage.addShowsToMylistFromSearch();
    }
  };

  removeShowFromMyList = async (pageName) => {
    await menuPage.navigateToPage(pageName);
    if (pageName === 'Home') {
      await homePage.removedShowFromMylistFromHomeHero();
    } else if (pageName === 'Browse') {
      await browsePage.addRemoveShowsFromMyList('remove');
    } else if (pageName === 'Search') {
      await searchPage.removeShowsFromMylistFromSearch();
    }
  };
}

module.exports = new MyListPage();
