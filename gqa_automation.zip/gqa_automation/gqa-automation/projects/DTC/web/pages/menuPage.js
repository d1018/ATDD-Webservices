const assert = require('assert');

const { BasePage, browserActions, testdataHelper } = require('./basePage');

const commons = browserActions;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  searchMenu_lbl = this.#getSelectorData('searchMenu_lbl');

  manageProfileMenu_lbl = this.#getSelectorData('manageProfileMenu_lbl');

  userMenu_dropdown = this.#getSelectorData('userMenu_dropdown');

  homeMenu_lbl = this.#getSelectorData('homeMenu_lbl');

  accountMenu_lbl = this.#getSelectorData('accountMenu_lbl');

  focusedMenuBar = this.#getSelectorData('focusedMenuBar');

  show_btn = this.#getSelectorData('show_btn');

  myList_btn = this.#getSelectorData('myList_btn');

  sportsMenu_lbl = this.#getSelectorData('sportsMenu_lbl');

  tvGuideMenu_lbl = this.#getSelectorData('tvGuideMenu_lbl');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  crime_lbl = this.getElementByPage('homePage', 'crime_lbl');

  forYou_btn = this.getElementByPage('homePage', 'forYou_btn');

  crime_btn = this.getElementByPage('homePage', 'crime_btn');

  signUpWatchNow_btn = this.getElementByPage('homePage', 'signUpWatchNow_btn');

  timeBarCellTitle_txt = this.getElementByPage(
    'tvGuidePage',
    'timeBarCellTitle_txt',
  );

  sports_lbl = this.getElementByPage('sportsPage', 'sports_lbl');

  search_txtBx = this.getElementByPage('searchPage', 'search_txtBx');

  networkSelector = this.getElementByPage('browserPage', 'networkSelector');

  myList_lbl = this.getElementByPage('myListPage', 'myList_lbl');

  signIn_btn = this.getElementByPage('accountPage', 'signIn_btn');

  accountDashboard = this.getElementByPage('accountPage', 'accountDashboard');

  profile_section = this.getElementByPage('profilePage', 'manageProfile_btn');

  defaultProfile_txt = this.getElementByPage(
    'profilePage',
    'defaultProfile_txt',
  );

  defaultProfile_btn = this.getElementByPage(
    'profilePage',
    'defaultProfile_txt',
  );

  manageProfile_btn = this.getElementByPage('accountPage', 'manageProfile');

  errorContainer_lbl = this.#getSelectorData('errorContainer_lbl');

  myListCTA_btn = this.getElementByPage('homePage', 'myListCTA_btn');

  menuItem = {
    Search: this.searchMenu_lbl,
    Sports: this.sportsMenu_lbl,
    'TV Guide': this.tvGuideMenu_lbl,
    Home: this.homeMenu_lbl,
    'My List': this.myList_btn,
    UserMenu: this.userMenu_dropdown,
    Account: this.accountMenu_lbl,
    Browse: this.show_btn,
    'Manage Profile': this.manageProfileMenu_lbl,
  };

  pageFocused = {
    Home: this.forYou_lbl,
    'TV Guide': this.timeBarCellTitle_txt,
    Sports: this.sports_lbl,
    Search: this.search_txtBx,
    'My List': this.myList_lbl,
    Browse: this.networkSelector,
    Account: this.accountDashboard,
    'Manage Profile': this.profile_section,
  };

  genreList = {
    'For You': this.forYou_lbl,
    Crime: this.crime_lbl,
  };

  genrePageFocused = {
    'For You': this.forYou_btn,
    Crime: this.crime_btn,
  };

  errorHandler = async () => {
    if (await commons.isDisplayed(this.errorContainer_lbl, 10))
      await commons.refreshPage();
  };

  CtaButton = {
    'My List': this.getElementByPage('homePage', 'myListCTA_btn'),
  };

  navigateToPage = async (pageValue) => {
    if (pageValue === 'Account') {
      await commons.waitUntil(this.userMenu_dropdown, 10);
      await commons.click(this.userMenu_dropdown);
    }
    await commons.waitUntil(this.menuItem[pageValue], 30);
    await commons.click(this.menuItem[pageValue]);
    const pageCurrentURL = await commons.getCurrentUrl();

    if (pageCurrentURL.includes('uat')) {
      await commons.getAuthURL();
    }
    try {
      await commons.waitUntil(this.pageFocused[pageValue], 60);
    } catch (error) {
      await commons.refreshPage();
      await commons.waitUntil(this.pageFocused[pageValue], 60);
    }
  };

  navigateToGenre = async (pageValue) => {
    await commons.click(this.genreList[pageValue]);
    await commons.waitUntil(this.genrePageFocused[pageValue], 20);
  };

  accessGlobalNavigationMenu = async () => {
    await commons.waitUntil(this.focusedMenuBar);
  };

  getUserMenuItems = async () => {
    let userMenu = [];

    if (
      !(await commons.isDisplayed(this.myList_btn)) &&
      (await commons.isDisplayed(this.signIn_btn))
    ) {
      userMenu = testdataHelper.getContent(
        'menuNavigationPageForWeb.anonymousUserMenuList',
      );
    } else if (await commons.isDisplayed(this.tvGuideMenu_lbl)) {
      userMenu = testdataHelper.getContent(
        'menuNavigationPageForWeb.defaultUserMenuList',
      );
    } else {
      userMenu = testdataHelper.getContent(
        'menuNavigationPageForWeb.kidsUserMenuList',
      );
    }
    return userMenu;
  };

  verifyMenuList = async () => {
    const userMenu = await this.getUserMenuItems();

    for (let i = 0; i < userMenu.length; i++) {
      if (userMenu[i] === 'Account') {
        await commons.click(this.userMenu_dropdown);
      }
      await commons.waitUntil(this.menuItem[userMenu[i]], 5);
    }
  };

  verifyGlobalNavigation = async () => {
    const userMenu = await this.getUserMenuItems();

    for (let i = 0; i < userMenu.length; i++) {
      await this.navigateToPage(userMenu[i]);
    }
  };

  assertPage = async (pageValue) => {
    await commons.waitUntil(this.pageFocused[pageValue], 10);
  };

  isMenuOptionPresent = async (menuOption, assertValue) => {
    if (assertValue === true) {
      assert(
        await commons.isDisplayed(this.menuItem[menuOption]),
        `Menu Item List is not Displayed`,
      );
    } else {
      assert(
        !(await commons.isDisplayed(this.menuItem[menuOption])),
        `Menu Item List is Displayed`,
      );
    }
  };

  isCTAPresent = async (CTA, assertValue) => {
    if (CTA === 'My List') {
      await commons.scrollToPageTop();
      await commons.click(this.forYou_lbl);
      if (assertValue === true) {
        assert(
          await commons.isDisplayed(this.CtaButton[CTA]),
          `My list cta button not displayed`,
        );
      } else {
        assert(
          !(await commons.isDisplayed(this.CtaButton[CTA])),
          `Mylist cta button displayed`,
        );
      }
    }
  };
}

module.exports = new MenuPage();
