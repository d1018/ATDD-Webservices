const assert = require('assert');
const retry = require('async-retry');
const { BasePage, browserActions } = require('./basePage');

const commons = browserActions;

const playerPositionAfterScrub = 0;

class VideoPlayerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('videoPlayerPage', locator);
  }

  videoContainer = this.#getSelectorData('videoContainer');

  videoControl = this.#getSelectorData('videoControl');

  playPause_btn = this.#getSelectorData('playPause_btn');

  play_icon = this.#getSelectorData('play_icon');

  playerBack_btn = this.#getSelectorData('playerBack_btn');

  fullScreen_btn = this.#getSelectorData('fullScreen_btn');

  startTimer_lbl = this.#getSelectorData('startTimer_lbl');

  endTimer_lbl = this.#getSelectorData('endTimer_lbl');

  playerErrorPage = this.#getSelectorData('playerErrorPage');

  timeline_scrubber = this.#getSelectorData('scrubber');

  timeline = this.#getSelectorData('playbackTimeline');

  /* verifying the video landing page */
  verifyVideoPlayerPage = async () => {
    await commons.waitUntil(this.videoContainer, 30);
  };

  fetchVideoControls = async () => {
    const video = await commons.findElement(this.videoControl);

    await commons.clickAndHold(video);
  };

  isVideoPlaying = async () => {
    await this.verifyVideoPlayerPage();
    try {
      await retry(
        async () => {
          await commons.isDisplayed(this.videoControl, 40);
        },
        { retries: 5 },
      );
    } catch (error) {
      throw new Error('unable to play video');
    }
    await this.fetchVideoControls();
    await commons.waitUntil(this.playPause_btn, 10);
    await commons.waitUntil(this.startTimer_lbl, 30);
    await this.fetchVideoControls();
    const timerText = (await commons.getText(this.startTimer_lbl)).split(':');
    const beforeTime =
      parseInt(timerText[0], 10) * 60 + parseInt(timerText[1], 10) + 5;
    let afterTime = 0;

    do {
      const timerText2 = (await commons.getText(this.startTimer_lbl)).split(
        ':',
      );

      afterTime =
        parseInt(timerText2[0], 10) * 60 + parseInt(timerText2[1], 10);
    } while (beforeTime >= afterTime);
  };

  scrubVideo = async (scrubPercent) => {
    // Percentages higher than 95% result in unexpected behaviors in web
    const percent = scrubPercent > 95 ? 95 : scrubPercent;
    const timelineSizeAndLocation = await commons.getElementSizeAndLocation(
      this.timeline,
    );
    const scrubberSizeAndLocation = await commons.getElementSizeAndLocation(
      this.timeline_scrubber,
    );

    await commons.waitUntil(this.timeline_scrubber, 30);
    const xOffset = parseInt(
      timelineSizeAndLocation.width * (percent / 100) -
        scrubberSizeAndLocation.x,
      10,
    );

    const scrubDetails = {
      offset: {
        x: xOffset,
        y: 0,
      },
    };

    await commons.clickAndDrag(this.timeline_scrubber, scrubDetails);
  };

  verifyUpNextBanner = async () => {
    await commons.waitUntil(this.upNextBanner, 30);
  };

  videoPlayerPosition = async () => {
    await commons.waitUntil(this.videoContainer, 20);
    await commons.click(this.videoContainer, 50);
    await commons.waitUntil(this.timeline_scrubber);
    const currentPlayerPosition = await commons.getElementSizeAndLocation(
      this.timeline_scrubber,
    );

    return currentPlayerPosition;
  };

  validateResumePoint = async () => {
    const playerPositionAOnResume = await this.videoPlayerPosition();

    assert(
      playerPositionAOnResume >= playerPositionAfterScrub,
      `Resume video is not successful as the player position on resume is ${playerPositionAOnResume} which is less than the player position after scrub ${playerPositionAfterScrub}`,
    );
  };
}

module.exports = new VideoPlayerPage();
