const assert = require('assert');

const { BasePage, browserActions, testdataHelper } = require('./basePage');
const profilePage = require('./profilePage');
const menuPage = require('./menuPage');

const commons = browserActions;

class AccountPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('accountPage', locator);
  }

  accountTitle_lbl = this.#getSelectorData('accountTitle_lbl');

  accountDashboard = this.#getSelectorData('accountDashboard');

  selectedProfile_txt = this.#getSelectorData('selectedProfile_txt');

  availableProfiles = this.#getSelectorData('availableProfiles');

  selectedProfile = '';

  signIn_btn = this.#getSelectorData('signIn_btn');

  signUp_btn = this.#getSelectorData('signUp_btn');

  billingSection = this.#getSelectorData('billingSection');

  manageProfileMenu_lbl = this.getElementByPage(
    'menuPage',
    'manageProfileMenu_lbl',
  );

  signOut_btn = this.getElementByPage('signInPage', 'signOut_btn');

  accountMenu_lbl = this.getElementByPage('menuPage', 'accountMenu_lbl');

  helpCentre_lbl = this.#getSelectorData('helpCentre_lbl');

  accountSection = this.#getSelectorData('accountSection');

  subscriptionSection = this.#getSelectorData('subscriptionSection');

  profileSection = this.#getSelectorData('profileSection');

  manageAccount = this.#getSelectorData('manageAccount');

  billingContent = this.#getSelectorData('billingContent');

  billingHistory = this.#getSelectorData('billingHistory');

  upcomingBillingDate = this.#getSelectorData('upcomingBillingDate');

  emailDashboard = this.#getSelectorData('emailDashboard');

  passwordDashboard = this.#getSelectorData('passwordDashboard');

  informationDashboard = this.#getSelectorData('informationDashboard');

  manageDeviceDashboard = this.#getSelectorData('manageDeviceDashboard');

  subscribe_btn = this.#getSelectorData('subscribe_btn');

  changePasswordPopup = this.#getSelectorData('changePasswordPopup');

  currentPassword = this.#getSelectorData('currentPassword');

  newPassword = this.#getSelectorData('newPassword');

  confirmPassword = this.#getSelectorData('confirmPassword');

  saveChangesCta_btn = this.#getSelectorData('saveChangesCta_btn');

  changePasswordError_lbl = this.#getSelectorData('changePasswordError_lbl');

  errorIcon_lbl = this.#getSelectorData('errorIcon_lbl');

  invalidError_txt = this.#getSelectorData('invalidError_txt');

  billingCurrency_txt = this.#getSelectorData('billingCurrency_txt');

  billingHistoryPaymentInfo_txt = this.#getSelectorData(
    'billingHistoryPaymentInfo_txt',
  );

  lastPaymentDate_txt = this.#getSelectorData('lastPaymentDate_txt');

  paymentDetailsTitle_lbl = this.#getSelectorData('paymentDetailsTitle_lbl');

  cardTypeIcon_lbl = this.#getSelectorData('cardTypeIcon_lbl');

  maskedCardNumber_txt = this.#getSelectorData('maskedCardNumber_txt');

  visibleCardNumber_txt = this.#getSelectorData('visibleCardNumber_txt');

  updateCta_btn = this.#getSelectorData('updateCta_btn');

  helpCentre_txt = this.#getSelectorData('helpCentre_txt');

  manageProfile_lbl = this.#getSelectorData('manageProfile_lbl');

  userDropdownSubMenuIteams = {
    Account: this.accountMenu_lbl,
    Help: this.helpCentre_lbl,
    'Manage Profile': this.manageProfileMenu_lbl,
    'Sign Out': this.signOut_btn,
  };

  accountLandingPage = [
    this.billingSection,
    this.accountSection,
    this.subscriptionSection,
    this.profileSection,
    this.manageAccount,
    this.billingContent,
    this.billingHistory,
    this.upcomingBillingDate,
    this.emailDashboard,
    this.passwordDashboard,
    this.informationDashboard,
    this.manageDeviceDashboard,
  ];

  validateCtaAccountPage = async () => {
    await commons.waitUntil(this.signIn_btn, 10);
    await commons.waitUntil(this.signUp_btn, 10);
  };

  changeActiveProfile = async () => {
    await commons.waitUntil(this.selectedProfile_txt, 30);
    const selectedProfileText = await commons.findElement(
      this.selectedProfile_txt,
    );

    this.selectedProfile = await commons.getText(selectedProfileText);
    const availableProfiles = await commons.findElements(
      this.availableProfiles,
    );

    await commons.click(availableProfiles[0]);
  };

  verifyActiveProfileSwitch = async () => {
    const selectedProfileText = await commons.findElement(
      this.selectedProfile_txt,
    );

    assert(
      this.selectedProfile !== (await commons.getText(selectedProfileText)),
      `profile switch is not successful`,
    );
  };

  verifyAccountPage = async (profileName) => {
    if (profileName !== 'Anonymous') {
      await this.selectManageProfileCTA();
      await profilePage.selectProfile(profileName);
      if (profileName === 'Default') {
        await menuPage.navigateToPage('Account');
      }
      const accountMenuList = this.getUserAccountMenuItems(profileName);

      for (let i = 0; i < accountMenuList.length; i++) {
        await commons.isDisplayed(
          this.userDropdownSubMenuIteams[accountMenuList[i]],
          5,
        );
      }
    }
  };

  verifyAccountSubNavigationPage = async (profileName) => {
    if (profileName !== 'Anonymous' && profileName !== 'Kids') {
      for (let i = 0; i < this.accountLandingPage.length; i++) {
        if (
          this.returnGeoLocation() === 'america' &&
          this.accountLandingPage[i] !== this.informationDashboard
        ) {
          await commons.waitUntil(this.accountLandingPage[i]);
        }
      }
    }
  };

  getUserAccountMenuItems = (profileName) => {
    const userMenu = {
      Default: 'defaultUserAccountItemListWeb',
      Kids: 'kidsUserAccountItemListWeb',
    };

    return testdataHelper.getContent(`accountPage.${userMenu[profileName]}`);
  };

  selectChangePassword = async () => {
    await commons.waitUntil(this.passwordDashboard);
    await commons.click(this.passwordDashboard);
    await commons.waitUntil(this.changePasswordPopup);
  };

  submitCredentialsOnChangePassword = async () => {
    await commons.sendText(this.currentPassword, `1234`);
    await commons.sendText(
      this.newPassword,
      process.env.DTC_SINGLE_PROFILE_PASSWORD,
    );
    await commons.sendText(
      this.confirmPassword,
      process.env.DTC_SINGLE_PROFILE_PASSWORD,
    );
    await commons.waitUntil(this.saveChangesCta_btn);
    await commons.click(this.saveChangesCta_btn);
  };

  verifyErrorMessageOnChangePassword = async () => {
    await commons.waitUntil(this.changePasswordError_lbl);
    assert(
      await commons.isDisplayed(this.errorIcon_lbl),
      `error icon is not displayed`,
    );
    assert(
      testdataHelper.getContent(`accountPage.invalidChangePasswordError`) ===
        (await commons.getText(
          await commons.findElement(this.invalidError_txt),
        )),
      `change password error is not displayed`,
    );
  };

  verifyMyAccountDetailsForCreditCard = async () => {
    await commons.waitUntil(this.billingSection);
    const fails = [];

    if (!(await commons.isDisplayed(this.billingHistory)))
      fails.push('Billing history/view charges CTA is not displayed');
    if (
      !(await commons.getText(
        await commons.findElement(this.upcomingBillingDate),
      ))
    )
      fails.push('Next Payment date is not displayed');
    if (!(await commons.isDisplayed(this.billingContent)))
      fails.push('Upcoming payment amount is not displayed');
    if (
      !(await commons.getText(
        await commons.findElement(this.billingCurrency_txt),
      ))
    )
      fails.push('Billing currency text is not displayed');
    if (
      !(await commons.getText(
        await commons.findElement(this.billingHistoryPaymentInfo_txt),
      ))
    )
      fails.push('Billing history section title is not displayed');
    if (
      !(await commons.getText(
        await commons.findElement(this.lastPaymentDate_txt),
      ))
    )
      fails.push('Last payment made date text is not displayed');
    if (!(await commons.isDisplayed(this.paymentDetailsTitle_lbl)))
      fails.push('Payment details section title is not displayed');
    if (!(await commons.isDisplayed(this.updateCta_btn)))
      fails.push('Update CTA button is not displayed');
    if (!(await commons.isDisplayed(this.cardTypeIcon_lbl)))
      fails.push('Card type icon is not displayed');
    if (
      !(await commons.getText(
        await commons.findElement(this.maskedCardNumber_txt),
      ))
    )
      fails.push('12 digit Card number as masked is not displayed');
    if (
      !(await commons.getText(
        await commons.findElement(this.visibleCardNumber_txt),
      ))
    )
      fails.push('4 digit visible card number is not displayed');

    assert.equal(fails.length === 0, true, fails);
  };

  selectManageProfileCTA = async () => {
    await commons.waitUntil(this.manageProfile_lbl, 10);
    await commons.click(this.manageProfile_lbl);
  };

  selectSubscribe = async () => {
    await commons.waitUntil(this.subscribe_btn, 10);
    await commons.click(this.subscribe_btn);
  };

  selectAdultProfile = async () => {};

  selectFooter = async (label) => {
    await menuPage.navigateToPage('Account');
    if (label === 'Help') {
      await commons.click(this.helpCentre_lbl);
    }
    await commons.switchTab(1);
  };

  verifyHelpPage = async () => {
    await commons.waitUntil(this.helpCentre_txt);
  };
}

module.exports = new AccountPage();
