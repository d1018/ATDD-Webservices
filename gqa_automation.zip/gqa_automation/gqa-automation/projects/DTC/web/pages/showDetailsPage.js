const assert = require('assert');

const { BasePage, browserActions } = require('./basePage');

const commons = browserActions;
const menuPage = require('./menuPage');
const videoPlayerPage = require('./videoPlayerPage');

class ShowDetailsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('showPage', locator);
  }

  showHero_img = this.#getSelectorData('showHero_img');

  first_episode = this.#getSelectorData('episodeVisibleCardContent');

  watchNow_btn = this.#getSelectorData('watchNow_btn');

  addToMyList_btn = this.#getSelectorData('addToMyList_btn');

  episodeRail_lbl = this.#getSelectorData('episodeRail_lbl');

  signUpWatchNow_btn = this.getElementByPage('homePage', 'signUpWatchNow_btn');

  viewPasses_cta = this.getElementByPage('homePage', 'viewPasses_cta');

  visibleresultCardContent = this.getElementByPage(
    'searchPage',
    'visibleresultCardContent',
  );

  myListCTA_btn = this.getElementByPage('homePage', 'myListCTA_btn');

  removeFromMylist_btn = this.getElementByPage(
    'homePage',
    'removeFromMylist_btn',
  );

  removeMylistToastMessage_txt = this.getElementByPage(
    'homePage',
    'removeMylistToastMessage_txt',
  );

  addedToMyList_txt = this.getElementByPage('homePage', 'addedToMyList_txt');

  addMylistIcon_img = this.#getSelectorData('addMylistIcon_img');

  addedMylistIcon_img = this.#getSelectorData('addedMylistIcon_img');

  removeMylistIcon_img = this.#getSelectorData('removeMylistIcon_img');

  addToMylistToastMessage_txt = this.#getSelectorData(
    'addToMylistToastMessage_txt',
  );

  /* verifying the show landing page */
  verifyShowLandingPage = async (cta) => {
    await commons.waitUntil(this.showHero_img, 30);
    if (cta === 'Watch Now CTA') {
      await commons.isDisplayed(this.watchNow_btn, 20);
      await commons.click(this.watchNow_btn, 20);
      await commons.clickBack();
    } else if (cta === 'My List CTA') {
      await commons.isDisplayed(this.addToMyList_btn, 60);
      await commons.click(this.addToMyList_btn, 20);
    }
  };

  getUserMenuItems = async (userType, pageValue) => {
    const pageItems = ['For You', 'Crime'];

    if (pageItems.includes(pageValue)) {
      if (userType === 'anonymous') {
        await commons.click(this.watchNow_btn, 20);
        await commons.waitUntil(this.signUpWatchNow_btn, 20);
        await commons.clickBack();
      } else if (userType === 'fully-entitled') {
        await commons.click(this.watchNow_btn, 20);
        await commons.waitUntil(this.signUpWatchNow_btn, 20);
        await commons.click(this.signUpWatchNow_btn);
        await videoPlayerPage.isVideoPlaying();
        await commons.clickBack();
        await menuPage.navigateToPage('Home');
      } else if (userType === 'non-entitled') {
        await commons.click(this.watchNow_btn, 20);
        await commons.waitUntil(this.signUpWatchNow_btn, 20);
        await commons.click(this.signUpWatchNow_btn);
        await commons.waitUntil(this.viewPasses_cta, 20);
        await commons.clickBack();
        await menuPage.navigateToPage('Home');
      }
    }
  };

  validateCTAonGenres = async (userType, pageName) => {
    const pages = pageName.raw();

    for (let i = 0; i < pages.length; i++) {
      await menuPage.navigateToGenre(pages[i].toString());
      await this.getUserMenuItems(userType, pages[i].toString());
    }
  };

  selectEpisode = async (index) => {
    const episodeCards = await commons.findElements(this.episodeRail_lbl);

    await commons.waitUntil(episodeCards[index]);
    await commons.click(episodeCards[index]);
  };

  selectAndPlayVideo = async () => {
    const searchResult = await commons.findElement(
      this.visibleresultCardContent,
    );

    await commons.click(searchResult);

    const firstEpisode = await commons.findElement(this.first_episode);

    await commons.click(firstEpisode);
  };

  validateShowDetailPage = async () => {
    assert.equal(
      await commons.isDisplayed(this.showHero_img, 30),
      true,
      'Show hero image is not present',
      await commons.isDisplayed(this.watchNow_btn),
      true,
      'Watch now CTA button is not present',
    );
  };

  selectHeroItemFromHome = async () => {
    await commons.waitUntil(this.watchNow_btn);
    await commons.click(this.watchNow_btn);
    await commons.waitUntil(this.showHero_img, 30);
    await commons.waitUntil(this.watchNow_btn);
  };

  addShowToMylistFromContentDetailPage = async () => {
    await commons.waitUntil(this.myListCTA_btn, 5);
    await commons.hover(this.myListCTA_btn);
    if (await commons.isDisplayed(this.removeFromMylist_btn, 5)) {
      await commons.click(this.removeFromMylist_btn);
    }
    await commons.waitUntil(this.addToMyList_btn, 5);
    await commons.click(this.myListCTA_btn);
  };

  verifyHeroMyListCtaIsCheckmarkIcon = async () => {
    await commons.waitUntil(this.addedToMyList_txt);
    await commons.hover(this.myListCTA_btn);
    assert.equal(
      await commons.isDisplayed(this.addedMylistIcon_img),
      true,
      'check mark icon is not present',
    );
  };

  removeShowFromMyList = async () => {
    await commons.refreshPage();
    await commons.waitUntil(this.myListCTA_btn, 5);
    await commons.hover(this.myListCTA_btn);
    await commons.isDisplayed(this.removeMylistIcon_img);
    await commons.isDisplayed(this.removeFromMylist_btn, 10);
    await commons.click(this.removeFromMylist_btn);
  };

  verifyHeroMyListCtaIsPlusIcon = async () => {
    assert.equal(
      await commons.isDisplayed(this.addToMyList_btn, 10),
      true,
      'add to my list button is not present',
    );
    assert.equal(
      await commons.isDisplayed(this.addMylistIcon_img, 10),
      true,
      'plus icon is not present',
    );
  };

  verifyMLToast = async (toastType) => {
    if (toastType === 'Added to My List') {
      const addToMLToast = await commons.getText(
        this.addToMylistToastMessage_txt,
      );

      assert.equal(toastType, addToMLToast);
    } else if (toastType === 'Removed from My List') {
      const removeFromMLToast = await commons.getText(
        this.removeMylistToastMessage_txt,
      );

      assert.equal(toastType, removeFromMLToast);
    }
  };
}

module.exports = new ShowDetailsPage();
