const browserName = process.env.BROWSER || 'Chrome';
const browserVersion = process.env.BROWSER_VERSION;
const geo = ['US', 'Us', 'us'].includes(process.env.GEO) ? '' : process.env.GEO;
const os = process.env.PREFERRED_OS;
const project = process.env.BS_PROJECT;
const name = process.env.NAME;
const build = process.env.BUILD;
const debug = process.env.DEBUG || true;
const osVersion = process.env.OS_VERSION;
const deviceName = process.env.DEVICE_NAME;
const autoAcceptAlerts = process.env.AUTO_ACCEPT_ALERTS || false;

const commonCapabilities = {
  'bstack:options': {
    userName: process.env.BS_USER,
    accessKey: process.env.BS_KEY,
    debug,
    geoLocation: geo,
    timezone: 'London',
    networkLogs: true,
    idleTimeout: 300,
    local: false,
    projectName: project,
    sessionName: name,
    buildName: build,
    networkLogsExcludeHosts: [
      'dplus-uk.media-edge.prod-vod.h264.io',
      'dplus-uk-prod-vod.akamaized.net',
    ],
    networkLogsOptions: {
      captureContent: true,
    },
  },
};

const browserCapabilities = {
  browserName,
  browser_version: browserVersion,
  os,
  autoAcceptAlerts,
  acceptInsecureCerts: true,
  acceptSslCerts: true,
  w3c: true,
  'profile.default_content_setting_values.geolocation': 2,
  credentials_enable_service: false,
  'goog:chromeOptions': {
    args: ['incognito', 'start-maximized', 'ignore-certificate-errors'],
  },
};

const browserCapabilitiesForAdtech = {
  browserName,
  browser_version: browserVersion,
  os,
  autoAcceptAlerts,
  acceptInsecureCerts: true,
  acceptSslCerts: true,
  w3c: true,
  'profile.default_content_setting_values.geolocation': 2,
  credentials_enable_service: false,
  'goog:chromeOptions': {
    args: ['start-maximized', 'ignore-certificate-errors'],
  },
};

const mobileBrowserCapabilities = {
  browserName,
  osVersion,
  deviceName,
  realMobile: true,
  autoAcceptAlerts: true,
  local: true,
};

const desiredWebCapabilities = () => {
  const source = deviceName ? mobileBrowserCapabilities : browserCapabilities;

  return Object.assign(commonCapabilities, source);
};

const desiredWebCapabilitiesForAdtech = () => {
  const source = deviceName
    ? mobileBrowserCapabilities
    : browserCapabilitiesForAdtech;

  return Object.assign(commonCapabilities, source);
};

module.exports = {
  desiredWebCapabilities,
  desiredWebCapabilitiesForAdtech,
};
