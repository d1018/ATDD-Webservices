const { mapGeoLocation } = require('@wbd/gqa-regional-routing/src/maplocation');

const localExecution = process.env.LOCAL_EXECUTION === 'true';
const appPackage = process.env.DTC_ANDROID_APP_PACKAGE;
const appActivity = process.env.APP_ACTIVITY;
const udid = process.env.UDID;
const autoAcceptAlerts = process.env.AUTO_ACCEPT_ALERTS === 'true';
const geo = process.env.GEO || 'us';

const hsAndroidTVCapabilities = {
  'headspin:selector': 'device_skus:"AndroidTV 4K"',
  'headspin:capture.video': true,
  'headspin:network.regionalRouting': mapGeoLocation(geo, 'headspin'),
};

const androidTVCapabilities = {
  deviceName: 'AndroidTV',
  automationName: 'Appium',
  platformName: 'Android',
  appPackage,
  appActivity,
  udid,
  newCommandTimeout: 130,
  autoAcceptAlerts,
};

const desiredAndroidTVCapabilities = localExecution
  ? androidTVCapabilities
  : Object.assign(androidTVCapabilities, hsAndroidTVCapabilities);

module.exports = { desiredAndroidTVCapabilities };
