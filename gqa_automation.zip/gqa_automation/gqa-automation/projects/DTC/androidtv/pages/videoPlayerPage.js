const assert = require('assert');

const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;
const { AKC } = commons;

let showNameText;
let elapsedtimeText;

class VideoPlayerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('videoPlayerPage', locator);
  }

  playerPlay_btn = this.#getSelectorData('playerPlay_btn');

  playerPause_btn = this.#getSelectorData('playerPause_btn');

  playerProgress_bar = this.#getSelectorData('playerProgress_bar');

  videoContainerView = this.#getSelectorData('videoContainerView');

  video_player_title = this.#getSelectorData('video_player_title');

  player_subtitle_player = this.#getSelectorData('player_subtitle_player');

  player_position_time = this.#getSelectorData('player_subtitle_player');

  player_position = this.#getSelectorData('player_position_time');

  resume_btn = this.getElementByPage('showPage', 'resume_btn');

  getSubTitleOftheShow() {
    return showNameText;
  }

  setSubTitleOftheShow(showName) {
    showNameText = showName;
  }

  getPlayerTime() {
    return elapsedtimeText;
  }

  setPlayerTime(elapsedtime) {
    elapsedtimeText = elapsedtime;
  }

  /**
   * The below function will validate the player screen once the video will start playing.
   */

  isVideoPlaying = async () => {
    await commons.waitUntil(this.videoContainerView, 15);

    if (await commons.elementExists(this.playerPause_btn, 30)) {
      await commons.pressKeyCode(AKC.SELECT);
      assert(
        await commons.fetchAttributeData(this.playerPlay_btn, 'displayed'),
        'Play button is not displayed',
      );
    } else {
      await commons.pressKeyCode(AKC.SELECT);
      assert(
        await commons.fetchAttributeData(this.playerPause_btn, 'displayed'),
        'Pause button is not displayed',
      );
    }

    assert(
      await commons.fetchAttributeData(this.playerProgress_bar, 'displayed'),
      'Progress bar is not displayed',
    );
  };

  scrubVideo = async (percentage) => {
    let count = parseInt(percentage, 10) / 4;

    await commons.waitUntil(this.playerProgress_bar);
    await commons.pressKeyCode(AKC.DOWN);
    await commons.pressKeyCode(AKC.SELECT);
    await this.setSubTitleOftheShow(
      await commons.fetchAttributeData(this.video_player_title, 'Text'),
    );
    await commons.pressKeyCode(AKC.SELECT);

    while (count > 0) {
      await commons.pressKeyCode(AKC.MEDIA_FAST_FORWARD, 30);
      count--;
    }
    await commons.pressKeyCode(AKC.SELECT);
    await this.setPlayerTime(
      await commons.fetchAttributeData(this.player_position, 'Text'),
    );

    await commons.pressKeyCode(AKC.BACK);
    await commons.pressKeyCode(AKC.BACK);

    if (await commons.elementExists(this.resume_btn)) {
      await commons.pressKeyCode(AKC.BACK);
    }
  };

  validateResumePoint = async () => {
    const playerPauseTime = await this.getPlayerTime();
    const playerCurrentTime = await commons.fetchAttributeData(
      this.player_position,
      'text',
      50,
    );
    const pauseTime = playerPauseTime.replace(':', '.');
    const currentTime = playerCurrentTime.replace(':', '.');

    assert(
      currentTime <= pauseTime,
      `Resume video is not successful as the player position on resume is ${playerPauseTime} which is less than the player position after scrub ${playerCurrentTime}`,
    );
    await commons.pressKeyCode(AKC.BACK);
    await commons.pressKeyCode(AKC.BACK);
  };
}
module.exports = new VideoPlayerPage();
