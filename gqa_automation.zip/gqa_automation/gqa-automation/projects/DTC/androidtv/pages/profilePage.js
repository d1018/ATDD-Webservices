const assert = require('assert');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const menuPage = require('./menuPage');

const commons = mobileActions;
const { AKC } = commons;

let newProfileName;
let profileLength = 0;
let profileCountBeforeDeletion = 0;

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  whoIsWatching_lbl = this.#getSelectorData('whoIsWatching_lbl');

  focusedFirstProfileImage = this.#getSelectorData('focusedFirstProfileImage');

  focusedNamedProfileImage = this.#getSelectorData('focusedNamedProfileImage');

  profileName_lbl = this.#getSelectorData('profileName_lbl');

  profileList = this.#getSelectorData('profileList');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  profileImage = this.getElementByPage('homePage', 'profileImage');

  homeButton = this.getElementByPage('homePage', 'homeButton');

  accountTitle_lbl = this.getElementByPage('accountPage', 'accountTitle_lbl');

  editProfile_txtBx = this.#getSelectorData('editProfile_txtBx');

  focusedButton = this.getElementByPage('homePage', 'focusedButton');

  kidsProfileSection = this.#getSelectorData('kidsProfileSection');

  listOfAllProfiles = this.#getSelectorData('listOfAllProfiles');

  dynamicProfileName_lbl = this.#getSelectorData('dynamicProfileName_lbl');

  pinProfile_txt = this.#getSelectorData('pinProfile_txt');

  kidsProfileToggle = this.#getSelectorData('kidsProfileToggle');

  save_btn = this.#getSelectorData('save_btn');

  goToFirstProfile = async () => {
    await commons.waitUntil(this.whoIsWatching_lbl);
    await commons.tryUntil(this.focusedFirstProfileImage, 'LEFT', 5, 3);
  };

  goToNamedProfile = async (profileName) => {
    const focusedNamedProfile = this.getCustomLocator(
      this.focusedNamedProfileImage,
      profileName,
    );

    await commons.tryUntil(focusedNamedProfile, 'RIGHT', 8, 3);
  };

  selectProfile = async (profileName) => {
    if (!(await commons.elementExists(this.whoIsWatching_lbl, 30))) {
      await menuPage.navigateToProfilePage();
    }
    await this.goToFirstProfile();
    await this.goToNamedProfile(profileName);
    await commons.pressKeyCode(AKC.SELECT);
    if (profileName === 'Pin') {
      await commons.waitUntil(this.pinProfile_txt);
      await commons.pressKeyCode(AKC.SELECT);
      for (let i = 0; i < 2; i++) {
        await commons.pressKeyCode(AKC.RIGHT);
        await commons.pressKeyCode(AKC.SELECT);
      }
      for (let i = 0; i < 2; i++) {
        await commons.pressKeyCode(AKC.LEFT);
      }
      await commons.pressKeyCode(AKC.DOWN);
      await commons.pressKeyCode(AKC.SELECT);
    }
    await commons.waitUntil(this.profileImage);
  };

  /**
   * Below function is used to create a new profile and select:
   *
   *@param {string} profileName name of the profile to be created
   */

  createNewProfileandSelect = async (profileName) => {
    if (!(await commons.elementExists(this.whoIsWatching_lbl, 30))) {
      await menuPage.navigateToProfilePage();
    }
    const profileCheck = await this.checkProfileIfExists(profileName);

    if (profileCheck === true) {
      await this.deleteProfile(profileName);
    }
    newProfileName = profileName;
    await this.createNewProfile(profileName);
    await this.selectProfile(profileName);
    await commons.waitUntil(this.forYou_lbl);
  };

  /**
   * Below function is used to check whether a profile is already existing in the profiles section:
   * 1) If profile is displayed, it returns value as true
   * 2) If profile is not displayed, then it returns the value as false
   *
   *@param {string} profileName name of the profile to be checked on the app
   * @returns {boolean} availability status of the profile
   */
  checkProfileIfExists = async (profileName) => {
    const requiredProfileName = this.getCustomLocator(
      this.profileName_lbl,
      profileName,
    );
    const result = await commons.elementExists(requiredProfileName, 25);

    return result;
  };

  /**
   * Below function is used to delete a profile , standard , kids or random . Anything except Default can be deleted
   * If in Kids profile, it will switch to Default and then deletes created kids profile
   *
   *@param {string} profileName name of the profile to be deleted
   */
  deleteProfile = async (profileName) => {
    let profileNames = [];
    let randomProfileName;

    profileNames = await this.getListOfProfiles();
    profileCountBeforeDeletion = profileNames.length;

    if (!profileNames.includes(profileName)) {
      [randomProfileName] = profileNames;
      await this.goToFirstProfile();
      await this.goToNamedProfile(randomProfileName);
    } else if (profileName.includes('Kids')) {
      await this.selectProfile('Default');
      await menuPage.navigateToProfilePage();
      await this.goToFirstProfile();
      await this.goToNamedProfile(profileName);
    } else {
      await this.goToFirstProfile();
      await this.goToNamedProfile(profileName);
    }

    await commons.pressKeyCode(AKC.DOWN);
    await commons.pressKeyCode(AKC.SELECT);

    await commons.pressKeyCode(AKC.UP);
    await commons.pressKeyCode(AKC.ENTER);

    const cancelButton = this.getCustomLocator(this.focusedButton, 'Cancel');

    await commons.waitUntil(cancelButton);

    await commons.pressKeyCode(AKC.UP);
    await commons.pressKeyCode(AKC.SELECT);

    assert(
      await commons.elementExists(this.whoIsWatching_lbl, 25),
      `User not directed back to Who's Watching`,
    );
  };

  /**
   * Below function is used to create a new profile and it works in following way:
   * 1) Post login, it opens manage profiles screen and checks if Add profile option is available
   * 2) If Add profile is displayed, it adds a new profile prefixing with Standard, Kids
   * 3) If Add profile is not displayed, then it deletes any random profile and creates new profile
   *
   * @param {string} profileName is the name of new profile to be created
   */
  createNewProfile = async (profileName) => {
    await this.moveToAddProfileAndSelect();

    const editProfile = this.getCustomLocator(
      this.editProfile_txtBx,
      'Profile',
    );

    assert(
      await commons.fetchAttributeData(editProfile, 'focused'),
      'Edit profile name text box is not focused',
    );

    await commons.sendText(editProfile, profileName);
    if (profileName.includes('Kids')) {
      await commons.pressKeyCode(AKC.ENTER);
      await commons.pressKeyCode(AKC.ENTER);

      assert(
        await commons.elementExists(this.kidsProfileSection, 25),
        'Kids profile section is not available',
      );

      await commons.pressKeyCode(AKC.DOWN);

      await commons.pressKeyCode(AKC.SELECT);
    } else {
      await commons.pressKeyCode(AKC.ENTER);
      await commons.pressKeyCode(AKC.DOWN);
      await commons.pressKeyCode(AKC.ENTER);
    }
    assert(
      await commons.elementExists(this.whoIsWatching_lbl, 25),
      `User not directed back to Who's Watching`,
    );
  };

  /**
   *The below function navigates to Add profile icon and selects it . If AddProfile icon is not displayed a random profile is deleted and then
   * Add profile is selected
   *
   */

  moveToAddProfileAndSelect = async () => {
    const isAddProfileDisplayed = await this.checkProfileIfExists(
      'Add Profile',
    );

    if (!isAddProfileDisplayed) {
      await this.deleteProfile('random');
      await this.goToFirstProfile();
    }
    await this.goToNamedProfile('Add Profile');
    await commons.pressKeyCode(AKC.SELECT);
  };

  /**
   * Below function is used to create a new profile and selects it by calling createNewProfileandSelect function
   *
   * @param {string} profileType as Standard, Kids
   */
  profileCreation = async (profileType) => {
    if (profileType === 'Pin') {
      newProfileName = profileType;
      await this.selectProfile(profileType);
    } else {
      await this.createNewProfileandSelect(profileType);
    }
  };

  /**
   *The below function deletes an existing profile.
   *
   */

  deleteExistingProfile = async () => {
    if (!(await commons.elementExists(this.whoIsWatching_lbl, 25))) {
      await menuPage.navigateToProfilePage();
    }
    if (newProfileName === 'Pin') {
      const listOfprofiles = await this.getListOfProfiles();

      assert(listOfprofiles.includes(newProfileName));
    } else {
      await this.deleteProfile(newProfileName);
    }
  };

  getListOfProfiles = async () => {
    let individualProfileName;
    const profileNames = [];
    const elements = await commons.findElements(this.listOfAllProfiles, 25);

    profileLength = await elements.length;
    for (let i = 0; i < profileLength; i++) {
      individualProfileName = await commons.fetchAttributeData(
        elements[i],
        'text',
      );
      if (
        !individualProfileName.includes('Default') &&
        individualProfileName !== 'Add Profile'
      ) {
        profileNames.push(individualProfileName);
      }
    }
    return profileNames;
  };

  /**
   * The profile count fetched from above function will be used here as comparison pre & post delete to ensure deletion is successful
   */
  verifyUserProfileDeleted = async () => {
    const profileNames = await this.getListOfProfiles();
    const profileCountAfterDeletion = profileNames.length;

    assert(
      profileCountBeforeDeletion > profileCountAfterDeletion,
      `Deletion of profiles is not successful`,
    );
  };

  navigateToManageProfiles = async () => {
    if (!(await commons.elementExists(this.whoIsWatching_lbl, 25))) {
      await menuPage.navigateToProfilePage();
    }
  };

  selectProfileToManage = async () => {
    await this.goToFirstProfile();

    await this.moveToAddProfileAndSelect();
  };

  /**
   * Verify elements in the edit profile page
   */
  verifyEditProfilePage = async () => {
    const pageTitle = this.getCustomLocator(
      this.profileName_lbl,
      'Create Profile',
    );

    assert(
      await commons.elementExists(pageTitle, 25),
      'User did not land on Create Profile Screen',
    );
    const editProfile = this.getCustomLocator(
      this.editProfile_txtBx,
      'Profile',
    );

    assert(
      await commons.fetchAttributeData(editProfile, 'focused'),
      'Edit profile name text box is not focused',
    );

    const familyProfile = this.getCustomLocator(
      this.profileName_lbl,
      'Family Profile',
    );

    assert(
      await commons.elementExists(familyProfile, 25),
      'Family profile label does not exist',
    );

    assert(
      await commons.elementExists(this.kidsProfileToggle, 25),
      'Toggle does not exist for kids profile',
    );

    assert(
      await commons.elementExists(this.save_btn, 25),
      'Save button not available in Edit Profile',
    );
  };

  /**
   * Below function is used to enter profileNames to verify error messages .
   * Currently in AndroidTV when we enter a profile name > 30 characters , it automatically truncates to 30 characters .
   * For the case of > 30 characters we are currently just asserting if the Save button exists
   *
   * @param {string} name is the name of new profile to be created
   */
  changeProfileName = async (name) => {
    const editProfile = this.getCustomLocator(
      this.editProfile_txtBx,
      'Profile',
    );

    if (name === '') {
      await commons.pressKeyCode(AKC.ENTER);
    } else if (name === 'ThisIsANameThatIsLongerThanThirtyCharacters') {
      assert(
        await commons.elementExists(this.save_btn, 25),
        'Save button not available in Edit Profile',
      );
    } else if (name === 'Default') {
      await commons.sendText(
        editProfile,
        `${testdataHelper.getContent(`editProfileLander.validProfileName`)}`,
      );
    }
  };

  /**
   * Below function verifies error messages for profile names of different lengths
   *
   * @param {string} err is the error message to be verified
   */
  verifyErrorMessage = async (err) => {
    if (
      err ===
      'Length of profile name must be from 1 to 30 characters. Please try again.'
    ) {
      const profileErrorMsg = this.getCustomLocator(this.profileName_lbl, err);

      await commons.waitUntil(profileErrorMsg);
    } else if (err === 'Maximum 30 characters') {
      /* Currently in AndroidTV when we enter a profile name > 30 characters , it automatically truncates to 30 characters .
      and the above error message is not displayed. We wil currently just perform Back operation for this case only */
      await commons.pressKeyCode(AKC.BACK);
    } else {
      assert(
        await commons.fetchAttributeData(this.save_btn, 'focused'),
        'Save button is not focused',
      );

      await commons.pressKeyCode(AKC.ENTER);
      await commons.pressKeyCode(AKC.DOWN);
      await commons.pressKeyCode(AKC.ENTER);
      assert(
        await commons.elementExists(this.whoIsWatching_lbl, 25),
        `User not directed back to Who's Watching`,
      );
      await this.deleteProfile(
        `${testdataHelper.getContent(`editProfileLander.validProfileName`)}`,
      );
    }
  };
}

module.exports = ProfilePage;
