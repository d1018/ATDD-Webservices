const assert = require('assert');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');

const commons = mobileActions;
const { AKC } = commons;

let searchText;

let searchText2;

let newResult;

class SearchPage extends BasePage {
  getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  search_txtBx = this.getSelectorData('search_txtBx');

  searchBar = this.getSelectorData('searchBar');

  searchedShowTitle_lbl = this.getSelectorData('searchedShowTitle_lbl');

  searchTabFocused_lbl = this.getSelectorData('searchTabFocused_lbl');

  showLogo_lbl = this.getElementByPage('showDetailsPage', 'showLogo_lbl');

  searchEdit_txtBx = this.getSelectorData('searchEdit_txtBx');

  searchTitles = this.getSelectorData('searchTitles');

  videoContainerView = this.getElementByPage(
    'videoPlayerPage',
    'videoContainerView',
  );

  collectionTitle_lbl = this.getElementByPage(
    'collectionDetailsPage',
    'collectionTitle_lbl',
  );

  firstThumbnailOnSearch = this.getSelectorData('firstThumbnailOnSearch');

  focusedSearchPage = this.getSelectorData('focusedSearchPage');

  subMenuItems = this.getSelectorData('subMenuItems');

  searchText = async (text) => {
    searchText = testdataHelper.getContent(`searchPage.${text}`);
    await commons.sendText(this.search_txtBx, searchText);
  };

  verifyResultsIncludeSearchText = async () => {
    const searchedShowTitle = this.getCustomLocator(
      this.searchedShowTitle_lbl,
      searchText,
    );

    await commons.waitUntil(searchedShowTitle);
  };

  verifySearchTabsLanding = async (tabName) => {
    if (tabName === 'Shows') {
      await commons.waitUntil(this.showLogo_lbl);
    } else if (
      tabName === 'Episodes' ||
      tabName === 'Extras' ||
      tabName === 'Specials'
    ) {
      await commons.waitUntil(this.videoContainerView);
    } else {
      await commons.waitUntil(this.collectionTitle_lbl);
    }
  };

  verifyLandingPageBasedOnContent = async () => {
    const searchTabs = testdataHelper.getContent('searchPage.searchResultTabs');

    for (let i = 0; i < searchTabs.length; i++) {
      const searchTab = this.getCustomLocator(
        this.searchTabFocused_lbl,
        searchTabs[i],
      );

      await commons.waitUntil(searchTab);
      await commons.pressKeyCode(AKC.DOWN);
      await commons.waitUntil(this.firstThumbnailOnSearch);
      await commons.pressKeyCode(AKC.SELECT);
      await this.verifySearchTabsLanding(searchTabs[i]);
      await commons.pressKeyCode(AKC.BACK);
      await commons.waitUntil(this.searchBar);
      await commons.pressKeyCode(AKC.UP);

      /* Verify search tabs displayed */
      await commons.waitUntil(searchTab);
      await commons.pressKeyCode(AKC.RIGHT);
    }
  };

  verifySearchedContentAndItsLandingPage = async () => {
    await this.verifyResultsIncludeSearchText();
    await this.verifyLandingPageBasedOnContent();
  };

  /**
   * This search method will be used when we have show name available
   *
   * @param {string} showName specifies the show to be searched
   */
  searchShow = async (showName) => {
    assert(
      await commons.elementExists(this.focusedSearchPage),
      'Search page is not found',
    );
    await commons.pressKeyCode(AKC.UP);
    await commons.sendText(this.search_txtBx, showName);
  };

  addToExistingQuery = async () => {
    const isSearchFocused = await commons.fetchAttributeData(
      this.searchEdit_txtBx,
      'focused',
    );
    const subMenuItems = await commons.findElements(this.subMenuItems, 10);

    const isSubMenuFocused = await commons.fetchAttributeData(
      subMenuItems[1],
      'focused',
    );

    if (isSearchFocused && isSubMenuFocused) {
      await commons.pressKeyCode(AKC.UP);
      await commons.pressKeyCode(AKC.UP);
    } else if (!isSearchFocused && isSubMenuFocused) {
      await commons.pressKeyCode(AKC.UP);
    }

    assert(isSearchFocused, 'Search is not focused');

    searchText2 = `${searchText} C`;

    await commons.sendText(this.searchEdit_txtBx, searchText2);

    const results = await commons.findElements(this.searchTitles, 20);

    newResult = await commons.fetchAttributeData(results[1], 'text');
  };

  validateUpdatedSearchResult = async () => {
    await commons.waitUntil(this.searchTitles);
    assert.notEqual(searchText, newResult, 'assert does not match');
  };
}

module.exports = new SearchPage();
