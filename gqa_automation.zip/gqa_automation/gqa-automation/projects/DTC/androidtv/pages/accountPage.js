const assert = require('assert');
const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const ProfilePage = require('./profilePage');
const menuPage = require('./menuPage');
const OnboardingPage = require('./onboardingPage');

const commons = mobileActions;
const profilePage = new ProfilePage();
const onboardingPage = new OnboardingPage();

const { AKC } = commons;

class AccountPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('accountPage', locator);
  }

  account_lbl = this.#getSelectorData('account_lbl');

  about_lbl = this.#getSelectorData('about_lbl');

  help_lbl = this.#getSelectorData('help_lbl');

  signOut_lbl = this.#getSelectorData('signOut_lbl');

  accountTitle_lbl = this.#getSelectorData('accountTitle_lbl');

  confirmCancel_btn = this.#getSelectorData('confirmCancel_btn');

  focusedSignOut_lbl = this.#getSelectorData('focusedSignOut_lbl');

  manageAccountPageOnNavbar = this.#getSelectorData(
    'manageAccountPageOnNavbar',
  );

  aboutPageOnNavbar = this.#getSelectorData('aboutPageOnNavbar');

  helpPageOnNavbar = this.#getSelectorData('helpPageOnNavbar');

  signOutPageOnNavbar = this.#getSelectorData('signOutPageOnNavbar');

  choosePlan_btn = this.getElementByPage('onboardingPage', 'choosePlan_btn');

  chooseYourPlan_txt = this.getElementByPage('menuPage', 'chooseYourPlan_txt');

  accountPageSubMenu = {
    Account: this.account_lbl,
    About: this.about_lbl,
    Help: this.help_lbl,
    'Sign Out': this.signOut_lbl,
  };

  KidsAccountPageSubMenu = {
    About: this.about_lbl,
    Help: this.help_lbl,
  };

  accountSubNavigationPageFocused = {
    Account: this.manageAccountPageOnNavbar,
    About: this.aboutPageOnNavbar,
    Help: this.helpPageOnNavbar,
    'Sign Out': this.signOutPageOnNavbar,
  };

  /**
   * On the basis of user type(Anonymous, Default, Kids), the below function will confirm Account Sub Menu list length accordingly.
   */

  getUserAccountMenuItems = (profileName) => {
    const accountType = {
      Anonymous: 'anonymousUserAccountItemList',
      Default: 'defaultUserAccountItemList',
      Kids: 'kidsUserAccountItemList',
    };

    return testdataHelper.getContent(`accountPage.${accountType[profileName]}`);
  };

  /**
   * The below function will verify the Account sub menu list based on user type (Anonymous, Default, Kids).
   */

  verifyAccountPage = async (profileName) => {
    const accountElements =
      profileName === 'Kids'
        ? this.KidsAccountPageSubMenu
        : this.accountPageSubMenu;

    if (profileName !== 'Anonymous') {
      await profilePage.selectProfile(profileName);
    }
    await menuPage.navigateToPage('Account');

    const accountMenuList = await this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < Object.keys(accountElements).length; i++) {
      if (!accountMenuList.includes(Object.keys(accountElements)[i])) {
        throw new Error(
          `Selector does not exist for ${Object.keys(accountElements)[i]}`,
        );
      }
      await commons.waitUntil(
        this.accountPageSubMenu[Object.keys(accountElements)[i]],
      );
    }
  };

  /**
   * The below function will navigate to the account sub menu pages and verify based on user type (Anonymous, Default, Kids).
   */

  verifyAccountSubNavigationPage = async (profileName) => {
    const accountElements =
      profileName === 'Kids'
        ? this.KidsAccountPageSubMenu
        : this.accountPageSubMenu;
    const accountMenuList = await this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < Object.keys(accountElements).length; i++) {
      if (!accountMenuList.includes(Object.keys(accountElements)[i])) {
        throw new Error(
          `Selector does not exist for ${Object.keys(accountElements)[i]}`,
        );
      }
      await commons.click(
        await this.accountPageSubMenu[Object.keys(accountElements)[i]],
      );
      await commons.waitUntil(
        await this.accountSubNavigationPageFocused[
          Object.keys(this.accountPageSubMenu)[i]
        ],
      );
      await commons.clickBack();
    }
  };

  validateCtaAccountPage = async () => {
    await menuPage.navigateToPage('Account');
    await commons.waitUntil(this.signInOnVOD_btn);
    await commons.waitUntil(this.signUpOnVOD_btn);
  };

  validateInactiveSubscriptionPage = async () => {
    await onboardingPage.verifyInactiveSubscriptionScreen();
  };

  selectSubscribe = async () => {
    await commons.waitUntil(this.choosePlan_btn);
    await commons.pressKeyCode(AKC.SELECT);
  };

  validateProductPickerPage = async () => {
    assert(
      await commons.elementExists(this.chooseYourPlan_txt, 20),
      'text does not exit',
    );
  };

  selectAdultProfile = async () => {};

  selectFooter = async (label) => {
    await commons.waitUntil(this.accountTitle_lbl);
    if (label === 'Sign Out') {
      await commons.tryUntil(this.focusedSignOut_lbl, 'RIGHT', 6, 2);
      await commons.pressKeyCode(AKC.DOWN);
      await commons.pressKeyCode(AKC.SELECT);
    }
  };

  selectCancelCTA = async () => {
    await commons.waitUntil(this.confirmCancel_btn);
    await commons.pressKeyCode(AKC.SELECT);
  };

  verifySignOutPage = async () => {
    await commons.waitUntil(this.accountTitle_lbl);
    assert(
      (await commons.elementExists(this.about_lbl, 10)) &&
        (await commons.elementExists(this.signOut_lbl), 10),
      'User is not navigated to previous page',
    );
  };
}

module.exports = AccountPage;
