const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');
const menuPage = require('./menuPage');

const commons = mobileActions;

const { AKC } = commons;

class MyListPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myListPage', locator);
  }

  noSavedShow_txt = this.#getSelectorData('noSavedShow_txt');

  browserShows_btn = this.#getSelectorData('browserShows_btn');

  focusedMyList_btn = this.#getSelectorData('focusedMyList_btn');

  allBrowserScreen_txt = this.#getSelectorData('allBrowserScreen_txt');

  myListAddShow_btn = this.#getSelectorData('myListAddShow_btn');

  myListShow_txt = this.#getSelectorData('myListShow_txt');

  framePoster = this.#getSelectorData('framePoster');

  searchedShowTitle_lbl = this.getElementByPage(
    'searchPage',
    'searchedShowTitle_lbl',
  );

  focusedMenuBar = this.getElementByPage('menuPage', 'focusedMenuBar');

  sideNavBar = this.getElementByPage('menuPage', 'sideNavBar');

  focusedWatchNow_btn = this.getElementByPage(
    'showPage',
    'focusedWatchNow_btn',
  );

  focusedWatch_btn = this.getElementByPage('showPage', 'focusedWatch_btn');

  startWatching_btn = this.getElementByPage('homePage', 'startWatching_btn');

  /**
   * The below function will add show to mylist from the Mylist screen
   */
  addShowsToMylistFromBrowse = async () => {
    await menuPage.navigateToPage('My List');
    await commons.waitUntil(this.noSavedShow_txt, 50);
    await commons.waitUntil(this.browserShows_btn, 50);
    await commons.pressKeyCode(AKC.SELECT);
    const showListElement = await commons.findElements(
      this.allBrowserScreen_txt,
      10,
    );

    await commons.clickElement(showListElement[0]);
    if (
      (await commons.elementExists(this.startWatching_btn)) ||
      (await commons.elementExists(this.focusedWatchNow_btn)) ||
      (await commons.elementExists(this.focusedWatch_btn))
    ) {
      await commons.tryUntil(this.focusedMyList_btn, 'RIGHT', 5, 1);
    } else {
      await commons.tryUntil(this.focusedMyList_btn, 'LEFT', 5, 1);
    }

    await commons.waitUntil(this.focusedMyList_btn);
    await commons.pressKeyCode(AKC.SELECT);
    while (!(await commons.elementExists(this.sideNavBar)))
      await commons.pressKeyCode(AKC.BACK);
  };

  /**
   * The below function will remove shows from Mylist screen
   */
  removeShowFromMyListPage = async () => {
    if (!(await commons.elementExists(this.noSavedShow_txt, 10))) {
      const totalShows = await commons.findElements(this.framePoster, 10);

      for (let i = 0; i < totalShows.length; i++) {
        await commons.pressKeyCode(AKC.SELECT);
        await commons.tryUntil(this.focusedMyList_btn, 'LEFT', 5, 1);
        await commons.waitUntil(this.focusedMyList_btn);
        await commons.pressKeyCode(AKC.SELECT);
        await commons.pressKeyCode(AKC.BACK);
        if (await commons.elementExists(this.noSavedShow_txt, 10)) {
          break;
        }
      }
    }
  };

  /**
   * The below function will verify the MyList Rail
   *
   * @param {boolean} isRailPresent - MyList Rail status true or false
   */
  verifyShowsInMyList = async (isRailPresent) => {
    await menuPage.navigateToPage('My List');
    if (isRailPresent) {
      assert(
        await commons.elementExists(this.myListShow_txt),
        `Show displayed in Mylist Screen`,
      );
    } else {
      assert(
        !(await commons.elementExists(this.myListShow_txt)),
        `No Show displayed in Mylist Screen`,
      );
    }
  };
}

module.exports = new MyListPage();
