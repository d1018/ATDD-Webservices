const assert = require('assert');
const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const HomePage = require('./homePage');

const commons = mobileActions;
const { AKC } = commons;

const homePage = new HomePage();

let networkTitle1 = '';
let networkTitle2 = '';

class NetworkLandingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('networkLandingPage', locator);
  }

  networkRail = this.#getSelectorData('networkRail');

  networkLogo = this.#getSelectorData('networkLogo');

  rfy_Rail_lbl = this.#getSelectorData('rfy_Rail_lbl');

  newEpisode_Rail_lbl = this.#getSelectorData('newEpisode_Rail_lbl');

  network_img = this.getElementByPage('homePage', 'network_img');

  networkRail_Title = this.#getSelectorData('networkRail_Title');

  listRowTitle = this.getElementByPage('homePage', 'listRowTitle');

  networkHeroBanner = this.#getSelectorData('networkHeroBanner');

  showName_lbl = this.getElementByPage('showPage', 'showName_lbl');

  /**
   * The below function will switch on Entertainment and Sports network channel
   *
   * @param {*} network will select Entertainment and Sports Network
   */
  selectAndValidateNetworkLandingPage = async (network) => {
    if (network === 'Entertainment') {
      await this.validateEntertainmentNetworkLandingPage();
    } else if (network === 'Sports' && this.countryCode === 'gb') {
      await commons.clickBack();
    }
  };

  /**
   * The below fuction will select and  validate the Entertainment Network Landing Page
   */
  validateEntertainmentNetworkLandingPage = async () => {
    await this.navigateToSelectNetwork(
      testdataHelper.getContent(`networkPage.foodNetworkRail`),
    );
    await this.validateAuthenticatedEntertainmentContent();
  };

  /**
   * The below fuction will validate Entertainment content
   */
  validateAuthenticatedEntertainmentContent = async () => {
    await commons.waitUntil(this.networkLogo);
    await homePage.verifyRailPresent(
      testdataHelper.getContent(`networkPage.RecommendedForYouRail`),
      true,
    );
    await homePage.verifyRailPresent(
      testdataHelper.getContent(`networkPage.newEpisodes`),
      true,
    );
    await homePage.verifyRailPresent(
      testdataHelper.getContent(`networkPage.likeRail`),
      true,
    );
    await commons.pressKeyCode(AKC.DOWN);
    await commons.waitUntil(this.networkRail);
  };

  /**
   * The below fuction will switch on Entertainment network channel
   *
   * @param {string} networkType specifies the network name
   */
  navigateToSelectNetwork = async (networkType) => {
    let i = 20;

    while (i > 0) {
      const heroTitleTxtFromScreen = await commons.fetchAttributeData(
        this.networkRail_Title,
        'text',
      );

      if (heroTitleTxtFromScreen === networkType) {
        await commons.pressKeyCode(AKC.SELECT);
        break;
      } else {
        await commons.pressKeyCode(AKC.RIGHT);
        i -= 1;
      }
    }
  };

  /**
   * The below function will verify network rail for kids profile user
   */
  verifyNetworkRailForKidsProfile = async () => {
    await homePage.scrollToNetworkRail();
    await homePage.validateNetworkRail();
    await this.navigateToSelectNetwork(
      testdataHelper.getContent(`networkPage.AnimalPlanet`),
    );
    await this.validateKidsAuthenticatedEntertainmentContent();
  };

  /**
   * The below function will validate Entertainment content
   */
  validateKidsAuthenticatedEntertainmentContent = async () => {
    await homePage.verifyRailPresent(
      testdataHelper.getContent(`networkPage.trendingRail`),
      true,
    );
    await homePage.verifyRailPresent(
      testdataHelper.getContent(`networkPage.tooCuteRail`),
      true,
    );
    await homePage.verifyRailPresent(
      testdataHelper.getContent(`networkPage.likeRail`),
      true,
    );
    await commons.pressKeyCode(AKC.DOWN);
    await commons.waitUntil(this.networkRail);
  };

  /**
   * The below function will select a network from the Network rail
   */
  selectNetworkLogo = async () => {
    await commons.pressKeyCode(AKC.SELECT);
    await commons.waitUntil(this.networkLogo);
    assert(await commons.elementExists(this.networkHeroBanner, 25));
    networkTitle1 = await commons.fetchAttributeData(this.showName_lbl, 'text');
  };

  /**
   * The below function will scroll to the bottom of network detail page and select a new network
   */
  scrollToNetworkRailAndSelectNetwork = async () => {
    await commons.waitUntil(this.networkLogo);
    let iteration = 0;

    do {
      await commons.pressKeyCode(AKC.DOWN);
      iteration++;
    } while (
      !(await commons.elementExists(this.network_img)) &&
      iteration < 20
    );

    await commons.pressKeyCode(AKC.DOWN);
    await commons.pressKeyCode(AKC.RIGHT);
    await commons.pressKeyCode(AKC.SELECT);
  };

  /**
   * The below function will validate navigation between network pages
   */
  validateNetworkPage = async () => {
    await commons.waitUntil(this.networkLogo);
    assert(await commons.elementExists(this.networkHeroBanner, 25));
    networkTitle2 = await commons.fetchAttributeData(this.showName_lbl, 'text');
    assert.notEqual(networkTitle1, networkTitle2, 'Network page not validated');
  };
}

module.exports = NetworkLandingPage;
