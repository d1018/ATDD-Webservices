const assert = require('assert');

const { BasePage, mobileActions } = require('./basePage');
const menuPage = require('./menuPage');
const SignInPage = require('./signInPage');

const commons = mobileActions;
const { AKC } = commons;
const signInPage = new SignInPage();

class WelcomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('welcomePage', locator);
  }

  welcomeTitle = this.#getSelectorData('welcomeTitle');

  signIn_btn = this.getElementByPage('signInPage', 'signIn_btn');

  focusedSignIn_btn = this.getElementByPage('signInPage', 'focusedSignIn_btn');

  subscribeNow = this.#getSelectorData('subscribe_btn');

  verifyWelcomeScreen = async () => {
    assert(
      await commons.elementExists(this.welcomeTitle),
      `WelcomeTitle is not displayed`,
    );
  };

  /**
   * Navigate CTA on WelcomeScreen
   *
   * @param {string} screenCTA -  Subscribe Now/Sign In
   */
  verifyLandingPageOfWelcomeScreen = async (screenCTA) => {
    const buttonsCTA = {
      'Subscribe Now': this.subscribeNow,
      'Sign In': this.signIn_btn,
    };

    assert(
      await commons.elementExists(buttonsCTA[screenCTA]),
      ` ${buttonsCTA[screenCTA]} is not displayed`,
    );
    if (screenCTA === 'Subscribe Now') {
      await commons.pressKeyCode(AKC.SELECT);
      await menuPage.validatePlanPickerPage();
    } else {
      await commons.tryUntil(this.focusedSignIn_btn, 'DOWN', 5, 1);
      await commons.pressKeyCode(AKC.SELECT);
      await signInPage.validateSignInPage();
    }
    await commons.pressKeyCode(AKC.BACK);
  };
}
module.exports = new WelcomePage();
