const assert = require('assert');

const { BasePage, mobileActions } = require('./basePage');
const ProfilePage = require('./profilePage');

const profilePage = new ProfilePage();
const {
  desiredAndroidTVCapabilities,
} = require('../capabilities/headspinCaps');

const commons = mobileActions;
const serverURL = process.env.SERVER_URL
  ? process.env.SERVER_URL.toLowerCase()
  : '';
const localExecution = process.env.LOCAL_EXECUTION === 'true' || false;
const { AKC } = commons;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  signIn_btn = this.#getSelectorData('signIn_btn');

  focusedSignIn_btn = this.#getSelectorData('focusedSignIn_btn');

  userName_txtBx = this.#getSelectorData('userName_txtBx');

  password_txtBx = this.#getSelectorData('password_txtBx');

  whoIsWatching_lbl = this.getElementByPage('profilePage', 'whoIsWatching_lbl');

  confirmSignOut_btn = this.getElementByPage(
    'accountPage',
    'confirmSignOut_btn',
  );

  confirmCancel_btn = this.getElementByPage('accountPage', 'confirmCancel_btn');

  openApp = async () => {
    commons.driverInit(serverURL, localExecution);
    await commons.openApp(desiredAndroidTVCapabilities);
    await commons.waitUntil(this.signIn_btn);
  };

  async hideKeyboard() {
    await commons.hideKeyboard();
  }

  async loginToApplication(credentialType) {
    const username = process.env[`${credentialType}_USERNAME`];
    const password = process.env[`${credentialType}_PASSWORD`];

    await commons.tryUntil(this.focusedSignIn_btn, 'DOWN', 3, 1);
    await commons.pressKeyCode(AKC.SELECT);
    await commons.sendText(this.userName_txtBx, username);
    await commons.sendText(this.password_txtBx, password);
    await this.hideKeyboard();
    await commons.tryUntil(this.focusedSignIn_btn, 'DOWN', 5, 1);
    await commons.pressKeyCode(AKC.SELECT);

    if (credentialType.includes('KIDS_PROFILE')) {
      await profilePage.goToFirstProfile();
      await profilePage.goToNamedProfile('Kids');
      await commons.pressKeyCode(AKC.SELECT);
    }
  }

  /**
   * Validate Sign In Page - Email & Password fields
   */
  validateSignInPage = async () => {
    assert(
      (await commons.elementExists(this.userName_txtBx)) &&
        (await commons.elementExists(this.password_txtBx)),
      `Sign In Page required attributes are not displayed`,
    );
  };

  /**
   * Validate user has signed out correctly
   */
  verifySignOut = async () => {
    assert(
      !(
        (await commons.elementExists(this.confirmSignOut_btn)) &&
        (await commons.elementExists(this.confirmCancel_btn))
      ),
      'Sign out elements are still present',
    );
    assert(
      (await commons.elementExists(this.userName_txtBx)) &&
        (await commons.elementExists(this.password_txtBx)),
      `Sign out was not successful`,
    );
  };
}

module.exports = SignInPage;
