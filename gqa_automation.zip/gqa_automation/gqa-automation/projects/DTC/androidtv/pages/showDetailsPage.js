const assert = require('assert');

const { BasePage, mobileActions } = require('./basePage');

const HomePage = require('./homePage');

const videoPlayerPage = require('./videoPlayerPage');

const homePage = new HomePage();

const commons = mobileActions;

const { AKC } = commons;

class ShowDetailsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('showPage', locator);
  }

  startWatching_btn = this.getElementByPage('showPage', 'startWatching_btn');

  watchNow_btn = this.getElementByPage('showPage', 'watchNow_btn');

  watch_btn = this.getElementByPage('showPage', 'watch_btn');

  exploreNow_btn = this.getElementByPage('showPage', 'exploreNow_btn');

  focusedStartWatch_btn = this.getElementByPage(
    'homePage',
    'startWatching_btn',
  );

  focusedWatchNow_btn = this.getElementByPage(
    'showPage',
    'focusedWatchNow_btn',
  );

  focusedExploreNow_btn = this.getElementByPage(
    'showPage',
    'focusedExploreNow_btn',
  );

  focusedWatch_btn = this.getElementByPage('showPage', 'focusedWatch_btn');

  addList_btn = this.getElementByPage('homePage', 'addList_btn');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  videoContainerView = this.getElementByPage(
    'videoPlayerPage',
    'videoContainerView',
  );

  resume_btn = this.#getSelectorData('resume_btn');

  myListAddShow_btn = this.getElementByPage('myListPage', 'myListAddShow_btn');

  showImage_img = this.getElementByPage('searchPage', 'showImage_img');

  firstThumbnailOnSearch = this.getElementByPage(
    'searchPage',
    'firstThumbnailOnSearch',
  );

  focusedWatchAndResume_cta = this.#getSelectorData(
    'focusedWatchAndResume_cta',
  );

  episodesList = {
    1: this.firstThumbnailOnSearch,
  };

  searchTabFocused_lbl = this.getElementByPage(
    'searchPage',
    'searchTabFocused_lbl',
  );

  validateCTAonGenres = async (userType, genreName) => {
    const pages = genreName.raw();

    for (let i = 0; i < pages.length; i++) {
      switch (pages[i].toString().toLowerCase()) {
        case 'for you':
          await commons.waitUntil(this.forYou_lbl, 20);
          break;
        case 'crime':
          await homePage.selectGenreTab('Crime');
          break;
        default:
      }

      assert(
        ((await commons.elementExists(this.startWatching_btn, 20)) ||
          (await commons.elementExists(this.watchNow_btn, 20)) ||
          (await commons.elementExists(this.exploreNow_btn, 20)) ||
          (await commons.elementExists(this.watch_btn, 20))) &&
          (await commons.elementExists(this.addList_btn, 5)),
        `Start Watching CTA and My list icon are not displayed`,
      );

      if (
        !(
          (await commons.elementExists(this.focusedStartWatch_btn)) ||
          (await commons.elementExists(this.focusedWatchNow_btn)) ||
          (await commons.elementExists(this.focusedExploreNow_btn)) ||
          (await commons.elementExists(this.focusedWatch_btn))
        )
      ) {
        await commons.pressKeyCode(AKC.DOWN);
      }
      await commons.pressKeyCode(AKC.SELECT);

      // Move to Play Button on show details page
      await homePage.moveToPlayVideoCTA();
      await commons.pressKeyCode(AKC.SELECT);

      // To check if video plays
      await videoPlayerPage.isVideoPlaying();
      await commons.pressKeyCode(AKC.BACK);
      await commons.waitUntil(this.myListAddShow_btn);
      await commons.pressKeyCode(AKC.BACK);
    }
  };

  selectAndPlayVideo = async (index) => {
    await commons.elementExists(this.showImage_img);
    const focusedLbl = await this.getCustomLocator(
      this.searchTabFocused_lbl,
      'Shows',
    );

    if (await commons.elementExists(focusedLbl, 20)) {
      await commons.pressKeyCode(AKC.DOWN);
    } else {
      await commons.pressKeyCode(AKC.DOWN);
      await commons.pressKeyCode(AKC.DOWN);
    }
    await commons.waitUntil(this.episodesList[index]);
    await commons.pressKeyCode(AKC.SELECT);
    if (await commons.elementExists(this.focusedWatchAndResume_cta, 20)) {
      await commons.pressKeyCode(AKC.SELECT);
    } else {
      await commons.tryUntil(this.focusedWatchAndResume_cta, 'LEFT', 5);
      await commons.pressKeyCode(AKC.SELECT);
    }
  };
}

module.exports = new ShowDetailsPage();
