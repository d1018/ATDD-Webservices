const { BasePage } = require('./basePage');

class PreLaunchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('preLaunchPage', locator);
  }

  async handlePopUps() {
    // TODO
  }

  async goToOnboardingScreen() {
    // TODO
  }

  async selectBrowseContentOption() {
    // TODO
  }
}

module.exports = new PreLaunchPage();
