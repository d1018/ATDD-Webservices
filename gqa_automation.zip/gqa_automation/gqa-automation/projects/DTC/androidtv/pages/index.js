const menuPage = require('./menuPage');
const welcomePage = require('./welcomePage');
const HomePage = require('./homePage');
const videoPlayerPage = require('./videoPlayerPage');
const browsePage = require('./browsePage');
const searchPage = require('./searchPage');
const showDetailsPage = require('./showDetailsPage');
const SignInPage = require('./signInPage');
const myListPage = require('./myListPage');
const NetworkLandingPage = require('./networkLandingPage');
const AccountPage = require('./accountPage');
const ProfilePage = require('./profilePage');
const OnboardingPage = require('./onboardingPage');

const signInPage = new SignInPage();
const profilePage = new ProfilePage();
const homePage = new HomePage();
const onboardingPage = new OnboardingPage();
const networkLandingPage = new NetworkLandingPage();
const accountPage = new AccountPage();

module.exports = {
  signInPage,
  profilePage,
  menuPage,
  welcomePage,
  homePage,
  videoPlayerPage,
  browsePage,
  searchPage,
  showDetailsPage,
  myListPage,
  networkLandingPage,
  onboardingPage,
  accountPage,
};
