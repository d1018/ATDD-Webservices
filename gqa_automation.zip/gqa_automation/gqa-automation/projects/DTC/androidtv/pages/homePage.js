const assert = require('assert');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const videoPlayerPage = require('./videoPlayerPage');
const menuPage = require('./menuPage');
const myListPage = require('./myListPage');
const searchPage = require('./searchPage');
const ProfilePage = require('./profilePage');

const profilePage = new ProfilePage();

const commons = mobileActions;

const { AKC } = commons;

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  watchNow_btn = this.getElementByPage('showPage', 'watchNow_btn');

  overlayRating = this.getElementByPage('showPage', 'overlayRating');

  nextEpisodeRating = this.getElementByPage('showPage', 'nextEpisodeRating');

  networkImage = this.getElementByPage('searchPage', 'networkImage');

  focusedHomePage = this.#getSelectorData('focusedHomePage');

  focusedMenuBar = this.getElementByPage('menuPage', 'focusedMenuBar');

  focusedMyList_btn = this.getElementByPage('myListPage', 'focusedMyList_btn');

  focusedTab = this.#getSelectorData('focusedTab');

  focusedButton = this.#getSelectorData('focusedButton');

  forYou_lbl = this.#getSelectorData('forYou_lbl');

  jipRail_txt = this.#getSelectorData('jipRail_txt');

  search_txtBx = this.getElementByPage('searchPage', 'search_txtBx');

  genre_lbl = this.#getSelectorData('genre_lbl');

  focusedRail = this.#getSelectorData('focusedRail');

  featureShow = this.#getSelectorData('featureShow');

  textHeroDescription = this.#getSelectorData('textHeroDescription');

  showName_lbl = this.getElementByPage('showPage', 'showName_lbl');

  rating_txt = this.#getSelectorData('rating_txt');

  addList_btn = this.#getSelectorData('addList_btn');

  addShow_btn = this.#getSelectorData('addShow_btn');

  startWatching_btn = this.#getSelectorData('startWatching_btn');

  exploreNow_btn = this.#getSelectorData('exploreNow_btn');

  playerProgress_bar = this.getElementByPage(
    'videoPlayerPage',
    'playerProgress_bar',
  );

  playerProgressBar_Standard = this.getElementByPage(
    'videoPlayerPage',
    'playerProgressBar_Standard',
  );

  videoContainerView = this.getElementByPage(
    'videoPlayerPage',
    'videoContainerView',
  );

  playerPlay_btn = this.getElementByPage('videoPlayerPage', 'playerPlay_btn');

  playerLiveLabel_lbl = this.getElementByPage(
    'videoPlayerPage',
    'playerLiveLabel_lbl',
  );

  playerPause_btn = this.getElementByPage('videoPlayerPage', 'playerPause_btn');

  searchedShowTitle_lbl = this.getElementByPage(
    'searchPage',
    'searchedShowTitle_lbl',
  );

  focusedWatchNow_btn = this.getElementByPage(
    'showPage',
    'focusedWatchNow_btn',
  );

  startWatching = this.getElementByPage('showPage', 'startWatching_btn');

  watch_btn = this.getElementByPage('showPage', 'watch_btn');

  focusedWatch_btn = this.getElementByPage('showPage', 'focusedWatch_btn');

  focusedSubNav_lbl = this.getElementByPage('browsePage', 'focusedSubNav_lbl');

  network_Rail = this.#getSelectorData('network_img');

  network_FirstTitle = this.#getSelectorData('network_FirstTitle');

  focusedResume_btn = this.getElementByPage('showPage', 'focusedResume_btn');

  resume_btn = this.getElementByPage('showPage', 'resume_btn');

  myListShow = this.#getSelectorData('myListShow');

  episodeInfo = this.getElementByPage('showPage', 'episodeInfo');

  listRowTitle = this.#getSelectorData('listRowTitle');

  imageShowLogo_cw = this.#getSelectorData('imageShowLogo_cw');

  textSecondaryTitle_cw = this.#getSelectorData('textSecondaryTitle_cw');

  player_position_time = this.getElementByPage(
    'videoPlayerPage',
    'player_position_time',
  );

  showsList = [
    testdataHelper.getContent('searchPage.myListShow1'),
    testdataHelper.getContent('searchPage.myListShow2'),
    testdataHelper.getContent('searchPage.multiContentShow'),
  ];

  showListDesc = [
    testdataHelper.getContent('searchPage.myListShow1Desc'),
    testdataHelper.getContent('searchPage.myListShow2Desc'),
    testdataHelper.getContent('searchPage.multiContentShowDesc'),
  ];

  signOutTab = this.getElementByPage('accountPage', 'signOutTab');

  signOut_btn = this.getElementByPage('accountPage', 'signOut_btn');

  confirmSignOut_btn = this.getElementByPage(
    'accountPage',
    'confirmSignOut_btn',
  );

  confirmCancel_btn = this.getElementByPage('accountPage', 'confirmCancel_btn');

  profileImage = this.getElementByPage('homePage', 'profileImage');

  whoIsWatching_lbl = this.getElementByPage('profilePage', 'whoIsWatching_lbl');

  verifyJIPVideoPlayback = async () => {
    if (await commons.elementExists(this.playerPause_btn, 30)) {
      await commons.pressKeyCode(AKC.SELECT);
      assert(
        await commons.fetchAttributeData(this.playerPlay_btn, 'displayed'),
        'Play button is not displayed',
      );
    }
    assert(
      await commons.fetchAttributeData(this.playerProgress_bar, 'displayed'),
      'Progress bar is not displayed',
    );
    assert(
      await commons.fetchAttributeData(this.playerLiveLabel_lbl, 'displayed'),
      'Live Label is not displayed',
    );
    await commons.pressKeyCode(AKC.BACK);
  };

  verifyJipContentPlayback = async (pageName) => {
    if (pageName === 'Home Page') {
      await this.scrollToRail('discovery+ Channels', true);
      await commons.pressKeyCode(AKC.SELECT);
      await this.verifyJIPVideoPlayback();
    } else if (pageName === 'Show Details Page') {
      await menuPage.navigateToPage('Search');
      await commons.sendText(
        this.search_txtBx,
        testdataHelper.getContent(`searchPage.JIPShowName`),
      );
      await commons.waitUntil(
        this.getCustomLocator(
          this.focusedTab,
          testdataHelper.getContent(`searchPage.JIPShowName`),
        ),
      );
      await commons.pressKeyCode(AKC.DOWN);
      await commons.pressKeyCode(AKC.SELECT);
      await this.scrollToRail('Channel', true);
      await commons.pressKeyCode(AKC.SELECT);
      await this.verifyJIPVideoPlayback();
    }
  };

  /**
   * Below function is used to scroll to a particular genre on home  page
   *
   * @param {string} genreName specifies the genre name
   */

  selectGenreTab = async (genreName) => {
    await commons.waitUntil(this.forYou_lbl);
    await commons.tryUntil(this.focusedHomePage, 'UP', 5);
    let genreTab;

    if (this.countryCode === 'us' && genreName === 'Crime') {
      genreTab = 'True Crime';
    } else {
      genreTab = 'Crime';
    }
    let i = 0;
    const crimeText = `Recommended in ${genreTab}`;
    const text = this.getCustomLocator(this.focusedTab, crimeText);

    while (!(await commons.elementExists(text, 5)) && i <= 5) {
      if (i !== 0) {
        await commons.pressKeyCode(AKC.UP);
      }
      await commons.pressKeyCode(AKC.RIGHT);

      i++;
    }
  };

  /**
   * Below function is used to check if video is playing
   * It checks for pause/play button and progress bar
   *
   */

  verifyVideoPlayed = async () => {
    await commons.waitUntil(this.featureShow);
    await commons.pressKeyCode(AKC.SELECT);
    await this.moveToPlayVideoCTA();

    await commons.pressKeyCode(AKC.SELECT);

    await videoPlayerPage.isVideoPlaying();
  };

  /**
   * The below function will verify Mylist rail present on Home Page
   *
   * @param {string} railName - rail name
   * @param {boolean} RailStatus - Rail status true or false
   */
  verifyMyListRailOnHomePage = async (railName, RailStatus) => {
    await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);
    await menuPage.navigateToPage('Home');
    await this.verifyRailPresent(railName, RailStatus);
  };

  /**
   * Below function checks availability of a rail on home page
   * It checks for pause/play button and progress bar
   *
   *  @param {string} railName specifies the rail name to be validated
   * @param {string} railStatus as true or false
   */

  scrollToRail = async (railName, railStatus = true) => {
    await this.verifyRailPresent(railName, railStatus);
  };

  /**
   * Below function is used to check rail availability
   * 1) Scroll to the rail mentioned in the railName parameter
   * 2) Validate the rail presence based on the value passed to railStatus field
   *
   * @param {string} railName specifies the rail name to be validated
   * @param {string} railStatus as true or false
   */
  verifyRailPresent = async (railName, railStatus) => {
    const railCheck = await this.scrollAndVerifyRailPresent(railName);

    assert.deepStrictEqual(
      railCheck,
      railStatus,
      'Rail Availability Status Mismtach',
    );
  };

  /**
   * Below function is used to scroll to a rail
   * 1) Break the loop and return true value if rail is already displayed
   * 2) If rail is not displayed then scroll down on the home page upto 15 tries
   * 3) If the rail is still not displayed then return false else return true
   *
   * @param {railName} railName is the header text of the rail available on the app
   */
  scrollAndVerifyRailPresent = async (railName) => {
    const railToVerify = this.getCustomLocator(this.focusedRail, railName);
    const text = [];

    for (let count = 0; count < 20; count++) {
      if (await commons.elementExists(railToVerify, 5)) {
        const rowTitles = await commons.findElements(this.listRowTitle, 7);

        if (rowTitles.length > 1) {
          for (let i = 0; i < rowTitles.length; i++) {
            text.push(await commons.fetchAttributeData(rowTitles[i], 'text'));
          }
          if (text[1] === railName) await commons.pressKeyCode(AKC.DOWN);
        }

        return true;
      }
      await commons.pressKeyCode(AKC.DOWN);
    }
    const myListRailDisplayed = await commons.findElements(railToVerify);

    return myListRailDisplayed.length > 0;
  };

  /**
   * Below function is used to search a show and to add the show to mylist
   *
   * @param {number} showCount specifies number of shows to be added to mylist
   */
  addShowToMyList = async (showCount) => {
    for (let i = 1; i <= showCount; i++) {
      await this.addOrRemoveShowFromMyList(this.showsList[i]);

      await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);
      await commons.pressKeyCode(AKC.DOWN);
    }
    await menuPage.navigateToPage('Home');
  };

  /**
   * Below function is used to add the show to mylist from the search page
   *
   * @param {string} showName specifies name of show to be added to mylist
   */

  addOrRemoveShowFromMyList = async (showName) => {
    await menuPage.navigateToPage('Search');
    await searchPage.searchShow(showName);
    const show = this.getCustomLocator(this.focusedTab, 'Shows');

    await commons.waitUntil(show);
    await commons.pressKeyCode(AKC.DOWN);
    await commons.pressKeyCode(AKC.DOWN);
    await commons.pressKeyCode(AKC.ENTER);
    if (
      (await commons.elementExists(this.startWatching_btn)) ||
      (await commons.elementExists(this.focusedWatchNow_btn)) ||
      (await commons.elementExists(this.focusedWatch_btn))
    ) {
      await commons.tryUntil(this.focusedMyList_btn, 'RIGHT', 5, 1);
    } else {
      await commons.tryUntil(this.focusedMyList_btn, 'LEFT', 5, 1);
    }

    await commons.waitUntil(this.focusedMyList_btn);
    await commons.pressKeyCode(AKC.SELECT);
    await commons.pressKeyCode(AKC.BACK);
  };

  /**
   * Below method validates metadata on the tiles available on the mylist rail
   * showCount specifies the number of tiles on which metadata has to be validated
   *
   * @param {string} showCount specifies number of tiles to validate
   */
  verifyMyListRailMetadata = async (showCount) => {
    await this.scrollToRail('My List', true);

    const images = await commons.findElements(this.myListShow);

    assert.strictEqual(
      images.length,
      parseInt(showCount, 10),
      ` No of shows in My List does not match`,
    );
  };

  /**
   * Validates the order of the shows available on mylist rail
   * The most recent one added should be on top of the mylist rail
   */
  verifyMyListRailShowOrder = async () => {
    const cardImages = await commons.findElements(this.myListShow);
    let episodeDetails = [];

    for (let i = 1; i <= cardImages.length; i++) {
      await commons.pressKeyCode(AKC.SELECT);
      await commons.waitUntil(this.watchNow_btn);
      episodeDetails.push(
        await commons.fetchAttributeData(this.episodeInfo, 'text'),
      );
      await commons.pressKeyCode(AKC.BACK);
      if (i < cardImages.length) {
        await commons.pressKeyCode(AKC.RIGHT);
      }
    }
    episodeDetails = episodeDetails.reverse();
    for (let i = 0; i < episodeDetails.length; i++) {
      assert.deepStrictEqual(
        episodeDetails[i],
        this.showListDesc[i + 1],
        `Episode descriptions do not match`,
      );
    }
  };

  /**
   * below function removes a show from the mylist rail
   *
   * @param {string} showName specifies the name of the show to be removed from mylist
   */
  removeFromMyList = async (showName) => {
    const show = await testdataHelper.getContent(`searchPage.${showName}`);

    await this.addOrRemoveShowFromMyList(show);
    await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);
    await menuPage.navigateToPage('Home');
    await this.verifyMyListRailMetadata(1);
  };

  /**
   * below function removes Home Hero show in mylist
   */
  removedShowFromMylistFromHomeHero = async () => {
    await menuPage.navigateToPage('Home');
    if (await this.focusedHomePage) {
      await commons.pressKeyCode(AKC.DOWN);
    }
    await commons.tryUntil(this.focusedMyList_btn, 'RIGHT', 5, 1);
    await commons.pressKeyCode(AKC.SELECT);
  };

  /**
   * The below function will verify the MyList Rail
   *
   * @param {boolean} isRailPresent - MyList Rail status true or false
   */
  verifyShowsInMyListRail = async (isRailPresent) => {
    await menuPage.navigateToPage('Home');
    await this.verifyRailPresent('My List', isRailPresent);
  };

  /**
   * The below function will add shows from home hero using Mylist Button
   */
  addShowToMylistFromHomeHero = async () => {
    await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);
    await menuPage.navigateToPage('My List');
    await myListPage.removeShowFromMyListPage();
    await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);
    await menuPage.navigateToPage('Home');
    await commons.pressKeyCode(AKC.DOWN);
    await commons.tryUntil(this.focusedMyList_btn, 'RIGHT', 5, 1);
    await commons.pressKeyCode(AKC.SELECT);
  };

  /**
   * The below function will compare the shows on Mylist with two Profile's
   */
  verifyMyListShowAvailability = async () => {
    await profilePage.selectProfile('Standard');
    await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);
    await menuPage.navigateToPage('My List');
    await commons.pressKeyCode(AKC.SELECT);
    const standardProfileShow = await commons.fetchAttributeData(
      this.episodeInfo,
      'text',
    );

    await commons.pressKeyCode(AKC.BACK);

    await profilePage.selectProfile('Kids');

    await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);
    await menuPage.navigateToPage('My List');
    await commons.pressKeyCode(AKC.SELECT);
    const kidsProfileShow = await commons.fetchAttributeData(
      this.episodeInfo,
      'text',
    );

    assert(standardProfileShow !== kidsProfileShow, `show title is duplicated`);
  };

  verifyKidsContentPopulated = async () => {
    const rating = await commons.fetchAttributeData(this.rating_txt, 'text');

    assert.equal(rating, 'TV-G', 'Kids content is not displayed');

    const isKidsContentDisplayed = await this.searchContent('kids');

    assert(
      isKidsContentDisplayed,
      `Kids content is not shown on the kids search screen`,
    );

    await commons.pressKeyCode(AKC.DOWN);
    await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);

    const isAdultContentDisplayed = await this.searchContent('adult');

    assert(
      !isAdultContentDisplayed,
      `A rated content is shown on the kids search screen`,
    );
    await commons.pressKeyCode(AKC.DOWN);
  };

  verifyJIPContent = async () => {
    await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);
    const isJIPContentDisplayed = await this.searchContent('JIP');

    assert(
      !isJIPContentDisplayed,
      `JIP content is shown on the kids search screen`,
    );
    await commons.pressKeyCode(AKC.DOWN);
  };

  searchContent = async (contentType) => {
    let isContentDisplayed = true;

    await menuPage.navigateToPage('Search');

    if (contentType === 'adult') {
      await searchPage.searchShow(
        testdataHelper.getContent(`searchPage.adultShowName`),
      );
      const adultContent = this.getCustomLocator(
        this.searchedShowTitle_lbl,
        testdataHelper.getContent(`searchPage.adultShowName`),
      );

      isContentDisplayed = await commons.elementExists(adultContent, 10);
    } else if (contentType === 'JIP') {
      await searchPage.searchShow(
        testdataHelper.getContent(`searchPage.JIPShowName`),
      );
      const JIPContent = this.getCustomLocator(
        this.searchedShowTitle_lbl,
        testdataHelper.getContent(`searchPage.JIPShowName`),
      );

      isContentDisplayed = await commons.elementExists(JIPContent, 10);
    } else if (contentType === 'kids') {
      await searchPage.searchShow(
        testdataHelper.getContent(`searchPage.kidsShowName`),
      );
      const kidsContent = this.getCustomLocator(
        this.searchedShowTitle_lbl,
        testdataHelper.getContent(`searchPage.kidsShowName`),
      );

      isContentDisplayed = await commons.elementExists(kidsContent, 10);
    }
    return isContentDisplayed;
  };

  signOut = async () => {
    await commons.waitUntil(this.forYou_lbl, 30);
    await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);
    await menuPage.navigateToPage('Account');
    await commons.tryUntil(this.signOut_btn, 'RIGHT', 5, 1);
    await commons.pressKeyCode(AKC.DOWN);
    await commons.elementExists(this.signOut_btn);
    await commons.pressKeyCode(AKC.SELECT);
    assert(
      (await commons.elementExists(this.confirmSignOut_btn)) &&
        (await commons.elementExists(this.confirmCancel_btn)),
      'Sign out elements are not present',
    );
    await commons.pressKeyCode(AKC.UP);
    await commons.pressKeyCode(AKC.SELECT);
  };

  /**
   * The below function will validate Network rail
   */
  validateNetworkRail = async () => {
    await commons.waitUntil(this.network_Rail);
    if (!(await commons.elementExists(this.network_FirstTitle))) {
      await commons.pressKeyCode(AKC.DOWN);
    }
    await commons.waitUntil(this.network_FirstTitle);
  };

  /**
   * The below function will scroll to network rail
   */
  scrollToNetworkRail = async () => {
    await commons.waitUntil(this.forYou_lbl);

    const text = this.getCustomLocator(
      this.focusedTab,
      testdataHelper.getContent('homePage.discoveryNetwork'),
    );

    await commons.tryUntil(text, 'DOWN', 5, 2);
  };

  validateCurrentRating = (currentRating) => {
    assert(
      testdataHelper.getContent('ratingList').includes(currentRating),
      `Rating is not as per rating standards`,
    );
  };

  moveToPlayVideoCTA = async () => {
    if (await commons.elementExists(this.resume_btn)) {
      await commons.tryUntil(this.focusedResume_btn, 'LEFT', 5, 1);
    } else if (await commons.elementExists(this.startWatching)) {
      await commons.tryUntil(this.startWatching_btn, 'LEFT', 5, 1);
    } else if (await commons.elementExists(this.watchNow_btn)) {
      await commons.tryUntil(this.focusedWatchNow_btn, 'LEFT', 5, 1);
    } else {
      await commons.tryUntil(this.focusedWatch_btn, 'LEFT', 5, 1);
    }
  };

  /**
   * This function will validate ageRating and Content on multiple Screens
   */

  verifyAgeRatingAndContentDescriptors = async (screensType) => {
    switch (screensType) {
      case 'Main Hero':
        await commons.waitUntil(this.forYou_lbl);
        this.validateCurrentRating(
          await commons.fetchAttributeData(this.rating_txt, 'text', 10),
        );
        break;

      case 'Show Details Page':
        await menuPage.navigateToPage('Search');
        await searchPage.searchText('ratingShow');
        await commons.waitUntil(this.networkImage);
        await commons.pressKeyCode(AKC.DOWN);
        await commons.pressKeyCode(AKC.ENTER);
        this.validateCurrentRating(
          await commons.fetchAttributeData(this.rating_txt, 'text', 10),
        );
        break;

      case 'Currently Playing Episode':
        await this.moveToPlayVideoCTA();
        await commons.pressKeyCode(AKC.SELECT);
        this.validateCurrentRating(
          await commons.fetchAttributeData(this.overlayRating, 'text', 10),
        );
        await commons.pressKeyCode(AKC.BACK);
        break;

      case 'Next Episodes listed on Episode Landing Page':
        await commons.tryUntil(this.nextEpisodeRating, 'DOWN', 3, 1);
        this.validateCurrentRating(
          await commons.fetchAttributeData(this.nextEpisodeRating, 'text', 10),
        );
        break;

      default:
        break;
    }
  };

  validateCTAonPages = async (userType, pageName) => {
    const pages = pageName.raw();

    for (let i = 0; i < pages.length; i++) {
      switch (pages[i].toString().toLowerCase()) {
        case 'home':
          await commons.waitUntil(this.forYou_lbl);
          if (
            !(
              (await commons.elementExists(this.startWatching_btn)) ||
              (await commons.elementExists(this.exploreNow_btn)) ||
              (await commons.elementExists(this.focusedResume_btn))
            )
          ) {
            await commons.pressKeyCode(AKC.DOWN);
          }
          await commons.pressKeyCode(AKC.SELECT);
          await this.validateCTAForUser(userType);
          break;
        case 'search':
          await menuPage.navigateToPage('Search');
          await searchPage.searchText('multiContentShow');
          await commons.waitUntil(this.networkImage);
          await commons.pressKeyCode(AKC.DOWN);
          await commons.pressKeyCode(AKC.ENTER);
          await this.validateCTAForUser(userType);
          break;
        case 'sports':
          if (this.countryCode === 'gb') {
            await menuPage.navigateToPage('Sports');
            await this.scrollAndVerifyRailPresent(
              this.railsList.SportsDocumentaries,
            );
            await commons.scrollToElement(
              this.firstShowOnSportsDocumentaries,
              'down',
            );
            await this.selectShow('FirstShowOnSportsDocumentaries');
          }
          break;
        case 'browse':
          if (this.countryCode === 'us') {
            await menuPage.navigateToPage('Browse');
            await commons.waitUntil(this.focusedSubNav_lbl, 20);
            await commons.pressKeyCode(AKC.DOWN);
            await commons.pressKeyCode(AKC.DOWN);
            await commons.pressKeyCode(AKC.SELECT);
            await this.validateCTAForUser(userType);
          }
          break;
        default:
      }

      await commons.pressKeyCode(AKC.BACK);
    }
  };

  /**
   * Below function is used to validate CTAs for different users
   *
   * @param {string} userType the CTA validation for user type
   */
  validateCTAForUser = async (userType) => {
    if (userType.toLowerCase() === 'anonymous') {
      await commons.waitUntil(this.signUp_btn);
    } else {
      assert(
        (await commons.elementExists(this.addShow_btn, 20)) ||
          ((await commons.elementExists(this.addList_btn, 20)) &&
            (await commons.elementExists(this.resume_btn, 5))) ||
          (await commons.elementExists(this.startWatching_btn, 5)) ||
          (await commons.elementExists(this.watchNow_btn, 5)),
        `Start Watching CTA and My list icon are not displayed`,
      );
    }
  };

  verifyContinueWatchingMetadata = async () => {
    const subtitleVideo = await videoPlayerPage.getSubTitleOftheShow();

    const subtitleCw = await commons.fetchAttributeData(
      this.textSecondaryTitle_cw,
      'text',
      10,
    );

    assert(
      subtitleCw.includes(subtitleVideo),
      'continue watching show name is not matching',
    );
  };

  resumeAndPlayVideo = async () => {
    await commons.waitUntil(this.playerProgressBar_Standard);
    await commons.pressKeyCode(AKC.SELECT);
    await commons.pressKeyCode(AKC.DOWN);
    await commons.pressKeyCode(AKC.SELECT);
  };

  verifyHomepage = async () => {
    assert(
      (await commons.elementExists(this.profileImage)) &&
        (await commons.elementExists(this.forYou_lbl)) &&
        !(await commons.elementExists(this.whoIsWatching_lbl, 10)),
      `Element Mismatch`,
    );
  };
}

module.exports = HomePage;
