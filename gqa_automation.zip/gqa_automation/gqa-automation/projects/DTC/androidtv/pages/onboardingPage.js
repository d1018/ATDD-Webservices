const assert = require('assert');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');

const commons = mobileActions;

class OnboardingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('onboardingPage', locator);
  }

  activationText = this.#getSelectorData('activationText');

  inactiveTitle = this.#getSelectorData('inactiveTitle');

  choosePlan_btn = this.#getSelectorData('choosePlan_btn');

  signOut_btn = this.#getSelectorData('signOut_btn');

  whoIsWatching_lbl = this.getElementByPage('profilePage', 'whoIsWatching_lbl');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  exit_btn = this.getElementByPage('exitPage', 'exit_btn');

  signIn_btn = this.getElementByPage('signInPage', 'signIn_btn');

  userName_txtBx = this.getElementByPage('signInPage', 'userName_txtBx');

  /**
   *
   * @param {string} CTAType takes input  as either Sign in Or Sign Up CTA and selects that option
   */
  selectCTA = async (CTAType) => {
    const buttonsCTA = {
      Back: 'BACK',
    };

    if (await commons.elementExists(this.forYou_lbl, 60)) {
      await commons.tryUntil(this.exit_btn, buttonsCTA[CTAType], 5);
    }
  };

  verifyInactiveSubscriptionScreen = async () => {
    assert(
      !(
        (await commons.elementExists(this.forYou_lbl)) ||
        (await commons.elementExists(this.whoIsWatching_lbl))
      ),
    );
    assert(
      (await commons.elementExists(this.inactiveTitle)) &&
        (await commons.elementExists(this.choosePlan_btn)) &&
        (await commons.elementExists(this.signOut_btn)),
      'Elements are not present',
    );

    const fetchTitle = await commons.fetchAttributeData(
      this.activationText,
      'text',
      5,
    );
    const lapsedText = testdataHelper.getContent(`onboardingPage.lapsedText`);

    assert(fetchTitle.includes(lapsedText));
  };

  verifySuccessfulLogin = async () => {
    assert(
      !(
        (await commons.elementExists(this.userName_txtBx, 10)) ||
        (await commons.elementExists(this.signIn_btn, 10))
      ) && (await commons.elementExists(this.forYou_lbl)),
      `Element Mismatch`,
    );
  };
}

module.exports = OnboardingPage;
