const assert = require('assert');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const menuPage = require('./menuPage');

const ProfilePage = require('./profilePage');

const profilePage = new ProfilePage();

const commons = mobileActions;
const { AKC } = commons;

class BrowsePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('browsePage', locator);
  }

  focusedBrowsePage = this.#getSelectorData('focusedBrowsePage');

  focusedSubNav_lbl = this.#getSelectorData('focusedSubNav_lbl');

  showName_lbl = this.#getSelectorData('showName_lbl');

  subNav_lbl = this.#getSelectorData('subNav_lbl');

  subNav2_lbl = this.#getSelectorData('subNav2_lbl');

  networkLogoRail = this.#getSelectorData('networkLogoRail');

  networkIcon = this.#getSelectorData('networkIcon');

  networkImage = this.#getSelectorData('networkImage');

  watchNow_btn = this.getElementByPage('showPage', 'watchNow_btn');

  listIcon_btn = this.getElementByPage('showPage', 'listIcon_btn');

  whoIsWatching_lbl = this.getElementByPage('profilePage', 'whoIsWatching_lbl');

  /**
   * The below function will select a page from global Navigation menu
   *
   * @param {string} pageType will select a page
   */

  selectPage = async (pageType) => {
    if (this.countryCode === 'us' && pageType === 'Browse') {
      if (await commons.elementExists(this.whoIsWatching_lbl, 30)) {
        await profilePage.selectProfile('Default');
      }

      await menuPage.navigateToPage(pageType);
    }
  };

  /**
   * The below function will verify items that are focussed by default in the networkRail and subNav menu
   *
   */

  verifyBrowsePage = async () => {
    assert(
      (await commons.elementExists(this.focusedBrowsePage)) &&
        (await commons.fetchAttributeData(this.focusedSubNav_lbl, 'displayed')),
      'All and Trending subNav are not highlighted by default',
    );
  };

  /**
   * The below function will select a network from the network rail in browse page and validate menu items that are focused by default
   *
   * @param {string} networkType will select a network
   */

  selectNetwork = async (networkType) => {
    if (this.countryCode === 'us' && networkType === 'Entertainment') {
      await commons.isDisplayed(this.networkLogoRail, 5);
      await commons.pressKeyCode(AKC.RIGHT);
      await commons.pressKeyCode(AKC.SELECT);
      await this.verifyShowOnSelectedNetwork();
      assert(
        (await commons.fetchAttributeData(
          this.focusedSubNav_lbl,
          'displayed',
        )) &&
          (await commons.fetchAttributeData(this.subNav_lbl, 'displayed')) &&
          (await commons.fetchAttributeData(this.subNav2_lbl, 'displayed')),
        'Default subNav is not selected and other subNav options are not displayed',
      );
    }
  };

  /**
   * The below function will verify show on selected network
   */

  verifyShowOnSelectedNetwork = async () => {
    const show = this.getCustomLocator(
      this.showName_lbl,
      testdataHelper.getContent(`browsePage.entertainmentShowName`),
    );

    assert(
      await commons.fetchAttributeData(show, 'displayed'),
      `Show is not displayed`,
    );
  };

  /**
   * The below function will select a subNavigation menu item and validate the title , image and networkIcon are displayed
   *
   * @param {string} subNav will select subNav menu item
   */

  selectSubNav = async (subNav) => {
    if (this.countryCode === 'us' && subNav === 'first') {
      await commons.pressKeyCode(AKC.DOWN);
      await commons.pressKeyCode(AKC.RIGHT);

      const show = this.getCustomLocator(
        this.showName_lbl,
        testdataHelper.getContent(`browsePage.subNavShow`),
      );

      assert(
        (await commons.elementExists(show, 5)) &&
          (await commons.elementExists(this.networkIcon, 5)) &&
          (await commons.elementExists(this.networkImage, 5)),
        `Show title, icon and image are not displayed`,
      );
    }
  };

  /**
   * The below function will open a show from Browse page and validate the CTAs
   */

  verifyShowCard = async () => {
    await commons.pressKeyCode(AKC.DOWN);
    await commons.pressKeyCode(AKC.SELECT);
    assert(
      (await commons.elementExists(this.watchNow_btn, 5)) &&
        (await commons.elementExists(this.listIcon_btn, 5)),
      'Watch Now button and Add to List Icon are not present',
    );
  };
}

module.exports = new BrowsePage();
