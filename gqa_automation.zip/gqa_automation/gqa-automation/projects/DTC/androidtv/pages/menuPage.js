const assert = require('assert');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');

const commons = mobileActions;
const { AKC } = commons;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  focusedMenuBar = this.#getSelectorData('focusedMenuBar');

  menu_lbl = this.#getSelectorData('menu_lbl');

  startWatching_btn = this.getElementByPage('homePage', 'startWatching_btn');

  focusedMenuItem = this.#getSelectorData('focusedMenuItem');

  focussedExit_btn = this.getElementByPage('exitPage', 'focussedExit_btn');

  accountMenu_lbl = this.#getSelectorData('accountMenu_lbl');

  searchMenu_lbl = this.#getSelectorData('searchMenu_lbl');

  homeMenu_lbl = this.#getSelectorData('homeMenu_lbl');

  browseMenu_lbl = this.#getSelectorData('browseMenu_lbl');

  sportsMenu_lbl = this.#getSelectorData('sportsMenu_lbl');

  showsMenu_lbl = this.#getSelectorData('showsMenu_lbl');

  tvGuideMenu_lbl = this.#getSelectorData('tvGuideMenu_lbl');

  myListMenu_lbl = this.#getSelectorData('myListMenu_lbl');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  focusedBrowsePage = this.getElementByPage('browsePage', 'focusedBrowsePage');

  focusedSportsPage = this.getElementByPage('sportsPage', 'focusedSportsPage');

  focusedShowsPage = this.getElementByPage('showPage', 'focusedShowsPage');

  focusedTvGuidePage = this.getElementByPage(
    'tvGuidePage',
    'focusedTvGuidePage',
  );

  focusedMyListPage = this.getElementByPage('myListPage', 'focusedMyListPage');

  focusedSearchPage = this.getElementByPage('searchPage', 'focusedSearchPage');

  focusedAccountPage = this.getElementByPage(
    'accountPage',
    'focusedAccountPage',
  );

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  switchProfilesImg = this.getElementByPage('homePage', 'switchProfilesImg');

  whoIsWatching_lbl = this.getElementByPage('profilePage', 'whoIsWatching_lbl');

  chooseYourPlan = this.#getSelectorData('chooseYourPlan_txt');

  exit_btn = this.getElementByPage('exitPage', 'exit_btn');

  cancel_btn = this.getElementByPage('exitPage', 'cancel_btn');

  menuItem = {
    Home: this.homeMenu_lbl,
    Browse: this.browseMenu_lbl,
    'TV Guide': this.tvGuideMenu_lbl,
    Sports: this.sportsMenu_lbl,
    Shows: this.showsMenu_lbl,
    Search: this.searchMenu_lbl,
    Account: this.accountMenu_lbl,
    'My List': this.myListMenu_lbl,
  };

  pageFocused = {
    Home: this.focusedHomePage,
    Browse: this.focusedBrowsePage,
    Sports: this.focusedSportsPage,
    Shows: this.focusedShowsPage,
    'TV Guide': this.focusedTvGuidePage,
    'My List': this.focusedMyListPage,
    Search: this.focusedSearchPage,
    Account: this.focusedAccountPage,
  };

  openMenu = async () => {
    await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);
  };

  closeMenu = async () => {
    await commons.pressKeyCode(AKC.RIGHT);
  };

  menuList = testdataHelper.getContent('menuNavigationPage.loggedInMenu');

  /**
   *
   * @param {string} str - Input String
   * @returns {string} - Convert string to Title Case
   */
  toTitleCase = (str) =>
    str
      .toLowerCase()
      .split(' ')
      .map((word) => word.replace(word[0], word[0].toUpperCase()))
      .join(' ');

  /**
   * The below function will verify the navigation menu list based on user type (Anonymous, Default, Kids).
   */
  verifyMenuList = async () => {
    await this.openMenu();

    const menuItemText = await commons.fetchAttributeData(
      this.focusedMenuItem,
      'text',
    );

    for (let i = 0; i < 5; i++) {
      assert.strictEqual(
        await commons.elementExists(
          this.getCustomLocator(this.menu_lbl, menuItemText),
        ),
        true,
        `${menuItemText} is not present!`,
      );
      await commons.pressKeyCode(AKC.DOWN);
    }
    await this.closeMenu();
  };

  /**
   * The below function will navigate to a particular page from global navigation menu.
   *
   * @param {string} pageValue will navigate to a page
   */

  navigateToPage = async (pageValue) => {
    if (!(await commons.elementExists(this.focusedMenuItem, 40))) {
      await this.openMenu();
    }
    const menuItemText = this.toTitleCase(
      await commons.fetchAttributeData(this.focusedMenuItem, 'text'),
    );

    const focusedIndex = this.menuList.indexOf(menuItemText);
    const moveToIndex = this.menuList.indexOf(pageValue);
    const difference = focusedIndex - moveToIndex;

    for (let i = 0; i < Math.abs(difference); i++) {
      if (difference < 0) {
        await commons.pressKeyCode(AKC.DOWN);
      } else {
        await commons.pressKeyCode(AKC.UP);
      }
    }

    await commons.pressKeyCode(AKC.SELECT);
    assert.strictEqual(
      await commons.elementExists(this.pageFocused[pageValue]),
      true,
      `${pageValue} is not focused!`,
    );
  };

  /**
   * The below function will verify the menuItems in the global navigation list.
   */
  verifyGlobalNavigation = async () => {
    await this.openMenu();

    for (let i = 0; i < this.menuList.length; i++) {
      await this.navigateToPage(this.menuList[i]);
      await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);
    }
  };

  accessGlobalNavigationMenu = async () => {
    await this.openMenu();
  };

  /**
   * Validate PlanPickerPage
   */
  validatePlanPickerPage = async () => {
    assert(
      await commons.elementExists(this.chooseYourPlan),
      `Choose your plan is not displayed`,
    );
  };

  assertPage = async (pageValue) => {
    if (pageValue === 'Home') {
      assert(
        (await commons.elementExists(this.forYou_lbl, 20)) ||
          (await commons.elementExists(this.startWatching_btn)),
        `Home page not displayed`,
      );
    } else {
      await commons.waitUntil(this.pageFocused[pageValue], 20);
    }
  };

  navigateToProfilePage = async () => {
    if (!(await commons.elementExists(this.focusedMenuItem))) {
      await commons.tryUntil(this.focusedMenuBar, 'LEFT', 7, 1);
    }
    await commons.tryUntil(this.switchProfilesImg, 'UP', 7, 5);
    await commons.pressKeyCode(AKC.SELECT);
    await commons.waitUntil(this.whoIsWatching_lbl);
  };

  verifyExitConfirmation = async () => {
    assert(
      (await commons.elementExists(this.exit_btn, 30)) &&
        (await commons.elementExists(this.cancel_btn, 30)),
      `Exit page not displayed`,
    );
  };

  verifyAppBehavior = async (cta) => {
    switch (cta) {
      case 'Back':
        if (await commons.elementExists(this.exit_btn, 20)) {
          await commons.pressKeyCode(AKC.BACK);
        }
        break;
      case 'Cancel':
        assert(
          await commons.elementExists(this.forYou_lbl, 10),
          'Action failed',
        );
        await commons.pressKeyCode(AKC.BACK);
        assert(await commons.elementExists(this.exit_btn, 10), 'Action failed');
        await commons.pressKeyCode(AKC.SELECT);
        break;
      case 'Exit':
        assert(
          await commons.elementExists(this.forYou_lbl, 10),
          'Action failed',
        );
        await commons.pressKeyCode(AKC.BACK);
        assert(await commons.elementExists(this.exit_btn, 10), 'Action failed');
        await commons.tryUntil(this.focussedExit_btn, 'UP', 5);
        await commons.pressKeyCode(AKC.SELECT);
        break;
      default:
        break;
    }
  };
}

module.exports = new MenuPage();
