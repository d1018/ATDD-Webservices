const AndroidTvSignInPage = require('../../androidtv/pages/signInPage');

const { mobileActions } = require('./basePage');

const commons = mobileActions;
const serverURL = process.env.SERVER_URL
  ? process.env.SERVER_URL.toLowerCase()
  : '';
const localExecution = process.env.LOCAL_EXECUTION === 'true' || false;

const { desiredFireTvCapabilities } = require('../capabilities/headspinCaps');

// Example if you want to extend or modify a page for firetv
class SignInPage extends AndroidTvSignInPage {
  async hideKeyboard() {
    // No-op for firetv for current scenarios.
    // Will need to update in future tests
    // due to lack of support in driver.isKeyboardShown()
  }

  openApp = async () => {
    commons.driverInit(serverURL, localExecution);
    await commons.openApp(desiredFireTvCapabilities);
    await commons.waitUntil(this.signIn_btn);
  };
}

module.exports = new SignInPage();
