const assert = require('assert');
const AndroidTvHomePage = require('../../androidtv/pages/homePage');

const menuPage = require('../../androidtv/pages/menuPage');
const profilePage = require('./profilePage');

const { mobileActions } = require('./basePage');

const commons = mobileActions;
const { AKC } = commons;

class HomePage extends AndroidTvHomePage {
  verifyMyListShowAvailability = async () => {
    await profilePage.selectProfile('Standard');

    await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);
    await menuPage.navigateToPage('My List');
    await commons.pressKeyCode(AKC.SELECT);
    const standardProfileShow = await commons.fetchAttributeData(
      this.episodeInfo,
      'text',
    );

    await commons.pressKeyCode(AKC.BACK);

    await profilePage.selectProfile('Kids');

    await commons.tryUntil(this.focusedMenuBar, 'LEFT', 5, 1);
    await menuPage.navigateToPage('My List');
    await commons.pressKeyCode(AKC.SELECT);
    const kidsProfileShow = await commons.fetchAttributeData(
      this.episodeInfo,
      'text',
    );

    assert(standardProfileShow !== kidsProfileShow, `show title is duplicated`);
  };
}

module.exports = new HomePage();
