const AndroidTvProfilePage = require('../../androidtv/pages/profilePage');
const menuPage = require('../../androidtv/pages/menuPage');

const { mobileActions } = require('./basePage');

const commons = mobileActions;
const { AKC } = commons;

class ProfilePage extends AndroidTvProfilePage {
  selectProfile = async (profileName) => {
    if (!(await commons.elementExists(this.whoIsWatching_lbl, 30))) {
      await menuPage.navigateToProfilePage();
    }
    await this.goToFirstProfile();
    await this.goToNamedProfile(profileName);
    await commons.pressKeyCode(AKC.SELECT);
    if (profileName === 'Pin') {
      await commons.waitUntil(this.pinProfile_txt);
      await commons.pressKeyCode(AKC.SELECT);
      for (let i = 0; i < 2; i++) {
        await commons.pressKeyCode(AKC.RIGHT);
        await commons.pressKeyCode(AKC.SELECT);
      }
      for (let i = 0; i < 2; i++) {
        await commons.pressKeyCode(AKC.LEFT);
      }
      await commons.pressKeyCode(AKC.DOWN);
      await commons.pressKeyCode(AKC.SELECT);
    } else if (profileName === ('Default' || 'Standard' || 'Kids')) {
      await commons.pressKeyCode(AKC.LEFT);
      await commons.pressKeyCode(AKC.SELECT);
    }
    await commons.waitUntil(this.forYou_lbl);
  };
}

module.exports = new ProfilePage();
