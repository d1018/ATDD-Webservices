// Use androidtv pages by default
const menuPage = require('../../androidtv/pages/menuPage');
const browsePage = require('../../androidtv/pages/browsePage');
const searchPage = require('../../androidtv/pages/searchPage');
const myListPage = require('../../androidtv/pages/myListPage');
const welcomePage = require('../../androidtv/pages/welcomePage');
const showDetailsPage = require('../../androidtv/pages/showDetailsPage');
const videoPlayerPage = require('../../androidtv/pages/videoPlayerPage');
const OnboardingPage = require('../../androidtv/pages/onboardingPage');
const AccountPage = require('../../androidtv/pages/accountPage');
const NetworkLandingPage = require('../../androidtv/pages/networkLandingPage');

// And use a firetv page that is unique or extended
const signInPage = require('./signInPage');
const profilePage = require('./profilePage');
const homePage = require('./homePage');

const onboardingPage = new OnboardingPage();
const accountPage = new AccountPage();
const networkLandingPage = new NetworkLandingPage();

module.exports = {
  signInPage,
  profilePage,
  menuPage,
  browsePage,
  searchPage,
  homePage,
  myListPage,
  onboardingPage,
  accountPage,
  networkLandingPage,
  welcomePage,
  showDetailsPage,
  videoPlayerPage,
};
