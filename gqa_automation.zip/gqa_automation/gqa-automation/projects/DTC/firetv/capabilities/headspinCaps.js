const { mapGeoLocation } = require('@wbd/gqa-regional-routing/src/maplocation');

const appPackage =
  process.env.DTC_ANDROID_APP_PACKAGE || 'com.discovery.discoveryplus.firetv';
const appActivity =
  process.env.APP_ACTIVITY ||
  'com.discovery.plus.presentation.activities.TVSplashActivity';
const udid = process.env.UDID;
const autoAcceptAlerts = process.env.AUTO_ACCEPT_ALERTS === 'true';
const localExecution = process.env.LOCAL_EXECUTION === 'true';
const geo = process.env.GEO || 'us';

const hsFireTvCapabilities = {
  'headspin:capture.video': true,
  'headspin:selector': 'device_skus:"Fire TV Stick 4K"',
  'headspin:network.regionalRouting': mapGeoLocation(geo, 'headspin'),
};

const fireTvCapabilities = {
  deviceName: 'AMAZON Fire TV Stick 4K',
  automationName: 'Appium',
  platformName: 'Android',
  appPackage,
  appActivity,
  udid,
  newCommandTimeout: 130,
  autoAcceptAlerts,
};

const desiredFireTvCapabilities = localExecution
  ? fireTvCapabilities
  : Object.assign(fireTvCapabilities, hsFireTvCapabilities);

module.exports = { desiredFireTvCapabilities };
