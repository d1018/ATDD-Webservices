const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const menuPage = require('./menuPage');

const { VRC } = commons;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  focusedSignInPage = this.#getSelectorData('focusedSignInPage');

  continue_btn = this.#getSelectorData('continue_btn');

  signInDifferent_btn = this.#getSelectorData('signInDifferent_btn');

  signIn_btn = this.#getSelectorData('signIn_btn');

  userName_txtBx = this.#getSelectorData('userName_txtBx');

  focusedUserName_txtBx = this.#getSelectorData('focusedUserName_txtBx');

  focusedPassword_txtBx = this.#getSelectorData('focusedPassword_txtBx');

  focusedProfile = this.getElementByPage('profilePage', 'focusedProfile');

  password_txtBx = this.#getSelectorData('password_txtBx');

  welcomeScreenSignIn = this.getElementByPage('welcomePage', 'signIn_btn');

  noSubscriptionTitle_lbl = this.getElementByPage(
    'onboardingPage',
    'noSubscriptionTitle_lbl',
  );

  openApp = async () => {
    await commons.clearAppData();
    // For Headspin devices still logged in from previous sessions
    await commons.closeApp();
    await commons.openApp();
    await commons.waitUntil(this.welcomeScreenSignIn, 20);
  };

  navigateToSignInScreen_US = async () => {
    await commons.userAction(VRC.DOWN);
    await commons.userAction(VRC.ENTER);
  };

  navigateToSignInScreen_EMEA = async () => {
    await commons.tryUntil(this.signIn_btn, VRC.DOWN, 2, 1);
    await commons.userAction(VRC.ENTER);
    await commons.tryUntil(this.signInDifferent_btn, VRC.DOWN, 2, 1);
    await commons.userAction(VRC.ENTER);
    await commons.waitUntil(this.userName_txtBx, 10);
  };

  enterCredentials = async (credentialType) => {
    const username = process.env[`${credentialType}_USERNAME`];
    const password = process.env[`${credentialType}_PASSWORD`];

    // selecting the password field and entering password
    await commons.assertExists(this.focusedUserName_txtBx, 3);
    await commons.userAction(VRC.ENTER);
    await commons.setText(this.userName_txtBx, username);
    await commons.userAction(VRC.DOWN);
    // selecting the password field and entering password
    await commons.assertExists(this.focusedPassword_txtBx, 3);
    await commons.userAction(VRC.ENTER);
    await commons.setText(this.password_txtBx, password);
    await commons.userAction(VRC.DOWN);
    // Selecting signin Button
    await commons.userAction(VRC.ENTER);
  };

  loginToApplication = async (credentialType) => {
    if (this.returnGeoLocation() === 'america') {
      await this.navigateToSignInScreen_US();
    } else {
      await menuPage.navigateToPage('Account');
      await this.navigateToSignInScreen_EMEA();
    }
    await this.enterCredentials(credentialType);
    if (credentialType === 'DTC_LAPSED') {
      await commons.waitUntil(this.noSubscriptionTitle_lbl, 20);
    } else {
      await commons.waitUntilVisible(this.focusedProfile, 20);
    }
  };

  /**
   * Verify SignOut by landing in SignIn Page
   *
   */

  verifySignOut = async () => {
    await commons.assertExists(this.signIn_btn, 30);
  };
}

module.exports = new SignInPage();
