const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class ShowDetailsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('showPage', locator);
  }

  showHero_img = this.#getSelectorData('showHero_img');

  watchNow_btn = this.#getSelectorData('watchNow_btn');

  focusedMyListUnchecked = this.#getSelectorData('focusedMyListUnchecked');

  focusedMyListchecked = this.#getSelectorData('focusedMyListchecked');

  verifyDRMIssue_screen = this.getElementByPage(
    'videoPlayerPage',
    'verifyDRMIssue_screen',
  );

  tryAgain_btn = this.getElementByPage('videoPlayerPage', 'tryAgain_btn');

  verifyShowLandingPage = async (ctaType) => {
    if (ctaType === 'Watch Now CTA') {
      await commons.assertExists(this.watchNow_btn, 10);
      await commons.userAction(VRC.SELECT);
      if (
        (await commons.elementExists(this.tryAgain_btn, 30)) ||
        (await commons.elementExists(this.verifyDRMIssue_screen, 30))
      ) {
        await commons.userAction(VRC.BACK);
      } else {
        await commons.assertVideoIsPlaying(40);
        await commons.userAction(VRC.BACK);
      }
    } else if (ctaType === 'My List CTA') {
      await commons.assertExists(this.focusedMyListUnchecked, 10);
      await commons.userAction(VRC.RIGHT);
      await commons.userAction(VRC.SELECT);
      await commons.assertExists(this.focusedMyListchecked, 10);
    }
  };
}

module.exports = new ShowDetailsPage();
