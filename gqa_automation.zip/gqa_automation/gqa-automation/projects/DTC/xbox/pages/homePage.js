const assert = require('assert');
const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const { PROP, VRC, COMP } = commons;
const searchPage = require('./searchPage');
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');
const myListPage = require('./myListPage');

const myListShows = [];

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  whoIsWatching = this.getElementByPage('profilePage', 'whoIsWatching');

  browseShows = this.getElementByPage('myListPage', 'browseShows');

  forYou_lbl = this.#getSelectorData('forYou_lbl');

  focusedStartWatching_btn = this.#getSelectorData('focusedStartWatching_btn');

  focusedMyList_btn = this.#getSelectorData('focusedMyList_btn');

  focusedAddToMyListBtn_lbl = this.#getSelectorData(
    'focusedAddToMyListBtn_lbl',
  );

  focusedRemoveFromMyListBtn_lbl = this.#getSelectorData(
    'focusedRemoveFromMyListBtn_lbl',
  );

  toastMsg_lbl = this.getElementByPage('myListPage', 'toastMsg_lbl');

  focusedHomePage = this.#getSelectorData('focusedHomePage');

  searchContent = this.getElementByPage('searchPage', 'searchResultTxt');

  networkRail_JIP = this.#getSelectorData('jipNetworkRail');

  networkRail = this.#getSelectorData('focusedAllNetworkRail');

  focusedNetworkRail = this.#getSelectorData('focusedNetworkRail');

  customMyListRailShow = this.#getSelectorData('customMyListRailShow');

  showsOnMyListRail = this.getElementByPage('myListPage', 'showsOnMyListRail');

  focusedShowTitle = this.getElementByPage('myListPage', 'focusedShowTitle');

  focusedMyListonRail = this.getElementByPage(
    'myListPage',
    'focusedMyListOnRail',
  );

  focusedAccountPage = this.getElementByPage(
    'accountPage',
    'focusedAccountPage',
  );

  focusedSignOut_tab = this.getElementByPage(
    'accountPage',
    'focusedSignOut_tab',
  );

  focusedSignOut_btn = this.getElementByPage(
    'accountPage',
    'focusedSignOut_btn',
  );

  confirmSignOut_txt = this.getElementByPage(
    'accountPage',
    'confirmSignOut_txt',
  );

  focusedSignOutConfirm_btn = this.getElementByPage(
    'accountPage',
    'focusedSignOutConfirm_btn',
  );

  userNameTxt = this.getElementByPage('signInPage', 'userName_txtBx');

  entireMyListShows = this.getElementByPage('myListPage', 'entireMyListShows');

  verifyKidsContentPopulated = async () => {
    await menuPage.navigateToPage('Search');
    await searchPage.searchText('kidsShowName');
    await commons.checkProperty(
      this.searchContent,
      PROP.TEXT_CONTENT,
      testdataHelper.getContent('searchPage.kidsShowName'),
      COMP.EQUAL,
    );
  };

  verifyJIPContent = async () => {
    await menuPage.navigateToPage('Home');
    await commons.userAction(VRC.DOWN, 12, 1);
    await commons.assertDoesNotExist(this.networkRail_JIP, 2);
  };

  scrollToNetworkRail = async () => {
    if (await commons.elementExists(this.whoIsWatching, 10)) {
      await profilePage.selectProfile('Default');
    }
    await commons.tryUntil(this.focusedNetworkRail, VRC.DOWN, 10, 1);
    await commons.assertExists(this.focusedNetworkRail);
  };

  validateNetworkRail = async () => {
    await commons.assertVisible(this.networkRail, 2);
  };

  /**
   *
   *  @param {string} railName name of the Rail to be evaluated
   *  @param {boolean} railStatus Whether the Rail should be present
   */
  scrollToRail = async (railName, railStatus = true) => {
    assert.strictEqual(await this.isRailPresent(railName), railStatus);
  };

  isRailPresent = async (railName) => {
    for (let count = 0; count < 20; count++) {
      const myListRail = await commons.checkProperty(
        this.focusedMyListonRail,
        PROP.TEXT_CONTENT,
        railName,
        COMP.CONTAIN,
      );

      if (myListRail) return true;
      await commons.userAction(VRC.DOWN);
    }
    return false;
  };

  /**
   * The below function will verify Shows exists or not in MyList Rail
   *
   * @param {boolean} isShowPresent - Status of Show in MyList Rail is true or false
   */
  verifyShowsInMyListRail = async (isShowPresent) => {
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.forYou_lbl);
    await this.scrollToRail('My List', isShowPresent);
    if (isShowPresent) {
      await commons.assertExists(this.showsOnMyListRail, 2);
    } else {
      await commons.assertDoesNotExist(this.showsOnMyListRail);
    }
  };

  addShowToMylistFromHomeHero = async () => {
    // clear all added assets in MyList from previous Run
    await menuPage.navigateToPage('My List');
    while (!(await commons.elementExists(this.browseShows, 1))) {
      await myListPage.removeShowsInMyList();
    }

    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.focusedHomePage, 10);

    // Add first hero tile to my list
    await commons.tryUntil(this.focusedStartWatching_btn, VRC.DOWN, 3, 1);
    await commons.userAction(VRC.RIGHT, 2);
    await commons.assertVisible(this.focusedMyList_btn, 5);

    // Remove item first if already added to my list
    if (await commons.doesNotExist(this.focusedAddToMyListBtn_lbl)) {
      await commons.userAction(VRC.SELECT);
      await commons.assertExists(this.focusedRemoveFromMyListBtn_lbl, 5);
    }
    await commons.userAction(VRC.SELECT);
    await commons.waitUntilVisible(this.toastMsg_lbl, 5);
    await commons.assertExists(this.focusedRemoveFromMyListBtn_lbl, 5);
  };

  verifyMyListShowAvailability = async () => {
    await profilePage.selectProfile('Standard');
    await menuPage.navigateToPage('My List');
    const standardProfileShow = await commons.fetchAttributeData(
      this.focusedShowTitle,
      PROP.TEXT_CONTENT,
    );

    await profilePage.selectProfile('Kids');
    await menuPage.navigateToPage('My List');
    const kidsProfileShow = await commons.fetchAttributeData(
      this.focusedShowTitle,
      PROP.TEXT_CONTENT,
    );

    assert.notStrictEqual(
      standardProfileShow,
      kidsProfileShow,
      `same show on both profiles`,
    );
  };

  /**
   * SignOut of the Application
   *
   */
  signOut = async () => {
    if (await commons.elementExists(this.whoIsWatching, 10)) {
      await profilePage.selectProfile('Default');
    }
    await menuPage.navigateToPage('Account');
    await commons.assertExists(this.focusedAccountPage, 5);
    await commons.tryUntil(this.focusedSignOut_tab, VRC.RIGHT, 5);
    await commons.tryUntil(this.focusedSignOut_btn, VRC.DOWN, 2);
    await commons.userAction(VRC.A);
    await commons.assertExists(this.confirmSignOut_txt, 10);
    await commons.tryUntil(this.focusedSignOutConfirm_btn, VRC.UP, 2);
    await commons.userAction(VRC.A);
    await commons.assertExists(this.userNameTxt, 3);
  };

  /**
   * Adds Multiple shows to MyList
   *
   * @param {number} count - the number of shows to be added to MyList
   */
  addShowToMyList = async (count) => {
    await this.removeFromMyList();
    await commons.assertExists(this.browseShows, 1);
    await commons.userAction(VRC.A);
    await myListPage.addMultipleShowsToMyList(count);
    await this.captureShowName(count);
  };

  /**
   * Compare showCount parameter with aria-label attribute
   * that contains count of MyList shows
   *
   * @param {number} showCount - the number of shows added to MyList rail
   */
  verifyMyListRailMetadata = async (showCount) => {
    await menuPage.navigateToPage('Home');
    await this.scrollToRail('My List', true);
    const entireMyListCount = this.getCustomLocator(
      this.entireMyListShows,
      showCount,
    );

    await commons.assertExists(entireMyListCount);
  };

  /**
   * MyList Rail shows ordered by Most Recently Saved to Oldest
   * As in Verify if the MyList Menu show order
   * matches with MyList Rail show order
   */
  verifyMyListRailShowOrder = async () => {
    const myListShowsCount = myListShows.length;

    for (let i = 0; i < myListShowsCount; i++) {
      const myListShowTitle = this.getCustomLocator(
        this.customMyListRailShow,
        myListShows[i],
      );

      await commons.assertExists(myListShowTitle);
      await commons.userAction(VRC.RIGHT);
    }
  };

  /**
   * Capture Show Name from MyList Menu Page
   *
   * @param {number} count - the number of shows to be captured from MyList
   */
  captureShowName = async (count) => {
    await menuPage.navigateToPage('My List');
    for (let i = 0; i < count; i++) {
      await commons.assertExists(this.focusedShowTitle);
      const showName = await commons.fetchAttributeData(
        this.focusedShowTitle,
        PROP.TEXT_CONTENT,
      );

      const show = showName.substr(1, 4);

      myListShows.push(show);
      await commons.userAction(VRC.RIGHT);
    }
  };

  removeFromMyList = async () => {
    await menuPage.navigateToPage('My List');
    while (!(await commons.elementExists(this.browseShows, 1))) {
      await myListPage.removeShowsInMyList();
    }
  };

  verifyMyListRailOnHomePage = async () => {
    await this.verifyShowsInMyListRail(false);
  };

  // This Method remove Show from My List from Hoem Hero by clicking the MyList CTA
  removedShowFromMylistFromHomeHero = async () => {
    await menuPage.openMenu();
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.focusedHomePage, 10);

    // Remove first hero tile from my list
    await commons.tryUntil(this.focusedStartWatching_btn, VRC.DOWN, 3, 1);
    await commons.userAction(VRC.RIGHT, 2);
    await commons.assertVisible(this.focusedMyList_btn, 5);
    await commons.assertExists(this.focusedRemoveFromMyListBtn_lbl, 5);
    await commons.userAction(VRC.SELECT);
    await commons.waitUntilVisible(this.toastMsg_lbl, 5);
    await commons.assertExists(this.focusedAddToMyListBtn_lbl, 5);
  };
}

module.exports = new HomePage();
