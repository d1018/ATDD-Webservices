const assert = require('assert');

const { BasePage, remoteActions } = require('./basePage');
const menuPage = require('./menuPage');

const commons = remoteActions;
const { VRC, PROP } = commons;
let firstShowName;
let currentShowName;

class BrowsePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('browserPage', locator);
  }

  focusedBrowsePage = this.#getSelectorData('focusedBrowsePage');

  focusedNetwork_tab = this.#getSelectorData('focusedNetwork_tab');

  focusedAllNetwork_tab = this.#getSelectorData('focusedAllNetwork_tab');

  subNav_tab = this.#getSelectorData('subNav_tab');

  firstSubNav_tab = this.#getSelectorData('firstSubNav_tab');

  focusedFirstSubNav_tab = this.#getSelectorData('focusedFirstSubNav_tab');

  focusedShowCard = this.#getSelectorData('focusedShowCard');

  firstShowCard = this.#getSelectorData('firstShowCard');

  focusedShowTitle = this.#getSelectorData('focusedShowTitle');

  focusedShow_img = this.#getSelectorData('focusedShow_img');

  assertTiles = this.#getSelectorData('assertTiles');

  focusedShowNetworkLogo_img = this.#getSelectorData(
    'focusedShowNetworkLogo_img',
  );

  /**
   * The below function will select a profile and select a page from global Navigation menu
   *
   * @param {string} pageType will select a page
   */

  selectPage = async (pageType) => {
    if (this.countryCode === 'us' && pageType === 'Browse') {
      await menuPage.navigateToPage(pageType);
    } else await menuPage.navigateToPage(pageType);
  };

  /**
   * This method will validate the browse page network and subnav tabs
   *
   */

  verifyBrowsePage = async () => {
    await commons.waitUntilVisible(this.focusedBrowsePage, 10);
    await commons.assertVisibleSelectorArray([
      this.focusedBrowsePage,
      this.focusedNetwork_tab,
      this.subNav_tab,
      this.focusedAllNetwork_tab,
    ]);
  };

  moveFocusToAllNetworkTab = async () => {
    await commons.tryUntil(this.focusedNetwork_tab, 'UP', 5, 1);
    await commons.tryUntil(this.focusedAllNetwork_tab, 'LEFT', 5, 1);
    await commons.assertVisible(this.focusedAllNetwork_tab, 10);
    await commons.userAction('ENTER');
  };

  /**
   * The below function will select a network from the network rail in browse page and validate network and subnav are shown
   *
   * @param {string} networkType will select a network
   */

  selectNetwork = async (networkType) => {
    if (this.countryCode === 'us' && networkType === 'Entertainment') {
      await this.moveFocusToAllNetworkTab();

      firstShowName = await commons.fetchAttributeData(
        this.firstShowCard,
        PROP.TEXT_CONTENT,
      );
      await commons.userAction('RIGHT', 3, 5);
      await commons.userAction('ENTER');
      await commons.waitUntil(this.firstShowCard, 10);
      await commons.assertVisibleSelectorArray([
        this.focusedNetwork_tab,
        this.firstSubNav_tab,
      ]);
    } else {
      throw new Error(`countryCode or networkType is Mismatched`);
    }
  };

  /**
   * The below function will verify the showname on networktab
   */

  verifyShowOnSelectedNetwork = async () => {
    await commons.waitUntil(this.firstShowCard, 10);
    currentShowName = await commons.fetchAttributeData(
      this.firstShowCard,
      PROP.TEXT_CONTENT,
    );

    assert.notEqual(
      firstShowName,
      currentShowName,
      'show names are same for 2 different browser network channel',
    );
  };

  /**
   * The below function will capture default firstshowname and will navigate trice right to other SubNav tab
   *
   * @param {string} subNav will select subNav menu item
   */

  selectSubNav = async (subNav) => {
    if (this.countryCode === 'us' && subNav === 'first') {
      await this.moveFocusToAllNetworkTab();
      await commons.tryUntil(this.focusedFirstSubNav_tab, 'DOWN', 1, 1);
      await commons.userAction('ENTER');
      await commons.waitUntil(this.firstShowCard, 10);

      firstShowName = await commons.fetchAttributeData(
        this.firstShowCard,
        PROP.TEXT_CONTENT,
      );
      await commons.userAction('RIGHT', 3, 1);
      await commons.userAction('ENTER');
    } else {
      throw new Error(`countryCode or subNav is Mismatched`);
    }
  };

  selectAsset = async () => {
    await commons.userAction(VRC.OK, 1, 10);
    await commons.assertExists(this.assertTiles);
    await commons.userAction(VRC.DOWN);
    await commons.userAction(VRC.ENTER);
  };

  /**
   * This method will validate the current name doesnot match firstshowname
   * This will assert the Show Title, Network Logo and Image
   */

  verifyShowCard = async () => {
    await commons.waitUntil(this.firstShowCard, 10);
    currentShowName = await commons.fetchAttributeData(
      this.firstShowCard,
      PROP.TEXT_CONTENT,
    );
    assert.notEqual(
      firstShowName,
      currentShowName,
      'show names are same for 2 different browser Sub-Nav',
    );
    await commons.tryUntil(this.focusedShowCard, 'DOWN', 3, 1);
    assert(
      (await commons.elementExists(this.focusedShowTitle, 2)) &&
        (await commons.elementExists(this.focusedShow_img, 2)) &&
        (await commons.elementExists(this.focusedShowNetworkLogo_img, 2)),
      `Show Title, Network Logo and Image are not displayed`,
    );
  };
}

module.exports = new BrowsePage();
