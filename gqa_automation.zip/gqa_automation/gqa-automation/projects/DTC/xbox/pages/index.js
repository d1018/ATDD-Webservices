const accountPage = require('./accountPage');
const homePage = require('./homePage');
const searchPage = require('./searchPage');
const signInPage = require('./signInPage');
const menuPage = require('./menuPage');
const welcomePage = require('./welcomePage');
const profilePage = require('./profilePage');
const networkLandingPage = require('./networkLandingPage');
const onboardingPage = require('./onboardingPage');
const myListPage = require('./myListPage');
const browsePage = require('./browsePage');
const showDetailsPage = require('./showDetailsPage');

module.exports = {
  accountPage,
  homePage,
  searchPage,
  signInPage,
  menuPage,
  welcomePage,
  profilePage,
  networkLandingPage,
  onboardingPage,
  myListPage,
  browsePage,
  showDetailsPage,
};
