const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;

const { VRC, PROP } = commons;
let searchText = '';

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  search_txtBx = this.#getSelectorData('search_txtBx');

  showTitle_lbl = this.#getSelectorData('showTitle_lbl');

  showImage_img = this.#getSelectorData('showImage_img');

  showNetworkIcon_img = this.#getSelectorData('showNetworkIcon_img');

  firstThumbnailOnSearch = this.#getSelectorData('focusedSearchResult');

  noResultsLabel_lbl = this.#getSelectorData('noResultsLabel_lbl');

  recommendedForYou_lbl = this.#getSelectorData('recommendedForYou_lbl');

  focusedShowDetailPage = this.getElementByPage(
    'showPage',
    'focusedShowDetailPage',
  );

  eventDetailPage = this.getElementByPage('sportsPage', 'eventDetailPage');

  searchResultTabs = {
    Shows: this.#getSelectorData('showsTab_lbl'),
    Episodes: this.#getSelectorData('showEpisodesTab_lbl'),
    Specials: this.#getSelectorData('showSpecialsTab_lbl'),
    Collections: this.#getSelectorData('showCollectionsTab_lbl'),
    Extras: this.#getSelectorData('showExtrasTab_lbl'),
  };

  searchText = async (text) => {
    searchText = testdataHelper.getContent(`searchPage.${text}`);
    await commons.userAction(VRC.UP, 3);
    await commons.userAction(VRC.ENTER, 1, 3);
    await commons.setText(this.search_txtBx, searchText);
  };

  verifyNoResultFound = async () => {
    await commons.waitUntil(this.noResultsLabel_lbl, 10);
    await commons.assertExists(this.noResultsLabel_lbl, 5);
  };

  verifyRecommendedForYou = async () => {
    await commons.waitUntil(this.recommendedForYou_lbl, 10);
    await commons.assertExists(this.recommendedForYou_lbl, 5);
  };

  verifyIfSearchResultsLoaded = async () => {
    await commons.assertExists(this.showTitle_lbl, 10);
    await commons.assertExists(this.showImage_img);
    await commons.assertExists(this.showNetworkIcon_img);
  };

  verifyResultsIncludeSearchText = async () => {
    const titleValue = await commons.fetchAttributeData(
      this.showTitle_lbl,
      PROP.TEXT_CONTENT,
    );

    if (titleValue.includes(searchText)) return;
    throw new Error(`Search result does not includes '${searchText}'`);
  };

  getSearchResultsTab = () => {
    let searchResultTabs;

    if (this.countryCode === 'us') {
      searchResultTabs = [
        testdataHelper.getContent('searchPage.showsTab'),
        testdataHelper.getContent('searchPage.episodesTab'),
        testdataHelper.getContent('searchPage.specialsTab'),
        testdataHelper.getContent('searchPage.collectionsTab'),
        testdataHelper.getContent('searchPage.extrasTab'),
      ];
    }
    return searchResultTabs;
  };

  /**
   * Verify Search Results Tab
   * Skips the tab Validation that has video Playback(i.e Known DRM issue on XBOX )
   */

  verifySearchTabsLanding = async (tabName) => {
    switch (tabName) {
      case 'Shows':
        await commons.userAction(VRC.SELECT);
        await commons.assertExists(this.focusedShowDetailPage, 20);
        await commons.userAction(VRC.BACK, 1, 2);
        break;
      case 'Episodes':
      case 'Specials':
      case 'Extras':
        await commons.userAction(VRC.UP, 1, 2);
        break;
      case 'Collections':
        await commons.userAction(VRC.SELECT);
        await this.verifySportsScreenAnchorDetails();
        await commons.userAction(VRC.BACK, 1, 2);
        break;
      default:
        break;
    }
  };

  verifySportsScreenAnchorDetails = async () => {
    await commons.assertExists(this.eventDetailPage, 5);
  };

  verifyLandingPageBasedOnContent = async () => {
    const searchTabs = this.getSearchResultsTab();

    for (let i = 0; i < searchTabs.length; i++) {
      await commons.waitUntil(this.searchResultTabs[searchTabs[i]]);
      await commons.tryUntil(this.firstThumbnailOnSearch, VRC.DOWN, 2, 2);
      await this.verifySearchTabsLanding(searchTabs[i]);
      await commons.userAction(VRC.DOWN, 1, 2);
      await commons.userAction(VRC.UP, 1, 2);
      await commons.userAction(VRC.RIGHT, 1, 1);
    }
  };

  verifySearchedContentAndItsLandingPage = async () => {
    await this.verifyResultsIncludeSearchText();
    await this.verifyLandingPageBasedOnContent();
  };
}

module.exports = new SearchPage();
