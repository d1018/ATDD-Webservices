const { BasePage, remoteActions } = require('./basePage');
const menuPage = require('./menuPage');

const commons = remoteActions;

const { VRC } = commons;

class MyListPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myListPage', locator);
  }

  browseShows = this.#getSelectorData('browseShows');

  focusedRandomShow = this.getElementByPage('browserPage', 'focusedRandomShow');

  focusedAddMyListBtn = this.#getSelectorData('focusedAddMyListBtn');

  firstSavedShowTile = this.#getSelectorData('firstSavedShowTile');

  /**
   * Go to My list page from Side menu
   * Select first show, go to show details page
   * click +My list button
   * click Back till focused show details present on browse page
   */

  addShowsToMylistFromBrowse = async () => {
    await menuPage.navigateToPage('My List');
    await commons.assertExists(this.browseShows, 1);
    await commons.userAction(VRC.A);
    await commons.tryUntil(this.focusedRandomShow, VRC.DOWN, 4, 1);
    await commons.userAction(VRC.A);
    await commons.tryUntil(this.focusedAddMyListBtn, VRC.RIGHT, 4, 1);
    await commons.userAction(VRC.A);
  };

  /**
   * The below function will verify the MyList Rail
   *
   * @param {boolean} isShowPresent - MyList Rail status true or false
   */
  verifyShowsInMyList = async (isShowPresent) => {
    await menuPage.navigateToPage('My List');
    if (isShowPresent) {
      await commons.assertExists(this.firstSavedShowTile);
    } else {
      await commons.doesNotExist(this.firstSavedShowTile);
    }
  };

  selectBrowseShows = async () => {
    await commons.assertExists(this.browseShows, 10);
    await commons.userAction(VRC.ENTER);
  };

  removeShowsInMyList = async () => {
    await commons.userAction(VRC.A);
    await commons.tryUntil(this.focusedAddMyListBtn, VRC.RIGHT, 4, 1);
    await commons.userAction(VRC.A);
    await commons.userAction(VRC.B);
  };

  /**
   * Select first show, go to show details page
   * click +My list button and click Back
   * select another show and repeat until Count
   */

  addMultipleShowsToMyList = async (count) => {
    await commons.tryUntil(this.focusedRandomShow, VRC.DOWN, 4, 1);
    for (let i = 0; i < count; i++) {
      await commons.userAction(VRC.A);
      await commons.tryUntil(this.focusedAddMyListBtn, VRC.RIGHT, 4, 1);
      await commons.userAction(VRC.A);
      await commons.userAction(VRC.BACK);
      await commons.userAction(VRC.DOWN);
    }
  };

  removeShowFromMyListPage = async () => {
    await menuPage.navigateToPage('My List');
    while (!(await commons.elementExists(this.browseShows, 1))) {
      await this.removeShowsInMyList();
    }
  };
}

module.exports = new MyListPage();
