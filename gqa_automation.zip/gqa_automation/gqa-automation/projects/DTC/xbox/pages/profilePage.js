const assert = require('assert');
const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const { PROP, VRC, COMP } = commons;

let newProfileName;
let retry = 0;
let profileLocalName;

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  focusedProfileName = this.#getSelectorData('focusedProfileName');

  whoIsWatching = this.#getSelectorData('whoIsWatching');

  profileLock_img = this.#getSelectorData('profileLock_img');

  focusedMenuBar = this.getElementByPage('menuPage', 'focusedMenuBar');

  profileNameTxt = this.#getSelectorData('profileName');

  focusedSaveBtn = this.#getSelectorData('focusedSaveBtn');

  kidProfileToggle = this.#getSelectorData('kidProfileToggle');

  deleteProfileBtn = this.#getSelectorData('deleteProfileBtn');

  focusedDeleteProfileBtn = this.#getSelectorData('focusedDeleteProfileBtn');

  focusedCancelBtn = this.#getSelectorData('focusedCancelBtn');

  deleteAccountTxt = this.#getSelectorData('deleteAccountTxt');

  randomProfile = this.#getSelectorData('randomProfile');

  focusedSwitchProfile = this.getElementByPage(
    'menuPage',
    'focusedSwitchProfile',
  );

  focusedProfileByName = this.#getSelectorData('focusedProfileByName');

  focusedPinProfile = this.#getSelectorData('focusedPinProfile');

  deleteModalFocused_btn = this.#getSelectorData('deleteModalFocused_btn');

  profileEdit_btn = this.#getSelectorData('profileEdit_btn');

  customProfileName = this.#getSelectorData('customProfileName');

  dynamicPinPad_txtBx = this.#getSelectorData('dynamicPinPad_txtBx');

  focusedFirstProfile = this.#getSelectorData('focusedFirstProfile');

  focusedProfileNameInputTxt = this.#getSelectorData(
    'focusedProfileNameInputTxt',
  );

  focusedProfile = this.#getSelectorData('focusedProfile');

  focusedForYou_lbl = this.getElementByPage('homePage', 'focusedForYou_lbl');

  profileNameInputTxt = this.getElementByPage(
    'profilePage',
    'profileNameInputTxt',
  );

  selectProfile = async (profileName) => {
    if (await commons.doesNotExist(this.whoIsWatching, 10)) {
      await this.navigateToProfilePickerScreen();
    }

    await commons.tryUntil(this.focusedFirstProfile, VRC.LEFT, 3, 3);

    for (let i = 0; i < 4; i++) {
      if (
        await commons.checkProperty(
          this.focusedProfileName,
          PROP.TEXT_CONTENT,
          profileName,
          COMP.CONTAIN,
        )
      ) {
        await commons.assertExists(this.focusedProfileName, 60);
        await commons.userAction(VRC.A);
        return;
      }
      await commons.userAction(VRC.RIGHT);
    }
  };

  /**
   * click delete Profile in Edit Profile Page
   */

  deleteProfileFromEditProfilePage = async () => {
    await commons.assertExists(this.focusedProfileNameInputTxt, 5);
    await commons.tryUntil(this.deleteModalFocused_btn, VRC.UP, 3, 3);
    await commons.assertExists(this.deleteModalFocused_btn, 2);
    await commons.userAction(VRC.A, 1, 3);
    await commons.assertExists(this.focusedCancelBtn);
    await commons.tryUntil(this.focusedDeleteProfileBtn, VRC.UP, 2, 2);
    await commons.assertExists(this.focusedDeleteProfileBtn);
    await commons.userAction(VRC.A, 1, 5);
  };

  /**
   * Navigates to Who is Watching Page
   */
  navigateToProfilePickerScreen = async () => {
    if (await commons.doesNotExist(this.focusedProfile, 10)) {
      await commons.tryUntil(this.focusedMenuBar, VRC.LEFT, 1, 2);
      await commons.tryUntil(this.focusedSwitchProfile, VRC.UP, 8, 2);
      await commons.userAction(VRC.A);
    } else if (await commons.assertExists(this.focusedProfile, 20)) {
      await commons.tryUntil(this.focusedProfile, VRC.B, 5, 2);
    }

    await commons.assertExists(this.focusedProfile, 20);
  };

  /**
   * click on +Add Profile
   * Fills in new Profile Name and set FamilyProfile as needed
   * Also deletes last profile used if Profiles are max'ed Out
   */

  createNewProfile = async (profileType) => {
    const dateObject = new Date();
    const localeDate = dateObject.toLocaleDateString();
    const localeTime = dateObject.toLocaleTimeString();

    profileLocalName = String(
      `${profileType}_${process.env.DEVICE}_${localeTime}_${localeDate}`,
    );

    if (profileLocalName.length > 30) {
      profileLocalName = profileLocalName.substring(0, 20);
    }

    if (
      !(await commons.elementExists(
        this.getCustomLocator(this.customProfileName, 'Add Profile'),
      ))
    ) {
      await this.deleteAnyProfile();
    }

    if (
      !(await commons.elementExists(
        this.getCustomLocator(this.customProfileName, profileType),
        5,
      ))
    ) {
      await this.selectProfile('Add Profile');
      await commons.userAction(VRC.A, 2);
      await commons.setText(this.profileNameTxt, profileLocalName);

      // Remove extra character if keyboard is open and save button is not enabled
      if (!(await commons.elementExists(this.focusedSaveBtn, 4))) {
        await commons.userAction(VRC.A);
        await this.removeExtrakeyboardChar;
      }

      // toggle On FamilyProfile for Kids
      if (profileType === 'Kids') {
        if (
          await commons.checkProperty(
            this.kidProfileToggle,
            PROP.TEXT_CONTENT,
            'Off',
            COMP.EQUAL,
          )
        ) {
          await commons.userAction(VRC.UP);
          await commons.userAction(VRC.A);
          await commons.checkProperty(
            this.kidProfileToggle,
            PROP.TEXT_CONTENT,
            'On',
            COMP.EQUAL,
          );
          await commons.userAction(VRC.DOWN);
          await commons.tryUntil(this.focusedSaveBtn, VRC.RIGHT, 1, 1);
          await commons.userAction(VRC.A);
        }
      } else {
        await commons.userAction(VRC.A);
      }
    } else {
      newProfileName = profileType;
      await this.deleteByProfileName();
      await this.createNewProfile(profileType);
    }
  };

  /**
   * Below function is used to create a new profile and calls createnewprofile function
   *
   * @param {string} profileType as Standard, Kids
   */
  profileCreation = async (profileType) => {
    newProfileName = profileType;
    if (newProfileName !== 'Pin') {
      await commons.tryUntil(this.focusedMenuBar, VRC.LEFT, 1, 1);
      await this.createNewProfile(profileType);
      await this.selectProfile(profileType);
    }
    // Creation of pin profile is applicable in Web Only so selecting for Hwa
    else await this.selectPinProfile(newProfileName);
  };

  editProfile = async () => {
    for (let i = 0; i < 5; i++) {
      if (
        await commons.checkProperty(
          this.focusedProfileName,
          PROP.TEXT_CONTENT,
          newProfileName,
          COMP.CONTAIN,
        )
      ) {
        await this.editProfileAction();
        return;
      }
      await commons.userAction(VRC.RIGHT);
    }
  };

  deleteByProfileName = async () => {
    await this.editProfile();
    await this.deleteProfileFromEditProfilePage();
  };

  deleteProfile = async (profileName) => {
    if (profileName === 'random') {
      newProfileName = profileName;
      await this.navigateToProfilePickerScreen();
      await this.createNewProfile(profileName);
    }
    await this.editAndDelete();
  };

  switchFromKidsToAdult = async () => {
    await this.navigateToProfilePickerScreen();
    while (
      await commons.checkProperty(
        this.focusedProfileName,
        PROP.TEXT_CONTENT,
        newProfileName,
        COMP.CONTAIN,
      )
    ) {
      await commons.userAction(VRC.RIGHT, 1, 1);
    }

    await commons.userAction(VRC.A, 1, 3);
    await this.navigateToProfilePickerScreen();
  };

  deleteAdultProfile = async () => {
    await this.navigateToProfilePickerScreen();
    await this.editProfileAction();
    await this.deleteProfileFromEditProfilePage();
  };

  removeExtrakeyboardChar = async () => {
    await commons.userAction(VRC.UP, 1, 1);
    await commons.userAction(VRC.RIGHT, 5, 2);
    await commons.userAction(VRC.A, 1, 1);
    await commons.userAction(VRC.B, 1, 1);
  };

  deleteExistingProfile = async () => {
    if (this.pinProfile !== 'Pin') {
      if (newProfileName === 'Kids') {
        await this.switchFromKidsToAdult();
        await commons.userAction(VRC.RIGHT, 1, 1);
        await this.deleteByProfileName();
      } else await this.deleteAdultProfile(newProfileName);

      // Retry Deleting Profile in case of Failure in previous attempt
      if (newProfileName !== undefined) {
        const focusedProfile = await commons.fetchAttributeData(
          this.focusedProfileName,
          PROP.TEXT_CONTENT,
        );

        const profileExist = await commons.elementExists(
          this.getCustomLocator(this.customProfileName, newProfileName),
        );

        if (focusedProfile !== newProfileName && profileExist && retry < 2) {
          retry++;
          await commons.assertExists(this.whoIsWatching);
          await this.deleteExistingProfile();
        } else if (
          focusedProfile !== newProfileName &&
          profileExist &&
          retry >= 2
        ) {
          assert.notEqual(
            focusedProfile,
            newProfileName,
            'profile not deleted after retrying twice',
          );
        }
      }
    }
  };

  selectPinProfile = async (profileName) => {
    await commons.assertVisible(this.profileLock_img, 5);
    await commons.tryUntil(this.focusedPinProfile, VRC.RIGHT, 4, 1);
    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.dynamicPinPad_txtBx, 3);
    await commons.userAction(VRC.SELECT, 4);
    await commons.assertExists(this.focusedForYou_lbl, 10);

    this.pinProfile = profileName;
  };

  verifyUserProfileDeleted = async () => {
    await commons.assertDoesNotExist(this.randomProfile, 2);
  };

  createNewProfileandSelect = async (profileName) => {
    await this.profileCreation(profileName);
  };

  editProfileAction = async () => {
    if (await commons.doesNotExist(this.whoIsWatching, 10)) {
      await this.navigateToProfilePickerScreen();
    }

    await commons.assertExists(this.focusedProfileName, 60);
    await commons.userAction(VRC.DOWN);
    await commons.tryUntil(this.focusedProfileNameInputTxt, VRC.A, 3, 3);
  };

  deleteAnyProfile = async () => {
    await commons.userAction(VRC.RIGHT, 5, 1);
    await this.editAndDelete();
  };

  editAndDelete = async () => {
    await this.editProfileAction();
    await this.deleteProfileFromEditProfilePage();
  };
}

module.exports = new ProfilePage();
