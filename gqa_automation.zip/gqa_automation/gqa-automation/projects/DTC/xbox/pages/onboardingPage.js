const { BasePage, remoteActions } = require('./basePage');
const profilePage = require('./profilePage');

const commons = remoteActions;

class OnboardingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('onboardingPage', locator);
  }

  noSubscriptionTitle_lbl = this.#getSelectorData('noSubscriptionTitle_lbl');

  whoIsWatching = this.getElementByPage('profilePage', 'whoIsWatching');

  verifyInactiveSubscriptionScreen = async () => {
    await commons.waitUntil(this.noSubscriptionTitle_lbl, 20);
  };

  selectCTA = async (CTAType) => {
    if (await commons.elementExists(this.whoIsWatching, 10)) {
      await profilePage.selectProfile('Default');
    }
    const btn = CTAType.toString().toUpperCase();

    await commons.userAction(btn);
  };
}

module.exports = new OnboardingPage();
