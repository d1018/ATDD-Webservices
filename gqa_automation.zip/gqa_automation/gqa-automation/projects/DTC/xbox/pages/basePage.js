const path = require('path');
const { remoteActions, testdataHelper } = require('@wbd/gqa-core/support');

const ymlpath = path.resolve(__dirname);

const EnvBase = require('../../../support/env');

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }
}

module.exports = {
  remoteActions,
  testdataHelper,
  BasePage,
};
