const { BasePage, remoteActions, testdataHelper } = require('./basePage');
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');

const commons = remoteActions;
const { VRC } = commons;

class AccountPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('accountPage', locator);
  }

  account_tab = this.#getSelectorData('account_tab');

  accountTitle_lbl = this.#getSelectorData('accountTitle_lbl');

  help_tab = this.#getSelectorData('help_tab');

  about_tab = this.#getSelectorData('about_tab');

  signOut_tab = this.#getSelectorData('signOut_tab');

  signOutBtn_lbl = this.#getSelectorData('signOutBtn_lbl');

  helpTabText = this.#getSelectorData('helpTabText');

  aboutTabText = this.#getSelectorData('aboutTabText');

  accountTabManageSubs_lbl = this.#getSelectorData('accountTabManageSubs_lbl');

  focusedAccountPage = this.#getSelectorData('focusedAccountPage');

  focusedAccountPage_tab = this.#getSelectorData('focusedAccountPage_tab');

  myListMenuListItem = this.getElementByPage('menuPage', 'myListMenuListItem');

  accountPageSubMenu = {
    Account: this.account_tab,
    Help: this.help_tab,
    About: this.about_tab,
    'Sign Out': this.signOut_tab,
  };

  getUserAccountMenuItems = (profileName) => {
    const accountType = {
      Anonymous: 'anonymousUserAccountItemListHwa',
      Default: 'defaultUserAccountItemListHwa',
      Kids: 'kidsUserAccountItemListHwa',
    };

    return testdataHelper.getContent(`accountPage.${accountType[profileName]}`);
  };

  /**
   * This Method naviates through all the tabs which should be shown to user depending on the profilename provided
   *
   * @param {string} profileName Provide the Profile name for which we want to validate accounts tab
   */
  verifyAccountSubNavigationPage = async (profileName) => {
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      await commons.waitUntil(this.accountPageSubMenu[accountMenuList[i]]);
      await this.accountSubNavigationPage(accountMenuList[i]);
      await commons.userAction(VRC.RIGHT, 1, 2);
    }
  };

  /**
   * This methods depending on the account tab selected validated the tabs availability
   *
   * @param {string} tabName Provide the name of the tab which we wants to Validate
   */
  accountSubNavigationPage = async (tabName) => {
    switch (tabName) {
      case 'Account':
        await commons.assertExists(
          this.getCustomLocator(
            this.accountTabManageSubs_lbl,
            testdataHelper.getContent('accountPage.manageSubscription'),
          ),
        );
        break;
      case 'Help Centre':
        await commons.assertExists(this.helpTabText);
        break;
      case 'About':
        await commons.assertExists(this.aboutTabText);
        break;
      case 'Sign Out':
        await commons.assertExists(this.signOutBtn_lbl);
        break;
      default:
        break;
    }
  };

  /**
   * This Methods verifies the account page tabs according to profile type
   *
   * @param {string} profileName Provide the Profile name for which we want to validate accounts tab
   */
  verifyAccountPage = async (profileName) => {
    await profilePage.selectProfile(profileName);
    await menuPage.navigateToPage('Account');
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      await commons.assertExists(this.accountPageSubMenu[accountMenuList[i]]);
    }
  };
}

module.exports = new AccountPage();
