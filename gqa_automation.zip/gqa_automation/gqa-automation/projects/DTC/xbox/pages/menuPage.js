const { BasePage, remoteActions, testdataHelper } = require('./basePage');
const profilePage = require('./profilePage');

const commons = remoteActions;
const { VRC } = commons;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  menuListLoggedIn = testdataHelper.getContent(
    'menuNavigationPage.loggedInMenu',
  );

  focusedMenuBar = this.#getSelectorData('focusedMenuBar');

  myListMenu_lbl = this.#getSelectorData('myListMenuListItem');

  accountMenu_lbl = this.#getSelectorData('accountMenu_lbl');

  searchMenu_lbl = this.#getSelectorData('searchMenu_lbl');

  focusedHomeMenu_lbl = this.#getSelectorData('focusedHomeMenu_lbl');

  menuBarList = this.#getSelectorData('menuBarList');

  homeMenu_lbl = this.#getSelectorData('homeMenu_lbl');

  myList_lbl = this.#getSelectorData('focusedMyList_lbl');

  browseMenu_lbl = this.#getSelectorData('browseMenu_lbl');

  focusedSearchPage = this.getElementByPage('searchPage', 'focusedSearchPage');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  firstSubNav_tab = this.getElementByPage('browserPage', 'firstSubNav_tab');

  focusedMyListPage = this.getElementByPage('myListPage', 'focusedMyListPage');

  focusedAccountPage = this.getElementByPage('accountPage', 'accountTopNav');

  focusedSwitchProfile = this.#getSelectorData('focusedSwitchProfile');

  browseShows = this.countryCode === 'us' ? 'shows' : 'browse';

  exit_btn = this.getElementByPage('exitPage', 'exit_btn');

  exitPageTitle = this.getElementByPage('exitPage', 'exitPageTitle');

  focusedCancel_btn = this.getElementByPage('exitPage', 'focusedCancel_btn');

  focusedExit_btn = this.getElementByPage('exitPage', 'focusedExit_btn');

  whoIsWatching = this.getElementByPage('profilePage', 'whoIsWatching');

  menuItem = {
    Home: this.homeMenu_lbl,
    Browse: this.getCustomLocator(this.browseMenu_lbl, this.browseShows),
    'My List': this.myList_lbl,
    Search: this.searchMenu_lbl,
    Account: this.accountMenu_lbl,
  };

  pageFocused = {
    Home: this.focusedHomePage,
    Browse: this.firstSubNav_tab,
    'My List': this.focusedMyListPage,
    Search: this.focusedSearchPage,
    Account: this.focusedAccountPage,
  };

  openMenu = async () => {
    await commons.tryUntil(this.focusedMenuBar, VRC.BACK, 10, 1);
  };

  navigateToPage = async (pageValue) => {
    if (await commons.elementExists(this.whoIsWatching, 10)) {
      await profilePage.selectProfile('Default');
    }
    await this.openMenu();
    if (!(await commons.elementExists(this.focusedSwitchProfile, 2))) {
      await commons.tryUntil(this.focusedSwitchProfile, VRC.UP, 6, 1);
    }
    await commons.navigateTo(this.menuItem[pageValue], VRC.DOWN, 8);
    // increasing because of slow network
    await commons.assertExists(this.pageFocused[pageValue], 10);
  };

  accessGlobalNavigationMenu = async () => {
    await commons.waitUntil(this.focusedHomePage);
    await this.openMenu();
  };

  closeMenu = async () => {
    await commons.tryUntil(this.menuBarList, VRC.RIGHT, 3, 1);
  };

  getMenuList = async () => {
    if (await commons.elementExists(this.myListMenu_lbl)) {
      return this.menuListLoggedIn;
    }
    return [];
  };

  /**
   * The below function will verify the navigation menu list based on user type (Anonymous, Default, Kids).
   */
  verifyMenuList = async () => {
    const menuList = await this.getMenuList();

    for (let i = 0; i < menuList.length; i++) {
      await commons.userAction(VRC.DOWN);
      await commons.assertExists(this.menuItem[menuList[i]]);
    }
    await commons.tryUntil(this.focusedHomeMenu_lbl, VRC.UP, 10, 1);
    await this.closeMenu();
  };

  /**
   * The below function will verify the navigation menu pages based on user type (Anonymous, Default, Kids).
   */

  verifyGlobalNavigation = async () => {
    await this.openMenu();
    const menuList = await this.getMenuList();

    for (let i = 0; i < menuList.length; i++) {
      await this.navigateToPage(menuList[i]);
    }
  };

  assertPage = async (pageValue) => {
    await commons.waitUntil(this.pageFocused[pageValue]);
  };

  verifyExitConfirmation = async () => {
    await commons.tryUntil(this.focusedCancel_btn, VRC.BACK, 4, 5);
    await commons.assertExists(this.exitPageTitle);
  };

  verifyAppBehavior = async (ctaType) => {
    if (ctaType === 'Back') {
      await commons.userAction(VRC.BACK);
      await commons.assertExists(this.focusedHomePage, 5);
    } else if (ctaType === 'Cancel') {
      await this.verifyExitConfirmation();
      await commons.assertExists(this.focusedCancel_btn, 5);
      await commons.userAction(VRC.SELECT);
      await commons.assertExists(this.focusedHomePage, 5);
    } else {
      await this.verifyExitConfirmation();
      await commons.userAction(VRC.UP);
      await commons.assertExists(this.focusedExit_btn, 5);
      await commons.userAction(VRC.SELECT);
      if ((await commons.isAppExited(20)) === false) {
        throw new Error(
          'Application has not exited succesfully which is not expected',
        );
      }
    }
  };
}

module.exports = new MenuPage();
