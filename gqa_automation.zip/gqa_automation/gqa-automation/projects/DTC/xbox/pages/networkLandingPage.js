const { BasePage, remoteActions, testdataHelper } = require('./basePage');
const homePage = require('./homePage');

const commons = remoteActions;
const { VRC, PROP, COMP } = commons;

const adultEntertainmentChannel = testdataHelper.getContent(
  'networkPage.Entertainment',
);

const foodNetworkRail = testdataHelper.getContent(
  'networkPage.foodNetworkRail',
);

class NetworkLandingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('networkLandingPage', locator);
  }

  featuredShows = this.#getSelectorData('featuredShows');

  recommendedShows = this.#getSelectorData('recommendedShows');

  network_logo = this.#getSelectorData('network_logo');

  networkRailChannel = this.getElementByPage('homePage', 'networkRailChannel');

  unFocusedNetworkRailChannel = this.getElementByPage(
    'homePage',
    'unFocusedNetworkRailChannel',
  );

  showRatingCode_lbl = this.getElementByPage('showPage', 'showRatingCode_lbl');

  navigateToSelectNetwork = async (networkType) => {
    let i = 20;

    while (i > 0) {
      if (
        await commons.elementExists(
          this.getCustomLocator(this.networkRailChannel, networkType),
          1,
        )
      ) {
        await commons.userAction(VRC.ENTER, 1, 5);
        break;
      } else {
        await commons.userAction(VRC.RIGHT);
        i -= 1;
      }
    }
  };

  validateEntertainmentNetwork = async () => {
    await this.validateNetworkByValidUser();
  };

  validateNetworkByValidUser = async () => {
    await commons.elementExists(this.network_logo, 3);
    await commons.elementExists(this.recommendedShows);
    await commons.elementExists(this.featuredShows);
  };

  validateEntertainmentNetworkLandingPage = async () => {
    await this.navigateToSelectNetwork(adultEntertainmentChannel);
    await this.validateEntertainmentNetwork();
  };

  /**
   * The below function includes Entertainment network channel
   *
   * @param {*} network will select Entertainment and other networks
   */
  selectAndValidateNetworkLandingPage = async (network) => {
    if (network === 'Entertainment') {
      await this.validateEntertainmentNetworkLandingPage();
    }
  };

  verifyNetworkRailForKidsProfile = async () => {
    await homePage.scrollToNetworkRail();
    if (this.countryCode === 'us') {
      commons.assertDoesNotExist(
        this.getCustomLocator(
          this.unFocusedNetworkRailChannel,
          adultEntertainmentChannel,
        ),
      );
      await this.navigateToSelectNetwork(foodNetworkRail);
      await commons.userAction(VRC.ENTER, 1, 2);
      await commons.assertProperty(
        this.showRatingCode_lbl,
        PROP.TEXT_CONTENT,
        'G',
        COMP.CONTAIN,
      );
    }
  };
}

module.exports = new NetworkLandingPage();
