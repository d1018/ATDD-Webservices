const assert = require('assert');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const SearchPage = require('./searchPage');
const MenuPage = require('./menuPage');
const MyListPage = require('./myListPage');
const ShowDetailsPage = require('./showDetailsPage');
const VideoPlayerPage = require('./videoPlayerPage');
const ProfilePage = require('./profilePage');

const commons = mobileActions;
const searchPage = new SearchPage();
const menuPage = new MenuPage();
const myListPage = new MyListPage();
const showDetailsPage = new ShowDetailsPage();
const videoPlayerPage = new VideoPlayerPage();
const profilePage = new ProfilePage();

const showsAddedByOrder = [];
let currentShowsOrder = [];

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  formerShow = null;

  myListShowTitle = this.getMyListShowTitle();

  forYou_lbl = this.#getSelectorData('forYou_lbl');

  crime_lbl = this.#getSelectorData('crime_lbl');

  paranormal_lbl = this.#getSelectorData('paranormal_lbl');

  featuredRail_lbl = this.#getSelectorData('featuredRail_lbl');

  rail_lbl = this.#getSelectorData('rail_lbl');

  action_btn = this.getElementByPage('basePage', 'action_btn');

  showCardThumbnail_img = this.#getSelectorData('showCardThumbnail_img');

  showCardNetworkLogo_img = this.#getSelectorData('showCardNetworkLogo_img');

  showCardTitle_lbl = this.#getSelectorData('showCardTitle_lbl');

  firstShow_tile = this.getElementByPage('searchPage', 'firstContent');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  myList_btn = this.getElementByPage('accountPage', 'myList_btn');

  homeMenu_lbl = this.getElementByPage('menuPage', 'homeMenu_lbl');

  networkRail_lbl = this.#getSelectorData('networkRail_lbl');

  networkTile_lbl = this.#getSelectorData('networkTile_lbl');

  network_img = this.#getSelectorData('network_img');

  firstTileOnRail_lbl = this.#getSelectorData('firstTileOnRail_lbl');

  signUp_btn = this.getElementByPage('showPage', 'signUp_btn');

  watchNow_btn = this.getElementByPage('showPage', 'watchNow_btn');

  removeMyList_lbl = this.getElementByPage('myListPage', 'removeMyList_lbl');

  addMyList_lbl = this.getElementByPage('myListPage', 'addMyList_lbl');

  homeHeroLogo_img = this.#getSelectorData('homeHeroLogo_img');

  primaryPoster = this.getElementByPage('homePage', 'primaryPosterShow');

  enlargedPoster = this.getElementByPage('homePage', 'enlargedPosterShow');

  standardPoster = this.getElementByPage('homePage', 'standardPosterShow');

  sportsPosterTitle = this.getElementByPage('homePage', 'sportsPosterTitle');

  posterChannelLogo = this.getElementByPage('homePage', 'channelLogo');

  tab_bar = this.getElementByPage('basePage', 'tab_bar');

  cancel_btn = this.getElementByPage('accountPage', 'focusedCancelPopUp');

  ctaButtons = this.getElementByPage('showPage', 'ctaButtons');

  account_lbl = this.getElementByPage('accountPage', 'account_lbl');

  signOut_btn = this.getElementByPage('accountPage', 'signOut_btn');

  signOut_popup = this.getElementByPage('accountPage', 'signOut_popup');

  searchScreenShowsTab = this.getElementByPage(
    'searchPage',
    'searchScreenShowsTab',
  );

  posterShowNameTitle = this.getElementByPage(
    'showPage',
    'posterShowNameTitle',
  );

  inLineHero = this.#getSelectorData('inLineHero');

  inLineHeroTitle = this.#getSelectorData('inLineHeroTitle');

  inLineHeroDescription = this.#getSelectorData('inLineHeroDescription');

  inLineHeroCTA = this.#getSelectorData('inLineHeroCTA');

  primaryPosterShow = this.getCustomLocator(
    this.primaryPoster,
    testdataHelper.getContent('homePage.sportsPosterShowName'),
  );

  enlargedPosterShow = this.getCustomLocator(
    this.enlargedPoster,
    testdataHelper.getContent('homePage.sportsPosterShowName'),
  );

  primaryPosterTitle = this.getCustomLocator(
    this.sportsPosterTitle,
    testdataHelper.getContent('homePage.sportsPosterShowName'),
  );

  channelLogo = this.getCustomLocator(
    this.posterChannelLogo,
    testdataHelper.getContent('homePage.sportsPosterShowName'),
  );

  standardPosterShow = this.getCustomLocator(
    this.sportsPosterTitle,
    testdataHelper.getContent('homePage.sportsStandardShowName'),
  );

  standardPosterTitle = this.getCustomLocator(
    this.standardPoster,
    testdataHelper.getContent('homePage.sportsStandardShowName'),
  );

  myListIcon = this.getElementByPage('myListPage', 'favorite_btn');

  keyBoardReturn_btn = this.getElementByPage('basePage', 'keyBoardReturn_btn');

  playerPause_btn = this.getElementByPage('videoPlayerPage', 'playerPause_btn');

  playerProgress_bar = this.getElementByPage(
    'eventDetailsPage',
    'livePlayerSeekBar',
  );

  playerLive_lbl = this.getElementByPage('eventDetailsPage', 'live_lbl');

  jipVideoTitle_lbl = this.getElementByPage(
    'videoPlayerPage',
    'jipVideoTitle_lbl',
  );

  videoContainerView = this.getElementByPage(
    'videoPlayerPage',
    'videoContainerView',
  );

  search_txtBx = this.getElementByPage('searchPage', 'search_txtBx');

  jipChannelTab = this.getElementByPage('showPage', 'channelsTab');

  jipContentName_img = this.getElementByPage('showPage', 'jipContentName_img');

  jipShowName = '';

  rating = this.#getSelectorData('rating');

  nextEpisodeRating = this.getElementByPage('showPage', 'nextEpisodeRating');

  genreTabItems = {
    'For You': this.forYou_lbl,
    Crime: this.crime_lbl,
    'Paranormal and Unexplained': this.paranormal_lbl,
  };

  railNames = {
    Featured: this.featuredRail_lbl,
    'My List': this.getCustomLocator(this.rail_lbl, 'My List'),
    postEnlargedRail: this.getCustomLocator(
      this.rail_lbl,
      'Link testing - Poster-Enlarged',
    ),
    primaryPosterRail: this.getCustomLocator(
      this.rail_lbl,
      'Link testing - poster primary',
    ),
    standardPosterRail: this.getCustomLocator(
      this.rail_lbl,
      'Link testing - poster primary',
    ),
    Network: this.networkRail_lbl,
    'Recommended For You': this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('networkPage.RecommendedForYouRail'),
    ),
    'Sports Documentaries': this.getCustomLocator(
      this.rail_lbl,
      'Sports Documentaries',
    ),
    'Coming Soon': this.getCustomLocator(this.rail_lbl, 'Coming Soon'),
    Trending: this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('homePage.trending'),
    ),
    'Leaving Soon': this.getCustomLocator(this.rail_lbl, 'Leaving Soon'),
    discovery: this.getCustomLocator(
      this.networkRail_lbl,
      testdataHelper.getContent('homePage.discovery'),
    ),
    'discovery Plus Channels': this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('homePage.discoveryPlusChannels'),
    ),
    'Top Searches': this.getCustomLocator(this.rail_lbl, 'Top Searches'),
    'Continue Watching': this.getCustomLocator(
      this.rail_lbl,
      'Continue Watching',
    ),
  };

  regionRailName = {
    emea: 'comingSoonRail',
    america: 'topSearchedRail',
  };

  pageNames = {
    Home: menuPage.homeMenu_lbl,
    Search: menuPage.searchMenu_lbl,
    Sports: menuPage.sportsMenu_lbl,
    Browse: menuPage.browse_lbl,
  };

  showTiles = {
    FirstTileOnFeaturedRail: this.#getSelectorData(
      'firstTileOnFeaturedRail_lbl',
    ),
    FirstShow: this.firstShow_tile,
  };

  assertCTAButton = {
    anonymous: this.signUp_btn,
    'fully-entitled': this.watchNow_btn,
    'non-entitled': this.watchNow_btn,
  };

  selectShow = async (index) => {
    await commons.click(this.showTiles[index], 10);
  };

  selectGenreTab = async (genreName) => {
    for (let i = 0; i < 10; i++) {
      if (!(await commons.elementExists(this.genreTabItems[genreName]))) {
        await commons.swipeOnElement(this.tab_bar, 'left', 5);
      } else {
        await commons.click(this.genreTabItems[genreName]);
        return;
      }
    }
    throw new Error(`'${genreName}' is not present!'`);
  };

  scrollToRail = async (railName, isPresent = true) => {
    const actualFlag = await this.isRailPresent(
      this.railNames[railName],
      '40%',
    );

    assert.strictEqual(
      actualFlag,
      isPresent,
      new TypeError(
        `Validation Failed! , Actual: ${railName} rail is not present`,
      ),
    );
  };

  scrollToRailByElement = async (railName) => {
    await commons.scrollToElement(this.railNames[railName], 'down', 5);
  };

  isRailPresent = async (railName, percentageVal = '30%') => {
    for (let count = 0; count < 20; count++) {
      if (await commons.elementExists(railName, 5)) return true;
      await commons.scrollOnPageByPercentage('down', percentageVal);
    }
    return false;
  };

  verifyRailPresent = async (railName, expflag, percentageVal = '30%') => {
    const actualFlag = await this.isRailPresent(
      this.railNames[railName],
      percentageVal,
    );

    assert.strictEqual(
      actualFlag,
      expflag,
      new TypeError(
        `Validation Failed! , Actual: ${railName} rail is not present`,
      ),
    );
  };

  clickAddToFavourites = async () => {
    await myListPage.clickAddToFavourites();
  };

  verifyMyListRailMetadata = async (showCount) => {
    await commons.waitUntil(this.homeMenu_lbl);
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.forYou_lbl);
    await commons.click(this.forYou_lbl, 20);
    await this.scrollToRail('My List', true);
    const thumbNailImages = await commons.findElements(
      this.getCustomLocator(this.showCardThumbnail_img, 'My List'),
    );
    const showTitles = await commons.findElements(
      this.getCustomLocator(this.showCardTitle_lbl, 'My List'),
    );
    const networkIcons = await commons.findElements(
      this.getCustomLocator(this.showCardNetworkLogo_img, 'My List'),
    );

    if (
      (thumbNailImages.length && showTitles.length && networkIcons.length) ===
      parseInt(showCount, 10)
    ) {
      for (let i = 0; i < showCount; i++) {
        assert.equal(
          await commons.isEnabled(thumbNailImages[i]),
          true,
          'thumbnailImage metadata validation failed',
        );
        assert.equal(
          await commons.isEnabled(networkIcons[i]),
          true,
          'network Logo metadata validation failed',
        );
        assert.equal(
          await commons.isEnabled(showTitles[i]),
          true,
          'show label metadata validation failed',
        );
      }
    } else {
      throw new Error('My list show count not matching');
    }
  };

  verifyMyListRailShowOrder = async () => {
    currentShowsOrder = await this.getListOfShows(
      this.getCustomLocator(this.showCardTitle_lbl, 'My List'),
    );
    assert.equal(
      currentShowsOrder.toString,
      showsAddedByOrder.toString,
      'Shows are not in order',
    );
  };

  verifyVideoPlayed = async () => {
    /* Show Rail playback validation */
    await this.selectShow('FirstTileOnFeaturedRail');
    await showDetailsPage.selectAndPlayVideo(1);
    await videoPlayerPage.isVideoPlaying();
    await videoPlayerPage.closeShowPlayer();
    await commons.clickBack();

    /* Page navigation to Shows landing */
    await commons.waitUntil(this.action_btn);
  };

  addShowToMyList = async (index) => {
    const listOfShows = testdataHelper.getContent('searchPage.myListShows');

    await menuPage.navigateToPage('Search');
    for (let i = 0; i < index; i++) {
      await searchPage.searchShow(listOfShows[i]);
      await this.selectShow('FirstShow');
      await myListPage.clickAddToFavourites();
      showsAddedByOrder.push(listOfShows[i]);
      await commons.click(myListPage.back_btn);
      if (await commons.elementExists(searchPage.clear_txtBx)) {
        await commons.click(searchPage.clear_txtBx);
      }
    }
    showsAddedByOrder.reverse();
  };

  removeFromMyList = async (showName) => {
    const multiContentShow = testdataHelper.getContent(
      `searchPage.${showName}`,
    );

    if (this.returnGeoLocation() === 'emea') {
      await menuPage.navigateToPage('Account');
    }
    await commons.waitUntil(this.myList_btn, 20);
    await commons.click(this.myList_btn);
    await myListPage.removeFromMyList(multiContentShow);
    await this.verifyUpdatedMyListRail(multiContentShow);
  };

  verifyUpdatedMyListRail = async (showName) => {
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.forYou_lbl);
    await commons.click(this.forYou_lbl, 20);
    await this.scrollToRail('My List', true);
    await this.verifyRailPresent('My List', true);
    currentShowsOrder = await this.getListOfShows(
      this.getCustomLocator(this.showCardTitle_lbl, 'My List'),
    );
    if (!currentShowsOrder.includes(showName)) return;
    throw new Error(`My List rail is not updated`);
  };

  validateCTAonPages = async (userType, pageName) => {
    const pageArr = pageName.raw();

    const failure = [];

    for (let i = 0; i < pageArr.length; i++) {
      const page = pageArr[i].toString().toLowerCase();

      switch (page) {
        case 'home':
          await this.scrollToRailByElement(
            testdataHelper.getContent('homePage.featured'),
          );
          if (await commons.elementExists(this.railNames.Featured)) {
            await commons.click(this.railNames.Featured);
          }
          await commons.waitUntil(this.showTiles.FirstTileOnFeaturedRail, 10);
          await this.selectShow('FirstTileOnFeaturedRail');
          break;
        case 'sports':
          if (this.returnGeoLocation() === 'emea') {
            // click on search glob-nav
            await commons.waitUntil(this.pageNames.Sports, 20);
            await commons.click(this.pageNames.Sports);
            // click on any show
            await this.verifyRailPresent(
              testdataHelper.getContent('sportsPage.sportsContent1'),
              true,
              '40%',
            );
            await commons.click(
              this.getCustomLocator(
                this.firstTileOnRail_lbl,
                testdataHelper.getContent('sportsPage.sportsContent1'),
              ),
            );
          }
          break;
        case 'search':
          {
            // click on search glob-nav
            await commons.waitUntil(this.pageNames.Search, 20);
            await commons.click(this.pageNames.Search);
            // click on any show
            const railName = testdataHelper.getContent(
              `searchPage.${
                this.regionRailName[this.returnGeoLocation().toLowerCase()]
              }`,
            );

            await this.verifyRailPresent(railName, true);
            await commons.click(
              this.getCustomLocator(this.firstTileOnRail_lbl, railName),
            );
          }
          break;
        case 'browse':
          if (this.returnGeoLocation() === 'america') {
            // click on search glob-nav
            await commons.waitUntil(this.pageNames.Browse, 20);
            await commons.click(this.pageNames.Browse);
            // click on any show
            if (await commons.elementExists(this.showTiles.FirstShow, 10)) {
              await commons.click(this.showTiles.FirstShow);
            }
          }
          break;
        default:
      }

      if (
        !(this.returnGeoLocation() === 'america' && page === 'sports') &&
        !(this.returnGeoLocation() === 'emea' && page === 'browse')
      ) {
        try {
          await showDetailsPage.verifyShowLandingAnchorDetails();
          await this.validateCTAForUser(userType);
          await commons.clickBack();
        } catch (e) {
          failure.push(`CTA validation failed for ${page} page!`);
          await commons.clickBack();
        }
      }
    }

    if (failure.length !== 0) {
      throw new Error(failure.toString());
    }
  };

  validateCTAForUser = async (userType) => {
    await commons.waitUntil(this.assertCTAButton[userType.toLowerCase()]);
  };

  verifyKidsContentPopulated = async () => {
    await menuPage.navigateToPage('Search');
    await searchPage.clearSearchTextBox();
    await searchPage.searchText('kidsShowName');
    await commons.waitUntil(searchPage.firstContentTitle, 20);
    const kidsShowTitle = await commons.fetchAttributeData(
      searchPage.firstContentTitle,
      'label',
    );

    const expectedKidsShowTitle = searchPage.searchedContent;

    assert.equal(kidsShowTitle, expectedKidsShowTitle);
    await searchPage.clearSearchTextBox();
    await searchPage.searchText('adultShowName');
    const adultShowTitle = await commons.fetchAttributeData(
      searchPage.firstContentTitle,
      'label',
    );

    const expectedAdultShowTitle = searchPage.searchedContent;

    assert.notEqual(
      adultShowTitle,
      expectedAdultShowTitle,
      'Adult Rated Content visible in Kids User Profile',
    );
  };

  verifyJIPContent = async () => {
    await searchPage.clearSearchTextBox();
    await searchPage.searchText('JIPShowName');
    if (await commons.elementExists(this.searchScreenShowsTab)) {
      await commons.click(this.searchScreenShowsTab);
    }
    const jipShowTitle = await commons.fetchAttributeData(
      searchPage.firstContentTitle,
      'label',
    );

    const expectedJIPShowTitle = searchPage.searchedContent;

    assert.notEqual(
      jipShowTitle,
      expectedJIPShowTitle,
      'JIP Content visible in Kids User Profile',
    );
  };

  /**
   * The below function will verify Shows Availablity in MyList Rail
   *
   * @param {boolean} isShowPresent - Status of Show in MyList Rail is true or false
   */

  verifyShowsInMyListRail = async (isShowPresent) => {
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.forYou_lbl);
    await commons.click(this.forYou_lbl, 20);
    await commons.waitUntil(this.forYou_lbl, 30);
    await this.scrollToRailByElement('My List');
    await this.verifyRailPresent('My List', true);
    const myListshowsList = await this.getListOfShows(
      this.getCustomLocator(this.showCardTitle_lbl, 'My List'),
    );

    this.setMyListRailShowsList(myListshowsList);
    const showStatus = myListshowsList.includes(this.getMyListShowTitle());

    if (isShowPresent) {
      assert.strictEqual(
        showStatus,
        isShowPresent,
        new TypeError(
          `Validation Failed! , ${this.getMyListShowTitle()} is not present in MyList rail`,
        ),
      );
      await menuPage.navigateToPage('Home');
    } else {
      assert.strictEqual(
        showStatus,
        isShowPresent,
        new TypeError(
          `Validation Failed! , ${this.getMyListShowTitle()} is  present in MyList rail`,
        ),
      );
    }
  };

  scrollToNetworkRail = async () => {
    await this.scrollToRail('Network', true);
    await this.verifyRailPresent('Network', true);
  };

  validateNetworkRail = async () => {
    await commons.waitUntil(this.networkTile_lbl);
    await commons.waitUntil(this.network_img);
  };

  addShowToMylistFromHomeHero = async () => {
    await myListPage.removeAllShowsFromMyListPage();
    await menuPage.navigateToPage('Home');

    await commons.waitUntil(this.addMyList_lbl);
    await myListPage.clickAddToFavourites();

    if (this.formerShow === null) {
      this.formerShow = await commons.fetchAttributeData(
        this.homeHeroLogo_img,
        'label',
      );
      this.setMyListShowTitle(
        await commons.fetchAttributeData(this.homeHeroLogo_img, 'label'),
      );
    } else {
      this.setMyListShowTitle(
        await commons.fetchAttributeData(this.homeHeroLogo_img, 'label'),
      );
    }
  };

  verifySportsRail = async (sportsRailType) => {
    await menuPage.assertPage('Home');
    const sportsRail = {
      primary: 'primaryPosterRail',
      enlarged: 'postEnlargedRail',
      'standard primary': 'standardPosterRail',
    };

    await this.scrollToRail(sportsRail[sportsRailType], true);
  };

  assertPrimaryPosterMetadata = async () => {
    await commons.waitUntil(this.primaryPosterShow);
    await commons.waitUntil(this.primaryPosterTitle);
    await commons.waitUntil(this.primaryPosterTitle);
    const isChannelLogoDisplayed = await commons.elementExists(
      this.channelLogo,
      5,
    );

    assert(
      !isChannelLogoDisplayed,
      `A Channel Logo is being displayed below Primary Poster`,
    );
    await commons.click(this.primaryPosterShow);
  };

  assertEnlargedPosterMetadata = async () => {
    await commons.waitUntil(this.enlargedPosterShow);
    const isChannelLogoDisplayed = await commons.elementExists(
      this.channelLogo,
      5,
    );

    assert(
      !isChannelLogoDisplayed,
      `A Channel Logo is being displayed below Primary Poster`,
    );
    await commons.click(this.enlargedPosterShow);
  };

  assertStandardPosterMetadata = async () => {
    await commons.waitUntil(this.standardPosterShow);
    await commons.waitUntil(this.standardPosterTitle);
    const isChannelLogoDisplayed = await commons.elementExists(
      this.channelLogo,
      5,
    );

    assert(
      !isChannelLogoDisplayed,
      `A Channel Logo is being displayed below Primary Poster`,
    );
    await commons.click(this.standardPosterShow);
  };

  verifySportsCardMetadata = async (sportsRailType) => {
    switch (sportsRailType) {
      case 'primary':
        await this.assertPrimaryPosterMetadata();
        break;
      case 'enlarged':
        await this.assertEnlargedPosterMetadata();
        break;
      case 'standard primary':
        await this.assertStandardPosterMetadata();
        break;
      default:
        break;
    }
  };

  selectSportsCard = async () => {
    await commons.waitUntil(this.posterShowNameTitle);
  };

  navigateToSportsInLineHero = async () => {
    await commons.scrollToElement(this.inLineHero, 'up');
  };

  verifySportsInLineHeroMetadata = async () => {
    await commons.waitUntil(this.inLineHeroTitle);
    await commons.waitUntil(this.inLineHeroDescription);
    await commons.waitUntil(this.inLineHeroCTA);
    const isChannelLogoDisplayed = await commons.elementExists(
      this.channelLogo,
      5,
    );

    assert(
      !isChannelLogoDisplayed,
      `A Channel Logo is being displayed below Primary Poster`,
    );
  };

  selectInlineHeroCTA = async () => {
    await commons.click(this.inLineHeroCTA);
  };

  verifyMyListCtaForShow = async () => {
    await this.selectShow('FirstTileOnFeaturedRail');
    await menuPage.validateCTAPresent('My List', false);
  };

  verifyMyListShowAvailability = () => {
    const myListPageShowStatus = this.getMyListPageShowsList().includes(
      this.formerShow,
    );
    const myListRailShowStatus = this.getMyListPageShowsList().includes(
      this.formerShow,
    );

    assert.strictEqual(
      myListPageShowStatus,
      false,
      new TypeError(
        `Validation Failed! , Actual: ${this.formerShow} is present in MyList page`,
      ),
    );

    assert.strictEqual(
      myListRailShowStatus,
      false,
      new TypeError(
        `Validation Failed! , Actual: ${this.formerShow} is present in MyList rail`,
      ),
    );
  };

  verifyMyListRailOnHomePage = async (railName, railStatus) => {
    await menuPage.navigateToPage('Home');
    await this.scrollToRail(railName, railStatus);
  };

  verifyJipContentPlayback = async (pageName) => {
    if (pageName === 'Home Page') {
      let count = 0;

      while (
        !(await commons.elementExists(
          this.railNames['discovery Plus Channels'],
          5,
        )) &&
        count < 3
      ) {
        await this.scrollToRail('discovery Plus Channels');
        count++;
      }
      await commons.click(
        this.getCustomLocator(
          this.firstTileOnRail_lbl,
          testdataHelper.getContent('homePage.discoveryPlusChannels'),
        ),
      );

      assert(
        await commons.elementExists(this.jipVideoTitle_lbl, 10),
        `JIP Content is not displayed`,
      );

      this.jipShowName = await commons.fetchAttributeData(
        this.jipVideoTitle_lbl,
        'label',
        10,
      );
      await this.verifyJIPVideoPlayback();
    } else if (pageName === 'Show Details Page') {
      await commons.clickBack();
      await menuPage.navigateToPage('Search');
      const jipShowtext = this.jipShowName.toString().replace(' Channel', '');

      await commons.sendText(this.search_txtBx, jipShowtext, 5);
      await this.selectShow('FirstShow');
      await commons.waitUntil(this.jipChannelTab, 20);
      await commons.click(this.jipChannelTab, 5);
      await commons.waitUntil(this.jipContentName_img);
      await commons.click(this.jipContentName_img);
      await this.verifyJIPVideoPlayback();
    }
  };

  verifyJIPVideoPlayback = async () => {
    if (!(await commons.elementExists(this.playerPause_btn, 15))) {
      await commons.click(this.videoContainerView, 15);
    }
    await commons.waitUntil(this.playerPause_btn);
    await commons.waitUntil(this.playerProgress_bar);
  };

  /**
   * This function will validate ageRating and Content on multiple Screens
   */

  verifyAgeRatingAndContentDescriptors = async (screensType) => {
    switch (screensType) {
      case 'Main Hero':
        break;

      case 'Show Details Page':
        await menuPage.navigateToPage('Search');
        await searchPage.searchText('multiContentShow');
        await searchPage.selectFirstResult();
        break;

      case 'Currently Playing Episode':
        await commons.click(this.ctaButtons);
        break;

      case 'Next Episodes listed on Episode Landing Page':
        assert(
          await commons.elementExists(this.nextEpisodeRating),
          `Rating for the Next Episode is not displayed`,
        );
        commons.clickBack();
        break;

      case 'Episode Info Panel':
        await commons.click(this.ctaButtons);
        break;

      default:
        throw new Error(
          'Actual screenType provided is not as per the expectations',
        );
    }

    if (screensType !== 'Next Episodes listed on Episode Landing Page') {
      assert(
        await commons.elementExists(this.rating),
        `Rating for the show is not displayed`,
      );

      const ratingLabel = await commons.fetchAttributeData(
        this.rating,
        'label',
        10,
      );

      // Remove "Rated " from ratingLabel
      const currentRating = ratingLabel.split(' ')[1];
      const ratingList = testdataHelper.getContent('ratingList');

      assert(
        ratingList.includes(currentRating),
        `Rating is not as per rating standards`,
      );
    }
  };

  continueWatchingRailShowMetadata = {
    showName: this.getCustomLocator(
      this.showCardTitle_lbl,
      'Continue Watching',
    ),
    episodeNameAndDescription: this.getElementByPage(
      'eventDetailsPage',
      'subTitle_lbl',
    ),
    thumbnailImage: this.getCustomLocator(
      this.showCardThumbnail_img,
      'Continue Watching',
    ),
    channelLogo: this.#getSelectorData('channelImage'),
    contentRatingLabel: this.getElementByPage('showPage', 'aboutShowLabel'),
  };

  verifyContinueWatchingMetadata = async () => {
    const showDetails = [
      'showName',
      'episodeNameAndDescription',
      'thumbnailImage',
      'channelLogo',
      'contentRatingLabel',
    ];

    for (let i = 0; i < showDetails.length; i++) {
      await commons.waitUntil(
        this.continueWatchingRailShowMetadata[showDetails[i]],
      );
    }
  };

  resumeAndPlayVideo = async () => {
    await commons.click(
      this.getCustomLocator(this.firstTileOnRail_lbl, 'Continue Watching'),
    );
    await videoPlayerPage.isVideoPlaying();
  };

  signOut = async () => {
    await menuPage.navigateToPage('Account');

    if (await commons.elementExists(this.signOut_btn)) {
      await commons.click(this.signOut_btn);
    } else {
      await profilePage.selectProfile('Default');
      await commons.waitUntil(menuPage.focusedHomePage, 30);
      await commons.click(menuPage.accountMenu_lbl, 30);
      if (await commons.elementExists(this.account_lbl)) {
        await commons.scrollOnPage('down');
      }
      await commons.waitUntil(this.signOut_btn, 30);
      await commons.click(this.signOut_btn);
    }

    if (await commons.elementExists(this.signOut_popup)) {
      await commons.click(this.signOut_popup, 10);
    }
  };
}

module.exports = HomePage;
