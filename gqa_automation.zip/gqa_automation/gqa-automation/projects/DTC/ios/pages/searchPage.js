const assert = require('assert');
const retry = require('async-retry');
const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const ShowDetailsPage = require('./showDetailsPage');
const SportsPage = require('./sportsPage');
const VideoPlayerPage = require('./videoPlayerPage');

const commons = mobileActions;
const showDetailsPage = new ShowDetailsPage();
const sportsPage = new SportsPage();
const videoPlayerPage = new VideoPlayerPage();

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  search_txtBx = this.#getSelectorData('search_txtBx');

  showTitle_lbl = this.#getSelectorData('showTitle_lbl');

  listOfContents = this.#getSelectorData('listOfContents');

  showNetworkIcon_img = this.#getSelectorData('showNetworkIcon_img');

  firstContentTitle = this.#getSelectorData('firstContentTitle');

  searchScreenTabsList = this.#getSelectorData('searchScreenTabsList');

  clear_txtBx = this.#getSelectorData('clear_txtBx');

  firstShow_tile = this.#getSelectorData('firstContent');

  searchTabs = this.#getSelectorData('searchTabs');

  closeOrBack_btn = this.#getSelectorData('closeOrBack_btn');

  searchResultTabs = {
    Shows: this.#getSelectorData('showsTab'),
    Episodes: this.#getSelectorData('episodesTab'),
    Extras: this.#getSelectorData('extrasTab'),
    Sports: this.#getSelectorData('sportsTab'),
    Collections: this.#getSelectorData('collectionsTab'),
    Specials: this.#getSelectorData('specialsTab'),
  };

  showTiles = {
    FirstShow: this.firstShow_tile,
  };

  searchedContent = '';

  selectShow = async (index) => {
    await commons.click(this.showTiles[index], 10);
  };

  getShowTitle = async (index) => {
    const showTitlesElements = await commons.findElements(this.showTitle_lbl);

    return showTitlesElements[index];
  };

  searchText = async (text) => {
    const showName = testdataHelper.getContent(`searchPage.${text}`);

    this.searchedContent = showName;
    await commons.sendText(this.search_txtBx, showName, 20);
  };

  searchShow = async (showName) => {
    await commons.sendText(this.search_txtBx, showName, 20);
  };

  selectFirstResult = async () => {
    await commons.click(this.firstShow_tile);
  };

  verifyIfSearchResultsLoaded = async () => {
    await commons.waitUntil(this.firstContentTitle, 30);
    await commons.waitUntil(this.showNetworkIcon_img, 30);
  };

  clearSearchTextBox = async () => {
    await commons.clearText(this.search_txtBx, 15);
  };

  verifyResultsIncludeSearchText = async () => {
    const titleValue = await commons.fetchAttributeData(
      await this.getShowTitle(0),
      'label',
    );

    assert.equal(
      titleValue,
      this.searchedContent,
      `Search result does not include '${this.searchedContent}'. Actual: ${titleValue}`,
    );
  };

  verifyLandingPageBasedOnContent = async () => {
    const searchTabs = testdataHelper.getContent('searchPage.searchResultTabs');

    for (let i = 0; i < searchTabs.length; i++) {
      await commons.waitUntil(this.searchResultTabs[searchTabs[i]]);
      await commons.click(this.searchResultTabs[searchTabs[i]], 60);
      await commons.waitUntil(this.firstContentTitle, 80);
      await this.selectShow('FirstShow');

      await this.verifySearchTabsLanding(searchTabs[i]);
      if (await commons.elementExists(this.closeOrBack_btn, 30)) {
        try {
          await retry(
            async () => {
              await commons.click(this.closeOrBack_btn, 30);
              await commons.waitUntil(this.search_txtBx, 30);
            },
            { retries: 3, minTimeout: 3000, maxTimeout: 5000 },
          );
        } catch (error) {
          await commons.clickBack();
        }
      }
      await commons.waitUntil(this.search_txtBx, 30);
      await commons.waitUntil(this.searchResultTabs[searchTabs[i]], 30);
    }
  };

  verifySearchTabsLanding = async (tabName) => {
    switch (tabName) {
      case 'Shows':
        await showDetailsPage.verifyShowLandingAnchorDetails();
        break;
      case 'Sports':
        await sportsPage.verifySportsScreenAnchorDetails();
        break;
      case 'Episodes':
      case 'Extras':
        await videoPlayerPage.verifyVideoPlayerAnchorDetails();
        if (!(await this.getUserAnonymous())) {
          await commons.clickBack();
        }
        break;
      default:
        break;
    }
  };

  verifySearchTabsDisplayed = async () => {
    const searchTabsNotPresentList = [];

    const expectedSearchTabs = new Set(
      testdataHelper.getContent('searchPage.searchResultTabs'),
    );

    const tabName = new Set();

    const actualSearchTabsList = await commons.findElements(
      this.searchScreenTabsList,
    );

    for (let i = 0; i < expectedSearchTabs.size - 1; i++) {
      if (i > 0) {
        await commons.swipeOnElement(this.searchTabs, 'left', 5);
      }

      tabName.add(
        await commons.fetchAttributeData(actualSearchTabsList[i], 'label'),
      );

      if (![...tabName].every((x) => expectedSearchTabs.has(x))) {
        searchTabsNotPresentList.push(
          await commons.fetchAttributeData(actualSearchTabsList[i], 'label'),
        );
      }
    }
    await commons.swipeOnElement(this.searchTabs, 'right', 5);
    if (searchTabsNotPresentList.length !== 0) {
      throw new Error(
        `Validation Failed for search tabs!! Search tabs not present: '${searchTabsNotPresentList}'`,
      );
    }
  };

  verifySearchedContentAndItsLandingPage = async () => {
    await this.verifyIfSearchResultsLoaded();
    await this.verifyResultsIncludeSearchText();
    await this.verifySearchTabsDisplayed();
    await this.verifyLandingPageBasedOnContent();
  };
}

module.exports = SearchPage;
