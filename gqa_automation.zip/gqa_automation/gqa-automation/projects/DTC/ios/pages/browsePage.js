const assert = require('assert');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const MenuPage = require('./menuPage');

const menuPage = new MenuPage();

const commons = mobileActions;

class BrowsePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('browsePage', locator);
  }

  selectedNetworkShowList;

  currentselectedNetworkShowList;

  networkTypeSelected;

  ctaButtons = this.getElementByPage('showPage', 'ctaButtons');

  myList_btn = this.getElementByPage('accountPage', 'myList_btn');

  listOfShowLabels = this.#getSelectorData('listOfShowLabels');

  networksTab = this.#getSelectorData('networksTab');

  subNavTab = this.#getSelectorData('subNavTab');

  networkIcon = this.#getSelectorData('networkIcon');

  allNetwork_lbl = this.getElementByPage('browsePage', 'allNetwork_lbl');

  subNavSelected_btn = this.#getSelectorData('subNavSelected_btn');

  trendingSubNav = this.getCustomLocator(this.subNavSelected_btn, 'Trending');

  listOfShowTiles = this.#getSelectorData('listOfShowTiles');

  browse_lbl = this.getElementByPage('menuPage', 'browse_lbl');

  networkCollection = this.#getSelectorData('networkCollection');

  networksTab_lbl = this.#getSelectorData('networksTab_lbl');

  selectPage = async (pageType) => {
    if (this.returnGeoLocation() === 'america' && pageType === 'Browse') {
      await commons.waitUntil(this.browse_lbl, 20);
      await commons.click(this.browse_lbl);
    } else if (this.returnGeoLocation() === 'emea') {
      await commons.click(menuPage.accountMenu_lbl);
      await commons.waitUntil(this.myList_btn, 20);
      await commons.click(this.myList_btn);
      await commons.waitUntil(this.ctaButtons, 20);
      await commons.click(this.ctaButtons);
    }
    await commons.waitUntil(this.allNetwork_lbl, 20);
  };

  verifyBrowsePage = async () => {
    await commons.waitUntil(this.allNetwork_lbl, 60);
    await commons.waitUntil(this.trendingSubNav, 20);
    const isNetworkSelected = await commons.fetchAttributeData(
      this.allNetwork_lbl,
      'selected',
    );
    const isSubNavSelected = await commons.elementExists(this.trendingSubNav);

    assert.equal(
      isNetworkSelected,
      'true',
      'All networks tab is not selected by Default',
    );
    assert.equal(
      isSubNavSelected,
      true,
      'Trending Sub navigation is not selected by Default',
    );
    this.selectedNetworkShowList = await this.getListOfShows(
      this.listOfShowLabels,
    );
  };

  selectNetwork = async (networkType) => {
    const networkName = testdataHelper.getContent(`networkPage.${networkType}`);
    const entertainmentNetwork = this.getCustomLocator(
      this.networksTab,
      networkName,
    );
    let networkList = await this.getListOfShows(this.networksTab_lbl);

    let count = 0;

    while (!networkList.includes(networkName) && count < 3) {
      await commons.swipeOnElement(this.networkCollection, 'left', 5);
      networkList = await this.getListOfShows(this.networksTab_lbl);
      count++;
    }
    this.networkTypeSelected = await commons.fetchAttributeData(
      entertainmentNetwork,
      'label',
    );
    await commons.click(entertainmentNetwork);
  };

  verifyShowOnSelectedNetwork = async () => {
    await commons.waitUntil(this.trendingSubNav);
    this.currentselectedNetworkShowList = await this.getListOfShows(
      this.listOfShowLabels,
    );
    const isShowListRefreshed = this.currentselectedNetworkShowList.includes(
      this.selectedNetworkShowList,
    );

    assert.equal(
      isShowListRefreshed,
      false,
      'Current selected network shows are not displayed',
    );
  };

  selectSubNav = async (subNav) => {
    const subNavigationTabName = testdataHelper.getContent(
      `browsePage.${subNav}`,
    );
    const isSubNavSelected = await commons.elementExists(this.trendingSubNav);

    assert.equal(
      isSubNavSelected,
      true,
      'Trending Sub navigation is not selected by Default',
    );
    const subNavigationTab = this.getCustomLocator(
      this.subNavTab,
      subNavigationTabName,
    );

    await commons.waitUntil(subNavigationTab);
    await commons.click(subNavigationTab);
  };

  verifyShowCard = async () => {
    await commons.waitUntil(this.listOfShowLabels);
    await commons.waitUntil(this.networkIcon);
    const listOfShowNames = await this.getListOfShows(this.listOfShowTiles);

    for (let i = 0; i < listOfShowNames.length; i++) {
      const isSelectedNetworkIcon = listOfShowNames[i].includes(
        this.networkTypeSelected,
      );

      assert.equal(
        isSelectedNetworkIcon,
        true,
        'Show card network icon is different from selected network',
      );
    }
  };
}

module.exports = BrowsePage;
