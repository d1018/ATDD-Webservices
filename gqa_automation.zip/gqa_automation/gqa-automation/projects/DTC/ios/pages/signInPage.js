const { BasePage, mobileActions } = require('./basePage');

const PreLaunchPage = require('./prelaunchPage');
const HomePage = require('./homePage');

const { desiredIosCapabilities } = require('../capabilities/bsCaps');

const commons = mobileActions;
const preLaunchPage = new PreLaunchPage();
const homePage = new HomePage();

const geoCode = process.env.GEO.toLowerCase();
const serverURL = process.env.SERVER_URL
  ? process.env.SERVER_URL.toLowerCase()
  : '';

const localExecution = process.env.LOCAL_EXECUTION === 'true' || false;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  signIn_btn = this.#getSelectorData('signIn_btn');

  signOut_btn = this.getElementByPage('accountPage', 'signOut_btn');

  signOut_popup = this.getElementByPage('accountPage', 'signOut_popup');

  focusedSignInPage = this.#getSelectorData('focusedSignInPage');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  userName_txtBx = this.#getSelectorData('userName_txtBx');

  password_txtBx = this.#getSelectorData('password_txtBx');

  continue_btn = this.#getSelectorData('continue_btn');

  ok_caps_btn = this.getElementByPage('preLaunchPage', 'ok_caps_btn');

  homeMenu_lbl = this.getElementByPage('menuPage', 'homeMenu_lbl');

  manageProfiles_btn = this.getElementByPage(
    'accountPage',
    'manageProfiles_btn',
  );

  #isUserAnonymousType = false;

  #isUserSignedIn = false;

  startWatchingAnonymousUser_lbl = this.getElementByPage(
    'videoPlayerPage',
    'startWatchingAnonymousUser_lbl',
  );

  whoIsWatching_lbl = this.getElementByPage('profilePage', 'whoIsWatching_lbl');

  profile_btn = this.getElementByPage('profilePage', 'profile_btn');

  defaultProfile = this.getCustomLocator(this.profile_btn, 'Default');

  isUserAnonymous = async () => {
    const result = await this.#isUserAnonymousType;

    return result;
  };

  userSignedInValue = async () => {
    const result = await this.#isUserSignedIn;

    return result;
  };

  async openApp() {
    commons.driverInit(serverURL, localExecution);
    await commons.openApp(desiredIosCapabilities);
    await preLaunchPage.acceptAllPopUp();
  }

  /* This code assumes that the sign in button exists only when the app
     is in a signed out state, and vice versa */
  isSignedOut = async () => {
    const result = await commons.elementExists(this.signIn_btn, 10);

    return result;
  };

  /* Performs several checks and navigation steps as part of the sign in
     and sign out process. Used to be a part of isSignedOut(), but was refactored
     to allow isSignedOut to be used outside of the sign in process. */
  signOutHelper = async () => {
    // Clicking on default profile to bypass "Who's Watching" page on iPad
    if (
      (await commons.elementExists(this.whoIsWatching_lbl, 10)) &&
      (await commons.elementExists(this.defaultProfile, 10))
    ) {
      await commons.click(this.defaultProfile);
    }

    // OK button for 'How to cast to your TV' dialogue
    if (await commons.elementExists(this.ok_caps_btn)) {
      await commons.click(this.ok_caps_btn);
    }
  };

  navigateToSignInScreen_EMEA = async () => {
    if (await this.signOutHelper()) {
      await commons.waitUntil(this.signIn_btn);
      await commons.click(this.signIn_btn);
      await commons.elementExists(this.focusedSignInPage);
    }
  };

  navigateToSignInScreen_US = async () => {};

  enterCredentials = async (credentialType) => {
    const username = process.env[`${credentialType}_USERNAME`];
    const password = process.env[`${credentialType}_PASSWORD`];

    if (geoCode === 'gb') {
      await commons.waitUntil(this.focusedSignInPage);
      await commons.clickCoordinates(165, 190, username); // e-mail
      await commons.clickCoordinates(165, 280, password); // password
      await commons.clickCoordinates(165, 400); // sign in

      if (this.getStartWatchingAnonymousUser()) {
        return;
      }
      await commons.waitUntil(this.focusedHomePage, 100);
    }
    if (geoCode === 'us') {
      await commons.waitUntil(this.signIn_btn);
      await commons.click(this.signIn_btn);
      await commons.click(this.userName_txtBx);
      await commons.sendText(this.userName_txtBx, username);
      await commons.click(this.password_txtBx);
      await commons.sendText(this.password_txtBx, password);
      await commons.click(this.continue_btn);

      if (credentialType.includes('LAPSED')) {
        return;
      }
      // "Who's Watching" Page appears after sign in on iPadOS, select Default to continue
      if (
        (await commons.elementExists(this.whoIsWatching_lbl, 10)) &&
        (await commons.elementExists(this.defaultProfile, 10))
      ) {
        await commons.click(this.defaultProfile);
      }
      // OK button for 'How to cast to your TV' dialogue
      if (await commons.elementExists(this.ok_caps_btn)) {
        await commons.click(this.ok_caps_btn);
      }
      await commons.waitUntil(this.focusedHomePage, 30);
    }
  };

  loginToApplication = async (credentialType) => {
    const signedOutValue = await this.isSignedOut();

    if (!signedOutValue) {
      await this.signOutHelper();
      await homePage.signOut();
    }

    if (this.returnGeoLocation() === 'emea') {
      if (await commons.elementExists(this.startWatchingAnonymousUser_lbl)) {
        this.setStartWatchingAnonymousUser(true);
        this.setUserAnonymous(false);
        await commons.click(this.signIn_btn);
        await this.enterCredentials(credentialType);
        return;
      }

      if (credentialType === 'anonymous' && signedOutValue) {
        this.setUserAnonymous(true);
        await commons.click(this.homeMenu_lbl);
        return;
      }

      await this.navigateToSignInScreen_EMEA();
    } else await this.navigateToSignInScreen_US();

    // Clicking on default profile to bypass the "Who's Watching" page for iPad
    if (
      (await commons.elementExists(this.whoIsWatching_lbl, 10)) &&
      (await commons.elementExists(this.defaultProfile, 10))
    ) {
      await commons.click(this.defaultProfile);
    }

    await this.enterCredentials(credentialType);
    this.#isUserSignedIn = true;
  };

  verifySignOut = async () => {
    await commons.waitUntil(this.signIn_btn, 30);
  };
}

module.exports = SignInPage;
