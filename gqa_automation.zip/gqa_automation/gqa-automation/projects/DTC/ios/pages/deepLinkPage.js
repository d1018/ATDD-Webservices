const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;
const prefix = 'discoveryplus://discoveryplus.com/';
const deepLinkValues = {
  manageAccount: 'account',
  shows: 'shows',
  home: 'home',
};

class DeepLinkPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('deepLinkPage', locator);
  }

  manageProfiles_btn = this.getElementByPage(
    'accountPage',
    'manageProfiles_btn',
  );

  backgroundApp = async () => {
    await commons.backgroundApp(10);
  };

  verifyAppOpened = async () => {
    const context = await commons.currentContext();

    assert(context === 'NATIVE_APP', 'App is not in native context');
  };

  deepLinkTo = async (linkType) => {
    const url = `${prefix}${deepLinkValues[linkType]}`;

    await commons.deepLinkTo(url);
  };

  verifyAccountScreen = async () => {
    await commons.waitUntil(this.manageProfiles_btn, 30);
  };
}

module.exports = DeepLinkPage;
