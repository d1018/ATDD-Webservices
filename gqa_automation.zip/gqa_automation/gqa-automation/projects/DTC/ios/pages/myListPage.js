const assert = require('assert');
const retry = require('async-retry');
const { BasePage, mobileActions } = require('./basePage');
const MenuPage = require('./menuPage');

const commons = mobileActions;
const menuPage = new MenuPage();

class MyListPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myListPage', locator);
  }

  myListShowTitle = this.getMyListShowTitle();

  favorite_btn = this.#getSelectorData('favorite_btn');

  myListShowsList = this.#getSelectorData('myListShowsList');

  back_btn = this.#getSelectorData('back_btn');

  ctaButtons = this.getElementByPage('showPage', 'ctaButtons');

  allNetwork_lbl = this.getElementByPage('browsePage', 'allNetwork_lbl');

  firstShow_tile = this.getElementByPage('searchPage', 'firstContent');

  firstContentTitle = this.getElementByPage('searchPage', 'firstContentTitle');

  myList_btn = this.getElementByPage('accountPage', 'myList_btn');

  showTitle_lbl = this.#getSelectorData('showTitle_lbl');

  browse_lbl = this.getElementByPage('menuPage', 'browse_lbl');

  browseShows_btn = this.#getSelectorData('browseShows_btn');

  kebabButton = this.getElementByPage('browsePage', 'networkIcon');

  goToShow_btn = this.#getSelectorData('goToShow_btn');

  removeMyList_lbl = this.#getSelectorData('removeMyList_lbl');

  addMyList_lbl = this.#getSelectorData('addMyList_lbl');

  myList_lbl = this.#getSelectorData('myList_lbl');

  listOfContents = this.getElementByPage('searchPage', 'listOfContents');

  showTiles = {
    FirstShow: this.firstShow_tile,
  };

  selectShow = async (index) => {
    await commons.click(this.showTiles[index], 10);
  };

  clickAddToFavourites = async () => {
    await commons.click(this.favorite_btn);
  };

  removeFromMyListAndCheck = async (showName) => {
    let showTitleList = await this.getListOfShows(this.showTitle_lbl);

    await commons.waitUntil(this.showTitle_lbl);
    if (showTitleList.includes(showName)) {
      const index = showTitleList.indexOf(showName);
      const showItem = await commons.findElements(this.myListShowsList);

      if (index > 0) {
        // Removing shows from the beginning if there are more than 1 show on the My List Page
        await commons.click(showItem[index - 1]);
      } else {
        // Removing the only show from the My List page
        await commons.click(showItem[index]);
      }

      await commons.click(this.favorite_btn);
      await commons.waitUntil(this.back_btn, 10);
      await commons.click(this.back_btn);
      await commons.waitUntil(this.myListShowsList, 20);
      await menuPage.navigateToPage('Home');
      await menuPage.navigateToPage('My List');

      if (index > 0) {
        showTitleList = await this.getListOfShows(this.showTitle_lbl);

        await commons.waitUntil(this.showTitle_lbl);
        if (showTitleList.includes(showName)) {
          throw new Error(`'${showName}' show is not removed from Mylist`);
        } else if (this.returnGeoLocation() === 'emea') {
          await commons.click(this.back_btn);
        }
      }
    } else {
      throw new Error(`Show is not added to MyList '${showName}'`);
    }
  };

  removeFromMyList = async (showName) => {
    await commons.waitUntil(this.myListShowsList, 20);
    await this.removeFromMyListAndCheck(showName);
  };

  checkShowCount = async () => {
    /* TODO: Implementation required */
  };

  addShowsToMylistFromBrowse = async () => {
    if (this.returnGeoLocation() === 'america') {
      await commons.waitUntil(this.browse_lbl, 20);
      await commons.click(this.browse_lbl);
    } else if (this.returnGeoLocation() === 'emea') {
      await menuPage.navigateToPage('Account');
      await commons.waitUntil(this.myList_btn, 20);
      await commons.click(this.myList_btn);
      await commons.waitUntil(this.ctaButtons, 20);
      await commons.click(this.ctaButtons);
    }

    await commons.waitUntil(this.allNetwork_lbl, 20);
    this.setMyListShowTitle(
      await commons.fetchAttributeData(this.firstContentTitle, 'label'),
    );
    await this.selectShow('FirstShow');
    await this.clickAddToFavourites();
    await commons.click(this.back_btn);
    await commons.waitUntil(this.allNetwork_lbl);
    if (this.returnGeoLocation() === 'emea') {
      await commons.click(this.back_btn);
      await commons.waitUntil(menuPage.accountMenu_lbl);
    }
  };

  /**
   * The below function will verify Shows Availablity in MyList page
   *
   * @param {boolean} isShowPresent - Status of Show in MyList page is true or false
   */
  verifyShowsInMyList = async (isShowPresent) => {
    if (this.returnGeoLocation() === 'emea') {
      await commons.click(menuPage.accountMenu_lbl);
      await commons.waitUntil(this.myList_btn, 20);
    }
    await commons.waitUntil(this.myList_btn, 20);
    await commons.click(this.myList_btn);
    try {
      await retry(
        async () => {
          await commons.waitUntil(this.myListShowsList, 80);
        },
        { retries: 3, minTimeout: 3000, maxTimeout: 5000 },
      );
    } catch (error) {
      throw new Error('Content is not displayed on My List Page');
    }

    const showTitleList = await this.getListOfShows(this.showTitle_lbl);

    this.setMyListPageShowsList(showTitleList);
    const showStatus = showTitleList.includes(this.getMyListShowTitle());

    if (isShowPresent) {
      assert.strictEqual(
        showStatus,
        isShowPresent,
        new TypeError(
          `Validation Failed! , ${this.getMyListShowTitle()} is not present in MyList`,
        ),
      );
      if (await commons.elementExists(this.back_btn)) {
        await commons.click(this.back_btn);
      }
    } else {
      assert.strictEqual(
        showStatus,
        isShowPresent,
        new TypeError(
          `Validation Failed! , ${this.getMyListShowTitle()} is  present in MyList`,
        ),
      );
    }
  };

  removeShowFromMyListPage = async () => {
    if (this.returnGeoLocation() === 'emea') {
      await commons.click(menuPage.accountMenu_lbl);
      await commons.waitUntil(this.myList_btn, 20);
    }
    await menuPage.navigateToPage('Home');
    await menuPage.navigateToPage('My List');
    await commons.waitUntil(this.myListShowsList, 20);
    const showName = this.getMyListShowTitle();

    await this.removeFromMyListAndCheck(showName);
  };

  removeAllShowsFromMyListPage = async () => {
    await menuPage.navigateToPage('My List');
    if (!(await commons.elementExists(this.browseShows_btn, 30))) {
      try {
        while (await commons.elementExists(this.kebabButton, 30)) {
          await commons.click(this.kebabButton);
          await commons.waitUntil(this.goToShow_btn, 30);
          await commons.click(this.goToShow_btn);
          await commons.waitUntil(this.removeMyList_lbl, 30);
          await commons.click(this.removeMyList_lbl);
          await commons.waitUntil(this.addMyList_lbl, 30);
          await commons.waitUntil(this.back_btn, 30);
          await commons.click(this.back_btn);
          await menuPage.navigateToPage('Home');
          await menuPage.navigateToPage('My List');
        }
      } catch {
        const myListShowsList = (
          await commons.findElements(this.myListShowsList)
        ).length;

        assert.equal(myListShowsList, 0, 'My list is not empty!');
      }
    }
    await commons.elementExists(this.browseShows_btn, 30);
  };
}

module.exports = MyListPage;
