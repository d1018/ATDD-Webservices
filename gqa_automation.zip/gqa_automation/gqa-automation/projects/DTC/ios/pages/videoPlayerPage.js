const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

let playerPositionAfterScrub = 0;

let videoShowTitle;

class VideoPlayerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('videoPlayerPage', locator);
  }

  #playerMediaControl = this.#getSelectorData('playerMediaControl');

  #startWatchingAnonymousUser_lbl = this.#getSelectorData(
    'startWatchingAnonymousUser_lbl',
  );

  playerMediaControl = this.#getSelectorData('playerMediaControl');

  fullScreenToggle_btn = this.#getSelectorData('fullScreenToggle_btn');

  playerCast_btn = this.#getSelectorData('playerCast_btn');

  playerPause_btn = this.#getSelectorData('playerPause_btn');

  skipForward_btn = this.#getSelectorData('skipForward_btn');

  videoTitle_txt = this.getElementByPage('basePage', 'title_lbl');

  playerClose_btn = this.getElementByPage('basePage', 'close_btn');

  videoContainerView = this.#getSelectorData('videoContainerView');

  videoScrollPoint = this.#getSelectorData('videoScrollPoint');

  close_btn = this.getElementByPage('basePage', 'close_btn');

  back_btn = this.getElementByPage('basePage', 'back_btn');

  verifyVideoPlayerAnchorDetails = async () => {
    if (await this.getUserAnonymous()) {
      assert.equal(
        await commons.elementExists(this.#startWatchingAnonymousUser_lbl, 50),
        true,
        'startWatchingAnonymousUser_lbl validation failed',
      );
      return;
    }
    assert.equal(
      await commons.elementExists(this.#playerMediaControl, 50),
      true,
      'playerMediaControl validation failed',
    );
  };

  isVideoPlaying = async () => {
    await commons.waitUntil(this.playerMediaControl);
    await commons.waitUntil(this.fullScreenToggle_btn);
    await commons.waitUntil(this.playerPause_btn);
    await commons.waitUntil(this.videoTitle_txt);
  };

  closeShowPlayer = async () => {
    await commons.click(this.playerClose_btn);
  };

  scrubVideoByPercentage = async (scrubPercentage) => {
    let percentageValue;

    if (scrubPercentage < '98') {
      percentageValue = scrubPercentage;
    } else {
      percentageValue = '99.7';
    }
    const progressBarLocation = await commons.getElementLocation(
      this.videoScrollPoint,
      5,
    );

    await commons.waitUntil(this.skipForward_btn);
    await commons.click(this.videoContainerView, 50);
    const progressBarDimensions = await commons.getElementSize(
      this.playerMediaControl,
      5,
    );
    const startXPosition = progressBarLocation.startXValue;
    const endXPosition =
      startXPosition + percentageValue * 0.01 * progressBarDimensions.width;

    await commons.click(this.videoContainerView, 50);
    const startYPosition =
      progressBarLocation.startYValue + progressBarDimensions.height / 2;
    const endYPosition = startYPosition;

    await commons.scrollByCoordinates(
      startXPosition,
      startYPosition,
      endXPosition,
      endYPosition,
    );
    await commons.click(this.videoContainerView, 50);
  };

  videoPlayerPosition = async () => {
    await commons.click(this.videoContainerView, 50);
    await commons.waitUntil(this.playerMediaControl);
    const currentPlayerPosition = await commons.getElementLocation(
      this.videoScrollPoint,
      5,
    );

    return currentPlayerPosition;
  };

  scrubVideo = async (scrubPercentage) => {
    await commons.waitUntil(this.playerMediaControl, 50);
    videoShowTitle = await commons.fetchAttributeData(
      this.videoTitle_txt,
      'label',
    );
    await commons.click(this.videoContainerView, 50);
    await commons.click(this.videoContainerView, 50);

    await this.scrubVideoByPercentage(scrubPercentage);
    if (scrubPercentage < '98') {
      playerPositionAfterScrub = await this.videoPlayerPosition();
      if (!(await commons.elementExists(this.close_btn))) {
        await commons.click(this.videoContainerView, 50);
        await commons.waitUntil(this.skipForward_btn);
      }
      await commons.click(this.close_btn);
      await commons.click(this.back_btn);
    }
  };

  /**
   * Validates player position comparing before & after scrubbing video player position
   */

  validateResumePoint = async () => {
    const resumedVideoShowTitle = await commons.fetchAttributeData(
      this.videoTitle_txt,
      'label',
    );

    assert.equal(
      resumedVideoShowTitle,
      videoShowTitle,
      `Resumed video show ${resumedVideoShowTitle} is not equal to ${videoShowTitle}  `,
    );
    const playerPositionOnResume = await this.videoPlayerPosition();

    const playerPositionStatus =
      playerPositionOnResume >= playerPositionAfterScrub;

    assert(
      playerPositionStatus,
      true,
      `Resume video is not successful as the player position on resume is ${playerPositionOnResume} is less than after scrub ${playerPositionAfterScrub}`,
    );

    await this.closeShowPlayer();
  };
}

module.exports = VideoPlayerPage;
