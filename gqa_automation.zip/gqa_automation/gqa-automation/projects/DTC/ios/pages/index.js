const AccountPage = require('./accountPage');
const HomePage = require('./homePage');
const SearchPage = require('./searchPage');
const SignInPage = require('./signInPage');
const PreLaunchPage = require('./prelaunchPage');
const MenuPage = require('./menuPage');
const ProfilePage = require('./profilePage');
const MyListPage = require('./myListPage');
const VideoPlayerPage = require('./videoPlayerPage');
const SportsPage = require('./sportsPage');
const NetworkLandingPage = require('./networkLandingPage');
const ShowDetailsPage = require('./showDetailsPage');
const OnboardingPage = require('./onboardingPage');
const BrowsePage = require('./browsePage');
const EventDetailPage = require('./eventDetailPage');
const WelcomePage = require('./welcomePage');
const UpNextPage = require('./upNextPage');
const DeepLinkPage = require('./deepLinkPage');

const accountPage = new AccountPage();
const homePage = new HomePage();
const searchPage = new SearchPage();
const signInPage = new SignInPage();
const preLaunchPage = new PreLaunchPage();
const menuPage = new MenuPage();
const profilePage = new ProfilePage();
const myListPage = new MyListPage();
const videoPlayerPage = new VideoPlayerPage();
const sportsPage = new SportsPage();
const networkLandingPage = new NetworkLandingPage();
const showDetailsPage = new ShowDetailsPage();
const onboardingPage = new OnboardingPage();
const browsePage = new BrowsePage();
const eventDetailPage = new EventDetailPage();
const welcomePage = new WelcomePage();
const upNextPage = new UpNextPage();
const deepLinkPage = new DeepLinkPage();

module.exports = {
  accountPage,
  homePage,
  searchPage,
  signInPage,
  preLaunchPage,
  menuPage,
  profilePage,
  myListPage,
  videoPlayerPage,
  sportsPage,
  networkLandingPage,
  showDetailsPage,
  onboardingPage,
  browsePage,
  eventDetailPage,
  welcomePage,
  upNextPage,
  deepLinkPage,
};
