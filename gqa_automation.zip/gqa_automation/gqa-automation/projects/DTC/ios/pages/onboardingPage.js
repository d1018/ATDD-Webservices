const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');
const MenuPage = require('./menuPage');
const HomePage = require('./homePage');

const commons = mobileActions;
const menuPage = new MenuPage();
const homePage = new HomePage();

class OnboardingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('onboardingPage', locator);
  }

  firstTileOnRail_lbl = this.getElementByPage(
    'homePage',
    'firstTileOnRail_lbl',
  );

  signup_btn = this.getElementByPage('signInPage', 'signup_btn');

  signIn_btn = this.getElementByPage('signInPage', 'signIn_btn');

  signUpPop_txt = this.#getSelectorData('signUpPop_txt');

  focusedSignInPage = this.getElementByPage('signInPage', 'focusedSignInPage');

  close_btn = this.#getSelectorData('close_btn');

  cancel_btn = this.#getSelectorData('cancel_btn');

  sportsMenu_lbl = this.getElementByPage('menuPage', 'sportsMenu_lbl');

  sportsContentVOD = this.getElementByPage('sportsPage', 'sportsContentVOD');

  chosePlan_txt = this.#getSelectorData('chosePlan_txt');

  register_btn = this.#getSelectorData('register_btn');

  startWatchingAnonymousUser_lbl = this.getElementByPage(
    'videoPlayerPage',
    'startWatchingAnonymousUser_lbl',
  );

  firstEpisode_img = this.getElementByPage('showPage', 'firstEpisode_img');

  upgradePass_lbl = this.getElementByPage('videoPlayerPage', 'upgradePass_lbl');

  viewPasses_lbl = this.getElementByPage('videoPlayerPage', 'viewPasses_lbl');

  inactiveSubscription_txt = this.#getSelectorData('inactiveSubscription_txt');

  choosePlan_btn = this.#getSelectorData('choosePlan_btn');

  manageAccount_btn = this.#getSelectorData('manageAccount_btn');

  signOut_btn = this.#getSelectorData('signOut_btn');

  firstTileOnTrendingRail_lbl = this.getCustomLocator(
    this.firstTileOnRail_lbl,
    'Trending',
  );

  firstTileOnLeavingRail_lbl = this.getCustomLocator(
    this.firstTileOnRail_lbl,
    'Leaving Soon',
  );

  firstPopularShowOnDiscovery = this.#getSelectorData(
    'firstPopularShowOnDiscovery',
  );

  subscribeToWatchList = [
    this.getElementByPage('signInPage', 'signup_btn'),
    this.getElementByPage('signInPage', 'signIn_btn'),
    this.getElementByPage('videoPlayerPage', 'startWatchingAnonymousUser_lbl'),
  ];

  selectCTAAndVerify = async (CTA) => {
    switch (CTA) {
      case 'Sign Up': {
        await this.navigateToSignUpLandingPage();
        break;
      }
      case 'Sign In': {
        await commons.click(this.signIn_btn);
        await commons.elementExists(this.focusedSignInPage);
        await commons.click(this.close_btn);
        break;
      }
      default:
        break;
    }
  };

  /**
   * The below function used to navigate to signup landing page
   */

  navigateToSignUpLandingPage = async () => {
    await commons.click(this.signup_btn);
    await commons.elementExists(this.signUpPop_txt);
    await commons.click(this.cancel_btn);
    await commons.elementExists(this.chosePlan_txt);
  };

  navigateAndSelectContent = async (contentType, userType) => {
    if (contentType.includes('Sports VOD') && userType.includes('anonymous')) {
      await commons.click(menuPage.sportsMenu_lbl);
      await commons.scrollToElement(this.sportsContentVOD, 'down');
      await commons.click(this.sportsContentVOD);
    } else if (
      contentType.includes('Entertainment VOD') &&
      userType.includes('anonymous')
    ) {
      await commons.click(menuPage.homeMenu_lbl);
      await homePage.isRailPresent(homePage.railNames['Leaving Soon']);
      await commons.scrollToElement(this.firstTileOnLeavingRail_lbl, 'down');
      await commons.click(this.firstTileOnLeavingRail_lbl);
    } else if (
      contentType.includes('Entertainment VOD') &&
      userType.includes('lapsed')
    ) {
      await homePage.isRailPresent(homePage.railNames.Trending);
      await commons.scrollToElement(this.firstTileOnTrendingRail_lbl, 'down');
      await commons.click(this.firstTileOnTrendingRail_lbl);
      await commons.click(this.firstEpisode_img);
    } else if (
      contentType.includes('Entertainment Linear') &&
      userType.includes('lapsed')
    ) {
      await homePage.scrollToNetworkRail();
      await commons.waitUntil(homePage.railNames.discovery);
      await commons.click(homePage.railNames.discovery);
      await commons.click(this.firstPopularShowOnDiscovery);
      await commons.click(this.firstEpisode_img);
    }
  };

  /**
   * The below function will validate the subscribe to watch screen whether the required elements are displayed
   */

  verifySubscribeToWatchScreen = async () => {
    for (let i = 0; i < this.subscribeToWatchList.length; i++) {
      assert(
        await commons.elementExists(this.subscribeToWatchList[i]),
        `${this.subscribeToWatchList[i]} is not displayed on the page`,
      );
    }
  };

  navigateToPlanPickerPage = async () => {
    await commons.click(menuPage.accountMenu_lbl);
    await this.navigateToSignUpLandingPage();
  };

  verifyRegisterFreeCta = async () => {
    await commons.waitUntil(this.register_btn);
  };

  selectAndCompleteRegistration = async () => {
    await commons.click(this.register_btn);
  };

  validateUpgradeToWatchScreen = async () => {
    assert(
      (await commons.elementExists(this.viewPasses_lbl)) &&
        (await commons.elementExists(this.upgradePass_lbl)),
      `View Passes is not showing on upgrade to watch screen`,
    );
  };

  verifyInactiveSubscriptionScreen = async () => {
    await commons.waitUntil(this.inactiveSubscription_txt);
    await commons.waitUntil(this.choosePlan_btn);
    await commons.waitUntil(this.manageAccount_btn);
    await commons.waitUntil(this.signOut_btn);
  };
}

module.exports = OnboardingPage;
