const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class PreLaunchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('preLaunchPage', locator);
  }

  ok_caps_btn = this.#getSelectorData('ok_caps_btn');

  ok_alert_btn = this.#getSelectorData('ok_alert_btn');

  privacyAccept_btn = this.#getSelectorData('privacyAccept_btn');

  continue_btn = this.#getSelectorData('continue_btn');

  allow_btn = this.#getSelectorData('allow_btn');

  noTracking_btn = this.#getSelectorData('noTracking_btn');

  alert_title_text = this.#getSelectorData('alert_title_text');

  systemPopUpTitle = async () => {
    let titleValue = '';

    if (await commons.elementExists(this.alert_title_text)) {
      titleValue = await commons.fetchAttributeData(
        this.alert_title_text,
        'name',
      );
    }
    return titleValue;
  };

  #systemPopUpMenu = {
    // Handle prompt discrepancy between iOS 15.0 & 16.0
    '“discovery+” would like to find and connect to devices on your local network.':
      this.ok_caps_btn,
    '“discovery+” would like to find and connect to devices on your local network':
      this.ok_caps_btn,
    '“discovery+” Would Like to Use Bluetooth': this.ok_caps_btn,
    'Allow “discovery+” to track your activity across other companies’ apps and websites?':
      this.allow_btn,
    '“discovery+” would like permission to track you across apps and websites owned by other companies.':
      this.allow_btn,
    'I Accept': this.privacyAccept_btn,
    Continue: this.continue_btn,
  };

  #systemPopUpButton = (alertTitle) =>
    this.#systemPopUpMenu[alertTitle] || new Error('Something went wrong');

  acceptPersonalization = async () => {
    if (await commons.elementExists(this.continue_btn)) {
      await commons.click(this.continue_btn);
    }

    // Handle additional system pop-up if present
    const alertTitle = await this.systemPopUpTitle();

    if (alertTitle && this.#systemPopUpMenu[alertTitle]) {
      await commons.click(this.#systemPopUpButton(alertTitle), 60);
    }
  };

  // loop count is given as per the number of popups being displayed on app
  systemPopUpHandler = async (numPopUps = 4) => {
    for (let i = 0; i < numPopUps; i++) {
      const alertTitle = await this.systemPopUpTitle();

      if (alertTitle && this.#systemPopUpMenu[alertTitle]) {
        await commons.click(this.#systemPopUpButton(alertTitle), 60);
      }
    }
  };

  acceptAllPopUp = async () => {
    if (this.returnGeoLocation() === 'emea') {
      for (let i = 1; i <= 5; i++) {
        const alertTitle = await this.systemPopUpTitle();

        if (alertTitle) {
          await commons.click(this.#systemPopUpButton(alertTitle), 60);
        }
      }

      if (await commons.elementExists(this.ok_alert_btn)) {
        await commons.click(this.ok_alert_btn);
      }
      if (await commons.elementExists(this.ok_caps_btn)) {
        await commons.click(this.ok_caps_btn);
      }
    } else {
      // geo location defaults to 'america'
      const expectedSystemPopUpCount = 4;

      await this.systemPopUpHandler(expectedSystemPopUpCount);
      await this.acceptPersonalization();
    }
  };
}

module.exports = PreLaunchPage;
