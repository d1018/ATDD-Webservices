const assert = require('assert');

const { BasePage, mobileActions } = require('./basePage');
const VideoPlayerPage = require('./videoPlayerPage');

const commons = mobileActions;
const videoPlayerPage = new VideoPlayerPage();

class UpNextPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('upNextPage', locator);
  }

  playerMediaControl = this.getElementByPage(
    'videoPlayerPage',
    'playerMediaControl',
  );

  upNext_lbl = this.#getSelectorData('upNext_lbl');

  upNextClose_btn = this.#getSelectorData('upNextClose_btn');

  playNextIcon = this.#getSelectorData('playNextIcon');

  upNextSeasonEpisode_lbl = this.#getSelectorData('upNextSeasonEpisode_lbl');

  upNextRating = this.#getSelectorData('upNextRating');

  upNextContainerView = this.#getSelectorData('upNextContainerView');

  upNextEpisodeTitle = this.#getSelectorData('upNextEpisodeTitle');

  videoTitleText = this.#getSelectorData('videoTitleText');

  upNextTitle = '';

  /**
   * Verify Up Next Label on Up Next banner
   */
  verifyUpNextBanner = async () => {
    assert(
      await commons.elementExists(this.upNextContainerView),
      `upNext container is not displayed`,
    );
    assert(
      await commons.elementExists(this.upNext_lbl),
      `upNext label is not displayed`,
    );
  };

  /**
   * Verify metadata on Up Next banner
   */
  verifyMetaDataForUpNext = async () => {
    assert(
      await commons.elementExists(this.upNextClose_btn),
      `upNext close button is not displayed`,
    );
    assert(
      await commons.elementExists(this.playNextIcon),
      `upNext play icon is not displayed`,
    );
    assert(
      await commons.elementExists(this.upNextSeasonEpisode_lbl),
      `upNext season/Episode label not displayed`,
    );
    assert(
      await commons.elementExists(this.upNextRating),
      `upNext Rating is not displayed`,
    );
    assert(
      await commons.elementExists(this.upNextEpisodeTitle),
      `upNext Episode Title is not displayed`,
    );
    this.upNextTitle = await commons.fetchAttributeData(
      this.upNextEpisodeTitle,
      'label',
    );
  };

  /**
   * Verify Next episode is playing on video page
   */
  verifyNextEpisode = async () => {
    await commons.waitUntil(this.playerMediaControl, 50);
    await videoPlayerPage.isVideoPlaying();
    const episodeTitle = await commons.fetchAttributeData(
      this.videoTitleText,
      'label',
    );

    assert.equal(
      episodeTitle,
      this.upNextTitle,
      `Next episode is not playing on video page`,
    );
  };

  /**
   * Click on Cancel/Play icon on upNext banner
   *
   * @param {string} CTAType -  Play/Cancel
   */

  clickOnUpNextCTA = async (CTAType) => {
    const buttonsCTA = {
      cancel: this.upNextClose_btn,
      Play: this.playNextIcon,
    };

    assert(
      await commons.elementExists(buttonsCTA[CTAType]),
      ` ${buttonsCTA[CTAType]} is not displayed`,
    );

    await commons.click(buttonsCTA[CTAType]);
  };

  /**
   * Verify current episode on video page
   */
  verifyScreenOnUpNextCancel = async () => {
    await videoPlayerPage.isVideoPlaying();
    assert(
      !(await commons.elementExists(this.upNextContainerView)),
      `upNext container is still displayed`,
    );
    assert(
      !(await commons.elementExists(this.upNext_lbl)),
      `upNext label is still displayed`,
    );
  };
}
module.exports = UpNextPage;
