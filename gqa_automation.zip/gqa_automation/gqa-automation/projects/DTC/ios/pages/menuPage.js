const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  focusedMenuBar = this.#getSelectorData('focusedMenuBar');

  accountMenu_lbl = this.#getSelectorData('accountMenu_lbl');

  searchMenu_lbl = this.#getSelectorData('searchMenu_lbl');

  homeMenu_lbl = this.#getSelectorData('homeMenu_lbl');

  myList_lbl = this.#getSelectorData('myList_lbl');

  browse_lbl = this.#getSelectorData('browse_lbl');

  sportsMenu_lbl = this.#getSelectorData('sportsMenu_lbl');

  tvGuideMenu_lbl = this.#getSelectorData('tvGuideMenu_lbl');

  signIn_btn = this.getElementByPage('signInPage', 'signIn_btn');

  signUp_btn = this.getElementByPage('signInPage', 'signup_btn');

  favorite_btn = this.getElementByPage('myListPage', 'favorite_btn');

  close_btn = this.getElementByPage('searchPage', 'closeOrBack_btn');

  manageProfiles_btn = this.getElementByPage(
    'accountPage',
    'manageProfiles_btn',
  );

  myList_btn = this.getElementByPage('accountPage', 'myList_btn');

  focusedSearchPage = this.getElementByPage('searchPage', 'focusedSearchPage');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  focusedMyListPage = this.getElementByPage('accountPage', 'focusedMyListPage');

  focusedBrowsePage = this.getElementByPage(
    'browsePage',
    'discoPlusOriginals_lbl',
  );

  timeBarCellTitle_txt = this.getElementByPage(
    'tvGuidePage',
    'timeBarCellTitle_txt',
  );

  sports_lbl = this.getElementByPage('allSportsPage', 'sports_lbl');

  search_txtBx = this.getElementByPage('searchPage', 'search_txtBx');

  focusedAccountPage = this.getElementByPage(
    'accountPage',
    'focusedAccountPage',
  );

  downloads_lbl = this.#getSelectorData('downloads_lbl');

  focusedDownloadsPage = this.getElementByPage(
    'downloadsPage',
    'focusedDownloadsPage',
  );

  menuItem = {
    Home: this.homeMenu_lbl,
    Search: this.searchMenu_lbl,
    Account: this.accountMenu_lbl,
    'My List': this.myList_lbl,
    Sports: this.sportsMenu_lbl,
    'Tv Guide': this.tvGuideMenu_lbl,
    Browse: this.browse_lbl,
    Downloads: this.downloads_lbl,
  };

  pageFocused = {
    Home: this.forYou_lbl,
    Search: this.search_txtBx,
    Account: this.manageProfiles_btn,
    Sports: this.sports_lbl,
    'Tv Guide': this.timeBarCellTitle_txt,
    'My List': this.focusedMyListPage,
    Browse: this.focusedBrowsePage,
    Downloads: this.focusedDownloadsPage,
  };

  ctaList = {
    'My List': this.favorite_btn,
    'Sign In': this.signIn_btn,
    'Sign Up': this.signUp_btn,
  };

  navigateToPage = async (pageValue) => {
    // As the UI has changed to due to the Offline Downloads feature, adding this piece of code to navigate seamlessly
    // for account page
    if (await commons.elementExists(this.close_btn)) {
      await commons.click(this.close_btn);
    }

    await commons.waitUntil(this.menuItem[pageValue], 80);
    await commons.click(this.menuItem[pageValue], 80);
    if (this.getUserAnonymous()) {
      return;
    }
    await commons.waitUntil(this.pageFocused[pageValue], 20);
  };

  accessGlobalNavigationMenu = async () => {
    await commons.waitUntil(this.focusedMenuBar, 35);
  };

  verifyMenuList = async () => {
    await commons.waitUntil(this.homeMenu_lbl, 20);
    await commons.waitUntil(this.accountMenu_lbl, 5);

    if (this.returnGeoLocation() === 'emea') {
      await commons.waitUntil(this.searchMenu_lbl, 5);
      await commons.waitUntil(this.sportsMenu_lbl, 5);
      if (!this.isKidsProfileSelected()) {
        await commons.waitUntil(this.tvGuideMenu_lbl, 5);
      }
    } else if (this.returnGeoLocation() === 'america') {
      await commons.waitUntil(this.browse_lbl, 5);
      await commons.waitUntil(this.myList_lbl, 5);
    }

    await commons.click(this.accountMenu_lbl);

    if (!(await this.getUserAnonymous())) {
      await commons.waitUntil(this.manageProfiles_btn, 25);
      if (!(this.returnGeoLocation() === 'america'))
        await commons.waitUntil(this.myList_btn, 5);
    }
  };

  verifyGlobalNavigation = async () => {
    await this.navigateToPage('Home');
    await this.navigateToPage('Account');
    await this.navigateToPage('Search');

    if (this.returnGeoLocation() === 'emea') {
      await this.navigateToPage('Sports');

      if (!this.isKidsProfileSelected()) {
        await this.navigateToPage('Tv Guide');
      }
    } else if (this.returnGeoLocation() === 'america') {
      await this.navigateToPage('Browse');
      await this.navigateToPage('My List');
      await this.navigateToPage('Downloads');
    }
  };

  assertPage = async (pageValue) => {
    await commons.waitUntil(this.pageFocused[pageValue]);
  };

  isMenuOptionPresent = async (menuOption, isMenuPresent) => {
    if (menuOption === 'My List') {
      await commons.click(this.menuItem.Account, 60);
    }
    const menuStatus = await commons.elementExists(this.menuItem[menuOption]);

    if (isMenuPresent) {
      assert.strictEqual(
        menuStatus,
        isMenuPresent,
        new TypeError(
          `Validation Failed! , Actual: ${menuOption} menu option is not present`,
        ),
      );
    } else {
      assert.strictEqual(
        menuStatus,
        isMenuPresent,
        new TypeError(
          `Validation Failed! , Actual: ${menuOption} menu option is present`,
        ),
      );
    }
  };

  validateCTAPresent = async (CTA, isCtaPresent) => {
    const ctaStatus = await commons.elementExists(this.ctaList[CTA]);

    if (isCtaPresent) {
      assert.strictEqual(
        ctaStatus,
        isCtaPresent,
        new TypeError(`Validation Failed! , Actual: ${CTA} CTA is not present`),
      );
    } else {
      assert.strictEqual(
        ctaStatus,
        isCtaPresent,
        new TypeError(`Validation Failed! , Actual: ${CTA} CTA is present`),
      );
    }
  };

  isCTAPresent = async (CTA, isCtaPresent) => {
    if (CTA === 'My List') {
      await commons.click(this.menuItem.Home, 60);
      await commons.waitUntil(this.forYou_lbl);
      await commons.click(this.forYou_lbl, 20);
    }
    this.validateCTAPresent(CTA, isCtaPresent);
  };
}

module.exports = MenuPage;
