const assert = require('assert');

const {
  BasePage,
  mobileActions,
  customErrors,
  skipReason,
} = require('./basePage');
const MenuPage = require('./menuPage');

const menuPage = new MenuPage();

const commons = mobileActions;
const { SkipError } = customErrors;

class EventDetailPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('eventDetailsPage', locator);
  }

  firstTileOnRail_lbl = this.getElementByPage(
    'homePage',
    'firstTileOnRail_lbl',
  );

  logoImage = this.getElementByPage('networkLandingPage', 'networkLogo_img');

  rail_lbl = this.getElementByPage('homePage', 'rail_lbl');

  close_btn = this.getElementByPage('basePage', 'close_btn');

  live_lbl = this.#getSelectorData('live_lbl');

  watchTimeText = this.#getSelectorData('watchTimeText');

  skipBackward_btn = this.getElementByPage(
    'videoPlayerPage',
    'skipBackward_btn',
  );

  skipForward_btn = this.getElementByPage('videoPlayerPage', 'skipForward_btn');

  signIn_btn = this.getElementByPage('accountPage', 'signIn_btn');

  signUp_btn = this.getElementByPage('signInPage', 'signup_btn');

  watchLiveText = this.#getSelectorData('watchLiveText');

  livePlaybackTime_lbl = this.#getSelectorData('livePlaybackTime_lbl');

  livePlaybackDuration_lbl = this.#getSelectorData('livePlaybackDuration_lbl');

  livePlayerSeekBar = this.#getSelectorData('livePlayerSeekBar');

  subTitle_lbl = this.#getSelectorData('subTitle_lbl');

  upcomingTime_lbl = this.#getSelectorData('upcomingTime_lbl');

  upcomingDate_lbl = this.#getSelectorData('upcomingDate_lbl');

  description_lbl = this.#getSelectorData('description_lbl');

  title_lbl = this.getElementByPage('searchPage', 'showTitle_lbl');

  chosePlan_txt = this.getElementByPage('onboardingPage', 'chosePlan_txt');

  viewPasses_lbl = this.getElementByPage('videoPlayerPage', 'viewPasses_lbl');

  firstTileOnLiveRail_lbl = this.getCustomLocator(
    this.firstTileOnRail_lbl,
    'Live',
  );

  firstTileOnUpcomingRail_lbl = this.getCustomLocator(
    this.firstTileOnRail_lbl,
    'Upcoming',
  );

  liveCTA = {
    watchFromStart_btn: this.#getSelectorData('watchFromStart_btn'),
    watchLive_btn: this.#getSelectorData('watchLive_btn'),
  };

  railNames = {
    Live: this.getCustomLocator(this.rail_lbl, 'Live'),
    Upcoming: this.getCustomLocator(this.rail_lbl, 'Upcoming'),
  };

  /**
   * The below function will verify live lable
   */
  checkLiveEventRailAvailability = async () => {
    await commons.waitUntil(this.logoImage, 20);
    if (!(await commons.elementExists(this.live_lbl))) {
      throw new SkipError(skipReason.noLiveEvent);
    }
  };

  /**
   * The below function will select the live rail first event
   */
  selectLiveRailFirstEvent = async () => {
    await this.checkLiveEventRailAvailability();
    await commons.scrollToElement(this.railNames.Live, 'down', 10);
    await commons.waitUntil(this.firstTileOnLiveRail_lbl, 10);
    await commons.click(this.firstTileOnLiveRail_lbl, 5);
  };

  /**
   * The below function will verify the cta and element on live Event page
   */
  validateLiveEventDeatilPage = async () => {
    await commons.waitUntil(this.live_lbl, 20);
    await commons.waitUntil(this.watchTimeText, 20);
    await commons.waitUntil(this.watchLiveText, 20);
    await commons.waitUntil(this.liveCTA.watchFromStart_btn);
    await commons.waitUntil(this.liveCTA.watchLive_btn);
  };

  /**
   * The below function will verify CTA Watch Live button On VOD player
   */
  selectLiveCtaAndValidateVOD = async () => {
    await commons.waitUntil(this.liveCTA.watchLive_btn, 5);
    await commons.click(this.liveCTA.watchLive_btn, 5);
    await commons.waitUntil(this.livePlayerSeekBar, 60);
    await commons.waitUntil(this.skipBackward_btn);
    await commons.waitUntil(this.live_lbl);
    await commons.waitUntil(this.livePlaybackDuration_lbl);
    await commons.waitUntil(this.livePlaybackTime_lbl);
    await commons.click(this.close_btn);
    await commons.waitUntil(this.firstTileOnLiveRail_lbl, 10);
  };

  selectStartCtaAndValidate = async () => {
    await commons.waitUntil(this.liveCTA.watchFromStart_btn, 5);
    await commons.click(this.liveCTA.watchFromStart_btn, 5);
    await commons.waitUntil(this.skipForward_btn);
    const timeLabel = await commons.fetchAttributeData(
      this.livePlaybackTime_lbl,
      'label',
    );

    await commons.waitUntil(this.livePlayerSeekBar, 60);
    await commons.waitUntil(this.live_lbl);
    await commons.waitUntil(this.livePlaybackDuration_lbl);
    await commons.waitUntil(this.livePlaybackTime_lbl);
    if (!timeLabel.includes('0:0'))
      assert.equal(timeLabel, '0:0', 'Video is not starting from start');
  };

  selectStartCtaAndValidateVOD = async () => {
    await commons.waitUntil(this.firstTileOnLiveRail_lbl, 10);
    await commons.click(this.firstTileOnLiveRail_lbl, 5);
    await this.selectStartCtaAndValidate();
  };

  /**
   * The below function will verify cta button on event landing page
   */
  verifyCTAonPlayer = async () => {
    if (this.getUserAnonymous()) {
      await menuPage.isCTAPresent('Sign In', true);
      await menuPage.isCTAPresent('Sign Up', true);
    } else {
      await menuPage.isCTAPresent('Sign In', false);
      await menuPage.isCTAPresent('Sign Up', false);
    }
  };

  /**
   * The below function will verify the element on Event landing page
   */
  validateEventDeatilPage = async () => {
    const items = [
      this.watchTimeText,
      this.title_lbl,
      this.subTitle_lbl,
      this.upcomingTime_lbl,
      this.upcomingDate_lbl,
      this.description_lbl,
    ];

    for (let i = 0; i < items.length; i++) {
      await commons.elementExists(items[i], 3);
    }
  };

  selectUpcomingRailFirstEvent = async () => {
    await menuPage.navigateToPage('Sports', 30);
    await commons.waitUntil(this.logoImage, 60);
    await commons.scrollToElement(this.railNames.Upcoming, 'down');
    await commons.waitUntil(this.firstTileOnUpcomingRail_lbl, 10);
    await commons.click(this.firstTileOnUpcomingRail_lbl);
  };

  clickOnViewPassesCta = async () => {
    await commons.waitUntil(this.viewPasses_lbl);
    await commons.click(this.viewPasses_lbl);
  };

  validatePlanPickerScreen = async () => {
    await commons.elementExists(this.chosePlan_txt);
  };
}

module.exports = EventDetailPage;
