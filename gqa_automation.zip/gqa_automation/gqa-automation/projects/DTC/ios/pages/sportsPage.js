const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class SportsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('sportsPage', locator);
  }

  posterShowNameTitle = this.getElementByPage(
    'showPage',
    'posterShowNameTitle',
  );

  #detailsTab = this.#getSelectorData('detailsTab');

  sportsSwipe = this.#getSelectorData('sportsSwipe');

  #startWatchingAnonymousUser_lbl = this.getElementByPage(
    'videoPlayerPage',
    'startWatchingAnonymousUser_lbl',
  );

  verifySportsScreenAnchorDetails = async () => {
    if (await this.getUserAnonymous()) {
      await commons.waitUntil(this.#startWatchingAnonymousUser_lbl);
      return;
    }
    while (!(await commons.elementExists(this.#detailsTab))) {
      await commons.swipeOnElement(this.sportsSwipe, 'left', 5);
    }
    await commons.waitUntil(this.#detailsTab);
  };

  verifySportsDetailsPage = async () => {
    await commons.waitUntil(this.posterShowNameTitle);
  };
}

module.exports = SportsPage;
