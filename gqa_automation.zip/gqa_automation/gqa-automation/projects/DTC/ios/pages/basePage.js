const path = require('path');
const {
  mobileActions,
  customErrors,
  testdataHelper,
} = require('@wbd/gqa-core/support');

const { skipReason } = require('../../../support/skipReason');

const ymlpath = path.resolve(__dirname);

const commons = mobileActions;
const EnvBase = require('../../../support/env');

let isUserAnonymousType;

let isStartWatchingUserAnonymousType;

let myListShowTitle;

let myListShowTitleList;

let myListRailShowTitleList;

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }

  setStartWatchingAnonymousUser(boolean) {
    isStartWatchingUserAnonymousType = boolean;
  }

  getStartWatchingAnonymousUser() {
    return isStartWatchingUserAnonymousType;
  }

  setUserAnonymous(boolean) {
    isUserAnonymousType = boolean;
  }

  getUserAnonymous() {
    return isUserAnonymousType;
  }

  getMyListShowTitle() {
    return myListShowTitle;
  }

  setMyListShowTitle(showTitle) {
    myListShowTitle = showTitle;
  }

  getMyListRailShowsList() {
    return myListRailShowTitleList;
  }

  setMyListRailShowsList(showList) {
    myListRailShowTitleList = showList;
  }

  getMyListPageShowsList() {
    return myListShowTitleList;
  }

  setMyListPageShowsList(showList) {
    myListShowTitleList = showList;
  }

  isKidsProfile = false;

  isKidsProfileSelected = () => this.isKidsProfile;

  isRailPresent = async () => {
    /* TODO: Implementation required */
  };

  getListOfShows = async (showListLocator) => {
    const showTitleList = [];
    const listOfShows = await commons.findElements(showListLocator);

    for (let i = 0; i < listOfShows.length; i++) {
      showTitleList.push(
        await commons.fetchAttributeData(listOfShows[i], 'label'),
      );
    }
    return showTitleList;
  };

  getRandomNumber = (len) => {
    const randomNumber = Math.floor(Math.random() * len);

    return `${randomNumber}`;
  };
}

module.exports = {
  mobileActions,
  customErrors,
  testdataHelper,
  skipReason,
  BasePage,
};
