const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');
const MenuPage = require('./menuPage');

const commons = mobileActions;
const menuPage = new MenuPage();

let profileCountBeforeDeletion = 0;

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  manageProfiles_btn = this.#getSelectorData('manageProfiles_btn');

  manageProfiles_lbl = this.#getSelectorData('manageProfiles_lbl');

  addProfile_btn = this.#getSelectorData('addProfile_btn');

  createProfileName_txtBx = this.#getSelectorData('createProfileName_txtBx');

  save_btn = this.#getSelectorData('save_btn');

  back_btn = this.#getSelectorData('back_btn');

  createProfileScreen_lbl = this.#getSelectorData('createProfileScreen_lbl');

  #nonDefaultProfilesList = this.#getSelectorData('nonDefaultProfilesList');

  deleteProfile_btn = this.#getSelectorData('deleteProfile_btn');

  deleteProfilePopup_btn = this.#getSelectorData('deleteProfilePopup_btn');

  kidsProfileToggle_btn = this.#getSelectorData('kidsProfileToggle_btn');

  editProfile_btn = this.#getSelectorData('editProfile_btn');

  randomProfileName = this.#getSelectorData('randomProfileName');

  profileName_txt = this.#getSelectorData('profileName_txt');

  profileTitle_lbl = this.#getSelectorData('profileTitle_lbl');

  tab_bar = this.getElementByPage('basePage', 'tab_bar');

  keyBoardReturn_btn = this.getElementByPage('basePage', 'keyBoardReturn_btn');

  profile_header = this.#getSelectorData('profile_header');

  profile_lbl = this.#getSelectorData('profile_lbl');

  closeOrBack_btn = this.getElementByPage('searchPage', 'closeOrBack_btn');

  homeMenu_lbl = this.getElementByPage('menuPage', 'homeMenu_lbl');

  usernameLabelList = this.getElementByPage('accountPage', 'usernameLabelList');

  profileNameList = this.getElementByPage('accountPage', 'profileNameList');

  profilesList = {
    Default: this.getCustomLocator(this.profileName_txt, 'Default'),
    Kids: this.getCustomLocator(this.profileName_txt, 'Kids'),
    Standard: this.getCustomLocator(this.profileName_txt, 'Standard'),
    Pin: this.#getSelectorData('pinProfileName'),
    Auto_Watch_Now: this.getCustomLocator(
      this.randomProfileName,
      'Auto_Watch_Now',
    ),
    Automation: this.getCustomLocator(this.profileName_txt, 'Automation'),
  };

  profileName = '';

  deletedProfileName = '';

  nonDefaultProfileList = '';

  isAddProfileOptionVisible = async () => {
    const result = await commons.elementExists(this.addProfile_btn, 30);

    return result;
  };

  #toggleKidsProfile = async () => {
    await commons.click(this.kidsProfileToggle_btn);
  };

  profileCreation = async (profileType) => {
    await this.createNewProfile(profileType);
    await this.selectProfile(this.profileName);
  };

  createNewProfile = async (profileType) => {
    if (profileType === 'Pin') {
      this.profileName = 'Pin';
      return;
    }
    await this.selectProfile('Default');
    await commons.waitUntil(menuPage.focusedHomePage, 30);
    await commons.click(menuPage.accountMenu_lbl, 30);
    await commons.waitUntil(this.manageProfiles_btn, 30);
    if (!(await this.isAddProfileOptionVisible())) {
      await this.deleteUserProfile('random');
    }

    if (await commons.isDisplayed(this.manageProfiles_btn, 30)) {
      await commons.click(this.manageProfiles_btn, 30);
      await commons.waitUntil(this.manageProfiles_lbl, 30);
    }
    this.profileName = profileType + Math.floor(Date.now() / 1000);
    await commons.click(this.addProfile_btn, 20);
    await commons.waitUntil(this.createProfileScreen_lbl, 30);
    await commons.click(this.createProfileName_txtBx, 20);
    await commons.sendText(this.createProfileName_txtBx, this.profileName);
    if (profileType === 'Kids') {
      await this.#toggleKidsProfile();
    }
    await commons.click(this.save_btn);
    await commons.click(this.back_btn, 20);
  };

  selectProfile = async (profileType) => {
    if (await commons.elementExists(this.closeOrBack_btn, 30)) {
      await commons.click(this.closeOrBack_btn);
    }
    if (await commons.elementExists(this.homeMenu_lbl, 30)) {
      await menuPage.navigateToPage('Home');
      await menuPage.navigateToPage('Account');
    }

    if (profileType.length === 0 || profileType === 'Anonymous') {
      this.isUserAnonymousType = true;
      return;
    }
    if (profileType === 'Pin') {
      await menuPage.navigateToPage('Account');
    }

    if (
      this.profilesList[profileType] !== undefined &&
      this.profilesList[profileType] !== null
    ) {
      if (!(await commons.elementExists(this.profilesList[profileType], 10))) {
        await commons.swipeOnElement(this.usernameLabelList, 'left');
      }

      await this.isProfileExist(profileType);
      await commons.click(this.profilesList[profileType], 10);
    } else {
      const profileLbl = this.getCustomLocator(
        this.profileTitle_lbl,
        this.profileName,
      );

      if (!(await commons.elementExists(profileLbl, 30))) {
        await commons.swipeOnElement(this.usernameLabelList, 'left');
      }
      await commons.waitUntil(profileLbl, 30);
      await commons.click(profileLbl, 10);
    }
    if (profileType === 'Pin') {
      await commons.sendPassKeys(process.env.PROFILE_PIN);
    }
    if (profileType === 'Kids') {
      this.isKidsProfile = true;
    }
    await commons.waitUntil(menuPage.focusedHomePage, 30);
  };

  isProfileExist = async (profileName) => {
    await menuPage.navigateToPage('Account');
    const profileNames = await commons.findElements(this.profileNameList);

    return profileNames.includes(
      this.getCustomLocator(this.profileName_txt, profileName),
    );
  };

  openManageProfiles = async () => {
    await menuPage.navigateToPage('Home');
    await menuPage.navigateToPage('Account');
    await commons.click(this.manageProfiles_btn, 30);
    await commons.waitUntil(this.manageProfiles_lbl, 30);
  };

  getNonDefaultProfilesList = async () => {
    let individualProfileName;
    const profileNames = [];
    const elements = await commons.findElements(this.#nonDefaultProfilesList);

    profileCountBeforeDeletion = await elements.length;
    for (let i = 0; i < profileCountBeforeDeletion; i++) {
      individualProfileName = await commons.fetchAttributeData(
        elements[i],
        'label',
      );

      let oldProfile = true;
      let existingProfileRandomTime;

      // Split the individualProfileName and then compare the timestamp.
      // if <10 minutes, then do not delete that profile, else mark that profile as old profile.
      if (!individualProfileName.includes('Default')) {
        existingProfileRandomTime = individualProfileName.match(/[a-z]+|\d+/gi);
        if (existingProfileRandomTime.length > 1) {
          if (
            Math.round(
              Math.abs(
                Date.now() / 1000 -
                  existingProfileRandomTime[
                    existingProfileRandomTime.length - 1
                  ],
              ) / 60,
            ) <= 10
          ) {
            oldProfile = false;
          }
        }
      }

      if (!individualProfileName.includes('Default') && oldProfile) {
        profileNames.push(
          this.getCustomLocator(this.profileTitle_lbl, individualProfileName),
        );
      }
      // For Oldprofile == false, we need to delete the newly created profile each time. Hence we need below condition
      if (individualProfileName === this.profileName && !oldProfile) {
        profileNames.push(
          this.getCustomLocator(this.profileTitle_lbl, individualProfileName),
        );
      }
    }

    return profileNames;
  };

  /**
   *  Deletes Profile
   *
   * @param {*} profileType [random: "deletes any profile",
   * Kids,Standard: "deletes profile name starting with Kids or Standard"],
   * '': if no value is passed , by default deletes random profile,
   * 'any other name': function deletes profile with given name
   */
  deleteUserProfile = async (profileType = '') => {
    await this.openManageProfiles();
    let profileToDelete;

    if (profileType.length === 0 || profileType === 'random') {
      this.nonDefaultProfileList = await this.getNonDefaultProfilesList();

      if (this.nonDefaultProfileList.length === 0) {
        throw new Error('There are no Non-Default profiles to delete');
      }
      profileToDelete =
        this.nonDefaultProfileList[
          Number(this.nonDefaultProfileList.length) - 1
        ];

      this.deletedProfileName = await commons.fetchAttributeData(
        profileToDelete,
        'label',
      );
      profileToDelete = this.getCustomLocator(
        this.editProfile_btn,
        this.deletedProfileName,
      );
    } else if (Object.keys(this.profilesList).includes(profileType)) {
      profileToDelete = this.profilesList[profileType];
    } else {
      profileToDelete = this.getCustomLocator(
        this.editProfile_btn,
        this.profileName,
      );
    }
    await commons.click(profileToDelete);
    await commons.waitUntil(this.createProfileName_txtBx, 80);
    if (await commons.elementExists(this.profile_lbl)) {
      await commons.click(this.profile_lbl);
    } else {
      await commons.clickCoordinates(300, 190);
    }
    await commons.click(this.deleteProfile_btn);
    await commons.waitUntil(this.deleteProfilePopup_btn, 20);
    await commons.click(this.deleteProfilePopup_btn, 20);
    await commons.waitUntil(this.profile_header, 20);
    await commons.clickBack();
  };

  deleteProfile = async (profileType) => {
    await this.selectProfile('Default');
    await commons.waitUntil(menuPage.accountMenu_lbl, 30);
    await commons.click(menuPage.accountMenu_lbl, 30);
    await this.openManageProfiles();
    if (!(await commons.elementExists(this.addProfile_btn))) {
      await commons.click(this.back_btn);
      await this.deleteUserProfile('random');
    }
    await this.createNewProfile('Standard');
    await this.deleteUserProfile(profileType);
  };

  verifyUserProfileDeleted = async () => {
    if (await commons.elementExists(this.manageProfiles_lbl)) {
      await commons.click(this.manageProfiles_lbl);
    }

    const nonDefaultProfilesPostDeletion =
      await this.getNonDefaultProfilesList();

    assert.equal(
      Number(nonDefaultProfilesPostDeletion.length),
      Number(this.nonDefaultProfileList.length - 1),
      'Profile Deletion Validation Failed!!',
    );
  };

  deleteExistingProfile = async () => {
    if (this.profileName === 'Pin') return;

    if (await commons.elementExists(this.homeMenu_lbl, 10)) {
      await commons.click(this.homeMenu_lbl);
      await commons.waitUntil(menuPage.accountMenu_lbl, 30);
      await commons.click(menuPage.accountMenu_lbl);
      await this.selectProfile('Default');
      await commons.waitUntil(menuPage.focusedHomePage, 30);
      await commons.waitUntil(menuPage.accountMenu_lbl, 30);
      await commons.click(menuPage.accountMenu_lbl, 30);
    }
    await this.deleteUserProfile(this.profileName);
  };

  createNewProfileandSelect = async (profileName) => {
    if (this.getUserAnonymous()) {
      return;
    }
    const isProfileExist = await this.isProfileExist(profileName);

    if (isProfileExist) {
      await this.deleteExistingProfile();
      await commons.elementExists(this.manageProfiles_lbl, 10);
      if (await commons.elementExists(this.back_btn)) {
        await commons.click(this.back_btn);
      }
    }
    await this.createNewProfile(profileName);
    await this.isProfileExist(this.profileName);
    await this.selectProfile(this.profileName);
  };
}

module.exports = ProfilePage;
