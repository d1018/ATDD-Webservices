const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const VideoPlayerPage = require('./videoPlayerPage');
const HomePage = require('./homePage');

const commons = mobileActions;
const videoPlayerPage = new VideoPlayerPage();
const homePage = new HomePage();

class NetworkLandingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('networkLandingPage', locator);
  }

  networkName_lbl = this.getElementByPage('homePage', 'networkName_lbl');

  networkRail_lbl = this.getElementByPage('homePage', 'networkRail_lbl');

  rail_lbl = this.getElementByPage('homePage', 'rail_lbl');

  signUpCta_btn = this.getElementByPage('basePage', 'signUpCta_btn');

  networkLogo_img = this.#getSelectorData('networkLogo_img');

  back_btn = this.getElementByPage('myListPage', 'back_btn');

  networkTile_lbl = this.getElementByPage('homePage', 'networkTile_lbl');

  watchNow_btn = this.getElementByPage('basePage', 'watchNow_btn');

  listOfNetworks = {
    Entertainment: this.getCustomLocator(
      this.networkName_lbl,
      testdataHelper.getContent('networkPage.Entertainment'),
    ),
    Sports: this.getCustomLocator(
      this.networkName_lbl,
      testdataHelper.getContent('networkPage.Sports'),
    ),
  };

  entertainmentNetworkRailsNames = [
    this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('networkPage.PopularShowsRail'),
    ),
    this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('networkPage.JustAddedRail'),
    ),
    this.networkRail_lbl,
  ];

  sportsNetworkRailsNames = [
    this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('networkPage.LiveRail'),
    ),
    this.getCustomLocator(
      this.rail_lbl,
      testdataHelper.getContent('networkPage.UpcomingRail'),
    ),
  ];

  validateEntertainmentNetworkLandingPage = async () => {
    if (await this.getUserAnonymous()) {
      await commons.waitUntil(this.signUpCta_btn);
    } else {
      if (!(this.returnGeoLocation() === 'america')) {
        await commons.waitUntil(this.watchNow_btn);
      }
      await homePage.isRailPresent(homePage.railNames['Recommended For You']);
    }
    await commons.waitUntil(this.networkLogo_img, 80);
    for (let i = 0; i < this.entertainmentNetworkRailsNames.length; i++) {
      await homePage.isRailPresent(
        this.entertainmentNetworkRailsNames[i],
        '40%',
      );
      await commons.waitUntil(this.entertainmentNetworkRailsNames[i]);
      await commons.scrollToElement(this.networkLogo_img, 'up', 5, '40%');
    }
    await commons.click(this.back_btn);
  };

  validateSportsNetworkLandingPage = async () => {
    if (await this.getUserAnonymous()) {
      await commons.waitUntil(this.signUpCta_btn);
    } else {
      await commons.waitUntil(this.watchNow_btn);
    }
    await commons.waitUntil(this.networkLogo_img, 80);
    for (let i = 0; i < this.sportsNetworkRailsNames.length; i++) {
      await homePage.isRailPresent(this.sportsNetworkRailsNames[i]);
      await commons.waitUntil(this.sportsNetworkRailsNames[i]);
      await commons.scrollToElement(this.networkLogo_img, 'up', 5);
    }
    await commons.click(this.back_btn);
  };

  validateNetworkLandingPage = async (network) => {
    if (network === 'Entertainment') {
      await this.validateEntertainmentNetworkLandingPage();
    } else if (network === 'Sports') {
      await this.validateSportsNetworkLandingPage();
    } else {
      throw new Error(`'${network}' Network is not defined`);
    }
  };

  selectAndValidateNetworkLandingPage = async (network) => {
    const networkName = testdataHelper.getContent(`networkPage.${network}`);
    let networkList = await this.getListOfShows(this.networkTile_lbl);

    if (
      (this.returnGeoLocation() === 'america' && network === 'Entertainment') ||
      (this.returnGeoLocation() === 'emea' &&
        network === ('Entertainment' || 'Sports'))
    ) {
      while (!networkList.includes(networkName)) {
        await commons.swipeOnElement(this.networkRail_lbl, 'left', 5);
        networkList = await this.getListOfShows(this.networkTile_lbl);
      }
      await commons.waitUntil(this.listOfNetworks[network]);
      await commons.click(this.listOfNetworks[network]);
      await this.validateNetworkLandingPage(network);
    }
  };

  /**
   * Verify Simulcast Users  (Verify CTA and Playback)
   *
   * @param {string} user -  Type of User - Anonymous and Fully-Entitled
   */
  validateSimulcastUsers = async (user) => {
    if (user === 'anonymous') {
      await commons.waitUntil(this.signUpCta_btn);
    } else {
      await commons.waitUntil(this.watchNow_btn);
      await commons.click(this.watchNow_btn);
      await videoPlayerPage.isVideoPlaying();
    }
    await commons.clickBack();
  };

  /**
   * Verify Simulcast Playback Page for Users
   *
   * @param {string} user -  Type of User (Anonymous or Fully Entitled)
   * @param {string} network - Entertainment - Discovery+, Sports - E1
   */
  verifySimulcastPlaybackOnNetworkPage = async (user, network) => {
    await this.goToSimulcastNetwork(network);
    await this.validateSimulcastUsers(user);
  };

  goToSimulcastNetwork = async (network) => {
    const networkName = testdataHelper.getContent(`networkPage.${network}`);
    let networkList = await this.getListOfShows(this.networkTile_lbl);

    while (!networkList.includes(networkName)) {
      await commons.swipeOnElement(this.networkRail_lbl, 'left', 5);
      networkList = await this.getListOfShows(this.networkTile_lbl);
    }
    await commons.waitUntil(this.listOfNetworks[network]);
    await commons.click(this.listOfNetworks[network]);
  };

  verifyNetworkRailForKidsProfile = async () => {
    if (this.returnGeoLocation() === 'america') {
      await homePage.verifyRailPresent('Network', true);
    } else if (this.returnGeoLocation() === 'emea') {
      await homePage.verifyRailPresent('Network', false);
    }
  };
}
module.exports = NetworkLandingPage;
