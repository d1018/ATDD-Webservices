const retry = require('async-retry');
const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const MenuPage = require('./menuPage');
const ProfilePage = require('./profilePage');

const commons = mobileActions;
const menuPage = new MenuPage();
const profilePage = new ProfilePage();

class AccountPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('accountPage', locator);
  }

  accountTitle_lbl = this.#getSelectorData('accountTitle_lbl');

  accountTab_lbl = this.#getSelectorData('accountTab_lbl');

  signIn_btn = this.#getSelectorData('signIn_btn');

  myList_lbl = this.#getSelectorData('myList_btn');

  account_lbl = this.#getSelectorData('account_lbl');

  settings_lbl = this.#getSelectorData('settings_lbl');

  helpCentre_lbl = this.#getSelectorData('helpCentre_lbl');

  about_lbl = this.#getSelectorData('about_lbl');

  signOut_lbl = this.#getSelectorData('signOut_lbl');

  focusedManageAccountPage = this.#getSelectorData('focusedManageAccountPage');

  focusedSettingsPage = this.#getSelectorData('focusedSettingsPage');

  focusedMyListPage = this.#getSelectorData('focusedMyListPage');

  focusedHelpCentrePage = this.#getSelectorData('focusedHelpCentrePage');

  focusedAboutPage = this.#getSelectorData('focusedAboutPage');

  focusedSignOutPopUp = this.#getSelectorData('focusedSignOutPopUp');

  focusedCancelPopUp = this.#getSelectorData('focusedCancelPopUp');

  signup_btn = this.getElementByPage('signInPage', 'signup_btn');

  back_btn = this.getElementByPage('basePage', 'back_btn');

  manageProfiles_btn = this.#getSelectorData('manageProfiles_btn');

  accountPageSubMenu = {
    Account: this.account_lbl,
    Settings: this.settings_lbl,
    'My List': this.myList_lbl,
    Help: this.helpCentre_lbl,
    'Help Centre': this.helpCentre_lbl,
    About: this.about_lbl,
    'Sign Out': this.signOut_lbl,
  };

  accountSubNavigationPageFocused = {
    Account: this.focusedManageAccountPage,
    Settings: this.focusedSettingsPage,
    'My List': this.focusedMyListPage,
    Help: this.focusedHelpCentrePage,
    'Help Centre': this.focusedHelpCentrePage,
    About: this.focusedAboutPage,
    'Sign Out': this.focusedSignOutPopUp,
  };

  /**
   * On the basis of user type(Anonymous, Default, Kids), the below function will confirm Account Sub Menu list length accordingly.
   */

  getUserAccountMenuItems = (profileName) => {
    const accountType = {
      Anonymous: 'anonymousUserAccountItemList',
      Default: 'defaultUserAccountItemList',
      Kids: 'kidsUserAccountItemList',
    };

    return testdataHelper.getContent(`accountPage.${accountType[profileName]}`);
  };

  /**
   * The below function will verify the Account sub menu list based on user type (Anonymous, Default, Kids).
   */

  verifyAccountPage = async (profileName) => {
    if (!(await this.getUserAnonymous())) {
      await profilePage.selectProfile(profileName);
    }
    await menuPage.navigateToPage('Account');
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      if (
        this.returnGeoLocation() === 'america' &&
        accountMenuList[i] !== 'My List'
      ) {
        await commons.waitUntil(this.accountPageSubMenu[accountMenuList[i]]);
      }
    }
  };

  /**
   * The below function will navigate to the account sub menu pages and verify based on user type (Anonymous, Default, Kids).
   */

  verifyAccountSubNavigationPage = async (profileName) => {
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      if (
        this.returnGeoLocation() === 'america' &&
        accountMenuList[i] !== 'My List'
      ) {
        await commons.waitUntil(
          this.accountPageSubMenu[accountMenuList[i]],
          30,
        );

        await retry(
          async () => {
            await commons.click(this.accountPageSubMenu[accountMenuList[i]]);
            await commons.waitUntil(
              this.accountSubNavigationPageFocused[accountMenuList[i]],
              10,
            );
          },
          { retries: 3, minTimeout: 3000, maxTimeout: 5000 },
        );

        if (accountMenuList[i] === 'Sign Out') {
          await commons.click(await this.focusedCancelPopUp);
        } else {
          await commons.waitUntil(this.back_btn, 10);
          await commons.click(this.back_btn);
          try {
            await retry(
              async () => {
                await commons.waitUntil(this.manageProfiles_btn, 10);
              },
              { retries: 3, minTimeout: 3000, maxTimeout: 5000 },
            );
          } catch (error) {
            await commons.clickBack();
            await menuPage.navigateToPage('Home');
            await menuPage.navigateToPage('Account');
          }
        }
      }
      await commons.waitUntil(this.accountPageSubMenu.About, 10);
    }
  };

  validateCtaAccountPage = async () => {
    await commons.click(menuPage.accountMenu_lbl);
    await commons.elementExists(this.signIn_btn, 30);
    await commons.elementExists(this.signup_btn, 30);
  };
}

module.exports = AccountPage;
