const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class ShowDetailsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('showPage', locator);
  }

  showHeroImage = this.#getSelectorData('showHeroImage');

  ctaButtons = this.#getSelectorData('ctaButtons');

  signUp_btn = this.#getSelectorData('signUp_btn');

  watchNow_btn = this.#getSelectorData('watchNow_btn');

  tab_bar = this.getElementByPage('basePage', 'tab_bar');

  crime_lbl = this.getElementByPage('homePage', 'crime_lbl');

  firstTileOnRail_lbl = this.getElementByPage(
    'homePage',
    'firstTileOnRail_lbl',
  );

  focusedHomePage = this.getElementByPage('homePage', 'featuredRail_lbl');

  featuredRail_lbl = this.getElementByPage('homePage', 'featuredRail_lbl');

  rail_lbl = this.getElementByPage('homePage', 'rail_lbl');

  firstShow_tile = this.getElementByPage('searchPage', 'firstContent');

  search_txtBx = this.getElementByPage('searchPage', 'search_txtBx');

  episodesList = {
    1: this.#getSelectorData('firstEpisode_img'),
  };

  back_btn = this.getElementByPage('basePage', 'back_btn');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  assertCTAButton = {
    anonymous: this.signUp_btn,
    'fully-entitled': this.watchNow_btn,
    'non-entitled': this.watchNow_btn,
    'new-profile': this.watchNow_btn,
  };

  genreTabItems = {
    'For You': this.forYou_lbl,
    Crime: this.crime_lbl,
  };

  railNames = {
    Trending: this.getCustomLocator(this.rail_lbl, 'Trending'),
    Featured: this.featuredRail_lbl,
  };

  showTiles = {
    FirstTileOnFeaturedRail: this.#getSelectorData(
      'firstTileOnFeaturedRail_lbl',
    ),
    FirstShow: this.firstShow_tile,
  };

  selectAndPlayVideo = async (index) => {
    if (await commons.elementExists(this.search_txtBx)) {
      await this.selectShow('FirstShow');
      await commons.waitUntil(this.watchNow_btn, 30);
      await commons.click(this.watchNow_btn);
    } else {
      await commons.click(this.episodesList[index], 10);
    }
  };

  verifyShowLandingAnchorDetails = async () => {
    assert.equal(
      await commons.elementExists(this.showHeroImage, 60),
      true,
      'showHeroImage metadata validation failed',
    );
    assert.equal(
      await commons.elementExists(this.ctaButtons, 60),
      true,
      'ctaButtons metadata validation failed',
    );
  };

  validateCTAonGenres = async (userType, genreName) => {
    const genreArr = genreName.raw();

    const failure = [];

    for (let i = 0; i < genreArr.length; i++) {
      const genre = genreArr[i].toString();

      switch (genre) {
        case 'For You':
          await commons.waitUntil(this.genreTabItems[genre], 20);
          await this.scrollToRailByElement('Featured');
          await this.verifyRailPresent('Featured', true);
          await commons.waitUntil(this.showTiles.FirstTileOnFeaturedRail, 20);
          await this.selectShow('FirstTileOnFeaturedRail');
          break;
        case 'Crime':
          await commons.waitUntil(this.genreTabItems[genre], 20);
          await commons.click(this.genreTabItems[genre]);
          await this.verifyRailPresent('Trending', true);
          await commons.click(
            this.getCustomLocator(this.firstTileOnRail_lbl, 'Trending'),
          );
          break;
        default:
      }

      try {
        await this.verifyShowLandingAnchorDetails();
        await this.validateCTAForUser(userType);
        await commons.click(this.back_btn);
      } catch (e) {
        failure.push(`CTA validation failed for ${genre} genre!`);
        await commons.click(this.back_btn);
      }

      await commons.waitUntil(this.tab_bar, 30);
      while (!(await commons.elementExists(this.forYou_lbl))) {
        await commons.swipeOnElement(this.tab_bar, 'right', 5);
      }
    }

    if (failure.length !== 0) {
      throw new Error(failure.toString());
    }
  };

  selectShow = async (index) => {
    await commons.click(this.showTiles[index], 10);
  };

  validateCTAForUser = async (userType) => {
    await commons.waitUntil(this.assertCTAButton[userType.toLowerCase()]);
  };

  isRailPresent = async (railName) => {
    for (let count = 0; count < 20; count++) {
      if (await commons.elementExists(railName, 5)) return true;
      await commons.scrollOnPageByPercentage('down', '25%');
    }
    return false;
  };

  verifyRailPresent = async (railName, expflag) => {
    const actualFlag = await this.isRailPresent(this.railNames[railName]);

    assert.strictEqual(
      actualFlag,
      expflag,
      new TypeError(
        `Validation Failed! , Actual: ${railName} rail is not present`,
      ),
    );
  };

  scrollToRailByElement = async (railName) => {
    await commons.scrollToElement(this.railNames[railName], 'down', 5);
    await commons.scrollToElement(
      this.getCustomLocator(this.firstTileOnRail_lbl, railName),
      'down',
      5,
    );
    await commons.waitUntil(
      this.getCustomLocator(this.firstTileOnRail_lbl, railName),
      30,
    );
    // await commons.click(this.railNames[railName]);
  };
}

module.exports = ShowDetailsPage;
