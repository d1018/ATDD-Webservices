const geo = ['US', 'Us', 'us'].includes(process.env.GEO) ? '' : process.env.GEO;
const project = process.env.BS_PROJECT || 'iOS Project';
const name = process.env.NAME || 'iOS Test';
const build = process.env.BUILD || 'iOS testing';
const debug = process.env.DEBUG || true;
const osVersion = process.env.OS_VERSION || '14.1';
const device = process.env.DEVICE_NAME || 'iPhone 12';
const app = process.env.APP || 'bs://cd7563e5228c22281136aa6490c63516a7e18d35';
const bsLocal = process.env.BS_LOCAL || false;
const locale = process.env.BS_LOCALE || 'en_US';
const autoAcceptAlerts = process.env.AUTO_ACCEPT_ALERTS || false;
const localExecution = process.env.LOCAL_EXECUTION || false;

const iosCapabilities = {
  'browserstack.user': process.env.BS_USER,
  'browserstack.key': process.env.BS_KEY,
  device,
  os_version: osVersion,
  platformName: 'IOS',
  automationName: 'XCUITest',
  locale,
  app,
  name,
  build,
  project,
  chromeOptions: { w3c: false },
  allowInvisibleElements: 'true',
  'browserstack.debug': debug,
  'browserstack.appium_version': '1.21.0',
  'browserstack.networkLogs': 'true',
  'browserstack.appProfiling': 'true',
  'browserstack.resignApp': 'false',
  'browserstack.geoLocation': geo,
  'browserstack.deviceLogs': true,
  autoAcceptAlerts,
  'browserstack.console': 'verbose',
  'browserstack.acceptInsecureCerts': 'false',
  acceptSslCert: 'true',
  'browserstack.idleTimeout': '180',
  'browserstack.local': bsLocal,
  language: 'en',
  fullReset: true,
  usePrebuiltWDA: true,
};

const localIosCapabilities = {
  platformName: 'iOS',
  platformVersion: osVersion,
  deviceName: 'iPhone',
  udid: process.env.UDID,
  xcodeOrgId: process.env.XCODE_ORG_ID,
  automationName: 'Appium',
  usePrebuiltWDA: false,
  useNewWDA: false,
  bundleId: process.env.BUNDLE_ID,
  wdaLaunchTimeout: 2_400_000,
  wdaConnectionTimeout: 2_400_000,
  shouldUseSingletonTestManager: false,
  waitForQuiescence: false,
  clearSystemFiles: true,
  allowInvisibleElements: true,
  wdaStartupRetryInterval: '1000',
  newCommandtimeout: '3600',
};

const desiredIosCapabilities =
  localExecution === 'true' ? localIosCapabilities : iosCapabilities;

module.exports = {
  desiredIosCapabilities,
};
