const assert = require('assert');

const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class ShowDetailsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('showPage', locator);
  }

  aboutTheShow_lbl = this.#getSelectorData('aboutTheShow_lbl');

  navigateBack_btn = this.#getSelectorData('navigateBack_btn');

  watchNow_btn = this.#getSelectorData('watchNow_btn');

  resume_btn = this.#getSelectorData('resume_btn');

  showName_img = this.#getSelectorData('showName_img');

  listIcon_btn = this.#getSelectorData('listIcon_btn');

  signUp_btn = this.#getSelectorData('signUp_btn');

  secondGenre_lbl = this.getElementByPage('homePage', 'secondGenre_lbl');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  crime_lbl = this.getElementByPage('homePage', 'crime_lbl');

  startWatching_btn = this.#getSelectorData('startWatching_btn');

  videoContainerView = this.getElementByPage(
    'videoPlayerPage',
    'videoContainerView',
  );

  startWatching_txt = this.#getSelectorData('startWatching_txt');

  videoTitle_txt = this.getElementByPage('videoPlayerPage', 'videoTitle_txt');

  videoOverline_txt = this.getElementByPage(
    'videoPlayerPage',
    'videoOverline_txt',
  );

  episodesList = {
    1: this.#getSelectorData('firstEpisode_img'),
    2: this.#getSelectorData('secondEpisode_img'),
  };

  verifyShowLandingAnchorDetails = async () => {
    await commons.waitUntil(this.aboutTheShow_lbl, 30);
  };

  selectAndPlayVideo = async (index) => {
    await commons.waitUntil(this.showName_img, 30);
    await this.setShowNameText(
      await commons.fetchAttributeData(this.showName_img, 'text'),
    );
    await commons.click(this.showName_img);
    await commons.click(this.episodesList[index], 10);
    await this.setEpisodeNameText(
      await commons.fetchAttributeData(this.videoTitle_txt, 'text'),
    );
  };

  clickAddToFavourites = async () => {
    await commons.click(this.listIcon_btn, 30);
  };

  validateCTAonGenres = async (userType, pageName) => {
    const pages = pageName.raw();

    for (let i = 0; i < pages.length; i++) {
      switch (pages[i].toString().toLowerCase()) {
        case 'for you':
          await commons.click(this.forYou_lbl, 30);
          break;
        case 'crime':
          await commons.click(this.crime_lbl, 30);
          break;
        default:
      }
      assert(
        (await commons.elementExists(this.startWatching_txt, 30)) &&
          (await commons.elementExists(this.listIcon_btn, 5)),
        `Start Watching CTA and My list icon are not displayed`,
      );
      await commons.click(this.startWatching_btn, 5);
      assert(
        await commons.elementExists(this.watchNow_btn, 30),
        `Watch Now CTA is not displayed`,
      );
      await commons.click(this.watchNow_btn, 5);
      assert(
        await commons.elementExists(this.videoContainerView, 30),
        `Video Playback is not initiated`,
      );
      await commons.clickBack();
      await commons.clickBack();
    }
  };
}

module.exports = ShowDetailsPage;
