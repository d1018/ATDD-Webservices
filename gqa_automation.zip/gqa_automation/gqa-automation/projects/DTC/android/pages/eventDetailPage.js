const assert = require('assert');

const {
  BasePage,
  mobileActions,
  skipReason,
  customErrors,
} = require('./basePage');
const MenuPage = require('./menuPage');

const commons = mobileActions;
const { SkipError } = customErrors;
const menuPage = new MenuPage();

class EventDetailPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('eventDetailPage', locator);
  }

  live_lbl = this.#getSelectorData('live_lbl');

  clockIcon = this.#getSelectorData('clockIcon');

  watchTimeText = this.#getSelectorData('watchTimeText');

  signUp_btn = this.#getSelectorData('signUp_btn');

  signIn_btn = this.#getSelectorData('signIn_btn');

  watchLiveText = this.#getSelectorData('watchLiveText');

  overlayErrorText = this.#getSelectorData('overlayErrorText');

  playerProgress_bar = this.getElementByPage(
    'videoPlayerPage',
    'playerProgress_bar',
  );

  playerGoLive_lbl = this.#getSelectorData('playerGoLive_lbl');

  videoContainerView = this.getElementByPage(
    'videoPlayerPage',
    'videoContainerView',
  );

  playerBack_btn = this.getElementByPage('videoPlayerPage', 'playerBack_btn');

  upcomingRail_lbl = this.getElementByPage('sportsPage', 'upcomingRail_lbl');

  liveRail_lbl = this.getElementByPage('sportsPage', 'liveRail_lbl');

  hidePlayerControl = this.#getSelectorData('hidePlayerControl');

  firstTileOnUpcomingRail_lbl = this.getElementByPage(
    'sportsPage',
    'firstTileOnUpcomingRail_lbl',
  );

  firstTileOnLiveRail_lbl = this.getElementByPage(
    'sportsPage',
    'firstTileOnLiveRail_lbl',
  );

  playerLiveLabel_lbl = this.getElementByPage(
    'videoPlayerPage',
    'playerLiveLabel_lbl',
  );

  viewPasses_lbl = this.getElementByPage('videoPlayerPage', 'viewPasses_lbl');

  chooseYourPass_lbl = this.getElementByPage(
    'signInPage',
    'chooseYourPass_lbl',
  );

  live_txt = this.getElementByPage('sportsPage', 'live_txt');

  /**
   * The below function will navigate to sports page and scroll to first tile upcoming rail
   *
   */
  selectUpcomingRailFirstEvent = async () => {
    await menuPage.navigateToPage('Sports');
    await commons.scrollToElement(this.upcomingRail_lbl, 'down', 10);
    await commons.waitUntil(this.firstTileOnUpcomingRail_lbl);
    await commons.click(this.firstTileOnUpcomingRail_lbl, 30);
  };

  /**
   * The below function will verify cta button on event landing page
   */
  verifyCTAonPlayer = async () => {
    if (await commons.elementExists(this.overlayErrorText)) {
      assert(
        (await commons.elementExists(this.signUp_btn)) &&
          (await commons.elementExists(this.signIn_btn)),
        `Sign In & Sign Up CTA are displayed`,
      );
    } else {
      assert(
        !(await commons.elementExists(this.signUp_btn)) &&
          !(await commons.elementExists(this.signIn_btn)),
        `Sign In & Sign Up CTA are displayed`,
      );
    }
  };

  /**
   * The below function will verify the cta and element on live Event page
   */
  validateLiveEventDeatilPage = async () => {
    await commons.waitUntil(this.clockIcon, 20);
    await commons.waitUntil(this.live_lbl, 20);
    await commons.waitUntil(this.watchTimeText, 20);
    await commons.waitUntil(this.watchLiveText, 20);
    await commons.waitUntil(this.liveCTA.watchFromStart_btn);
    await commons.waitUntil(this.liveCTA.watchLive_btn);
  };

  /**
   * The below function will verify the element on Event landing page
   */
  validateEventDeatilPage = async () => {
    await commons.waitUntil(this.clockIcon);
    await commons.waitUntil(this.watchTimeText, 5);
    await commons.waitUntil(this.watchLiveText, 10);
  };

  /**
   * The below function will select the live rail first event
   */
  selectLiveRailFirstEvent = async () => {
    await commons.scrollToElement(this.liveRail_lbl, 'down', 10);
    await commons.waitUntil(this.firstTileOnLiveRail_lbl, 10);
    await commons.click(this.firstTileOnLiveRail_lbl, 5);
  };

  liveCTA = {
    watchFromStart_btn: this.#getSelectorData('watchFromStart_btn'),
    watchLive_btn: this.#getSelectorData('watchLive_btn'),
  };

  /**
   * The below function will verify live lable
   */
  checkLiveEventRailAvailability = async () => {
    if (!(await commons.elementExists(this.live_txt))) {
      throw new SkipError(skipReason.noLiveEvent);
    }
  };

  /**
   * The below function will verify CTA Watch Live button On VOD player
   */
  selectLiveCtaAndValidateVOD = async () => {
    await commons.waitUntil(this.liveCTA.watchLive_btn, 5);
    await commons.click(this.liveCTA.watchLive_btn, 5);
    await commons.waitUntil(this.videoContainerView);
    await commons.waitUntil(this.playerLiveLabel_lbl);
  };

  /**
   * The below function will verify CTA Watch from start button On VOD player
   */
  selectStartCtaAndValidateVOD = async () => {
    await commons.clickBack();
    await this.selectLiveRailFirstEvent();
    await commons.waitUntil(this.liveCTA.watchFromStart_btn, 10);
    await commons.click(this.liveCTA.watchFromStart_btn, 5);
    await commons.waitUntil(this.videoContainerView);
    await commons.waitUntil(this.playerGoLive_lbl);
  };

  clickOnViewPassesCta = async () => {
    await commons.click(this.viewPasses_lbl);
  };

  validatePlanPickerScreen = async () => {
    await commons.waitUntil(this.chooseYourPass_lbl);
  };
}

module.exports = EventDetailPage;
