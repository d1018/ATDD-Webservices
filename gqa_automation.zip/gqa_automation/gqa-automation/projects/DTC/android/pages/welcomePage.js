const assert = require('assert');
const { SkipError } = require('@wbd/gqa-core/support/customErrors');
const { BasePage, skipReason, mobileActions } = require('./basePage');
const PlanPickerPage = require('./planPickerPage');
const SignInPage = require('./signInPage');

const commons = mobileActions;
const planPickerPage = new PlanPickerPage();
const signInPage = new SignInPage();

class WelcomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('welcomePage', locator);
  }

  welcomeTitle = this.#getSelectorData('welcomeTitle');

  subscribeNow = this.#getSelectorData('subscribe_btn');

  signIn = this.getElementByPage('accountPage', 'signIn_btn');

  maybeLater_btn = this.#getSelectorData('maybeLater_btn');

  verifyWelcomeScreen = async () => {
    if (!(process.env.DEVICE === 'firetab')) {
      await signInPage.reOpenApp();
    }
    assert(
      await commons.elementExists(this.welcomeTitle),
      `WelcomeTitle is not displayed`,
    );
  };

  /**
   * Navigate CTA on WelcomeScreen
   *
   * @param {string} screenCTA -  Subscribe Now/Sign In
   */
  verifyLandingPageOfWelcomeScreen = async (screenCTA) => {
    if (process.env.DEVICE === 'firetab') {
      throw new SkipError(skipReason.planPickerNotDisplayed);
    }
    const buttonsCTA = {
      'Subscribe Now': this.subscribeNow,
      'Sign In': this.signIn,
    };

    assert(
      await commons.elementExists(buttonsCTA[screenCTA], 30),
      ` ${buttonsCTA[screenCTA]} is not displayed`,
    );
    await commons.click(buttonsCTA[screenCTA]);
    if (screenCTA === 'Subscribe Now') {
      if (await commons.elementExists(this.maybeLater_btn, 30)) {
        await commons.click(this.maybeLater_btn);
      }
      await planPickerPage.validatePlanPickerPage();
    } else {
      await signInPage.validateSignInPage();
    }
    await commons.clickBack();
  };
}
module.exports = WelcomePage;
