const assert = require('assert');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const SearchPage = require('./searchPage');
const MenuPage = require('./menuPage');
const ShowDetailsPage = require('./showDetailsPage');
const VideoPlayerPage = require('./videoPlayerPage');
const MyListPage = require('./myListPage');
const ProfilePage = require('./profilePage');

const commons = mobileActions;

const searchPage = new SearchPage();
const menuPage = new MenuPage();
const showDetailsPage = new ShowDetailsPage();
const videoPlayerPage = new VideoPlayerPage();
const myListPage = new MyListPage();
const profilePage = new ProfilePage();

let jipShowName;

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  focusedHomePage = this.#getSelectorData('focusedHomePage');

  kidsContent_title = this.#getSelectorData('kidsContent_title');

  showName_lbl = this.#getSelectorData('showName_lbl');

  JIPContent = this.getElementByPage('searchPage', 'JIPContent');

  clearSearch_Btn = this.getElementByPage('searchPage', 'clearSearch_Btn');

  homeIcon_txt = this.#getSelectorData('homeIcon_txt');

  heroShowTitle = this.#getSelectorData('heroShowTitle');

  heroShowDescription = this.#getSelectorData('heroShowDescription');

  myListTilesSection = this.#getSelectorData('myListTilesSection');

  startWatching_btn = this.getElementByPage('showPage', 'startWatching_btn');

  jipRail_txt = this.#getSelectorData('jipRail_txt');

  jipShowName_img = this.#getSelectorData('jipShowName_img');

  jipShowName_img2 = this.#getSelectorData('jipShowName_img2');

  jipchannels_lbl = this.#getSelectorData('jipchannels_lbl');

  jipVideoTitle_lbl = this.#getSelectorData('jipVideoTitle_lbl');

  search_txtBx = this.getElementByPage('searchPage', 'search_txtBx');

  rating = this.#getSelectorData('rating_txt');

  signOut_btn = this.#getSelectorData('signOut_btn');

  confirmSignOut_btn = this.#getSelectorData('confirmSignOut_btn');

  nextEpisodeRating = this.getElementByPage(
    'showPage',
    'nextEpisodeRating_txt',
  );

  videoContainerView = this.getElementByPage(
    'videoPlayerPage',
    'videoContainerView',
  );

  playerBack_btn = this.getElementByPage(
    'videoPlayerPage',
    'videoContainerView',
  );

  fullScreenToggle_btn = this.getElementByPage(
    'videoPlayerPage',
    'fullScreenToggle_btn',
  );

  playerPause_btn = this.getElementByPage('videoPlayerPage', 'playerPause_btn');

  jipContentName_img = this.#getSelectorData('jipContentName_img');

  playerProgress_bar = this.getElementByPage(
    'videoPlayerPage',
    'playerProgress_bar',
  );

  playerLiveLabel_lbl = this.getElementByPage(
    'videoPlayerPage',
    'playerLiveLabel_lbl',
  );

  enjoyingDiscovery_popup = this.getElementByPage(
    'profilePage',
    'enjoyingDiscovery_popup',
  );

  firstEpisode_img = this.getElementByPage('showPage', 'firstEpisode_img');

  homeMenu_lbl = this.getElementByPage('menuPage', 'homeMenu_lbl');

  network_img = this.#getSelectorData('network_img');

  browserShows_btn = this.getElementByPage('myListPage', 'browserShows_btn');

  showTitle_lbl = this.getElementByPage('searchPage', 'showTitle_lbl');

  addList_btn = this.getElementByPage('myListPage', 'addList_btn');

  signUp_btn = this.getElementByPage('showPage', 'signUp_btn');

  watchNow_btn = this.getElementByPage('showPage', 'watchNow_btn');

  resume_btn = this.getElementByPage('showPage', 'resume_btn');

  networkRail = this.getElementByPage('networkLandingPage', 'networkRail');

  firstShowOnSportsDocumentaries = this.#getSelectorData(
    'firstShowOnSportsDocs_img',
  );

  cwRailFirstEpisode_txt = this.#getSelectorData('cwRailFirstEpisode_txt');

  cwRailFirstShow_txt = this.#getSelectorData('cwRailFirstShow_txt');

  cwRailFirstEpisodeCard = this.#getSelectorData('cwRailFirstEpisodeCard');

  forYou_lbl = this.#getSelectorData('forYou_lbl');

  startWatching_txt = this.getElementByPage('showPage', 'startWatching_txt');

  closePlayer_btn = this.getElementByPage('videoPlayerPage', 'closePlayer_btn');

  contentRatingTitle_lbl = this.getElementByPage(
    'videoPlayerPage',
    'contentRatingTitle_lbl',
  );

  playerForward_btn = this.getElementByPage(
    'videoPlayerPage',
    'playerForward_btn',
  );

  playerPlay_btn = this.getElementByPage('videoPlayerPage', 'playerPlay_btn');

  videoPlayerElementsJIP = [
    this.playerBack_btn,
    this.playerPlay_btn,
    this.playerProgress_bar,
    this.playerLiveLabel_lbl,
  ];

  /**
   * This function will switch to Kids profile and searches for UK-U label on Home rail. Also, this searches for A rated content and if shown, the validation fails
   */
  verifyKidsContentPopulated = async () => {
    if (await commons.elementExists(this.enjoyingDiscovery_popup)) {
      await commons.click(this.enjoyingDiscovery_popup);
    }

    const isKidsContentDisplayed = await this.searchContent('kids');

    assert(
      isKidsContentDisplayed,
      `Kids content is not shown on the kids search screen`,
    );

    const isAdultContentDisplayed = await this.searchContent('adult');

    assert(
      !isAdultContentDisplayed,
      `A rated content is shown on the kids search screen`,
    );
  };

  verifyJIPContent = async () => {
    if (this.countryCode !== 'us') {
      const isContentDisplayed = await this.searchContent('JIP');

      assert(
        !isContentDisplayed,
        `JIP content is shown on the kids search screen for non-US regions`,
      );
    } else if (this.countryCode === 'us') {
      const isContentDisplayed = await this.searchContent('JIP');

      assert(
        isContentDisplayed,
        `JIP content is NOT shown on the kids search screen for US region`,
      );
    }
  };

  searchContent = async (contentType) => {
    let isContentDisplayed = true;

    if (contentType === 'adult') {
      if (await commons.elementExists(this.clearSearch_Btn)) {
        await commons.click(this.clearSearch_Btn);
      }
      await searchPage.searchText('adultShowName');
      const adultContent = this.getCustomLocator(
        this.showName_lbl,
        testdataHelper.getContent(`searchPage.adultShowName`),
      );

      isContentDisplayed = await commons.elementExists(adultContent, 10);
    } else if (contentType === 'JIP') {
      if (await commons.elementExists(this.clearSearch_Btn)) {
        await commons.click(this.clearSearch_Btn);
      }
      await searchPage.searchText('JIPShowName');
      isContentDisplayed = await commons.elementExists(this.JIPContent, 10);
    } else if (contentType === 'kids') {
      await commons.waitUntil(this.kidsContent_title, 10);
      await menuPage.navigateToPage('Search');
      await searchPage.searchText('kidsShowName');
      const kidsContent = this.getCustomLocator(
        this.showName_lbl,
        testdataHelper.getContent(`searchPage.kidsShowName`),
      );

      isContentDisplayed = await commons.elementExists(kidsContent, 10);
    }
    return isContentDisplayed;
  };

  genreTabItems = {
    'For You': this.#getSelectorData('forYou_lbl'),
    Crime: this.#getSelectorData('crime_lbl'),
    'Paranormal and Unexplained': this.#getSelectorData('paranormal_lbl'),
  };

  railsList = {
    Featured: this.#getSelectorData('featuredRail_lbl'),
    SerialKillers: this.#getSelectorData('serialKillersRailOnCrimeTab_lbl'),
    FakingIt: this.#getSelectorData('videoRailOnCrimeTab_lbl'),
    'My List': this.#getSelectorData('myListRail_txt'),
    'Continue Watching': this.#getSelectorData('continueWatchingRail_lbl'),
    SportsDocumentaries: this.#getSelectorData('sportsDocumentaries_lbl'),
    FreeEpisodes: this.#getSelectorData('freeEpisodesRail_lbl'),
  };

  metadataForShow = {
    showName: this.#getSelectorData('showName'),
    episodeNameAndDescription: this.#getSelectorData(
      'episodeNameAndDescription',
    ),
    thumbnailImage: this.#getSelectorData('thumbnailImage'),
    progressBar: this.#getSelectorData('progressBar'),
  };

  showTiles = {
    FirstTileOnFeaturedRail: this.#getSelectorData(
      'firstTileOnFeaturedRail_lbl',
    ),
    FirstTileOnSerialKillersRail: this.#getSelectorData(
      'firstTileOnSerialKillersRail_lbl',
    ),
    FirstTileOnFakingItRail: this.#getSelectorData('firstTileOnVideoRail_lbl'),
    TheLastAlaskans: this.#getSelectorData('showName'),
    FirstShowOnSearchResults: this.#getSelectorData('firstShow_img'),
    FirstShowOnSportsDocumentaries: this.#getSelectorData(
      'firstShowOnSportsDocs_img',
    ),
    FirstShowOnFreeEpisodes: this.#getSelectorData('freeEpisode_img'),
    FirstPopularShowOnTLC: this.#getSelectorData('FirstPopularShowOnTLC_img'),
    FirstImageOnTrendingRail_img: this.#getSelectorData(
      'firstImageOnTrendingRail_img',
    ),
  };

  showsList = [
    testdataHelper.getContent('searchPage.myListShow1'),
    testdataHelper.getContent('searchPage.myListShow2'),
    testdataHelper.getContent('searchPage.multiContentShow'),
  ];

  myListMetadata = {
    thumbNail_img: this.#getSelectorData('myListThumbnail_img'),
    showTitle_txt: this.#getSelectorData('myListShowTitle_txt'),
    networkIcon_img: this.#getSelectorData('myListNetworkLogo_img'),
  };

  networkChannelsList = {
    TLC: this.#getSelectorData('tlc_lbl'),
  };

  selectGenreTab = async (genreName) => {
    await commons.click(this.genreTabItems[genreName]);
  };

  scrollToRail = async (railName, railStatus = true) => {
    await this.verifyRailPresent(railName, railStatus);
  };

  /**
   * Below function is used to check rail availability
   * 1) Scroll to the rail mentioned in the railName parameter
   * 2) Validate the rail presence based on the value passed to railStatus field
   *
   * @param {string} railName specifies the rail name to be validated
   * @param {string} railStatus as true or false
   */
  verifyRailPresent = async (railName, railStatus) => {
    if (railName === 'Continue Watching') {
      await this.verifyHomeHeroShowPlay();
      await commons.waitUntil(this.startWatching_btn, 20);
      await commons.clickBack();
      await commons.waitUntil(this.startWatching_txt, 20);
    }
    const railCheck = await this.scrollAndVerifyRailPresent(
      this.railsList[railName],
    );

    assert.deepStrictEqual(
      railCheck,
      railStatus,
      'Rail Availability Status Mismtach',
    );
  };

  /**
   * Below function is used to scroll to a
   * 1) Break the loop and return true value if rail is already displayed
   * 2) If rail is not displayed then scroll down on the home page upto 15 tries
   * 3) If the rail is still not displayed then return false else return true
   *
   * @param {railName} railName is the header text of the rail available on the app
   */
  scrollAndVerifyRailPresent = async (railName) => {
    for (let count = 0; count < 15; count++) {
      if (await commons.elementExists(railName, 5)) return true;
      await commons.scrollOnPageByPercentage('down', '50%');
    }
    const myListRailDisplayed = await commons.findElements(railName);

    return myListRailDisplayed.length > 0;
  };

  verifyHomeHeroShowPlay = async () => {
    await commons.waitUntil(this.startWatching_txt, 20);
    await commons.click(this.startWatching_txt, 20);
    if (await commons.elementExists(this.watchNow_btn)) {
      await commons.click(this.watchNow_btn, 20);
    } else {
      await commons.click(this.resume_btn, 20);
    }
    await videoPlayerPage.dragProgressBar('60');
    await commons.click(this.videoContainerView, 50);
    await commons.waitUntil(this.playerForward_btn);
    await commons.click(this.closePlayer_btn);
  };

  selectShow = async (index) => {
    if (await commons.elementExists(this.showTiles[index])) {
      await commons.click(this.showTiles[index], 30);
    } else {
      await commons.scrollOnPageByPercentage('down', '30%');
      await commons.click(this.showTiles[index], 30);
    }
  };

  verifyVideoPlayed = async () => {
    /* Show Rail playback validation */
    await this.selectShow('FirstTileOnFeaturedRail');
    await commons.click(this.firstEpisode_img);
    await videoPlayerPage.isVideoPlaying();
    await videoPlayerPage.closeShowPlayer();
    await commons.clickBack();
    if (!(await commons.elementExists(this.homeMenu_lbl))) {
      await commons.clickBack();
    }
    /* Video Rail playback validation */
    await this.scrollToRail('SerialKillers');
    await this.selectShow('FirstTileOnSerialKillersRail');
    await commons.click(this.firstEpisode_img);
    await videoPlayerPage.isVideoPlaying();
  };

  /**
   * Below method validates metadata on the tiles available on the mylist rail
   * showCount specifies the number of tiles on which metadata has to be validated
   *
   * @param {string} showCount specifies number of tiles to validate
   */
  verifyMyListRailMetadata = async (showCount) => {
    const thumNailImages = await commons.findElements(
      this.myListMetadata.thumbNail_img,
    );
    const showTitles = await commons.findElements(
      this.myListMetadata.showTitle_txt,
    );

    await commons.swipeOnElement(this.myListTilesSection, 'left', 5);
    const networkIcons = await commons.findElements(
      this.myListMetadata.networkIcon_img,
    );

    if (
      (thumNailImages.length && showTitles.length && networkIcons.length) ===
      parseInt(showCount, 10) + 1
    )
      return;
    throw new Error('My list show count not matching');
  };

  /**
   * Below method validates showTitles on the tiles available on the mylist rail
   * Mainly used to validate that shows available on the mylist rail matches with the shows user added to mylist
   *
   * @param {string} showCount specifies number of tiles to validate
   */
  validateTilesOnMyList = async (showCount) => {
    const showTitles = await commons.findElements(
      this.myListMetadata.showTitle_txt,
    );

    for (let i = 0; i < showCount; i++) {
      const showTitle = await commons.fetchAttributeData(showTitles[i], 'text');

      if (!showTitle.includes(this.showsList[showCount - (i + 1)])) {
        throw new Error('show title is not matching');
      }
    }
  };

  /**
   * Validates the order of the shows available on mylist rail
   * The most recent one added should be on top of the mylist rail
   */
  verifyMyListRailShowOrder = async () => {
    await commons.swipeOnElement(this.myListTilesSection, 'right', 5);
    await this.validateTilesOnMyList(3);
  };

  /**
   * below function removes a show from the mylist rail
   *
   * @param {string} showName specifies the name of the show to be removed from mylist
   */
  removeFromMyList = async (showName) => {
    const currentShowTitle = await commons.fetchAttributeData(
      this.myListMetadata.showTitle_txt,
      'text',
    );

    if (
      currentShowTitle.includes(
        testdataHelper.getContent(`searchPage.${showName}`),
      )
    ) {
      await commons.click(this.myListMetadata.showTitle_txt);
      await showDetailsPage.clickAddToFavourites();
      await commons.clickBack();
    }
    await this.verifyMyListRailMetadata(1);
    await this.validateTilesOnMyList(2);
  };

  /**
   * Below function will search for a show and will add it to mylist and returns back to search screen
   *
   * @param {number} showIndex specifies the tile number on search screen
   */
  searchAndAddShowToMyList = async (showIndex) => {
    await this.selectShow(showIndex);
    await showDetailsPage.clickAddToFavourites();
    await commons.clickBack();
  };

  /**
   * Below function will search and add a show to mylist
   * Validate the mylist available on the home page by scrolling through the home page
   * Validates the metadata available on the show tile in mylist rail
   */
  verifyMyListRailWhenOneShowAdded = async () => {
    await menuPage.navigateToPage('Search');
    await searchPage.searchShow(this.showsList[0]);
    await this.searchAndAddShowToMyList('FirstShowOnSearchResults');
    await commons.click(this.homeMenu_lbl);
    if (await commons.elementExists(this.enjoyingDiscovery_popup, 10)) {
      await commons.click(this.enjoyingDiscovery_popup);
    }
    await commons.waitUntil(this.homeIcon_txt);
    await commons.click(this.homeIcon_txt);
    await commons.scrollToElement(this.railsList['My List'], 'down', 10);
    await commons.scrollOnPageByPercentage('down', '40%');
    await this.verifyMyListRailMetadata(0);
    const currentShowTitle = await commons.fetchAttributeData(
      this.myListMetadata.showTitle_txt,
      'text',
    );

    if (currentShowTitle.includes(this.showsList[0])) return;
    throw new Error(`My List rail does not includes '${this.showsList[0]}'`);
  };

  /**
   * Below function is used to search a show and to add the show to mylist
   *
   * @param {number} showCount specifies number of shows to be added to mylist
   */
  addShowToMyList = async (showCount) => {
    await this.verifyMyListRailWhenOneShowAdded();
    await menuPage.navigateToPage('Search');
    for (let i = 1; i <= showCount; i++) {
      await searchPage.searchShow(this.showsList[i]);
      await this.searchAndAddShowToMyList('FirstShowOnSearchResults');
    }
    await commons.click(this.homeMenu_lbl);
    await commons.waitUntil(this.homeIcon_txt);
  };

  verifyContinueWatchingMetadata = async () => {
    const showDetails = ['thumbnailImage', 'progressBar'];

    await commons.scrollOnPageByPercentage('down', '30%');

    for (let i = 0; i < showDetails.length; i++) {
      await commons.waitUntil(this.metadataForShow[showDetails[i]]);
    }

    assert(
      (await commons.elementExists(this.cwFirstShow())) &&
        (await commons.elementExists(this.cwFirstEpisode())),
      `continue watching first show & episode names are not matching `,
    );
  };

  cwFirstShow = () => {
    let showName = this.getShowNameText();

    showName = this.getCustomLocator(this.cwRailFirstShow_txt, showName);

    return showName;
  };

  cwFirstEpisode = () => {
    let episodeName = this.getEpisodeNameText();

    episodeName = this.getCustomLocator(
      this.cwRailFirstEpisode_txt,
      episodeName,
    );

    return episodeName;
  };

  resumeAndPlayVideo = async () => {
    await commons.click(this.cwFirstShow());
    await videoPlayerPage.isVideoPlaying();
  };

  /**
   * Below function is used to validate CTAs on different pages
   *
   * @param {string}  userType the pages to be navigated for CTA validation with user type
   * @param {string}  pageName the pages to be navigated for CTA validation with user type
   */
  validateCTAonPages = async (userType, pageName) => {
    const pages = pageName.raw();

    for (let i = 0; i < pages.length; i++) {
      let performValidation = true;

      switch (pages[i].toString().toLowerCase()) {
        case 'home':
          await commons.waitUntil(this.focusedHomePage, 50);
          await commons.scrollToElement(
            this.showTiles.FirstTileOnFeaturedRail,
            'down',
          );
          await this.selectShow('FirstTileOnFeaturedRail');
          break;
        case 'search':
          await menuPage.navigateToPage('Search');
          await searchPage.searchText('multiContentShow');
          await searchPage.clickOnSearchResultsImage('multiContentShow');
          break;
        case 'sports':
          if (this.countryCode === 'gb') {
            await menuPage.navigateToPage('Sports');
            await this.scrollAndVerifyRailPresent(
              this.railsList.SportsDocumentaries,
            );
            await commons.scrollToElement(
              this.firstShowOnSportsDocumentaries,
              'down',
            );
            await this.selectShow('FirstShowOnSportsDocumentaries');
          } else {
            performValidation = false;
          }
          break;
        case 'browse':
          if (this.countryCode === 'us') {
            await menuPage.navigateToPage('Browse');
            await this.selectShow('FirstImageOnTrendingRail_img');
          } else {
            performValidation = false;
          }
          break;
        default:
      }

      if (performValidation) {
        await showDetailsPage.verifyShowLandingAnchorDetails();
        await this.validateCTAForUser(userType);
        await commons.clickBack();
        if (await commons.elementExists(this.homeMenu_lbl))
          await commons.click(this.homeMenu_lbl);
      }
    }
  };

  /**
   * Below function is used to validate CTAs for different users
   *
   * @param {string} userType the CTA validation for user type
   */
  validateCTAForUser = async (userType) => {
    if (userType.toLowerCase() === 'anonymous') {
      await commons.waitUntil(this.signUp_btn);
    } else {
      assert(
        (await commons.elementExists(this.watchNow_btn)) ||
          (await commons.elementExists(this.resume_btn)),
        `Watch Now or Resume button not found!`,
      );
    }
  };

  /**
   * The below function will scroll to network rail
   */
  scrollToNetworkRail = async () => {
    await commons.scrollToElement(this.network_img, 'down', 10);
  };

  /**
   * The below function will validate Network rail
   */
  validateNetworkRail = async () => {
    await commons.waitUntil(this.network_img);
  };

  /**
   * The below function will handel popup on Home screen
   */
  handleHomeScreenPopUp = async () => {
    if (await commons.elementExists(this.enjoyingDiscovery_popup)) {
      await commons.click(this.enjoyingDiscovery_popup);
    }
  };

  /**
   * The below function will verify the MyList Rail
   *
   * @param {boolean} isRailPresent - MyList Rail status true or false
   */
  verifyShowsInMyListRail = async (isRailPresent) => {
    await menuPage.navigateToPage('Home');
    await this.handleHomeScreenPopUp();
    await this.selectGenreTab['For You'];
    await this.verifyRailPresent('My List', isRailPresent);
  };

  selectNetwork = async (channelName) => {
    const networkRail = await commons.findElements(this.networkRail);
    let i = 3;

    while (i > 0) {
      await commons.swipeOnElement(networkRail[1], 'left', 2);
      i--;
    }

    await commons.click(this.networkChannelsList[channelName]);
  };

  /**
   * The below function will verify Mylist rail present on Home Page
   *
   * @param {string} railName - rail name
   * @param {boolean} RailStatus - Rail status true or false
   */
  verifyMyListRailOnHomePage = async (railName, RailStatus) => {
    await menuPage.navigateToPage('Home');
    await this.handleHomeScreenPopUp();
    await this.verifyRailPresent(railName, RailStatus);
  };

  /**
   * The below function will compare the shows on Mylist with two Profile's
   */
  verifyMyListShowAvailability = async () => {
    await profilePage.selectProfile('Standard');
    const currentTitleNameOnStandard = await commons.fetchAttributeData(
      this.focusedHomePage,
      'content-desc',
    );

    await myListPage.navigateToMyListScreen();
    const standardProfileShow = await commons.fetchAttributeData(
      this.showTitle_lbl,
      'text',
    );

    assert.strictEqual(
      currentTitleNameOnStandard,
      standardProfileShow,
      `show name does not includes title ' ${currentTitleNameOnStandard}'`,
    );
    if (this.countryCode !== 'us') await commons.clickBack();
    await profilePage.selectProfile('Kids');
    const currentTitleNameOnKids = await commons.fetchAttributeData(
      this.focusedHomePage,
      'content-desc',
    );

    await myListPage.navigateToMyListScreen();
    const kidsProfileShow = await commons.fetchAttributeData(
      this.showTitle_lbl,
      'text',
    );

    assert.strictEqual(
      currentTitleNameOnKids,
      kidsProfileShow,
      `show name does not includes title ' ${currentTitleNameOnKids}'`,
    );
    assert(standardProfileShow !== kidsProfileShow, `show title is duplicated`);
  };

  /**
   * The below function will add shows from home hero using Mylist Button
   */
  addShowToMylistFromHomeHero = async () => {
    await myListPage.navigateToMyListScreen();
    await myListPage.removeShowFromMyListPage();
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.addList_btn);
    await commons.click(this.addList_btn, 10);
  };

  /**
   * The below function will check mylist present on selected shows
   */
  verifyMyListCtaForShow = async () => {
    await commons.waitUntil(this.showTiles.FirstTileOnFeaturedRail, 10);
    await commons.click(this.showTiles.FirstTileOnFeaturedRail, 10);
    assert(
      !(await commons.elementExists(this.addList_btn)),
      `Mylist cta button displayed`,
    );
  };

  /**
   * The below function will navigate back to home page
   */
  navigateBacktoHomePage = async () => {
    let count = 5;

    while (
      count-- > 0 &&
      !(await commons.elementExists(menuPage.homeMenu_lbl, 10))
    ) {
      await commons.clickBack();
    }
    await commons.click(this.homeMenu_lbl);
    await this.handleHomeScreenPopUp();
    await commons.waitUntil(this.homeIcon_txt, 5);
    await commons.click(this.homeIcon_txt);
  };

  verifyJipContentPlayback = async (pageName) => {
    if (pageName === 'Home Page') {
      await commons.scrollDownMax(2);
      let count = 0;

      while (
        !(await commons.elementExists(this.jipRail_txt, 5)) &&
        count <= 6
      ) {
        await commons.scrollOnPageByPercentage('down', '50%');
        count++;
      }
      await commons.scrollToElement(this.jipShowName_img, 'down', '5');
      if (!(await commons.elementExists(this.jipShowName_img2))) {
        await commons.scrollToElement(this.jipShowName_img, 'up', '5');
      }
      await commons.click(this.jipShowName_img2);

      assert(
        await commons.elementExists(this.jipVideoTitle_lbl, 10),
        `JIP Content is not displayed`,
      );

      jipShowName = await commons.fetchAttributeData(
        this.jipVideoTitle_lbl,
        'text',
        10,
      );
      await this.verifyJIPVideoPlayback();
    } else if (pageName === 'Show Details Page') {
      await commons.clickBack();
      await menuPage.navigateToPage('Search');
      const newJipShowName = jipShowName.toString().replace(' Channel', '');

      await commons.sendText(this.search_txtBx, newJipShowName, 5);
      await commons.click(
        this.getCustomLocator(this.jipContentName_img, newJipShowName),
      );
      await commons.waitUntil(this.jipchannels_lbl, 20);
      await commons.click(this.jipchannels_lbl, 5);
      await commons.click(
        this.getCustomLocator(this.jipContentName_img, jipShowName),
      );
      await this.verifyJIPVideoPlayback();
    }
  };

  /**
   * This function will validate ageRating and Content on multiple Screens
   */

  verifyAgeRatingAndContentDescriptors = async (screensType) => {
    switch (screensType) {
      case 'Main Hero':
        break;

      case 'Show Details Page':
        await menuPage.navigateToPage('Search');
        await searchPage.searchText('multiContentShow');
        await searchPage.clickOnSearchResultsImage('multiContentShow');
        break;

      case 'Currently Playing Episode':
        await commons.click(this.startWatching_btn);
        break;

      case 'Next Episodes listed on Episode Landing Page':
        assert(
          await commons.elementExists(this.nextEpisodeRating),
          `Rating for the Next Episode is not displayed`,
        );
        commons.clickBack();
        break;

      case 'Episode Info Panel':
        await commons.click(this.startWatching_btn);
        break;

      default:
        throw new Error(
          'Actual screenType provided is not as per the expectations',
        );
    }

    if (screensType !== 'Next Episodes listed on Episode Landing Page') {
      assert(
        await commons.elementExists(this.rating, 30),
        `Rating for the show is not displayed`,
      );

      const currentRating = await commons.fetchAttributeData(
        this.rating,
        'text',
        10,
      );

      assert(
        testdataHelper.getContent('ratingList').includes(currentRating),
        `Rating is not as per rating standards`,
      );
    }
  };

  verifyJIPVideoPlayback = async () => {
    if (!(await commons.elementExists(this.playerForward_btn))) {
      await commons.click(this.videoContainerView);
      await commons.click(this.playerPause_btn);
    }
    for (let i = 0; i < this.videoPlayerElementsJIP.length; i++) {
      assert(
        await commons.elementExists(this.videoPlayerElementsJIP[i], 5),
        `${JSON.stringify(
          this.videoPlayerElementsJIP[i],
        )} is not displayed on JIP Playback`,
      );
    }
  };

  signOut = async () => {
    await menuPage.navigateToPage('Account');
    if (!(await commons.elementExists(this.signOut_btn))) {
      await menuPage.navigateToPage('Account');
    }
    await commons.click(this.signOut_btn);
    await commons.click(this.confirmSignOut_btn);
  };

  verifyHomepage = async () => {
    await commons.waitUntil(this.focusedHomePage, 10);
    await commons.elementExists(this.heroShowTitle, 10);
    await commons.elementExists(this.heroShowDescription, 10);
  };

  removedShowFromMylistFromHomeHero = async () => {
    await commons.click(this.homeMenu_lbl);
    await commons.waitUntil(this.addList_btn);
    await commons.click(this.addList_btn);
  };

  navigateToMyList = async (myListype) => {
    if (myListype === 'Rail') {
      await menuPage.navigateToPage('Home');
      await this.scrollToRail('My List');
    } else if (myListype === 'Page') {
      await myListPage.navigateToMyListScreen();
    }
  };
}
module.exports = HomePage;
