const assert = require('assert');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const MenuPage = require('./menuPage');
const HomePage = require('./homePage');

const commons = mobileActions;
const menuPage = new MenuPage();
const homePage = new HomePage();

class OnboardingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('onboardingPage', locator);
  }

  firstName_txtBx = this.#getSelectorData('firstName_txtBx');

  email_txtBx = this.#getSelectorData('email_txtBx');

  password_txtBx = this.#getSelectorData('password_txtBx');

  yearOfBirth_txtBx = this.#getSelectorData('yearOfBirth_txtBx');

  selectGender = this.#getSelectorData('selectGender');

  termsOfUse_chckBx = this.#getSelectorData('termsOfUse_chckBx');

  continue_btn = this.getElementByPage('signInPage', 'continue_btn');

  genderType = this.#getSelectorData('genderType');

  allSet_lbl = this.#getSelectorData('allSet_lbl');

  close_btn = this.#getSelectorData('close_btn');

  signOut_btn = this.#getSelectorData('signOut_btn');

  inactiveSub_lbl = this.#getSelectorData('inactiveSub_lbl');

  confirmSignOut_btn = this.#getSelectorData('confirmSignOut_btn');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  signInBack_btn = this.getElementByPage('signInPage', 'signInBack_btn');

  signUpOnVOD_btn = this.getElementByPage('accountPage', 'signUpOnVOD_btn');

  signInOnVOD_btn = this.getElementByPage('accountPage', 'signInOnVOD_btn');

  firstEpisode_img = this.getElementByPage('showPage', 'firstEpisode_img');

  upgradePass_lbl = this.getElementByPage('videoPlayerPage', 'upgradePass_lbl');

  viewPasses_lbl = this.getElementByPage('videoPlayerPage', 'viewPasses_lbl');

  watchNow_btn = this.getElementByPage('showPage', 'watchNow_btn');

  choosePlan_cta = this.getElementByPage('onboardingPage', 'choosePlan_cta');

  firstShowOnFreeEpisodes = this.getElementByPage(
    'homePage',
    'freeEpisode_img',
  );

  trendingRail_lbl = this.getElementByPage('homePage', 'trendingRail_lbl');

  firstTileOnTrendingRail_lbl = this.getElementByPage(
    'homePage',
    'firstTileOnTrendingRail_lbl',
  );

  sportsContentVOD = this.getElementByPage('sportsPage', 'sportsContentVOD');

  CTASignInList = [
    this.getElementByPage('signInPage', 'userName_txtBx'),
    this.getElementByPage('signInPage', 'password_txtBx'),
    this.getElementByPage('signInPage', 'continue_btn'),
  ];

  CTASignUpList = [
    this.getElementByPage('signInPage', 'registration_btn'),
    this.getElementByPage('signInPage', 'noPassAvailable_lbl'),
    this.getElementByPage('signInPage', 'chooseYourPass_lbl'),
  ];

  subscribeToWatchList = [
    this.getElementByPage('accountPage', 'signUpOnVOD_btn'),
    this.getElementByPage('accountPage', 'signInOnVOD_btn'),
    this.#getSelectorData('signInOrSignUp_lbl'),
  ];

  cancelSignOutCTA_btn = this.getElementByPage(
    'accountPage',
    'cancelSignOutCTA_btn',
  );

  selectCTAAndVerify = async (CTA) => {
    await this.selectCTA(CTA);
    await this.verifyCTAScreen(CTA);
  };

  /**
   *
   * @param {string} CTAType takes input  as either Sign in Or Sign Up CTA and selects that option
   */
  selectCTA = async (CTAType) => {
    const buttonsCTA = {
      'Sign In': this.signInOnVOD_btn,
      'Sign Up': this.signUpOnVOD_btn,
      'Watch Now': this.watchNow_btn,
      'Sign Out': this.signOut_btn,
      Cancel: this.cancelSignOutCTA_btn,
    };

    await commons.click(buttonsCTA[CTAType]);
  };

  /**
   *
   * @param {string} CTAType takes input as either Sign in Or Sign Up and clicks on it and verifies the elements related to that CTA action
   */

  verifyCTAScreen = async (CTAType) => {
    if (CTAType === 'Sign In') {
      for (let i = 0; i < this.CTASignInList.length; i++) {
        await commons.waitUntil(this.CTASignInList[i]);
      }
      await commons.click(this.signInBack_btn);
    } else {
      for (let i = 0; i < this.CTASignUpList.length; i++) {
        await commons.waitUntil(this.CTASignUpList[i]);
      }
    }
  };

  /**
   * This function is used to create a new account from register screen. This will generate random email, first name and reads password, DoB from testData.yml.
   */

  createFreeAccount = async () => {
    const chars = 'abcdefghijklmnopqrstuvwxyz1234567890';
    let email = '';
    let firstName = 'Automation';

    for (let i = 0; i < 15; i++) {
      email += chars[Math.floor(Math.random() * chars.length)];
      firstName += chars[Math.floor(Math.random() * chars.length)];
    }
    await commons.click(this.CTASignUpList[0]);
    await commons.waitUntil(this.firstName_txtBx);
    await commons.sendText(this.firstName_txtBx, firstName);
    await commons.sendText(this.email_txtBx, `${email}@disco.com`);
    await commons.sendText(
      this.password_txtBx,
      testdataHelper.getContent(`registrationPage.password`),
    );
    await commons.sendText(
      this.yearOfBirth_txtBx,
      testdataHelper.getContent(`registrationPage.yearOfBirth`),
    );
    await commons.click(this.selectGender);
    await commons.click(this.genderType);
    await commons.scrollOnPage('down');
    await commons.click(this.termsOfUse_chckBx);
    await commons.click(this.continue_btn);
    await commons.waitUntil(this.allSet_lbl);
    await commons.click(this.close_btn);
  };

  /**
   * The below function is used to sign out from the application
   */

  signOutFromApplication = async () => {
    await menuPage.navigateToPage('Account');
    if (!(await commons.elementExists(this.signOut_btn))) {
      await menuPage.navigateToPage('Account');
    }
    await commons.click(this.signOut_btn);
    await commons.click(this.confirmSignOut_btn);
    await commons.waitUntil(this.focusedHomePage);
  };

  verifyRegisterFreeCta = async () => {
    await commons.waitUntil(this.CTASignUpList[0]);
  };

  selectAndCompleteRegistration = async () => {
    await this.createFreeAccount();
  };

  navigateToPlanPickerPage = async () => {
    await menuPage.navigateToPage('Account');
    await commons.click(this.signUpOnVOD_btn);
    await commons.waitUntil(this.CTASignUpList[2]);
  };

  verifyAccountCreation = async () => {
    await menuPage.assertPage('Account');
    await menuPage.navigateToPage('Home');
  };

  /**
   *
   * @param {string} contentType - whether the content type if VOD/Linear/Live
   * @param {string} userType  - whether the user type is anonymous/lapsed
   * This function will navigate and select the shows/content based on the contentType & userType
   */

  navigateAndSelectContent = async (contentType, userType) => {
    await menuPage.navigateToPage('Home');
    if (
      contentType.includes('Entertainment VOD') &&
      userType.includes('anonymous')
    ) {
      let isDisplayed = await commons.elementExists(
        this.firstShowOnFreeEpisodes,
        2,
      );
      let count = 0;

      while (!isDisplayed && count <= 5) {
        await commons.scrollDownMax(2);
        isDisplayed = await commons.elementExists(
          this.firstShowOnFreeEpisodes,
          2,
        );
        count++;
      }
      await commons.scrollToElement(this.firstShowOnFreeEpisodes, 'up');
      await homePage.selectShow('FirstShowOnFreeEpisodes');
    } else if (contentType.includes('Entertainment Linear')) {
      await homePage.scrollToNetworkRail();
      await homePage.selectNetwork('TLC');
      await homePage.selectShow('FirstPopularShowOnTLC');
      await this.selectEpisode();
    } else if (
      contentType.includes('Entertainment VOD') &&
      userType.includes('lapsed')
    ) {
      let isDisplayed = await commons.elementExists(this.trendingRail_lbl, 2);
      let count = 0;

      while (!isDisplayed && count <= 5) {
        await commons.scrollDownMax();
        isDisplayed = await commons.elementExists(this.trendingRail_lbl, 2);
        count++;
      }
      await commons.scrollToElement(this.firstTileOnTrendingRail_lbl, 'down');
      await commons.click(this.firstTileOnTrendingRail_lbl);
      await this.selectEpisode();
    } else if (
      contentType.includes('Sports VOD') &&
      userType.includes('anonymous')
    ) {
      await menuPage.navigateToPage('Sports');
      await commons.scrollToElement(this.sportsContentVOD, 'down');
      await commons.click(this.sportsContentVOD);
    }
  };

  selectEpisode = async () => {
    await commons.waitUntil(this.firstEpisode_img);
    await commons.click(this.firstEpisode_img);
  };

  /**
   * The below function will validate the subscribe to watch screen whether the required elements are displayed
   */

  verifySubscribeToWatchScreen = async () => {
    for (let i = 0; i < this.subscribeToWatchList.length; i++) {
      assert(
        await commons.elementExists(this.subscribeToWatchList[i]),
        `${this.subscribeToWatchList[i]} is not displayed on the page`,
      );
    }
  };

  /**
   * The below function will validate the upgrade to watch screen whether the required elements are displayed
   */
  validateUpgradeToWatchScreen = async () => {
    assert(
      (await commons.elementExists(this.viewPasses_lbl)) &&
        (await commons.elementExists(this.upgradePass_lbl)),
      `View Passes is not showing on upgrade to watch screen`,
    );
  };

  /**
   * The below function will validate the Lapsed/Inactive Subscription screen whether the required elements are displayed
   */
  verifyInactiveSubscriptionScreen = async () => {
    assert(
      (await commons.elementExists(this.inactiveSub_lbl), 30) &&
        (await commons.elementExists(this.choosePlan_cta), 30),
      `Inactive Subscription Screen is not visible`,
    );
  };

  verifySuccessfulLogin = async () => {
    await commons.waitUntil(this.focusedHomePage);
  };
}

module.exports = OnboardingPage;
