const { SkipError } = require('@wbd/gqa-core/support/customErrors');
const assert = require('assert');

const { BasePage, skipReason, mobileActions } = require('./basePage');
const MenuPage = require('./menuPage');

const commons = mobileActions;
const menuPage = new MenuPage();
let newProfileName;
let profileCountBeforeDeletion = 0;
let pinProfileNameText;

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  manageProfiles_btn = this.#getSelectorData('manageProfiles_btn');

  manageProfiles_lbl = this.#getSelectorData('manageProfiles_lbl');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  account_img = this.getElementByPage('homePage', 'account_img');

  listOfAllProfiles = this.#getSelectorData('listOfAllProfiles');

  addProfile_btn = this.#getSelectorData('addProfile_btn');

  createProfileName_txtBx = this.#getSelectorData('createProfileName_txtBx');

  save_btn = this.#getSelectorData('save_btn');

  kidsProfileToggle_btn = this.#getSelectorData('kidsProfileToggle_btn');

  deleteProfile_btn = this.#getSelectorData('deleteProfile_btn');

  deleteProfilePopup_btn = this.#getSelectorData('deleteProfilePopup_btn');

  enjoyingDiscovery_popup = this.#getSelectorData('enjoyingDiscovery_popup');

  navigateBackFromProfile_Btn = this.#getSelectorData(
    'navigateBackFromProfile_Btn',
  );

  standardProfileName = this.#getSelectorData('standardProfileName');

  kidsProfileName = this.#getSelectorData('kidsProfileName');

  profileIconsView_img = this.#getSelectorData('profileIconsView_img');

  firstPinProfile_txtBx = this.#getSelectorData('firstPinProfile_txtBx');

  pinScreenCancel_btn = this.#getSelectorData('pinScreenCancel_btn');

  forgotPin_btn = this.#getSelectorData('forgotPin_btn');

  pinProfileName = this.#getSelectorData('pinProfile_txt');

  defaultProfileName = this.#getSelectorData('defaultProfile_txt');

  homeMenu_lbl = this.getElementByPage('menuPage', 'homeMenu_lbl');

  dynamicProfileName_lbl = this.#getSelectorData('dynamicProfileName_lbl');

  profileName_lbl = this.#getSelectorData('profileName_lbl');

  profileError_lbl = this.#getSelectorData('profileError_lbl');

  profileCancel_btn = this.#getSelectorData('profileCancel_btn');

  ok_btn = this.getElementByPage('preLaunchPage', 'ok_btn');

  whosWatching_lbl = this.#getSelectorData('whosWatching_lbl');

  profileLimitReached_lbl = this.#getSelectorData('profileLimitReached_lbl');

  ok_btn2 = this.#getSelectorData('ok_btn');

  #toggleKidsProfile = async (toggleStatus) => {
    if (toggleStatus.includes('ON')) {
      await commons.waitUntil(this.kidsProfileToggle_btn, 10);
      await commons.click(this.kidsProfileToggle_btn);
    }
  };

  /**
   * Post login, the below function clicks on Account menu and waits till manage profiles button is visible
   */
  openManageProfiles = async () => {
    if (await commons.elementExists(this.enjoyingDiscovery_popup, 5)) {
      await commons.click(this.enjoyingDiscovery_popup, 5);
    }
    if (!(await commons.elementExists(this.manageProfiles_btn))) {
      await menuPage.navigateToPage('Account');
    }
    await commons.waitUntil(this.manageProfiles_btn);
    await commons.click(this.manageProfiles_btn);
    await commons.waitUntil(this.manageProfiles_lbl);
  };

  verifyAddProfile = async () => {
    const isAddProfileDisplayed = await commons.elementExists(
      this.addProfile_btn,
      30,
    );

    return isAddProfileDisplayed;
  };

  verifyManageProfiles = async () => {
    assert(
      (await commons.elementExists(this.manageProfiles_lbl, 20)) &&
        (await commons.elementExists(this.addProfile_btn, 20)),
      'Not in Manage Profiles Screen',
    );
  };

  /**
   * Below function is used to create a new profile and it works in following way:
   * 1) Post login, it opens manage profiles screen and checks if Add profile option is available
   * 2) If Add profile is displayed, it adds a new profile prefixing with Standard, Kids
   * 3) If Add profile is not displayed, then it deletes any random profile and creates new profile
   *
   * @param {string} profileType as Standard, Kids
   */
  createNewProfile = async (profileType) => {
    await this.openManageProfiles();
    const isAddProfileDisplayed = await this.verifyAddProfile();
    // get timestamp (in millseconds)

    newProfileName = profileType + Math.floor(Date.now() / 1000);
    if (!isAddProfileDisplayed) {
      await this.deleteProfile('anyprofile');
      await commons.click(this.manageProfiles_btn, 10);
      await commons.waitUntil(this.manageProfiles_lbl, 15);
    }

    if (await commons.elementExists(this.addProfile_btn, 10)) {
      await commons.scrollToElement(this.addProfile_btn, 'down');
      await commons.click(this.addProfile_btn);
    }
    if (profileType.includes('Kids')) {
      await this.#toggleKidsProfile('ON');
    }
    await commons.sendText(this.createProfileName_txtBx, newProfileName);
    await commons.click(this.save_btn);
    if (await commons.elementExists(this.profileLimitReached_lbl, 10)) {
      await commons.click(this.ok_btn2);
      throw new SkipError(skipReason.maxProfilesLimitReached);
    }
    await commons.clickBack();
  };

  /**
   * Below function is used to create a new profile and calls createnewprofile function
   *
   * @param {string} profileType as Standard, Kids, pin
   */
  profileCreation = async (profileType) => {
    if (profileType === 'Standard' || profileType === 'Kids') {
      await this.createNewProfile(profileType);
      await this.selectProfile(newProfileName);
    }
    if (profileType === 'Pin') {
      await menuPage.navigateToPage('Account');
      pinProfileNameText = await commons.fetchAttributeData(
        this.pinProfileName,
        'Text',
      );
      await this.selectProfile(profileType);
      const profilePin = process.env.PROFILE_PIN.split(' ').map(Number);

      await commons.pressKeyCode(profilePin);
    }
  };

  /**
   *The below function 'if' condition will validate the PIN profile and bypass the deletion operation for the same.
   * 'else' condition will delete the Standard, Kids or any random profile.
   */

  deleteExistingProfile = async () => {
    if (pinProfileNameText === 'Pin') {
      await this.openManageProfiles();
      await commons.waitUntil(this.pinProfileName, 30);
    } else {
      await this.deleteProfile(newProfileName);
    }
  };

  /**
   *This delete profile function will -
   1) Delete existing profile that starts with Standard, Kids and if not found, any random profile, except default will be deleted. 
   2) Fetch count of all profiles
   3) If in Kids profile, it will switch to Default and then deletes created kids profile
   */

  deleteProfile = async (profileName) => {
    if (profileName === 'random') {
      await this.createNewProfile(profileName);
    }
    let profileNames = [];

    if (!(await commons.elementExists(this.manageProfiles_btn))) {
      if (profileName.includes('Kids')) {
        if (this.countryCode === 'us') {
          await this.selectProfile('Default');
        } else if (this.countryCode === 'gb') {
          await this.selectProfile('Default Profile');
        }
      }
      await this.openManageProfiles();
    } else {
      await commons.click(this.manageProfiles_btn);
    }

    profileNames = await this.getListOfProfiles();
    const arraySize = profileNames.length;

    if (arraySize === 0) {
      throw new SkipError(skipReason.noProfilesAvailableToDelete);
    }
    let requiredProfileName;

    if (profileNames.includes(profileName)) {
      requiredProfileName = this.getCustomLocator(
        this.dynamicProfileName_lbl,
        profileName,
      );
      await commons.waitUntil(requiredProfileName, 5);
      await commons.click(requiredProfileName, 5);
      await commons.click(this.deleteProfile_btn, 5);
      await commons.waitUntil(this.deleteProfilePopup_btn, 5);
      await commons.click(this.deleteProfilePopup_btn, 5);
      await this.verifyUserProfileDeleted();
    } else {
      for (let i = 0; i < arraySize; i++) {
        if (typeof profileNames[0] !== 'undefined') {
          requiredProfileName = this.getCustomLocator(
            this.dynamicProfileName_lbl,
            profileNames[0],
          );

          await commons.waitUntil(requiredProfileName, 5);
          await commons.click(requiredProfileName, 5);
          await commons.click(this.deleteProfile_btn, 5);
          await commons.waitUntil(this.deleteProfilePopup_btn, 5);
          await commons.click(this.deleteProfilePopup_btn, 5);
          if (await commons.elementExists(this.profileError_lbl, 5)) {
            await commons.click(this.ok_btn, 5);
            await commons.click(this.profileCancel_btn, 5);
          }

          if (await commons.elementExists(this.manageProfiles_btn, 5)) {
            await commons.click(this.manageProfiles_btn, 5);
          }

          profileNames = await this.getListOfProfiles();
          if (await commons.elementExists(this.profileError_lbl, 5)) {
            await commons.click(this.ok_btn, 5);
            await commons.click(this.profileCancel_btn, 5);
          }
        }
      }
      await this.verifyUserProfileDeleted();
    }
  };

  getListOfProfiles = async () => {
    let individualProfileName;
    const profileNames = [];
    const elements = await commons.findElements(this.listOfAllProfiles, 10);

    profileCountBeforeDeletion = await elements.length;
    for (let i = 0; i < profileCountBeforeDeletion; i++) {
      individualProfileName = await commons.fetchAttributeData(
        elements[i],
        'text',
      );
      let oldProfile = true;
      let existingProfileRandomTime;

      // Split the individualProfileName and then compare the timestamp.
      // if <10 minutes, then do not delete that profile, else mark that profile as old profile.
      if (
        !individualProfileName.includes('Default') &&
        individualProfileName !== 'Add Profile' &&
        individualProfileName !== 'My Profile'
      ) {
        existingProfileRandomTime = individualProfileName.match(/[a-z]+|\d+/gi);
        if (existingProfileRandomTime.length > 1) {
          if (
            Math.round(
              Math.abs(
                Date.now() / 1000 -
                  existingProfileRandomTime[
                    existingProfileRandomTime.length - 1
                  ],
              ) / 60,
            ) <= 10
          ) {
            oldProfile = false;
          }
        }
      }

      if (
        !individualProfileName.includes('Default') &&
        individualProfileName !== 'Add Profile' &&
        oldProfile &&
        individualProfileName !== 'My Profile'
      ) {
        profileNames.push(individualProfileName);
      }
      // For Oldprofile == false, we need to delete the newly created profile each time. Hence we need below condition
      if (individualProfileName === newProfileName) {
        profileNames.push(individualProfileName);
      }
    }
    return profileNames;
  };

  verifyUserProfileDeleted = async () => {
    assert(
      (await commons.elementExists(this.manageProfiles_lbl, 20)) ||
        (await commons.elementExists(this.whosWatching_lbl, 20)) ||
        (await commons.elementExists(this.manageProfiles_btn, 20)),
      `Deletion of profiles is not successful`,
    );
  };

  /**
   * Below function is used to check whether a profile is already existing in the profiles section:
   * 1) Post login, it navigates to account section
   * 2) If profile is displayed, it returns value as true
   * 3) If profile is not displayed, then it returns the value as false
   *
   *@param {string} profileName name of the profile to be checked on the app
   * @returns {boolean} availability status of the profile
   */
  checkProfileIfExists = async (profileName) => {
    const requiredProfileName = this.getCustomLocator(
      this.profileName_lbl,
      profileName,
    );
    const profileExists = await commons.elementExists(requiredProfileName);

    return profileExists;
  };

  /**
   *  Below function is used to check select a profile with name profileNames available in the profiles section:
   * 1) If profile is displayed, then the profile will be selected
   * 2) If profile is not displayed, then swipe left and right operations are done.
   * 3) If profile is not found even after the swipe operations then assertion error will be thrown
   *
   * @param {string} profileNames specifies the name of the profile to be selected
   */
  selectProfile = async (profileNames) => {
    let requiredProfileName;

    if (profileNames.length === 0) {
      return;
    }
    if (profileNames.length > 0 && !profileNames.includes('Anonymous')) {
      if (!(await commons.elementExists(this.manageProfiles_btn))) {
        await menuPage.navigateToPage('Account');
      }

      let profileCheck = await this.checkProfileIfExists(profileNames);

      requiredProfileName = this.getCustomLocator(
        this.profileName_lbl,
        profileNames,
      );
      while (!profileCheck) {
        await commons.swipeOnElement(this.profileIconsView_img, 'left', 5);
        await commons.swipeOnElement(this.profileIconsView_img, 'left', 5);
        profileCheck = await this.checkProfileIfExists(profileNames);
        if (!profileCheck) {
          await commons.swipeOnElement(this.profileIconsView_img, 'right', 5);
          await commons.swipeOnElement(this.profileIconsView_img, 'right', 5);
          assert(await commons.elementExists(requiredProfileName));
          profileCheck = true;
        }
      }
      await commons.click(requiredProfileName);
      if (profileNames === 'Pin') {
        await this.validatePinProfileScreen();
      } else {
        await commons.waitUntil(menuPage.pageFocused.Home, 30);
      }
    }
  };

  createNewProfileandSelect = async (profileName) => {
    await this.createNewProfile(profileName);
    await this.selectProfile(newProfileName);
  };

  pinScreenElements = [
    this.pinScreenCancel_btn,
    this.forgotPin_btn,
    this.firstPinProfile_txtBx,
  ];

  /**
   * The below function will take the values from 'pinScreenElements' Array and validate the screen.
   */
  validatePinProfileScreen = async () => {
    for (let i = 0; i < this.pinScreenElements.length; i++) {
      await commons.waitUntil(this.pinScreenElements[i]);
    }
  };

  adTechDeleteProfiles = async (profileName) => {
    let profileNames = [];

    if (!(await commons.elementExists(this.manageProfiles_btn))) {
      if (profileName.includes('Kids')) {
        await this.selectProfile('Default');
      }
      await this.openManageProfiles();
    } else {
      await commons.click(this.manageProfiles_btn);
    }

    profileNames = await this.getListOfProfiles();
    const arraySize = profileNames.length;

    if (arraySize !== 0) {
      let requiredProfileName;

      for (let i = 0; i < arraySize; i++) {
        if (typeof profileNames[i] !== 'undefined') {
          requiredProfileName = this.getCustomLocator(
            this.dynamicProfileName_lbl,
            profileNames[i],
          );

          if (profileNames[i].includes(profileName)) {
            await commons.waitUntil(requiredProfileName, 5);
            await commons.click(requiredProfileName, 5);
            await commons.click(this.deleteProfile_btn, 5);
            await commons.waitUntil(this.deleteProfilePopup_btn, 5);
            await commons.click(this.deleteProfilePopup_btn, 5);
            if (await commons.elementExists(this.profileError_lbl, 5)) {
              await commons.click(this.ok_btn, 5);
              await commons.click(this.profileCancel_btn, 5);
            }
          }
        }
        if (await commons.elementExists(this.manageProfiles_btn, 5)) {
          await commons.click(this.manageProfiles_btn, 5);
        }
      }
    }

    profileNames = await this.getListOfProfiles();
    if (await commons.elementExists(this.profileError_lbl, 5)) {
      await commons.click(this.ok_btn, 5);
      await commons.click(this.profileCancel_btn, 5);
    }
    await commons.waitUntil(this.navigateBackFromProfile_Btn);
    await commons.click(this.navigateBackFromProfile_Btn);
    await this.verifyUserProfileDeleted();
  };

  adTechCreateNewProfileandSelect = async (profileName) => {
    await this.adTechDeleteProfiles(profileName);
    await this.createNewProfile(profileName);
    await this.selectProfile(newProfileName);
  };
}

module.exports = ProfilePage;
