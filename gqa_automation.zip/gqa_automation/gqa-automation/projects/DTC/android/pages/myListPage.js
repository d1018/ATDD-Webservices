const assert = require('assert');

const { BasePage, mobileActions } = require('./basePage');
const MenuPage = require('./menuPage');
const SearchPage = require('./searchPage');
const BrowsePage = require('./browsePage');

const commons = mobileActions;
const menuPage = new MenuPage();
const searchPage = new SearchPage();
const browsePage = new BrowsePage();

class MyListPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myListPage', locator);
  }

  myListOnAccountScreen = this.#getSelectorData('myListOnAccountScreen');

  noSavedShow_txt = this.#getSelectorData('noSavedShow_txt');

  tapToSave_txt = this.#getSelectorData('tapToSave_txt');

  addList_btn = this.#getSelectorData('addList_btn');

  tap_txt = this.#getSelectorData('tap_txt');

  mylistScreenTitle = this.#getSelectorData('mylistScreenTitle');

  accountMenu_Btn = this.getElementByPage('menuPage', 'accountMenu_Btn');

  kebabIconOnMyListScreen = this.#getSelectorData('kebabIconOnMyListScreen');

  episodeDetailPanelClose_btn = this.#getSelectorData(
    'episodeDetailPanelClose_btn',
  );

  browserShows_btn = this.#getSelectorData('browserShows_btn');

  allBrowserScreen_txt = this.#getSelectorData('allBrowserScreen_txt');

  showInMyListPage = this.#getSelectorData('showInMyListPage');

  myListShowName_img = this.#getSelectorData('myListShowName_img');

  rating_txt = this.getElementByPage('homePage', 'rating_txt');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  myListRail_txt = this.getElementByPage('homePage', 'myListRail_txt');

  my_List_lbl = this.getElementByPage('homePage', 'myListRail_txt');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  firstTileOnFeaturedRail = this.getElementByPage(
    'homePage',
    'firstTileOnFeaturedRail_lbl',
  );

  myListShowTitle_txt = this.getElementByPage(
    'homePage',
    'myListShowTitle_txt',
  );

  showTitle_lbl = this.getElementByPage('searchPage', 'showTitle_lbl');

  homeMenu_lbl = this.getElementByPage('menuPage', 'homeMenu_lbl');

  /**
   * The below function will add show to mylist from the Mylist screen
   */
  addShowsToMylistFromBrowse = async () => {
    await commons.click(this.myListOnAccountScreen, 10);
    await commons.waitUntil(this.noSavedShow_txt);
    await commons.waitUntil(this.browserShows_btn);
    await commons.click(this.browserShows_btn, 30);
    const showListElement = await commons.findElements(
      this.allBrowserScreen_txt,
      10,
    );

    await commons.clickElement(showListElement[0]);
    await commons.click(this.addList_btn, 10);
    await commons.clickBack();
    if (!(await commons.elementExists(this.homeMenu_lbl))) {
      await commons.clickBack();
    }
  };

  /**
   * The below function will verify the MyList Rail
   *
   * @param {boolean} isRailPresent - MyList Rail status true or false
   */
  verifyShowsInMyList = async (isRailPresent) => {
    if (isRailPresent) {
      await this.navigateToMyListScreen();
      assert(
        (await commons.elementExists(this.showTitle_lbl), 30) &&
          (await commons.elementExists(this.kebabIconOnMyListScreen), 30),
        `No Show displayed in Mylist Screen`,
      );
      if (this.countryCode !== 'us') await commons.clickBack();
    } else {
      await this.navigateToMyListScreen();
      assert(
        (await commons.elementExists(this.noSavedShow_txt), 30),
        `Show displayed in Mylist Screen`,
      );
      if (this.countryCode !== 'us') await commons.clickBack();
    }
  };

  /**
   * The below function will verify the MyList cta on shows
   *
   */
  verifyMyListCtaForShow = async () => {
    await commons.click(this.firstTileOnFeaturedRail);
    if (await commons.elementExists(this.addList_btn)) {
      assert(
        await commons.elementExists(this.firstTileOnFeaturedRail),
        `MyList Cta button not displayed`,
      );
    } else {
      assert(
        !(await commons.elementExists(this.firstTileOnFeaturedRail)),
        `MyList Cta button displayed`,
      );
    }
  };

  /**
   * The below function will remove shows from Mylist screen
   */
  removeShowFromMyListPage = async () => {
    if (await commons.elementExists(this.myListOnAccountScreen)) {
      await commons.click(this.myListOnAccountScreen);
    }
    const totalShows = await commons.findElements(
      this.kebabIconOnMyListScreen,
      10,
    );

    for (let i = 0; i < totalShows.length; i++) {
      await commons.click(this.kebabIconOnMyListScreen, 10);
      await commons.click(this.addList_btn, 10);
      if (process.env.DEVICE === 'firetab') {
        await commons.clickBack();
      } else {
        await commons.click(this.episodeDetailPanelClose_btn, 10);
      }
      if (await commons.elementExists(this.noSavedShow_txt, 20)) {
        break;
      }
    }
    if (this.countryCode !== 'us') await commons.clickBack();
  };

  /**
   * The below function will navigate to Mylist screen
   */
  navigateToMyListScreen = async () => {
    await commons.click(this.myListOnAccountScreen);
  };

  addShowsToMyList = async (pageName) => {
    await this.navigateToMyListScreen();
    await this.removeShowFromMyListPage();
    await menuPage.navigateToPage(pageName);
    if (pageName === 'Home') {
      await commons.waitUntil(this.addList_btn);
      await commons.click(this.addList_btn, 10);
    } else if (pageName === 'Browse') {
      await browsePage.addRemoveShowFromBrowse();
    } else if (pageName === 'Search') {
      await searchPage.addShowsToMylistFromSearch();
    }
  };

  removeShowFromMyList = async (pageName) => {
    await menuPage.navigateToPage(pageName);
    if (pageName === 'Home') {
      await commons.waitUntil(this.addList_btn);
      await commons.click(this.addList_btn);
    } else if (pageName === 'Browse') {
      await browsePage.addRemoveShowFromBrowse();
      await this.navigateToMyListScreen();
      await this.waitUntil(this.noSavedShow_txt);
    } else if (pageName === 'Search') {
      await searchPage.removeShowsFromMyListFromSearch();
      await this.navigateToMyListScreen();
      await this.waitUntil(this.noSavedShow_txt);
    }
  };

  verifyAssetTile = async (myListype) => {
    await menuPage.navigateToPage('Home');

    const heroTitleElementText = await commons.fetchAttributeData(
      this.focusedHomePage,
      'Content-Desc',
    );

    if (myListype === 'Rail') {
      for (let count = 0; count < 15; count++) {
        if (await commons.elementExists(this.myListRail_txt, 5)) return true;
        await commons.scrollOnPageByPercentage('down', '50%');
      }
      await commons.scrollOnPageByPercentage('down', '10');
      const myListShowTitleInRail = await commons.fetchAttributeData(
        this.myListShowName_img,
        'Content-Desc',
      );

      assert.deepStrictEqual(
        heroTitleElementText,
        myListShowTitleInRail,
        'My List tiles mismatched',
      );
    } else if (myListype === 'Page') {
      await this.navigateToMyListScreen();
      const myListShowTitleInPage = await commons.fetchAttributeData(
        this.showInMyListPage,
        'Content-Desc',
      );

      assert.deepStrictEqual(
        heroTitleElementText,
        myListShowTitleInPage,
        'My List Tiles mismatched',
      );
    }
    return heroTitleElementText;
  };

  verifyMyListMetadata = async (myListype) => {
    if (myListype === 'Rail') {
      await commons.click(this.myListShowName_img);
      await commons.isDisplayed(this.addList_btn);
      await commons.isDisplayed(this.rating_txt);
    } else if (myListype === 'Page') {
      await commons.isDisplayed(this.mylistScreenTitle);
      await commons.isDisplayed(this.showInMyListPage);
    }
  };
}
module.exports = MyListPage;
