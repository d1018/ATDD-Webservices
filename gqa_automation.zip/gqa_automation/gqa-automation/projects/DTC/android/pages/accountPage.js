const assert = require('assert');
const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const MenuPage = require('./menuPage');
const ProfilePage = require('./profilePage');
const PlanPickerPage = require('./planPickerPage');
const OnboardingPage = require('./onboardingPage');
const SignInPage = require('./signInPage');

const commons = mobileActions;
const menuPage = new MenuPage();
const profilePage = new ProfilePage();
const planPickerPage = new PlanPickerPage();
const onboardingPage = new OnboardingPage();
const signPage = new SignInPage();

class AccountPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('accountPage', locator);
  }

  accountTitle_lbl = this.#getSelectorData('accountTitle_lbl');

  accountTab_lbl = this.#getSelectorData('accountTab_lbl');

  signIn_btn = this.#getSelectorData('signIn_btn');

  account_lbl = this.#getSelectorData('account_lbl');

  settings_lbl = this.#getSelectorData('settings_lbl');

  myList_lbl = this.getElementByPage('menuPage', 'myList_lbl');

  helpCentre_lbl = this.#getSelectorData('helpCentre_lbl');

  about_lbl = this.#getSelectorData('about_lbl');

  signOut_lbl = this.#getSelectorData('signOut_lbl');

  focusedManageAccountPage = this.#getSelectorData('focusedManageAccountPage');

  focusedSettingsPage = this.#getSelectorData('focusedSettingsPage');

  focusedMyListPage = this.getElementByPage('myListPage', 'focusedMyListPage');

  focusedHelpCentrePage = this.#getSelectorData('focusedHelpCentrePage');

  focusedAboutPage = this.#getSelectorData('focusedAccountPage');

  focusedSignOutPopUp = this.#getSelectorData('focusedSignOutPopUp');

  signInOnVOD_btn = this.#getSelectorData('signInOnVOD_btn');

  signUpOnVOD_btn = this.#getSelectorData('signUpOnVOD_btn');

  help_lbl = this.#getSelectorData('help_lbl');

  focusedHelpPage = this.#getSelectorData('help_lbl');

  choosePlan_cta = this.getElementByPage('onboardingPage', 'choosePlan_cta');

  manageProfiles_btn = this.getElementByPage(
    'profilePage',
    'manageProfiles_btn',
  );

  addProfile_btn = this.getElementByPage('profilePage', 'addProfile_btn');

  accountPageSubMenu = {
    Account: this.account_lbl,
    Settings: this.settings_lbl,
    'Help Centre': this.helpCentre_lbl,
    Help: this.help_lbl,
    About: this.about_lbl,
    'Sign Out': this.signOut_lbl,
  };

  accountSubNavigationPageFocused = {
    Account: this.focusedManageAccountPage,
    Settings: this.focusedSettingsPage,
    'Help Centre': this.focusedHelpCentrePage,
    Help: this.focusedHelpPage,
    About: this.focusedAboutPage,
    'Sign Out': this.focusedSignOutPopUp,
  };

  /**
   * On the basis of user type(Anonymous, Default, Kids), the below function will confirm Account Sub Menu list length accordingly.
   */

  getUserAccountMenuItems = (profileName) => {
    const accountType = {
      Anonymous: 'anonymousUserAccountItemList',
      Default: 'defaultUserAccountItemList',
      Kids: 'kidsUserAccountItemList',
    };

    return testdataHelper.getContent(`accountPage.${accountType[profileName]}`);
  };

  /**
   * The below function will verify the Account sub menu list based on user type (Anonymous, Default, Kids).
   */

  verifyAccountPage = async (profileName) => {

     if (profileName !== 'Anonymous') {
      await profilePage.selectProfile(profileName);
    }
    await menuPage.navigateToPage('Account');
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      await commons.waitUntil(this.accountPageSubMenu[accountMenuList[i]]);
    }
  };

  /**
   * The below function will navigate to the account sub menu pages and verify based on user type (Anonymous, Default, Kids).
   */

  verifyAccountSubNavigationPage = async (profileName) => {
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      await commons.click(await this.accountPageSubMenu[accountMenuList[i]]);
      await commons.waitUntil(
        await this.accountSubNavigationPageFocused[accountMenuList[i]],
      );
      if (accountMenuList[i] !== 'Account') {
        await commons.clickBack();
      }
    }
  };

  validateCtaAccountPage = async () => {
    await menuPage.navigateToPage('Account');
    await commons.waitUntil(this.signInOnVOD_btn);
    await commons.waitUntil(this.signUpOnVOD_btn);
  };

  selectAdultProfile = async () => {};

  selectCancelCTA = async () => {
    await onboardingPage.selectCTA('Cancel');
  };

  selectFooter = async (CTA) => {
    if (CTA === 'Sign Out') {
      await onboardingPage.selectCTA('Sign Out');
    }
  };

  verifySignOutPage = async () => {
    assert(
      (await commons.elementExists(this.manageProfiles_btn, 20)) &&
        (await commons.elementExists(this.help_lbl, 20)),
      'Not Back From Sign Out Screen Notification',
    );
  };

  selectManageProfileCTA = async () => {
    await profilePage.openManageProfiles();
  };

  validateInactiveSubscriptionPage = async () => {
    await onboardingPage.verifyInactiveSubscriptionScreen();
  };

  selectSubscribe = async () => {
    await signPage.reOpenApp();
    await signPage.loginToApplication('DTC_LAPSED');
    await commons.click(this.choosePlan_cta);
  };

  validateProductPickerPage = async () => {
    await planPickerPage.validatePlanPickerPage();
  };
}

module.exports = AccountPage;
