const assert = require('assert');
const { BasePage, mobileActions, testdataHelper } = require('./basePage');

const ShowDetailsPage = require('./showDetailsPage');
const VideoPlayerPage = require('./videoPlayerPage');

const commons = mobileActions;
const showDetailsPage = new ShowDetailsPage();
const videoPlayerPage = new VideoPlayerPage();
let searchText;
let firstOnSearch;

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  addList_btn = this.getElementByPage('myListPage', 'addList_btn');

  showName_lbl = this.getElementByPage('browsePage', 'showName_lbl');

  search_txtBx = this.#getSelectorData('search_txtBx');

  showTitle_lbl = this.#getSelectorData('showTitle_lbl');

  showImage_img = this.#getSelectorData('showImage_img');

  showNetworkIcon_img = this.#getSelectorData('showNetworkIcon_img');

  sportsThumbnail_img = this.#getSelectorData('sportsThumbnail_img');

  playList = this.getElementByPage('videoPlayerPage', 'playList');

  Episode_tab = this.#getSelectorData('showEpisodesTab');

  searchResultTabs = {
    Shows: this.#getSelectorData('showsTab_lbl'),
    Sports: this.#getSelectorData('showSportsTab_lbl'),
    Episodes: this.#getSelectorData('showEpisodesTab_lbl'),
    Extras: this.#getSelectorData('showExtrasTab_lbl'),
    Specials: this.#getSelectorData('showSpecialsTab_lbl'),
    Collections: this.#getSelectorData('showCollectionsTab_lbl'),
  };

  /**
   * This search method will be used when we have the key available on the geo-yml file instead of search text
   *
   * @param {string} text specifies the key value in the geo.yml file
   */
  searchText = async (text) => {
    const showName = testdataHelper.getContent(`searchPage.${text}`);

    searchText = showName;
    await commons.sendText(this.search_txtBx, searchText);
  };

  /**
   * This search method will be used when we have show name available
   *
   * @param {string} showName specifies the show to be searched
   */
  searchShow = async (showName) => {
    await commons.sendText(this.search_txtBx, showName);
  };

  verifyIfSearchResultsLoaded = async () => {
    await commons.elementExists(this.showTitle_lbl, 20);
    await commons.elementExists(this.showImage_img);
    await commons.elementExists(this.showNetworkIcon_img);
  };

  verifyResultsIncludeSearchText = async () => {
    const titleValue = await commons.fetchAttributeData(
      this.showTitle_lbl,
      'Text',
    );

    if (titleValue.includes(searchText)) return;
    throw new Error(`Search result does not includes '${searchText}'`);
  };

  getSearchResultsTab = () => {
    let expsearchResultTabs;
    let regionSpecificsearchResultTabs;

    expsearchResultTabs = [
      testdataHelper.getContent('searchPage.showsTab'),
      testdataHelper.getContent('searchPage.episodesTab'),
      testdataHelper.getContent('searchPage.extrasTab'),
    ];

    if (this.countryCode === 'gb') {
      regionSpecificsearchResultTabs = [
        testdataHelper.getContent('searchPage.showsTab'),
      ];
    } else if (this.countryCode === 'us') {
      regionSpecificsearchResultTabs = [
        testdataHelper.getContent('searchPage.specialsTab'),
        testdataHelper.getContent('searchPage.collectionsTab'),
      ];
    }
    expsearchResultTabs = expsearchResultTabs.concat(
      regionSpecificsearchResultTabs,
    );
    return expsearchResultTabs;
  };

  clickOnSearchResultsImage = async (searchResultTabName) => {
    if (
      searchResultTabName === testdataHelper.getContent('searchPage.sportsTab')
    ) {
      await commons.click(this.sportsThumbnail_img, 40);
    } else {
      await commons.click(this.showImage_img, 40);
    }
  };

  verifySearchTabsLanding = async (tabName) => {
    switch (tabName) {
      case 'Shows':
        await showDetailsPage.verifyShowLandingAnchorDetails();
        break;
      case 'Sports':
      case 'Episodes' || 'Extras' || 'Specials':
        await videoPlayerPage.verifyVideoPlayerAnchorDetails();
        break;
      case 'Collections':
        await commons.waitUntil(this.playList, 15);
        break;
      default:
        break;
    }
  };

  verifyLandingPageBasedOnContent = async () => {
    const searchTabs = this.getSearchResultsTab();

    for (let i = 0; i < searchTabs.length; i++) {
      await commons.waitUntil(this.searchResultTabs[searchTabs[i]]);
      await commons.click(this.searchResultTabs[searchTabs[i]]);
      await this.clickOnSearchResultsImage(searchTabs[i]);
      await this.verifySearchTabsLanding(searchTabs[i]);
      await commons.clickBack();
    }
  };

  verifySearchedContentAndItsLandingPage = async () => {
    await this.verifyResultsIncludeSearchText();
    await this.verifyLandingPageBasedOnContent();
  };

  navigateToEpisodeTab = async () => {
    await commons.waitUntil(this.Episode_tab, 15);
    await commons.click(this.Episode_tab, 15);
    assert(
      await commons.fetchAttributeData(this.Episode_tab, 'selected', 10),
      `Episode tab is not selected`,
    );
  };

  addShowsToMylistFromSearch = async () => {
    firstOnSearch = await commons.fetchAttributeData(this.showName_lbl, 'Text');
    await commons.click(this.showName_lbl);
    await commons.click(this.addList_btn);
    await commons.clickBack();
  };

  removeShowsFromMyListFromSearch = async () => {
    const firstOnSearchAfterAdd = await commons.fetchAttributeData(
      this.showName_lbl,
      'Text',
    );

    if (firstOnSearchAfterAdd === firstOnSearch) {
      await commons.click(this.showName_lbl);
      await commons.click(this.addList_btn);
      await commons.clickBack();
    } else {
      await this.searchShow(firstOnSearch);
      await commons.click(this.showName_lbl);
      await commons.click(this.addList_btn);
      await commons.clickBack();
    }
  };
}

module.exports = SearchPage;
