const AccountPage = require('./accountPage');
const HomePage = require('./homePage');
const SearchPage = require('./searchPage');
const SignInPage = require('./signInPage');
const MenuPage = require('./menuPage');
const PreLaunchPage = require('./prelaunchPage');
const ProfilePage = require('./profilePage');
const ShowDetailsPage = require('./showDetailsPage');
const VideoPlayerPage = require('./videoPlayerPage');
const SportsPage = require('./sportsPage');
const NetworkLandingPage = require('./networkLandingPage');
const EventDetailPage = require('./eventDetailPage');
const OnboardingPage = require('./onboardingPage');
const MyListPage = require('./myListPage');
const EpgTVGuidePage = require('./epgTVGuidePage');
const BrowsePage = require('./browsePage');
const WelcomePage = require('./welcomePage');
const UpNextPage = require('./upNextPage');
const PlanPickerPage = require('./planPickerPage');
const AdTechPage = require('./adTechPage');
const DeepLinkPage = require('./deepLinkPage');

const accountPage = new AccountPage();
const homePage = new HomePage();
const searchPage = new SearchPage();
const signInPage = new SignInPage();
const menuPage = new MenuPage();
const preLaunchPage = new PreLaunchPage();
const profilePage = new ProfilePage();
const showDetailsPage = new ShowDetailsPage();
const videoPlayerPage = new VideoPlayerPage();
const sportsPage = new SportsPage();
const networkLandingPage = new NetworkLandingPage();
const eventDetailPage = new EventDetailPage();
const onboardingPage = new OnboardingPage();
const myListPage = new MyListPage();
const epgTVGuidePage = new EpgTVGuidePage();
const browsePage = new BrowsePage();
const welcomePage = new WelcomePage();
const upNextPage = new UpNextPage();
const planPickerPage = new PlanPickerPage();
const adTechPage = new AdTechPage();
const deepLinkPage = new DeepLinkPage();

module.exports = {
  accountPage,
  homePage,
  searchPage,
  signInPage,
  menuPage,
  preLaunchPage,
  profilePage,
  showDetailsPage,
  videoPlayerPage,
  sportsPage,
  networkLandingPage,
  eventDetailPage,
  onboardingPage,
  myListPage,
  epgTVGuidePage,
  browsePage,
  welcomePage,
  upNextPage,
  planPickerPage,
  adTechPage,
  deepLinkPage,
};
