const assert = require('assert');

const { BasePage, mobileActions } = require('./basePage');
const MenuPage = require('./menuPage');

const commons = mobileActions;
const menuPage = new MenuPage();
let showName;

class BrowsePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('browsePage', locator);
  }

  addList_btn = this.getElementByPage('myListPage', 'addList_btn');

  myList_lbl = this.getElementByPage('menuPage', 'myList_lbl');

  browse_lbl = this.getElementByPage('menuPage', 'browse_lbl');

  browseShows_btn = this.getElementByPage('myListPage', 'browserShows_btn');

  accountMenu_lbl = this.getElementByPage('menuPage', 'accountMenu_lbl');

  focusedNetwork_lbl = this.#getSelectorData('focusedNetwork_lbl');

  focusedSubNav_lbl = this.#getSelectorData('focusedSubNav_lbl');

  networkLogoRail = this.#getSelectorData('networkLogoRail');

  showName_lbl = this.#getSelectorData('showName_lbl');

  subNav_lbl = this.#getSelectorData('subNav_lbl');

  networkIcon = this.#getSelectorData('networkIcon');

  networkImage = this.#getSelectorData('networkImage');

  showCard = this.#getSelectorData('showCard');

  watchNow_btn = this.getElementByPage('showPage', 'watchNow_btn');

  listIcon_btn = this.getElementByPage('showPage', 'listIcon_btn');

  subNav_lbl2 = this.#getSelectorData('subNav_lbl2');

  /**
   * The below function will select a page from global Navigation menu
   *
   * @param {string} pageType will select a page
   */

  selectPage = async (pageType) => {
    if (this.countryCode === 'us' && pageType === 'Browse') {
      await menuPage.navigateToPage(pageType);
    }
  };

  /**
   * The below function will verify items that are focussed by default in the networkRail and subNav menu
   *
   */

  verifyBrowsePage = async () => {
    await commons.waitUntil(this.focusedNetwork_lbl);
    assert(
      (await commons.fetchAttributeData(this.focusedNetwork_lbl, 'selected')) &&
        (await commons.fetchAttributeData(this.focusedSubNav_lbl, 'selected')),
      'All and Trending subNav are not slected bu default',
    );
    showName = await commons.fetchAttributeData(this.showName_lbl, 'text');
  };

  /**
   * The below function will select a network from the network rail in browse page and validate menu items that are focused by default
   *
   * @param {string} networkType will select a network
   */

  selectNetwork = async (networkType) => {
    if (this.countryCode === 'us' && networkType === 'Entertainment') {
      await commons.waitUntil(this.networkLogoRail);
      await commons.click(this.networkLogoRail);
      let firstShowNameInAll;

      firstShowNameInAll = await commons.fetchAttributeData(
        this.showName_lbl,
        'text',
      );
      let i = 0;

      while (i < 2 && firstShowNameInAll === showName) {
        firstShowNameInAll = await commons.fetchAttributeData(
          this.showName_lbl,
          'text',
        );
        i++;
      }
      await this.verifyShowOnSelectedNetwork();
      assert(
        (await commons.fetchAttributeData(
          this.focusedSubNav_lbl,
          'selected',
        )) &&
          (await commons.fetchAttributeData(this.subNav_lbl, 'displayed')) &&
          (await commons.fetchAttributeData(this.subNav_lbl2, 'displayed')),
        'Default subNav is not selected and other subNav options are not displayed',
      );
    }
  };

  /**
   * The below function will verify show on selected network
   */

  verifyShowOnSelectedNetwork = async () => {
    const actualShowName = await commons.fetchAttributeData(
      this.showName_lbl,
      'text',
    );

    assert.notEqual(
      showName,
      actualShowName,
      'Show not available on selected Network',
    );
  };

  /**
   * The below function will select a subNavigation menu item and validate the title , image and networkIcon are displayed
   *
   * @param {string} subNav will select subNav menu item
   */

  selectSubNav = async (subNav) => {
    if (this.countryCode === 'us' && subNav === 'first') {
      await commons.click(this.subNav_lbl);

      assert(
        (await commons.elementExists(this.showName_lbl, 5)) &&
          (await commons.elementExists(this.networkIcon, 5)) &&
          (await commons.elementExists(this.networkImage, 5)),
        `Show title, icon and image are not displayed`,
      );
    }
  };

  /**
   * The below function will open a show from Browse page and validate the CTAs
   */

  verifyShowCard = async () => {
    await commons.waitUntil(this.showCard);
    await commons.click(this.showCard);
    assert(
      (await commons.elementExists(this.watchNow_btn)) &&
        (await commons.elementExists(this.listIcon_btn)),
      'Watch Now button and Add to List Icon are not present',
    );
  };

  addRemoveShowFromBrowse = async () => {
    await commons.click(this.showName_lbl);
    await commons.waitUntil(this.addList_btn);
    await commons.click(this.addList_btn);
    await commons.clickBack();
  };
}

module.exports = BrowsePage;
