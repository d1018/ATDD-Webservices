const { BasePage } = require('./basePage');

class SportsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('sportsPage', locator);
  }

  sportsTab_lbl = this.#getSelectorData('sportsTab_lbl');

  scheduleTab_lbl = this.#getSelectorData('scheduleTab_lbl');

  allSportsTab_lbl = this.#getSelectorData('allSportsTab_lbl');

  upcomingRail_lbl = this.#getSelectorData('upcomingRail_lbl');
}
module.exports = SportsPage;
