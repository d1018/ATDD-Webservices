const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

let playerPositionAfterScrub = 0;

class VideoPlayerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('videoPlayerPage', locator);
  }

  playerContainer_img = this.#getSelectorData('playerContainer_img');

  playerBack_btn = this.#getSelectorData('playerBack_btn');

  playerCross_btn = this.#getSelectorData('playerCross_btn');

  videoTitle_txt = this.#getSelectorData('videoTitle_txt');

  fullScreenToggle_btn = this.#getSelectorData('fullScreenToggle_btn');

  playerRewind_btn = this.#getSelectorData('playerRewind_btn');

  playerForward_btn = this.#getSelectorData('playerForward_btn');

  playerPlay_btn = this.#getSelectorData('playerPlay_btn');

  playerPause_btn = this.#getSelectorData('playerPause_btn');

  playerProgress_bar = this.#getSelectorData('playerProgress_bar');

  videoContainerView = this.#getSelectorData('videoContainerView');

  closePlayer_btn = this.#getSelectorData('closePlayer_btn');

  navigateBack_btn = this.getElementByPage('showPage', 'navigateBack_btn');

  contentRatingTitle_lbl = this.#getSelectorData('contentRatingTitle_lbl');

  playerControls = this.#getSelectorData('playerControls');

  homeMenu_lbl = this.getElementByPage('menuPage', 'homeMenu_lbl');

  verifyVideoPlayerAnchorDetails = async () => {
    assert(
      (await commons.elementExists(this.videoContainerView, 20)) ||
        (await commons.elementExists(this.contentRatingTitle_lbl, 5)) ||
        (await commons.elementExists(this.playerPause_btn, 5)),
      `Video not initiated or Video took too much time to load`,
    );
  };

  playerScreenElement = [
    this.playerBack_btn,
    this.fullScreenToggle_btn,
    this.playerPlay_btn,
    this.videoTitle_txt,
  ];

  /**
   * The below function will validate the player screen once the video will start playing.
   */

  isVideoPlaying = async () => {
    if (process.env.DEVICE === 'firetab') {
      try {
        if (await commons.isDisplayed(this.contentRatingTitle_lbl, 50)) {
          await commons.click(this.videoContainerView, 10);
        }
      } catch (error) {
        await commons.click(this.videoContainerView, 10);
      }
      assert(
        (await commons.elementExists(this.playerControls, 60)) ||
          (await commons.isDisplayed(this.playerControls, 60)),
        `Video is not playing as the element is not displayed`,
      );
    } else {
      if (await commons.isDisplayed(this.contentRatingTitle_lbl, 70)) {
        await commons.click(this.videoContainerView, 10);
        if (await commons.elementExists(this.playerPause_btn, 10)) {
          await commons.click(this.playerPause_btn, 10);
        }
      } else {
        await commons.click(this.videoContainerView, 10);
      }
      for (let i = 0; i < this.playerScreenElement.length; i++) {
        await commons.waitUntil(this.playerScreenElement[i]);
      }
    }
  };

  closeShowPlayer = async () => {
    if (process.env.DEVICE === 'firetab') {
      await commons.clickBack();
    } else {
      await commons.click(this.playerBack_btn);
    }
  };

  videoPlayerPosition = async () => {
    await commons.elementExists(this.playerContainer_img, 20);
    await commons.click(this.videoContainerView, 50);
    await commons.waitUntil(this.playerProgress_bar);
    const currentPlayerPosition = await commons.fetchAttributeData(
      this.playerProgress_bar,
      'Content-Desc',
    );

    return currentPlayerPosition;
  };
  /**
   *
   * @param {*} percentage to scrub the % of player bar and this function also fetches the time line of the seek bar post scrub
   */

  scrubVideo = async (percentage) => {
    await this.dragProgressBar(percentage);
    if (percentage < '98') {
      playerPositionAfterScrub = await this.videoPlayerPosition();
      if (!(await commons.elementExists(this.closePlayer_btn))) {
        await commons.click(this.videoContainerView, 50);
        await commons.waitUntil(this.playerForward_btn);
      }
      await commons.click(this.closePlayer_btn);
      await commons.waitUntil(this.navigateBack_btn);
      await commons.click(this.navigateBack_btn);
    }
  };

  /**
   *
   * @param {*} percentageValue seeks the player from 00:00 to % of seek bar length. This function scrolls to coordinates by taking inputs as startX, startY, endX & endY positions.
   */
  dragProgressBar = async (percentageValue) => {
    let endXPosition;

    await commons.click(this.videoContainerView, 50);
    await commons.waitUntil(this.playerForward_btn);
    await commons.click(this.videoContainerView, 10);
    const progressBarLocation = await commons.getElementLocation(
      this.playerProgress_bar,
      5,
    );

    await commons.click(this.videoContainerView, 50);
    await commons.waitUntil(this.playerForward_btn);
    await commons.click(this.videoContainerView, 10);
    const progressBarDimensions = await commons.getElementSize(
      this.playerProgress_bar,
      5,
    );
    const startXPosition = progressBarLocation.startXValue;

    if (percentageValue < '98') {
      endXPosition =
        startXPosition + percentageValue * 0.01 * progressBarDimensions.width;
    } else {
      endXPosition =
        startXPosition +
        percentageValue * 0.01 * progressBarDimensions.width -
        7;
    }

    await commons.click(this.videoContainerView, 50);
    await commons.waitUntil(this.playerForward_btn);
    const startYPosition =
      progressBarLocation.startYValue + progressBarDimensions.height / 2;
    const endYPosition = startYPosition;

    await commons.scrollByCoordinates(
      startXPosition,
      startYPosition,
      endXPosition,
      endYPosition,
    );
  };
  /**
   * Validates time line by comparing before & after scrubbing video time-line
   */

  validateResumePoint = async () => {
    const playerPositionAOnResume = await this.videoPlayerPosition();

    assert(
      playerPositionAOnResume >= playerPositionAfterScrub,
      `Resume video is not successful as the player position on resume is ${playerPositionAOnResume} which is less than the player position after scrub ${playerPositionAfterScrub}`,
    );
    await commons.clickBack();
    if (!(await commons.elementExists(this.homeMenu_lbl, 10))) {
      await commons.clickBack();
    }
  };
}

module.exports = VideoPlayerPage;
