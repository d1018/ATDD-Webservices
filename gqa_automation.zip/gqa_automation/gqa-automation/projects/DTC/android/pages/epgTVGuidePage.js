const assert = require('assert');

const {
  BasePage,
  mobileActions,
  skipReason,
  customErrors,
} = require('./basePage');
const MenuPage = require('./menuPage');

const commons = mobileActions;
const { SkipError } = customErrors;
const menuPage = new MenuPage();

let isLiveDisplayed;

class EPGTVGuidePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('tvGuidePage', locator);
  }

  focusedTvGuidePage = this.#getSelectorData('focusedTvGuidePage');

  epgWeekDay = this.#getSelectorData('epgWeekDay');

  epgToday_lbl = this.#getSelectorData('epgToday_lbl');

  epgFirstDay_lbl = this.#getSelectorData('epgFirstDay_lbl');

  epgLastDayElements_lbl = this.#getSelectorData('epgLastDayElements_lbl');

  epgLastDay_lbl = this.#getSelectorData('epgLastDay_lbl');

  epgTimeOfDay = this.#getSelectorData('epgTimeOfDay');

  epgExactTimeOfDay = this.#getSelectorData('epgExactTimeOfDay');

  epgAllTimesOfDay = this.#getSelectorData('epgAllTimesOfDay');

  programPlayable_img = this.#getSelectorData('programPlayable_img');

  programPlayableTile_img = this.#getSelectorData('programPlayableTile_img');

  channelsList = this.#getSelectorData('channelsList');

  channelsEuroSports = this.#getSelectorData('channelsEuroSports');

  tvGuide_lbl = this.#getSelectorData('tvGuide_lbl');

  timeBarsList = this.#getSelectorData('timeBarsList');

  live_lbl = this.#getSelectorData('live_lbl');

  liveCard_img = this.#getSelectorData('liveCard_img');

  epgLiveContent = this.#getSelectorData('epgLiveContent');

  epgMetaData = [
    this.#getSelectorData('dayBarTabs'),
    this.#getSelectorData('timeBarTab'),
    this.#getSelectorData('epgAllTimesOfDay'),
    this.#getSelectorData('epgContent'),
    this.#getSelectorData('channelLogo'),
    this.#getSelectorData('programTime_txt'),
    this.#getSelectorData('programTitle_txt'),
    this.#getSelectorData('programSubtitle_txt'),
  ];

  epgLiveMetaData = [
    this.#getSelectorData('dayBarTabs'),
    this.#getSelectorData('timeBarTab'),
    this.#getSelectorData('epgAllTimesOfDay'),
    this.#getSelectorData('epgContent'),
    this.#getSelectorData('channelLogo'),
    this.#getSelectorData('programTime_txt'),
    this.#getSelectorData('programTitle_txt'),
    this.#getSelectorData('programSubtitle_txt'),
    this.#getSelectorData('epgLiveContent'),
  ];

  verifyDaySelection = async (day) => {
    const isSelected = await commons.fetchAttributeData(
      this.focusedTvGuidePage,
      'Selected',
    );
    const today = await commons.fetchAttributeData(this.epgToday_lbl, 'text');

    assert(
      isSelected && today === day,
      'Today is not selected by default on the EPG screen',
    );
  };

  /**
   *
   * @param {string} day  - takes input as below - if day passed is equal to
   *  previous -> clicks on immediate previous day from current day
   *  tomorrow -> clicks on immedicate next day from current day
   *  last or forward -> navigates to +7 days from current day
   *  backward -> navigates to -7 days from current day
   *
   * Additonally, this function also verifies the timeline bar is sticky. It verifies the current time       interval is in between past & future time.
   */
  selectDay = async (day) => {
    let i = 2;
    let previousDayOrFutureDay;
    let requiredDay;
    const today = this.getDay('today');

    if (day.toLowerCase() === 'previous') {
      previousDayOrFutureDay = this.getDay(day, 1);
      requiredDay = this.getCustomLocator(
        this.epgWeekDay,
        previousDayOrFutureDay,
      );
      await commons.click(requiredDay);
      await this.verifyTimeLineBar();
    } else if (day.toLowerCase() === 'tomorrow') {
      previousDayOrFutureDay = this.getDay(day, 1);
      requiredDay = this.getCustomLocator(
        this.epgWeekDay,
        previousDayOrFutureDay,
      );
      await commons.click(requiredDay);
      await this.verifyTimeLineBar();
    } else if (day.includes('last')) {
      while (i <= 7) {
        previousDayOrFutureDay = this.getDay(day, i);
        requiredDay = this.getCustomLocator(
          this.epgWeekDay,
          previousDayOrFutureDay,
        );
        await commons.click(requiredDay);
        if (i === 7) {
          assert(
            await commons.fetchAttributeData(requiredDay, 'selected'),
            `Last weekday is not selected`,
          );
          await this.verifyTimeLineBar();
        }

        i++;
      }
    } else if (day.includes('backward')) {
      while (i <= 14) {
        previousDayOrFutureDay = this.getDay(day, i);
        requiredDay = this.getCustomLocator(
          this.epgWeekDay,
          previousDayOrFutureDay,
        );
        if (previousDayOrFutureDay !== today) {
          await commons.click(requiredDay);
        }
        if (i === 14) {
          assert(
            await commons.fetchAttributeData(requiredDay, 'selected'),
            `Last weekday is not selected`,
          );
          await this.verifyTimeLineBar();
        }
        i++;
      }
    }
  };

  /**
   *
   * @param {string} timeZone  - Europe/London timezone or any desired region
   * @param {string} localeTimeString -en-GB or any locale as per region
   * This function verifies the current time is in between past & future time on EPG timeline bar
   */

  verifyTimeLineBar = async () => {
    const timeIntervals = [];
    const timeZone = 'Europe/London';
    const localeTimeString = 'en-GB';
    const timeBarList = await commons.findElements(this.timeBarsList);
    const timeBarCount = timeBarList.length;
    const currentTime = menuPage.getTimeZone(timeZone, localeTimeString);

    for (let i = 0; i < timeBarCount; i++) {
      timeIntervals.push(
        await commons.fetchAttributeData(timeBarList[i], 'text'),
      );
    }
    assert(
      currentTime > timeIntervals[0] && timeIntervals < timeIntervals[2],
      `Time bar intervals is not showing correct times as current time is ${currentTime} and actual time interval is ${timeIntervals}`,
    );
  };

  /**
   *
   * @param {string} direction - specify right or left based on navigation in EPG Day bar and pass that param to selectDay() function.
   */
  validateNavigationOnEPG = async (direction) => {
    const day = direction === 'right' ? 'backward' : 'forward';

    await this.selectDay(day);
  };

  verifyDisplayedContentMetaData = async (currentDate) => {
    if (
      currentDate === 'today' ||
      currentDate === 'tomorrow' ||
      currentDate === 'last'
    ) {
      for (let i = 0; i < this.epgMetaData.length; i++) {
        await commons.waitUntil(this.epgMetaData[i]);
      }
    } else if (currentDate === 'live' && isLiveDisplayed) {
      for (let i = 0; i < this.epgMetaData.length; i++) {
        await commons.waitUntil(this.epgLiveMetaData[i]);
      }
    }
  };

  /**
   *
   * @param {string} direction  - direction of scroll on EPG Guide - left or right based on requirement
   * @param {string} contentType  - Linear/Current broadcast Or Live content
   * @returns boolean if Live or Linear content is displayed
   */

  scrollLeftOrRight = async (direction, contentType) => {
    let i = 1;
    let isProgramPlayIconDisplayed = false;
    const channelList = await commons.findElements(this.channelsList);

    const channelLogo = this.getCustomLocator(
      this.channelsEuroSports,
      channelList.length,
    );

    while (i <= 5 && !isProgramPlayIconDisplayed) {
      await commons.swipeOnElement(channelLogo, direction, 5);

      if (contentType === 'Linear') {
        isProgramPlayIconDisplayed = await commons.elementExists(
          this.programPlayable_img,
        );
      } else {
        isProgramPlayIconDisplayed = await commons.elementExists(this.live_lbl);
      }
      i++;
    }
    return isProgramPlayIconDisplayed;
  };

  /**
   *
   * @returns true if Current broadcasting content is displayed
   */

  checkForLinearContent = async () => {
    let isProgramPlayIconDisplayed;
    let i = 1;

    isProgramPlayIconDisplayed = await commons.elementExists(
      this.programPlayable_img,
    );
    if (!isProgramPlayIconDisplayed) {
      while (!isProgramPlayIconDisplayed && i <= 3) {
        await commons.scrollOnPage('down');
        isProgramPlayIconDisplayed = await commons.elementExists(
          this.programPlayable_img,
        );
        i++;
      }
    }
    return isProgramPlayIconDisplayed;
  };

  checkForLiveContent = async () => {
    let isLiveIconDisplayed = false;
    let i = 1;

    if (!isLiveIconDisplayed) {
      while (!isLiveIconDisplayed && i <= 5) {
        await commons.scrollOnPageByPercentage('down', '40%');
        isLiveIconDisplayed = await commons.elementExists(this.live_lbl);
        i++;
      }
    }
    return isLiveIconDisplayed;
  };

  /**
   *
   * @param {string} requiredDay - takes input as below - if day passed is equal to
   *  previous -> clicks on immediate previous day from current day
   *  tomorrow -> clicks on immedicate next day from current day
   *  last or forward -> navigates to +7 days from current day
   *  backward -> navigates to -7 days from current day
   * @param {string} numberOfDays  - to increment or decrement the days based on required navigation to week days
   * @returns
   */

  getDay = (requiredDay, numberOfDays = 0) => {
    const date = new Date();
    const options = { weekday: 'short' };
    let requiredDate;
    let num;

    if (requiredDay.toLowerCase() === 'previous') {
      date.setDate(date.getDate() - 1);
      requiredDate = date.getDate();
      num = new Date().setDate(new Date().getDate() - 1);
    } else if (requiredDay.toLowerCase() === 'tomorrow') {
      date.setDate(date.getDate() + 1);
      requiredDate = date.getDate();
      num = new Date().setDate(new Date().getDate() + 1);
    } else if (requiredDay.includes('last')) {
      date.setDate(date.getDate() + numberOfDays);
      requiredDate = date.getDate();
      num = new Date().setDate(new Date().getDate() + numberOfDays);
    } else if (requiredDay.includes('backward')) {
      date.setDate(date.getDate() + 7 - numberOfDays);
      requiredDate = date.getDate();
      num = new Date().setDate(new Date().getDate() + 7 - numberOfDays);
    } else if (requiredDay === 'today') {
      date.setDate(date.getDate());
      requiredDate = date.getDate();
      num = new Date().setDate(new Date().getDate());
    }

    return `${new Intl.DateTimeFormat('en-US', options).format(
      num,
    )} ${requiredDate}`;
  };

  selectBroadcastingContent = async () => {
    let isPlayIconDisplayed = await this.checkForLinearContent();

    if (isPlayIconDisplayed === false) {
      isPlayIconDisplayed = await this.scrollLeftOrRight('right', 'Linear');
      if (isPlayIconDisplayed === false) {
        isPlayIconDisplayed = await this.scrollLeftOrRight('left', 'Linear');
      }
    }

    if (isPlayIconDisplayed) {
      await commons.click(this.programPlayableTile_img);
    }
  };

  /**
   *
   * @returns true if Live content is available; else it skips the scenario
   */

  isLiveContentDisplayed = async () => {
    isLiveDisplayed = await this.checkForLiveContent();
    if (!isLiveDisplayed) {
      isLiveDisplayed = await this.scrollLeftOrRight('right', 'Live');
    }

    if (!isLiveDisplayed) {
      throw new SkipError(skipReason.noLiveEvent);
    }
  };

  clickOnLiveContent = async () => {
    if (isLiveDisplayed) {
      await commons.click(this.liveCard_img);
    }
  };
}

module.exports = EPGTVGuidePage;
