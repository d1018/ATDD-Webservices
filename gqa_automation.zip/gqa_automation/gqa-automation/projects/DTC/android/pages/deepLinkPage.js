const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;
const prefix = 'discovery-plus://';
const deepLinkValues = {
  manageAccount: 'account',
  shows: 'shows',
  myList: 'my-list',
};

class DeepLinkPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('deepLinkPage', locator);
  }

  account_lbl = this.getElementByPage('accountPage', 'account_lbl');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  backgroundApp = async () => {
    /**
     * To Do : The following check should be moved to the login step to make sure login was successful
     */
    await commons.waitUntil(this.forYou_lbl, 30);
    await commons.backgroundApp(20);
  };

  verifyAppOpened = async () => {
    const context = await commons.currentContext();

    assert(context === 'NATIVE_APP', 'App is not in native context');
  };

  deepLinkTo = async (linkType) => {
    const url = `${prefix}${deepLinkValues[linkType]}`;

    await commons.deepLinkTo(url);
  };

  verifyAccountScreen = async () => {
    await commons.waitUntil(this.account_lbl, 30);
  };
}

module.exports = DeepLinkPage;
