const assert = require('assert');
const { BasePage, mobileActions } = require('./basePage');

const VideoPlayerPage = require('./videoPlayerPage');
const HomePage = require('./homePage');
const MenuPage = require('./menuPage');

const commons = mobileActions;
const videoPlayerPage = new VideoPlayerPage();
const homePage = new HomePage();
const menuPage = new MenuPage();

class NetworkLandingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('networkLandingPage', locator);
  }

  network_img = this.getElementByPage('homePage', 'network_img');

  networkRail = this.#getSelectorData('networkRail');

  signUp_btn = this.getElementByPage('signInPage', 'signUp_btn');

  showRail_lbl = this.getElementByPage('showPage', 'showRail_lbl');

  episodeRail_lbl = this.getElementByPage('showPage', 'episodeRail_lbl');

  watchNow_btn = this.getElementByPage('showPage', 'watchNow_btn');

  networkPagePlayerCta_txt = this.#getSelectorData('networkPagePlayerCta_txt');

  networkPagePlayerCta_btn = this.#getSelectorData('networkPagePlayerCta_btn');

  networkLogo = this.#getSelectorData('networkLogo');

  liveRail_lbl = this.getElementByPage('sportsPage', 'liveRail_lbl');

  liveRail = this.getElementByPage('sportsPage', 'liveRail');

  upcomingRail = this.getElementByPage('sportsPage', 'upcomingRail');

  upcomingRail_lbl = this.getElementByPage('sportsPage', 'upcomingRail_lbl');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  euroSports1Network_txt = this.getElementByPage(
    'sportsPage',
    'euroSports1Network_txt',
  );

  discoveryNetwork_txt = this.getElementByPage(
    'homePage',
    'discoveryNetwork_txt',
  );

  /**
   * The below function will validate the Network Landing Page CTA's
   */
  validateNetworkLandingPageCta = async () => {
    if (this.countryCode === 'gb') {
      if (await commons.elementExists(this.networkPagePlayerCta_txt)) {
        await commons.waitUntil(this.signUp_btn);
      } else if (await commons.elementExists(this.networkPagePlayerCta_btn)) {
        await commons.waitUntil(this.watchNow_btn);
      }
    }
  };

  entertainmeNtnetworkLandingPage = [
    this.showRail_lbl,
    this.episodeRail_lbl,
    this.network_img,
  ];

  /**
   * The below function will validate discovery network channel
   *
   * @returns {boolean} will return true or false
   */
  isEntertainmentNetworkDisplayed = async () => {
    const result = await commons.elementExists(this.discoveryNetwork_txt, 5);

    return result;
  };

  /**
   * The below fuction will select and  validate the Entertainment Network Landing Page
   */
  validateEntertainmentNetworkLandingPage = async () => {
    const networkRail = await commons.findElements(this.networkRail);
    let count = 0;

    while (!(await this.isEntertainmentNetworkDisplayed()) && count <= 5) {
      await commons.swipeOnElement(networkRail[1], 'left', 5);
      count++;
      if (await this.isEntertainmentNetworkDisplayed()) {
        break;
      }
    }
    await commons.click(this.discoveryNetwork_txt);
    await commons.waitUntil(this.networkLogo);
    await this.validateNetworkLandingPageCta();

    if (this.countryCode === 'us') {
      count = 1;
      let displayedCount = 0;

      for (let i = 0; i < this.entertainmeNtnetworkLandingPage.length; i++) {
        while (
          count <= 10 &&
          !(await commons.elementExists(
            this.entertainmeNtnetworkLandingPage[i],
            5,
          ))
        ) {
          await commons.scrollDownMax(count);
          count++;
        }
        if (
          await commons.elementExists(
            this.entertainmeNtnetworkLandingPage[i],
            5,
          )
        ) {
          ++displayedCount;
        }
      }
      assert(displayedCount === 3, `Entertainment rail are not displayed`);
    } else if (this.countryCode === 'gb') {
      for (let i = 0; i < this.entertainmeNtnetworkLandingPage.length; i++) {
        await commons.scrollToElement(
          this.entertainmeNtnetworkLandingPage[i],
          'down',
          5,
        );
        await commons.waitUntil(this.entertainmeNtnetworkLandingPage[i], 10);
        await commons.scrollOnPageByPercentage('up', '40%');
      }
    }
  };

  /**
   * The below function will validate sports network channel
   *
   * @returns {boolean} will return true or false
   */
  isSportsNetworkDisplayed = async () => {
    const result = await commons.elementExists(this.euroSports1Network_txt, 5);

    return result;
  };

  /**
   * The below function will validate the sports Network Landing Page
   */
  validateSportsNetworkLandingPage = async () => {
    const networkRail = await commons.findElements(this.networkRail);

    while (!(await this.isSportsNetworkDisplayed())) {
      await commons.swipeOnElement(networkRail[1], 'left', 5);
      if (await this.isSportsNetworkDisplayed()) {
        await commons.click(this.euroSports1Network_txt);
        break;
      }
    }
    await commons.waitUntil(this.networkLogo);
    await this.validateNetworkLandingPageCta();
    await commons.scrollOnPage('down');
    if (await commons.elementExists(this.liveRail_lbl)) {
      await commons.waitUntil(this.liveRail, 10);
    }
    await commons.waitUntil(this.upcomingRail, 10);
  };

  /**
   * The below function will switch on Entertainment and Sports network channel
   *
   * @param {*} network will select Entertainment and Sports Network
   */
  selectAndValidateNetworkLandingPage = async (network) => {
    if (network === 'Entertainment') {
      await this.validateEntertainmentNetworkLandingPage();
    } else if (network === 'Sports' && this.countryCode === 'gb') {
      await commons.clickBack();
      await this.validateSportsNetworkLandingPage();
    }
  };

  /**
   * Go to DiscoveryNetwork or E1Sports network
   *
   * @param {string} network -  Entertainment/Sports
   */
  goToSimulcastNetwork = async (network) => {
    const networkRail = await commons.findElements(this.networkRail);
    let count = 0;

    while (count <= 5) {
      if (network === 'Entertainment') {
        if (await commons.elementExists(this.discoveryNetwork_txt)) {
          await commons.click(this.discoveryNetwork_txt);
          break;
        }
      } else if (await commons.elementExists(this.euroSports1Network_txt)) {
        await commons.click(this.euroSports1Network_txt);
        break;
      }
      await commons.swipeOnElement(networkRail[1], 'left', 5);
      count++;
    }
  };

  /**
   * Verify Simulcast Users  (Verify CTA and Playback)
   *
   * @param {string} user -  Type of User - Anonymous and Fully-Entitled
   */
  validateSimulcastUsers = async (user) => {
    if (user === 'anonymous') {
      await commons.waitUntil(this.signUp_btn);
    } else {
      await commons.waitUntil(this.watchNow_btn);
      await commons.click(this.watchNow_btn);
      await videoPlayerPage.isVideoPlaying();
    }
    await commons.clickBack();
  };

  /**
   * Verify Simulcast Playback Page for Users
   *
   * @param {string} user -  Type of User (Anonymous or Fully Entitled)
   * @param {string} network - Entertainment - Discovery+, Sports - E1
   */
  verifySimulcastPlaybackOnNetworkPage = async (user, network) => {
    await this.goToSimulcastNetwork(network);
    await this.validateSimulcastUsers(user);
  };

  /**
   * The below function will validate Network Rail
   *
   * @returns {boolean} will return true or false
   */
  isNetworkRailDisplayed = async () => {
    const result = await commons.elementExists(this.network_img, 2);

    return result;
  };

  /**
   * The below function will verufy network rail for kids profile user
   */
  verifyNetworkRailForKidsProfile = async () => {
    let count = 0;

    while (!(await this.isNetworkRailDisplayed()) && count <= 12) {
      await commons.scrollOnPageByPercentage('down', '40%');
      count++;
    }

    if (this.countryCode === 'gb') {
      assert(
        !(await this.isNetworkRailDisplayed()),
        `A network rail is shown for the kids user`,
      );
    } else if (this.countryCode === 'us') {
      assert(
        await this.isNetworkRailDisplayed(),
        `A network rail is not shown for the kids user`,
      );
      await commons.click(this.discoveryNetwork_txt, 10);
      await commons.waitUntil(this.networkLogo, 10);
      await commons.clickBack();
      await menuPage.navigateToPage('Search');

      const isAdultContentDisplayed = await homePage.searchContent('adult');

      assert(
        !isAdultContentDisplayed,
        `A rated content is shown on the kids search screen`,
      );
    }
  };
}

module.exports = NetworkLandingPage;
