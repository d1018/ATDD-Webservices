const assert = require('assert');

const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class PlanPickerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('planPickerPage', locator);
  }

  chooseYourPlan = this.#getSelectorData('chooseYourPlan_txt');

  /**
   * Validate PlanPickerPage
   */
  validatePlanPickerPage = async () => {
    assert(
      await commons.elementExists(this.chooseYourPlan),
      `Choose your plan is not displayed`,
    );
  };
}
module.exports = PlanPickerPage;
