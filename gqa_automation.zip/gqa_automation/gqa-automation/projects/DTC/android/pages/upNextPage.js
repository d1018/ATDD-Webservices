const assert = require('assert');

const { BasePage, mobileActions } = require('./basePage');
const videoPlayerPage = require('./videoPlayerPage');

const commons = mobileActions;

class UpNextPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('upNextPage', locator);
  }

  upNext = this.#getSelectorData('upNext');

  upNextCloseLayout = this.#getSelectorData('upNextCloseLayout');

  upNextProgressBar = this.#getSelectorData('upNextProgressBar');

  playNextIcon = this.#getSelectorData('playNextIcon');

  upNextExtraLayout = this.#getSelectorData('upNextExtraLayout');

  /**
   * Verify Up Next Label on Up Next banner
   */
  verifyUpNextBanner = async () => {
    assert(
      await commons.elementExists(this.upNext),
      `upNext label is not displayed`,
    );
  };

  /**
   * Verify metadata on Up Next banner
   */
  verifyMetaDataForUpNext = async () => {
    assert(
      await commons.elementExists(this.upNextExtraLayout),
      `upNext attributes not displayed`,
    );
  };

  /**
   * Verify Next episode playing on video page
   */
  verifyNextEpisode = async () => {
    await videoPlayerPage.isVideoPlaying();
  };

  /**
   * Click on buttons on upNext banner
   *
   * @param {string} CTAType -  Play/Cancel
   */

  clickOnUpNextCTA = async (CTAType) => {
    const buttonsCTA = {
      cancel: this.upNextCloseLayout,
      Play: this.playNextIcon,
    };

    assert(
      await commons.elementExists(buttonsCTA[CTAType]),
      ` ${buttonsCTA[CTAType]} is not displayed`,
    );

    await commons.click(buttonsCTA[CTAType]);
  };

  /**
   * Verify current episode on video page
   */
  verifyScreenOnUpNextCancel = async () => {
    await videoPlayerPage.isVideoPlaying();
  };
}

module.exports = UpNextPage;
