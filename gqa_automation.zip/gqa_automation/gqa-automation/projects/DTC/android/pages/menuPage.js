const assert = require('assert');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');

const commons = mobileActions;

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  focusedMenuBar = this.#getSelectorData('focusedMenuBar');

  accountMenu_lbl = this.getElementByPage('homePage', 'account_img');

  searchMenu_lbl = this.#getSelectorData('searchMenu_lbl');

  homeMenu_lbl = this.#getSelectorData('homeMenu_lbl');

  downloadsMenu_lbl = this.#getSelectorData('downloadsMenu_lbl');

  signIn_btn = this.getElementByPage('accountPage', 'signIn_btn');

  sports_lbl = this.#getSelectorData('sports_lbl');

  tvGuide_lbl = this.#getSelectorData('tvGuide_lbl');

  myList_lbl = this.#getSelectorData('myList_lbl');

  browse_lbl = this.#getSelectorData('browse_lbl');

  focusedSearchPage = this.getElementByPage('searchPage', 'focusedSearchPage');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  focusedDownloadsPage = this.getElementByPage(
    'downloadsPage',
    'focusedDownloadsPage',
  );

  focusedSportsPage = this.getElementByPage('sportsPage', 'focusedSportsPage');

  focusedMyListPage = this.getElementByPage('myListPage', 'focusedMyListPage');

  focusedTvGuidePage = this.getElementByPage(
    'tvGuidePage',
    'focusedTvGuidePage',
  );

  focusedAccountPage = this.getElementByPage(
    'accountPage',
    'focusedAccountPage',
  );

  focusedBrowsePage = this.getElementByPage('browsePage', 'focusedBrowsePage');

  addList_btn = this.#getSelectorData('addList_btn');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  defaultProfileName = this.getElementByPage(
    'profilePage',
    'defaultProfile_txt',
  );

  kidsProfileName = this.getElementByPage('profilePage', 'kidsProfileName');

  signUpOnVOD_btn = this.getElementByPage('accountPage', 'signUpOnVOD_btn');

  manageProfiles_btn = this.getElementByPage(
    'profilePage',
    'manageProfiles_btn',
  );

  profileIcon = this.getElementByPage('profilePage', 'profileIcon');

  menuItem = {
    Home: this.homeMenu_lbl,
    'TV Guide': this.tvGuide_lbl,
    Sports: this.sports_lbl,
    Search: this.searchMenu_lbl,
    Account: this.accountMenu_lbl,
    Downloads: this.downloadsMenu_lbl,
    'My List': this.myList_lbl,
    Browse: this.browse_lbl,
    Profile: this.profileIcon,
  };

  pageFocused = {
    Home: this.focusedHomePage,
    'TV Guide': this.focusedTvGuidePage,
    Sports: this.focusedSportsPage,
    Search: this.focusedSearchPage,
    Account: this.focusedAccountPage,
    Downloads: this.focusedDownloadsPage,
    'My List': this.focusedMyListPage,
    Browse: this.focusedBrowsePage,
    Profile: this.focusedAccountPage,
  };

  userMenuItem = [];

  navigateToPage = async (pageValue) => {
    let retries = 2;

    if (this.countryCode === 'us' && this.returnBuildType() === 'release') {
      if (pageValue === 'Account') {
        /* eslint-disable no-param-reassign */
        pageValue = 'Profile';

        /**
         * The below snippet is required to scroll to top of the screen. Sometimes the screen will be scrolled half-way and we need to scroll top in order to click the Profile Icon.
         */
        if (!(await commons.elementExists(this.menuItem[pageValue], 10))) {
          await commons.click(this.homeMenu_lbl);
          if (!(await commons.elementExists(this.profileIcon))) {
            await commons.click(this.homeMenu_lbl);
          }
        }
      }
    }
    while (
      retries-- > 0 &&
      !(await commons.elementExists(this.pageFocused[pageValue], 30))
    ) {
      await commons.click(this.menuItem[pageValue], 30);
    }
  };

  accessGlobalNavigationMenu = async () => {
    await commons.waitUntil(this.focusedHomePage);
  };

  /**
   * The below function will confirm the user type(Anonymous, Default, Kids) and confirm the Menu list length accordingly.
   */

  getUserMenuItems = async () => {
    if (await commons.elementExists(this.signIn_btn)) {
      this.userMenuItem = testdataHelper.getContent(
        'menuNavigationPage.anonymousUserMenuList',
      );
    } else {
      this.userMenuItem = testdataHelper.getContent(
        'menuNavigationPage.defaultUserMenuList',
      );
    }
  };

  /**
   * The below function will verify the navigation menu list based on user type (Anonymous, Default, Kids).
   */
  verifyMenuList = async () => {
    await this.getUserMenuItems();
    for (let i = 0; i < this.userMenuItem.length; i++) {
      await commons.waitUntil(this.menuItem[this.userMenuItem[i]], 15);
    }
  };

  /**
   * The below function will verify the navigation menu pages based on user type (Anonymous, Default, Kids).
   */
  verifyGlobalNavigation = async () => {
    await this.getUserMenuItems();
    for (let i = 0; i < this.userMenuItem.length; i++) {
      await commons.click(this.menuItem[this.userMenuItem[i]]);
      await commons.waitUntil(this.pageFocused[this.userMenuItem[i]]);
    }
  };

  assertPage = async (pageValue) => {
    await commons.waitUntil(this.pageFocused[pageValue]);
  };

  /**
   * The below function will verify MYlist CTA button
   *
   * @param {string} CTA  the CTA validation
   * @param {boolean} assertValue CTA status true or false
   */
  isCTAPresent = async (CTA, assertValue) => {
    if (CTA === 'My List') {
      await commons.click(this.forYou_lbl);
      if (assertValue === true) {
        assert(
          await commons.elementExists(this.CtaButton[CTA]),
          `My list cta button not displayed`,
        );
      } else {
        assert(
          !(await commons.elementExists(this.CtaButton[CTA])),
          `Mylist cta button displayed`,
        );
      }
    } else if (CTA === 'Sign Up') {
      await commons.waitUntil(this.signUpOnVOD_btn);
      await commons.click(this.signUpOnVOD_btn);
    }
  };

  CtaButton = {
    'My List': this.#getSelectorData('addList_btn'),
  };

  getTimeZone = (timeZone, localeTimeString) => {
    const options = {
      timeZone,
      hour: '2-digit',
      minute: '2-digit',
    };
    const today = new Date();

    return `${today.toLocaleTimeString(localeTimeString, options).toString()}`;
  };

  isMenuOptionPresent = async (menuOption, AssertValue) => {
    if (AssertValue === true) {
      assert(
        await commons.elementExists(this.menuItem[menuOption]),
        `Menu Item List is not Displayed`,
      );
    } else {
      assert(
        !(await commons.elementExists(this.menuItem[menuOption])),
        `Menu Item List is Displayed`,
      );
    }
  };
}

module.exports = MenuPage;
