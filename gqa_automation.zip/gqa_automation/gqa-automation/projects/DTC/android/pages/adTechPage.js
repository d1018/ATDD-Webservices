const assert = require('assert');

const {
  BasePage,
  mobileActions,
  testdataHelper,
  analyticsValidationHelper,
} = require('./basePage');

const commons = mobileActions;

const MenuPage = require('./menuPage');
const SearchPage = require('./searchPage');
const VideoPlayerPage = require('./videoPlayerPage');

const menuPage = new MenuPage();
const searchPage = new SearchPage();
const videoPlayerPage = new VideoPlayerPage();

let showName = '';

class AdTechPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('adTechPage', locator);
  }

  Episodes = this.#getSelectorData('episodes');

  Clip_title = this.#getSelectorData('clip_title');

  search_txtBx = this.getElementByPage('searchPage', 'search_txtBx');

  ad_label = this.#getSelectorData('ad_label');

  ad_countdown = this.#getSelectorData('ad_countdown');

  playerPause_btn = this.getElementByPage('videoPlayerPage', 'playerPause_btn');

  contentRatingTitle_lbl = this.getElementByPage(
    'videoPlayerPage',
    'contentRatingTitle_lbl',
  );

  videoContainerView = this.getElementByPage(
    'videoPlayerPage',
    'videoContainerView',
  );

  searchShow = async (show) => {
    await menuPage.navigateToPage('Search');
    await this.searchText(show);
    await searchPage.navigateToEpisodeTab();
    const clip = await commons.fetchAttributeData(this.Clip_title, 'Text');

    assert(await clip.includes(showName), `Show not displayed`);
    await commons.waitUntil(this.Episodes, 30);
    await commons.click(this.Episodes, 30);
  };

  adPlaying = async () => {
    if (commons.isDisplayed(this.ad_label, 30)) {
      assert(await commons.isDisplayed(this.ad_countdown, 30), `Ad not played`);
    }
  };

  scrubOverMultipleMidroll = async () => {
    await videoPlayerPage.isVideoPlaying();
    await this.scrubVideo(90);
  };

  trackBeacons = async (beaconType, adType) => {
    await this.playAdFull();
    if (adType !== 'preroll') await this.scrubBack();
    const bsSessionId = commons.getBsSessionId();

    await analyticsValidationHelper.bsBeaconsValidation(
      bsSessionId,
      beaconType,
      adType,
    );
  };

  getShowName = async (show) => {
    showName = await testdataHelper.getContent(`adtech.${show}`);
    return showName;
  };

  searchText = async (show) => {
    const searchText = await this.getShowName(show);

    showName = searchText;
    await commons.sendText(this.search_txtBx, showName);
  };

  scrubVideo = async (percentage) => {
    await videoPlayerPage.dragProgressBar(percentage);
  };

  scrubBack = async () => {
    await videoPlayerPage.dragProgressBar(1);
  };

  playAdFull = async () => {
    await commons.waitUntil(this.contentRatingTitle_lbl, 120);
    assert(
      await commons.isDisplayed(this.contentRatingTitle_lbl, 120),
      `Ad not played entirely`,
    );
  };
}

module.exports = AdTechPage;
