const { BasePage, mobileActions } = require('./basePage');

const commons = mobileActions;

class PreLaunchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('preLaunchPage', locator);
  }

  privacyAccept_btn = this.#getSelectorData('privacyAccept_btn');

  ok_btn = this.#getSelectorData('ok_btn');

  goToOnboarding_btn = this.#getSelectorData('goToOnboarding_btn');

  browseContent_btn = this.#getSelectorData('browseContent_btn');

  async handlePopUps() {
    if (this.returnGeoLocation() === 'emea') {
      await commons.click(this.privacyAccept_btn);
      if (
        this.returnBuildType() === 'release' ||
        this.returnBuildType() === 'enterprise'
      ) {
        await commons.click(this.ok_btn);
      }
    }
  }

  async goToOnboardingScreen() {
    if (this.returnBuildType() === 'enterprise') {
      await commons.click(this.goToOnboarding_btn);
    }
  }

  async selectBrowseContentOption() {
    await commons.click(this.browseContent_btn);
  }
}

module.exports = PreLaunchPage;
