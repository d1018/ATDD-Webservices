const path = require('path');
const {
  mobileActions,
  customErrors,
  testdataHelper,
} = require('@wbd/gqa-core/support');

const ymlpath = path.resolve(__dirname);

const EnvBase = require('../../../support/env');

const { skipReason } = require('../../../support/skipReason');

const analyticsValidationHelper = require('../../../support/adtechSupport/analyticsValidationHelper');

let episodeNameText;

let showNameText;

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }

  getShowNameText() {
    return showNameText;
  }

  setShowNameText(showName) {
    showNameText = showName;
  }

  getEpisodeNameText() {
    return episodeNameText;
  }

  setEpisodeNameText(episodeName) {
    episodeNameText = episodeName;
  }

  returnBuildType = () => {
    const buildType = process.env.DTC_ANDROID_APP_PACKAGE.toLowerCase();

    if (buildType.includes(['enterprise'])) {
      return 'enterprise';
    }
    return 'release';
  };

  returnRandomNumber = (len) => {
    const randomNumber = Math.floor(Math.random() * len);

    return `${randomNumber}`;
  };
}

module.exports = {
  mobileActions,
  customErrors,
  skipReason,
  testdataHelper,
  BasePage,
  analyticsValidationHelper,
};
