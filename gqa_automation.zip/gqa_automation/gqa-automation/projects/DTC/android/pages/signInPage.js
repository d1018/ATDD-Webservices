const assert = require('assert');

const { BasePage, mobileActions, testdataHelper } = require('./basePage');
const PreLaunchPage = require('./prelaunchPage');
const MenuPage = require('./menuPage');
const { desiredAndroidCapabilities } = require('../capabilities/bsCaps');

const preLaunchPage = new PreLaunchPage();
const menuPage = new MenuPage();

const commons = mobileActions;

const serverURL = process.env.SERVER_URL
  ? process.env.SERVER_URL.toLowerCase()
  : '';

const localExecution = process.env.LOCAL_EXECUTION === 'true' || false;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  userName_txtBx = this.#getSelectorData('userName_txtBx');

  password_txtBx = this.#getSelectorData('password_txtBx');

  continue_btn = this.#getSelectorData('continue_btn');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  accountMenu_lbl = this.getElementByPage('menuPage', 'accountMenu_lbl');

  signIn_btn = this.getElementByPage('accountPage', 'signIn_btn');

  signIn_error_popup = this.getElementByPage(
    'accountPage',
    'focusedSignOutPopUp',
  );

  videoInfo_lbl = this.getElementByPage('videoPlayerPage', 'videoInfo_lbl');

  signInEmail = this.#getSelectorData('signInEmail');

  signInPassword = this.#getSelectorData('signInPassword');

  signIn_error_message = this.#getSelectorData('signIn_error_message');

  inactiveSub_lbl = this.getElementByPage('onboardingPage', 'inactiveSub_lbl');

  subscribe_btn = this.getElementByPage('welcomePage', 'subscribe_btn');

  whosWatching_lbl = this.getElementByPage('profilePage', 'whosWatching_lbl');

  defaultProfile_txt = this.getElementByPage(
    'profilePage',
    'defaultProfile_txt',
  );

  async openApp() {
    commons.driverInit(serverURL, localExecution);
    await commons.openApp(desiredAndroidCapabilities);
  }

  async enterCredentials(credentialType) {
    const credentials = this.setCredentials(credentialType);
    const { username } = credentials;
    const { password } = credentials;

    await commons.sendText(this.userName_txtBx, username);
    await commons.sendText(this.password_txtBx, password);
    await commons.click(this.continue_btn);
  }

  /*
   * setting credentials for enterCredentials method.
   * testing incorrect credentials test cases are added.
   */
  setCredentials = (credentialType) => {
    const invalidUsername = testdataHelper.getContent(
      'signInPage.incorrectUser',
    );
    const invalidPassword = testdataHelper.getContent(
      'signInPage.incorrectPass',
    );

    let username;
    let password;
    // for testing incorrect credentials test cases
    const correctCredentialType = 'DTC_VALID';

    switch (credentialType) {
      case 'InvalidPassword':
        username = process.env[`${correctCredentialType}_USERNAME`];
        password = invalidPassword;
        break;

      case 'InvalidUsername':
        username = invalidUsername;
        password = process.env[`${correctCredentialType}_PASSWORD`];
        break;

      case 'InvalidUserName_InvalidPassword':
        username = invalidUsername;
        password = invalidPassword;
        break;

      // default is to use credentials from .env
      default:
        username = process.env[`${credentialType}_USERNAME`];
        password = process.env[`${credentialType}_PASSWORD`];
        break;
    }

    return { username, password };
  };

  /**
   * Validate Sign In Page - Email & Password fields
   */
  validateSignInPage = async () => {
    assert(
      (await commons.elementExists(this.signInEmail)) &&
        (await commons.elementExists(this.signInPassword)),
      `Sign In Page required attributes are not displayed`,
    );
  };

  loginToApplication = async (userType) => {
    if (await commons.elementExists(this.videoInfo_lbl)) {
      await commons.click(this.signIn_btn);
      await this.enterCredentials(userType);
    } else {
      await preLaunchPage.handlePopUps();
      await preLaunchPage.goToOnboardingScreen();
      if (!userType.includes('anonymous')) {
        await this.#accessSignInScreen();
        await this.enterCredentials(userType);
        if (this.returnGeoLocation() === 'emea') {
          await menuPage.navigateToPage('Home');
        }
      } else if (
        this.returnBuildType() === 'enterprise' &&
        userType.includes('anonymous')
      ) {
        await preLaunchPage.selectBrowseContentOption();
      }
    }
  };

  async #accessSignInScreen() {
    if (this.returnGeoLocation() === 'america') {
      // click sign in
      await commons.click(this.signIn_btn);
    } else {
      if (!(await commons.elementExists(this.signIn_btn))) {
        await commons.click(this.accountMenu_lbl);
      }
      await commons.click(this.signIn_btn);
    }
    if (this.returnGeoLocation() === 'apac') {
      // clik on email
    }
    await commons.elementExists(this.userName_txtBx, 20);
  }

  verifySignOut = async () => {
    assert(
      (await commons.elementExists(this.subscribe_btn, 30)) &&
        (await commons.elementExists(this.signIn_btn, 30)),
      `Sign out is not successful`,
    );
  };

  async reOpenApp() {
    desiredAndroidCapabilities['browserstack.appStoreConfiguration'] = {
      username: process.env.PLAYSTORE_ACCOUNT_EMAIL,
      password: process.env.PLAYSTORE_ACCOUNT_PASSWORD,
    };
    const capability = {
      android: desiredAndroidCapabilities,
    }.android;

    await commons.closeApp();
    await commons.openApp(capability);
  }

  /*
   * to verify sign in error message:
   * Email or password entered incorrectly. Please try again.
   */
  verifyIncorrectCredentialError = async () => {
    await commons.waitUntil(this.signIn_error_popup);

    const errorMsg = await commons.fetchAttributeData(
      this.signIn_error_message,
      'text',
      10,
    );

    assert(
      testdataHelper
        .getContent('signInPage.invalid_entry_message')
        .includes(errorMsg),
      `Error Message is not as per rating standards`,
    );
  };

  navigateToSignInFromWelcomeScreen = async () => {
    await this.#accessSignInScreen();
  };
}

module.exports = SignInPage;
