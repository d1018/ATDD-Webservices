const assert = require('assert');

const { BasePage, remoteActions, testdataHelper } = require('./basePage');
const homePage = require('./homePage');

const commons = remoteActions;
const { VRC, PROP, COMP } = commons;

class NetworkLandingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('networkLandingPage', locator);
  }

  signUp_btn = this.#getSelectorData('signUp_btn');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  watchNow_cta = this.#getSelectorData('watchNow_cta');

  popularShows = this.#getSelectorData('popularShows');

  recommendedShows = this.#getSelectorData('recommendedShows');

  live = this.#getSelectorData('live');

  upcoming = this.#getSelectorData('upcoming');

  network_logo = this.#getSelectorData('network_logo');

  networkRail = this.getElementByPage('homePage', 'networkRail');

  NetworkRailChannel = this.getElementByPage('homePage', 'NetworkRailChannel');

  networkLogo_img = this.getElementByPage('homePage', 'networkLogo_img');

  focusedNetworkShow_tile = this.#getSelectorData('focusedShow_tile');

  focusedCustomNetwork_chnl = this.getElementByPage(
    'homePage',
    'focusedCustomNetworkChannel',
  );

  homeGenre_tab = this.getElementByPage('homePage', 'genreTab_lbl');

  showRatingCode_lbl = this.getElementByPage('showPage', 'showRatingCode_lbl');

  focusedShowTitle = this.getElementByPage('browsePage', 'focusedShowTitle');

  focusedShow_img = this.getElementByPage('browsePage', 'focusedShow_img');

  focusedShowNetworkLogo_img = this.getElementByPage(
    'browsePage',
    'focusedShowNetworkLogo_img',
  );

  navigateToSelectNetwork = async (networkType) => {
    let i = 20;

    while (i > 0) {
      const focusedNetwork = await commons.fetchAttributeData(
        this.NetworkRailChannel,
        PROP.TEXT_CONTENT,
      );

      if (focusedNetwork === networkType) {
        await commons.userAction(VRC.SELECT);
        break;
      } else {
        await commons.userAction(VRC.RIGHT);
        i -= 1;
      }
    }
  };

  validateEntertainmentNetwork = async () => {
    if (await this.getUserAnonymous()) await this.validateNetworkAnonymously();
    else await this.validateNetworkByValidUser();
  };

  verifyNetworkRailForKidsProfile = async () => {
    await commons.assertVisible(this.homeGenre_tab, 10);
    if (this.countryCode === 'gb') {
      assert(
        !(await homePage.isNetworkRailDisplayed()),
        `Fail: A network rail is shown for the UK kids user`,
      );
    } else if (this.countryCode === 'us') {
      assert(
        await homePage.isNetworkRailDisplayed(),
        `Fail:A network rail is not shown for the US kids user`,
      );
      await homePage.scrollToNetworkRail();
      await commons.navigateTo(
        this.getCustomLocator(this.focusedCustomNetwork_chnl, 'discovery'),
        'RIGHT',
      );
      await commons.navigateTo(this.focusedNetworkShow_tile, 'DOWN', 2, 5);
      await commons.assertVisible(this.showRatingCode_lbl, 10);
      await commons.assertProperty(
        this.showRatingCode_lbl,
        PROP.TEXT_CONTENT,
        'G',
        COMP.CONTAIN,
      );
    }
  };

  validateNetworkByValidUser = async () => {
    await commons.elementExists(this.watchNow_cta, 3);
    await commons.elementExists(this.network_logo, 3);
    await commons.elementExists(this.recommendedShows);
    await commons.elementExists(this.popularShows);
  };

  validateNetworkAnonymously = async () => {
    await commons.elementExists(this.signUp_btn, 3);
    await commons.elementExists(this.network_logo, 3);
    await commons.elementExists(this.popularShows);
  };

  validateSportsNetwork = async () => {
    if (await this.getUserAnonymous()) await this.validateSportsAnonymously();
    else await this.validateSportsByValidUser();
  };

  validateSportsAnonymously = async () => {
    await commons.elementExists(this.signUp_btn, 3);
    await commons.elementExists(this.live, 3);
    await commons.elementExists(this.upcoming, 3);
  };

  validateSportsByValidUser = async () => {
    await commons.elementExists(this.watchNow_cta, 3);
    await commons.elementExists(this.live, 3);
    await commons.elementExists(this.upcoming, 3);
  };

  validateEntertainmentNetworkLandingPage = async () => {
    const entertainmentChannel = testdataHelper.getContent(
      'networkPage.Entertainment',
    );

    await this.navigateToSelectNetwork(entertainmentChannel);
    await this.validateEntertainmentNetwork();
  };

  validateSportsNetworkLandingPage = async () => {
    const sportsChannel = testdataHelper.getContent('networkPage.Sports');

    await this.navigateToSelectNetwork(sportsChannel);
    await this.validateSportsNetwork();
  };

  /**
   * The below function will switch on Entertainment and Sports network channel
   *
   * @param {*} network will select Entertainment and Sports Network
   */
  selectAndValidateNetworkLandingPage = async (network) => {
    if (network === 'Entertainment') {
      await this.validateEntertainmentNetworkLandingPage();
    } else if (network === 'Sports' && this.returnGeoLocation() === 'emea') {
      await commons.tryUntil(this.forYou_lbl, VRC.BACK, 5, 1);
      await homePage.scrollToNetworkRail();
      await this.validateSportsNetworkLandingPage();
    }
  };

  selectNetworkLogo = async () => {
    await commons.assertExists(this.networkRail, 10);
    await commons.userAction(VRC.RIGHT, 3, 1);
    await commons.userAction(VRC.SELECT);
  };

  scrollToNetworkRailAndSelectNetwork = async () => {
    await commons.assertExists(this.focusedNetworkShow_tile, 10);
    await homePage.scrollToNetworkRail();
    await commons.userAction(VRC.RIGHT, 2, 1);
    await commons.userAction(VRC.SELECT);
  };

  validateNetworkPage = async () => {
    await commons.assertExists(this.focusedNetworkShow_tile, 10);
    assert(
      (await commons.elementExists(this.focusedShowTitle, 2)) &&
        (await commons.elementExists(this.focusedShow_img, 2)) &&
        (await commons.elementExists(this.focusedShowNetworkLogo_img, 2)),
      `Show Title, Network Logo and Image are not displayed`,
    );
  };
}

module.exports = new NetworkLandingPage();
