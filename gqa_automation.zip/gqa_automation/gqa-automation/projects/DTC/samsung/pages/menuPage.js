const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const { VRC, PROP } = commons;

let menu = [];

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  menuListLoggedIn = testdataHelper.getContent('menuItemSamsung.loggedInMenu');

  menuListLoggedOut = testdataHelper.getContent(
    'menuItemSamsung.loggedOutMenu',
  );

  kidsMenuList = testdataHelper.getContent('menuItemSamsung.kidsMenu');

  tvGuideMenuListItem = this.#getSelectorData('tvGuideMenuListItem');

  focusedMenuBar = this.#getSelectorData('focusedMenuBar');

  unfocusedMenuBar = this.#getSelectorData('unfocusedMenuBar');

  accountMenu_lbl = this.#getSelectorData('accountMenu_lbl');

  searchMenu_lbl = this.#getSelectorData('searchMenu_lbl');

  homeMenu_lbl = this.#getSelectorData('homeMenu_lbl');

  epgMenu_lbl = this.#getSelectorData('epgMenu_lbl');

  sports_lbl = this.#getSelectorData('sportsMenu_lbl');

  myList_lbl = this.#getSelectorData('myListMenu_lbl');

  shows_lbl = this.#getSelectorData('showsMenu_lbl');

  browseMenu_lbl = this.#getSelectorData('browseMenu_lbl');

  focusedSearchPage = this.getElementByPage('searchPage', 'focusedSearchPage');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  focusedAccountPage = this.getElementByPage(
    'accountPage',
    'focusedAccountPage',
  );

  focusedShowDetailPage = this.getElementByPage(
    'showPage',
    'focusedShowDetailPage',
  );

  focusedBrowsePage = this.getElementByPage('browsePage', 'focusedBrowsePage');

  focusedSportsPage = this.getElementByPage('sportsPage', 'focusedSportsPage');

  focusedMyListPage = this.getElementByPage('myListPage', 'focusedMyListPage');

  focusedTvGuidePage = this.getElementByPage(
    'tvGuidePage',
    'focusedTvGuidePage',
  );

  myListMenuListItem = this.#getSelectorData('myListMenuListItem');

  manageProfiles_lbl = this.#getSelectorData('manageProfiles_lbl');

  focusedManageProfiles_lbl = this.#getSelectorData(
    'focusedManageProfiles_lbl',
  );

  focusedHomeMenu_lbl = this.#getSelectorData('focusedHomeMenu_lbl');

  focusedEpgMenu_lbl = this.#getSelectorData('focusedEpgMenu_lbl');

  focusedAccountMenu_lbl = this.#getSelectorData('focusedAccountMenu_lbl');

  focusedSportsMenu_lbl = this.#getSelectorData('focusedSportsMenu_lbl');

  focusedShowsMenu_lbl = this.#getSelectorData('focusedShowsMenu_lbl');

  focusedSearchMenu_lbl = this.#getSelectorData('focusedSearchMenu_lbl');

  focusedMyListMenu_lbl = this.#getSelectorData('focusedMyListMenu_lbl');

  cancel_btn = this.getElementByPage('exitPage', 'cancel_btn');

  exit_btn = this.getElementByPage('exitPage', 'exit_btn');

  exitPageTitle = this.getElementByPage('exitPage', 'exitPageTitle');

  focusedCancel_btn = this.getElementByPage('exitPage', 'focusedCancel_btn');

  focusedExit_btn = this.getElementByPage('exitPage', 'focusedExit_btn');

  /**
   * The below function will return true if the user can see mylist
   */
  loggedIn = async () => {
    const result = await commons.elementExists(this.myListMenuListItem);

    return result;
  };

  menuItem = {
    Home: this.homeMenu_lbl,
    'TV Guide': this.epgMenu_lbl,
    Sports: this.sports_lbl,
    Search: this.searchMenu_lbl,
    Account: this.accountMenu_lbl,
    'My List': this.myList_lbl,
    Shows: this.shows_lbl,
    Browse: this.browseMenu_lbl,
  };

  focusedMenuItem = this.#getSelectorData('focusedMenuItem');

  pageFocused = {
    Home: this.focusedHomePage,
    Sports: this.focusedSportsPage,
    Shows: this.focusedShowDetailPage,
    'TV Guide': this.focusedTvGuidePage,
    'My List': this.focusedMyListPage,
    Search: this.focusedSearchPage,
    Account: this.focusedAccountPage,
    Browse: this.focusedBrowsePage,
  };

  openMenu = async () => {
    await commons.tryUntil(this.focusedMenuBar, VRC.BACK, 10, 1);
  };

  closeMenu = async () => {
    await commons.tryUntil(this.unfocusedMenuBar, VRC.RIGHT, 3, 1);
  };

  getMenuList = async () => {
    if ((await this.returnGeoLocation()) === 'america') {
      if (this.getUserTypeKids()) return this.kidsMenuList;
      return this.menuListLoggedIn;
    }
    if ((await this.returnGeoLocation()) === 'emea') {
      if (await this.loggedIn()) {
        if (await this.noTvGuide()) {
          return this.kidsMenuList;
        }
        return this.menuListLoggedIn;
      }
      return this.menuListLoggedOut;
    }
    return [];
  };

  navigateToPage = async (pageValue) => {
    await this.openMenu();

    if (await commons.elementExists(this.focusedManageProfiles_lbl, 3))
      await commons.tryUntil(this.focusedHomeMenu_lbl, VRC.DOWN, 2, 1);

    const menuItemText = await commons.fetchAttributeData(
      this.focusedMenuItem,
      PROP.TEXT_CONTENT,
    );

    menu = await this.getMenuList();

    const focusedIndex = menu.indexOf(menuItemText);
    const moveToIndex = menu.indexOf(pageValue);
    const difference = focusedIndex - moveToIndex;

    if (difference < 0)
      await commons.userAction(VRC.DOWN, Math.abs(difference), 1);

    if (difference > 0) await commons.userAction(VRC.UP, difference, 1);

    await commons.userAction(VRC.SELECT, 1);
    await commons.assertExists(this.pageFocused[pageValue], 20);
  };

  accessGlobalNavigationMenu = async () => {
    await commons.waitUntil(this.focusedHomePage);
    await this.openMenu();
  };

  /**
   * The below function will verify the navigation menu list based on user type (Anonymous, Default, Kids).
   */
  verifyMenuList = async () => {
    await this.openMenu();
    const menuList = await this.getMenuList();

    for (let i = 0; i < menuList.length; i++) {
      await commons.assertExists(this.menuItem[menuList[i]]);
      await commons.userAction(VRC.DOWN);
    }
    await commons.tryUntil(this.focusedHomeMenu_lbl, VRC.UP, 10, 1);
    await this.closeMenu();
  };

  /**
   * The below function will verify the navigation menu pages based on user type (Anonymous, Default, Kids).
   */
  verifyGlobalNavigation = async () => {
    await this.openMenu();
    const menuList = await this.getMenuList();

    for (let i = 0; i < menuList.length; i++) {
      await this.navigateToPage(menuList[i]);
    }
  };

  assertPage = async (pageValue) => {
    await commons.waitUntil(this.pageFocused[pageValue]);
  };

  verifyExitConfirmation = async () => {
    await commons.tryUntil(this.exitPageTitle, VRC.BACK, 4, 5);
    await this.assertSelectorArray(this.exit_btn, this.cancel_btn);
  };

  verifyAppBehavior = async (ctaType) => {
    if (ctaType === 'Back') {
      await commons.userAction(VRC.BACK);
      await commons.assertExists(this.focusedHomePage, 5);
    } else if (ctaType === 'Cancel') {
      await commons.tryUntil(this.exitPageTitle, VRC.BACK, 5, 3);
      await commons.assertExists(this.focusedCancel_btn, 5);
      await commons.userAction(VRC.SELECT);
      await commons.assertExists(this.focusedHomePage, 5);
    } else {
      await commons.tryUntil(this.exitPageTitle, VRC.BACK, 5, 3);
      await commons.userAction(VRC.UP);
      await commons.assertExists(this.focusedExit_btn, 5);
      await commons.userAction(VRC.SELECT);
      if ((await commons.isAppExited(20)) === false) {
        throw new Error(
          'Application has not exited succesfully which is not expected',
        );
      }
    }
  };
}
module.exports = new MenuPage();
