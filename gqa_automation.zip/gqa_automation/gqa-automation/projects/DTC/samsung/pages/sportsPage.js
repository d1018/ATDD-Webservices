const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const menuPage = require('./menuPage');

const { VRC, PROP, COMP } = commons;

class SportsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('sportsPage', locator);
  }

  eventDetailPage = this.#getSelectorData('eventDetailPage');

  videoPlayerScene = this.getElementByPage(
    'videoPlayerPage',
    'videoPlayerScene',
  );

  sportsHeroTitle_lbl = this.#getSelectorData('sportsHeroTitle_lbl');

  sportsHeroSecondaryTitle_lbl = this.#getSelectorData(
    'sportsHeroSecondaryTitle_lbl',
  );

  sportsHeroDescription_lbl = this.#getSelectorData(
    'sportsHeroDescription_lbl',
  );

  sportsHeroTimeStamp_lbl = this.#getSelectorData('sportsHeroTimeStamp_lbl');

  sportsShowTitle_lbl = this.#getSelectorData('sportsShowTitle_lbl');

  sportsGenreTab_lbl = this.#getSelectorData('sportsGenreTab_lbl');

  sportsSelectedTitle_lbl = this.#getSelectorData('sportsSelectedTitle_lbl');

  sportsSelectedTile = this.#getSelectorData('sportsSelectedTile');

  secondarySportsPage_img = this.#getSelectorData('secondarySportsPage_img');

  verifySportsScreenAnchorDetails = async () => {
    if (await commons.waitTillVideoIsPlaying(20)) {
      await commons.assertExists(this.videoPlayerScene);
    } else {
      await commons.assertExists(this.eventDetailPage);
    }
  };

  verifySportsDetailsPage = async () => {
    await menuPage.assertPage('Sports');
  };

  assertSportsHeroMetadata = async (railName) => {
    await commons.assertExists(this.sportsHeroTitle_lbl);
    await commons.assertExists(this.sportsHeroDescription_lbl);
    await commons.assertExists(this.sportsHeroTimeStamp_lbl);
    await commons.assertExists(this.sportsShowTitle_lbl);

    switch (railName) {
      case 'Live events':
        break;
      case 'Upcoming':
      case 'Latest':
        await commons.assertExists(this.sportsHeroSecondaryTitle_lbl);
        break;
      default:
        break;
    }
  };

  verifyRailTileAndInteractiveHeroMetadata = async (railName) => {
    await this.assertSportsHeroMetadata(railName);
  };

  selectSecondaryGenreTab = async (genreName) => {
    await menuPage.assertPage('Sports', 10);
    while (
      await commons.checkProperty(
        this.sportsGenreTab_lbl,
        PROP.TEXT_CONTENT,
        genreName,
        COMP.NOT_EQUAL,
      )
    ) {
      await commons.userAction(VRC.RIGHT, 1, 2);
    }
  };

  selectSportsCategoryPage = async (categoryName) => {
    await commons.tryUntil(this.sportsSelectedTile, VRC.DOWN, 3, 5);
    let fetchedSportCategory;

    for (let i = 1; i <= 8; i++) {
      for (let j = 1; j < 5; j++) {
        fetchedSportCategory = String(
          await commons.fetchAttributeData(
            this.sportsSelectedTitle_lbl,
            PROP.TEXT_CONTENT,
          ),
        ).trim();

        if (fetchedSportCategory === categoryName) {
          await commons.userAction(VRC.SELECT, 1, 2);
          return;
        }
        if (i % 2 === 0) {
          await commons.userAction(VRC.LEFT, 1, 2);
        } else {
          await commons.userAction(VRC.RIGHT, 1, 2);
        }
      }
      await commons.userAction(VRC.DOWN, 1, 2);
    }
    throw new Error(`could not find: ${categoryName} on All Sports page`);
  };

  verifySecondarySportsMetadata = async () => {
    await commons.assertExists(this.secondarySportsPage_img, 5);
    const secondaryMetadata = [
      this.sportsHeroTitle_lbl,
      this.sportsHeroDescription_lbl,
      this.sportsShowTitle_lbl,
    ];

    for (let i = 0; i < secondaryMetadata.length; i++) {
      await commons.assertDoesNotExist(secondaryMetadata[i], 2);
    }
  };
}

module.exports = new SportsPage();
