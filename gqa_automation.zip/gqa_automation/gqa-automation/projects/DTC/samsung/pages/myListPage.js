const { BasePage, remoteActions, testdataHelper } = require('./basePage');
const homePage = require('./homePage');
const menuPage = require('./menuPage');

const commons = remoteActions;
const { VRC, PROP, COMP } = commons;
let toolTipStatus = false;

class MyListPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myListPage', locator);
  }

  focusedMyListPage = this.#getSelectorData('focusedMyListPage');

  pressAndHoldToMyList_lbl = this.#getSelectorData('pressAndHoldToMyList_lbl');

  noSavedShow_txt = this.#getSelectorData('noSavedShow_txt');

  browseShows_btn = this.#getSelectorData('browseShows_btn');

  focusedShowCard = this.getElementByPage('browsePage', 'focusedShowCard');

  focusedShowDetailPage = this.getElementByPage(
    'showPage',
    'focusedShowDetailPage',
  );

  focusedFirstShowTile = this.#getSelectorData('focusedFirstShowTile');

  watchNow_btn = this.getElementByPage('showPage', 'watchNow_btn');

  focusedBrowsePage = this.getElementByPage('browsePage', 'focusedBrowsePage');

  toastMsg_lbl = this.#getSelectorData('toastMsg_lbl');

  focusedForYou_lbl = this.getElementByPage('homePage', 'focusedForYou_lbl');

  focusedShow_tile = this.getElementByPage(
    'networkLandingPage',
    'focusedShow_tile',
  );

  metadataList = {
    'added to': 'added_to_toast',
    'removed from': 'removed_from_toast',
    add: 'add_tooltip',
    remove: 'remove_tooltip',
  };

  /**
   * Navigate to Browse Page from Empty Mylist Page clicking Browse Show CTA
   * Select first show, go to show details page
   * click + My list CTA
   * click Back till focused show card present on browse page
   */
  addShowsToMylistFromBrowse = async () => {
    if (await commons.doesNotExist(this.focusedMyListPage)) {
      await menuPage.navigateToPage('My List');
    }
    await commons.waitUntil(this.noSavedShow_txt);
    await commons.assertVisible(this.browseShows_btn);
    await commons.userAction(VRC.SELECT);
    await commons.assertVisible(this.focusedBrowsePage, 10);

    await commons.tryUntil(this.focusedShowCard, VRC.DOWN, 3, 1);
    await commons.userAction(VRC.SELECT);

    await commons.waitUntil(this.focusedShowDetailPage, 5);
    await commons.assertVisible(this.watchNow_btn);
    await commons.userAction(VRC.RIGHT);
    await commons.userAction(VRC.SELECT); // wait for toast msg to be shown
    await commons.waitUntilVisible(this.toastMsg_lbl, 5);
    await commons.tryUntil(this.focusedShowCard, VRC.BACK, 3);
  };

  /**
   * The below function will verify the MyList page has shows or not
   *
   * @param {boolean} isShowPresent - expected show to be present or not
   */
  verifyShowsInMyList = async (isShowPresent) => {
    if (await commons.doesNotExist(this.focusedMyListPage)) {
      await menuPage.navigateToPage('My List');
    }
    await commons.assertVisible(this.focusedMyListPage, 5);

    if (isShowPresent) {
      await commons.assertExists(this.focusedFirstShowTile);
    } else {
      await commons.assertDoesNotExist(this.focusedFirstShowTile);
    }
  };

  /**
   * Go to My list page
   * Remove ALL shows from my list
   * Verify empty My List page and no Saved Show, Browse Shown CTA's
   */
  removeShowFromMyListPage = async () => {
    if (await commons.doesNotExist(this.focusedMyListPage)) {
      await menuPage.navigateToPage('My List');
    }
    await commons.assertVisible(this.focusedMyListPage);
    while (await commons.elementExists(this.focusedFirstShowTile)) {
      await commons.pressAndHold('ENTER', 2);
      await commons.assertExists(this.toastMsg_lbl);
    }
    await this.assertSelectorArray(this.noSavedShow_txt, this.browseShows_btn);
  };

  selectBrowseShows = async () => {
    await commons.assertVisible(this.browseShows_btn);
    await commons.userAction(VRC.SELECT);
  };

  /**
   * Go to For You tab and select a show which is not added to my list.
   */
  navigateToShowTileInHomePage = async () => {
    if ((await commons.elementVisible(this.focusedForYou_lbl)) === false) {
      await menuPage.navigateToPage('Home');
    }
    await commons.waitUntil(this.focusedForYou_lbl, 10);
    await homePage.moveToNextRail();
    await commons.tryUntil(this.focusedShow_tile, VRC.DOWN, 2, 1);
    while (toolTipStatus === false) {
      // here we are checking if the tool tip shows that the current show is added to mylist we move to next Show tile
      await commons.assertVisible(this.focusedShow_tile, 5);
      await commons.assertExists(this.pressAndHoldToMyList_lbl, 5);
      toolTipStatus = await commons.checkProperty(
        this.pressAndHoldToMyList_lbl,
        PROP.TEXT_CONTENT,
        testdataHelper.getContent(`myList.add_tooltip`),
        COMP.CONTAIN,
      );
      if (toolTipStatus === true) break;
      await commons.userAction(VRC.RIGHT);
    }
  };

  /**
   * This Method will check for focused ShowTile , will Press and Hold to add/remove the show to/from My List
   */
  pressAndHoldOnShow = async () => {
    if (await commons.elementExists(this.focusedShow_tile)) {
      await commons.pressAndHold('ENTER', 2);
      await commons.assertExists(this.toastMsg_lbl);
      this.toastMsgTxt = await commons.fetchAttributeData(
        this.toastMsg_lbl,
        PROP.TEXT_CONTENT,
      );
    }
  };

  /**
   * This method Checks the Toast Msg after adding/Removing Shows to/from Mylist
   *
   * @param {string} action This parameter accepts a string like add/remove to check toast message text
   */
  verifyAddRemoveMyListInHomePage = async (action) => {
    const expectedToastMessage = testdataHelper.getContent(
      `myList.${this.metadataList[action.toLowerCase()]}`,
    );
    const toastMsgStatus = await commons.checkProperty(
      this.toastMsg_lbl,
      PROP.TEXT_CONTENT,
      expectedToastMessage,
      COMP.CONTAIN,
    );

    if (toastMsgStatus === false) {
      throw new Error(
        `Expected toast msg: ${expectedToastMessage} did not match with Actual Toast msg: ${this.toastMsgTxt}`,
      );
    }
  };

  /**
   * Verify selected show tool tip is present when a show is highlighted and validate its Message text
   *
   * @param {string} attribute This parameter accepts a string like add/remove to check tool tip message text
   */
  verifyShowToolTipMsg = async (attribute) => {
    await commons.assertExists(this.pressAndHoldToMyList_lbl, 5);
    const actualToolTipTxt = await commons.fetchAttributeData(
      this.pressAndHoldToMyList_lbl,
      PROP.TEXT_CONTENT,
    );
    const expectedToolTipText = testdataHelper.getContent(
      `myList.${this.metadataList[attribute.toLowerCase()]}`,
    );

    toolTipStatus = await commons.checkProperty(
      this.pressAndHoldToMyList_lbl,
      PROP.TEXT_CONTENT,
      expectedToolTipText,
      COMP.CONTAIN,
    );

    if (toolTipStatus === false) {
      throw new Error(
        `Expected tooltip keyword msg: ${expectedToolTipText} not available in Actual tooltip msg: ${actualToolTipTxt}`,
      );
    }
  };

  /**
   * Verify remove show tool tip is present when a show is highlighted
   */
  verifyRemoveShowTooltip = async () => {
    await this.verifyShowToolTipMsg('remove');
  };
}

module.exports = new MyListPage();
