const { BasePage, remoteActions } = require('./basePage');
const menuPage = require('./menuPage');
const homePage = require('./homePage');
const networkLandingPage = require('./networkLandingPage');

const commons = remoteActions;
const { VRC } = commons;

class OnboardingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  focusedRefreshedCode_btn = this.getElementByPage(
    'activationPage',
    'focusedRefreshCode_btn',
  );

  refreshCode_btn = this.getElementByPage('activationPage', 'refreshCode_btn');

  focusedSignIn_btn = this.getElementByPage('accountPage', 'focusedSignIn_btn');

  focusedSignUp_btn = this.getElementByPage('accountPage', 'focusedSignUp_btn');

  signIn_btn = this.getElementByPage('accountPage', 'signIn_btn');

  signUp_btn = this.getElementByPage('accountPage', 'signUp_btn');

  focusedSignInWithEmail_btn = this.getElementByPage(
    'activationPage',
    'focusedSignInWithEmail_btn',
  );

  signInWithEmail_btn = this.getElementByPage(
    'activationPage',
    'signInWithEmail_btn',
  );

  userName_txtBx = this.#getSelectorData('userName_txtBx');

  noSubscriptionTitle_lbl = this.getElementByPage(
    'inactiveSubscriptionPage',
    'noSubscriptionTitle_lbl',
  );

  chooseYourPlan_btn = this.getElementByPage(
    'inactiveSubscriptionPage',
    'chooseYourPlan_btn',
  );

  selectCTA = async (CTAType) => {
    const ctaType = {
      'Sign In': this.focusedSignIn_btn,
      'Sign Up': this.focusedSignUp_btn,
    };

    if (CTAType.includes('Sign')) {
      await commons.tryUntil(ctaType[CTAType], VRC.DOWN, 3, 1);
      await commons.userAction(VRC.ENTER);
    } else {
      const btn = CTAType.toString().toUpperCase();

      await commons.userAction(btn);
    }
  };

  verifyCTAScreen = async (CTAType) => {
    if (CTAType === 'Sign In') {
      await commons.waitUntil(this.refreshCode_btn, 10);
      await commons.tryUntil(this.focusedSignInWithEmail_btn, VRC.DOWN, 2, 1);
      await commons.userAction(VRC.ENTER, 1);
      await commons.waitUntil(this.userName_txtBx, 10);
      await commons.assertExists(this.userName_txtBx, 5);
      await commons.tryUntil(this.signInWithEmail_btn, VRC.BACK, 2, 5);
    } else if (CTAType === 'Sign Up') {
      await commons.assertExists(this.focusedRefreshedCode_btn, 10);
    }
  };

  selectCTAAndVerify = async (CTA) => {
    await this.selectCTA(CTA);
    await this.verifyCTAScreen(CTA);
    await commons.tryUntil(this.signUp_btn, VRC.BACK, 2, 5);
    await commons.userAction(VRC.UP);
  };

  selectContentEntertainmentVOD = async () => {
    await homePage.scrollToRail('Featured');
    await commons.userAction(VRC.ENTER);
    await commons.userAction(VRC.DOWN, 2, 2);
    await commons.userAction(VRC.ENTER);
  };

  selectContentEntertainmentLinear = async () => {
    await homePage.scrollToRail('');
    await networkLandingPage.navigateToSelectNetwork('TLC');
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.signUp_btn, 10);
  };

  selectContentSportsVOD = async () => {
    await menuPage.navigateToPage('Sports');
    await homePage.scrollToRail('Sports Documentaries');
    await commons.userAction(VRC.ENTER);
    await homePage.scrollToRail('Episodes');
    await commons.userAction(VRC.ENTER);
  };
  /**
   *
   * @param {string} contentType - whether the content type if VOD/Linear/Live
   * @param {string} userType  - whether the user type is anonymous/lapsed
   * This function will navigate and select the shows/content based on the contentType & userType
   */

  navigateAndSelectContent = async (contentType, userType) => {
    await menuPage.navigateToPage('Home');
    if (
      contentType.includes('Entertainment VOD') &&
      (userType.includes('anonymous') || userType.includes('lapsed'))
    ) {
      await this.selectContentEntertainmentVOD();
    } else if (
      contentType.includes('Entertainment Linear') &&
      userType.includes('lapsed')
    ) {
      await this.selectContentEntertainmentLinear();
    } else if (
      contentType.includes('Sports VOD') &&
      userType.includes('anonymous')
    ) {
      await this.selectContentSportsVOD();
    }
  };

  verifyInactiveSubscriptionScreen = async () => {
    await commons.waitUntil(this.noSubscriptionTitle_lbl, 20);
    await commons.assertVisible(this.chooseYourPlan_btn, 5);
  };
}

module.exports = new OnboardingPage();
