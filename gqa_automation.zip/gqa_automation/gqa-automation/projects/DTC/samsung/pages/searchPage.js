const assert = require('assert');
const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const { VRC, PROP } = commons;

let searchText = '';

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  search_txtBx = this.#getSelectorData('search_txtBx');

  firstThumbnailOnSearch = this.#getSelectorData('firstThumbnailOnSearch');

  focusedShow_lbl = this.#getSelectorData('focusedShow_lbl');

  focusedSearch_txtBx = this.#getSelectorData('focusedSearch_txtBx');

  showTitle_lbl = this.#getSelectorData('showTitle_lbl');

  showImage_img = this.#getSelectorData('showImage_img');

  showNetworkIcon_img = this.#getSelectorData('showNetworkIcon_img');

  focusedFirstThumbnailOnSearch = this.#getSelectorData(
    'focusedFirstThumbnailOnSearch',
  );

  focusedShowDetailPage = this.getElementByPage(
    'showPage',
    'focusedShowDetailPage',
  );

  showHeroImage = this.getElementByPage('showPage', 'showHeroImage');

  videoPlayerScene = this.getElementByPage(
    'videoPlayerPage',
    'videoPlayerScene',
  );

  subscribeToWatch = this.getElementByPage(
    'subscribetoWatchPage',
    'subscribeToWatch',
  );

  eventDetailPage = this.getElementByPage('sportsPage', 'eventDetailPage');

  searchResultTabs = {
    Shows: this.#getSelectorData('showsTab_lbl'),
    Sports: this.#getSelectorData('showSportsTab_lbl'),
    Episodes: this.#getSelectorData('showEpisodesTab_lbl'),
    Extras: this.#getSelectorData('showExtrasTab_lbl'),
    Specials: this.#getSelectorData('showSpecialsTab_lbl'),
    'Ultra HD': this.#getSelectorData('showUltraHDTab_lbl'),
    Collections: this.#getSelectorData('showCollectionsTab_lbl'),
  };

  noResultsFound_txt = this.#getSelectorData('noResultsFound_txt');

  searchRecommendedForYou = this.#getSelectorData('searchRecommendedForYou');

  searchText = async (text) => {
    searchText = testdataHelper.getContent(`searchPage.${text}`);
    await commons.tryUntil(this.focusedSearch_txtBx, VRC.UP, 2, 1);
    await commons.userAction(VRC.ENTER);
    await commons.sendText(searchText);
    await commons.userAction(VRC.BACK);
  };

  verifyIfSearchResultsLoaded = async () => {
    await commons.assertExists(this.showTitle_lbl, 10);
    await commons.assertExists(this.showImage_img);
    await commons.assertExists(this.showNetworkIcon_img);
  };

  verifyResultsIncludeSearchText = async () => {
    await commons.waitUntil(this.showTitle_lbl, 5);
    const titleValue = await commons.fetchAttributeData(
      this.showTitle_lbl,
      PROP.TEXT_CONTENT,
    );

    if (titleValue.includes(searchText)) return true;
    return false;
  };

  getSearchResultsTab = () => {
    let expsearchResultTabs;
    const geoLocation = process.env.GEO.toLowerCase();

    if (geoLocation === 'gb') {
      expsearchResultTabs = [
        testdataHelper.getContent('searchPage.showsTab'),
        testdataHelper.getContent('searchPage.sportsTab'),
        testdataHelper.getContent('searchPage.episodesTab'),
        testdataHelper.getContent('searchPage.extrasTab'),
      ];
    } else {
      // Default is US region
      expsearchResultTabs = [
        testdataHelper.getContent('searchPage.showsTab'),
        testdataHelper.getContent('searchPage.episodesTab'),
        testdataHelper.getContent('searchPage.specialsTab'),
        testdataHelper.getContent('searchPage.collectionsTab'),
        testdataHelper.getContent('searchPage.extrasTab'),
      ];
    }

    return expsearchResultTabs;
  };

  verifySearchTabsLanding = async (tabName) => {
    switch (tabName) {
      case 'Shows':
        await commons.assertExists(this.focusedShowDetailPage, 20);
        break;
      case 'Sports':
        await this.verifySportsScreenAnchorDetails();
        break;
      case 'Episodes':
        await this.verifyVideoPlayerAnchorDetails();
        break;
      case 'Extras':
        await this.verifyVideoPlayerAnchorDetails();
        break;
      case 'Collections':
        await commons.assertExists(this.showHeroImage, 5);
        break;
      case 'Specials':
        await this.verifyVideoPlayerAnchorDetails();
        break;
      default:
        break;
    }
  };

  verifySportsScreenAnchorDetails = async () => {
    if (await commons.waitTillVideoIsPlaying(20)) {
      await commons.assertExists(this.videoPlayerScene);
    } else {
      await commons.assertExists(this.eventDetailPage);
    }
  };

  verifyVideoPlayerAnchorDetails = async () => {
    if (!(await commons.elementExists(this.subscribeToWatch, 10))) {
      await commons.assertVideoIsPlaying();
    }
  };

  verifyLandingPageBasedOnContent = async () => {
    const searchTabs = testdataHelper.getContent('searchPage.searchResultTabs');

    for (let i = 0; i < searchTabs.length; i++) {
      await commons.waitUntil(this.searchResultTabs[searchTabs[i]]);
      await commons.userAction(VRC.DOWN, 1, 1);
      await commons.assertExists(this.focusedFirstThumbnailOnSearch, 60);
      await commons.userAction(VRC.SELECT);
      await this.verifySearchTabsLanding(searchTabs[i], 60);
      await commons.userAction(VRC.BACK, 1, 2);
      await commons.tryUntil(this.focusedSearch_txtBx, VRC.UP, 4, 1);
      await commons.userAction(VRC.DOWN, 1, 2);
      /* Verify search tabs displayed */
      await commons.assertExists(this.searchResultTabs[searchTabs[i]]);
      await commons.userAction(VRC.RIGHT, 1, 1);
    }
  };

  verifySearchedContentAndItsLandingPage = async () => {
    if ((await this.verifyResultsIncludeSearchText()) === false) {
      throw new Error(`Search result does not includes '${searchText}'`);
    }
    await this.verifyLandingPageBasedOnContent();
  };

  verifyNoResultFound = async () => {
    await commons.assertExists(this.noResultsFound_txt, 10);
  };

  verifyRecommendedForYou = async () => {
    await commons.assertExists(this.searchRecommendedForYou, 10);
  };

  verifyResultsIncludeSpecificText = async (showName) => {
    let index = 1;
    const resultsTitle = [];
    const searchResult = testdataHelper.getContent(`searchPage.${showName}`);
    let foundInSearchFlag = false;

    await commons.assertExists(this.firstThumbnailOnSearch, 5);

    while (index !== 7) {
      const showTitle = await commons.fetchAttributeData(
        this.focusedShow_lbl,
        PROP.TEXT_CONTENT,
      );

      resultsTitle.push(showTitle);

      const rowPosition = index;

      if (rowPosition < 7) {
        await commons.userAction(VRC.RIGHT, 1, 1);
      }

      index++;
    }

    for (let i = 0; i < resultsTitle.length; i++) {
      if (resultsTitle[i].includes(searchResult)) {
        foundInSearchFlag = true;
        break;
      }
    }
    assert(
      foundInSearchFlag === true,
      `'${searchResult}' NOT included in Search Results.`,
    );
  };
}

module.exports = new SearchPage();
