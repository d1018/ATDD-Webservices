const { ok } = require('assert');
const assert = require('assert');

const { BasePage, remoteActions, testdataHelper } = require('./basePage');
const menuPage = require('./menuPage');
const searchPage = require('./searchPage');
const signInPage = require('./signInPage');
const profilePage = require('./profilePage');

const commons = remoteActions;
const { PROP, VRC, COMP } = commons;
const myListShowsOrder = [];

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  forYou_lbl = this.#getSelectorData('forYou_lbl');

  focusedThumbnail = this.#getSelectorData('focusedThumbnail');

  heroShowTitle = this.#getSelectorData('heroShowTitle');

  heroShowDescription = this.#getSelectorData('heroShowDescription');

  focusedRailName = this.#getSelectorData('focusedRailName');

  focusedRail = this.#getSelectorData('focusedRail');

  focusedNetworkRail = this.#getSelectorData('focusedNetworkRail');

  focusedHomePage = this.#getSelectorData('focusedHomePage');

  focusedForYou_lbl = this.#getSelectorData('focusedForYou_lbl');

  focusedProfile = this.getElementByPage('profilePage', 'focusedProfile');

  focusedProfilePage = this.getElementByPage(
    'profilePage',
    'focusedProfilePage',
  );

  genreTab_lbl = this.#getSelectorData('genreTab_lbl');

  focusedChannelLogo_img = this.#getSelectorData('focusedChannelLogo_img');

  focusedHeroTitle_txt = this.#getSelectorData('focusedHeroTitle_txt');

  focusedHeroPoster_img = this.#getSelectorData('focusedHeroPoster_img');

  enlargedFocusedTitle_txt = this.#getSelectorData('enlargedFocusedTitle_txt');

  selectedSportsTile = this.#getSelectorData('selectedSportsTile');

  focusedHeroTitle = this.#getSelectorData('focusedHeroTitle');

  focusedHeroDescription = this.#getSelectorData('focusedHeroDescription');

  focusedInLineHero_btn = this.#getSelectorData('focusedInLineHero_btn');

  focusedBrowsePage = this.getElementByPage('browsePage', 'focusedBrowsePage');

  focusedGenereMenuItem = this.#getSelectorData('focusedGenereMenuItem');

  toastMsg_lbl = this.getElementByPage('myListPage', 'toastMsg_lbl');

  networkRail = this.#getSelectorData('networkRail');

  focusedstandardPrimaryTile = this.#getSelectorData(
    'focusedstandardPrimaryTile',
  );

  enlargedFocusedShowPoster_img = this.#getSelectorData(
    'enlargedFocusedShowPoster_img',
  );

  enlargedFocusedNetworkLogo_img = this.#getSelectorData(
    'enlargedFocusedNetworkLogo_img',
  );

  focusedMyListChecked = this.getElementByPage(
    'showPage',
    'focusedMyListChecked',
  );

  focusedMyListUnchecked = this.getElementByPage(
    'showPage',
    'focusedMyListUnchecked',
  );

  showDescription_txt = this.getElementByPage(
    'showPage',
    'showDescription_txt',
  );

  showDetailsPage = this.getElementByPage('showPage', 'showDetailsPage');

  focusedRailShowTiles = this.#getSelectorData('focusedRailShowTiles');

  focusedFirstThumbnailOnSearch = this.getElementByPage(
    'searchPage',
    'focusedFirstThumbnailOnSearch',
  );

  signUp_btn = this.getElementByPage('networkLandingPage', 'signUp_btn');

  focusedShowDetailPage = this.getElementByPage(
    'showPage',
    'focusedShowDetailPage',
  );

  secondEpisode_tile = this.getElementByPage(
    'episodeLandingPage',
    'secondEpisode_tile',
  );

  episodeInfo_lbl = this.getElementByPage(
    'episodeLandingPage',
    'episodeInfo_lbl',
  );

  ratingCode_lbl = this.#getSelectorData('ratingCode_lbl');

  watchNow_btn = this.getElementByPage('showPage', 'watchNow_btn');

  focusedWatchNow_btn = this.getElementByPage(
    'showPage',
    'focusedWatchNow_btn',
  );

  focusedMyList_btn = this.getElementByPage('showPage', 'focusedMyList_btn');

  focusedShow = this.getElementByPage('browsePage', 'focusedShowCard');

  myList_btn = this.getElementByPage('showPage', 'myList_btn');

  eventDetailPage = this.getElementByPage('sportsPage', 'eventDetailPage');

  signIn_btn = this.getElementByPage('sportsPage', 'signIn_btn');

  upgradeTitle_lbl = this.getElementByPage(
    'upgradeToWatchPage',
    'upgradeTitle_lbl',
  );

  jipContentTitle_lbl = this.getElementByPage(
    'videoPlayerPage',
    'jipContentTitle_lbl',
  );

  playerPause_btn = this.getElementByPage('videoPlayerPage', 'playerPause_btn');

  playerPlay_btn = this.getElementByPage('videoPlayerPage', 'playerPlay_btn');

  closedCaption_btn = this.getElementByPage(
    'videoPlayerPage',
    'closedCaption_btn',
  );

  focusedFirstShowTile = this.getElementByPage(
    'myListPage',
    'focusedFirstShowTile',
  );

  searchContentName = {
    kids: 'kidsShowName',
    Adults: 'adultShowName',
    JIP: 'JIPShowName',
  };

  focusedsignOut_tab = this.getElementByPage(
    'accountPage',
    'focusedsignOut_tab',
  );

  focusedAccountPage = this.getElementByPage(
    'accountPage',
    'focusedAccountPage',
  );

  focusedSignOut_btn = this.getElementByPage(
    'accountPage',
    'focusedSignOut_btn',
  );

  focusedSignOutConfirmationPage = this.getElementByPage(
    'accountPage',
    'focusedSignOutConfirmationPage',
  );

  focusedSignOutConfirmation_btn = this.getElementByPage(
    'accountPage',
    'focusedSignOutConfirmation_btn',
  );

  jipVideoPlayerElements = [
    this.playerPlay_btn,
    this.jipContentTitle_lbl,
    this.closedCaption_btn,
  ];

  focusedAddToMyListBtn_lbl = this.#getSelectorData(
    'focusedAddToMyListBtn_lbl',
  );

  focusedRemoveFromMyListBtn_lbl = this.#getSelectorData(
    'focusedRemoveFromMyListBtn_lbl',
  );

  verifySportsRail = async (sportsRailType) => {
    await menuPage.assertPage('Home');
    switch (sportsRailType) {
      case 'primary':
        await this.scrollToRail('Link testing - poster primary');
        break;
      case 'enlarged':
        await this.scrollToRail('Link testing - Poster-Enlarged');
        break;
      case 'standard primary':
        await this.scrollToRail('link testing standard primary');
        break;
      default:
        break;
    }
  };

  // This method moves the focus to the next rail on Home page
  moveToNextRail = async (direction = VRC.DOWN) => {
    do {
      await commons.userAction(direction, 1, 1);
    } while (await commons.doesNotExist(this.focusedRailName));
  };

  // This method moves the user to mentioned genre tabs under home Page
  selectGenreTab = async (genreName) => {
    await commons.waitUntil(this.genreTab_lbl, 10);
    while (
      await commons.checkProperty(
        this.genreTab_lbl,
        PROP.TEXT_CONTENT,
        genreName,
        COMP.NOT_CONTAIN,
      )
    ) {
      await commons.userAction(VRC.RIGHT, 1, 2);
    }
    await commons.assertExists(this.watchNow_btn, 5);
  };

  // This Method captured show description and pushes to an array called "myListShowsOrder"
  captureShowName = async () => {
    await commons.assertExists(this.showDetailsPage);
    const showName = await commons.fetchAttributeData(
      this.showDescription_txt,
      PROP.TEXT_CONTENT,
    );

    myListShowsOrder.push(showName);
  };

  addShowToMyList = async (count) => {
    if ((await this.returnGeoLocation()) === 'america')
      await menuPage.navigateToPage('Browse');
    else await menuPage.navigateToPage('Shows');

    await commons.assertVisible(this.focusedBrowsePage, 5);
    await commons.tryUntil(this.focusedShow, VRC.DOWN, 4);

    for (let i = 1; i <= count; i++) {
      await commons.assertVisible(this.focusedShow, 5);
      await commons.userAction(VRC.SELECT);
      await commons.assertVisible(this.focusedShowDetailPage, 5);
      await commons.tryUntil(this.focusedMyList_btn, VRC.RIGHT, 3);

      if (await commons.elementExists(this.focusedMyListUnchecked)) {
        await commons.userAction(VRC.SELECT);
        await this.captureShowName();
      }

      await commons.tryUntil(this.focusedShow, VRC.BACK, 2, 2);
      await commons.userAction(VRC.RIGHT);
    }
    this.showAddedFromBrowser = true;
  };

  verifyMyListRailMetadata = async (showCount) => {
    await menuPage.navigateToPage('Home');
    await this.scrollToRail('My List', true);

    for (let i = 0; i < showCount; i++) {
      await commons.assertExists(this.focusedThumbnail);
      await commons.assertExists(this.heroShowTitle);
      await commons.userAction(VRC.RIGHT);
    }
    await commons.userAction(VRC.LEFT, Number(showCount));
    if (await commons.elementExists(menuPage.focusedMenuBar)) {
      await commons.userAction(VRC.RIGHT);
      await commons.assertExists(this.focusedThumbnail);
    }
  };

  verifyMyListRailShowOrder = async () => {
    const reverseMyListShowsOrder = myListShowsOrder.reverse();

    for (let i = 0; i < reverseMyListShowsOrder.length; i++) {
      await this.selectShow();
      await commons.assertProperty(
        this.showDescription_txt,
        PROP.TEXT_CONTENT,
        reverseMyListShowsOrder[i],
        COMP.EQUAL,
      );
      await commons.userAction(VRC.BACK);
      await commons.waitUntil(this.focusedHomePage, 10);
      await commons.userAction(VRC.RIGHT);
    }
  };

  removeFromMyList = async (showName) => {
    if (this.showAddedFromBrowser === true) {
      await commons.assertVisible(this.focusedRail, 5);
      const elementArrayBeforeRemoval = await this.arrayOfSelectorProperty(
        this.focusedRailShowTiles,
        PROP.HREF,
      );

      await commons.assertVisible(this.focusedShow, 5);
      await commons.pressAndHold('ENTER', 2);
      await commons.assertExists(this.toastMsg_lbl);
      await commons.assertVisible(this.focusedRail, 5);
      const elementArrayAfterRemoval = await this.arrayOfSelectorProperty(
        this.focusedRailShowTiles,
        PROP.HREF,
      );

      if (
        elementArrayBeforeRemoval.length === elementArrayAfterRemoval.length
      ) {
        throw new Error(
          'Show is not removed from MyList rail which is not expected',
        );
      }
    } else {
      await menuPage.navigateToPage('Search');
      await commons.sendText(
        `${testdataHelper.getContent(`searchPage.${showName}`)}`,
      );
      await commons.tryUntil(
        this.focusedFirstThumbnailOnSearch,
        VRC.DOWN,
        3,
        1,
      );
      await commons.pressAndHold('ENTER', 2);
      await commons.assertExists(this.toastMsg_lbl);
    }
  };

  selectShow = async () => {
    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.focusedShowDetailPage, 10);
  };

  playVideo = async () => {
    await commons.assertExists(this.focusedWatchNow_btn);
    await commons.userAction(VRC.SELECT);
  };

  verifyVideoPlayed = async () => {
    await this.selectShow();
    await this.playVideo();
    await commons.assertVideoIsPlaying();
  };

  scrollToRail = async (railName, flag = true) => {
    await commons.tryUntil(this.focusedGenereMenuItem, VRC.UP, 20, 1);
    const searchedRailName = railName.toLowerCase();
    const railList = [];

    for (let i = 0; i < 21; i++) {
      await this.moveToNextRail();
      const focusedRail = String(
        await commons.fetchAttributeData(
          this.focusedRailName,
          PROP.TEXT_CONTENT,
        ),
      )
        .trim()
        .toLowerCase();

      if (railList.includes(focusedRail)) {
        if (!railList.includes(searchedRailName)) {
          break;
        }
      }
      railList.push(focusedRail);
      if (focusedRail === searchedRailName && flag === true) {
        break;
      } else if (focusedRail === searchedRailName && flag === false) {
        throw new Error(
          `${railName} rail is still shown which is not expected`,
        );
      } else if (i === 20 && flag === true)
        throw new Error(`${railName} rail is not shown which is not expected`);
    }
  };

  /**
   * The below function will validate Network Rail
   *
   * @returns {boolean} will return true or false
   */
  isNetworkRailDisplayed = async () => {
    const result = await commons.elementExists(this.networkRail, 2);

    return result;
  };

  scrollToNetworkRail = async () => {
    await commons.tryUntil(this.focusedNetworkRail, VRC.DOWN, 14, 1);
    await this.validateNetworkRail();
  };

  validateNetworkRail = async () => {
    await commons.assertVisible(this.networkRail, 2);
  };

  verifyRailPresent = async (railName, railPresent) => {
    if (
      await commons.checkProperty(
        this.focusedRailName,
        PROP.TEXT_CONTENT,
        railName,
        COMP.EQUAL,
      )
    ) {
      ok(railPresent === true);
    } else {
      const flag = false;
      const railList = [];

      let counter = 0;

      while (await commons.elementExists(this.focusedRailName)) {
        await commons.userAction(VRC.BACK);
      }

      while (flag !== true) {
        await this.moveToNextRail();
        const focusedRailName = String(
          await commons.fetchAttributeData(
            this.focusedRailName,
            PROP.TEXT_CONTENT,
          ),
        ).trim();

        if (railList.includes(focusedRailName)) {
          break;
        }
        railList.push(focusedRailName);
        counter++;
        if (focusedRailName === railName) {
          break;
        }
      }

      const railExist = railList.includes(railName);

      ok(
        railExist === railPresent,
        `Expected: ${railPresent}, Received: ${railExist}`,
      );
      await commons.userAction(VRC.UP, counter + 2, 1);
    }
  };

  assertPrimaryPosterMetadata = async () => {
    await commons.assertExists(this.focusedThumbnail);
    await commons.assertExists(this.focusedHeroTitle_txt);
    await commons.assertExists(this.focusedHeroPoster_img);
    await commons.assertDoesNotExist(this.focusedChannelLogo_img);
  };

  assertEnlargedPosterMetadata = async () => {
    await commons.assertExists(this.enlargedFocusedShowPoster_img);
    await commons.assertExists(this.enlargedFocusedTitle_txt);
    await commons.assertNotVisible(this.enlargedFocusedNetworkLogo_img);
  };

  assertStandardPrimaryPosterMetadata = async () => {
    await commons.assertExists(this.focusedThumbnail);
    await commons.assertExists(this.focusedHeroTitle_txt);
    await commons.assertExists(this.focusedHeroPoster_img);
    await commons.assertDoesNotExist(this.focusedChannelLogo_img);
  };

  verifySportsCardMetadata = async (sportsRailType) => {
    await commons.tryUntil(this.selectedSportsTile, VRC.RIGHT, 20, 1);
    await commons.assertExists(this.selectedSportsTile);
    switch (sportsRailType) {
      case 'primary':
        await this.assertPrimaryPosterMetadata();
        break;
      case 'enlarged':
        await this.assertEnlargedPosterMetadata();
        break;
      case 'standard primary':
        await commons.tryUntil(
          this.focusedstandardPrimaryTile,
          VRC.RIGHT,
          10,
          1,
        );
        await this.assertStandardPrimaryPosterMetadata();
        break;
      default:
        break;
    }
  };

  selectSportsCard = async () => {
    await commons.assertExists(this.focusedThumbnail);
    await commons.userAction(VRC.SELECT, 1, 5);
  };

  navigateToSportsInLineHero = async () => {
    await commons.tryUntil(this.focusedInLineHero_btn, VRC.DOWN, 30, 1);
  };

  verifySportsInLineHeroMetadata = async () => {
    await commons.assertExists(this.focusedHeroTitle, 2);
    await commons.assertExists(this.focusedHeroDescription, 2);
    await commons.assertExists(this.focusedInLineHero_btn, 2);
    await commons.assertNotVisible(this.focusedChannelLogo_img);
  };

  selectInlineHeroCTA = async () => {
    await commons.assertExists(this.focusedInLineHero_btn);
    await commons.userAction(VRC.ENTER, 1, 5);
  };

  moveToFirstRail = async () => {
    await this.moveToNextRail();
    if (
      await commons.checkProperty(
        this.focusedRailName,
        PROP.TEXT_CONTENT,
        'Episodes',
        COMP.EQUAL,
      )
    ) {
      await commons.userAction(VRC.DOWN);
    }
  };

  validateCTAonShowPage = async () => {
    await commons.assertExists(this.watchNow_btn, 10);
    await commons.assertExists(this.myList_btn, 5);
    await commons.userAction(VRC.SELECT);
  };

  validateCTAonPages = async (userType, pageName) => {
    const page = pageName.raw();

    for (let i = 0; i < page.length; i++) {
      let pageToBe = page[i].toString();

      if (pageToBe === 'Sports' && this.returnGeoLocation() === 'america') {
        break;
      } else if (pageToBe === 'Browse' && this.returnGeoLocation() === 'emea') {
        pageToBe = 'Shows';
      }
      await menuPage.navigateToPage(pageToBe);
      if (pageToBe === 'Home') {
        await this.moveToFirstRail();
        await commons.userAction(VRC.DOWN);
      } else if (pageToBe === 'Shows' || pageToBe === 'Browse') {
        do {
          await commons.userAction(VRC.DOWN);
        } while (await commons.doesNotExist(this.focusedShow));
      } else if (pageToBe === 'Search') {
        await commons.userAction(VRC.DOWN, 2, 2);
        await commons.tryUntil(this.focusedShow, VRC.DOWN, 3, 1);
      } else if (pageToBe === 'Sports') {
        await commons.userAction(VRC.DOWN, 2, 2);
      }
      switch (userType) {
        case 'anonymous':
          await commons.userAction(VRC.SELECT);
          if (pageToBe === 'Sports') {
            await commons.assertExists(this.eventDetailPage);
            await commons.assertExists(this.signUp_btn);
            await commons.assertExists(this.signIn_btn);
          } else {
            await commons.assertExists(this.focusedShowDetailPage);
            await commons.assertExists(this.signUp_btn);
          }
          break;
        case 'fully-entitled':
          if (pageToBe === 'Sports') {
            await this.scrollToRail('Sports Documentaries', true);
          }
          if (pageToBe === 'Sports' && this.returnGeoLocation() === 'america') {
            // This Duplicate condition block is added to increase script stability during regression
            break;
          }
          await commons.userAction(VRC.SELECT);
          await this.validateCTAonShowPage();
          await commons.assertVideoIsPlaying();
          break;
        case 'non-entitled':
          if (pageToBe === 'Sports') {
            await this.scrollToRail('Sports Documentaries', true);
          }
          await commons.userAction(VRC.SELECT);
          await this.validateCTAonShowPage();
          await commons.assertExists(this.upgradeTitle_lbl);
          break;
        default:
          break;
      }
    }
  };

  verifyJipContentPlayback = async (pageName) => {
    /*
     At the moment, one can access JIP on Samsung only via the Homepage,
     but keeping the option open if there are going to be more ways
     to access JIP content. Keeping that in mind, using a switch/case
     seemed a more appropriate choice.
    */
    switch (pageName) {
      case 'Home Page':
        await this.scrollToRail(
          testdataHelper.getContent('homePage.discoveryPlusChannels'),
        );
        await commons.userAction(VRC.ENTER);
        await this.verifyJIPVideoPlayback();
        break;
      default:
        break;
    }
  };

  verifyJIPVideoPlayback = async () => {
    await commons.userAction(VRC.DOWN, 1, 5);
    if (!(await commons.elementExists(this.playerPause_btn, 5))) {
      await commons.userAction(VRC.DOWN, 1, 2);
      await commons.assertExists(this.playerPause_btn, 5);
    }
    await commons.userAction(VRC.ENTER, 1, 5);

    for (let i = 0; i < this.jipVideoPlayerElements.length; i++) {
      await commons.assertExists(this.jipVideoPlayerElements[i], 5);
    }
  };

  /**
   * The below function will verify Shows Availablity in MyList Rail
   *
   * @param {boolean} isShowPresent - Status of Show in MyList Rail is true or false
   */
  verifyShowsInMyListRail = async (isShowPresent) => {
    await menuPage.navigateToPage('Home');
    await commons.assertVisible(this.forYou_lbl, 10);
    await this.scrollToRail('My List', true);

    if (isShowPresent)
      await commons.assertVisible(this.focusedFirstShowTile, 5);
    else await commons.assertNotVisible(this.focusedFirstShowTile);
  };

  /**
   * Check for the content Type and provides a boolean response on availability
   *
   * @param {string} contentType show name which needs to be searched
   * @returns {boolean} true or flase depending on the show availability
   */
  searchContent = async (contentType) => {
    let isContentDisplayed = false;

    await searchPage.searchText(this.searchContentName[contentType]);

    isContentDisplayed = await searchPage.verifyResultsIncludeSearchText();
    return isContentDisplayed;
  };

  /**
   * This function will check if the Kids shows are shown and Adult content are not shown under search content
   */
  verifyKidsContentPopulated = async () => {
    let isContentDisplayed = false;

    await commons.assertExists(this.focusedHomePage, 5);
    await commons.userAction(VRC.DOWN);
    if (this.isNetworkRailDisplayed === true) {
      throw new Error(
        'Network Rail is shown for Kids Profile which is not expected',
      );
    }
    await menuPage.navigateToPage('Search');
    isContentDisplayed = await this.searchContent('kids');

    ok(isContentDisplayed, `Kids content is not shown on the kids profile`);

    isContentDisplayed = await this.searchContent('Adults');

    ok(
      !isContentDisplayed,
      `Adults content is shown on the kids profile which is not expected`,
    );
  };

  /**
   * This function will check if the JIP shows are not shown for kids profile
   */
  verifyJIPContent = async () => {
    if (this.countryCode === 'us') {
      const isContentDisplayed = await this.searchContent('JIP');

      ok(
        !isContentDisplayed,
        `JIP content is shown on the kids profile which is not expected`,
      );
    }
  };

  /**
   * The below function will sign Out from the Application's home Page
   *
   */
  signOut = async () => {
    await commons.assertExists(this.focusedHomePage, 60);
    await menuPage.navigateToPage('Account');
    await commons.assertExists(this.focusedAccountPage, 5);
    await commons.navigateTo(this.focusedsignOut_tab, VRC.RIGHT, 5);
    await commons.navigateTo(this.focusedSignOut_btn, VRC.DOWN, 2);
    await commons.assertExists(this.focusedSignOutConfirmationPage, 10);
    await commons.navigateTo(this.focusedSignOutConfirmation_btn, VRC.UP, 2);
    if (this.returnGeoLocation() !== 'america') {
      await commons.waitUntil(this.focusedHomePage, 30);
    } else await commons.waitUntil(signInPage.userName_txtBx, 30);
  };

  addShowToMylistFromHomeHero = async () => {
    if ((await commons.elementVisible(this.focusedForYou_lbl)) === false) {
      await menuPage.navigateToPage('Home');
    }
    await commons.waitUntil(this.focusedForYou_lbl, 10);

    // Add first hero tile to my list
    await commons.tryUntil(this.focusedWatchNow_btn, VRC.DOWN, 3, 1);
    await commons.userAction(VRC.RIGHT, 2);
    await commons.assertVisible(this.focusedMyList_btn, 5);

    // Remove item first if already added to my list
    if (await commons.doesNotExist(this.focusedAddToMyListBtn_lbl)) {
      await commons.userAction(VRC.SELECT);
      await commons.assertExists(this.focusedRemoveFromMyListBtn_lbl, 5);
    }
    await commons.userAction(VRC.SELECT);
    await commons.waitUntilVisible(this.toastMsg_lbl, 5);
    await commons.assertExists(this.focusedRemoveFromMyListBtn_lbl, 5);
  };

  verifyMyListShowAvailability = async () => {
    await profilePage.selectProfile('Standard');
    await commons.userAction(VRC.ENTER);
    await menuPage.navigateToPage('My List');
    const standardProfileShow = await commons.fetchAttributeData(
      this.focusedFirstShowTile,
      PROP.HREF,
    );

    await profilePage.selectProfile('Kids');
    await menuPage.navigateToPage('My List');
    const kidsProfileShow = await commons.fetchAttributeData(
      this.focusedFirstShowTile,
      PROP.HREF,
    );

    if (await commons.elementExists(this.focusedFirstShowTile, 3)) {
      assert(
        standardProfileShow !== kidsProfileShow,
        `same show on both profiles`,
      );
    } else {
      assert(
        standardProfileShow === kidsProfileShow,
        `show title is duplicated`,
      );
    }
  };

  resumeAndPlayVideo = async () => {
    await commons.userAction(VRC.SELECT);
    await commons.assertVideoIsPlaying(40);
  };

  verifyAgeRatingAndContentDescriptors = async (screensType) => {
    const ratings = testdataHelper.getContent('ratingList');

    await commons.assertExists(this.ratingCode_lbl, 20);
    const currentRating = await commons.fetchAttributeData(
      this.ratingCode_lbl,
      PROP.TEXT_CONTENT,
    );
    const results = ratings.includes(currentRating.trim());

    switch (screensType) {
      case 'Main Hero':
        await commons.assertExists(this.focusedHomePage, 10);
        ok(results === true, 'Rating is not as per rating standards');
        break;
      case 'Show Details Page':
        // Sometime on Homepage live content is shown that time will move to next genre tab for Shows
        if (!(await commons.elementExists(this.myList_btn, 5))) {
          await commons.userAction(VRC.RIGHT);
        }
        await commons.assertExists(this.watchNow_btn, 5);
        await commons.tryUntil(this.focusedWatchNow_btn, VRC.DOWN, 2);
        await commons.userAction(VRC.ENTER);
        await commons.assertExists(this.focusedShowDetailPage, 10);
        await commons.assertProperty(
          this.ratingCode_lbl,
          PROP.TEXT_CONTENT,
          '',
          COMP.NOT_EQUAL,
        );
        break;
      case 'Currently Playing Episode':
        await commons.tryUntil(this.focusedWatchNow_btn, VRC.LEFT, 2);
        await commons.userAction(VRC.ENTER);
        await commons.waitTillVideoIsPlaying(20);
        await commons.userAction(VRC.BACK);
        break;
      case 'Next Episodes listed on Episode Landing Page':
        await commons.userAction(VRC.DOWN);
        await commons.assertExists(this.secondEpisode_tile, 10);
        break;
      case 'Episode Info Panel':
        await commons.assertExists(this.episodeInfo_lbl, 10);
        break;
      default:
        break;
    }
  };

  /**
   * The below function will verify Mylist rail present on Home Page
   *
   * @param {string} railName - rail name which is to be checked for
   * @param {boolean} railStatus - rail is expected or not
   */
  verifyMyListRailOnHomePage = async (railName, railStatus) => {
    if ((await commons.elementVisible(this.focusedForYou_lbl)) === false) {
      await menuPage.navigateToPage('Home');
    }
    await this.verifyRailPresent(railName, railStatus);
  };

  /**
   * The below function will verify metadata Show Description on ContinueWatching rail
   * is matching with the video played earlier
   */
  verifyContinueWatchingMetadata = async () => {
    await this.assertSelectorArray(
      this.focusedThumbnail,
      this.heroShowTitle,
      this.heroShowDescription,
    );
    const showDescrip = this.getShowDetails();

    const currentShowDescrip = await commons.fetchAttributeData(
      this.heroShowDescription,
      PROP.TEXT_CONTENT,
    );

    if (currentShowDescrip !== showDescrip)
      throw new Error(
        `Continue watching Rail Video metadata: '${currentShowDescrip}' didnot match with '${showDescrip}'`,
      );
  };

  // This Method remove Show from My List from Hoem Hero by clicking the MyList CTA
  removedShowFromMylistFromHomeHero = async () => {
    await menuPage.openMenu();
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.focusedForYou_lbl, 10);

    // Remove first hero tile from my list
    await commons.tryUntil(this.focusedWatchNow_btn, VRC.DOWN, 3, 1);
    await commons.userAction(VRC.RIGHT, 2);
    await commons.assertVisible(this.focusedMyList_btn, 5);
    await commons.assertExists(this.focusedRemoveFromMyListBtn_lbl, 5);
    await commons.userAction(VRC.SELECT);
    await commons.waitUntilVisible(this.toastMsg_lbl, 5);
    await commons.assertExists(this.focusedAddToMyListBtn_lbl, 5);
  };

  verifyContinueWatchingNotVisible = async () => {
    if ((await commons.elementVisible(this.focusedForYou_lbl)) === false) {
      await menuPage.navigateToPage('Home');
    }
    await this.verifyRailPresent(
      testdataHelper.getContent('homePage.continueWatching'),
      false,
    );
  };
}

module.exports = new HomePage();
