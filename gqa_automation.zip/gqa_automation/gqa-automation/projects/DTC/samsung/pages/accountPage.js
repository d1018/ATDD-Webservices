const { BasePage, remoteActions, testdataHelper } = require('./basePage');
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');

const commons = remoteActions;
const { VRC, PROP } = commons;

class AccountPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('accountPage', locator);
  }

  accountTitle_lbl = this.#getSelectorData('accountTitle_lbl');

  account_tab = this.#getSelectorData('account_tab');

  subscriptions_tab = this.#getSelectorData('subscriptions_tab');

  signIn_btn = this.#getSelectorData('signIn_btn');

  signUp_btn = this.#getSelectorData('signUp_btn');

  help_tab = this.#getSelectorData('help_tab');

  about_tab = this.#getSelectorData('about_tab');

  signOut_tab = this.#getSelectorData('signOut_tab');

  signOutBtn_lbl = this.#getSelectorData('signOutBtn_lbl');

  settings_tab = this.#getSelectorData('settings_tab');

  welcomeTitleForAnonymous = this.#getSelectorData('welcomeTitleForAnonymous');

  helpTabText = this.#getSelectorData('helpTabText');

  aboutTabText = this.#getSelectorData('aboutTabText');

  accountTabManageSubs_lbl = this.#getSelectorData('accountTabManageSubs_lbl');

  focusedAccountPage = this.#getSelectorData('focusedAccountPage');

  focusedSignOut_btn = this.#getSelectorData('focusedSignOut_btn');

  focusedAccountPage_tab = this.#getSelectorData('focusedAccountPage_tab');

  focusedSignOutConfirmationPage = this.#getSelectorData(
    'focusedSignOutConfirmationPage',
  );

  focusedSignOutConfirmation_btn = this.#getSelectorData(
    'focusedSignOutConfirmation_btn',
  );

  myListMenuListItem = this.getElementByPage('menuPage', 'myListMenuListItem');

  tvGuideMenuListItem = this.getElementByPage(
    'menuPage',
    'tvGuideMenuListItem',
  );

  accountPageSubMenu = {
    Subscription: this.subscriptions_tab,
    Settings: this.settings_tab,
    Account: this.accountTabManageSubs_lbl,
    Help: this.help_tab,
    About: this.about_tab,
    'Sign Out': this.signOut_tab,
  };

  getUserAccountMenuItems = (profileName) => {
    const accountType = {
      Anonymous: 'anonymousUserAccountItemListHwa',
      Default: 'defaultUserAccountItemListHwa',
      Kids: 'kidsUserAccountItemListHwa',
    };

    return testdataHelper.getContent(`accountPage.${accountType[profileName]}`);
  };

  verifyAccountSubNavigationPage = async (profileName) => {
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      await commons.waitUntil(this.accountPageSubMenu[accountMenuList[i]]);
      await this.accountSubNavigationPage(accountMenuList[i]);
      await commons.userAction(VRC.RIGHT, 1, 2);
    }
  };

  accountSubNavigationPage = async (tabName) => {
    switch (tabName) {
      case 'Account':
        if (this.getUserAnonymous()) {
          await commons.assertExists(this.welcomeTitle);
          await commons.assertExists(this.signIn_btn);
          await commons.assertExists(this.signUp_btn);
        } else await commons.assertExists(this.accountTabManageSubs_lbl);
        break;
      case 'Help Centre':
        await commons.assertExists(this.helpTabText);
        break;
      case 'About':
        await commons.assertExists(this.aboutTabText);
        break;
      case 'Sign Out':
        await commons.assertExists(this.signOutBtn_lbl);
        break;
      default:
        break;
    }
  };

  validateCtaAccountPage = async () => {
    await menuPage.navigateToPage('Account');
    await commons.assertExists(this.signIn_btn);
    await commons.assertExists(this.signUp_btn);
  };

  verifyAccountPage = async (profileName) => {
    await profilePage.selectProfile(profileName);

    await menuPage.navigateToPage('Account');
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      await commons.assertExists(this.accountPageSubMenu[accountMenuList[i]]);
    }
  };

  /**
   * The below function will navigate user Profile to required Account tab
   *
   * @param {string} profileName Provide the profile for which user is navigating to accounts page
   * @param {string} pageValue Provide the Accounts tab name to which user wants to navigate to
   */
  navigateThroughAccountTab = async (profileName, pageValue) => {
    await commons.assertExists(this.focusedAccountPage, 5);
    await commons.userAction(VRC.UP, 2);
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    const menuItemText = await commons.fetchAttributeData(
      this.focusedAccountPage_tab,
      PROP.TEXT_CONTENT,
    );

    const focusedIndex = accountMenuList.indexOf(menuItemText);
    const moveToIndex = accountMenuList.indexOf(pageValue);
    const difference = focusedIndex - moveToIndex;

    if (difference < 0)
      await commons.userAction(VRC.RIGHT, Math.abs(difference), 1);

    if (difference > 0) await commons.userAction(VRC.LEFT, difference, 1);

    await commons.assertExists(this.accountPageSubMenu[pageValue], 10);
    await this.accountSubNavigationPage(pageValue);
  };
}

module.exports = new AccountPage();
