const accountPage = require('./accountPage');
const homePage = require('./homePage');
const searchPage = require('./searchPage');
const signInPage = require('./signInPage');
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');
const showDetailsPage = require('./showDetailsPage');
const sportsPage = require('./sportsPage');
const networkLandingPage = require('./networkLandingPage');
const onboardingPage = require('./onboardingPage');
const welcomePage = require('./welcomePage');
const browsePage = require('./browsePage');
const myListPage = require('./myListPage');
const videoPlayerPage = require('./videoPlayerPage');

module.exports = {
  accountPage,
  homePage,
  searchPage,
  signInPage,
  menuPage,
  profilePage,
  showDetailsPage,
  sportsPage,
  networkLandingPage,
  onboardingPage,
  welcomePage,
  browsePage,
  myListPage,
  videoPlayerPage,
};
