const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;

const { VRC, PROP, COMP } = commons;

class WelcomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('welcomePage', locator);
  }

  focusedWelcomePageSignIn_btn = this.#getSelectorData('focusedSignIn_btn');

  welcomePageSignIn_btn = this.#getSelectorData('signIn_btn');

  focusedSubscribeNow_btn = this.#getSelectorData('focusedSubscribeNow_btn');

  subscribeNow_btn = this.#getSelectorData('subscribeNow_btn');

  welcomepage = this.#getSelectorData('welcomeScreen');

  welcomeTitle_lbl = this.#getSelectorData('welcomeTitle_lbl');

  chooseYourPlan_lbl = this.getElementByPage(
    'planPickerPage',
    'chooseYourPlan_lbl',
  );

  userName_txtBx = this.getElementByPage('signInPage', 'userName_txtBx');

  password_txtBx = this.getElementByPage('signInPage', 'password_txtBx');

  signIn_btn = this.getElementByPage('signInPage', 'signIn_btn');

  privacyMsgAccept_btn = this.#getSelectorData('privacyMsgAccept_btn');

  verifyWelcomeScreen = async () => {
    await commons.assertVisible(this.welcomepage, 10);
    await this.verifyWelcomeScreenLocalizedMetadata();
  };

  verifyWelcomeScreenLocalizedMetadata = async () => {
    await commons.assertVisible(this.focusedSubscribeNow_btn, 10);
    await commons.assertVisible(this.welcomeTitle_lbl, 5);
    await commons.assertVisible(this.subscribeNow_btn, 5);
    await commons.assertProperty(
      this.welcomePageSignIn_btn,
      PROP.TEXT_CONTENT,
      testdataHelper.getContent(`welcomePage.signInBtn`),
      COMP.EQUAL,
    );
  };

  verifyLandingPageOfWelcomeScreen = async (CTAName) => {
    await commons.assertVisible(this.welcomepage, 10);
    if (CTAName === 'Subscribe Now') {
      await commons.navigateTo(this.focusedSubscribeNow_btn, VRC.UP, 2);
      await commons.assertVisible(this.chooseYourPlan_lbl, 10);
    } else if (CTAName === 'Sign In') {
      await commons.navigateTo(this.focusedWelcomePageSignIn_btn, VRC.DOWN, 2);
      await commons.assertVisible(this.userName_txtBx, 10);
      await commons.assertVisible(this.password_txtBx, 1);
      await commons.assertVisible(this.signIn_btn, 1);
    }
    await commons.tryUntil(this.welcomepage, VRC.BACK, 2, 5);
    await commons.assertVisible(this.welcomepage, 10);
  };
}
module.exports = new WelcomePage();
