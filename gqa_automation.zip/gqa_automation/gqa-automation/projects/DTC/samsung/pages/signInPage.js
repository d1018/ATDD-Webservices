const retry = require('async-retry');
const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');
const welcomePage = require('./welcomePage');

const { VRC } = commons;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  signInWithEmail_btn = this.getElementByPage(
    'activationPage',
    'signInWithEmail_btn',
  );

  focusedSignInWithEmail_btn = this.getElementByPage(
    'activationPage',
    'focusedSignInWithEmail_btn',
  );

  signIn_btn = this.#getSelectorData('signIn_btn');

  focusedSignIn_btn = this.#getSelectorData('focusedSignIn_btn');

  focusedAccountSignIn_btn = this.getElementByPage(
    'accountPage',
    'focusedSignIn_btn',
  );

  accountSignIn_btn = this.getElementByPage('accountPage', 'signIn_btn');

  focusedUserName_txtBx = this.#getSelectorData('focusedUserName_txtBx');

  focusedPassword_txtBx = this.#getSelectorData('focusedPassword_txtBx');

  userName_txtBx = this.#getSelectorData('userName_txtBx');

  password_txtBx = this.#getSelectorData('password_txtBx');

  focusedProfile = this.getElementByPage('profilePage', 'focusedProfile');

  myListMenuListItem = this.getElementByPage('menuPage', 'myListMenuListItem');

  focusedSignOut_btn = this.getElementByPage(
    'accountPage',
    'focusedSignOut_btn',
  );

  signOutConfirmation_btn = this.getElementByPage(
    'accountPage',
    'signOutConfirmation_btn',
  );

  focusedsignOut_tab = this.getElementByPage(
    'accountPage',
    'focusedsignOut_tab',
  );

  tvGuideMenuListItem = this.getElementByPage(
    'menuPage',
    'tvGuideMenuListItem',
  );

  noSubscriptionTitle_lbl = this.getElementByPage(
    'inactiveSubscriptionPage',
    'noSubscriptionTitle_lbl',
  );

  openApp = async () => {
    await commons.openApp();
    await commons.clearAppData();
    if (this.returnGeoLocation() === 'america') {
      await commons.assertVisible(welcomePage.welcomepage, 60);
    } else {
      await commons.assertVisible(this.focusedHomePage, 60);
    }
  };

  isLoggedIn = async () => {
    if (
      (await commons.elementExists(this.myListMenuListItem)) ||
      (await commons.elementExists(this.focusedProfile))
    ) {
      if (await commons.elementExists(this.focusedProfile, 10))
        await profilePage.selectProfile('root');
    }
  };

  navigateToSignInFromWelcome = async () => {
    await retry(
      async () => {
        if (await commons.elementExists(welcomePage.privacyMsgAccept_btn, 1)) {
          await commons.userAction(VRC.SELECT);
        }
      },
      { retries: 3 },
    );
    await commons.waitUntil(welcomePage.welcomepage, 10);
    await commons.navigateTo(
      welcomePage.focusedWelcomePageSignIn_btn,
      VRC.DOWN,
      2,
      1,
    );
    await commons.assertVisible(this.userName_txtBx, 30);
  };

  navigateToSignInFromAccount = async () => {
    await commons.waitUntil(this.accountSignIn_btn, 10);
    await commons.tryUntil(this.focusedAccountSignIn_btn, VRC.DOWN, 2, 1);
    await commons.userAction(VRC.ENTER);
    await commons.tryUntil(this.focusedSignInWithEmail_btn, VRC.DOWN, 2, 1);
    await commons.userAction(VRC.ENTER);
    await commons.waitUntil(this.userName_txtBx, 10);
  };

  enterCredentials = async (credentialType) => {
    const username = process.env[`${credentialType}_USERNAME`];
    const password = process.env[`${credentialType}_PASSWORD`];

    // selecting the password field and entering password
    await commons.assertExists(this.userName_txtBx);
    await commons.assertVisible(this.focusedUserName_txtBx, 5);
    await commons.userAction(VRC.ENTER, 1, 2);
    await commons.sendText(username);
    await commons.userAction(VRC.BACK, 1, 2);
    await commons.waitUntilVisible(this.signIn_btn, 10);
    // selecting the password field and entering password
    await commons.userAction(VRC.DOWN);
    await commons.assertExists(this.password_txtBx);
    await commons.tryUntil(this.focusedPassword_txtBx, VRC.DOWN, 2, 2);
    await commons.userAction(VRC.ENTER, 1, 2);
    await commons.sendText(password);
    await commons.userAction(VRC.BACK, 1, 2);
    await commons.waitUntilVisible(this.signIn_btn, 10);
    await commons.navigateTo(this.focusedSignIn_btn, VRC.DOWN, 3, 2);
  };

  loginToApplication = async (credentialType) => {
    if (credentialType !== 'anonymous') {
      if (this.returnGeoLocation() === 'america')
        await this.navigateToSignInFromWelcome();
      else if (this.returnGeoLocation() === 'emea') {
        await menuPage.navigateToPage('Account');
        await this.navigateToSignInFromAccount();
      }
      await this.enterCredentials(credentialType);
      if (credentialType === 'DTC_LAPSED') {
        await commons.waitUntil(this.noSubscriptionTitle_lbl, 20);
      } else if (credentialType === ('DTC_SINGLE_PROFILE' || 'DTC_VALID')) {
        await commons.waitUntil(this.focusedHomePage, 20);
      } else {
        await commons.waitUntilVisible(this.focusedProfile, 20);
        await commons.userAction(VRC.ENTER);
      }
      this.setUserAnonymous(false);
    }
  };

  navigateToSignInScreen = async () => {
    if (await commons.elementVisible(welcomePage.welcomepage)) {
      await this.navigateToSignInFromWelcome();
    } else if (await commons.elementVisible(this.accountSignIn_btn)) {
      await this.navigateToSignInFromAccount();
    } else if (await commons.elementExists(this.signInWithEmail_btn)) {
      await commons.tryUntil(this.focusedSignInWithEmail_btn, VRC.DOWN, 2, 1);
      await commons.userAction(VRC.ENTER);
      await commons.waitUntilVisible(this.userName_txtBx, 10);
    }
  };

  verifySignOut = async () => {
    await commons.assertExists(this.signIn_btn, 30);
  };
}
module.exports = new SignInPage();
