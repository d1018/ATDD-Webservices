const { ok } = require('assert');
const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const { VRC, PROP } = commons;

class VideoPlayerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('videoPlayerPage', locator);
  }

  videoPlayerScene = this.#getSelectorData('videoPlayerScene');

  currentTime_lbl = this.#getSelectorData('currentTime_lbl');

  progressBar = this.#getSelectorData('progressBar');

  skipIntro_btn = this.#getSelectorData('skipIntro_btn');

  playerPlay_btn = this.#getSelectorData('playerPlay_btn');

  playBackError = this.#getSelectorData('playBackError');

  showHeroImage = this.getElementByPage('showPage', 'showHeroImage');

  showDescription_txt = this.getElementByPage(
    'showPage',
    'showDescription_txt',
  );

  /**
   * The Scrubbing of Video in HWA is not working so we are playing the video for provided time
   * saving the video position before navigating back to show details Page
   *
   * @param {string} percentage Here was take the percentage in string for the number of seconds * 2 we play video
   */
  scrubVideo = async (percentage) => {
    if (await commons.elementVisible(this.playBackError, 2)) {
      throw new Error('There was a playBack Error shown on screen');
    }
    await commons.assertVideoIsPlaying(40);
    // as hard wait/sleep is not allowed so waiting for an element which will never be shown
    await commons.elementVisible(
      this.showDescription_txt,
      Number(percentage) * 2,
    );
    await commons.userAction(VRC.PAUSE);
    const video = await commons.videoDetails();

    this.videoPosition = video.videoPos / 1000;
    await commons.userAction(VRC.BACK);
    // adding for stability
    await commons.tryUntil(this.showHeroImage, VRC.BACK, 2, 10);
    await commons.assertExists(this.showDescription_txt);
    const showName = await commons.fetchAttributeData(
      this.showDescription_txt,
      PROP.TEXT_CONTENT,
    );

    this.setShowDetails(showName);
  };

  /**
   * This method will check the video Resume points matches with the video position
   * after the video is scrubbed to a percentage and its closed
   *
   * @param {string} percentage Here was take the percentage in string for the number of seconds we play video
   */
  validateResumePoint = async (percentage) => {
    const video = await commons.videoDetails();
    const newVideoPosition = video.videoPos / 1000;

    ok(
      newVideoPosition <= this.videoPosition + 20 &&
        newVideoPosition >= this.videoPosition - 20,
      `${percentage}% - Actual: ${newVideoPosition} sec, Expected: ${this.videoPosition} sec didnot match`,
    );
  };
}

module.exports = new VideoPlayerPage();
