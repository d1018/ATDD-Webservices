const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const homePage = require('./homePage');

const { VRC } = commons;

class ShowDetailsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('showPage', locator);
  }

  showHeroImage = this.#getSelectorData('showHeroImage');

  focusedShowDetailPage = this.#getSelectorData('focusedShowDetailPage');

  myList_btn = this.#getSelectorData('myList_btn');

  focusedMyListChecked = this.#getSelectorData('focusedMyListChecked');

  focusedMyListUnchecked = this.#getSelectorData('focusedMyListUnchecked');

  forYou_lbl = this.getElementByPage('homePage', 'forYou_lbl');

  trueCrime_lbl = this.getElementByPage('homePage', 'trueCrime_lbl');

  focusedWatchNow_btn = this.#getSelectorData('focusedWatchNow_btn');

  showDetailsPage = this.#getSelectorData('showDetailsPage');

  showDescription_txt = this.#getSelectorData('showDescription_txt');

  episodesList = {
    1: this.#getSelectorData('firstEpisode'),
  };

  thumbnailOnSearch = this.getElementByPage('searchPage', 'thumbnailOnSearch');

  focusedFirstThumbnailOnSearch = this.getElementByPage(
    'searchPage',
    'focusedFirstThumbnailOnSearch',
  );

  selectAndPlayVideo = async (videoNumber) => {
    await commons.assertVisible(
      this.getCustomLocator(this.thumbnailOnSearch, videoNumber),
      10,
    );
    if (await commons.doesNotExist(this.focusedFirstThumbnailOnSearch, 1)) {
      await commons.tryUntil(
        this.focusedFirstThumbnailOnSearch,
        VRC.DOWN,
        3,
        1,
      );
    }
    await commons.assertVisible(this.focusedFirstThumbnailOnSearch, 5);
    await commons.userAction(VRC.SELECT);
    // adding for stability
    await commons.tryUntil(this.focusedWatchNow_btn, VRC.SELECT, 2, 10);
    await commons.assertVisible(this.focusedWatchNow_btn);
    await commons.userAction(VRC.SELECT);
  };

  verifyShowLandingAnchorDetails = async () => {
    await commons.assertExists(this.focusedShowDetailPage);
  };

  verifyShowLandingPage = async (ctaName) => {
    switch (ctaName) {
      case 'Watch Now CTA':
        await commons.waitUntil(this.focusedWatchNow_btn, 10);
        await commons.userAction(VRC.SELECT);
        await commons.waitTillVideoIsPlaying(45);
        await commons.userAction(VRC.BACK);
        break;
      case 'My List CTA':
        await commons.waitUntil(this.myList_btn, 5);
        await commons.tryUntil(this.focusedMyListUnchecked, VRC.RIGHT, 4, 1);
        await commons.assertExists(this.focusedMyListUnchecked, 5);
        await commons.userAction(VRC.SELECT);
        await commons.assertExists(this.focusedMyListChecked, 10);
        break;
      default:
        throw new Error('Failed to verify show landing page');
    }
  };

  validateCTAonGenres = async (userType, genreNames) => {
    await commons.assertExists(this.forYou_lbl, 5);
    const genreNameList = genreNames.raw();

    for (let i = 0; i < genreNameList.length; i++) {
      const genreName = genreNameList[i].toString();

      if (genreName === 'Crime') {
        await commons.tryUntil(this.trueCrime_lbl, 'RIGHT', 2, 5);
        await commons.assertExists(this.trueCrime_lbl, 5);
      }
      await commons.tryUntil(this.focusedWatchNow_btn, 'DOWN', 3, 1);
      await commons.assertExists(this.focusedWatchNow_btn, 5);
      await commons.userAction(VRC.SELECT);
      switch (userType) {
        case 'new-profile':
          await homePage.validateCTAonShowPage();
          await commons.assertVideoIsPlaying();
          break;
        default:
          break;
      }
      await commons.userAction(VRC.BACK, 2);
      await commons.userAction(VRC.UP);
      await commons.assertExists(this.forYou_lbl, 5);
    }
  };
}

module.exports = new ShowDetailsPage();
