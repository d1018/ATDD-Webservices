const assert = require('assert');

const { BasePage, remoteActions } = require('./basePage');
const menuPage = require('./menuPage');

const commons = remoteActions;
const { VRC } = commons;

class BrowsePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('browsePage', locator);
  }

  focusedBrowsePage = this.#getSelectorData('focusedBrowsePage');

  focusedNetwork_tab = this.#getSelectorData('focusedNetwork_tab');

  allNetwork_tab = this.#getSelectorData('allNetwork_tab');

  focusedAllNetwork_tab = this.#getSelectorData('focusedAllNetwork_tab');

  focusedTlcNetwork_tab = this.#getSelectorData('focusedTlcNetwork_tab');

  subNav_tab = this.#getSelectorData('subNav_tab');

  focusedSubNav_tab = this.#getSelectorData('focusedSubNav_tab');

  firstSubNav_tab = this.#getSelectorData('firstSubNav_tab');

  focusedFirstSubNav_tab = this.#getSelectorData('focusedFirstSubNav_tab');

  focusedShowCard = this.#getSelectorData('focusedShowCard');

  firstShowCard = this.#getSelectorData('firstShowCard');

  focusedShowTitle = this.#getSelectorData('focusedShowTitle');

  focusedShow_img = this.#getSelectorData('focusedShow_img');

  focusedShowNetworkLogo_img = this.#getSelectorData(
    'focusedShowNetworkLogo_img',
  );

  /**
   * The below function will select a page from global Navigation menu
   *
   * @param {string} pageType will select a page
   */

  selectPage = async (pageType) => {
    if (this.countryCode === 'us' && pageType === 'Browse') {
      await menuPage.navigateToPage(pageType);
    } else await menuPage.navigateToPage(pageType);
  };

  /**
   * This method will validate the browse page network and subnav tabs
   *
   */

  verifyBrowsePage = async () => {
    await commons.waitUntilVisible(this.focusedBrowsePage, 10);
    await commons.assertVisibleSelectorArray([
      this.focusedBrowsePage,
      this.focusedNetwork_tab,
      this.subNav_tab,
      this.focusedAllNetwork_tab,
    ]);
  };

  moveFocusToAllNetworkTab = async () => {
    await commons.tryUntil(this.focusedNetwork_tab, 'UP', 5, 1);
    await commons.tryUntil(this.focusedAllNetwork_tab, 'LEFT', 5, 1);
    await commons.userAction('ENTER');
    await commons.assertVisible(this.firstShowCard, 10);
  };

  moveFocusToTlcNetworkTab = async () => {
    await commons.tryUntil(this.focusedTlcNetwork_tab, 'RIGHT', 5, 1);
    await commons.userAction('ENTER');
    await commons.assertVisible(this.firstShowCard, 10);
  };
  /**
   * The below function will select a network from the network rail in browse page and validate network and subnav are shown
   *
   * @param {string} networkType will select a network
   */

  selectNetwork = async (networkType) => {
    if (this.countryCode === 'us' && networkType === 'Entertainment') {
      await this.moveFocusToAllNetworkTab();
      await this.moveFocusToTlcNetworkTab();
    }
  };

  /**
   * The below function will verify show on selected network
   */

  verifyShowOnSelectedNetwork = async () => {
    await commons.waitUntil(this.firstShowCard, 10);
  };

  /**
   * The below function will capture default firstshowname and will navigate trice right to other SubNav tab
   *
   * @param {string} subNav will select subNav menu item
   */

  selectSubNav = async (subNav) => {
    if (this.countryCode === 'us' && subNav === 'first') {
      await commons.tryUntil(this.focusedFirstSubNav_tab, 'DOWN', 2, 1);
      await commons.userAction('ENTER');
    }
  };

  selectAsset = async () => {
    await commons.userAction(VRC.DOWN, 1, 10);
    await commons.userAction(VRC.OK);
  };
  /**
   * This method will validate the current name doesnot match firstshowname
   * This will assert the Show Title, Network Logo and Image
   */

  verifyShowCard = async () => {
    await commons.waitUntil(this.firstShowCard, 10);
    await commons.tryUntil(this.focusedShowCard, 'DOWN', 3, 1);
    assert(
      (await commons.elementExists(this.focusedShowTitle, 2)) &&
        (await commons.elementExists(this.focusedShow_img, 2)) &&
        (await commons.elementExists(this.focusedShowNetworkLogo_img, 2)),
      `Show Title, Network Logo and Image are not displayed`,
    );
  };
}

module.exports = new BrowsePage();
