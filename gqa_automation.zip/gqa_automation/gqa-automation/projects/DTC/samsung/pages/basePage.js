const path = require('path');
const { remoteActions, testdataHelper } = require('@wbd/gqa-core/support');

const ymlpath = path.resolve(__dirname);
const commons = remoteActions;

const EnvBase = require('../../../support/env');

let isUserAnonymousType;
let isUserKidsType;
let showName;

class BasePage extends EnvBase {
  constructor() {
    super(ymlpath);
  }

  setUserAnonymous(boolean) {
    isUserAnonymousType = boolean;
  }

  getUserAnonymous() {
    return isUserAnonymousType;
  }

  setUserTypeKids(boolean) {
    isUserKidsType = boolean;
  }

  getUserTypeKids() {
    return isUserKidsType;
  }

  setShowDetails(string) {
    showName = string;
  }

  getShowDetails() {
    return showName;
  }

  /**
   * this Method accepts Property Type and Locator with indexes to iterate and Return an Array of locator properties
   *
   * @param {Element} locator Here we provide the locator with indexes to get the property value
   * @param {string} property fetches the property value type as mentioned
   * @returns {Array}  returns an array of fetched property value for the provided locator for all Indexes
   */
  arrayOfSelectorProperty = async (locator, property) => {
    const propertyArray = [];

    for (let i = 1; i <= 50; i++) {
      if (await commons.doesNotExist(this.getCustomLocator(locator, i), 1)) {
        break;
      }
      const locatorProperty = await commons.fetchAttributeData(
        this.getCustomLocator(locator, i),
        property,
      );

      propertyArray.push(locatorProperty);
    }
    return propertyArray;
  };

  /**
   * This Method accepts Locators in an array and validates if those locators exists on the screen or not
   *
   * @param {...any} selectorArray Provide an array of Locators which needs to be assert for existance
   */
  assertSelectorArray = async (...selectorArray) => {
    const fails = [];
    const promises = selectorArray.map(async (element) => {
      try {
        await commons.assertExists(element);
      } catch (error) {
        fails.push(error);
      }
    });

    await Promise.all(promises);
    if (fails.length > 0) {
      throw new Error(
        `assertSelectorArray: seletor not available showing error ${JSON.stringify(
          fails,
          null,
          2,
        )}`,
      );
    }
  };
}

module.exports = {
  remoteActions,
  testdataHelper,
  BasePage,
};
