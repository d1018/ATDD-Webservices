const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const menuPage = require('./menuPage');

const { VRC, PROP, COMP } = commons;
let profileLocalName;
let numberofProfilesPreDeletion;
let kidsFlag = false;

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  focusedProfilePage = this.#getSelectorData('focusedProfilePage');

  focusedProfile = this.#getSelectorData('focusedProfile');

  focusedFirstProfile = this.#getSelectorData('focusedFirstProfile');

  kidsProfileMsg = this.#getSelectorData('kidsProfileMsg');

  focusedProfileName = this.#getSelectorData('focusedProfileName');

  focusedProfileSave_btn = this.#getSelectorData('focusedProfileSave_btn');

  profileLock_img = this.#getSelectorData('profileLock_img');

  dynamicPinPad_txtBx = this.#getSelectorData('dynamicPinPad_txtBx');

  addProfile_btn = this.#getSelectorData('addProfile_btn');

  disabledSave_btn = this.#getSelectorData('disabledSave_btn');

  focusedAddProfile_btn = this.#getSelectorData('focusedAddProfile_btn');

  deleteProfile_btn = this.#getSelectorData('deleteProfile_btn');

  focusedDeleteProfile_btn = this.#getSelectorData('focusedDeleteProfile_btn');

  focusedDeleteConfirmation_btn = this.#getSelectorData(
    'focusedDeleteConfirmation_btn',
  );

  focusedCancelConfirmation_btn = this.#getSelectorData(
    'focusedCancelConfirmation_btn',
  );

  profileName_txtBx = this.#getSelectorData('profileName_txtBx');

  focusedProfileName_txtBx = this.#getSelectorData('focusedProfileName_txtBx');

  editProfilePage = this.#getSelectorData('editProfilePage');

  focusedProfileCancel_btn = this.#getSelectorData('focusedProfileCancel_btn');

  kidsProfileToggle = this.#getSelectorData('kidsProfileToggle');

  kidsProfileToggleSelected = this.#getSelectorData(
    'kidsProfileToggleSelected',
  );

  profileCreationError_txt = this.#getSelectorData('profileCreationError_txt');

  profileList = this.#getSelectorData('profileList');

  focusedProfileByName = this.#getSelectorData('focusedProfileByName');

  profilePinCode1_txtBx = this.#getSelectorData('profilePinCode1_txtBx');

  profileName = this.#getSelectorData('profileName');

  focusedForYou_lbl = this.getElementByPage('homePage', 'focusedForYou_lbl');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  focusedMenuBar = this.getElementByPage('menuPage', 'focusedMenuBar');

  focusedManageProfiles_lbl = this.getElementByPage(
    'menuPage',
    'focusedManageProfiles_lbl',
  );

  navigateToProfile = async (profileName) => {
    await this.moveToFirstProfile();
    for (let i = 0; i < 5; i++) {
      if (await this.verifyFocusedProfileName(profileName)) {
        const requiredProfile = await commons.checkProperty(
          this.focusedProfileName,
          PROP.TEXT_CONTENT,
          profileName,
          COMP.CONTAIN,
        );

        if (requiredProfile) {
          await commons.assertVisible(this.focusedProfile, 2);
          if (profileName.toLowerCase().includes('kids')) {
            await commons.userAction(VRC.DOWN);
            await commons.userAction(VRC.ENTER);

            if (await commons.elementExists(this.kidsProfileMsg)) {
              this.setUserTypeKids(true);
              kidsFlag = true;
            }
            await commons.userAction(VRC.BACK);
          }
          return;
        }
        break;
      } else if (i === 4) {
        throw new Error(`Profile: ${profileName} doesnot exist`);
      }
      await commons.userAction(VRC.RIGHT, 1);
    }
  };

  navigateToProfilePickerScreen = async () => {
    if (await commons.doesNotExist(this.focusedProfileName, 10)) {
      await menuPage.openMenu();
      await commons.tryUntil(menuPage.focusedManageProfiles_lbl, VRC.UP, 8, 1);
      await commons.userAction(VRC.ENTER);
    }
    await commons.assertExists(this.focusedProfileName, 10);
  };

  selectProfile = async (profileName) => {
    await this.navigateToProfilePickerScreen();
    await this.navigateToProfile(profileName);
    await commons.userAction(VRC.ENTER);
  };

  /**
   * Check the focused profile name , compare with name provided and return boolean response.
   *
   * @param {string} profileName profile name we want to check.
   * @returns {boolean} boolean value.
   */
  verifyFocusedProfileName = async (profileName) => {
    await commons.assertVisible(this.focusedProfile, 15);
    const currentProfileName = await commons.fetchAttributeData(
      this.focusedProfileName,
      PROP.TEXT_CONTENT,
    );

    if (currentProfileName.toLowerCase() === profileName.toLowerCase()) {
      return true;
    }
    return false;
  };

  deleteProfileFromDeleteCta = async () => {
    await commons.waitUntilVisible(this.focusedCancelConfirmation_btn, 5);
    await commons.tryUntil(this.focusedDeleteConfirmation_btn, 'UP', 3, 1);
    await commons.userAction(VRC.SELECT);
    await commons.waitUntilVisible(this.focusedProfilePage, 5);
  };

  deleteSelectedProfile = async () => {
    const elementArraylist = await this.arrayOfSelectorProperty(
      this.profileList,
      PROP.TEXT_CONTENT,
    );

    numberofProfilesPreDeletion = await elementArraylist.length;

    for (let i = 0; i < 5; i++) {
      await this.navigateToEditProfile();
      if (await commons.elementVisible(this.deleteProfile_btn, 2)) {
        await commons.navigateTo(this.focusedDeleteProfile_btn, VRC.UP, 5);
        await this.deleteProfileFromDeleteCta();
        break;
      } else {
        await commons.userAction(VRC.BACK);
        await commons.assertExists(this.focusedProfilePage, 5);
        await commons.tryUntil(this.focusedProfileName, VRC.UP, 3);
        await commons.userAction(VRC.RIGHT);
        await commons.waitUntilVisible(this.focusedProfileName, 5);
        if (
          await commons.checkProperty(
            this.focusedProfileName,
            PROP.TEXT_CONTENT,
            'Add Profile',
            COMP.EQUAL,
          )
        ) {
          throw new Error('None of the Profile has Delete Profile CTA');
        }
      }
    }
  };

  moveToFirstProfile = async () => {
    await commons.assertExists(this.focusedProfilePage, 10);
    await commons.tryUntil(this.focusedFirstProfile, VRC.LEFT, 4);
  };

  deleteProfileIfAddButtonNotShown = async () => {
    for (let i = 0; i < 5; i++) {
      if (await commons.elementExists(this.addProfile_btn)) {
        break;
      }
      await this.deleteSelectedProfile();
    }
  };

  clearTextBoxAndEnterData = async (text) => {
    await commons.userAction(VRC.SELECT);
    await commons.sendText(text);
    await commons.userAction(VRC.BACK);
  };

  createNewProfile = async (profileName) => {
    const dateObject = new Date();
    const localeDate = dateObject.toLocaleDateString();
    const localeTime = dateObject.toLocaleTimeString();

    profileLocalName = String(
      `${profileName}_${process.env.DEVICE}_${localeTime}_${localeDate}`,
    );

    if (profileLocalName.length > 30) {
      profileLocalName = profileLocalName.substring(0, 30);
    }
    await commons.assertVisible(this.focusedProfilePage, 5);
    await this.deleteProfileIfAddButtonNotShown();
    await commons.assertVisible(this.addProfile_btn);
    await commons.navigateTo(this.focusedAddProfile_btn, VRC.RIGHT, 5, 1);
    await commons.assertVisible(this.editProfilePage, 5);
    await commons.tryUntil(this.focusedProfileName_txtBx, VRC.UP, 3);
    await this.clearTextBoxAndEnterData(profileLocalName);
    if (profileName === 'Kids') {
      await commons.userAction(VRC.DOWN);
      await commons.navigateTo(this.kidsProfileToggleSelected, VRC.UP, 2, 1);
      const kidsProfileBtn = await commons.fetchAttributeData(
        this.kidsProfileToggle,
        PROP.TEXT_CONTENT,
      );

      if (kidsProfileBtn.toLowerCase() !== 'on')
        throw new Error('Kids profile is not activated');
    }
    await commons.userAction(VRC.DOWN, 2);
    await commons.navigateTo(this.focusedProfileSave_btn, VRC.RIGHT, 2);
  };

  createNewProfileandSelect = async (profileName) => {
    await this.profileCreation(profileName);
  };

  selectPinProfile = async (profileName) => {
    await this.moveToFirstProfile();
    await commons.assertVisible(this.profileLock_img, 5);
    await commons.navigateTo(
      this.getCustomLocator(this.focusedProfileByName, profileName),
      VRC.RIGHT,
      5,
      1,
    );
    await commons.assertExists(this.dynamicPinPad_txtBx, 3);
    await commons.userAction(VRC.SELECT, 4);
    await commons.assertExists(this.focusedForYou_lbl, 10);

    this.pinProfile = profileName;
  };

  profileCreation = async (profileName) => {
    await this.navigateToProfilePickerScreen();
    if (profileName === 'Pin') {
      // Creation of pin profile is applicable in Web Only so selecting for Hwa
      await this.selectPinProfile(profileName);
    } else {
      await this.createNewProfile(profileName);
      if (!(await commons.elementVisible(this.focusedProfile, 15))) {
        if (await commons.elementVisible(this.profileCreationError_txt, 2)) {
          await commons.userAction(VRC.BACK);
          await this.createNewProfile(profileName);
        }
      }
      if ((await this.verifyFocusedProfileName(profileLocalName)) === false) {
        await this.navigateToProfilePickerScreen();
        if (
          await commons.doesNotExist(
            this.getCustomLocator(this.profileName, profileLocalName),
          )
        ) {
          throw new Error(
            `Profile is not created with name ${profileLocalName}`,
          );
        }
        await this.navigateToProfile(profileLocalName);
      }
      await this.moveToHomePage();
    }
  };

  deleteProfile = async (profileName = 'random') => {
    await this.navigateToProfilePickerScreen();
    if (profileName !== 'random') {
      await this.navigateToProfile(profileName);
      // This will check if its Kids profile then move to default profile so that we can delete any profile
      if (kidsFlag === true) {
        await this.navigateToProfile('Default');
        await commons.userAction(VRC.SELECT);
        await commons.assertVisible(this.focusedHomePage, 10);
        await this.navigateToProfilePickerScreen();
      }
    } else if (profileName === 'random') {
      const elementArraylist = await this.arrayOfSelectorProperty(
        this.profileList,
        PROP.TEXT_CONTENT,
      );
      const x = elementArraylist.length;

      if (x < 2) {
        await this.createNewProfile(profileName);
      }
    }
    await this.deleteSelectedProfile();
    if (
      await commons.elementExists(
        this.getCustomLocator(this.profileName, profileName),
      )
    ) {
      throw new Error(`Profile is not deleted with name ${profileName}`);
    }
  };

  deleteExistingProfile = async () => {
    if (this.pinProfile !== 'Pin') {
      await this.navigateToProfilePickerScreen();
      await this.moveToFirstProfile();
      await this.deleteProfile(profileLocalName);
    }
  };

  verifyUserProfileDeleted = async () => {
    const elementArraylist = await this.arrayOfSelectorProperty(
      this.profileList,
      PROP.TEXT_CONTENT,
    );

    if (!(elementArraylist.length < numberofProfilesPreDeletion)) {
      throw new Error('Profile has not been deleted');
    }
  };

  moveToHomePage = async () => {
    if (await commons.elementExists(menuPage.cancel_btn, 1)) {
      await commons.userAction(VRC.BACK);
    }
    if (await commons.elementExists(this.focusedProfile)) {
      await commons.assertExists(this.focusedProfilePage, 10);
      while (
        await commons.checkProperty(
          this.focusedProfile,
          PROP.INDEX,
          0,
          COMP.NOT_EQUAL,
        )
      ) {
        await commons.userAction(VRC.LEFT);
      }
      await commons.assertExists(this.focusedProfile, 5);
      await commons.userAction(VRC.SELECT);
    } else if ((await commons.elementExists(this.focusedHomePage)) === false) {
      await menuPage.navigateToPage('Home');
      await commons.assertExists(this.focusedHomePage, 10);
    }
  };

  changeProfileName = async (name) => {
    if (name === '') {
      await commons.assertExists(this.focusedProfileName_txtBx);
      await commons.userAction(VRC.SELECT);
      await commons.sendText('');
      await commons.userAction(VRC.BACK);
      await commons.assertExists(this.disabledSave_btn);
    } else if (name === 'ThisIsANameThatIsLongerThanThirtyCharacters') {
      await commons.tryUntil(this.focusedAddProfile_btn, VRC.RIGHT, 4);
      await commons.assertExists(this.focusedProfileName_txtBx, 2);
      await commons.userAction(VRC.SELECT);
      await commons.sendText(name);
      await commons.assertProperty(
        this.profileCreationError_txt,
        PROP.TEXT_CONTENT,
        testdataHelper.getContent('editProfileLander.inLineErrorSamsung'),
        COMP.EQUAL,
      );
    } else if (name === 'Default') {
      await this.createNewProfile(name);
      await commons.assertDoesNotExist(this.profileCreationError_txt);
    }

    await commons.tryUntil(this.focusedProfilePage, VRC.BACK, 3);
  };

  verifyEditProfilePage = async () => {
    await commons.assertVisible(this.profileName_txtBx, 10);
  };

  navigateToEditProfile = async () => {
    await commons.assertExists(this.focusedProfileName, 5);
    // focusedEditProfile_btn is not getting recognised because the locator is getting duplicated
    await commons.userAction(VRC.DOWN, 2);
    await commons.userAction(VRC.ENTER);
    await commons.assertVisible(this.profileName_txtBx, 10);
  };

  moveToAddProfileAndSelect = async () => {
    await commons.assertExists(this.focusedProfilePage, 5);
    await commons.assertExists(this.addProfile_btn);
    await commons.tryUntil(this.focusedAddProfile_btn, VRC.RIGHT, 4);
    await commons.assertExists(this.focusedAddProfile_btn);
    await commons.userAction(VRC.SELECT);
  };

  selectProfileToManage = async () => {
    await this.navigateToManageProfiles();
    await this.moveToFirstProfile();
    await this.deleteProfileIfAddButtonNotShown();
    await this.moveToAddProfileAndSelect();
  };

  navigateToManageProfiles = async () => {
    await this.navigateToProfilePickerScreen();
  };
}

module.exports = new ProfilePage();
