const geo = ['US', 'Us', 'us'].includes(process.env.GEO) ? '' : process.env.GEO;
const project = process.env.BS_PROJECT || 'iOS Project';
const name = process.env.NAME || 'iOS Test';
const build = process.env.BUILD || 'iOS testing';
const debug = process.env.DEBUG || true;
const osVersion = process.env.OS_VERSION || '15';
const device = process.env.DEVICE_NAME || 'iPad 9th';
const app = process.env.APP || 'bs://b083d84f9c94a8ecadfbfeefc758aa7fb134e710';
const bsLocal = process.env.BS_LOCAL || false;
const locale = process.env.BS_LOCALE || 'en_US';
const autoAcceptAlerts = process.env.AUTO_ACCEPT_ALERTS || false;
const localExecution = process.env.LOCAL_EXECUTION || false;

const iPadCapabilities = {
  'browserstack.user': process.env.BS_USER,
  'browserstack.key': process.env.BS_KEY,
  device,
  os_version: osVersion,
  platformName: 'IOS',
  automationName: 'XCUITest',
  locale,
  app,
  name,
  build,
  project,
  chromeOptions: { w3c: false },
  allowInvisibleElements: 'true',
  'browserstack.debug': debug,
  'browserstack.appium_version': '1.21.0',
  'browserstack.networkLogs': 'true',
  'browserstack.appProfiling': 'true',
  'browserstack.resignApp': 'false',
  'browserstack.geoLocation': geo,
  'browserstack.deviceLogs': true,
  autoAcceptAlerts,
  'browserstack.console': 'verbose',
  'browserstack.acceptInsecureCerts': 'false',
  acceptSslCert: 'true',
  'browserstack.idleTimeout': '180',
  'browserstack.local': bsLocal,
  language: 'en',
  fullReset: true,
  usePrebuiltWDA: true,
};

const localIPadCapabilities = {
  platformName: 'iOS',
  platformVersion: osVersion,
  deviceName: 'iPad',
  udid: process.env.UDID,
  xcodeOrgId: process.env.XCODE_ORG_ID,
  automationName: 'Appium',
  usePrebuiltWDA: false,
  useNewWDA: false,
  bundleId: process.env.BUNDLE_ID,
  wdaLaunchTimeout: 2_400_000,
  wdaConnectionTimeout: 2_400_000,
  shouldUseSingletonTestManager: false,
  waitForQuiescence: false,
  clearSystemFiles: true,
  allowInvisibleElements: true,
  wdaStartupRetryInterval: '1000',
  newCommandtimeout: '3600',
};

const desiredIPadCapabilities =
  localExecution === 'true' ? localIPadCapabilities : iPadCapabilities;

module.exports = {
  desiredIPadCapabilities,
};
