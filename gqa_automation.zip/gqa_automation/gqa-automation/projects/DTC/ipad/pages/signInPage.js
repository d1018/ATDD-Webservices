const IosSignInPage = require('../../ios/pages/signInPage');

/**
 * // Example if you want to extend or modify a page for ipad
 */
class SignInPage extends IosSignInPage {}

module.exports = new SignInPage();
