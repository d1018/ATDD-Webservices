const AccountPage = require('../../ios/pages/accountPage');
const HomePage = require('../../ios/pages/homePage');
const SearchPage = require('../../ios/pages/searchPage');
const PreLaunchPage = require('../../ios/pages/prelaunchPage');
const MenuPage = require('../../ios/pages/menuPage');
const ProfilePage = require('../../ios/pages/profilePage');
const MyListPage = require('../../ios/pages/myListPage');
const VideoPlayerPage = require('../../ios/pages/videoPlayerPage');
const SportsPage = require('../../ios/pages/sportsPage');
const NetworkLandingPage = require('../../ios/pages/networkLandingPage');
const ShowDetailsPage = require('../../ios/pages/showDetailsPage');
const OnboardingPage = require('../../ios/pages/onboardingPage');
const BrowsePage = require('../../ios/pages/browsePage');
const EventDetailPage = require('../../ios/pages/eventDetailPage');
const WelcomePage = require('../../ios/pages/welcomePage');
const UpNextPage = require('../../ios/pages/upNextPage');

const signInPage = require('./signInPage');

const accountPage = new AccountPage();
const homePage = new HomePage();
const searchPage = new SearchPage();
const preLaunchPage = new PreLaunchPage();
const menuPage = new MenuPage();
const profilePage = new ProfilePage();
const myListPage = new MyListPage();
const videoPlayerPage = new VideoPlayerPage();
const sportsPage = new SportsPage();
const networkLandingPage = new NetworkLandingPage();
const showDetailsPage = new ShowDetailsPage();
const onboardingPage = new OnboardingPage();
const browsePage = new BrowsePage();
const eventDetailPage = new EventDetailPage();
const welcomePage = new WelcomePage();
const upNextPage = new UpNextPage();

module.exports = {
  accountPage,
  homePage,
  searchPage,
  signInPage,
  preLaunchPage,
  menuPage,
  profilePage,
  myListPage,
  videoPlayerPage,
  sportsPage,
  networkLandingPage,
  showDetailsPage,
  onboardingPage,
  browsePage,
  eventDetailPage,
  welcomePage,
  upNextPage,
};
