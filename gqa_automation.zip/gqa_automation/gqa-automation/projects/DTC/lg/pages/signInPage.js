const { BasePage, remoteActions } = require('./basePage');

const profilePage = require('./profilePage');

const commons = remoteActions;

const { VRC } = commons;

class SignInPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('signInPage', locator);
  }

  welcomePage = this.getElementByPage('welcomePage', 'welcomeScreen');

  welcomeTitle = this.getElementByPage('welcomePage', 'welcomeTitle');

  privacyOverlay = this.getElementByPage('welcomePage', 'privacyOverlay');

  focusedWelcomePageSignIn_btn = this.getElementByPage(
    'welcomePage',
    'focusedSignIn_btn',
  );

  userName_txtBx = this.#getSelectorData('userName_txtBx');

  password_txtBx = this.#getSelectorData('password_txtBx');

  signIn_btn = this.#getSelectorData('signIn_btn');

  focusedProfile = this.getElementByPage('profilePage', 'focusedProfile');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  // There is a new privacy-protection overlay that appears on the welcome screen sometimes
  bypassPrivacyOverlay = async () => {
    if (await commons.elementExists(this.privacyOverlay, 3)) {
      await commons.userAction(VRC.SELECT);
    }
  };

  openApp = async () => {
    await commons.clearAppData();
    await commons.openApp();
    await commons.waitUntil(this.welcomePage, 30);
    await this.bypassPrivacyOverlay();
  };

  navigateToSignInScreen_US = async () => {
    await commons.waitUntil(this.welcomeTitle, 60);
    await commons.tryUntil(this.focusedWelcomePageSignIn_btn, VRC.DOWN, 6, 1);
    await commons.userAction(VRC.ENTER);
    await commons.waitUntil(this.userName_txtBx, 15);
  };

  enterCredentials = async (credentialType) => {
    const username = process.env[`${credentialType}_USERNAME`];
    const password = process.env[`${credentialType}_PASSWORD`];

    // selecting the email field and entering email
    await commons.assertExists(this.userName_txtBx, 3);
    await commons.userAction(VRC.ENTER);
    await commons.setText(this.userName_txtBx, username);
    await commons.userAction(VRC.DOWN);
    // selecting the password field and entering password
    await commons.userAction(VRC.ENTER);
    await commons.setText(this.password_txtBx, password);
    await commons.userAction(VRC.DOWN);
    // Selecting sign-in button
    await commons.userAction(VRC.ENTER);
    await commons.waitUntil(this.focusedHomePage, 10);
  };

  loginToApplication = async (credentialType) => {
    await this.navigateToSignInScreen_US();
    await this.enterCredentials(credentialType);
    await commons.waitUntilVisible(this.focusedProfile, 20);
    if (credentialType === 'DTC_VALID') {
      await profilePage.selectProfile('Default');
    } else if (credentialType === 'DTC_KIDS_PROFILE') {
      await profilePage.selectProfile('Kids');
    }
  };

  verifySignOut = async () => {
    await commons.assertExists(this.signIn_btn, 10);
  };
}

module.exports = new SignInPage();
