const { ok } = require('assert');

const { BasePage, remoteActions, testdataHelper } = require('./basePage');
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');
const showsPage = require('./showDetailsPage');
const searchPage = require('./searchPage');

const commons = remoteActions;
const { PROP, VRC, COMP } = commons;
const myListShowsOrder = [];

const searchShowList = {
  Kids: testdataHelper.getContent('searchPage.kidsShowName'),
  Adult: testdataHelper.getContent('searchPage.adultShowName'),
  JIP: testdataHelper.getContent('searchPage.JIPShowName'),
};

const ratingCodesList = testdataHelper.getContent('ratingList');

const episodeDescriptorList = {
  Number: 'detail_episode-number',
  Title: 'Text_TEXT_TITLE',
  Description: 'detail_description',
};

const playerInfo = {
  episodeTitle: 1,
  episodeInfo: 2,
};

let isProfileSelected = false;

const continueWatchingMetadata = {
  showLogo: 'show-logo',
  episodeInfo: 'sub-title',
  episodeDescription: 'description',
  episodeRating: 'rating-code',
};

class HomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('homePage', locator);
  }

  forYou_lbl = this.#getSelectorData('forYou_lbl');

  crime_lbl = this.#getSelectorData('crime_lbl');

  networkRail = this.#getSelectorData('focusedAllNetworkRail');

  focusedHomePage = this.#getSelectorData('focusedHomePage');

  focusedRail = this.#getSelectorData('focusedRail');

  focusedNetworkRail = this.#getSelectorData('focusedNetworkRail');

  focusedShow = this.getElementByPage('showPage', 'focusedShow');

  focusedGenreMenuItem = this.#getSelectorData('focusedGenreMenuItem');

  watchNowCTA_lbl = this.getElementByPage('showPage', 'watchNowCTA_lbl');

  whoIsWatching = this.getElementByPage('profilePage', 'whoIsWatching');

  heroShowTitle = this.#getSelectorData('heroShowTitle');

  focusedThumbnail = this.#getSelectorData('focusedThumbnail');

  myListCta_lbl = this.getElementByPage('showPage', 'myListCta_lbl');

  focusedMyListCta = this.getElementByPage('showPage', 'focusedMyListCta');

  removedFromMyList_lbl = this.#getSelectorData('removedFromMyList_lbl');

  focusedBrowsePage = this.getElementByPage('browsePage', 'focusedBrowsePage');

  showDetailsPage = this.getElementByPage('showPage', 'showDetailsPage');

  focusedMyList_btn = this.getElementByPage('showPage', 'focusedMyList_btn');

  focusedRailShowTiles = this.#getSelectorData('focusedRailShowTiles');

  focusedAccountPage = this.getElementByPage('accountPage', 'accountTopNav');

  signIn_btn = this.getElementByPage('signInPage', 'signIn_btn');

  focusedSignOut_tab = this.getElementByPage(
    'accountPage',
    'focusedSignOut_tab',
  );

  focusedSignOut_btn = this.getElementByPage(
    'accountPage',
    'focusedSignOut_btn',
  );

  focusedCancelConfirm_btn = this.getElementByPage(
    'accountPage',
    'focusedCancelConfirm_btn',
  );

  focusedSignOutConfirm_btn = this.getElementByPage(
    'accountPage',
    'focusedSignOutConfirm_btn',
  );

  showDescription_txt = this.getElementByPage(
    'showPage',
    'showDescription_txt',
  );

  focusedMyListChecked = this.getElementByPage(
    'showPage',
    'focusedMyListChecked',
  );

  focusedMyListUnchecked = this.getElementByPage(
    'showPage',
    'focusedMyListUnchecked',
  );

  focusedSearchPage = this.getElementByPage('searchPage', 'focusedSearchPage');

  searchResultFirstTile = this.getElementByPage(
    'searchPage',
    'searchResultFirstTile_txt',
  );

  ratingsCode_txt = this.#getSelectorData('ratingsCode_txt');

  focusedStartWatching_btn = this.#getSelectorData('focusedStartWatching_btn');

  focusedForYou_lbl = this.getElementByPage('homePage', 'focusedForYou_lbl');

  startWatching_btn = this.getElementByPage('homePage', 'startWatching_btn');

  focusedHeroAddToMyList_btn = this.getElementByPage(
    'homePage',
    'focusedHeroAddToMyList_btn',
  );

  focusedHeroRemoveFromMyList_btn = this.getElementByPage(
    'homePage',
    'focusedHeroRemoveFromMyList_btn',
  );

  episodeRatingCode_lbl = this.getElementByPage(
    'showPage',
    'episodeRatingCode_lbl',
  );

  focusedEpisodeTile = this.getElementByPage('showPage', 'focusedEpisodeTile');

  runningEpisodeTile = this.getElementByPage('showPage', 'runningEpisodeTile');

  contentDescriptors_txt = this.#getSelectorData('contentDescriptors_txt');

  episodeDescriptors_txt = this.#getSelectorData('episodeDescriptors_txt');

  progressBar = this.getElementByPage('videoPlayerPage', 'progressBar');

  continueWatchingMetadata = this.#getSelectorData('continueWatchingMetadata');

  focusedFirstShowTile = this.getElementByPage(
    'myListPage',
    'focusedFirstShowTile',
  );

  kidsContentRatingList = ratingCodesList.slice(0, 4);

  selectAndPlayVideo = async () => {
    await commons.assertExists(this.watchNowCTA_lbl);
    await commons.userAction(VRC.SELECT);
  };

  focusedShowDetailPage = this.getElementByPage(
    'showPage',
    'focusedShowDetailPage',
  );

  genreTabItems = {
    'For You': this.#getSelectorData('forYou_lbl'),
    'True Crime': this.#getSelectorData('crime_lbl'),
  };

  invalidToken_txt = this.getElementByPage(
    'videoPlayerPage',
    'invalidToken_txt',
  );

  episodeInfoPlayer = this.getElementByPage(
    'videoPlayerPage',
    'episodeInfoPlayer',
  );

  selectGenreTab = async () => {
    if (await profilePage.selectProfile('Standard'))
      await commons.userAction('select');
    await commons.waitUntil(this.crime_lbl, 30);
    await commons.tryUntil(this.crime_lbl, VRC.RIGHT, 10, 6);
  };

  scrollToRail = async (railName) => {
    await commons.tryUntil(this.focusedGenreMenuItem, VRC.UP, 20, 3);
    let flag = false;
    const railList = [];

    while (flag !== true) {
      await this.moveToNextRail();
      const myLog = String(
        await commons.fetchAttributeData(this.focusedRail, PROP.TEXT_CONTENT),
      ).trim();

      if (railList.includes(myLog)) {
        if (!railList.includes(railName)) {
          break;
        }
      }
      railList.push(myLog);
      if (myLog === railName) {
        flag = true;
        return;
      }
    }
  };

  captureShowName = async () => {
    await commons.assertExists(this.showDetailsPage);
    const showName = await commons.fetchAttributeData(
      this.showDescription_txt,
      PROP.TEXT_CONTENT,
    );

    myListShowsOrder.push(showName);
  };

  addShowToMyList = async (count) => {
    if ((await this.returnGeoLocation()) === 'america')
      await menuPage.navigateToPage('Browse');
    else await menuPage.navigateToPage('Shows');
    await commons.assertVisible(this.focusedBrowsePage, 5);
    await commons.tryUntil(this.focusedShow, VRC.DOWN, 3, 1);
    for (let i = 1; i <= count; i++) {
      await commons.assertVisible(this.focusedShow, 5);
      await commons.userAction(VRC.SELECT);
      await commons.assertVisible(this.focusedShowDetailPage, 5);
      await commons.tryUntil(this.focusedMyList_btn, VRC.RIGHT, 2, 1);
      if (await commons.elementExists(this.focusedMyListUnchecked)) {
        await commons.userAction(VRC.SELECT);
        await this.captureShowName();
      }
      await commons.tryUntil(this.focusedShow, VRC.BACK, 2, 2);
      await commons.userAction(VRC.RIGHT);
    }
    this.showAddedFromBrowser = true;
  };

  verifyMyListRailMetadata = async (showCount) => {
    await menuPage.navigateToPage('Home');
    await this.scrollToRail('My List', true);

    for (let i = 0; i < showCount; i++) {
      await commons.assertExists(this.focusedThumbnail);
      await commons.assertExists(this.heroShowTitle);
      await commons.userAction(VRC.RIGHT);
    }
    await commons.userAction(VRC.LEFT, Number(showCount));
    if (await commons.elementExists(menuPage.focusedMenuBar)) {
      await commons.userAction(VRC.RIGHT);
      await commons.assertExists(this.focusedThumbnail);
    }
  };

  verifyMyListRailShowOrder = async () => {
    const reverseMyListShowsOrder = myListShowsOrder.reverse();

    for (let i = 0; i < reverseMyListShowsOrder.length; i++) {
      await this.selectShow();
      await commons.assertProperty(
        this.showDescription_txt,
        PROP.TEXT_CONTENT,
        reverseMyListShowsOrder[i],
        COMP.EQUAL,
      );
      await commons.userAction(VRC.BACK);
      await commons.waitUntil(this.focusedHomePage, 10);
      await commons.userAction(VRC.RIGHT);
    }
    this.showAddedFromBrowser = true;
  };

  removeFromMyList = async () => {
    await menuPage.navigateToPage('My List');
    await commons.tryUntil(this.focusedShow, VRC.RIGHT, 3, 1);
    while (await commons.elementExists(this.focusedShow)) {
      await commons.assertVisible(this.focusedShow, 5);
      await commons.userAction(VRC.SELECT);
      await commons.assertVisible(this.focusedShowDetailPage, 5);
      await commons.tryUntil(this.focusedMyList_btn, VRC.RIGHT, 2, 1);
      if (await commons.elementExists(this.focusedMyListChecked)) {
        await commons.userAction(VRC.SELECT);
        await this.captureShowName();
      }
      await commons.tryUntil(this.focusedShow, VRC.BACK, 2, 2);
    }
  };

  verifyVideoPlayed = async () => {
    await this.selectShow();
    await this.selectAndPlayVideo();
    await commons.assertVideoIsPlaying();
  };

  selectShow = async () => {
    await commons.userAction(VRC.SELECT, 1, 5);
    await commons.assertExists(this.focusedShowDetailPage, 10);
  };

  moveToNextRail = async (direction = VRC.DOWN) => {
    do {
      await commons.userAction(direction, 1, 1);
    } while (await commons.doesNotExist(this.focusedRail));
  };

  moveToFirstShowsRail = async () => {
    await this.moveToNextRail();
    if (
      await commons.checkProperty(
        this.focusedRail,
        PROP.TEXT_CONTENT,
        'Episodes',
        COMP.EQUAL,
      )
    ) {
      await commons.userAction(VRC.DOWN);
    }
  };

  validateCTAonPages = async (pageName) => {
    if (await commons.elementExists(profilePage.whoIsWatching, 5)) {
      await profilePage.selectProfile('Default');
    }

    const page = pageName.raw();

    for (let i = 0; i < page.length; i++) {
      const pageToBe = page[i].toString();

      if (pageToBe === 'Sports') {
        // This is out of scope for US; breaking since we are only implementing for US right now
        break;
      }
      await menuPage.navigateToPage(pageToBe);
      if (pageToBe === 'Home') {
        await this.moveToFirstShowsRail();
        await commons.userAction(VRC.DOWN);
      } else if (pageToBe === 'Shows' || pageToBe === 'Browse') {
        do {
          await commons.userAction(VRC.DOWN);
        } while (await commons.doesNotExist(this.focusedShow));
      } else if (pageToBe === 'Search') {
        await commons.userAction(VRC.DOWN, 2, 2);
        await commons.tryUntil(this.focusedShow, VRC.DOWN, 3, 1);
      } else {
        throw new Error(`Page type not supported`);
      }
      await commons.userAction(VRC.SELECT);
      await showsPage.validateCTAonShowPage();
    }
  };

  scrollToNetworkRail = async () => {
    if (await commons.elementExists(this.whoIsWatching, 10)) {
      await profilePage.selectProfile('Default');
    }
    await commons.tryUntil(this.focusedNetworkRail, VRC.DOWN, 10, 1);
  };

  validateNetworkRail = async () => {
    await commons.assertVisible(this.networkRail, 2);
  };

  /**
   * Below function is used to validate Kids profile content
   *
   */
  verifyKidsContentPopulated = async () => {
    // To verify content rating on Home Page
    await this.verifyHomePageKidsContent();

    // To verify content rating on Search Page
    if (
      !(await this.verifySearchPageKidsContent(
        'kidsShowName',
        searchShowList.Kids,
      ))
    ) {
      // Clean up if scenario fails
      await profilePage.deleteExistingProfile();
      throw new Error('Kids page did not contain Kids content');
    }

    // Navigate back to home to refresh the search textbox because
    // it is not cleared for the next entry
    await menuPage.navigateToPage('Home');
    if (
      await this.verifySearchPageKidsContent(
        'adultShowName',
        searchShowList.Adult,
      )
    ) {
      // Clean up if scenario fails
      await profilePage.deleteExistingProfile();
      throw new Error('Kids page contained Adult content');
    }
  };

  /**
   * Below function is used to validate Kids content on
   * Home page
   *
   */
  verifyHomePageKidsContent = async () => {
    if (await commons.doesNotExist(this.focusedHomePage)) {
      await this.navigateToPage('Home');
    }

    const fetchedCode = await commons.fetchAttributeData(
      this.ratingsCode_txt,
      PROP.TEXT_CONTENT,
    );

    const foundCode = this.kidsContentRatingList.includes(
      fetchedCode.toString(),
    );

    if (!foundCode) {
      // Clean up if scenario fails
      await profilePage.deleteExistingProfile();
      throw new Error('Kids rating not correct');
    }
  };

  /**
   * Below function is used to delete a profile passing its name as
   * parameter
   *
   * @param {string} searchText - Text to search
   * @param {string} contentType - search item whether Kids, Adult, or JIP
   */
  verifySearchPageKidsContent = async (searchText, contentType) => {
    if (await commons.doesNotExist(this.focusedSearchPage)) {
      await menuPage.navigateToPage('Search');
    }
    await searchPage.searchText(searchText);
    if (
      await commons.checkProperty(
        this.searchResultFirstTile,
        PROP.TEXT_CONTENT,
        contentType,
        COMP.EQUAL,
      )
    ) {
      return true;
    }
    return false;
  };

  /**
   * Below function is used to validate that JIP content does not appear
   * on Kids profile
   *
   */
  verifyJIPContent = async () => {
    // First navigate to home to refresh the search textbox because
    // it is not cleared for the next entry
    await menuPage.navigateToPage('Home');
    if (
      await this.verifySearchPageKidsContent('JIPShowName', searchShowList.JIP)
    ) {
      throw new Error('Kids page contained JIP content');
    }
  };

  signOut = async () => {
    // Allow 10 seconds for the asserts below in case of low bandwidth or slower OS versions

    // If no default profile, click on first profile
    if (await commons.elementExists(this.whoIsWatching, 10)) {
      await commons.userAction(VRC.SELECT);
    }
    await commons.assertExists(this.focusedHomePage, 10);
    // Proceed to sign out
    await menuPage.navigateToPage('Account');
    await commons.navigateTo(this.focusedSignOut_tab, VRC.RIGHT, 5);
    await commons.userAction(VRC.DOWN);
    await commons.assertExists(this.focusedSignOut_btn, 10);
    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.focusedCancelConfirm_btn, 10);
    await commons.userAction(VRC.UP);
    await commons.assertExists(this.focusedSignOutConfirm_btn, 10);
    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.signIn_btn, 10);
  };

  /**
   * Below function is used to verify age rating and content descriptors
   * on various screens.
   *
   * @param {string} screenType - Selected screen
   */
  verifyAgeRatingAndContentDescriptors = async (screenType) => {
    if (!isProfileSelected) {
      if (await commons.elementExists(this.whoIsWatching, 10)) {
        await profilePage.selectProfile('Default');
        isProfileSelected = true;
      }
    }

    switch (screenType) {
      case 'Main Hero':
        await commons.assertExists(this.focusedHomePage, 10);

        // Verify content descriptors
        await commons.assertExists(this.contentDescriptors_txt, 10);

        if (
          !ratingCodesList.includes(
            await commons.fetchAttributeData(
              this.ratingsCode_txt,
              PROP.TEXT_CONTENT,
            ),
          )
        ) {
          throw new Error('Rating is not as per rating standards!');
        }
        break;
      case 'Show Details Page':
        await commons.tryUntil(this.focusedStartWatching_btn, VRC.DOWN, 2, 1);
        await commons.userAction(VRC.SELECT);
        await commons.assertExists(this.watchNowCTA_lbl, 10);

        // Verify content descriptors
        await commons.assertExists(this.contentDescriptors_txt, 10);

        // Verify rating codes
        if (
          !ratingCodesList.includes(
            await commons.fetchAttributeData(
              this.ratingsCode_txt,
              PROP.TEXT_CONTENT,
            ),
          )
        ) {
          throw new Error('Rating is not as per rating standards!');
        }
        break;
      case 'Currently Playing Episode':
        await commons.userAction(VRC.SELECT);

        // Sometimes playback does not work because of token issues.
        // In such cases, throw error.
        if (await commons.elementExists(this.invalidToken_txt, 5)) {
          throw new Error('Error in playback: Invalid Token');
        } else {
          await commons.waitTillVideoIsPlaying(45);
          await commons.tryUntil(this.progressBar, VRC.DOWN, 3, 2);
          await commons.userAction(VRC.RIGHT, 4, 2);
          await commons.userAction(VRC.SELECT, 4, 3);
          await commons.userAction(VRC.LEFT, 1, 1);
          await commons.userAction(VRC.SELECT);
          await commons.tryUntil(this.progressBar, VRC.DOWN, 5, 3);
          await commons.userAction(VRC.PAUSE);
          await commons.assertExists(
            this.getCustomLocator(
              this.episodeInfoPlayer,
              playerInfo.episodeTitle.toString(),
            ),
          );
          await commons.assertExists(
            this.getCustomLocator(
              this.episodeInfoPlayer,
              playerInfo.episodeInfo.toString(),
            ),
          );
          await commons.userAction(VRC.PLAY);
          await commons.assertVideoIsPlaying(30);
          await commons.tryUntil(this.watchNowCTA_lbl, VRC.BACK, 3, 2);
        }

        // Move to episode navigation
        await commons.tryUntil(this.focusedEpisodeTile, VRC.DOWN, 3, 1);

        // Verify content descriptors
        await Object.values(episodeDescriptorList).forEach((value) => {
          commons.assertExists(
            this.getCustomLocator(this.episodeDescriptors_txt, `${value}`),
            10,
          );
        });

        // Verify rating codes
        if (
          !ratingCodesList.includes(
            await commons.fetchAttributeData(
              this.episodeRatingCode_lbl,
              PROP.TEXT_CONTENT,
            ),
          )
        ) {
          throw new Error('Rating is not as per rating standards!');
        }
        break;
      case 'Next Episodes listed on Episode Landing Page':
        // Switch to a new episode if current one has progressed enough.
        while (await commons.elementExists(this.runningEpisodeTile, 1)) {
          await commons.userAction(VRC.RIGHT);
        }

        // Verify content descriptors
        await Object.values(episodeDescriptorList).forEach((value) => {
          commons.assertExists(
            this.getCustomLocator(this.episodeDescriptors_txt, `${value}`),
            10,
          );
        });

        // Verify rating codes
        if (
          !ratingCodesList.includes(
            await commons.fetchAttributeData(
              this.episodeRatingCode_lbl,
              PROP.TEXT_CONTENT,
            ),
          )
        ) {
          throw new Error('Rating is not as per rating standards!');
        }
        break;
      case 'Episode Info Panel':
        // Episode Info Panel is not available on LG.
        // So we break in this case.
        break;
      default:
        throw new Error('Screen Type is not as per the expectations');
    }
  };

  /**
   * Below function is used to verify JIP content on home page. HWA does not
   * have JIP content on Channel and Show Details Page.
   *
   * @param {string} pageName - set as Home, Channel, Show Details Page etc.
   */

  verifyJipContentPlayback = async (pageName) => {
    await profilePage.selectProfile('Default');
    if (pageName === 'Home Page') {
      await this.scrollToRail(
        testdataHelper.getContent('homePage.discoveryPlusChannels'),
      );
      await commons.userAction(VRC.ENTER);
      if (await commons.elementExists(this.invalidToken_txt, 5)) {
        throw new Error('Playback error: Invalid token!');
      } else {
        await commons.assertVideoIsPlaying(30);
        await commons.userAction(VRC.BACK);
      }
    }
  };

  /**
   * Below function is used to verify metadata on the Continue Watching
   * rail.
   *
   */
  verifyContinueWatchingMetadata = async () => {
    // Collect and verify content descriptors
    await Object.values(continueWatchingMetadata).forEach((value) => {
      commons.assertExists(
        this.getCustomLocator(this.continueWatchingMetadata, `${value}`),
        10,
      );
    });
  };

  /**
   * Below function is used to resume playback from Continue Watching
   * rail.
   *
   */
  resumeAndPlayVideo = async () => {
    // Select content
    await commons.userAction(VRC.SELECT);
  };

  addShowToMylistFromHomeHero = async () => {
    if (!(await commons.elementExists(this.focusedForYou_lbl, 10))) {
      await menuPage.navigateToPage('Home');
    }

    // "For You" tab loads way quicker before main video asset in Hero
    // So we need to wait for "Start Watching" to show up before moving down
    await commons.assertExists(this.startWatching_btn, 10);
    await commons.userAction(VRC.DOWN);
    await commons.assertExists(this.focusedStartWatching_btn, 5);
    await commons.userAction(VRC.RIGHT);

    // Remove item first if already added to my list
    if (await commons.elementExists(this.focusedHeroRemoveFromMyList_btn, 5)) {
      await commons.userAction(VRC.SELECT);
    }
    await commons.assertExists(this.focusedHeroAddToMyList_btn, 5);

    await commons.userAction(VRC.SELECT);
    await commons.assertExists(this.focusedHeroRemoveFromMyList_btn, 5);
  };

  verifyRailPresent = async (railName, railPresent) => {
    if (
      await commons.checkProperty(
        this.focusedRail,
        PROP.TEXT_CONTENT,
        railName,
        COMP.EQUAL,
      )
    ) {
      ok(railPresent === true);
    } else {
      let flag = false;
      const railList = [];

      let counter = 0;

      while (flag !== true) {
        await this.moveToNextRail();
        const focusedRailName = String(
          await commons.fetchAttributeData(this.focusedRail, PROP.TEXT_CONTENT),
        ).trim();

        if (railList.includes(focusedRailName)) {
          break;
        }
        railList.push(focusedRailName);
        counter++;
        if (focusedRailName === railName) {
          flag = true;
        }
      }

      const railExist = railList.includes(railName);

      ok(
        railExist === railPresent,
        `Expected: ${railPresent}, Received: ${railExist}`,
      );
      await commons.userAction(VRC.UP, counter + 2, 1);
    }
  };

  verifyMyListRailOnHomePage = async (railName, railStatus) => {
    if (!(await commons.elementVisible(this.focusedForYou_lbl, 10))) {
      await menuPage.navigateToPage('Home');
    }

    await this.verifyRailPresent(railName, railStatus);
  };

  /**
   * The below function will verify Shows exists or not in MyList Rail
   *
   * @param {boolean} isAdded - Status of Show in MyList Rail is true or false
   */
  verifyShowsInMyListRail = async (isAdded) => {
    await menuPage.navigateToPage('Home');
    await commons.waitUntil(this.forYou_lbl, 10);
    await this.scrollToRail('My List', isAdded);

    if (isAdded) {
      await commons.assertVisible(this.focusedFirstShowTile, 5);
    } else {
      await commons.assertNotVisible(this.focusedFirstShowTile);
    }
  };

  /**
   * The below function verifies that Standard and Kids do not contain
   * the same show on My List.
   *
   */
  verifyMyListShowAvailability = async () => {
    await profilePage.selectProfile('Standard');
    await commons.userAction(VRC.ENTER);
    await menuPage.navigateToPage('My List');
    const standardProfileShow = await commons.fetchAttributeData(
      this.focusedFirstShowTile,
      PROP.HREF,
    );

    await profilePage.selectProfile('Kids');
    await menuPage.navigateToPage('My List');
    const kidsProfileShow = await commons.fetchAttributeData(
      this.focusedFirstShowTile,
      PROP.HREF,
    );

    ok(
      standardProfileShow !== kidsProfileShow,
      `Same show on Kids and Standard profiles`,
    );
  };
}

module.exports = new HomePage();
