const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const { PROP, VRC, COMP } = commons;
const menuPage = require('./menuPage');

let newProfileName;
let retry = 0;
const doNotDelete = ['Default', 'Standard', 'Kids'];

class ProfilePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('profilePage', locator);
  }

  focusedProfileName = this.#getSelectorData('focusedProfileName');

  whoIsWatching = this.#getSelectorData('whoIsWatching');

  focusedMenuBar = this.getElementByPage('menuPage', 'focusedMenuBar');

  profileName_txt = this.#getSelectorData('profileName_txt');

  profileEdit_btn = this.#getSelectorData('profileEdit_btn');

  focusedSave_btn = this.#getSelectorData('focusedSave_btn');

  focusedDeleteProfile_btn = this.#getSelectorData('focusedDeleteProfile_btn');

  deleteProfile_txt = this.#getSelectorData('deleteProfile_txt');

  delete_btn = this.#getSelectorData('delete_btn');

  profileName = this.#getSelectorData('profileName');

  profileList = this.#getSelectorData('profileList');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  focusedManageProfiles = this.getElementByPage(
    'menuPage',
    'focusedManageProfiles_lbl',
  );

  deleteThisProfile = '';

  profileNameCreatedList = [];

  userProfileDeleted_flag = true;

  isKidsProfile = false;

  maxNumberOfProfiles = testdataHelper.getContent(
    'profilePage.maxNumberOfProfiles',
  );

  pinEntryPageTitle_txt = this.#getSelectorData('pinEntryPageTitle_txt');

  isPinProfile = false;

  pinPadlockIcon_img = this.#getSelectorData('pinPadlockIcon_img');

  addProfile_btn = this.#getSelectorData('addProfile_btn');

  selectProfile = async (profileName) => {
    if (await commons.doesNotExist(this.whoIsWatching, 10)) {
      await this.navigateToProfilePickerScreen();
    }

    for (
      let profileCounter = 0;
      profileCounter <= this.maxNumberOfProfiles;
      profileCounter++
    ) {
      if (profileCounter === 5) {
        throw new Error(
          `"Profile named ${profileName} not found! Please create one and rerun scenario."`,
        );
      }
      if (
        await commons.checkProperty(
          this.focusedProfileName,
          PROP.TEXT_CONTENT,
          profileName,
          COMP.EQUAL,
        )
      ) {
        await commons.assertExists(this.focusedProfileName, 30);
        if (this.isPinProfile) {
          await commons.assertExists(this.pinPadlockIcon_img, 1);
          await commons.userAction(VRC.ENTER);
          await this.enterPin();
        } else {
          await commons.userAction(VRC.ENTER);
        }
        return;
      }
      await commons.userAction(VRC.RIGHT);
    }
  };

  deleteProfileFromEditProfilePage = async () => {
    await commons.userAction(VRC.UP);
    await commons.userAction(VRC.ENTER);
    await commons.assertExists(this.delete_btn, 4);
    await commons.userAction(VRC.UP);
    await commons.userAction(VRC.ENTER);
  };

  navigateToProfilePickerScreen = async () => {
    if (await commons.doesNotExist(this.focusedProfileName, 10)) {
      await commons.tryUntil(this.focusedMenuBar, VRC.BACK, 2, 1);
      await commons.userAction(VRC.UP, 1);
      await menuPage.openMenu();
      await commons.tryUntil(menuPage.focusedManageProfiles_lbl, VRC.UP, 8, 1);
      await commons.userAction(VRC.SELECT);
    }
    await commons.assertExists(this.focusedProfileName, 30);
  };

  createNewProfile = async (profileType) => {
    // Need to randomize it enough on the off chance that the profile name is already
    // present: Duplicate names are not allowed.
    const dateObject = new Date();
    const timeSeconds = dateObject.getUTCSeconds();
    const timeMilliseconds = dateObject.getUTCMilliseconds();

    let counterProfile = 0;

    newProfileName =
      profileType === 'Auto_Watch_Now'
        ? 'Auto_Watch_Now'
        : String(`${profileType}${timeSeconds}${timeMilliseconds}`);

    if (await commons.doesNotExist(this.whoIsWatching, 10)) {
      await this.navigateToProfilePickerScreen();
    }
    // Code for profile deletion if maxed out
    if (await commons.doesNotExist(this.addProfile_btn, 5)) {
      const profileToDelete = await this.pickRandomProfileToDelete();

      await this.deleteProfileByName(profileToDelete);
    }
    await this.selectProfile('Add Profile');
    await commons.userAction(VRC.ENTER, 3);
    await commons.setText(this.profileName_txt, newProfileName);

    // To turn on Family Profile
    if (this.isKidsProfile) {
      await commons.userAction(VRC.DOWN, 3);
      await commons.userAction(VRC.UP, 1, 2);
      await commons.userAction(VRC.SELECT, 1, 2);
      await commons.userAction(VRC.DOWN, 1, 2);
      await commons.userAction(VRC.RIGHT, 1, 2);
    }

    // Intermittent Bug: Hack around to enable Save button
    // so this hack will try 4 times and then will throw error if save btn doesn't get enabled
    else {
      while (!(await commons.elementExists(this.focusedSave_btn, 1))) {
        await commons.userAction(VRC.DOWN, 3, 1);
        await commons.userAction(VRC.LEFT);
        await commons.userAction(VRC.RIGHT);
        counterProfile++;
        if (counterProfile === 4) {
          throw new Error('Profile save failed!');
        }
      }
    }

    await commons.userAction(VRC.ENTER);

    await commons.elementExists(this.focusedProfileName, 5);

    this.deleteThisProfile = await commons.fetchAttributeData(
      this.focusedProfileName,
      PROP.TEXT_CONTENT,
    );
  };

  /**
   * Below function is used to create and select a new profile
   *
   * @param {string} profileType - Auto_Watch_Now
   */

  createNewProfileandSelect = async (profileName) => {
    await this.createNewProfile(profileName);
    await this.selectProfile(this.deleteThisProfile);
  };

  /**
   * Below function is used to enter the Pin
   *
   */
  enterPin = async () => {
    await commons.assertExists(this.pinEntryPageTitle_txt, 1);
    await commons.userAction(VRC.SELECT, 4, 1);
  };

  /**
   * Below function is used to create a new profile and calls createnewprofile function
   *
   * @param {string} profileType (Standard, Kids, etc.)
   */
  profileCreation = async (profileType) => {
    // The Pin profile creation and deletion is only applicable for web.
    // For HWA, the expectation is to only select the profile.
    if (profileType === 'Pin') {
      this.isPinProfile = true;
      await this.selectProfile(profileType);
      return;
    }

    this.isKidsProfile = profileType === 'Kids';

    if (await commons.doesNotExist(this.focusedProfileName, 10)) {
      await commons.tryUntil(this.focusedMenuBar, VRC.LEFT, 1, 1);
      await commons.userAction(VRC.ENTER);
    }
    await this.createNewProfile(profileType);
    await commons.userAction(VRC.ENTER);
  };

  editProfile = async () => {
    for (let i = 0; i < 4; i++) {
      if (
        await commons.checkProperty(
          this.focusedProfileName,
          PROP.TEXT_CONTENT,
          newProfileName,
          COMP.EQUAL,
        )
      ) {
        await commons.assertExists(this.focusedProfileName, 60);
        await commons.userAction(VRC.DOWN, 2);
        await commons.userAction(VRC.ENTER, 2, 2);
        return;
      }
      await commons.userAction(VRC.RIGHT);
    }
  };

  // This function is for step: I validate data is cleaned up by deleting profile
  deleteExistingProfile = async () => {
    // HWA platforms do not have an option to delete "Pin" profiles.
    // So, in such situations, we simply return.
    if (this.isPinProfile) {
      return;
    }

    /* Temporary hack to get around the problem wherein the delete button
     * does not appear on the Kids profile upon first use. So, first switch
     * to a Default profile and then delete the kids profile.
     */
    if (this.deleteThisProfile.includes('Kids')) {
      await this.selectProfile('Default');
      await this.deleteProfileByName(this.deleteThisProfile);
      return;
    }

    if (await commons.doesNotExist(this.whoIsWatching, 10)) {
      await this.navigateToProfilePickerScreen();
    }

    let i = 5;

    while (i > 0) {
      await commons.userAction(VRC.DOWN);
      await commons.userAction(VRC.SELECT);
      if (await commons.elementExists(this.delete_btn, 5)) {
        await commons.userAction(VRC.UP);
        await commons.userAction(VRC.SELECT);
        await commons.assertExists(this.deleteProfile_txt, 4);
        await commons.userAction(VRC.UP);
        await commons.userAction(VRC.SELECT);
        break;
      } else {
        i -= 1;
      }
    }
  };

  /**
   * Below function is used to create a new profile and calls createnewprofile function
   *
   * @param {string} profileName (Standard, Kids, etc.)
   * or "random" for Scenario: Deletion of a user profile
   */
  deleteProfile = async (profileName) => {
    if (profileName === 'random') {
      await this.deleteRandomProfile(profileName);
    }
  };

  /**
   * Below function is used to fetch all profile names into a global array
   *
   */
  fetchAllProfileNames = async () => {
    // Delete a random profile except default or from a list
    let profileCounter = testdataHelper.getContent(
      'profilePage.maxNumberOfProfiles',
    );

    // Get all the profile names
    while (profileCounter > 0) {
      if (
        (await commons.fetchAttributeData(
          this.focusedProfileName,
          PROP.TEXT_CONTENT,
        )) === 'Add Profile' ||
        profileCounter === 0
      ) {
        break;
      }

      this.profileNameCreatedList.push(
        await commons.fetchAttributeData(
          this.focusedProfileName,
          PROP.TEXT_CONTENT,
        ),
      );

      await commons.userAction(VRC.RIGHT, 1, 2);
      profileCounter -= 1;
    }
  };

  /**
   * Below function is used to delete a random profile. If the profile
   * is not found, the function will first create the profile before
   * deletion.
   *
   * @param {string} profileName - profile name to be deleted
   */
  deleteRandomProfile = async (profileName) => {
    // If Default is the only profile available the app will launch
    // to the home page by default. We will need to then navigate to
    // profile picker screen first.
    if (await commons.elementExists(this.focusedHomePage, 15)) {
      await commons.userAction(VRC.LEFT, 3, 5);
      await commons.userAction(VRC.UP, 2);
      await commons.userAction(VRC.SELECT, 1);
      await commons.assertExists(this.whoIsWatching, 10);
    }

    let foundProfile = -1;

    await this.fetchAllProfileNames();

    foundProfile = this.profileNameCreatedList.findIndex((element) =>
      element.includes(profileName),
    );

    // If number of profiles have already maxed out then a
    // random profile will automatically be deleted.
    if (
      this.profileNameCreatedList.length.toString() ===
      testdataHelper.getContent('profilePage.maxNumberOfProfiles')
    ) {
      await this.moveToLeftMostProfile();
      while (
        await commons.checkProperty(
          this.focusedProfileName,
          PROP.TEXT_CONTENT,
          'Default',
          COMP.EQUAL,
        )
      ) {
        await commons.userAction(VRC.RIGHT, 1);
      }

      this.deleteThisProfile = await commons.fetchAttributeData(
        this.focusedProfileName,
        PROP.TEXT_CONTENT,
      );
      await this.deleteProfileByName(this.deleteThisProfile);
    }
    // To check if profile needs to be first created before deletion.
    // i.e if the only profile existing is the Default profile
    else if (foundProfile === -1 || this.profileNameCreatedList.length === 1) {
      await this.createNewProfile(profileName);
      this.profileNameCreatedList.push(this.deleteThisProfile);
      await this.deleteProfileByName(this.deleteThisProfile);
    } else {
      await this.deleteProfileByName(this.profileNameCreatedList[foundProfile]);
    }
  };

  /**
   * Below function is used to delete a profile passing its name as
   * parameter
   *
   * @param {string} profileName - profile name to be deleted
   */
  deleteProfileByName = async (profileName) => {
    if (await commons.doesNotExist(this.whoIsWatching, 10)) {
      await this.navigateToProfilePickerScreen();
    }

    await this.moveToLeftMostProfile();

    while (
      await commons.checkProperty(
        this.focusedProfileName,
        PROP.TEXT_CONTENT,
        profileName,
        COMP.NOT_EQUAL,
      )
    ) {
      await commons.userAction(VRC.RIGHT, 1);
    }
    await commons.userAction(VRC.DOWN);
    await commons.userAction(VRC.SELECT);

    if (await commons.elementExists(this.delete_btn, 5)) {
      await commons.userAction(VRC.UP);
      await commons.userAction(VRC.SELECT);
      await commons.assertExists(this.deleteProfile_txt, 4);
      await commons.userAction(VRC.UP);
      await commons.userAction(VRC.SELECT);
    }
  };

  /**
   * Below function is used to move focus to the left most profile.
   * This is done solely because the profile order is not always
   * consistent and one will have to reset the position to the
   * left most profile.
   */
  moveToLeftMostProfile = async () => {
    let currentFocusedProfile = await commons.fetchAttributeData(
      this.focusedProfileName,
      PROP.TEXT_CONTENT,
    );
    let profileToLeft = '';

    while (currentFocusedProfile !== profileToLeft) {
      await commons.userAction(VRC.LEFT, 1);
      profileToLeft = await commons.fetchAttributeData(
        this.focusedProfileName,
        PROP.TEXT_CONTENT,
      );
      if (currentFocusedProfile === profileToLeft) {
        break;
      } else {
        currentFocusedProfile = profileToLeft;
        profileToLeft = '';
      }
    }
  };

  /**
   * Below function is used to verify that profile has been deleted.
   */
  verifyUserProfileDeleted = async () => {
    if (await commons.doesNotExist(this.whoIsWatching, 10)) {
      await this.navigateToProfilePickerScreen();
    }

    // To land on the left most profile because profile order is
    // not always consistent.
    await this.moveToLeftMostProfile();

    for (
      let profileCounter = 0;
      profileCounter <
      testdataHelper.getContent('profilePage.maxNumberOfProfiles');
      profileCounter++
    ) {
      if (
        await commons.checkProperty(
          this.focusedProfileName,
          PROP.TEXT_CONTENT,
          this.deleteThisProfile,
          COMP.EQUAL,
        )
      ) {
        this.userProfileDeleted_flag = false;
      }

      // Break out of the loop if `Add Profile` is reached
      await commons.userAction(VRC.RIGHT, 1);
      if (
        await commons.checkProperty(
          this.focusedProfileName,
          PROP.TEXT_CONTENT,
          'Add Profile',
          COMP.EQUAL,
        )
      ) {
        break;
      }
    }

    // If profile is not deleted for some reason, a delete
    // retry attempt will be made.
    if (this.userProfileDeleted_flag === false && retry < 1) {
      await this.deleteExistingProfile();
      retry++;
      await this.verifyUserProfileDeleted();
    }

    if (this.userProfileDeleted_flag === false && retry >= 1) {
      throw Error('Profile not deleted');
    }
  };

  /**
   * Below function is used to pick a random profile to delete
   * as long as the profile is not named Default, Standard, or Kids.
   */
  pickRandomProfileToDelete = async () => {
    await this.moveToLeftMostProfile();
    let profileName = await commons.fetchAttributeData(
      this.focusedProfileName,
      PROP.TEXT_CONTENT,
    );

    while (await doNotDelete.includes(profileName)) {
      await commons.userAction(VRC.RIGHT);
      profileName = await commons.fetchAttributeData(
        this.focusedProfileName,
        PROP.TEXT_CONTENT,
      );
    }

    const profileToDelete = commons.fetchAttributeData(
      this.focusedProfileName,
      PROP.TEXT_CONTENT,
    );

    return profileToDelete;
  };
}

module.exports = new ProfilePage();
