const { BasePage, remoteActions } = require('./basePage');
const menuPage = require('./menuPage');

const commons = remoteActions;
const { VRC } = commons;

class MyListPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('myListPage', locator);
  }

  focusedMyListPage = this.#getSelectorData('focusedMyListPage');

  noSavedShow_txt = this.getElementByPage('myListPage', 'noSavedShow_txt');

  browseShows_btn = this.getElementByPage('myListPage', 'browseShows_btn');

  focusedShowCard = this.getElementByPage('browsePage', 'focusedShowCard');

  focusedShowDetailPage = this.getElementByPage(
    'showPage',
    'focusedShowDetailPage',
  );

  firstSavedShowTile = this.getElementByPage(
    'myListPage',
    'firstSavedShowTile',
  );

  watchNowCTA_lbl = this.getElementByPage('showPage', 'watchNowCTA_lbl');

  myListPageFirstItem_tile = this.#getSelectorData('myListPageFirstItem_tile');

  focusedMyListChecked = this.getElementByPage(
    'showPage',
    'focusedMyListChecked',
  );

  focusedMyListUnchecked = this.getElementByPage(
    'showPage',
    'focusedMyListUnchecked',
  );

  /**
   * Navigate to My List page via opening left side menu
   */
  navigateToMyListPage = async () => {
    await menuPage.openMenu();
    await menuPage.navigateToPage('My List');
    await commons.waitUntil(this.focusedMyListPage);
  };

  /**
   * Go to My list page then browse page
   * Select first show, go to show details page
   * click +My list button
   * click Back till focused show details present on browse page
   */
  addShowsToMylistFromBrowse = async () => {
    await this.navigateToMyListPage();
    await commons.waitUntil(this.noSavedShow_txt);
    await commons.waitUntil(this.browseShows_btn);
    await commons.assertExists(this.browseShows_btn, 5);
    await commons.userAction(VRC.SELECT);

    await commons.tryUntil(this.focusedShowCard, VRC.DOWN, 10);
    await commons.userAction(VRC.SELECT);

    await commons.waitUntil(this.focusedShowDetailPage, 5);
    await commons.waitUntil(this.watchNowCTA_lbl, 5);
    await commons.assertExists(this.watchNowCTA_lbl);
    await commons.userAction(VRC.RIGHT);
    await commons.userAction(VRC.SELECT);
    await commons.tryUntil(this.focusedShowCard, VRC.BACK, 3);
  };

  /**
   * The below function will verify the MyList Rail
   *
   * @param {boolean} isShowPresent - MyList Rail status true or false
   */
  verifyShowsInMyList = async (isShowPresent) => {
    await this.navigateToMyListPage();
    await commons.waitUntil(this.focusedMyListPage, 5);

    if (isShowPresent) {
      await commons.assertExists(this.myListPageFirstItem_tile);
    } else {
      await commons.doesNotExist(this.myListPageFirstItem_tile);
    }
  };

  removeShowFromMyListPage = async () => {
    if (!(await commons.elementExists(this.focusedMyListPage, 10))) {
      await menuPage.navigateToPage('My List');
    }

    while (await commons.elementExists(this.myListPageFirstItem_tile, 10)) {
      await commons.userAction(VRC.SELECT);
      await commons.assertExists(this.watchNowCTA_lbl, 10);
      await commons.userAction(VRC.RIGHT);
      await commons.assertExists(this.focusedMyListChecked, 5);
      await commons.userAction(VRC.SELECT);
      await commons.assertExists(this.focusedMyListUnchecked, 5);
      await commons.userAction(VRC.BACK);
    }

    await commons.assertExists(this.noSavedShow_txt, 5);
    await commons.assertExists(this.browseShows_btn, 5);
  };

  selectBrowseShows = async () => {
    await commons.assertExists(this.browseShows_btn, 5);
    await commons.userAction(VRC.ENTER);
  };
}

module.exports = new MyListPage();
