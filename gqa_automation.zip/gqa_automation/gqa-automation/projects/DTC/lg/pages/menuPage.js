const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

const onboardingPage = require('./onboardingPage');

class MenuPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('menuPage', locator);
  }

  focusedMenuBar = this.#getSelectorData('focusedMenuBar');

  menuListLoggedIn = testdataHelper.getContent(
    'menuNavigationPage.loggedInMenu',
  );

  menuBarList = this.#getSelectorData('menuBarList');

  homeMenu_lbl = this.#getSelectorData('homeMenu_lbl');

  searchMenu_lbl = this.#getSelectorData('searchMenu_lbl');

  accountMenu_lbl = this.#getSelectorData('accountMenu_lbl');

  myListMenu_lbl = this.#getSelectorData('myListMenu_lbl');

  browseMenu_lbl = this.#getSelectorData('browseMenu_lbl');

  myListMenuListItem = this.#getSelectorData('myListMenuListItem');

  focusedManageProfiles_lbl = this.#getSelectorData(
    'focusedManageProfiles_lbl',
  );

  focusedHomeMenu_lbl = this.#getSelectorData('focusedHomeMenu_lbl');

  focusedAccountMenu_lbl = this.#getSelectorData('focusedAccountMenu_lbl');

  focusedBrowseMenu_lbl = this.#getSelectorData('focusedBrowseMenu_lbl');

  focusedSearchMenu_lbl = this.#getSelectorData('focusedSearchMenu_lbl');

  focusedMyListMenu_lbl = this.#getSelectorData('focusedMyListMenu_lbl');

  focusedSearchPage = this.getElementByPage('searchPage', 'focusedSearchPage');

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  focusedAccountPage = this.getElementByPage('accountPage', 'accountTopNav');

  focusedBrowsePage = this.getElementByPage('browsePage', 'focusedBrowsePage');

  focusedMyListPage = this.getElementByPage('myListPage', 'focusedMyListPage');

  menuItem = {
    Home: this.homeMenu_lbl,
    Browse: this.browseMenu_lbl,
    'My List': this.myListMenu_lbl,
    Search: this.searchMenu_lbl,
    Account: this.accountMenu_lbl,
  };

  focusedmenuItem = {
    Home: this.focusedHomeMenu_lbl,
    Browse: this.focusedBrowseMenu_lbl,
    'My List': this.focusedMyListMenu_lbl,
    Search: this.focusedSearchMenu_lbl,
    Account: this.focusedAccountMenu_lbl,
  };

  pageFocused = {
    Home: this.focusedHomePage,
    Browse: this.focusedBrowsePage,
    'My List': this.focusedMyListPage,
    Search: this.focusedSearchPage,
    Account: this.focusedAccountPage,
  };

  exitWindow_txt = this.getElementByPage('exitPage', 'exitWindow_txt');

  exitCTA_btn = this.getElementByPage('exitPage', 'exitCTA_btn');

  cancelCTA_btn = this.getElementByPage('exitPage', 'cancelCTA_btn');

  whoIsWatching = this.getElementByPage('profilePage', 'whoIsWatching');

  openMenu = async () => {
    await commons.tryUntil(this.focusedMenuBar, VRC.BACK, 3, 1);
    if (await commons.elementExists(this.focusedManageProfiles_lbl)) {
      await commons.userAction(VRC.DOWN, 3, 1);
    }
    await commons.tryUntil(this.focusedHomeMenu_lbl, VRC.UP, 7, 1);
  };

  closeMenu = async () => {
    await commons.tryUntil(this.menuBarList, VRC.RIGHT, 2, 1);
  };

  accessGlobalNavigationMenu = async () => {
    await commons.waitUntil(this.focusedHomePage);
    await this.openMenu();
  };

  navigateToPage = async (pageValue) => {
    await this.openMenu();

    if (await commons.elementExists(this.focusedmenuItem[pageValue])) {
      await commons.userAction(VRC.ENTER);
      await commons.assertExists(this.pageFocused[pageValue], 10);
    } else {
      await commons.tryUntil(this.focusedmenuItem[pageValue], VRC.DOWN, 5, 1);
      await commons.userAction(VRC.ENTER);
      await commons.assertExists(this.pageFocused[pageValue], 10);
    }
  };

  getMenuList = async () => {
    if (await commons.elementExists(this.myListMenu_lbl)) {
      return this.menuListLoggedIn;
    }
    return [];
  };

  /**
   * The below function will verify the navigation menu list
   */
  verifyMenuList = async () => {
    await this.openMenu();
    const menuList = await this.getMenuList();

    for (let i = 0; i < menuList.length; i++) {
      await commons.assertExists(this.menuItem[menuList[i]]);
      await commons.userAction(VRC.DOWN, 1, 1);
    }
    await commons.tryUntil(this.focusedHomeMenu_lbl, VRC.UP, 10, 1);
    await this.closeMenu();
  };

  /**
   * The below function will verify the navigation menu pages
   */

  verifyGlobalNavigation = async () => {
    await this.openMenu();
    const menuList = await this.getMenuList();

    for (let i = 0; i < menuList.length; i++) {
      await this.navigateToPage(menuList[i]);
    }
  };

  assertPage = async (pageValue) => {
    await commons.waitUntil(this.pageFocused[pageValue]);
  };

  verifyExitConfirmation = async () => {
    await commons.assertExists(this.exitWindow_txt, 2);
  };

  verifyAppBehavior = async (ctaType) => {
    switch (ctaType) {
      case 'Back':
        await commons.userAction(VRC.BACK, 1, 2);
        if (!(await commons.elementExists(this.focusedHomePage, 2))) {
          if (!(await commons.elementExists(this.whoIsWatching, 2))) {
            throw Error('Unable to return to app');
          }
        }
        break;
      case 'Cancel':
        await onboardingPage.exitFromApp();
        await commons.assertExists(this.cancelCTA_btn, 2);
        await commons.userAction(VRC.SELECT, 1, 2);
        if (!(await commons.elementExists(this.focusedHomePage, 2))) {
          if (!(await commons.elementExists(this.whoIsWatching, 2))) {
            throw Error('Unable to return to app');
          }
        }
        break;
      case 'Exit':
        await onboardingPage.exitFromApp();
        await commons.assertExists(this.exitCTA_btn, 2);
        await commons.userAction(VRC.UP, 1, 2);
        await commons.userAction(VRC.SELECT, 1, 2);
        break;
      default:
        break;
    }
  };
}

module.exports = new MenuPage();
