const { BasePage, remoteActions, testdataHelper } = require('./basePage');

const homePage = require('./homePage');

const commons = remoteActions;

const { VRC, PROP, COMP } = commons;
const adultEntertainmentChannel = testdataHelper.getContent(
  'networkPage.Entertainment',
);

const foodNetworkRail = testdataHelper.getContent(
  'networkPage.foodNetworkRail',
);

class NetworkLandingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('networkLandingPage', locator);
  }

  networkRailChannel = this.getElementByPage('homePage', 'networkRailChannel');

  focusedTlcNetwork_logo = this.#getSelectorData('focusedTlcNetwork_logo');

  tlcPage_logo = this.#getSelectorData('tlcPage_logo');

  tlcNetworkRail_logo = this.#getSelectorData('tlcNetworkRail_logo');

  discoNetworkRail_logo = this.#getSelectorData('discoNetworkRail_logo');

  network_logo = this.#getSelectorData('network_logo');

  recommendedShows = this.#getSelectorData('recommendedShows');

  featuredShows = this.#getSelectorData('featuredShows');

  focusedNetworkRail = this.getElementByPage('homePage', 'focusedNetworkRail');

  showRatingCode_lbl = this.getElementByPage('showPage', 'showRatingCode_lbl');

  unFocusedNetworkRailChannel = this.getElementByPage(
    'homePage',
    'unFocusedNetworkRailChannel',
  );

  navigateToSelectNetwork = async (networkType) => {
    let i = 20;

    while (i > 0) {
      if (
        await commons.elementExists(
          this.getCustomLocator(this.networkRailChannel, networkType),
          1,
        )
      ) {
        await commons.userAction(VRC.ENTER, 1, 5);
        break;
      } else {
        await commons.userAction(VRC.RIGHT);
        i -= 1;
      }
    }
  };

  validateEntertainmentNetwork = async () => {
    await this.validateNetworkByValidUser();
  };

  validateNetworkByValidUser = async () => {
    await commons.elementExists(this.network_logo, 3);
    await commons.elementExists(this.featuredShows, 5);
    await commons.elementExists(this.recommendedShows, 5);
  };

  validateEntertainmentNetworkLandingPage = async () => {
    await this.navigateToSelectNetwork(adultEntertainmentChannel);
    await this.validateEntertainmentNetwork();
  };

  /**
   * The below function will switch on Entertainment/Sports network channel
   *
   * @param {string} network will select Entertainment/Sports Network
   */
  selectAndValidateNetworkLandingPage = async (network) => {
    if (network === 'Entertainment') {
      await this.validateEntertainmentNetworkLandingPage();
    }
  };

  /**
   * The below function will select a Network from network rail
   */
  selectNetworkLogo = async () => {
    await commons.tryUntil(this.discoNetworkRail_logo, VRC.RIGHT, 5, 10);
    await commons.assertExists(this.discoNetworkRail_logo);
    await commons.userAction(VRC.SELECT);
  };

  /**
   * The below function will scroll to the bottom of network detail page and select another network
   */
  scrollToNetworkRailAndSelectNetwork = async () => {
    await commons.tryUntil(this.focusedNetworkRail, VRC.DOWN, 20, 1);
    await commons.assertExists(this.tlcNetworkRail_logo, 3);
    await commons.tryUntil(this.focusedTlcNetwork_logo, VRC.RIGHT, 10);
    await commons.userAction(VRC.SELECT);
  };

  /**
   * The below function will validate network page
   */
  validateNetworkPage = async () => {
    await commons.assertExists(this.tlcPage_logo, 3);
  };

  verifyNetworkRailForKidsProfile = async () => {
    await homePage.scrollToNetworkRail();
    if (this.countryCode === 'us') {
      commons.assertDoesNotExist(
        this.getCustomLocator(
          this.unFocusedNetworkRailChannel,
          adultEntertainmentChannel,
        ),
      );
      await this.navigateToSelectNetwork(foodNetworkRail);
      await commons.userAction(VRC.ENTER, 1, 2);
      await commons.assertProperty(
        this.showRatingCode_lbl,
        PROP.TEXT_CONTENT,
        'G',
        COMP.CONTAIN,
      );
    }
  };
}

module.exports = new NetworkLandingPage();
