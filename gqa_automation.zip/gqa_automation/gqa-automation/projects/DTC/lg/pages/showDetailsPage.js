const { BasePage, remoteActions } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class ShowDetailsPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('showPage', locator);
  }

  showDetailsCTA_btn = this.#getSelectorData('showDetailsCTA_btn');

  watchNowCTA_lbl = this.#getSelectorData('watchNowCTA_lbl');

  myListCTA_lbl = this.#getSelectorData('myListCta_lbl');

  tabGenre_lbl = this.getElementByPage('homePage', 'tabGenre_lbl');

  startWatching_btn = this.getElementByPage('homePage', 'startWatching_btn');

  myList_btn = this.getElementByPage('homePage', 'myList_btn');

  focusedSearchItem_tile = this.getElementByPage(
    'searchPage',
    'focusedSearchItem_tile',
  );

  focusedMyListChecked = this.#getSelectorData('focusedMyListChecked');

  focusedMyListUnchecked = this.#getSelectorData('focusedMyListUnchecked');

  focusedMyListCta = this.#getSelectorData('focusedMyListCta');

  invalidToken_txt = this.getElementByPage(
    'videoPlayerPage',
    'invalidToken_txt',
  );

  validateCTAonShowPage = async () => {
    await commons.waitUntil(this.showDetailsCTA_btn, 10);
    await commons.assertExists(this.myListCTA_lbl, 5);
    await commons.assertExists(this.watchNowCTA_lbl, 5);
    await commons.userAction(VRC.BACK);
  };

  /**
   * Below function is used to validate the CTA buttons on the
   * show details page.
   *
   * @param {string} userType - Authenticated user with a new profile
   * @param {string} genreName - List containing the genre items
   */

  validateCTAonGenres = async (userType, genreName) => {
    const genreArray = genreName.raw();

    if (userType === 'new-profile') {
      for (let i = 0; i < genreArray.length; i++) {
        await commons.tryUntil(
          this.getCustomLocator(this.tabGenre_lbl, genreArray[i].toString()),
          'RIGHT',
          10,
          2,
        );

        // An UP is required because of focus behavior inconsistency
        await commons.userAction(VRC.UP, 1, 2);
        await commons.userAction(VRC.DOWN, 1, 2);
        await commons.assertExists(this.startWatching_btn);
        await commons.userAction(VRC.SELECT, 1, 5);
        await commons.assertExists(this.watchNowCTA_lbl);
        await commons.assertExists(this.myList_btn);

        // Start video
        await commons.userAction(VRC.SELECT, 1, 10);
        await commons.assertVideoIsPlaying(25);

        // Go back to Home
        await commons.userAction(VRC.BACK, 2, 3);
        await commons.userAction(VRC.UP, 1, 3);
      }
    }
  };

  /**
   * Below function is used to select content from search results
   * and start playback from show details page.
   *
   */
  selectAndPlayVideo = async () => {
    // The focus behavior on the search page is somewhat inconsistent.
    // So we are making sure that the focus lands on the first tile before
    // making a selection.
    await commons.userAction(VRC.UP, 5, 1);
    await commons.tryUntil(this.focusedSearchItem_tile, VRC.DOWN, 4, 1);
    await commons.userAction(VRC.SELECT);

    // Select content for playback from show details page
    await commons.waitUntilVisible(this.watchNowCTA_lbl, 10);
    await commons.assertExists(this.watchNowCTA_lbl);
    await commons.userAction(VRC.SELECT);
  };

  verifyShowLandingPage = async (ctaName) => {
    switch (ctaName) {
      case 'Watch Now CTA':
        await commons.tryUntil(this.watchNowCTA_lbl, VRC.DOWN, 4, 1);
        await commons.assertExists(this.watchNowCTA_lbl, 5);
        await commons.userAction(VRC.SELECT);

        if (await commons.elementExists(this.invalidToken_txt, 10)) {
          throw new Error('Error in playback: Invalid Token');
        }

        await commons.assertVideoIsPlaying(45);
        await commons.userAction(VRC.BACK);
        break;
      case 'My List CTA':
        await commons.waitUntil(this.myListCTA_lbl, 5);
        await commons.tryUntil(this.focusedMyListCta, VRC.RIGHT, 4, 1);
        await commons.assertExists(this.focusedMyListUnchecked, 5);
        await commons.userAction(VRC.SELECT);
        await commons.assertExists(this.focusedMyListChecked, 5);
        break;
      default:
        throw new Error('Validation failed');
    }
  };
}

module.exports = new ShowDetailsPage();
