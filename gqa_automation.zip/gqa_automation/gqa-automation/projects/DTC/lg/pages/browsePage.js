const { BasePage, testdataHelper, remoteActions } = require('./basePage');

const menuPage = require('./menuPage');
const profilePage = require('./profilePage');

const commons = remoteActions;

const { VRC } = commons;

class BrowsePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('browsePage', locator);
  }

  watchNowCTA_lbl = this.getElementByPage('showPage', 'watchNowCTA_lbl');

  invalidToken_txt = this.getElementByPage(
    'videoPlayerPage',
    'invalidToken_txt',
  );

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  browsePageMenu = this.#getSelectorData('browsePageMenu');

  browsePageMenuItem = this.#getSelectorData('browsePageMenuItem');

  browsePageSubNavMenu = this.#getSelectorData('browsePageSubNavMenu');

  focusedSubNav = this.#getSelectorData('focusedSubNav');

  focusedSubNavItem = this.#getSelectorData('focusedSubNavItem');

  browsePageTile = this.#getSelectorData('browsePageTile');

  focusedBrowsePageTile = this.#getSelectorData('focusedBrowsePageTile');

  browseShows_btn = this.getElementByPage('myListPage', 'browseShows_btn');

  /**
   * Below function is used to select Browse Page
   *
   * @param {string} pageType - set to Browse Page
   */
  selectPage = async (pageType) => {
    if (!(await commons.elementExists(this.focusedHomePage))) {
      await profilePage.selectProfile('Default');
    }
    await menuPage.navigateToPage(pageType);
  };

  /**
   * Below function is used to verify that Browse Page is loaded
   *
   */
  verifyBrowsePage = async () => {
    await commons.assertExists(this.browsePageMenu);
  };

  /**
   * Below function is used to select the network tab
   *
   * @param {string} networkType - set to Entertainment
   */
  selectNetwork = async (networkType) => {
    const browsePageEntertainment = testdataHelper.getContent(
      `networkPage.${networkType}`,
    );

    await commons.tryUntil(
      this.getCustomLocator(this.browsePageMenuItem, browsePageEntertainment),
      VRC.RIGHT,
      5,
      5,
    );

    await commons.assertExists(
      this.getCustomLocator(this.browsePageMenuItem, browsePageEntertainment),
      5,
    );
  };

  /**
   * Below function is used to verify that shows are present in the network
   *
   */
  verifyShowOnSelectedNetwork = async () => {
    await commons.assertExists(this.browsePageTile, 2);
  };

  /**
   * Below function is used to select the sub nav item
   *
   * @param {string} subNav - set to A-Z
   */
  selectSubNav = async (subNav) => {
    const browsePageSubNavTab = testdataHelper.getContent(
      `browsePage.${subNav}`,
    );
    const moveToItem = this.getCustomLocator(
      this.focusedSubNavItem,
      browsePageSubNavTab,
    );

    await commons.tryUntil(this.focusedBrowsePageTile, VRC.DOWN, 3, 1);
    await commons.userAction(VRC.UP);
    await commons.tryUntil(moveToItem, VRC.RIGHT, 5);
    await commons.assertExists(moveToItem, 5);
  };

  /**
   * Below function is used to verify show card on selected sub nav
   *
   */
  verifyShowCard = async () => {
    await commons.tryUntil(this.focusedBrowsePageTile, VRC.DOWN, 2, 1);
    await commons.assertExists(this.focusedBrowsePageTile);
    await commons.userAction(VRC.SELECT);
    await commons.waitUntil(this.watchNowCTA_lbl, 5);
    await commons.assertExists(this.watchNowCTA_lbl, 5);
  };

  selectAsset = async () => {
    await this.verifyShowCard();
  };
}

module.exports = new BrowsePage();
