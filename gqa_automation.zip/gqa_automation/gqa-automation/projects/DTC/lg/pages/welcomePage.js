const { BasePage, testdataHelper, remoteActions } = require('./basePage');

const commons = remoteActions;
const { VRC, PROP, COMP } = commons;

class WelcomePage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('welcomePage', locator);
  }

  welcomePage = this.#getSelectorData('welcomeScreen');

  welcomePageSignIn_btn = this.#getSelectorData('signIn_btn');

  welcomeTitle_lbl = this.#getSelectorData('welcomeTitle');

  focusedSignIn_btn = this.#getSelectorData('focusedSignIn_btn');

  subscribeNow_btn = this.#getSelectorData('subscribeNow_btn');

  focusedSubscribeNow_btn = this.#getSelectorData('focusedSubscribeNow_btn');

  chooseYourPlan_lbl = this.getElementByPage(
    'planPickerPage',
    'chooseYourPlan_lbl',
  );

  userName_txtBx = this.getElementByPage('signInPage', 'userName_txtBx');

  password_txtBx = this.getElementByPage('signInPage', 'password_txtBx');

  signIn_btn = this.getElementByPage('signInPage', 'signIn_btn');

  verifyWelcomeScreen = async () => {
    await commons.assertVisible(this.welcomePage, 15);
    await this.verifyWelcomeScreenLocalizedMetadata();
  };

  verifyWelcomeScreenLocalizedMetadata = async () => {
    await commons.assertVisible(this.subscribeNow_btn, 10);
    await commons.assertProperty(
      this.welcomeTitle_lbl,
      PROP.TEXT_CONTENT,
      testdataHelper.getContent('welcomePage.welcomeTitle'),
      COMP.CONTAIN,
    );
    await commons.assertProperty(
      this.subscribeNow_btn,
      PROP.TEXT_CONTENT,
      testdataHelper.getContent('welcomePage.subscribeNowBtn'),
      COMP.EQUAL,
    );
    await commons.assertProperty(
      this.welcomePageSignIn_btn,
      PROP.TEXT_CONTENT,
      testdataHelper.getContent('welcomePage.signInBtn'),
      COMP.EQUAL,
    );
  };

  verifyLandingPageOfWelcomeScreen = async (CTAName) => {
    await commons.assertVisible(this.welcomePage, 10);
    if (CTAName === 'Subscribe Now') {
      await commons.tryUntil(this.focusedSubscribeNow_btn, VRC.UP, 2, 1);
      await commons.userAction(VRC.ENTER);
      await commons.assertVisible(this.chooseYourPlan_lbl, 10);
    } else if (CTAName === 'Sign In') {
      await commons.tryUntil(this.focusedSignIn_btn, VRC.DOWN, 2, 1);
      await commons.userAction(VRC.ENTER);
      await commons.assertVisible(this.userName_txtBx, 10);
      await commons.assertVisible(this.password_txtBx, 1);
      await commons.assertVisible(this.signIn_btn, 1);
    }
    await commons.tryUntil(this.welcomePage, VRC.BACK, 2, 5);
    await commons.assertVisible(this.welcomePage, 10);
  };
}

module.exports = new WelcomePage();
