const { BasePage, remoteActions, testdataHelper } = require('./basePage');
const menuPage = require('./menuPage');
const profilePage = require('./profilePage');

const commons = remoteActions;
const { VRC } = commons;

class AccountPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('accountPage', locator);
  }

  accountTitle_lbl = this.#getSelectorData('accountTitle_lbl');

  accountTab_lbl = this.#getSelectorData('accountTab_lbl');

  accountTabManageSubs_lbl = this.#getSelectorData('accountTabManageSubs_lbl');

  help_tab = this.#getSelectorData('help_tab');

  account_tab = this.#getSelectorData('account_tab');

  signOut_tab = this.#getSelectorData('signOut_tab');

  signOutBtn_lbl = this.#getSelectorData('signOutBtn_lbl');

  helpTabText = this.#getSelectorData('helpTabText');

  aboutTabText = this.#getSelectorData('aboutTabText');

  about_tab = this.#getSelectorData('about_tab');

  accountPageSubMenu = {
    Account: this.account_tab,
    Help: this.help_tab,
    About: this.about_tab,
    'Sign Out': this.signOut_tab,
  };

  getUserAccountMenuItems = (profileName) => {
    const accountType = {
      Default: 'defaultUserAccountItemListHwa',
      Kids: 'kidsUserAccountItemListHwa',
    };

    return testdataHelper.getContent(`accountPage.${accountType[profileName]}`);
  };

  accountSubNavigationPage = async (tabName) => {
    switch (tabName) {
      case 'Account':
        await commons.assertExists(this.accountTabManageSubs_lbl);
        break;
      case 'Help Centre':
        await commons.assertExists(this.helpTabText);
        break;
      case 'About':
        await commons.assertExists(this.aboutTabText);
        break;
      case 'Sign Out':
        await commons.assertExists(this.signOutBtn_lbl);
        break;
      default:
        break;
    }
  };

  verifyAccountPage = async (profileName) => {
    await profilePage.selectProfile(profileName);

    await menuPage.navigateToPage('Account');
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      await commons.assertExists(this.accountPageSubMenu[accountMenuList[i]]);
    }
  };

  verifyAccountSubNavigationPage = async (profileName) => {
    const accountMenuList = this.getUserAccountMenuItems(profileName);

    for (let i = 0; i < accountMenuList.length; i++) {
      await commons.waitUntil(this.accountPageSubMenu[accountMenuList[i]]);
      await this.accountSubNavigationPage(accountMenuList[i]);
      await commons.userAction(VRC.RIGHT, 1, 2);
    }
  };
}

module.exports = new AccountPage();
