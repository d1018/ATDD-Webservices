const { BasePage, remoteActions } = require('./basePage');

const profilePage = require('./profilePage');

const commons = remoteActions;

const { VRC, PROP } = commons;

const timeProgressed = [];

class VideoPlayerPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('videoPlayerPage', locator);
  }

  watchNowCTA_lbl = this.getElementByPage('showPage', 'watchNowCTA_lbl');

  currentTime = this.#getSelectorData('currentTime');

  invalidToken_txt = this.#getSelectorData('invalidToken_txt');

  progressBar = this.#getSelectorData('progressBar');

  skipIntro_btn = this.#getSelectorData('skipIntro_btn');

  /**
   * Below function is used to validate the video resumes from where
   * it stopped from Continue Watching rail.
   *
   */
  validateResumePoint = async () => {
    // Get the time from which video will resume
    await this.collectVideoDetails(true);

    const timeInSeconds = [];

    // To calculate time in seconds
    for (let i = 0; i < timeProgressed.length; i++) {
      timeInSeconds.push(
        +timeProgressed[i].split(':')[0] * 60 +
          +timeProgressed[i].split(':')[1],
      );
    }

    // We are making sure that the resume point is within a timeframe
    // of ±8 seconds to take into consideration the delay between playback
    // and actual collection of the time progressed.
    if (Math.abs(timeInSeconds[0] - timeInSeconds[1]) > 8) {
      await profilePage.deleteExistingProfile();
      throw new Error('Video did not continue from the resume point!');
    }
  };

  /**
   * Below function is used to scrub video.
   *
   */
  scrubVideo = async () => {
    // To collect the time progressed
    await this.collectVideoDetails();

    // Exit playback and return to show details page
    await commons.tryUntil(this.watchNowCTA_lbl, VRC.BACK, 3, 2);
  };

  /**
   * Below function is used to collect the time progressed from video playback.
   *
   * @param {boolean} isVideoProgressed - set as Home, Channel, Show Details Page etc.
   */
  collectVideoDetails = async (isVideoProgressed = false) => {
    // To handle failure due to token issues
    if (await commons.elementExists(this.invalidToken_txt, 10)) {
      await profilePage.deleteExistingProfile();
      throw new Error('Error in playback: Invalid Token');
    } else {
      await commons.waitTillVideoIsPlaying(45);
      await commons.tryUntil(this.progressBar, VRC.DOWN, 3, 2);

      // This flag is true only for Continue Watching scenario
      if (!isVideoProgressed) {
        if (await commons.elementExists(this.skipIntro_btn)) {
          await commons.userAction(VRC.SELECT);
          await commons.waitTillVideoIsPlaying(45);
        } else {
          await commons.userAction(VRC.RIGHT, 4, 2);
          await commons.userAction(VRC.SELECT, 4, 3);
          await commons.userAction(VRC.LEFT, 1, 1);
          await commons.userAction(VRC.SELECT);
        }
      }

      await commons.tryUntil(this.progressBar, VRC.DOWN, 5, 3);
      await commons.userAction(VRC.SELECT);
      await commons.assertExists(this.currentTime);

      // Grab the progressed time of the video
      timeProgressed.push(
        await commons.fetchAttributeData(this.currentTime, PROP.TEXT_CONTENT),
      );
    }
  };
}

module.exports = new VideoPlayerPage();
