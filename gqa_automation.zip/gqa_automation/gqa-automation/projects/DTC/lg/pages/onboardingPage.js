const { remoteActions, BasePage } = require('./basePage');

const commons = remoteActions;
const { VRC } = commons;

class OnboardingPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('onboardingPage', locator);
  }

  focusedHomePage = this.getElementByPage('homePage', 'focusedHomePage');

  exitWindow_txt = this.getElementByPage('exitPage', 'exitWindow_txt');

  menuBarList = this.getElementByPage('menuPage', 'menuBarList');

  noSubscriptionTitle_lbl = this.getElementByPage(
    'inactiveSubscriptionPage',
    'noSubscriptionTitle_lbl',
  );

  noSubscriptionSubTitle_lbl = this.getElementByPage(
    'inactiveSubscriptionPage',
    'noSubscriptionSubTitle_lbl',
  );

  exitFromApp = async () => {
    if (await commons.elementExists(this.focusedHomePage, 10)) {
      await commons.tryUntil(this.menuBarList, VRC.BACK, 5);
    }
    await commons.tryUntil(this.exitWindow_txt, VRC.BACK, 5);
  };

  selectCTA = async (cta) => {
    if (cta === 'Back') {
      await this.exitFromApp();
    }
  };

  verifyInactiveSubscriptionScreen = async () => {
    await commons.waitUntil(this.noSubscriptionTitle_lbl, 20);
    await commons.assertVisible(this.noSubscriptionSubTitle_lbl, 20);
  };
}

module.exports = new OnboardingPage();
