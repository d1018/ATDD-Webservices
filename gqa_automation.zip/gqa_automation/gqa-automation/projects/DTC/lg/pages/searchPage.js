const { remoteActions, testdataHelper, BasePage } = require('./basePage');

const commons = remoteActions;
const { VRC, PROP, COMP } = commons;

const searchResultsTab = testdataHelper.getContent(
  'searchPage.searchResultTabs',
);

const multiContentSearch = testdataHelper.getContent(
  'searchPage.multiContentShow',
);

class SearchPage extends BasePage {
  #getSelectorData(locator) {
    return this.getElementByPage('searchPage', locator);
  }

  search_txtBx = this.#getSelectorData('search_txtBx');

  searchPageTab_lbl = this.#getSelectorData('searchPageTab_lbl');

  searchResultsContainer = this.#getSelectorData('searchResultsContainer');

  searchResultsTabMenu = this.#getSelectorData('searchResultsTabMenu');

  showTitle_lbl = this.#getSelectorData('showTitle_lbl');

  showTitle = this.#getSelectorData('showTitle_lbl');

  focusedSearchItem = this.#getSelectorData('focusedSearchItem_tile');

  collectionsFirstTile_tile = this.#getSelectorData(
    'collectionsFirstTile_tile',
  );

  focusedShowPage = this.getElementByPage('showPage', 'focusedShowsPage');

  watchNowCTA_lbl = this.getElementByPage('showPage', 'watchNowCTA_lbl');

  invalidToken_txt = this.getElementByPage(
    'videoPlayerPage',
    'invalidToken_txt',
  );

  noResultsLabel_lbl = this.#getSelectorData('noResultsLabel_lbl');

  recommendedForYou_lbl = this.#getSelectorData('recommendedForYou_lbl');

  focusedRecommendedForYouItem_tile = this.#getSelectorData(
    'focusedRecommendedForYouItem_tile',
  );

  focusedShowDetailsPage = this.getElementByPage(
    'showPage',
    'focusedShowDetailPage',
  );

  selectFirstRecommendedForYou = async () => {
    await commons.assertExists(this.focusedRecommendedForYouItem_tile);
    await commons.userAction(VRC.SELECT);
  };

  verifyLandedOnSeriesDetail = async (cta) => {
    await commons.waitUntil(this.focusedShowDetailsPage);
    if (cta === 'Watch Now CTA') {
      await commons.assertExists(this.watchNowCTA_lbl, 50);
    } else if (cta === 'My List CTA') {
      await commons.assertExists(this.myListCTA_lbl, 10);
    }
  };

  /**
   * Below function is used to search for content from the search screen
   *
   * @param {string} searchText - Text to search
   */
  searchText = async (searchText) => {
    await commons.assertExists(this.search_txtBx, 2);
    await commons.userAction(VRC.UP, 3, 1);
    await commons.userAction(VRC.ENTER);
    await commons.sendText(
      testdataHelper.getContent(`searchPage.${searchText}`),
    );
    await commons.userAction(VRC.BACK);
  };

  verifyNoResultFound = async () => {
    await commons.waitUntil(this.noResultsLabel_lbl, 10);
    await commons.assertExists(this.noResultsLabel_lbl, 2);
  };

  verifyRecommendedForYou = async () => {
    await commons.waitUntil(this.recommendedForYou_lbl, 10);
    await commons.assertExists(this.recommendedForYou_lbl, 2);
  };

  /**
   * Below function is used to verify search content
   *
   */
  verifySearchedContentAndItsLandingPage = async () => {
    await this.verifySearchContentTabMenu();

    for (let count = 0; count < searchResultsTab.length; count++) {
      await commons.tryUntil(this.focusedSearchItem, VRC.DOWN, 1);
      await commons.assertExists(this.focusedSearchItem);
      await commons.userAction(VRC.SELECT);
      await this.verifySearchedContentLandingPage(searchResultsTab[count]);

      // Switch focus to tab menu
      await commons.tryUntil(
        this.getCustomLocator(this.searchPageTab_lbl, searchResultsTab[count]),
        VRC.UP,
        2,
        2,
      );

      // Move to next tab on menu
      await commons.userAction(VRC.RIGHT, 1, 1);
    }
  };

  /**
   * Below function is used to verify that the search tab
   * menu is correctly displayed based on test data
   *
   */
  verifySearchContentTabMenu = async () => {
    await commons.waitUntil(this.searchResultsTabMenu, 5);
    await commons.userAction(VRC.DOWN);
    for (let count = 0; count < searchResultsTab.length; count++) {
      // Focus is sometimes unstable, so we want to make sure the tab item
      // is in focus.
      await commons.tryUntil(
        this.getCustomLocator(
          this.searchPageTab_lbl,
          searchResultsTab[count].toString(),
        ),
        VRC.UP,
        4,
      );
      await commons.assertExists(this.searchResultsContainer);
      await commons.assertExists(
        this.getCustomLocator(
          this.searchPageTab_lbl,
          searchResultsTab[count].toString(),
        ),
        4,
      );

      // Validate that the Shows page contains the searched item
      if (searchResultsTab[count] === 'Shows') {
        if (
          !(await commons.checkProperty(
            this.showTitle_lbl,
            PROP.TEXT_CONTENT,
            multiContentSearch,
            COMP.EQUAL,
          ))
        ) {
          throw new Error('Search results do not contain searched item!');
        }
      }
      await commons.userAction(VRC.RIGHT, 1);
    }

    // Return focus to Shows tab
    for (let count = searchResultsTab.length - 1; count >= 0; count--) {
      await commons.tryUntil(
        this.getCustomLocator(this.searchPageTab_lbl, searchResultsTab[count]),
        VRC.UP,
        2,
        2,
      );
      if (
        await commons.elementExists(
          this.getCustomLocator(this.searchPageTab_lbl, 'Shows'),
        )
      ) {
        break;
      }
      await commons.userAction(VRC.LEFT, 1);
    }
  };

  /**
   * Below function is used to search for content from the search screen
   *
   * @param {string} tabName - menu item name - 'Shows', 'Episodes' etc.
   */
  verifySearchedContentLandingPage = async (tabName) => {
    switch (tabName) {
      case 'Shows':
        await commons.waitUntil(this.watchNowCTA_lbl, 10);
        await commons.assertExists(this.watchNowCTA_lbl, 5);
        await commons.userAction(VRC.SELECT);
        if (commons.elementExists(this.invalidToken_txt, 25)) {
          await commons.userAction(VRC.BACK, 2, 2);
          break;
        }
        await commons.assertVideoIsPlaying(45);
        await commons.userAction(VRC.BACK, 2, 1);
        break;
      case 'Episodes':
      case 'Specials':
      case 'Extras':
        if (commons.elementExists(this.invalidToken_txt, 25)) {
          await commons.userAction(VRC.BACK);
          break;
        }
        await commons.assertVideoIsPlaying(45);
        await commons.userAction(VRC.BACK);
        break;
      case 'Collections':
        await commons.assertExists(this.collectionsFirstTile_tile, 5);
        await commons.userAction(VRC.SELECT);
        if (commons.elementExists(this.invalidToken_txt, 25)) {
          await commons.userAction(VRC.BACK, 2, 2);
          break;
        }
        await commons.assertVideoIsPlaying(45);
        await commons.userAction(VRC.BACK, 2, 2);
        break;
      default:
        throw new Error('Search content landing not available!');
    }
  };
}

module.exports = new SearchPage();
