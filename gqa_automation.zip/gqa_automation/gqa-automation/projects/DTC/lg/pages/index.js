const accountPage = require('./accountPage');
const browsePage = require('./browsePage');
const homePage = require('./homePage');
const menuPage = require('./menuPage');
const myListPage = require('./myListPage');
const profilePage = require('./profilePage');
const searchPage = require('./searchPage');
const networkLandingPage = require('./networkLandingPage');
const showDetailsPage = require('./showDetailsPage');
const signInPage = require('./signInPage');
const welcomePage = require('./welcomePage');
const onboardingPage = require('./onboardingPage');
const videoPlayerPage = require('./videoPlayerPage');

module.exports = {
  accountPage,
  browsePage,
  homePage,
  menuPage,
  myListPage,
  profilePage,
  searchPage,
  showDetailsPage,
  networkLandingPage,
  signInPage,
  welcomePage,
  onboardingPage,
  videoPlayerPage,
};
