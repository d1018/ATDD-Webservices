const {
  createRunnerTasks,
  createHeadspinTasks,
  createSuitestTasks,
  createUtilsTasks,
  createReportTask,
  createJiraTask,
} = require('@wbd/gqa-core/tasks');

createRunnerTasks({
  jiraConfigFile: 'jiraConfig.js',
});
createHeadspinTasks();
createSuitestTasks();
createUtilsTasks();
createReportTask();
createJiraTask('jiraConfig.js');
