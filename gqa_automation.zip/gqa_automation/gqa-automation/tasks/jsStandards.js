const { runCommandOnFileDiffs } = require('@wbd/gqa-core/tasks/utils');

const fileMatcher = 'js$';
const [action] = process.argv.map((val) => val).slice(2);

let failed = false;

// eslint
const eslintCommand = `npx eslint ${
  action === 'fix' ? '--fix' : ''
}  --rulesdir ./customJsRules`;

try {
  runCommandOnFileDiffs(
    fileMatcher,
    eslintCommand,
    'ESLIINT ISSUES: Run `npm run js:fix`. See how to fix / avoid these issues here: https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3432579262/Code+quality+lint+rubocop+and+formatting+prettier',
  );
} catch (e) {
  failed = true;
}

// prettier
const prettierCommand = `npx prettier ${action === 'fix' ? '-w' : '-c'}`;

try {
  runCommandOnFileDiffs(
    fileMatcher,
    prettierCommand,
    'FORMATTING ISSUES: Run `npm run js:fix`. See how to fix your issues here: https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3432579262/Code+quality+lint+rubocop+and+formatting+prettier',
  );
} catch (e) {
  failed = true;
}

if (failed) {
  process.exit(1);
}
