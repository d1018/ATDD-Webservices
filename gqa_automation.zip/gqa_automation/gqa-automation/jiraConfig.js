// see the following for more details of this config file:
// https://github.com/wbd-streaming/gqa-core/blob/main/docs/jiraAutoBug.md#highlevel-workflow
module.exports = {
  logDir: 'results/jira',
};
