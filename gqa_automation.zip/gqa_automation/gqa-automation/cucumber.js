const { join } = require('path');
const { paths } = require('@wbd/gqa-core/support');

const retry = process.env.RETRY === 'true' ? 1 : 0;

const projectPath = process.env.PROJECT || 'DTC';

// reference: https://github.com/cucumber/cucumber-js/blob/main/docs/profiles.md
module.exports = {
  default: {
    publishQuiet: false,
    retry,
    tags: process.env.CUCUMBER_TAG || 'not @wip',
    require: [`projects/${projectPath}/**/**/**/*.js`],
    format: [`json:${join(paths.results, 'json_report.json')}`],
  },
  debug: {
    publishQuiet: false,
    format: [`json:${join(paths.results, 'json_report.json')}`],
  },
};
