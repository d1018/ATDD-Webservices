package com.Utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Properties;

public class commonFunction {

	public static Connection getINetDBConnection() throws Exception {
		String driver = "net.sourceforge.jtds.jdbc.Driver";
		String url = "jdbc:jtds:sqlserver://DBSET1664:1433;DatabaseName=INETFORMULARY";
		String username = "runx_ecs_svc";
		String password = "meC3f=vX";

		Class.forName(driver);
		Connection conn = DriverManager.getConnection(url, username, password);
		return conn;
	}
	
	public static Connection getRxClaimDBConnection() throws Exception {
		String driver = "com.ibm.as400.access.AS400JDBCDriver";
		String url = "jdbc:as400:RXBK2QA;libraries=*LIB;naming=system";
		String username = "ORXWEB";
		String password = "bwx1oer5";

		Class.forName(driver);
		Connection conn = DriverManager.getConnection(url, username, password);
		return conn;
	}
	
	public String getInputFieldfromTDMPropertyFile(String servicename)
	{
		
		Properties InputField;
		InputField=new Properties();
		InputStream InputFile = null;
		try {
			InputFile= new FileInputStream(new File("src/test/resources/TDM/InputRequest.properties"));
			InputField.load(InputFile);
			
		}catch (IOException ex) {
			System.out.println("unable to read property file");
		}
		
		String request = (InputField.getProperty(servicename));
		
		return request;
		
	}
	
	public String getParametersforSP(String DataList ,ArrayList<String> InputParam )
	{
		String tempData[];
		String parametertoPass=""; 
		String[] InputDataList = DataList.split(",");
		
		try
		{
			for(int ip=0;ip<InputParam.size();ip++)
			{
				try {
						for(int j=0;j<InputDataList.length+1;j++){
							String valData=InputDataList[j];
							if(!valData.equals("")){
								tempData=valData.split(":");
								if(InputParam.get(ip).toUpperCase().contains(tempData[0].toUpperCase()))
								{
									parametertoPass = parametertoPass + "'" + tempData[1] + "'"+",";
									break;
								}
							}
						}
					
				}catch(Exception e){
					
					parametertoPass = parametertoPass + null +",";					
				}				
			}			
		}catch(Exception e){
			System.out.println(e.getMessage());			
		}
		 if (parametertoPass.endsWith(",")) {
			 parametertoPass = parametertoPass.substring(0, parametertoPass.length() - 1);
		 }		
		return parametertoPass;
		
	}
	
	public String getDataFromDBUsingParameter(String parametertoPass,Connection conn,String SP_Name) throws Exception {
	
		ArrayList<String> existingTagCheck = new ArrayList<String>();
		String finalValue = "";

		try {
			CallableStatement cStmt = conn.prepareCall("{call " + SP_Name + "(" + parametertoPass + ")}");
			
			cStmt.executeQuery();
			boolean results = cStmt.execute();
			while(results)
			{
				ResultSet finalResult = cStmt.getResultSet();
				ResultSetMetaData colu = finalResult.getMetaData();
				int colm = colu.getColumnCount();
				System.out.println(colm);		
				while(finalResult.next())
				{
					for(int v = 1;v<colm+1;v++)
					{
						String ColumnName = colu.getColumnName(v).replaceAll("[\\s_&/+$@]", "");
						
						try
						{
							String tempVariable = finalResult.getString(v).toString().replaceAll("\\s+$", "");
							if(tempVariable.matches("")||tempVariable==null)
							{
								int occurrences = Collections.frequency(existingTagCheck, ColumnName);
								if(occurrences != 0)
								{
									finalValue = (finalValue+ColumnName.replaceAll("[\\s_&/+$@]","")+ occurrences+":"+ "Blank" + "->");
									existingTagCheck.add(ColumnName);
								}else
								{
									finalValue = (finalValue+ColumnName.replaceAll("[\\s_&/+$@]","")+":"+ "Blank" + "->");
									existingTagCheck.add(ColumnName);
								}
								
							}else
							{
								int occurrences = Collections.frequency(existingTagCheck, ColumnName);
								if(occurrences != 0)
								{
									finalValue = (finalValue+ColumnName.replaceAll("[\\s_&/+$@]","")+ occurrences+":"+finalResult.getString(v).replaceAll("\\s", "").trim()+ "->");
									existingTagCheck.add(ColumnName);
								}else
								{
									finalValue = (finalValue+ColumnName.replaceAll("[\\s_&/+$@]","")+":"+finalResult.getString(v).replaceAll("\\s", "").trim()+ "->");
									existingTagCheck.add(ColumnName);
								}
							}
							
						}catch(Exception e){
							
						}

							
						}
					}
						finalResult.close();
						results = cStmt.getMoreResults();
				}
			
			cStmt.close();	 

			}catch(Exception e){ System.out.println(e.getMessage());}
		

		 conn.close();
		
		return finalValue;
	}
	
	
	
	

}
