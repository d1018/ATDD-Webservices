package com.stepDefination;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import com.Utility.commonFunction;

public class StepDefination {

	commonFunction com = new commonFunction();
	Connection conn = null;
	ResultSet rs = null;
	ArrayList<String> InputParam = new ArrayList<String>();
	String parametertoPass="";
	String finalValue = "";
	String SP_Name="";
	

	@SuppressWarnings("unused")
	@Given("^RxClaim DB Credential \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void rxclaim_DB_Credential(String SPName, String DBName, String Schema) throws Throwable {
		SP_Name = SPName;
		conn = com.getRxClaimDBConnection();
		System.out.println("Connected to the database!!! Successful...");
		
		Statement st = conn.createStatement();
		DatabaseMetaData dbm = conn.getMetaData();
		rs = dbm.getProcedureColumns(DBName, Schema , SP_Name, null);

		while (rs.next()) {
			InputParam.add(rs.getString(4).replaceAll("[@/]", ""));
			System.out.println(InputParam.toString());
		}

	}

	@When("^Passing parameter to SP using \"([^\"]*)\"$")
	public void passing_parameter_to_SP_using(String servicename) throws Throwable {

		String DataList =com.getInputFieldfromTDMPropertyFile(servicename);
		System.out.println(DataList);		
		parametertoPass=com.getParametersforSP(DataList,InputParam );
		
		System.out.println(parametertoPass);				
	}

	@Then("^Get values from DB$")
	public void get_values_from_DB() throws Throwable {
		
		finalValue=com.getDataFromDBUsingParameter (parametertoPass,conn,SP_Name);
		 
		 try (Writer writer = new BufferedWriter(new OutputStreamWriter(
	            new FileOutputStream("src/test/resources/Result/TestResult.txt"), "utf-8"))) {
			 	writer.write(finalValue);
		 }	
	}

	@Then("^Close the DB connection$")
	public void close_the_DB_connection() throws Throwable {
		
		rs.close();
		conn.close();

	}

}
