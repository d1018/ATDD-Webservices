package com.uhg.optumrx.ms.hemi.address.service;

import com.uhg.optumrx.ms.hemi.address.cosmos.AddressDao;
import com.uhg.optumrx.ms.hemi.address.domain.*;
import com.uhg.optumrx.ms.hemi.address.util.AddressRecordConverter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AddressDataService {

    @Autowired
    private AddressDao addressDao;

    private static final Logger logger = LogManager.getLogger(AddressDataService.class);

    public boolean processAddressData(PartyAddress address) {
        return upsertAddress(address);
    }

    public boolean processLocationData(PartyLocation location) {
        boolean isSuccessful = true;
        String locationId = location.getLocationId();
        List<AddressDocument> documents = addressDao.searchAddressByLocationId(locationId);
        if (documents.isEmpty()) {
            logger.error("Failed to find corresponding Address in Cosmos DB with locationId " + locationId);
            isSuccessful = false;
        } else {
            for (AddressDocument document : documents) {
                boolean shouldUpdateDocument = false;
                for (Address address : document.getAddressList()) {
                    if (locationId.equals(address.getLocationId())) {
                        address.setAddress1(location.getAddress1());
                        address.setAddress2(location.getAddress2());
                        address.setAddress3(location.getAddress3());
                        address.setCity(location.getCity());
                        address.setState(location.getState());
                        address.setZip(location.getZip());
                        address.setAzureUpdateDate(AddressRecordConverter.currentISOUtcDateTime());
                        shouldUpdateDocument = true;
                        break; // assuming location id is unique in each Address of Address List
                    }
                }
                if (shouldUpdateDocument) {
                    boolean upserted = addressDao.saveOrReplaceAddressData(document, false);
                    if (!upserted) {
                        isSuccessful = false;
                        logger.error("Failed to Update Address for the locationId " + locationId);
                        logger.info("Trying again to update location");
                        processLocationData(location);
                        
                    } else {
                        logger.info("Updated Address with Location Id " + locationId + document.toString());
                    }
                }
            }
        }
        return isSuccessful;
    }

    public boolean processPsuData(PartySiteUse psu) {
        boolean isSuccessful = true;
        String partySiteId = psu.getPsId();
        List<AddressDocument> documents = addressDao.searchAddressByPartySiteId(partySiteId);
        if (documents.isEmpty()) {
            logger.error("Failed to find corresponding Address in Cosmos DB with partySiteId " + partySiteId);
        } else if (documents.size() > 1) {
            logger.error("There should be one Address but found more with partySiteId " + partySiteId);
        } else {
            Usage newUsage = AddressRecordConverter.convertToUsage(psu);
            AddressDocument document = documents.get(0);
            boolean shouldUpdateDocument = false;
            for (Address address : document.getAddressList()) {
                if (address.getPartySiteId().equals(partySiteId)) {
                    int usageIdx = -1;
                    boolean foundMatchPSU = false;
                    for (Usage usage : address.getUsageList()) {
                        usageIdx++;
                        if (newUsage.getPartySiteUseId().equals(usage.getPartySiteUseId())) {
                            foundMatchPSU = true;
                            shouldUpdateDocument = true;
                            break; // assuming party site use id is unique in each Usage of Address
                        }
                    }
                    if (foundMatchPSU) {
                        if (address.getUsageList().get(usageIdx).getAzureCreateDate() != null) {
                            newUsage.setAzureCreateDate(address.getUsageList().get(usageIdx).getAzureCreateDate());
                        }
                        address.getUsageList().set(usageIdx, newUsage);
                        logger.debug("Replaced PSU of Address/PS " + document.getPartyId() + "/" + address.getPartySiteId() + " with " + newUsage);
                    }
                    break; // assuming party site id is unique in each Address of Address List
                }
            }
            if (shouldUpdateDocument) {
                boolean upserted = addressDao.saveOrReplaceAddressData(document, false);
                if (!upserted) {
                    isSuccessful = false;
                    logger.error("Failed to Update Address for the PSU "+ partySiteId);
                    logger.info("Trying again to update PartySiteUse");
                    processPsuData(psu);
                    
                } else {
                    logger.info("Replaced Address with partySiteId " + partySiteId);
                }
            }
        }
        return isSuccessful;
    }
    
    public boolean upsertAddress(PartyAddress address){
    	boolean isSuccessful = true;
    	String partySiteId = address.getPartySiteId();
    	List<AddressDocument> checkDocument = addressDao.searchAddressByPartySiteId(partySiteId);
    	if(checkDocument.size()==1){
    		return updateAddress(address);
    	}
    	else if(checkDocument.size()>1){
    		logger.error("Multiple address for same partySiteId" + partySiteId);
    		isSuccessful=false;
    		return isSuccessful;
    	}
    	
    	String partyId = address.getPartyId();
    	AddressDocument addressDocument = addressDao.searchAddressByPartyId(partyId);
    	if(addressDocument==null){
    		logger.error("Could not find the PartyId " + partyId);
    		isSuccessful = false;
    		return isSuccessful;
    	}
    	Address newAddress = AddressRecordConverter.convertToAddress(address);
    	
    	if(address.getIdentifyingAddressFlag().equals("Y")){
    		for(Address addr : addressDocument.getAddressList()){
    			addr.setIsPrimary("N");
    		}
    	}
    	if(!address.getPartySiteUseId().equals("null")){
    	addressDocument.getAddressList().add(newAddress);
    	}
    	else
    	{
    		logger.error("PartySite do not exist and trying to add  new address without PartySiteUse");
    		isSuccessful = false;
    		return isSuccessful;
    	}
    	
    	if(addressDao.saveOrReplaceAddressData(addressDocument, false)){
    		logger.info("Inserted Address Successfully with PartySiteId " + address.getPartySiteId() );
    	}
    	else{
    		logger.error("Failed to Insert Address with PartySiteId " + address.getPartySiteId());
    		isSuccessful=false;
    		  logger.info("Trying again to insert Address");
    		  upsertAddress(address);
    	}
    	
    	return isSuccessful;
    	
    }
    
    public boolean updateAddress(PartyAddress address){
    	boolean isSuccessful = true;
    	boolean shouldUpdateDocument = false;
    	String partySiteId = address.getPartySiteId();
    	List<AddressDocument> documents = addressDao.searchAddressByPartySiteId(partySiteId);
    	 if (documents.isEmpty()) {
             logger.error("Failed to find corresponding Address in Cosmos DB with partySiteId " + partySiteId);
             isSuccessful= false;
             return isSuccessful;
         } else if (documents.size() > 1) {
             logger.error("There should be one Address but found more with partySiteId " + partySiteId);
             isSuccessful= false;
             return isSuccessful;
         } else {
        	 AddressDocument document = documents.get(0);
        	 if(!address.getPartySiteUseId().equals("null")){
        		 Usage newUsage = AddressRecordConverter.convertToUsageForPartyAddress(address);
        		 for(Address docAddress:document.getAddressList()){
        			 if(docAddress.getPartySiteId().equals(address.getPartySiteId())){
        				 boolean isUsageAlreadyPresent = false;
        				 for(Usage usage: docAddress.getUsageList()){
        					 if(usage.getPartySiteUseId().equals(address.getPartySiteUseId())){
        						 isUsageAlreadyPresent = true;
        						 break;
        					 }
        				 }
        				 if(!isUsageAlreadyPresent && !address.getPartySiteUseId().equals("null")){
        					 docAddress.getUsageList().add(newUsage);
        					 logger.info("Trying to add New usage "+ newUsage.toString() +" existing Address "+address.getPartySiteId()+ document.toString());
        				 }
        				
        				 docAddress.setAzureUpdateDate(AddressRecordConverter.currentISOUtcDateTime());
        				 docAddress.setEffectiveStartDate(address.getPsCreationDate());
        				 docAddress.setLastUpdateDate(address.getPsLastUpdatedDate());
        				 docAddress.setIsPrimary(address.getIdentifyingAddressFlag());
        				 docAddress.setIsValid(address.getIsVerified());
        				 docAddress.setAddressStatus(address.getStatus());
        				 shouldUpdateDocument = true;
        				 break;
        			 }
        		 }
        	 }
        	 else{
        		 for(Address docAddress:document.getAddressList()){
        			 if(docAddress.getPartySiteId().equals(address.getPartySiteId())){
        				 docAddress.setAzureUpdateDate(AddressRecordConverter.currentISOUtcDateTime());
        				 docAddress.setEffectiveStartDate(address.getPsCreationDate());
        				 docAddress.setLastUpdateDate(address.getPsLastUpdatedDate());
        				 docAddress.setIsPrimary(address.getIdentifyingAddressFlag());
        				 docAddress.setIsValid(address.getIsVerified());
        				 docAddress.setAddressStatus(address.getStatus());
        				 shouldUpdateDocument = true;
        				 logger.info("Trying to update address corresponding to PartySiteId "+ address.getPartySiteId()+ document.toString());
        				 break;
        				 
        			 }
        		 }
        	 }
        	 
             if (shouldUpdateDocument) {
                 boolean upserted = addressDao.saveOrReplaceAddressData(document, false);
                 if (!upserted) {
                     isSuccessful = false;
                     logger.error("Failed to Update the Address with PartySiteId  "+ address.getPartySiteId());
                     logger.info("Trying again to update Address");
                     updateAddress(address);
                     return isSuccessful;
                 }
                 logger.info("Updated Address " + address.getPartySiteId());
             }
        	 
         }
    	return isSuccessful;
    }

}
