package com.uhg.optumrx.ms.hemi.address.domain;

public class PartyAddress {

    private String partyId;
    private String partySiteId;
    private String locationId;
    private String psLastUpdatedDate;
    private String psCreationDate;
    private String isVerified;
    private String status;
    private String identifyingAddressFlag;
    private String partySiteUseId;
    private String siteUseType;
    private String siteUsePrimaryPerType;
    private String siteUseStatus;
    private String address1;
    private String address2;
    private String address3;
    private String city;
    private String zip;
    private String state;

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getPartySiteId() {
        return partySiteId;
    }

    public void setPartySiteId(String partySiteId) {
        this.partySiteId = partySiteId;
    }

    public String getLocationId() {
        return locationId;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    public String getPsLastUpdatedDate() {
        return psLastUpdatedDate;
    }

    public void setPsLastUpdatedDate(String psLastUpdatedDate) {
        this.psLastUpdatedDate = psLastUpdatedDate;
    }

    public String getPsCreationDate() {
        return psCreationDate;
    }

    public void setPsCreationDate(String psCreationDate) {
        this.psCreationDate = psCreationDate;
    }

    public String getIsVerified() {
        return isVerified;
    }

    public void setIsVerified(String isVerified) {
        this.isVerified = isVerified;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getIdentifyingAddressFlag() {
        return identifyingAddressFlag;
    }

    public void setIdentifyingAddressFlag(String identifyingAddressFlag) {
        this.identifyingAddressFlag = identifyingAddressFlag;
    }

    public String getPartySiteUseId() {
        return partySiteUseId;
    }

    public void setPartySiteUseId(String partySiteUseId) {
        this.partySiteUseId = partySiteUseId;
    }

    public String getSiteUseType() {
        return siteUseType;
    }

    public void setSiteUseType(String siteUseType) {
        this.siteUseType = siteUseType;
    }

    public String getSiteUsePrimaryPerType() {
        return siteUsePrimaryPerType;
    }

    public void setSiteUsePrimaryPerType(String siteUsePrimaryPerType) {
        this.siteUsePrimaryPerType = siteUsePrimaryPerType;
    }

    public String getSiteUseStatus() {
        return siteUseStatus;
    }

    public void setSiteUseStatus(String siteUseStatus) {
        this.siteUseStatus = siteUseStatus;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getAddress3() {
        return address3;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "PartyAddress{" +
                "partyId='" + partyId + '\'' +
                ", partySiteId='" + partySiteId + '\'' +
                ", locationId='" + locationId + '\'' +
                ", psLastUpdatedDate='" + psLastUpdatedDate + '\'' +
                ", psCreationDate='" + psCreationDate + '\'' +
                ", isVerified='" + isVerified + '\'' +
                ", status='" + status + '\'' +
                ", identifyingAddressFlag='" + identifyingAddressFlag + '\'' +
                ", partySiteUseId='" + partySiteUseId + '\'' +
                ", siteUseType='" + siteUseType + '\'' +
                ", siteUsePrimaryPerType='" + siteUsePrimaryPerType + '\'' +
                ", siteUseStatus='" + siteUseStatus + '\'' +
                ", address1='" + address1 + '\'' +
                ", address2='" + address2 + '\'' +
                ", address3='" + address3 + '\'' +
                ", city='" + city + '\'' +
                ", zip='" + zip + '\'' +
                ", state='" + state + '\'' +
                '}';
    }
}
