package com.uhg.optumrx.ms.hemi.address.domain;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonPropertyOrder({"createDate", "lastUpdateDate", "azureUpdateDate", "azureCreateDate",
"patientId", "partyId", "isActive", "addressList", "id"})
public class AddressDocument {

 
	private String id;
    private String partyId;
    private String patientId;
    private String _etag;
    private String isActive;
    private String createDate;
    private String lastUpdateDate;
    private String azureCreateDate;
    private String azureUpdateDate;
    private List<Address> addressList;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String get_etag() {
 		return _etag;
 	}

 	public void set_etag(String _etag) {
 		this._etag = _etag;
 	}

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getAzureCreateDate() {
        return azureCreateDate;
    }

    public void setAzureCreateDate(String azureCreateDate) {
        this.azureCreateDate = azureCreateDate;
    }

    public String getAzureUpdateDate() {
        return azureUpdateDate;
    }

    public void setAzureUpdateDate(String azureUpdateDate) {
        this.azureUpdateDate = azureUpdateDate;
    }

    public List<Address> getAddressList() {
        return addressList;
    }

    public void setAddressList(List<Address> addressList) {
        this.addressList = addressList;
    }

    @Override
    public String toString() {
        return "AddressDocument{" +
                "id='" + id + '\'' +
                ", partyId='" + partyId + '\'' +
                ", patientId='" + patientId + '\'' +
                ", isActive='" + isActive + '\'' +
                ", createDate='" + createDate + '\'' +
                ", lastUpdateDate='" + lastUpdateDate + '\'' +
                ", azureCreateDate='" + azureCreateDate + '\'' +
                ", azureUpdateDate='" + azureUpdateDate + '\'' +
                ", addressList=" + addressList +
                '}';
    }
}
