package com.uhg.optumrx.ms.hemi.address.domain;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"azureUpdateDate", "azureCreateDate", "partySiteUseId",
"useType", "isPrimary", "useStatus"})
public class Usage {

    private String azureUpdateDate;
    private String azureCreateDate;
    private String partySiteUseId;
    private String useType;
    private String isPrimary;
    private String useStatus;

    public String getAzureUpdateDate() {
        return azureUpdateDate;
    }

    public void setAzureUpdateDate(String azureUpdateDate) {
        this.azureUpdateDate = azureUpdateDate;
    }

    public String getAzureCreateDate() {
        return azureCreateDate;
    }

    public void setAzureCreateDate(String azureCreateDate) {
        this.azureCreateDate = azureCreateDate;
    }

    public String getPartySiteUseId() {
        return partySiteUseId;
    }

    public void setPartySiteUseId(String partySiteUseId) {
        this.partySiteUseId = partySiteUseId;
    }

    public String getUseType() {
        return useType;
    }

    public void setUseType(String useType) {
        this.useType = useType;
    }

    public String getIsPrimary() {
        return isPrimary;
    }

    public void setIsPrimary(String isPrimary) {
        this.isPrimary = isPrimary;
    }

    public String getUseStatus() {
        return useStatus;
    }

    public void setUseStatus(String useStatus) {
        this.useStatus = useStatus;
    }

    @Override
    public String toString() {
        return "Usage{" +
                "azureUpdateDate='" + azureUpdateDate + '\'' +
                ", azureCreateDate='" + azureCreateDate + '\'' +
                ", partySiteUseId='" + partySiteUseId + '\'' +
                ", useType='" + useType + '\'' +
                ", isPrimary='" + isPrimary + '\'' +
                ", useStatus='" + useStatus + '\'' +
                '}';
    }
}
