package com.uhg.optumrx.ms.hemi.address.domain;

public class PartySiteUse {

    private String psuId;
    private String psId;
    private String siteUseType;
    private String siteUsePrimaryPerType;
    private String siteUseStatus;
    private String psuOperationType;
    private String psuTransId;

    public String getPsuId() {
        return psuId;
    }

    public void setPsuId(String psuId) {
        this.psuId = psuId;
    }

    public String getPsId() {
        return psId;
    }

    public void setPsId(String psId) {
        this.psId = psId;
    }

    public String getSiteUseType() {
        return siteUseType;
    }

    public void setSiteUseType(String siteUseType) {
        this.siteUseType = siteUseType;
    }

    public String getSiteUsePrimaryPerType() {
        return siteUsePrimaryPerType;
    }

    public void setSiteUsePrimaryPerType(String siteUsePrimaryPerType) {
        this.siteUsePrimaryPerType = siteUsePrimaryPerType;
    }

    public String getSiteUseStatus() {
        return siteUseStatus;
    }

    public void setSiteUseStatus(String siteUseStatus) {
        this.siteUseStatus = siteUseStatus;
    }

    public String getPsuOperationType() {
        return psuOperationType;
    }

    public void setPsuOperationType(String psuOperationType) {
        this.psuOperationType = psuOperationType;
    }

    public String getPsuTransId() {
        return psuTransId;
    }

    public void setPsuTransId(String psuTransId) {
        this.psuTransId = psuTransId;
    }

    @Override
    public String toString() {
        return "PartySiteUse{" +
                "psuId='" + psuId + '\'' +
                ", psId='" + psId + '\'' +
                ", siteUseType='" + siteUseType + '\'' +
                ", siteUsePrimaryPerType='" + siteUsePrimaryPerType + '\'' +
                ", siteUseStatus='" + siteUseStatus + '\'' +
                ", psuOperationType='" + psuOperationType + '\'' +
                ", psuTransId='" + psuTransId + '\'' +
                '}';
    }
}
