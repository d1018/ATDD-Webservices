package com.uhg.optumrx.ms.hemi.address.util;

import com.uhg.optumrx.ms.hemi.address.domain.Address;
import com.uhg.optumrx.ms.hemi.address.domain.PartyAddress;
import com.uhg.optumrx.ms.hemi.address.domain.PartyLocation;
import com.uhg.optumrx.ms.hemi.address.domain.PartySiteUse;
import com.uhg.optumrx.ms.hemi.address.domain.Usage;
import org.apache.avro.generic.GenericRecord;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class AddressRecordConverter {

    public static PartyAddress convertToPartyAddress(GenericRecord record) {
        PartyAddress partyAddress = new PartyAddress();
        partyAddress.setPartyId(Objects.toString(record.get("PARTYID")));
        partyAddress.setPartySiteId(Objects.toString(record.get("PARTYSITEID")));
        partyAddress.setLocationId(Objects.toString(record.get("LOCATIONID")));
        partyAddress.setPsLastUpdatedDate(Objects.toString(record.get("PSLASTUPDATEDATE")));
        partyAddress.setPsCreationDate(Objects.toString(record.get("PSCREATIONDATE")));
        partyAddress.setIsVerified(Objects.toString(record.get("ISVERIFIED")));
        partyAddress.setStatus(Objects.toString(record.get("STATUS")));
        partyAddress.setIdentifyingAddressFlag(Objects.toString(record.get("IDENTIFYINGADDRESSFLAG")));
        partyAddress.setPartySiteUseId(Objects.toString(record.get("PARTYSITEUSEID")));
        partyAddress.setSiteUseType(Objects.toString(record.get("SITEUSETYPE")));
        partyAddress.setSiteUsePrimaryPerType(Objects.toString(record.get("SITEUSEPRIMARYPERTYPE")));
        partyAddress.setSiteUseStatus(Objects.toString(record.get("SITEUSESTATUS")));
        partyAddress.setAddress1(Objects.toString(record.get("ADDRESS1")));
        partyAddress.setAddress2(Objects.toString(record.get("ADDRESS2")));
        partyAddress.setAddress3(Objects.toString(record.get("ADDRESS3")));
        partyAddress.setCity(Objects.toString(record.get("CITY")));
        partyAddress.setZip(Objects.toString(record.get("ZIP")));
        partyAddress.setState(Objects.toString(record.get("STATE")));
        return partyAddress;
    }

    public static PartyLocation convertToPartyLocation(GenericRecord record) {
        PartyLocation partyLocation = new PartyLocation();
        partyLocation.setLocationId(Objects.toString(record.get("LOCATIONID")));
        partyLocation.setAddress1(Objects.toString(record.get("ADDRESS1")));
        partyLocation.setAddress2(Objects.toString(record.get("ADDRESS2")));
        partyLocation.setAddress3(Objects.toString(record.get("ADDRESS3")));
        partyLocation.setAddress4(Objects.toString(record.get("ADDRESS4")));
        partyLocation.setCity(Objects.toString(record.get("CITY")));
        partyLocation.setZip(Objects.toString(record.get("ZIP")));
        partyLocation.setState(Objects.toString(record.get("STATE")));
        partyLocation.setLocOperationType(Objects.toString(record.get("LOPERATIONTYPE")));
        partyLocation.setLocTransId(Objects.toString(record.get("LTRANSID")));
        return partyLocation;
    }

    public static PartySiteUse convertToPartySiteUse(GenericRecord record) {
        PartySiteUse partySiteUse = new PartySiteUse();
        partySiteUse.setPsuId(Objects.toString(record.get("PARTYSITEUSEID")));
        partySiteUse.setPsId(Objects.toString(record.get("PARTYSITEID")));
        partySiteUse.setSiteUseType(Objects.toString(record.get("SITEUSETYPE")));
        partySiteUse.setSiteUsePrimaryPerType(Objects.toString(record.get("SITEUSEPRIMARYPERTYPE")));
        partySiteUse.setSiteUseStatus(Objects.toString(record.get("SITEUSESTATUS")));
        partySiteUse.setPsuOperationType(Objects.toString(record.get("PSUOPERATIONTYPE")));
        partySiteUse.setPsuTransId(Objects.toString(record.get("PSUTRANSID")));
        return partySiteUse;
    }

    public static Address convertToAddress(PartyAddress pAddress){
    	Address address = new Address();
    	String timestamp = currentISOUtcDateTime();
    	address.setAzureCreateDate(timestamp);
    	address.setAzureUpdateDate(timestamp);
    	address.setEffectiveStartDate(pAddress.getPsCreationDate());
    	address.setLastUpdateDate(pAddress.getPsLastUpdatedDate());
    	address.setPartySiteId(pAddress.getPartySiteId());
    	address.setLocationId(pAddress.getLocationId());
    	address.setAddress1(pAddress.getAddress1());
    	address.setAddress2(pAddress.getAddress2());
    	address.setAddress3(pAddress.getAddress3());
    	address.setCity(pAddress.getCity());
    	address.setState(pAddress.getState());
    	address.setZip(pAddress.getZip());
    	address.setIsPrimary(pAddress.getIdentifyingAddressFlag());
    	address.setIsValid(pAddress.getIsVerified());
    	address.setAddressStatus(pAddress.getStatus());
    	Usage usage = AddressRecordConverter.convertToUsageForPartyAddress(pAddress);
    	List<Usage> usageList = new ArrayList<>();
    	if(!pAddress.getPartySiteUseId().equals("null")){
    	usageList.add(usage);
    	}
    	address.setUsageList(usageList);
    	return address;
    }
    public static Usage convertToUsage(PartySiteUse psu) {
        Usage usage = new Usage();
        String timestamp = currentISOUtcDateTime();
        usage.setAzureUpdateDate(timestamp);
        usage.setAzureCreateDate(timestamp);
        usage.setPartySiteUseId(psu.getPsuId());
        usage.setUseType(psu.getSiteUseType());
        usage.setIsPrimary(psu.getSiteUsePrimaryPerType());
        usage.setUseStatus(psu.getSiteUseStatus());
        return usage;
    }

    public static Usage convertToUsageForPartyAddress(PartyAddress address){
    	Usage usage = new Usage();
    	 String timestamp = currentISOUtcDateTime();
    	 usage.setAzureCreateDate(timestamp);
    	 usage.setAzureUpdateDate(timestamp);
    	 usage.setPartySiteUseId(address.getPartySiteUseId());
    	 usage.setUseType(address.getSiteUseType());
    	 usage.setIsPrimary(address.getSiteUsePrimaryPerType());
    	 usage.setUseStatus(address.getSiteUseStatus());
    	return usage;
    }
    public static String currentISOUtcDateTime() {
        return new DateTime().withZone(DateTimeZone.UTC).toString();
    }
}
