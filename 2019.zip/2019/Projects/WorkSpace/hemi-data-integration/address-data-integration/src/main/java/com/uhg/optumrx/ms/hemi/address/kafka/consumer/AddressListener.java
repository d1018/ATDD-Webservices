package com.uhg.optumrx.ms.hemi.address.kafka.consumer;

import com.microsoft.azure.documentdb.DocumentClientException;
import com.uhg.optumrx.ms.hemi.address.domain.PartyAddress;
import com.uhg.optumrx.ms.hemi.address.domain.PartyLocation;
import com.uhg.optumrx.ms.hemi.address.domain.PartySiteUse;
import com.uhg.optumrx.ms.hemi.address.service.AddressDataService;
import com.uhg.optumrx.ms.hemi.address.util.AddressRecordConverter;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class AddressListener {

    private static final Logger logger = LogManager.getLogger(AddressListener.class);

    @Autowired
    AddressDataService addressDataService;

    @KafkaListener(id = "${kafka.address.id}",
            containerFactory = "addressKafkaListenerContainerFactory",
            topics = "${kafka.address.topic}",
            groupId = "${kafka.address.group}")
    public void listenToAddress(ConsumerRecord<?, GenericRecord> consumerRecord, Acknowledgment acknowledgment) throws DocumentClientException, IOException {
        PartyAddress partyAddress = AddressRecordConverter.convertToPartyAddress(consumerRecord.value());
        logger.info(String.format("Partition: %s Offset: %s Received Address: %s",
                consumerRecord.partition(), consumerRecord.offset(), partyAddress.toString()));
        if (addressDataService.processAddressData(partyAddress)) {
            acknowledgment.acknowledge();
        } else {
            // TODO failure handling
        }
    }

    @KafkaListener(id = "${kafka.location.id}",
            containerFactory = "locationKafkaListenerContainerFactory",
            topics = "${kafka.location.topic}",
            groupId = "${kafka.location.group}")
    public void listenToLocation(ConsumerRecord<?, GenericRecord> consumerRecord, Acknowledgment acknowledgment) {
        PartyLocation partyLocation = AddressRecordConverter.convertToPartyLocation(consumerRecord.value());
        logger.info(String.format("Partition: %s Offset: %s Received Location: %s",
                consumerRecord.partition(), consumerRecord.offset(), partyLocation.toString()));
        if (addressDataService.processLocationData(partyLocation)) {
            acknowledgment.acknowledge();
        } else {
            // TODO failure handling
        }
    }

    @KafkaListener(id = "${kafka.psu.id}",
            containerFactory = "psuKafkaListenerContainerFactory",
            topics = "${kafka.psu.topic}",
            groupId = "${kafka.psu.group}")
    public void listenToPartySiteUse(ConsumerRecord<?, GenericRecord> consumerRecord, Acknowledgment acknowledgment) {
        PartySiteUse psu = AddressRecordConverter.convertToPartySiteUse(consumerRecord.value());
        logger.info(String.format("Partition: %s Offset: %s Received PSU: %s",
                consumerRecord.partition(), consumerRecord.offset(), psu.toString()));
        if (addressDataService.processPsuData(psu)) {
            acknowledgment.acknowledge();
        } else {
            // TODO failure handling
        }
    }

}
