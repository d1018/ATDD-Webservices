package com.uhg.optumrx.ms.hemi.address.domain;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonPropertyOrder({"azureUpdateDate", "azureCreateDate", "partySiteId", "locationId",
"address1", "address2", "address3", "city", "county", "state", "zip", "isPrimary", "isValid",
"addressStatus", "lastUpdateDate", "effectiveStartDate", "effectiveEndDate", "usageList"})
public class Address {

    private String azureUpdateDate;
    private String azureCreateDate;
    private String partySiteId;
    private String locationId;
    private String address1;
    private String address2;
    private String address3;
    private String city;
    private String county;
    private String state;
    private String zip;
    private String isPrimary;
    private String isValid;
    private String addressStatus;
    private String lastUpdateDate;
    private String effectiveStartDate;
    private String effectiveEndDate;
    private List<Usage> usageList;

    public String getAzureUpdateDate() {
        return azureUpdateDate;
    }

    public void setAzureUpdateDate(String azureUpdateDate) {
        this.azureUpdateDate = azureUpdateDate;
    }

    public String getAzureCreateDate() {
        return azureCreateDate;
    }

    public void setAzureCreateDate(String azureCreateDate) {
        this.azureCreateDate = azureCreateDate;
    }

    public String getPartySiteId() {
        return partySiteId;
    }

    public void setPartySiteId(String partySiteId) {
        this.partySiteId = partySiteId;
    }

    public String getLocationId() {
        return locationId;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getAddress3() {
        return address3;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getIsPrimary() {
        return isPrimary;
    }

    public void setIsPrimary(String isPrimary) {
        this.isPrimary = isPrimary;
    }

    public String getIsValid() {
        return isValid;
    }

    public void setIsValid(String isValid) {
        this.isValid = isValid;
    }

    public String getAddressStatus() {
        return addressStatus;
    }

    public void setAddressStatus(String addressStatus) {
        this.addressStatus = addressStatus;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getEffectiveStartDate() {
        return effectiveStartDate;
    }

    public void setEffectiveStartDate(String effectiveStartDate) {
        this.effectiveStartDate = effectiveStartDate;
    }

    public String getEffectiveEndDate() {
        return effectiveEndDate;
    }

    public void setEffectiveEndDate(String effectiveEndDate) {
        this.effectiveEndDate = effectiveEndDate;
    }

    public List<Usage> getUsageList() {
        return usageList;
    }

    public void setUsageList(List<Usage> usageList) {
        this.usageList = usageList;
    }

    @Override
    public String toString() {
        return "Address{" +
                "azureUpdateDate='" + azureUpdateDate + '\'' +
                ", azureCreateDate='" + azureCreateDate + '\'' +
                ", partySiteId='" + partySiteId + '\'' +
                ", locationId='" + locationId + '\'' +
                ", address1='" + address1 + '\'' +
                ", address2='" + address2 + '\'' +
                ", address3='" + address3 + '\'' +
                ", city='" + city + '\'' +
                ", county='" + county + '\'' +
                ", state='" + state + '\'' +
                ", zip='" + zip + '\'' +
                ", isPrimary='" + isPrimary + '\'' +
                ", isValid='" + isValid + '\'' +
                ", addressStatus='" + addressStatus + '\'' +
                ", lastUpdateDate='" + lastUpdateDate + '\'' +
                ", effectiveStartDate='" + effectiveStartDate + '\'' +
                ", effectiveEndDate='" + effectiveEndDate + '\'' +
                ", usageList=" + usageList +
                '}';
    }
}
