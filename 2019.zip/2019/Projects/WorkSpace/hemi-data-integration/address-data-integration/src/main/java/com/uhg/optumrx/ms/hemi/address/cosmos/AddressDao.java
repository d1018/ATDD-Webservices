package com.uhg.optumrx.ms.hemi.address.cosmos;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.documentdb.*;
import com.uhg.optumrx.ms.hemi.address.domain.AddressDocument;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
public class AddressDao {

    @Value("${azure.cosmosdb.uri}")
    private String cosmosDbUri;
    @Value("${azure.cosmosdb.key}")
    private String cosmosDbKey;
    @Value("${azure.cosmosdb.database}")
    private String databaseId;
    @Value("${azure.cosmosdb.collection}")
    private String collectionId;
    @Value("${azure.cosmosdb.partition.key}")
    private String partitionKey;
    private String partitionKeyPath;
    private String collectionLink;

    private RequestOptions reqOptions = new RequestOptions();
    private FeedOptions feedOptions = new FeedOptions();
    private DocumentClient documentClient;
    private ObjectMapper mapper = new ObjectMapper();

    private static final Logger logger = LogManager.getLogger(AddressDao.class);

    @PostConstruct
    public void setup() {
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        partitionKeyPath = "/" + partitionKey;
        collectionLink = String.format("/dbs/%s/colls/%s", databaseId, collectionId);
        feedOptions.setEnableCrossPartitionQuery(true);
        documentClient = new DocumentClient(
                cosmosDbUri,
                cosmosDbKey,
                ConnectionPolicy.GetDefault(),
                ConsistencyLevel.Session);
    }

    public boolean saveOrReplaceAddressData(AddressDocument address, boolean isNewDocument) {
        try {
        	AccessCondition ac = new AccessCondition();
     
            if (isNewDocument) {
                documentClient.createDocument(collectionLink, address, reqOptions, false);
            } else {
            	ac.setCondition(address.get_etag());
            	ac.setType(AccessConditionType.IfMatch);
            	reqOptions.setAccessCondition(ac);
                documentClient.replaceDocument(collectionLink + "/docs/" + address.getId(), address, reqOptions);
            }
            return true;
        } 
        catch(DocumentClientException dce){
        	logger.error("ETag doesn't match " + dce);
        	return false;
        }
        catch (Exception ex) {
            logger.error("Failed to save/replace address data to cosmos DB with partyId: " + address.getPartyId(), ex);
            return false;
        }
    }

    public AddressDocument searchAddressByPartyId(String partyId) {
        SqlQuerySpec querySpec = new SqlQuerySpec(
                QUERY_BY_PARTY_ID,
                new SqlParameterCollection(new SqlParameter("@partyId", partyId)));
        List<AddressDocument> result = queryForAddressDocument(querySpec);
        return getAvailableAddressDocument(result);
    }

    public AddressDocument searchAddressByPatientId(String patientId) {
        SqlQuerySpec querySpec = new SqlQuerySpec(
                QUERY_BY_PATIENT_ID,
                new SqlParameterCollection(new SqlParameter("@patientId", patientId)));
        List<AddressDocument> result = queryForAddressDocument(querySpec);
        return getAvailableAddressDocument(result);
    }

    public List<AddressDocument> searchAddressByPartySiteId(String partySiteId) {
        SqlQuerySpec querySpec = new SqlQuerySpec(
                QUERY_BY_PARTY_SITE_ID,
                new SqlParameterCollection(new SqlParameter("@partySiteId", partySiteId)));
        return queryForAddressDocument(querySpec);
    }

    public List<AddressDocument> searchAddressByLocationId(String locationId) {
        SqlQuerySpec querySpec = new SqlQuerySpec(
                QUERY_BY_LOCATION_ID,
                new SqlParameterCollection(new SqlParameter("@locationId", locationId)));
        return queryForAddressDocument(querySpec);
    }

    public List<String> searchPsuIdByPsuId(String partySiteUseId) {
        SqlQuerySpec querySpec = new SqlQuerySpec(
                QUERY_PSU_ID_BY_PSU_ID,
                new SqlParameterCollection(new SqlParameter("@partySiteUseId", partySiteUseId)));
        return queryForSingleField(querySpec, "partySiteUseId");
    }

    public List<String> searchPsIdByPsId(String partySiteId) {
        SqlQuerySpec querySpec = new SqlQuerySpec(
                QUERY_PS_ID_BY_PS_ID,
                new SqlParameterCollection(new SqlParameter("@partySiteId", partySiteId)));
        return queryForSingleField(querySpec, "partySiteId");
    }

    private List<String> queryForSingleField(SqlQuerySpec querySpec, String fieldName) {
        List<String> result = new ArrayList<>();
        try {
            List<Document> documents = documentClient.queryDocuments(
                    collectionLink,
                    querySpec,
                    feedOptions)
                    .getQueryIterable()
                    .toList();
            for (Document document : documents) {
                result.add(document.getString(fieldName));
            }
        } catch (Exception ex) {
            logger.error("Failed to lookup field by : " + querySpec.getQueryText(), ex);
        } finally {
            return result;
        }
    }

    private List<AddressDocument> queryForAddressDocument(SqlQuerySpec querySpec) {
        List<AddressDocument> result = new ArrayList<>();
        try {
            List<Document> documents = documentClient.queryDocuments(
                    collectionLink,
                    querySpec,
                    feedOptions)
                    .getQueryIterable()
                    .toList();
            result = convertDocuments(documents, AddressDocument.class);
        } catch (Exception ex) {
            logger.error("Failed to lookup Address by : " + querySpec.getQueryText(), ex);
        } finally {
            return result;
        }
    }

    private AddressDocument getAvailableAddressDocument(List<AddressDocument> result) {
        if (!result.isEmpty()) {
            return result.get(0);
        } else {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    private <T> List<T> convertDocuments(List<Document> docs, Class<?> cl)
            throws IOException {
        List<T> convertedDocs = new ArrayList<>();
        for (Document document : docs) {
            convertedDocs.add((T) mapper.readValue(document.toString(), cl));
        }
        return convertedDocs;
    }

    private final static String QUERY_BY_PARTY_ID = "select * from root r where r.partyId = @partyId";
    private final static String QUERY_BY_PATIENT_ID = "select * from root r where r.patientId = @patientId";
    private final static String QUERY_BY_PARTY_SITE_ID = "select * from root r where array_contains(r.addressList, {partySiteId: @partySiteId}, true)";
    private final static String QUERY_PSU_ID_BY_PSU_ID = "select usage.partySiteUseId from root r join addr in r.addressList join usage in addr.usageList where usage.partySiteUseId = @partySiteUseId";
    private final static String QUERY_PS_ID_BY_PS_ID = "select addr.partySiteId from root r join addr IN r.addressList where addr.partySiteId = @partySiteId";
    private final static String QUERY_BY_LOCATION_ID = "select * from root r where array_contains(r.addressList, {locationId: @locationId}, true)";

}
