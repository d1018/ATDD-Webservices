package com.uhg.optumrx.ms.hemi.address.kafka.config;

import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;

import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableKafka
public class KafkaConsumerConfig {

    @Value("${kafka.server}")
    private String server;
    @Value("${kafka.schema.registry.url}")
    private String schemaRegistryUrl;
    @Value(("${kafka.address.group}"))
    private String addressGroup;
    @Value(("${kafka.location.group}"))
    private String locationGroup;
    @Value(("${kafka.psu.group}"))
    private String psuGroup;
    @Value(("${kafka.autocommit}"))
    private boolean autoCommit;
    @Value(("${kafka.session.timeout.ms}"))
    private int sessionTimeout;
    @Value(("${kafka.poll.timeout.ms}"))
    private int pollTimeout;
    @Value("${kafka.max.poll.interval.ms}")
    private String maxPollInterval;
    @Value("${kafka.auto.offset.reset}")
    private String autoOffsetReset;
    @Value("${kafka.key.serializer}")
    private String keySerializer;
    @Value("${kafka.value.serializer}")
    private String valueSerializer;
    @Value("${kafka.concurrency}")
    private String concurrency;
    @Value("${kafka.max.poll.records}")
    private String poll;

    @Bean("addressKafkaListenerContainerFactory")
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, String>> addressKafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory = genericFactory();
        factory.setConsumerFactory(new DefaultKafkaConsumerFactory<>(addressConsumerConfigs()));
        factory.setConcurrency(Integer.valueOf(concurrency));
        return factory;
    }

    public Map<String, Object> addressConsumerConfigs() {
        Map<String, Object> propsMap = genericConsumerConfigs();
        propsMap.put(ConsumerConfig.GROUP_ID_CONFIG, addressGroup);
        return propsMap;
    }

    @Bean("locationKafkaListenerContainerFactory")
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, String>> locationKafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory = genericFactory();
        factory.setConsumerFactory(new DefaultKafkaConsumerFactory<>(locationConsumerConfigs()));
        factory.setConcurrency(Integer.valueOf(concurrency));
        return factory;
    }

    public Map<String, Object> locationConsumerConfigs() {
        Map<String, Object> propsMap = genericConsumerConfigs();
        propsMap.put(ConsumerConfig.GROUP_ID_CONFIG, locationGroup);
        return propsMap;
    }

    @Bean("psuKafkaListenerContainerFactory")
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, String>> psuKafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory = genericFactory();
        factory.setConsumerFactory(new DefaultKafkaConsumerFactory<>(psuConsumerConfigs()));
        factory.setConcurrency(Integer.valueOf(concurrency));
        return factory;
    }

    public Map<String, Object> psuConsumerConfigs() {
        Map<String, Object> propsMap = genericConsumerConfigs();
        propsMap.put(ConsumerConfig.GROUP_ID_CONFIG, psuGroup);
        return propsMap;
    }

    private ConcurrentKafkaListenerContainerFactory<String, String> genericFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConcurrency(1);
        factory.getContainerProperties().setPollTimeout(pollTimeout);
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        return factory;
    }

    private Map<String, Object> genericConsumerConfigs() {
        Map<String, Object> propsMap = new HashMap<>();
        propsMap.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, server);
        propsMap.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, autoCommit);
        propsMap.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, sessionTimeout);
        propsMap.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, keySerializer);
        propsMap.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, valueSerializer);
        propsMap.put(KafkaAvroDeserializerConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaRegistryUrl);
        propsMap.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
        propsMap.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, poll);
        return propsMap;
    }

}
