package com.uhg.optumrx.ms.hemi.address;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddressApp {

    public static void main(String[] args) {
        SpringApplication.run(AddressApp.class, args);
    }

}
