package com.Utility;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.documentdb.*;
//import com.uhg.optumrx.ms.hemi.address.domain.AddressDocument;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


public class cosmosDB {
	
	commonFunction com = new commonFunction();
	

    private String cosmosDbUri = com.getPropertyFile("azure.cosmosdb.uri");
    private String cosmosDbKey = com.getPropertyFile("azure.cosmosdb.key");
    private String databaseId = com.getPropertyFile("azure.cosmosdb.database");
    private String collectionId = com.getPropertyFile("azure.cosmosdb.collection");
    private String partitionKey = com.getPropertyFile("azure.cosmosdb.partition.key");
    private String partitionKeyPath;
    private String collectionLink;
    
    private RequestOptions reqOptions = new RequestOptions();
    private FeedOptions feedOptions = new FeedOptions();
    private DocumentClient documentClient;
    private ObjectMapper mapper = new ObjectMapper();
    
    private static final Logger logger = LogManager.getLogger(cosmosDB.class);
    
    public void setup() {
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        partitionKeyPath = "/" + partitionKey;
        collectionLink = String.format("/dbs/%s/colls/%s", databaseId, collectionId);
        feedOptions.setEnableCrossPartitionQuery(true);
        documentClient = new DocumentClient(
                cosmosDbUri,
                cosmosDbKey,
                ConnectionPolicy.GetDefault(),
                ConsistencyLevel.Session);
    }
}
