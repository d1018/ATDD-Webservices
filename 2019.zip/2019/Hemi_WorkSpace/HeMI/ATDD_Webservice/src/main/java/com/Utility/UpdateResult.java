package com.Utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class UpdateResult {
	
	ExcelUtility erw = new ExcelUtility();

	String getWebServiceName="";
	String gettcName="";
	String getTCidName="";
	String actualtag="";
	String actualtagList ="";
	String actual= "";
	String expVal= "";
	String actualData="";
	String[] actualDataArr;
	String exptedData="";
	String[] exptedDataArr;
	int colurcnt=0;
	public void fnupdateResultWithData(String Filename,String DbSheetName,String WSSheetName,String ResultSheet) throws IOException{
		int serchCnt=0;
		int updateRowData=0;
		int updateRowData1=0;
		String tempData[];
		
		erw.fnSetUpForWriteToExcelData1(Filename);
	try{		
		XSSFSheet wshTemp =erw.fnGetSheet(WSSheetName);
		int irow=wshTemp.getLastRowNum();
		
		try{
			for(int i=1;i<=irow;i++){
				
				 String[] actualtagArr;
				 String actualtagList ="";
				
				int webServColCnt=erw.getColumnHeaderIndex("WebServiceName", WSSheetName);
				getWebServiceName= wshTemp.getRow(i).getCell(webServColCnt).toString().trim();
				int tcName=erw.getColumnHeaderIndex("TestCaseName", WSSheetName);
				gettcName= wshTemp.getRow(i).getCell(tcName).toString().trim();
				int rcIdCnt=erw.getColumnHeaderIndex("TC_ID", WSSheetName);
				getTCidName= wshTemp.getRow(i).getCell(rcIdCnt).toString().trim();
				
				colurcnt=colurcnt+1;
				boolean x=false;
				String colour="GREY";
				if(colurcnt%2==0){
					x=true;
					colour="TURQUOISE";
				}
				int getColCnt=wshTemp.getRow(i).getLastCellNum();
				try{
						int field1Cnt=erw.getColumnHeaderIndex("Response", WSSheetName);
						for(int j=field1Cnt;j<getColCnt;j++){
							String valData= wshTemp.getRow(i).getCell(j).toString().trim();
							if(!valData.equals("")){
								tempData=valData.split(":");
								updateRowData=updateRowData+1;
								String slNumer=Integer.toString(updateRowData);
								erw.setValueIntoCellWithColour(0,slNumer, ResultSheet,updateRowData,x,colour);
								erw.setValueIntoCellWithColour(1,getWebServiceName,ResultSheet,updateRowData,x,colour);
								erw.setValueIntoCellWithColour(2,gettcName,ResultSheet,updateRowData,x,colour);
								erw.setValueIntoCellWithColour(3,getTCidName,ResultSheet,updateRowData,x,colour);
								actualtag = erw.setValueIntoCellWithColour(4,tempData[0], ResultSheet,updateRowData,x,colour);
								actualtagList=actualtagList+":"+actualtag;
								actual= erw.setValueIntoCellWithColour(5,tempData[1], ResultSheet,updateRowData,x,colour);
								actualData=actualData+":"+actual;
							}
						}
					
				}catch(Exception e){
					 System.out.println(e.getMessage());
				 }
				
				actualDataArr=actualData.split(":");
				actualtagArr = actualtagList.split(":");
				System.out.println(actualtagArr.length);
				System.out.println(actualtagArr[0]);
				
				wshTemp =erw.fnGetSheet(DbSheetName);
				getColCnt=wshTemp.getRow(i).getLastCellNum();
				try{

					 for(int d=1;d<actualtagArr.length;d++)
					 {
													 
					 int field1Cnt=erw.getColumnHeaderIndex("Response", DbSheetName);
					 
					 try
					 {
					 for(int j=field1Cnt;j<getColCnt+1;j++){
					 
					 String valData= wshTemp.getRow(i).getCell(j).toString().trim();

					 if(!valData.equals("")){
						 tempData=valData.split(":");
						 //write data in to CalculateResult Sheet
						 
						 if(actualtagArr[d].toUpperCase().equals(tempData[0].toUpperCase()))
						 {
						 updateRowData1=updateRowData1+1;
						 try
						 {
						 if((tempData[1]  != null)){
							 
								expVal= erw.setValueIntoCellWithColour(6, tempData[1], ResultSheet,updateRowData1,x,colour);
								exptedData=exptedData+":"+expVal;
							}
						 
						 }catch(Exception e){
							 
							 expVal= erw.setValueIntoCellWithColour(6, "No Data Found", ResultSheet,updateRowData1,x,colour);
							 exptedData=exptedData+":"+expVal;
							 
						 }
						 break;
						 
						 }
							
						}										 							 
						 
					 }
					}catch(Exception e){
						
						updateRowData1=updateRowData1+1;
						 expVal= erw.setValueIntoCellWithColour(6, "No Tag Value", ResultSheet,updateRowData1,x,colour);
						 exptedData=exptedData+":"+expVal;
						
					}
					 
					 
					 }				
					
				}catch(Exception e){
					 System.out.println(e.getMessage());
				 }
				
				exptedDataArr=exptedData.split(":");
			}
			
			
		}catch(Exception e){
			 System.out.println(e.getMessage());
		 }
		
		 wshTemp = erw.fnGetSheet(ResultSheet);
		 for(int i1=1;i1<=actualDataArr.length;i1++){
			 boolean x=false;
			 if(i1%2==0){
				x=true; 
			 }
			 if(actualDataArr[i1].trim().equals(exptedDataArr[i1].trim())){
//				 erw.setValueIntoCell("Status", "Pass", resultSheet,i1);
				 erw.setValueIntoCellWithColour(7, "PASS", ResultSheet,i1,x,"green");
				 }else{
					 if(actualDataArr[i1].trim().contains("No Data Found")){
						 erw.setValueIntoCellWithColour(7, "Not completed", ResultSheet,i1,x,"yellow");
					 }
					 else if(exptedDataArr[i1].trim().contains("No Tag Value"))
						 {
						 erw.setValueIntoCellWithColour(7, "Deffered", ResultSheet,i1,x,"yellow");
						 }
					 else{
						 
//					 erw.setValueIntoCell("Status", "Fail", resultSheet,i1); 
					 erw.setValueIntoCellWithColour(7, "FAIL", ResultSheet,i1,x,"red");
					 }
				 }
		 }
		
	}catch(Exception e){
		 System.out.println(e.getMessage());
	 }finally{
		 try{
			 	erw.updateTestResult();
			 	
		 }catch(Exception e){
				e.getMessage();
			}
	 }
		
	}

}
