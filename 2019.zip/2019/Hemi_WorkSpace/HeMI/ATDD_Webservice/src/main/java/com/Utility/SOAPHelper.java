package com.Utility;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.impl.wsdl.WsdlTestSuite;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner;
import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestRequestStepResult;
import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStep;
import com.eviware.soapui.model.testsuite.TestProperty;
import com.eviware.soapui.model.testsuite.TestStepResult;
import com.eviware.soapui.support.GroovyUtils;
import com.eviware.soapui.support.XmlHolder;
import com.eviware.soapui.support.types.StringToObjectMap;
import com.eviware.soapui.support.xml.XmlUtils;
import com.eviware.soapui.tools.SoapUITestCaseRunner;

import groovy.util.NodeList;
import com.Utility.*;

public class SOAPHelper {
	
	commonFunction com = new commonFunction();
	
	public ArrayList<String> getPropertyList(String TestSuiteName,String TestCaseName ) throws ParserConfigurationException, SAXException, IOException {
		
		ArrayList<String> ListProperty=null;
		
		
	try
	{
		ListProperty = com.reqTagCalulation("C:\\Backup\\TestProject\\sample.xml");
		
		
	} catch (Exception e) {
		e.printStackTrace();
	}
		return ListProperty;	
	}

}
