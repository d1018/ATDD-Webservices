package com.Utility;

import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.Utility.*;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class VariableDeclaration {

	public void testMain(Object[] args) {
		// System.out.println("file:"+destinationFile);
	}

	static commonFunction com = new commonFunction();
	static ExcelUtility erw = new ExcelUtility();

	public static final XSSFWorkbook wb = null;
	public static final XSSFWorkbook Sheet = null;
	public static final XSSFWorkbook Sheet1 = null;
	public static final String WebServicesResponseData = "WebServicesResponseData";
	public static final String DBData = "DatabaseResults";	
	public static final String ResultSheet = "ResultSheet";
	public static final String getTieStamp = com.fnGetTimeStamp();
	public static final String destFilePath = "C:\\WorkSpace\\HeMI\\ATDD_Webservice\\ResultSheet\\WebServiceAutomationData_"
			+ getTieStamp + ".xlsx";
	public static final String testdataPath = "C:\\WorkSpace\\HeMI\\ATDD_Webservice\\testDataPath.txt";
	public static final String TCaseID = "TC_ID";
	public static final String S_No = "S.No";
	public static final String WebServiceName ="WebServiceName";
	public static final String TestCaseName ="TestCaseName";
	public static final String Response ="Response";
	public static final String NoDataFound= "No Data Found";
	public static final String StatusNotcompleted="Not completed";
	
	
	

}
