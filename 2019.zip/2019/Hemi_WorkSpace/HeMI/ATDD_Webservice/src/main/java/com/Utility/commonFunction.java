package com.Utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Properties;
import java.text.SimpleDateFormat;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Date;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import groovy.ui.SystemOutputInterceptor;

public class commonFunction {

	public static Connection getINetDBConnection() throws Exception {
		String driver = "net.sourceforge.jtds.jdbc.Driver";
		String url = "jdbc:jtds:sqlserver://DBSET1664:1433;DatabaseName=INETFORMULARY";
		String username = "runx_ecs_svc";
		String password = "meC3f=vX";

		Class.forName(driver);
		Connection conn = DriverManager.getConnection(url, username, password);
		return conn;
	}

	public static Connection getRxClaimDBConnection() throws Exception {
		String driver = "com.ibm.as400.access.AS400JDBCDriver";
		String url = "jdbc:as400:RXBK2QA;libraries=*LIB;naming=system";
		String username = "ORXWEB";
		String password = "bwx1oer5";

		Class.forName(driver);
		Connection conn = DriverManager.getConnection(url, username, password);
		return conn;
	}

	public String getInputFieldfromTDMPropertyFile(String servicename) {

		Properties InputField;
		InputField = new Properties();
		InputStream InputFile = null;
		try {
			InputFile = new FileInputStream(new File("src/test/resources/TDM/InputRequest.properties"));
			InputField.load(InputFile);

		} catch (IOException ex) {
			System.out.println("unable to read property file");
		}

		String request = (InputField.getProperty(servicename));

		return request;

	}
	
	public String getPropertyFile(String servicename) {

		Properties InputField;
		InputField = new Properties();
		InputStream InputFile = null;
		try {
			InputFile = new FileInputStream(new File("src/main/resources/application.properties"));
			InputField.load(InputFile);

		} catch (IOException ex) {
			System.out.println("unable to read property file");
		}

		String request = (InputField.getProperty(servicename));

		return request;

	}

	public String getParametersforSP(String DataList, ArrayList<String> InputParam) {
		String tempData[];
		String parametertoPass = "";
		String[] InputDataList = DataList.split(",");

		try {
			for (int ip = 0; ip < InputParam.size(); ip++) {
				try {
					for (int j = 0; j < InputDataList.length + 1; j++) {
						String valData = InputDataList[j];
						if (!valData.equals("")) {
							tempData = valData.split("=");
							System.out.println(tempData[0].trim());
							if (InputParam.get(ip).toUpperCase().contains(tempData[0].toUpperCase().trim())) {
								parametertoPass = parametertoPass + "'" + tempData[1] + "'" + ",";
								break;
							}
						}
					}

				} catch (Exception e) {

					parametertoPass = parametertoPass + null + ",";
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		if (parametertoPass.endsWith(",")) {
			parametertoPass = parametertoPass.substring(0, parametertoPass.length() - 1);
		}
		return parametertoPass;

	}

	public String getDataFromDBUsingParameter(String parametertoPass, Connection conn, String SP_Name)
			throws Exception {

		ArrayList<String> existingTagCheck = new ArrayList<String>();
		String finalValue = "";

		try {
			CallableStatement cStmt = conn.prepareCall("{call " + SP_Name + "(" + parametertoPass + ")}");

			cStmt.executeQuery();
			boolean results = cStmt.execute();
			while (results) {
				ResultSet finalResult = cStmt.getResultSet();
				ResultSetMetaData colu = finalResult.getMetaData();
				int colm = colu.getColumnCount();
				System.out.println(colm);
				while (finalResult.next()) {
					for (int v = 1; v < colm + 1; v++) {
						String ColumnName = colu.getColumnName(v).replaceAll("[\\s_&/+$@]", "");

						try {
							String tempVariable = finalResult.getString(v).toString().replaceAll("\\s+$", "");
							if (tempVariable.matches("") || tempVariable == null) {
								int occurrences = Collections.frequency(existingTagCheck, ColumnName);
								if (occurrences != 0) {
									finalValue = (finalValue + ColumnName.replaceAll("[\\s_&/+$@]", "") + occurrences
											+ ":" + "Blank" + "->");
									existingTagCheck.add(ColumnName);
								} else {
									finalValue = (finalValue + ColumnName.replaceAll("[\\s_&/+$@]", "") + ":" + "Blank"
											+ "->");
									existingTagCheck.add(ColumnName);
								}

							} else {
								int occurrences = Collections.frequency(existingTagCheck, ColumnName);
								if (occurrences != 0) {
									finalValue = (finalValue + ColumnName.replaceAll("[\\s_&/+$@]", "") + occurrences
											+ ":" + finalResult.getString(v).replaceAll("\\s", "").trim() + "->");
									existingTagCheck.add(ColumnName);
								} else {
									finalValue = (finalValue + ColumnName.replaceAll("[\\s_&/+$@]", "") + ":"
											+ finalResult.getString(v).replaceAll("\\s", "").trim() + "->");
									existingTagCheck.add(ColumnName);
								}
							}

						} catch (Exception e) {

						}

					}
				}
				finalResult.close();
				results = cStmt.getMoreResults();
			}

			cStmt.close();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		

		return finalValue;
	}

	public static String getFilePath() {
		String sCurrentLine = "";
		String temp = "";

		BufferedReader br = null;

		try {

			br = new BufferedReader(new FileReader("C:/WorkSpace/HeMI/ATDD_Webservice/testDataPath.txt"));

			while ((sCurrentLine = br.readLine()) != null) {
				// System.out.println(sCurrentLine);
				temp = sCurrentLine;

			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}

		}

		return temp;

	}



	public String RunNodeJsFile() {
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine engine = manager.getEngineByName("js");
		try {
			FileReader reader = new FileReader("yourFile.js");
			engine.eval(reader);
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ArrayList<String> reqTagCalulation(String path)
			throws ParserConfigurationException, SAXException, IOException {

		ArrayList<String> existingTagCheck = new ArrayList<String>();
		ArrayList<String> ListProperty = new ArrayList<String>();

		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
		Document document = docBuilder.parse(new File(path));

		NodeList nodeList = document.getElementsByTagName("*");

		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				// do something with the current element
				if (node.getNodeName().contains("soap")) {

				} else {
				String[] tempnode = node.getNodeName().split("[-+*/=:,]");
					System.out.println(tempnode);

					try {
						String tempAttribute = (tempnode[1]);
						int occurrences = Collections.frequency(existingTagCheck, tempnode[1]);

						if (occurrences != 0) {
							ListProperty.add(tempnode[1] + occurrences);
							existingTagCheck.add(tempnode[1]);

						} else {
							ListProperty.add(tempAttribute.replaceAll("\\s", ""));
							existingTagCheck.add(tempAttribute);

						}

					} catch (Exception e) {

						e.printStackTrace();
					}

				}
			}

		}

		return ListProperty;
	}
	
	public String ReadXMlandStoreString(String path) throws SAXException, IOException
	{
		String xmlAsString = null;
		
		try {
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document document = docBuilder.parse(new File(path));
			
			xmlAsString = document.toString();
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return xmlAsString;
	}
	
	public String fnGetTimeStamp() {
		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		System.out.println("timeStamp:" + timeStamp);

		return timeStamp;
	}
	

	
	

}
