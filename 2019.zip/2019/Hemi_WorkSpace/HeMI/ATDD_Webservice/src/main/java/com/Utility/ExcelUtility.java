package com.Utility;

import com.Utility.*;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility extends commonFunction {

	VariableDeclaration vb = new VariableDeclaration();

	XSSFWorkbook wb;
	XSSFWorkbook workBook;
	
	XSSFCellStyle style = null;
	XSSFCellStyle stylexFalse = null;
	XSSFCellStyle stylexTrue = null;
	XSSFCellStyle styleGreen = null;
	XSSFCellStyle styleRed = null;
	XSSFCellStyle styleYellow = null;
	XSSFSheet wshSheet;
	XSSFFont my_font = null;
	XSSFCell cell = null;
	XSSFRow row;
	FileInputStream file;
	String testCaseName = "";
	String fieldName = "";
	String tcIdName = "";
	String envName = "";
	
	public String fn_CreateExlFile(String FilePath,String WSSheet,String DBSheet,String ResultSheet) throws IOException {
		String newFilePath = FilePath;
		XSSFSheet sheet=null;

		try
		{
			
		
			workBook = new XSSFWorkbook();
		
		sheet = workBook.createSheet(WSSheet);  

		XSSFRow WSrowhead = sheet.createRow((short)0);
		WSrowhead.createCell(0).setCellValue(vb.S_No);
		WSrowhead.createCell(1).setCellValue("Endpoint");		
		WSrowhead.createCell(2).setCellValue(vb.WebServiceName);
		WSrowhead.createCell(3).setCellValue(vb.TestCaseName);
		WSrowhead.createCell(4).setCellValue(vb.TCaseID);
		WSrowhead.createCell(5).setCellValue(vb.Response);
        
        sheet = workBook.createSheet(DBSheet);  
		XSSFRow DBrowhead = sheet.createRow((short)0);
		DBrowhead.createCell(0).setCellValue(vb.S_No);
		DBrowhead.createCell(1).setCellValue("Endpoint");
		DBrowhead.createCell(2).setCellValue(vb.WebServiceName);
		DBrowhead.createCell(3).setCellValue(vb.TestCaseName);
		DBrowhead.createCell(4).setCellValue(vb.TCaseID);
		DBrowhead.createCell(5).setCellValue(vb.Response);
		
		
		sheet = workBook.createSheet(ResultSheet); 
		XSSFRow RSrowhead = sheet.createRow((short)0);
		RSrowhead.createCell(0).setCellValue(vb.S_No);
		RSrowhead.createCell(1).setCellValue(vb.WebServiceName);
		RSrowhead.createCell(2).setCellValue(vb.TestCaseName);
		RSrowhead.createCell(3).setCellValue(vb.TCaseID);
		RSrowhead.createCell(4).setCellValue("FieldName");
		RSrowhead.createCell(5).setCellValue("ActualValue-Webservice");	
		RSrowhead.createCell(6).setCellValue("ExpectedValue-DBData");	
		RSrowhead.createCell(7).setCellValue("Status");
		
		FileOutputStream outFile = new FileOutputStream(new File(FilePath));
		workBook.write(outFile);
		outFile.close();
		
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return newFilePath;
	}
	
	public String fnCreaTestDataPathFile(String destPath,String fileName){
		String testdataPath = fileName;
	    byte data[] = destPath.getBytes();
	    Path p = Paths.get(fileName);
	    File f = new File(fileName);
         if(f.exists()){
        	 f.delete();
//        	 System.out.println("Text file deleted");
         }
	    try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(p))) {
	      out.write(data, 0, data.length);
	    } catch (IOException x) {
//	      System.err.println(x);
	    }
		return testdataPath;
	    	 
	}
	
	@SuppressWarnings("unused")
	public void ExcelWrite(String Filename, String strData ,String sheetName,int rowNum) throws Exception
	{
		file = new FileInputStream(new File(Filename));
		wb = new XSSFWorkbook(file);
		String tempData[];
		int incr=0;
	//	int field1Cnt=getColumnHeaderIndex("Response", sheetName);
		int field1Cnt=0;
		tempData=strData.split("->");
		for(int k=0;k<tempData.length;k++){
			
			int iRowNumber=rowNum;
			wshSheet = wb.getSheet(sheetName);
			int cc=tempData.length;
			
		for (int i=field1Cnt;i<cc;i++){
			if(!strData.equals("")){
			XSSFRow	row2 = wshSheet.getRow(iRowNumber);
			
			if(row2==null)
			{
				row2 = wshSheet.createRow(iRowNumber);
			}
			XSSFCell cell2 = row2.getCell(field1Cnt);
			if(cell2 == null)
			{
				cell2 = row2.createCell(field1Cnt);
				cell2.setCellValue(tempData[incr]);
				incr=incr+1;
				field1Cnt=field1Cnt+1;
				break;				
			}else
			{
				cell2.setCellValue(tempData[incr]);
				incr=incr+1;
				field1Cnt=field1Cnt+1;
				break;
			}
		}
			}
			
		}
		FileOutputStream fileOut = new FileOutputStream(Filename);
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}
	
	public String getDataFromWebserviceResponse(String Filename, String sheetName,String Field, int rowNum) throws Exception
	{
		String finalValue = "";
		file = new FileInputStream(new File(Filename));
		wb = new XSSFWorkbook(file);
		wshSheet= wb.getSheet(sheetName);
		int getColCnt=wshSheet.getRow(rowNum).getLastCellNum();
		try
		{
			int field1Cnt= getColumnHeaderIndex(Field, sheetName);
			for(int j=field1Cnt;j<getColCnt;j++){
				String valData= wshSheet.getRow(rowNum).getCell(j).toString().trim();
				if(!valData.equals("")){
					finalValue = finalValue+valData +"->";
				}
				
			}
		}catch(Exception e){
			 System.out.println(e.getMessage());
		 }
		return finalValue;
	}
	
	public void fnSetUpForWriteToExcelData1(String FileName){
		String tempUpdatePath=FileName;
		readExcel(tempUpdatePath);
	}
	
	  public  void readExcel(String FileName)
	    {
			try{
			file = new FileInputStream(new File(FileName));
			   wb = new XSSFWorkbook(file);
	    }
	    catch(Exception e){
	        e.printStackTrace();
			}
	    }
	  
	  public  XSSFSheet fnGetSheet(String driverSheet){
		  XSSFSheet wshTemp = wb.getSheet(driverSheet);
		  return wshTemp;
		  }
	
	public  int getColumnHeaderIndex(String columneName,String sheetName) throws Exception{
	     int col=0;
	     XSSFSheet wshTemp = wb.getSheet(sheetName);
			int cc=wshTemp.getRow(0).getLastCellNum();
			for (int i = 0; i < cc; i++) {
					String data=wshTemp.getRow(0).getCell(i).toString().trim();
					if(data.equals(columneName)){
						col=i;
						break;
				}
			}
			return col;
	}
	
	public void updateTestResult() throws IOException{
		
    	String tempUpdatePath=getFilePath();
    	file.close();
    	FileOutputStream fileOut = new FileOutputStream(tempUpdatePath);
        wb.write(fileOut);
        fileOut.flush();
        fileOut.close();
	}
	
	public  String setValueIntoCellWithColour(int columnName, String strData,String sheetName,int iRowNumber,boolean x,String colour) throws Exception
	    {
		 XSSFRow row2=null;
		 XSSFCell    cell=null;
		 int iColumnNumber= columnName; 
//	     System.out.println("column indexs:"+iColumnNumber);
		 String temp=strData;
		 wshSheet = wb.getSheet(sheetName);
	    	row = wshSheet.getRow(iRowNumber);
	    		if(!strData.equals("")){
	    		row2 = wshSheet.getRow(iRowNumber);
	    		if(row2==null)
	    		{
	    			row2 = wshSheet.createRow(iRowNumber);
	    		}
	            cell = row2.getCell(iColumnNumber);
	            if(cell==null){
	            	cell = row2.createCell(iColumnNumber);
	            	cell.setCellValue(temp);
	            	if(strData.contains(vb.NoDataFound)){
	            		cell.setCellStyle(setCoulorCode(x,"yellow"));
	            	}else if(strData.equals(vb.StatusNotcompleted)){
	            		cell.setCellStyle(setCoulorCode(x,colour));
	            	}else{
	            	cell.setCellStyle(setCoulorCode(x,colour));
	            	}
	            }else{
	            	cell.setCellValue(temp);
	            	if(strData.contains(vb.NoDataFound)){
	            		cell.setCellStyle(setCoulorCode(x,"yellow"));
	            	}else{
	            	cell.setCellStyle(setCoulorCode(x,colour));
	            	}
	    		}
	    		}
	    		if(strData.equals("PASS")||strData.equals("FAIL")){
	    	//	createHyperLink(strData,sheetName,iRowNumber);
	    		}
	    		
	        return temp;
	    }
	
	 public XSSFCellStyle  setCoulorCode(boolean x,String colour){
			
		 if(style == null)
		 {
			 style = wb.createCellStyle();
			 				 
			 stylexFalse = wb.createCellStyle();
			 my_font=wb.createFont();
			 my_font.setFontName("Times New Roman"); 
		//	 my_font.setColor(XSSFColor.BLACK.index);
			 my_font.setColor(IndexedColors.BLACK.getIndex());
			 
			 
			 stylexFalse.setFont(my_font);
             stylexFalse.setFont(my_font);
             stylexFalse.setAlignment(XSSFCellStyle.ALIGN_CENTER);
             stylexFalse.setBorderBottom(XSSFCellStyle.BORDER_THIN);
             stylexFalse.setBorderTop(XSSFCellStyle.BORDER_THIN);
             stylexFalse.setBorderRight(XSSFCellStyle.BORDER_THIN);
             stylexFalse.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			 stylexFalse.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			 
			 styleGreen = wb.createCellStyle();
			 my_font=wb.createFont();
			 my_font.setFontName("Times New Roman"); 
		//	 my_font.setColor(XSSFColor.BLACK.index);
			 my_font.setColor(IndexedColors.BLACK.getIndex());
			 
			 styleGreen.setFont(my_font);
			 styleGreen.setFont(my_font);
			 styleGreen.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			 styleGreen.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			 styleGreen.setBorderTop(XSSFCellStyle.BORDER_THIN);
			 styleGreen.setBorderRight(XSSFCellStyle.BORDER_THIN);
			 styleGreen.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			 styleGreen.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			 
			 styleRed = wb.createCellStyle();
			 my_font=wb.createFont();
			 my_font.setFontName("Times New Roman"); 
			 
			 styleRed.setFont(my_font);
			 styleRed.setFont(my_font);
			 styleRed.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			 styleRed.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			 styleRed.setBorderTop(XSSFCellStyle.BORDER_THIN);
			 styleRed.setBorderRight(XSSFCellStyle.BORDER_THIN);
			 styleRed.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			 styleRed.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			 
			 styleYellow = wb.createCellStyle();
			 my_font=wb.createFont();
			 my_font.setFontName("Times New Roman"); 
		//	 my_font.setColor(XSSFColor.BLACK.index);
			 my_font.setColor(IndexedColors.BLACK.getIndex());
			 
			 styleYellow.setFont(my_font);
			 styleYellow.setFont(my_font);
			 styleYellow.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			 styleYellow.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			 styleYellow.setBorderTop(XSSFCellStyle.BORDER_THIN);
			 styleYellow.setBorderRight(XSSFCellStyle.BORDER_THIN);
			 styleYellow.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			 styleYellow.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			 
			 
			 stylexTrue = wb.createCellStyle();
			 my_font=wb.createFont();
			 my_font.setFontName("Times New Roman"); 
		//	 my_font.setColor(XSSFColor.BLACK.index);
			 my_font.setColor(IndexedColors.BLACK.getIndex());
			 
			 stylexTrue.setFont(my_font);
			 stylexTrue.setFont(my_font);
			 stylexTrue.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			 stylexTrue.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			 stylexTrue.setBorderTop(XSSFCellStyle.BORDER_THIN);
			 stylexTrue.setBorderRight(XSSFCellStyle.BORDER_THIN);
			 stylexTrue.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			 stylexTrue.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			 
			 if(x==false)
			 {
				// stylexFalse.setFillForegroundColor(XSSFColor.GREY_25_PERCENT.getIndex);
				 stylexFalse.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
				 
            	if(colour.equals("green")){
            		
            		styleGreen.setFillForegroundColor(IndexedColors.GREEN.getIndex());
            		return style = styleGreen;
            		}
            	else if(colour.equals("red")){
            		
            		styleRed.setFillForegroundColor(IndexedColors.RED.getIndex());
            		my_font.setColor(IndexedColors.INDIGO.getIndex());
            		styleRed.setFont(my_font);
            		return style = styleRed;
            		}
            	else if(colour.equals("yellow")){

            		styleYellow.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
            		
            		return style = styleYellow;
            		
            	}
            	 return style = stylexFalse;
	 
			 }else if(x==true)
			 {
				 stylexTrue.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex()); 
				 
				 if(colour.equals("green")){
	            		
	            		styleGreen.setFillForegroundColor(IndexedColors.GREEN.getIndex());
	            		return style = styleGreen;
	            		}
	            	else if(colour.equals("red")){
	            		
	            		styleRed.setFillForegroundColor(IndexedColors.RED.getIndex());
	            		my_font.setColor(IndexedColors.INDIGO.getIndex());
	            		styleRed.setFont(my_font);
	            		return style = styleRed;
	            		}
	            	else if(colour.equals("yellow")){

	            		styleYellow.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
	            		
	            		return style = styleYellow;
	            		
	            	}
            	 return style = stylexTrue;
			 }
			
		 }else
		 {
			 if(x==false)
			 {
				 stylexFalse.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex()); 						 
				 if(colour.equals("green")){
	            		
	            		styleGreen.setFillForegroundColor(IndexedColors.GREEN.getIndex());
	            		return style = styleGreen;
	            		}
	            	else if(colour.equals("red")){
	            		
	            		styleRed.setFillForegroundColor(IndexedColors.RED.getIndex());
	            		my_font.setColor(IndexedColors.INDIGO.getIndex());
	            		styleRed.setFont(my_font);
	            		return style = styleRed;
	            		}
	            	else if(colour.equals("yellow")){

	            		styleYellow.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
	            		
	            		return style = styleYellow;
	            		
	            	}
            	 return style = stylexFalse;
			 }else if(x==true)
			 {
				 stylexTrue.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.index);
				 						 
				 if(colour.equals("green")){
	            		
	            		styleGreen.setFillForegroundColor(IndexedColors.GREEN.getIndex());
	            		return style = styleGreen;
	            		}
	            	else if(colour.equals("red")){
	            		
	            		styleRed.setFillForegroundColor(IndexedColors.RED.getIndex());
	            		my_font.setColor(IndexedColors.INDIGO.getIndex());
	            		styleRed.setFont(my_font);
	            		return style = styleRed;
	            		}
	            	else if(colour.equals("yellow")){

	            		styleYellow.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
	            		
	            		return style = styleYellow;
	            		
	            	}
            	 return style = stylexTrue;
			 }
		 }
		 return style;
	 }

}