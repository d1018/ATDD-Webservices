package com.Hemi.stepDefination;


import com.Utility.cosmosDB;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class stepDefination {
	
	cosmosDB cdb = new cosmosDB();
	
	
	@Given("^IRIS UI has done some changes$")
	public void iris_UI_has_done_some_changes() throws Throwable {
	    // Write code here that turns the phrase above into concrete action
	}

	@When("^Changes is successful$")
	public void changes_is_successful() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	
	}

	@Then("^DB should be connected Successfully$")
	public void db_should_be_connected_Successfully() throws Throwable {
	    cdb.setup();
	
	}

}
