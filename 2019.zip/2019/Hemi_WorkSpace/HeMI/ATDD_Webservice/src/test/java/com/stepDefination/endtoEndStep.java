package com.stepDefination;

import java.util.List;
import java.util.Map;

import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.impl.wsdl.WsdlTestSuite;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner;
import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestRequestStepResult;
import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStep;
import com.eviware.soapui.model.testsuite.TestProperty;
import com.eviware.soapui.model.testsuite.TestStepResult;
import com.eviware.soapui.support.types.StringToObjectMap;
import com.eviware.soapui.tools.SoapUITestCaseRunner;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class endtoEndStep {
	
	String endPoint_URL = null;
	String testSuiteName = "";
	String testCaseName = "";
	
	@Given("^The Endpoint for Service as \"([^\"]*)\"$")
	public void the_Endpoint_for_Service_as(String endPoint){
			
		endPoint_URL = endPoint;
	}

	@When("^TestSuite and Testcase name to be execute as \"([^\"]*)\",\"([^\"]*)\"$")
	public void testsuite_and_Testcase_name_to_be_execute_as(String TSName, String TCName){
		
		testSuiteName = TSName;
		testCaseName = TCName;
	}

	@Then("^Execute SoapUI to get the Response$")
	public void execute_SoapUI_to_get_the_Response() throws Throwable {
		
		String[] prop= {testSuiteName,endPoint_URL,testCaseName};
		
		
		try {

			SoapUITestCaseRunner SoapUITestCaseRunner = new SoapUITestCaseRunner();
			SoapUITestCaseRunner.setProjectFile("src\\test\\resources\\WebservicesProject_SXC Regression-soapui-project.xml");

			SoapUITestCaseRunner.setProjectProperties(prop);

			SoapUITestCaseRunner.setTestSuite("Driver");

			SoapUITestCaseRunner.setTestCase("Execution");
			
			SoapUITestCaseRunner.setWssPasswordType("client123");
			SoapUITestCaseRunner.run();

			

		} catch (Exception e) {

			e.printStackTrace();

		}

	}


}
