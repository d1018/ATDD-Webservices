package com.stepDefination;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.SOAPMessage;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.xmlbeans.XmlException;
import org.testng.Assert;
import org.xml.sax.SAXException;

import com.Utility.commonFunction;
import com.eviware.soapui.model.propertyexpansion.PropertyExpansionContext;
import com.eviware.soapui.model.support.PropertiesMap;
import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.model.testsuite.TestProperty;
import com.eviware.soapui.model.testsuite.TestRunner;
import com.eviware.soapui.model.testsuite.TestStep;
import com.eviware.soapui.model.testsuite.TestStepResult;
import com.eviware.soapui.model.testsuite.TestSuite;
import com.eviware.soapui.support.GroovyUtils;
import com.eviware.soapui.support.SoapUIException;
import com.eviware.soapui.support.XmlHolder;
import com.eviware.soapui.support.xml.XmlUtils;
import com.eviware.soapui.tools.SoapUITestCaseRunner;
import com.eviware.soapui.impl.*;
import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.impl.wsdl.WsdlTestSuite;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner;
import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStep;
import com.gargoylesoftware.htmlunit.javascript.host.xml.XMLDocument;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import jxl.demo.XML;


import com.Utility.*;

public class SOAPTestSteps {
	
	SOAPHelper SH = new SOAPHelper();
	commonFunction com = new commonFunction();
	UpdateResult upe = new UpdateResult();
	ExcelUtility ex = new ExcelUtility();
	VariableDeclaration vb = new VariableDeclaration();
	String newFilePath="";
	String endPoint_URL = null;
	String testSuiteName = "";
	String testCaseName = "";
	XSSFSheet WSsheet=null;
	
	Connection conn = null;
	ResultSet rs = null;
	ArrayList<String> InputParam = new ArrayList<String>();
	String parametertoPass = "";
	String finalValue = "";
	String SP_Name = "";
	
	@Given("^The Endpoint_URL \"([^\"]*)\"$")
	public void the_Endpoint_URL(String endPoint) {
		
		
	}
	
	@Given("^The Endpoint_URL \"([^\"]*)\" and RxClaim DB Credential \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void the_Endpoint_URL_and_RxClaim_DB_Credential(String endPoint, String SPName, String DBName, String Schema) throws Exception {
		endPoint_URL = endPoint;
		SP_Name = SPName;
		conn = com.getRxClaimDBConnection();
		System.out.println("Connected to the database!!! Successful...");

		Statement st = conn.createStatement();
		DatabaseMetaData dbm = conn.getMetaData();
		rs = dbm.getProcedureColumns(DBName, Schema, SP_Name, null);

		while (rs.next()) {
			InputParam.add(rs.getString(4).replaceAll("[@/]", ""));
			System.out.println(InputParam.toString());
		}
		
	}

	@When("^TestSuite and Testcase to execute as \"([^\"]*)\",\"([^\"]*)\"$")
	public void testsuite_and_Testcase_to_execute_as(String TSName, String TCName) {
		
		testSuiteName = TSName;
		testCaseName = TCName;

	}
	
	@Then("^Execute SoapUI with the Request$")
	public void execute_SoapUI_with_the_Request(DataTable InputParameter) throws Exception{
		
		List<Map<String,String>> data = InputParameter.asMaps(String.class,String.class);
	
		newFilePath = ex.fn_CreateExlFile(vb.destFilePath,vb.WebServicesResponseData,vb.DBData,vb.ResultSheet);
		String TestDataPath = ex.fnCreaTestDataPathFile(newFilePath,vb.testdataPath);
		System.out.println(newFilePath);
		
			WsdlProject project;

				project = new WsdlProject("src\\test\\resources\\WebservicesProject_SXC Regression-soapui-project.xml");
	
		
		
		int Row=1;
		
		for(int i=0;i<=data.size();i++)
		{
			try
			{
				String RowNo = Integer.toString(Row);
				String TCaseID= data.get(i).get("TCName");
				String InputTag = data.get(i).toString();				
				
				System.out.println(InputTag);
							
				TestSuite testSuite = project.getTestSuiteByName("Driver");
				TestCase  testcase = testSuite.getTestCaseByName("Execution");
				TestStep  testStep = testcase.getTestStepByName("GroovyScript");
				
				testSuite.setPropertyValue("TestSuiteName",testSuiteName);
				testSuite.setPropertyValue("TestCaseName",testCaseName);
				testSuite.setPropertyValue("EndPoint",endPoint_URL);
				testSuite.setPropertyValue("InputParameters",InputTag);
				testSuite.setPropertyValue("RowNo",RowNo);
				testSuite.setPropertyValue("TC_ID",TCaseID);
				
				TestRunner runner = testcase.run(new PropertiesMap(), false);
				
				// DB to Perform	
				try
				{
				String TestingType= data.get(i).get("TestingType");	
				
				String DataList = data.get(i).toString().replaceAll("[{}]","").trim();
				System.out.println(DataList);
				parametertoPass = com.getParametersforSP(DataList, InputParam);		
				finalValue = (RowNo +"->"+endPoint_URL+"->"+testSuiteName+"->"+testCaseName+"->"+TCaseID+"->");
				
				//Update Result to DBsheet
				if(TestingType.equals("Positive"))
				{
					finalValue = finalValue + com.getDataFromDBUsingParameter(parametertoPass, conn, SP_Name);
					ex.ExcelWrite(newFilePath,finalValue ,vb.DBData,Row);
				}else
				{
					finalValue = finalValue + ex.getDataFromWebserviceResponse(newFilePath,vb.WebServicesResponseData,vb.Response,Row);
					ex.ExcelWrite(newFilePath,finalValue ,vb.DBData,Row);
				}
				
				
				}catch (Exception e) {}	
				
				
			}catch (Exception e) {}
			Row++;
		}
		
	}
	
	@Then("^compare the result and update in ResultSheet$")
	public void compare_the_result_and_update_in_ResultSheet() throws Throwable {
	   
		upe.fnupdateResultWithData(newFilePath,vb.DBData,vb.WebServicesResponseData,vb.ResultSheet);
	}

}
