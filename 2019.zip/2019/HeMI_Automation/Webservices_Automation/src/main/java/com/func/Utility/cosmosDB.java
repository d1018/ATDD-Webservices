package com.func.Utility;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.documentdb.ConnectionPolicy;
import com.microsoft.azure.documentdb.ConsistencyLevel;
import com.microsoft.azure.documentdb.DocumentClient;
import com.microsoft.azure.documentdb.FeedOptions;
import com.microsoft.azure.documentdb.RequestOptions;

public class cosmosDB {
	

	commonFunctions com = new commonFunctions();
	public static void main(String[] args) {
        SpringApplication.run(cosmosDB.class, args);
    }
	
	private DocumentClient client;
	
    private String cosmosDbUri = com.getPropertyFile("azure.cosmosdb.uri");
    private String cosmosDbKey = com.getPropertyFile("azure.cosmosdb.key");
    private String databaseId = com.getPropertyFile("azure.cosmosdb.database");
    private String collectionId = com.getPropertyFile("azure.cosmosdb.collection");
    private String partitionKey = com.getPropertyFile("azure.cosmosdb.partition.key");
    private String partitionKeyPath;
    private String collectionLink;

    private RequestOptions reqOptions = new RequestOptions();
    private FeedOptions feedOptions = new FeedOptions();
    private DocumentClient documentClient;
    private ObjectMapper mapper = new ObjectMapper();
    
    private static final Logger logger = LogManager.getLogger(cosmosDB.class);
    
	
    @PostConstruct
    public void setup() {
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        partitionKeyPath = "/" + partitionKey;
        collectionLink = String.format("/dbs/%s/colls/%s", databaseId, collectionId);
        feedOptions.setEnableCrossPartitionQuery(true);
        documentClient = new DocumentClient(
                cosmosDbUri,
                cosmosDbKey,
                ConnectionPolicy.GetDefault(),
                ConsistencyLevel.Session);
    }
    
    private final static String QUERY_BY_PARTY_ID = "select * from root r where r.partyId = @partyId";



}
