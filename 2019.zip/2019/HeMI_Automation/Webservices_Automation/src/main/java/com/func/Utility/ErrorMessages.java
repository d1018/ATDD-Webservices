package com.func.Utility;


public class ErrorMessages {

}
