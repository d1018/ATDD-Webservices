package com.func.Utility;

import static java.nio.file.StandardOpenOption.APPEND;
import static java.nio.file.StandardOpenOption.CREATE;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class commonFunctions {
	

	public static String formatDateFromOnetoAnother(String date,String givenformat,String resultformat){
	    String result="";
	    SimpleDateFormat sdf;
	    SimpleDateFormat sdf1;
	    
	    try {
	        sdf = new SimpleDateFormat(givenformat);
	        sdf1 = new SimpleDateFormat(resultformat);
	        result=sdf1.format(sdf.parse(date));
	    } catch(Exception e) {
	        e.printStackTrace();
	        return "null";
	    } finally {
	        sdf=null;
	        sdf1=null;
	    }


	  return result;
	}
		
	
	  public static Connection getMySqlConnection() throws Exception {
		    String driver = "net.sourceforge.jtds.jdbc.Driver";
		    String url = "jdbc:jtds:sqlserver://DBSET1664:1433;DatabaseName=INETFORMULARY";
		    String username = "runx_ecs_svc";
		    String password = "meC3f=vX";

		    Class.forName(driver);
		    Connection conn = DriverManager.getConnection(url, username, password);
		    return conn;
		  }
	  
	  
	  public static Connection getDb2Connection() throws Exception {
		    String driver = "net.sourceforge.jtds.jdbc.Driver";
		    String url = "jdbc:jtds:sqlserver://DBSET1664:1433;DatabaseName=INETFORMULARY";
		    String username = "runx_ecs_svc";
		    String password = "meC3f=vX";

		    Class.forName(driver);
		    Connection conn = DriverManager.getConnection(url, username, password);
		    return conn;
		  }
	  
	
	public static String formatDecimalSinFromOnetoAnother(String Value,String givenformat,String resultformat){
	    String result="";
	    DecimalFormat sdf;
	    DecimalFormat sdf1;
	    
	    try {
	        sdf = new DecimalFormat(givenformat);
	        sdf1 = new DecimalFormat(resultformat);
	        result=sdf1.format(sdf.parse(Value));
	    } catch(Exception e) {
	        e.printStackTrace();
	        return "";
	    } finally {
	        sdf=null;
	        sdf1=null;
	    }
	    
	  return result;
	}


	public static ArrayList<String> formatArrayDateFromOnetoAnother(ArrayList<String> arrayList,String givenformat,String resultformat){
		ArrayList <String> result = new ArrayList<String>();
		//String result="";
	    SimpleDateFormat sdf;
	    SimpleDateFormat sdf1;

	    try {
	        sdf = new SimpleDateFormat(givenformat);
	        sdf1 = new SimpleDateFormat(resultformat);
	        for (String dateinput : arrayList ) {
	        	  
	        	result.add(sdf1.format(sdf.parse(dateinput)));
	        }
	      
	    } catch(Exception e) {
	        e.printStackTrace();
	  } finally {
	        sdf=null;
	        sdf1=null;
	    }

	    
	  return result;
	}
	
	public String fnGetTimeRead(){
		
		
		String sCurrentLine ="";
		String resultFolder="";
		BufferedReader br = null;
		
		try{
			
			br = new BufferedReader(new FileReader(VariableDeclaration.testFileName));
		
			sCurrentLine = br.readLine();
		String[] splitStr = sCurrentLine.split("[_.]");
		resultFolder = splitStr[1].trim().toString();
		
		}
		 catch (IOException e) {
				e.printStackTrace();
			}
		finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
			
			
		}
		
		 return resultFolder;
		
	}
	public String fnGetTimeStamp(){
		 String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		System.out.println("timeStamp:"+timeStamp);
		
		return timeStamp;
	}
	public void fnCreaTestDataPathFile(String destPath,String fileName){
	    byte data[] = destPath.getBytes();
	    Path p = Paths.get(fileName);
	    File f = new File(fileName);
         if(f.exists()){
        	 f.delete();
//        	 System.out.println("Text file deleted");
         }
	    try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(p, CREATE, APPEND))) {
	      out.write(data, 0, data.length);
	    } catch (IOException x) {
//	      System.err.println(x);
	    }
	    
	}
	public void fnMovePreviousExcutedFileToArchiveFolder(String destPathArchive,String sourceFilesPath){
		 File destinationFolder = new File(destPathArchive);
		    File sourceFolder = new File(sourceFilesPath);

		    if (!destinationFolder.exists())
		    {
		        destinationFolder.mkdirs();
		    }

		    // Check weather source exists and it is folder.
		    if (sourceFolder.exists() && sourceFolder.isDirectory())
		    {
		        // Get list of the files and iterate over them
		        File[] listOfFiles = sourceFolder.listFiles();

		        if (listOfFiles != null)
		        {
		            for (File child : listOfFiles )
		            {
		            	if(!child.isDirectory()){
		                // Move files to destination folder
		                child.renameTo(new File(destinationFolder + "\\" + child.getName()));
		            	}
		            }

		            // Add if you want to delete the source folder 
//		            sourceFolder.delete();
		        }
		    }
		    else
		    {
		        System.out.println(sourceFolder + "  Folder does not exists");
		    }
		    
	}
	
	public static void func_ScreenCapture(String screenName) throws AWTException, IOException 
	{
		
		BufferedImage capture = null;
		String dte = new SimpleDateFormat("yyyyMMdd").format(new Date());
		String filePath=VariableDeclaration.screenPath+"\\"+dte+"\\"+VariableDeclaration.getTieStamp;
		VariableDeclaration.screenShotPath=filePath;
		File destinationFolder = new File(filePath);
	    if (!destinationFolder.exists()){
	        destinationFolder.mkdirs();
	    }
		Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
		
			capture = new Robot().createScreenCapture(screenRect);
//		ImageIO.write(capture, "jpg", new File(destinationFolder+"\\"+VariableDeclaration.testCaseNameForScreenShot+"_"+screenName+".jpg"));
		ImageIO.write(capture, "jpg", new File(destinationFolder+"\\"+VariableDeclaration.environmentSelected.replaceAll("\\s", "")+"_"+VariableDeclaration.testCaseNameForScreenShot+"_"+screenName+".jpg"));
		
	}
	
	public String getvalidatedData(String statusText){
		String tempVal=statusText;
		if(statusText.equals("")){
			
			//tempVal.add("No Data Found");
			tempVal=VariableDeclaration.NoDataFound;
		}
		
		return tempVal;
		
	}
	public ArrayList getvalidatedData(ArrayList data){
		ArrayList<String> tempVal=data;
//			if(data.size()==0)
		if(tempVal.size()==0){
				tempVal.add(VariableDeclaration.NoDataFound);
			}
		
			return tempVal;
			
		}
	public ArrayList<String> getvalidatedarrayData(ArrayList<String> priorAuthNumber){
		ArrayList<String> tempVal=priorAuthNumber;
//		if(priorAuthNumber.equals(""))
		if(tempVal.isEmpty()){
			
			tempVal.add("No Data Found");
			//tempVal=VariableDeclaration.NoDataFound;
		}
		
		return tempVal;
		
	}
	/**
	 * Validate To date
	 * @param memberToDte
	 *   enter todate
	 * @return 
	 * updated todate
	 */
	public String valThroughDate(String memberToDte){
		String tempToDate="";
		tempToDate=memberToDte;
		if(tempToDate.startsWith("19")){
			tempToDate=tempToDate.replace("19", "20");
		}
		if(tempToDate.startsWith("00")){
			if(tempToDate.startsWith("0091")){
				tempToDate=tempToDate.replace("0091", "1991");
			}else{
			tempToDate=tempToDate.replace("00", "20");
			}
		}
		
		
		return tempToDate;
	}
	
	/**
	 * Find window by title name
	 * @param windowTitle
	 * 	Enter window title name
	 * @return
	 * @throws InterruptedException 
	 */

	  
	public String getPropertyFile(String servicename) {

		Properties InputField;
		InputField = new Properties();
		InputStream InputFile = null;
		try {
			InputFile = new FileInputStream(new File("src/main/resources/application.properties"));
			InputField.load(InputFile);

		} catch (IOException ex) {
			System.out.println("unable to read property file");
		}

		String request = (InputField.getProperty(servicename));

		return request;

	}


	  

	public String getResponseDataFrmXml(String tagName,String fieldName,String fileName){
		String fieldData="";
		try {

			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			 DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			 Document doc = docBuilder.parse (new File("C:\\WebserviceAutomation\\WebServiceResponse\\"+fileName));
			 // normalize text representation
			 doc.getDocumentElement ().normalize ();

			 NodeList listOfPersons = doc.getElementsByTagName(tagName);
//			 int totalPersons = listOfPersons.getLength();
//			 System.out.println("Total no of people : " + totalPersons);
			 for(int s=0; s<listOfPersons.getLength() ; s++){
			 Node firstPersonNode = listOfPersons.item(s);
			 if(firstPersonNode.getNodeType() == Node.ELEMENT_NODE){
			 Element firstPersonElement = (Element)firstPersonNode; 
			 NodeList firstNameList = firstPersonElement.getElementsByTagName(fieldName);
			 Element firstNameElement = (Element)firstNameList.item(0);

			 NodeList textFNList = firstNameElement.getChildNodes();
//			 System.out.println(fieldName+" : " + ((Node)textFNList.item(0)).getNodeValue().trim());
			 fieldData=((Node)textFNList.item(0)).getNodeValue().trim();
			 return fieldData;
			 
			 }//end of if clause
			 }//end of for loop with s var
			 }catch (SAXParseException err) {
//			 System.out.println ("** Parsing error" + ", line " + err.getLineNumber () + ", uri " + err.getSystemId ());
//			 System.out.println(" " + err.getMessage ());
			 }catch (SAXException e) {
			 Exception x = e.getException ();
			 ((x == null) ? e : x).printStackTrace ();
			 }catch (Throwable t) {
			 t.printStackTrace ();
			 }
		
		return fieldData;

	}

    /**
     * Create soupUI batch file
     * @param fileName
     * 		Enter file name
     * @throws IOException
     * @throws InterruptedException 
     */
	public static void fnCreateSoupBatFile(String fileName) throws IOException, InterruptedException 
    { 
    	String path="C:\\ConsolidatedWebservices\\WebServiceTempBatFile\\";
    	
    	String soupPath="\"C:\\Program Files\\SmartBear\\SoapUI-5.2.0\\bin\\testrunner.bat\"" +" -s" +"\"Driver\"" +" -c" +  "\"Execution\""+ " \"C:\\ConsolidatedWebservices\\WebServiceProject\\Webservices-Speciality-soapui-project.xml\"";
    //	String soupPath="\"C:\\Program Files\\SmartBear\\SoapUI-5.2.0\\bin\\testrunner.bat\"" +" -s" +"\"Driver\"" +" -c" +  "\"Execution\""+ " \"C:\\ConsolidatedWebservices\\WebServiceProject\\WebservicesProject-soapui-project.xml\"";
    //	String soupPath="\"C:\\Program Files\\SmartBear\\SoapUI-5.2.0\\bin\\testrunner.bat\"" +" -s" +"\"Driver\"" +" -c" +  "\"Execution\""+ " \"C:\\ConsolidatedWebservices\\WebServiceProject\\Webservices_Automation_PORTALS.xml\"";
   // 	String soupPath="\"C:\\Program Files\\SmartBear\\SoapUI-5.2.0\\bin\\testrunner.bat\"" +" -s" +"\"Driver\"" +" -c" +  "\"Execution\""+ " \"C:\\ConsolidatedWebservices\\WebServiceProject\\Webservices-Aging-soapui-project.xml\"";
   // 	String soupPath="\"C:\\Program Files\\SmartBear\\SoapUI-5.2.0\\bin\\testrunner.bat\"" +" -s" +"\"Driver\"" +" -c" +  "\"Execution\""+ " \"C:\\ConsolidatedWebservices\\WebServiceProject\\Webservices-KANBAN-POC-soapui-project.xml\"";
  // 	String soupPath="\"C:\\Program Files\\SmartBear\\SoapUI-5.2.0\\bin\\testrunner.bat\"" +" -s" +"\"Driver\"" +" -c" +  "\"Execution\""+ " \"C:\\ConsolidatedWebservices\\WebServiceProject\\WebservicesProject_SXC Regression-soapui-project.xml\"";
 //   	String soupPath="\"C:\\Program Files\\SmartBear\\SoapUI-5.3.0\\bin\\testrunner.bat\"" +" -s" +"\"Driver\"" +" -c" +  "\"Execution\""+ " \"C:\\ConsolidatedWebservices\\WebServiceProject\\WebservicesProject-soapui-project.xml\"";
//    	String soupPath="\"C:\\Program Files\\SmartBear\\SoapUI-5.2.0\\bin\\testrunner.bat\"" +" -s" +"\"DriverData\"" +" -c" +  "\"ConsolidatedTestRun\""+ " \"C:\\WebserviceAutomation\\WebServiceProject\\POCFinal-soapui-project.xml\"" + "\n" + "exit" + "\n" + "exit";
//    	String soupPath="\"C:\\Program Files\\SmartBear\\SoapUI-5.2.0\\bin\\testrunner.bat\"" +" -s" +"\"Driver\"" +" -c" +  "\"Execution\""+ " \"C:\\ConsolidatedWebservices\\WebServiceProject\\WebServices_RxESB-soapui-project.xml\"";
//    	System.out.println("soup:"+soupPath); 
    	
  	
    	File file = new File(path+fileName);
          if (file.createNewFile()){
            System.out.println("File is created!");
          }else{	
            System.out.println("File already exists.");
          }
           
        //Write Content
          FileWriter writer = new FileWriter(file);
          writer.write(soupPath);
          writer.close();
          Thread.sleep(4000);
          
          
    }
    
    /**
     * Execute SoupUI batch file
     * @param batFileName
     * 		Enter batch file
     * @throws InterruptedException 
     */
    public void fnExecuteSoupUIBat(String batFileName) throws InterruptedException{
    	String path="C:\\ConsolidatedWebservices\\WebServiceTempBatFile\\"+batFileName;
    	
    	try{    
    		Runtime runtime = Runtime.getRuntime();
    	    Process p = runtime.exec("cmd /c start "+path);
    	    System.out.println(p.getInputStream().read());    	    
    	}catch( IOException ex ){
    	    //Validate the case the file can't be accesed (not enought permissions)

    	}
    	
    	
    }
    
   
	public static String getFilePath()			
    {
			String sCurrentLine ="";
			String temp="";
	

	BufferedReader br = null;

	try {

		br = new BufferedReader(new FileReader("C:/ConsolidatedWebservices/testDataPath.txt"));

		while ((sCurrentLine = br.readLine()) != null) {
//			System.out.println(sCurrentLine);
			temp=sCurrentLine;
			
		}
		
	} catch (IOException e) {
		e.printStackTrace();
	}
	 
	finally {
		try {
			if (br != null)br.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		
		
	}
	
	return temp;

	
}
	
    

}
