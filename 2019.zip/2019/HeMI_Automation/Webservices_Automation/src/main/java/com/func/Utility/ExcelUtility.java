package com.func.Utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility extends commonFunctions  {
	

	String tcCountName=VariableDeclaration.tcCountName;
	String EnvName = VariableDeclaration.envName;
	 XSSFWorkbook wb;
	 
	 
	 XSSFSheet sheet;
	 XSSFCellStyle style = null;
	 XSSFCellStyle stylexFalse = null;
	 XSSFCellStyle stylexTrue = null;
	 XSSFCellStyle styleGreen = null;
	 XSSFCellStyle styleRed = null;
	 XSSFCellStyle styleYellow = null;
	  
	 XSSFFont my_font = null;
	 XSSFCell cell = null;
	 XSSFRow row;
	 FileInputStream file;
	 String testCaseName="";
	 String fieldName="";
	 String tcIdName="";
	 String envName="";
	public static StringBuilder sb = new StringBuilder();
	 public String getDriverSheetNameFromEnvironment() throws InterruptedException {
			String tempEnv="";
			String tempExc="";
			String environmentToBeExe="";
			try {
				fnSetUpForMasterExcelData();
			} catch (IOException e) {
				e.printStackTrace();
			}
			Thread.sleep(2000);
			sheet=fnGetSheet(VariableDeclaration.environment);
			int irow=sheet.getLastRowNum();
			for(int i=0;i<=irow;i++){
				int environment=0;
				try {
					environment = getColumnHeaderIndex("Environment", VariableDeclaration.environment);
				} catch (Exception e) {
					e.printStackTrace();
				}
				tempEnv= sheet.getRow(i).getCell(environment).toString().toUpperCase().trim();
				int EnvExc = 0;
				try {
					EnvExc = getColumnHeaderIndex("ExecutionStatus", VariableDeclaration.environment);
				} catch (Exception e) {
					e.printStackTrace();
				}
				tempExc= sheet.getRow(i).getCell(EnvExc).toString().toUpperCase().trim();
				if(tempEnv.equals("LORX")&&(tempExc.equals("YES"))){
					environmentToBeExe=VariableDeclaration.DriverSheetBOOK1;
					break;
				}
				if(tempEnv.equals("UHG instance")&&(tempExc.equals("YES"))){
					environmentToBeExe=VariableDeclaration.DriverSheetBOOK2;
					break;
				}
			}
			System.out.println("environmentToBeExe:"+environmentToBeExe);
			return environmentToBeExe;
		}
	 public static String getEnvironmentToBeSet(String env) {
		 String tempBOOK="";
			if(env.toUpperCase().equals("LORX")){
				tempBOOK="1";
			}else if(env.toUpperCase().equals("CATAMARAN(LCTRX)")){
				tempBOOK="3";
			}else{
				tempBOOK="2";
			}
			return tempBOOK;
		}
	 public static String getHostNameToBeSet(String env) {
		 String tempBOOK="";
			if(env.toUpperCase().equals("1")||env.toUpperCase().equals("LORX")){
				tempBOOK=VariableDeclaration.hostBook1;
			}else if(env.toUpperCase().equals("3")||env.toUpperCase().equals("Catamaran(LCTRX)")){
				tempBOOK=VariableDeclaration.hostBook3;
			}else{
				tempBOOK=VariableDeclaration.hostBook2;
			}
			return tempBOOK;
		}
	public void fnSetUpForWriteToExcelData() throws IOException{
		String filePath=fun_CreateAndGetNewDataSheet1(VariableDeclaration.orgFilePathMaster,VariableDeclaration.destFilePath);
		readExcel(filePath);
	}
	public void fnSetUpForMasterExcelData() throws IOException{
		readExcel(VariableDeclaration.orgFilePathMaster);
		
	}
	  public String fun_CreateAndGetNewDataSheet1(String originalPath,String destPath) throws IOException {
		  String newFilePath=destPath;
//		  fnCreaTestDataPathFile(destPath,VariableDeclaration.testFileName);
//			Thread.sleep(2000);
				file = new FileInputStream(new File(originalPath));
				wb = new XSSFWorkbook(file);
				file.close();
			FileOutputStream outFile =new FileOutputStream(new File(destPath)); 
			wb.write(outFile);
			outFile.close();
		  return newFilePath;
	  }
	  
	  public  void readExcel(String destinationFile)
	    {
			try{
			file = new FileInputStream(new File(destinationFile));
			   wb = new XSSFWorkbook(file);
	    }
	    catch(Exception e){
	        e.printStackTrace();
			}
	    }
	  public  XSSFSheet fnGetSheet(String driverSheet){
		  XSSFSheet wshTemp = wb.getSheet(driverSheet);
		  return wshTemp;
		  }
	  
	  /**
		 * Get test case Column count
		 * @param filePath
		 * 				Enter file Path
		 * @return
		 * 	Returns Column count
		 * @throws Exception
		 */
		public  int getColumnHeaderIndex(String columneName,String sheetName) throws Exception{
			     int col=0;
			     XSSFSheet wshTemp = wb.getSheet(sheetName);
					int cc=wshTemp.getRow(0).getLastCellNum();
					for (int i = 0; i < cc; i++) {
							String data=wshTemp.getRow(0).getCell(i).toString().trim();
							if(data.equals(columneName)){
								col=i;
								break;
						}
					}
					return col;
			}
		/**
		 * @param fieldNameToFind
		 * 			Enter field name to find row count
		 * @param sheetName
		 * 			Enter sheet name
		 * @param colHeader
		 * 			Enter column header Name
		 * @return
		 * 			return integer value
		 * @throws Exception
		 */
		public  int getRowIndex(String fieldNameToFind,String sheetName,String colHeader) throws Exception{
			     int row=0;
			     XSSFSheet wshTemp = wb.getSheet(sheetName);
			     int serviceColIndex=getColumnHeaderIndex(colHeader,sheetName);
					int rc=wshTemp.getLastRowNum();
					for (int i = 1; i <= rc; i++) {
						String data=wshTemp.getRow(i).getCell(serviceColIndex).toString().trim();
							if(data.equals(fieldNameToFind)){
								row=i;
								break;
						}
					}
					return row;
				}
		public  int getTestCaseStartCnt(String testCaseName,String sheetName,String colHeader) throws Exception{
		     int row=0;
		     XSSFSheet wshTemp = wb.getSheet(sheetName);
		     int serviceColIndex=getColumnHeaderIndex(colHeader,sheetName);
				int rc=wshTemp.getLastRowNum();
				for (int i = 1; i < rc; i++) {
					String data=wshTemp.getRow(i).getCell(serviceColIndex).toString().trim();
						if(data.equals(testCaseName)){
							row=i;
							break;
					}
				}
				return row;
			}
		  public int getRowEndCnt(String sheetName,String colName,String tcCntName) throws Exception{
				int colCnt=getRowStartingCnt(sheetName, colName, tcCntName);
				System.out.println("colCnt:"+colCnt);
				 XSSFSheet wshTemp = fnGetSheet(sheetName);
				 int icol=wshTemp.getLastRowNum();
				 for(int i=colCnt;i<icol;i++){
					 int webSerNmelvlExc=getColumnHeaderIndex(colName, sheetName);
					 String data= wshTemp.getRow(i).getCell(webSerNmelvlExc).toString().trim();
						 if(data.startsWith(tcCntName)){
							colCnt=colCnt+1;
						 }
				 }
				 String data2= wshTemp.getRow(colCnt).getCell(3).toString().trim();
				 System.out.println("-------Data2:"+data2);
				return colCnt-1;
			}
		  
		  public int getRowStartCnt(String sheetName,String colName1,String colName2,String tcCntName1,String env) throws Exception{
				int colCnt1=getRowStartingCnt(sheetName, colName1, tcCntName1);
				System.out.println("colCnt:"+colCnt1);
				int colCnt2=getRowStartingCnt(sheetName, colName2, env);
				System.out.println("colCnt:"+colCnt1);
				 XSSFSheet wshTemp = fnGetSheet(sheetName);
				 int icol=wshTemp.getLastRowNum();
				 for(int i=colCnt1;i<icol;i++){
					 int webSerNmelvlExc=getColumnHeaderIndex(colName1, sheetName);
					 int envir=getColumnHeaderIndex(colName2, sheetName);
					 String data= wshTemp.getRow(i).getCell(webSerNmelvlExc).toString().trim();
						 if(data.startsWith(tcCntName1)&&data.startsWith(env)){
							colCnt1=colCnt1+1;
						 }
				 }
				 String data2= wshTemp.getRow(colCnt1).getCell(3).toString().trim();
				 System.out.println("-------Data2:"+data2);
				return colCnt1;
			}
		  
		  public int getRowStartingCnt(String sheetName,String colName,String tcCntName) throws Exception{
				int colCnt=0;
				XSSFSheet wshTemp = fnGetSheet(sheetName);
				 int icol=wshTemp.getRow(0).getLastCellNum();
				 for(int i=0;i<icol;i++){
					 int webSerNmelvlExc=getColumnHeaderIndex(colName, sheetName);
					 String data= wshTemp.getRow(i).getCell(webSerNmelvlExc).toString().trim();
					 System.out.println("Data:"+data);
						 if(data.startsWith(tcCntName)){
							 String data2= wshTemp.getRow(i).getCell(3).toString().trim();
							 System.out.println("Data1:"+data2);
							colCnt=i;
							return colCnt;
						 }
				 }
				return colCnt;
			}
		  /**
			 * Get test case Column count
			 * @param filePath
			 * 				Enter file Path
			 * @return
			 * 	Returns Column count
			 * @throws Exception
			 */
			public  int getColumnHeaderIndexForDriver(String columneName,String sheetName) throws Exception{
				     int col=0;
				     XSSFSheet wshTemp = wb.getSheet(sheetName);
						int cc=wshTemp.getRow(0).getLastCellNum();
						for (int i = 0; i < cc; i++) {
							String data= wshTemp.getRow(0).getCell(i).toString().trim();
								if(data.equals(columneName)){
									col=i;
							}
						}
						return col;
				}
		  /**
			 * Get test case Row count
			 * @param filePath
			 * 				Enter file Path
			 * @return
			 * 	Returns Row count
			 * @throws Exception
			 */
			public  int getTestCaseRowIndex(String webServiceOperation,String sheetName) throws Exception{
				     int row=0;
				     XSSFSheet wshTemp = wb.getSheet(sheetName);
				     int serviceColIndex=getColumnHeaderIndexForDriver(tcCountName,sheetName);
						int rc=wshTemp.getLastRowNum();
						for (int i = 1; i < rc+1; i++) {
							String data= wshTemp.getRow(i).getCell(serviceColIndex).toString().trim();
								if(data.equals(webServiceOperation)){
									row=i;
									break;
							}
						}
						return row;
					}
			
			public  int getTestCaseRowIndexLatestFramework(String webServiceOperation,String sheetName) throws Exception{
			     int row=0;
			     XSSFSheet wshTemp = wb.getSheet(sheetName);
			     int serviceColIndex=getColumnHeaderIndexForDriver(tcCountName,sheetName);
					int rc=wshTemp.getLastRowNum();
					for (int i = 1; i < rc+1; i++) {
						String data= wshTemp.getRow(i).getCell(serviceColIndex).toString().toUpperCase().trim();
							if(data.equals(webServiceOperation)){
								row=i;
								break;
						}
					}
					return row;
				}
		  
			 public  void setValueIntoCell(String columnName, String WebserviceOperationName,String strData,String sheetName) throws Exception
			    {
				
				 String tempData=strData;
				 tempData=columnName+":"+tempData;
			    	int iRowNumber=getTestCaseRowIndex(WebserviceOperationName,sheetName);
			    	sheet = wb.getSheet(sheetName);
			    	int cc=sheet.getRow(0).getLastCellNum();
			    	row = sheet.getRow(iRowNumber);
			    	 int field1Cnt=getColumnHeaderIndex("Field1", sheetName);
			    	for (int i=field1Cnt;i<cc;i++){
			    		if(!strData.equals("")){
			    		XSSFRow row2 = sheet.getRow(iRowNumber);
			            XSSFCell    cell = row2.getCell(i);
			//    		Thread.sleep(1000);
			       try{
			    	if(cell == null||cell.equals(""))
					{
					cell = row2.createCell(i);
					Thread.sleep(1000);
					cell.setCellValue(tempData);
					break;
					}
			       }catch(Exception e){
			    	   if(cell == null||cell.equals(""))
						{
						cell = row2.createCell(i);
						Thread.sleep(1000);
						cell.setCellValue(tempData);
						break; 
			       }
			       }
			    	
			    		}
			    	
			    	}
			    	String tempUpdatePath=getFilePath();
			    	System.out.println("Temp destinantion path used:"+tempUpdatePath);
			    	file.close();
			    	FileOutputStream fileOut = new FileOutputStream(tempUpdatePath);
			        wb.write(fileOut);
			        fileOut.close();
			    	
			   }
			 
			 public  void setValueIntoCellWithItems(String WebserviceOperationName,String strData,String sheetName) throws Exception
			    {
				String tempData[];
				int incr=0;
				 int field1Cnt=getColumnHeaderIndex("Field1", sheetName);
				  tempData=strData.split("_");
				  for(int k=0;k<tempData.length;k++){
			    	int iRowNumber=getTestCaseRowIndex(WebserviceOperationName,sheetName);
			    	sheet = wb.getSheet(sheetName);
			    	int cc=sheet.getRow(0).getLastCellNum();
			    	row = sheet.getRow(iRowNumber);
			    	
			    	for (int i=field1Cnt;i<cc;i++){
			    		if(!strData.equals("")){
			    		XSSFRow row2 = sheet.getRow(iRowNumber);
			            XSSFCell    cell = row2.getCell(field1Cnt);
			    	if(cell == null)
					{
					cell = row2.createCell(field1Cnt);
					cell.setCellValue(tempData[incr]);
					incr=incr+1;
					field1Cnt=field1Cnt+1;
					break;
					}else{
						cell.setCellValue(tempData[incr]);
						incr=incr+1;
						field1Cnt=field1Cnt+1;
						break;
					}
			    		}
			    	
			    	}
				  }
//			    	String tempUpdatePath=getFilePath();
				  String tempUpdatePath=VariableDeclaration.orgFilePathMaster;
//			    	System.out.println("Temp destinantion path used:"+tempUpdatePath);
			    	file.close();
			    	FileOutputStream fileOut = new FileOutputStream(tempUpdatePath);
			        wb.write(fileOut);
			        fileOut.close();
			    	
			   }
			 
			 public  void setValueIntoCellWithItemsLatestAllValid(String WebserviceOperationName,String strData,String sheetName) throws Exception
			    {
				String tempData[];
				int incr=0;
				 int field1Cnt=getColumnHeaderIndex("Field1", sheetName);
				  tempData=strData.split("->");
				  for(int k=0;k<tempData.length;k++){
			    	int iRowNumber=getTestCaseRowIndexLatestFramework(WebserviceOperationName,sheetName);
			    	sheet = wb.getSheet(sheetName);
			    	int cc=sheet.getRow(0).getLastCellNum();
			    	row = sheet.getRow(iRowNumber);
			    	
			    	for (int i=field1Cnt;i<cc;i++){
			    		if(!strData.equals("")){
			    		XSSFRow row2 = sheet.getRow(iRowNumber);
			            XSSFCell    cell = row2.getCell(field1Cnt);
			    	if(cell == null)
					{
					cell = row2.createCell(field1Cnt);
					cell.setCellValue(tempData[incr]);
					incr=incr+1;
					field1Cnt=field1Cnt+1;
					break;
					}else{
						cell.setCellValue(tempData[incr]);
						incr=incr+1;
						field1Cnt=field1Cnt+1;
						break;
					}
			    		}
			    	
			    	}
				  }
//			    	String tempUpdatePath=getFilePath();
				  String tempUpdatePath=VariableDeclaration.orgFilePathMaster;
//			    	System.out.println("Temp destinantion path used:"+tempUpdatePath);
			    	file.close();
			    	FileOutputStream fileOut = new FileOutputStream(tempUpdatePath);
			        wb.write(fileOut);
			        fileOut.flush();
			        fileOut.close();
			        
			    	
			   }
			 
			 
			 public  void setValueIntoCellWithItemsLatestInValid(String WebserviceOperationName,String strData,String sheetName,int rowNum) throws Exception
			    {
					String tempData[];
					int incr=0;
					 int field1Cnt=getColumnHeaderIndex("Field1", sheetName);
					  tempData=strData.split("->");
					  for(int k=0;k<tempData.length;k++){
				  //  	int iRowNumber=getTestCaseRowIndexLatestFramework(WebserviceOperationName,sheetName);
						int iRowNumber = rowNum;
				    	sheet = wb.getSheet(sheetName);
				    	int cc=sheet.getRow(0).getLastCellNum();
				    	row = sheet.getRow(iRowNumber);
				    	
				    	for (int i=field1Cnt;i<cc;i++){
				    		if(!strData.equals("")){
				    		XSSFRow row2 = sheet.getRow(iRowNumber);
				            XSSFCell    cell = row2.getCell(field1Cnt);
				    	if(cell == null)
						{
						cell = row2.createCell(field1Cnt);
						cell.setCellValue(tempData[incr]);
						incr=incr+1;
						field1Cnt=field1Cnt+1;
						break;
						}else{
							cell.setCellValue(tempData[incr]);
							incr=incr+1;
							field1Cnt=field1Cnt+1;
							break;
						}
				    		}
				    	
				    	}
					  }
//				    	String tempUpdatePath=getFilePath();
					  String tempUpdatePath=VariableDeclaration.orgFilePathMaster;
//				    	System.out.println("Temp destinantion path used:"+tempUpdatePath);
				    	file.close();
				    	FileOutputStream fileOut = new FileOutputStream(tempUpdatePath);
				        wb.write(fileOut);
				        fileOut.flush();
				        fileOut.close();
				        
				    	
				   }
			 
			 public  String setValueIntoCell(String columnName, String strData,String sheetName,int iRowNumber) throws Exception
			    {
				 XSSFRow row2=null;
				 XSSFCell    cell=null;
				 int iColumnNumber=getColumnHeaderIndex(columnName,sheetName);
//			    	System.out.println("column indexs:"+iColumnNumber);
				 String temp=strData;
				 sheet = wb.getSheet(sheetName);
			    	row = sheet.getRow(iRowNumber);
			    		if(!strData.equals("")){
			    		row2 = sheet.getRow(iRowNumber);
			            cell = row2.getCell(iColumnNumber);
			            if(cell==null){
			            	cell = row2.createCell(iColumnNumber);
							cell.setCellValue(temp);
			            }else{
			            	 cell.setCellValue(temp);
			            }
			            }
			    	String tempUpdatePath=getFilePath();
			    	file.close();
			    	FileOutputStream fileOut = new FileOutputStream(tempUpdatePath);
			        wb.write(fileOut);
			        fileOut.close();
			    	
			        return temp;
			    }
			 
			 public  String setValueIntoCellWithColour(int columnName, String strData,String sheetName,int iRowNumber,boolean x,String colour) throws Exception
			    {
				 XSSFRow row2=null;
				 XSSFCell    cell=null;
				 int iColumnNumber= columnName; 
//			     System.out.println("column indexs:"+iColumnNumber);
				 String temp=strData;
				 sheet = wb.getSheet(sheetName);
			    	row = sheet.getRow(iRowNumber);
			    		if(!strData.equals("")){
			    		row2 = sheet.getRow(iRowNumber);
			    		if(row2==null)
			    		{
			    			row2 = sheet.createRow(iRowNumber);
			    		}
			            cell = row2.getCell(iColumnNumber);
			            if(cell==null){
			            	cell = row2.createCell(iColumnNumber);
			            	cell.setCellValue(temp);
			            	if(strData.contains(VariableDeclaration.NoDataFound)){
			            		cell.setCellStyle(setCoulorCode(x,"yellow"));
			            	}else if(strData.equals(VariableDeclaration.StatusNotcompleted)){
			            		cell.setCellStyle(setCoulorCode(x,colour));
			            	}else{
			            	cell.setCellStyle(setCoulorCode(x,colour));
			            	}
			            }else{
			            	cell.setCellValue(temp);
			            	if(strData.contains(VariableDeclaration.NoDataFound)){
			            		cell.setCellStyle(setCoulorCode(x,"yellow"));
			            	}else{
			            	cell.setCellStyle(setCoulorCode(x,colour));
			            	}
			    		}
			    		}
			    		if(strData.equals("PASS")||strData.equals("FAIL")){
			    		createHyperLink(strData,sheetName,iRowNumber);
			    		}
			    		
			        return temp;
			    }
			 
				public void updateTestResult() throws IOException{
					
			    	String tempUpdatePath=getFilePath();
			    	file.close();
			    	FileOutputStream fileOut = new FileOutputStream(tempUpdatePath);
			        wb.write(fileOut);
			        fileOut.flush();
			        fileOut.close();
				}
				
			public void createHyperLink(String strData,String sheetName,int iRowNumber) throws Exception{
				 XSSFRow row=null;
				 XSSFRow row1=null;
				 XSSFCell    cell=null;
				 XSSFSheet sheet1;
				 String dte = new SimpleDateFormat("yyyyMMdd").format(new Date());
				 int iColTestSuitno=getColumnHeaderIndex("WebServiceName",sheetName);
				 int iColumnNumber=getColumnHeaderIndex("LINK",sheetName);
				 int iColTestCaseName=getColumnHeaderIndex("TestCaseName",sheetName);
				 int iColEnvName=getColumnHeaderIndex("Environment",sheetName);
				 int iColFieldName=getColumnHeaderIndex("FieldName",sheetName);
				 int iColTcId=getColumnHeaderIndex("TC_ID",sheetName);
				 row = sheet.getRow(iRowNumber);
				 tcIdName = row.getCell(iColTcId).getStringCellValue();
				 System.out.println(tcIdName);
				 int iColDescriptionName=getColumnHeaderIndex("TestDescription",VariableDeclaration.dataSheetDriver);
				 sheet1 = wb.getSheet(VariableDeclaration.dataSheetDriver);
				 int getRowCnt=getRowIndex(tcIdName, VariableDeclaration.dataSheetDriver, "TC_ID");
				 row1 = sheet1.getRow(getRowCnt);
				 String DriverDescriptData = row1.getCell(iColDescriptionName).getStringCellValue();
				 System.out.println("DriverDescriptData:"+DriverDescriptData);
				 String iColTestSuitname = row.getCell(iColTestSuitno).getStringCellValue();
				envName=row.getCell(iColEnvName).getStringCellValue().replaceAll("\\s", "");
		            testCaseName = row.getCell(iColTestCaseName).getStringCellValue();
		            fieldName = row.getCell(iColFieldName).getStringCellValue();
		            if(!DriverDescriptData.contains("Invalid")){
//		            String screenPath=VariableDeclaration.screenShotPath+"\\"+testCaseName+"_"+fieldName+".jpg";
		            	VariableDeclaration.htmlscreenPath1=VariableDeclaration.screenShotPath+"//"+envName+"_"+testCaseName+"_"+fieldName+".jpg";
		            	VariableDeclaration.htmlWSResponsePath="C://ConsolidatedWebservices//Result//WebServiceResponse//"+dte+"//"+ VariableDeclaration.getTieStamp+"//"+iColTestSuitname+"_"+testCaseName+"_"+tcIdName+"_"+ "Response" +".json";
		            System.out.println("screenPath:"+VariableDeclaration.htmlscreenPath1);
				    CreationHelper createHelper = wb.getCreationHelper();
				    System.out.println("found");

				    //cell style for hyperlinks
				    //by default hyperlinks are blue and underlined
				    CellStyle hlink_style = wb.createCellStyle();
				    XSSFFont hlink_font = wb.createFont();
				    hlink_font.setUnderline(Font.U_SINGLE);
				    if(strData.equals("PASS")){
				    hlink_font.setColor(IndexedColors.BLUE.getIndex());
				    }else{
				    	 hlink_font.setColor(IndexedColors.RED.getIndex());
				    }
				    hlink_style.setFont(hlink_font);
				    try{
				    	VariableDeclaration.htmlxmlvalue= saveXmltoString(VariableDeclaration.htmlWSResponsePath);
					    createHtmlReport();
					    System.out.println("xmlvalue:"+VariableDeclaration.htmlxmlvalue);
				    	}catch(Exception e)
				    		{
				    		e.printStackTrace();
				    		}
				    //URL
					 sheet = wb.getSheet(sheetName);
					 
				    Hyperlink link = createHelper.createHyperlink(Hyperlink.LINK_FILE);
				    link.setAddress(VariableDeclaration.htmlreportPath);
				    
				    
				    if(!strData.equals("")){
			    		row = sheet.getRow(iRowNumber);
			            cell = row.getCell(iColumnNumber);
			            if(cell==null){
			            	cell = row.createCell(iColumnNumber);
			            	 cell.setHyperlink((XSSFHyperlink)link);
							    cell.setCellStyle(hlink_style);
			            	cell.setCellValue(fieldName);
			            }else{
			            	 cell.setHyperlink((XSSFHyperlink)link);
							    cell.setCellStyle(hlink_style);
			            	cell.setCellValue(fieldName);
			    		}
			    		}
				    VariableDeclaration.htmlreportPath="";
		            }
			 }
			 public XSSFCellStyle  setCoulorCode(boolean x,String colour){
				
				 if(style == null)
				 {
					 style = wb.createCellStyle();
					 				 
					 stylexFalse = wb.createCellStyle();
					 my_font=wb.createFont();
					 my_font.setFontName("Times New Roman"); 
				//	 my_font.setColor(XSSFColor.BLACK.index);
					 my_font.setColor(IndexedColors.BLACK.getIndex());
					 
					 
					 stylexFalse.setFont(my_font);
		             stylexFalse.setFont(my_font);
		             stylexFalse.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		             stylexFalse.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		             stylexFalse.setBorderTop(XSSFCellStyle.BORDER_THIN);
		             stylexFalse.setBorderRight(XSSFCellStyle.BORDER_THIN);
		             stylexFalse.setBorderLeft(XSSFCellStyle.BORDER_THIN);
					 stylexFalse.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
					 
					 styleGreen = wb.createCellStyle();
					 my_font=wb.createFont();
					 my_font.setFontName("Times New Roman"); 
				//	 my_font.setColor(XSSFColor.BLACK.index);
					 my_font.setColor(IndexedColors.BLACK.getIndex());
					 
					 styleGreen.setFont(my_font);
					 styleGreen.setFont(my_font);
					 styleGreen.setAlignment(XSSFCellStyle.ALIGN_CENTER);
					 styleGreen.setBorderBottom(XSSFCellStyle.BORDER_THIN);
					 styleGreen.setBorderTop(XSSFCellStyle.BORDER_THIN);
					 styleGreen.setBorderRight(XSSFCellStyle.BORDER_THIN);
					 styleGreen.setBorderLeft(XSSFCellStyle.BORDER_THIN);
					 styleGreen.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
					 
					 styleRed = wb.createCellStyle();
					 my_font=wb.createFont();
					 my_font.setFontName("Times New Roman"); 
					 
					 styleRed.setFont(my_font);
					 styleRed.setFont(my_font);
					 styleRed.setAlignment(XSSFCellStyle.ALIGN_CENTER);
					 styleRed.setBorderBottom(XSSFCellStyle.BORDER_THIN);
					 styleRed.setBorderTop(XSSFCellStyle.BORDER_THIN);
					 styleRed.setBorderRight(XSSFCellStyle.BORDER_THIN);
					 styleRed.setBorderLeft(XSSFCellStyle.BORDER_THIN);
					 styleRed.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
					 
					 styleYellow = wb.createCellStyle();
					 my_font=wb.createFont();
					 my_font.setFontName("Times New Roman"); 
				//	 my_font.setColor(XSSFColor.BLACK.index);
					 my_font.setColor(IndexedColors.BLACK.getIndex());
					 
					 styleYellow.setFont(my_font);
					 styleYellow.setFont(my_font);
					 styleYellow.setAlignment(XSSFCellStyle.ALIGN_CENTER);
					 styleYellow.setBorderBottom(XSSFCellStyle.BORDER_THIN);
					 styleYellow.setBorderTop(XSSFCellStyle.BORDER_THIN);
					 styleYellow.setBorderRight(XSSFCellStyle.BORDER_THIN);
					 styleYellow.setBorderLeft(XSSFCellStyle.BORDER_THIN);
					 styleYellow.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
					 
					 
					 stylexTrue = wb.createCellStyle();
					 my_font=wb.createFont();
					 my_font.setFontName("Times New Roman"); 
				//	 my_font.setColor(XSSFColor.BLACK.index);
					 my_font.setColor(IndexedColors.BLACK.getIndex());
					 
					 stylexTrue.setFont(my_font);
					 stylexTrue.setFont(my_font);
					 stylexTrue.setAlignment(XSSFCellStyle.ALIGN_CENTER);
					 stylexTrue.setBorderBottom(XSSFCellStyle.BORDER_THIN);
					 stylexTrue.setBorderTop(XSSFCellStyle.BORDER_THIN);
					 stylexTrue.setBorderRight(XSSFCellStyle.BORDER_THIN);
					 stylexTrue.setBorderLeft(XSSFCellStyle.BORDER_THIN);
					 stylexTrue.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
					 
					 if(x==false)
					 {
						// stylexFalse.setFillForegroundColor(XSSFColor.GREY_25_PERCENT.getIndex);
						 stylexFalse.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
						 
		            	if(colour.equals("green")){
		            		
		            		styleGreen.setFillForegroundColor(IndexedColors.GREEN.getIndex());
		            		return style = styleGreen;
		            		}
		            	else if(colour.equals("red")){
		            		
		            		styleRed.setFillForegroundColor(IndexedColors.RED.getIndex());
		            		my_font.setColor(IndexedColors.INDIGO.getIndex());
		            		styleRed.setFont(my_font);
		            		return style = styleRed;
		            		}
		            	else if(colour.equals("yellow")){

		            		styleYellow.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
		            		
		            		return style = styleYellow;
		            		
		            	}
		            	 return style = stylexFalse;
			 
					 }else if(x==true)
					 {
						 stylexTrue.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex()); 
						 
						 if(colour.equals("green")){
			            		
			            		styleGreen.setFillForegroundColor(IndexedColors.GREEN.getIndex());
			            		return style = styleGreen;
			            		}
			            	else if(colour.equals("red")){
			            		
			            		styleRed.setFillForegroundColor(IndexedColors.RED.getIndex());
			            		my_font.setColor(IndexedColors.INDIGO.getIndex());
			            		styleRed.setFont(my_font);
			            		return style = styleRed;
			            		}
			            	else if(colour.equals("yellow")){

			            		styleYellow.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
			            		
			            		return style = styleYellow;
			            		
			            	}
		            	 return style = stylexTrue;
					 }
					
				 }else
				 {
					 if(x==false)
					 {
						 stylexFalse.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex()); 						 
						 if(colour.equals("green")){
			            		
			            		styleGreen.setFillForegroundColor(IndexedColors.GREEN.getIndex());
			            		return style = styleGreen;
			            		}
			            	else if(colour.equals("red")){
			            		
			            		styleRed.setFillForegroundColor(IndexedColors.RED.getIndex());
			            		my_font.setColor(IndexedColors.INDIGO.getIndex());
			            		styleRed.setFont(my_font);
			            		return style = styleRed;
			            		}
			            	else if(colour.equals("yellow")){

			            		styleYellow.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
			            		
			            		return style = styleYellow;
			            		
			            	}
		            	 return style = stylexFalse;
					 }else if(x==true)
					 {
						 stylexTrue.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.index);
						 						 
						 if(colour.equals("green")){
			            		
			            		styleGreen.setFillForegroundColor(IndexedColors.GREEN.getIndex());
			            		return style = styleGreen;
			            		}
			            	else if(colour.equals("red")){
			            		
			            		styleRed.setFillForegroundColor(IndexedColors.RED.getIndex());
			            		my_font.setColor(IndexedColors.INDIGO.getIndex());
			            		styleRed.setFont(my_font);
			            		return style = styleRed;
			            		}
			            	else if(colour.equals("yellow")){

			            		styleYellow.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
			            		
			            		return style = styleYellow;
			            		
			            	}
		            	 return style = stylexTrue;
					 }
				 }
				 return style;
			 }
					 
			 /**
				 * Get test case Row count
				 * @param filePath
				 * 				Enter file Path
				 * @return
				 * 	Returns Row count
				 * @throws Exception
				 */
				public  int getTestCaseRowIndexForDriver(String webServiceOperation,String sheetName) throws Exception{
					     int row=0;
					     XSSFSheet wshTemp = wb.getSheet(sheetName);
					     int serviceColIndex=getColumnHeaderIndexForDriver(tcCountName,sheetName);
							int rc=wshTemp.getLastRowNum();
							for (int i = 1; i <= rc; i++) {
								String data= wshTemp.getRow(i).getCell(serviceColIndex).toString().trim();
									if(data.equals(webServiceOperation)){
										row=i;
										break;
								}
							}
							return row;
						}
				

				
				public  int getTestCaseRowIndexForDriverforTDM(String webServiceOperation,String envName,String sheetName) throws Exception{
				     int row=0;
				     XSSFSheet wshTemp = wb.getSheet(sheetName);
				     int serviceColIndex=getColumnHeaderIndexForDriver("TestCaseName",sheetName);
				     int EnvColIndex=getColumnHeaderIndexForDriver(EnvName,sheetName);
						int rc=wshTemp.getLastRowNum();
						for (int i = 1; i <= rc; i++) {
							String data= wshTemp.getRow(i).getCell(serviceColIndex).toString().trim();
							String data1= wshTemp.getRow(i).getCell(EnvColIndex).toString().toUpperCase().trim();
								if(data.equals(webServiceOperation) && data1.equals(envName)){
									row=i;
									break;
							}
						}
						return row;
					}
				
				public  int getRowIndexForExcel(String webServiceOperation,String envName,String sheetName) throws Exception{
				     int row=0;
				     XSSFSheet wshTemp = wb.getSheet(sheetName);
				     int serviceColIndex=getColumnHeaderIndexForDriver("WebServiceName",sheetName);
				     int EnvColIndex=getColumnHeaderIndexForDriver(EnvName,sheetName);
				int rc=wshTemp.getLastRowNum();
				for (int i = 1; i <= rc; i++) {
				String data= wshTemp.getRow(i).getCell(serviceColIndex).toString().trim();
				String data1= wshTemp.getRow(i).getCell(EnvColIndex).toString().toUpperCase().trim();
				if(data.equals(webServiceOperation) && data1.equals(envName)){
				row=i;
				break;
				}
				}
				return row;
				}
				
				
				public  int getTestCaseRowIndexForExcel(String webServiceOperation,String envName,String sheetName) throws Exception{
				     int row=0;
				     XSSFSheet wshTemp = wb.getSheet(sheetName);
				     int serviceColIndex=getColumnHeaderIndexForDriver(tcCountName,sheetName);
				     int EnvColIndex=getColumnHeaderIndexForDriver(EnvName,sheetName);
						int rc=wshTemp.getLastRowNum();
						for (int i = 1; i <= rc; i++) {
							String data= wshTemp.getRow(i).getCell(serviceColIndex).toString().trim().toUpperCase();
							String data1= wshTemp.getRow(i).getCell(EnvColIndex).toString().toUpperCase().trim();
								if(data.equals(webServiceOperation) && data1.equals(envName)){
									row=i;
									break;
							}
						}
						return row;
					}
				
			 /**
				 * Get Required data from excel sheet
				 * @param columnName
				 * 				Enter Field/Column Name
				 * @param WebserviceOperationName
				 * 				Enter WebserviceOperationName name to retrive data
				 * @param sheetName
				 * 				Enter sheet Name Name
				 * @return
				 * 	Returns cell data
				 * @throws Exception
				 */
				  public  String fngetInputTestDataField(String columnName, String tcName,String sheetName) throws Exception
				    {
					  String[] tempData;
					  	String cellData="";
				    	int iRowNumber=getTestCaseRowIndexForDriver(tcName,sheetName);
				    	System.out.println("testcase row count:"+iRowNumber);
				    	XSSFSheet wshTemp = wb.getSheet(sheetName);
				    	int cc=wshTemp.getRow(0).getLastCellNum();
				    	for (int i=0;i<cc;i++){
				    	String data= wshTemp.getRow(iRowNumber).getCell(i).toString().trim();
						if(data.contains(columnName)){
							tempData=data.split(":");
							cellData=tempData[1];
							break;
						}
				    	}
						return cellData;
				    }
				  
				  public  String fngetInputTestDataFieldfromTDM(String columnName,String envName, String tcName,String sheetName) throws Exception
				    {
					  
					  String[] tempData;
					  	String cellData="";
				    	int iRowNumber=getTestCaseRowIndexForDriverforTDM(tcName,envName,sheetName);

				    	System.out.println("testcase row count:"+iRowNumber);
				    	XSSFSheet wshTemp = wb.getSheet(sheetName);
				    	int cc=wshTemp.getRow(0).getLastCellNum();
				    	for (int i=0;i<cc;i++){
				    	String data= wshTemp.getRow(iRowNumber).getCell(i).toString().toUpperCase().trim();
							tempData=data.split(":");

							if(tempData.length == 2)
					    	{
					    		if(tempData[0].toString().equals(columnName))
					    		{
					    			cellData=tempData[1];
									break;
					    		}
					    	}else
					    	{
					    	if(tempData.length == 3)
					    	{
					    		if(tempData[1].toString().equals(columnName))
					    		{
					    			cellData=tempData[2];
									break;
					    		}
					    	}
					    	}
					    }
					    	return cellData;
					    }
				  
				  
				  
				  
				  public String Retrivevaluefromjson(String columnName,String envName, String tcName,String sheetName) throws Exception
                  {


                         
                         String[] tempData;
                              String cellData="";String data="failedtofetch";
                       //RxLink code
                              XSSFSheet wshTemp = wb.getSheet(sheetName);
                              System.out.println(columnName+envName+tcName+sheetName);
                              
                              if(sheetName.equals("TDM"))
                              {  //need to add
                                     //with casesid i need to get service name
                                     int iRowNumber=getRowIndexForExcel(tcName,envName,sheetName);
                                     int reqdetTDM=getColumnHeaderIndex("Field1", sheetName);
                                       data= wshTemp.getRow(iRowNumber).getCell(reqdetTDM).toString().trim();
                                     System.out.println("TDM"+iRowNumber+":"+reqdetTDM+":"+data);
                              }else if(sheetName.equals("WebServicesResponseData"))
                              {
                                     int iRowN2=getTestCaseRowIndexForExcel(tcName,envName,sheetName);
                                     int reqdetresp=getColumnHeaderIndex("CompleteResponse", sheetName);
                                       data= wshTemp.getRow(iRowN2).getCell(reqdetresp).toString().trim();
                                     System.out.println("WS"+iRowN2+":"+reqdetresp+":"+data);
                              }
                              
                         
                              
                       /*   try{*/
                              //getting value from json
                              String inputtofind=data.toUpperCase();
                              String temp1="\""+columnName+"\"";
                               String[] temp4,temp3;
                               
                              String temp2[]=inputtofind.split(temp1);
                              temp3=temp2[1].split(",");
                              System.out.println("temp2[1]"+temp2[1]);
                              System.out.println("temp2[0]"+temp2[0]);
                              cellData=temp3[0].replaceAll("\"", "").trim();
                              cellData=cellData.replaceAll(":", "").trim();
                              System.out.println(cellData);
                              
                              
                         /* }catch(Exception e)
                          {
                                 System.out.println("Unable to read data from TDM and response sheet");
                          }*/
                              
                              return cellData;
                           
                  
}

				  
				  public  String fngetDatafromExcelSheet(String columnName,String envName, String tcName,String sheetName) throws Exception
				    {
					  
					  String[] tempData;
					  	String cellData="";
				    	int iRowNumber=getTestCaseRowIndexForExcel(tcName,envName,sheetName);

				    	System.out.println("testcase row count:"+iRowNumber);
				    	XSSFSheet wshTemp = wb.getSheet(sheetName);
				    	int cc=wshTemp.getRow(0).getLastCellNum();
				    	for (int i=0;i<cc;i++){
				    	String data= wshTemp.getRow(iRowNumber).getCell(i).toString().toUpperCase().trim();
							tempData=data.split("\\[|\\]|\\:|\\/|\\=");	

					    	if(tempData.length == 2)
					    	{
					    		if(tempData[0].toString().equals(columnName))
					    		{
					    			cellData=tempData[1];
									break;
					    		}
					    	}else
					    	{
					    	if(tempData.length == 3)
					    	{
					    		if(tempData[1].toString().equals(columnName))
					    		{
					    			cellData=tempData[2];
									break;
					    		}
					    	}
					    	}
					    }
					    	return cellData;
					    }


				  public  String fngetInputWebserviceDataField(String columnName, String tcName,String sheetName) throws Exception
				    {
					  String[] tempData;
					 
					  	String cellData="";
				    	int iRowNumber=getTestCaseRowIndexForDriver(tcName,sheetName);
				    	System.out.println("testcase row count:"+iRowNumber);
				    	XSSFSheet wshTemp = wb.getSheet(sheetName);
				    	int cc=wshTemp.getRow(0).getLastCellNum();
				    	for (int i=0;i<cc;i++){
				    	String data= wshTemp.getRow(iRowNumber).getCell(i).toString().trim();
						if(data.contains(columnName)){
							tempData=data.split("\\[|\\]|\\:|\\/|\\=");	
							
							if(tempData.length == 2)
							{
							cellData=tempData[1];
							break;
							}else
							{
								if(tempData.length == 3)
								{
									cellData=tempData[2];
									break;
								}
							}
							
						}
				    	}
						return cellData;
				    }
				  
				//*******
					 public  void createHtmlReport()
					 {						 
							try {
								
								String reportIn = new String(Files.readAllBytes(Paths.get(VariableDeclaration.templatePath)));
//								for (int i = 0; i < details.size();i++) {
//									reportIn = reportIn.replaceFirst(VariableDeclaration.resultPlaceholder,"<tr><td><xmp>"+WSResponsePath+ "</td><td>><img src="+screenPath1+" alt="+testCaseName+"_"+fieldName+" /></td> </tr>" VariableDeclaration.environmentSelected + VariableDeclaration.resultPlaceholder);
								reportIn = reportIn.replace(VariableDeclaration.testcasePlaceholder,testCaseName+"_"+tcIdName+"_"+fieldName);	
								reportIn = reportIn.replace(VariableDeclaration.resultPlaceholder,"<tr><td><xmp>"+VariableDeclaration.htmlxmlvalue+"</xmp></td><td><img src="+VariableDeclaration.htmlscreenPath1+" alt="+envName.toUpperCase()+"_"+testCaseName+"_"+fieldName+" /></td> </tr>");
//								}
								String dte = new SimpleDateFormat("yyyyMMdd").format(new Date());
								String filePath=VariableDeclaration.htmlfilepath+"//"+dte+"//"+VariableDeclaration.getTieStamp;
								File destinationFolder = new File(filePath);
							    if (!destinationFolder.exists()){
							        destinationFolder.mkdirs();
							    }
							    
//							    String	currentDatetime = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
//								VariableDeclaration.htmlreportPath = "C:/WebserviceAutomation/Report/HtmlReports/"+testCaseName+"_"+fieldName+".html";VariableDeclaration.tempEnvironmentToBeSet
								VariableDeclaration.htmlreportPath = "C://ConsolidatedWebservices//Result//Report//HtmlReports"+"//"+envName+"_"+testCaseName+"_"+fieldName+".html";
								Files.write(Paths.get(VariableDeclaration.htmlreportPath),reportIn.getBytes(),StandardOpenOption.CREATE);
								
								
							} catch (Exception e) {
								System.out.println("Error when writing report file:\n"+e.toString());
								e.printStackTrace();
							}
						}
					 
					 public static String saveXmltoString(String filename) {
//						 StringBuilder sb = new StringBuilder();
						 sb.setLength(0);
//						 sb.delete(0, sb.length());
						 
						 try{
							BufferedReader br1 = new BufferedReader(new FileReader(new File(filename)));
							String line="";
//							StringBuilder sb = new StringBuilder();
							
							while((line=br1.readLine())!= null){
								sb.append(line.trim()+"\n");
//							    StringEscapeUtils.unescapeXml(xmlvalue);
							}
							}catch(Exception e){e.printStackTrace();}
						
						return sb.toString();
						 }
					 //********
					 
		public void fnSetUpForWriteToExcelData1(){
			String tempUpdatePath=getFilePath();
			readExcel(tempUpdatePath);

		}
		
		public  void fnExcelCloseSheet()
	    {
    try {
    	wb.close();
    	file.close();
    	
	        } catch (Exception e){
	            e.printStackTrace();
	        }
	    }


}
