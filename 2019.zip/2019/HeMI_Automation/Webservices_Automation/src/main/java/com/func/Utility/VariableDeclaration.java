package com.func.Utility;

import org.apache.poi.common.usermodel.Hyperlink;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class VariableDeclaration {
	

	
	public void testMain(Object[] args) 
	{
//		System.out.println("file:"+destinationFile);
	}
	static commonFunctions com =new commonFunctions();
	static ExcelUtility erw=new ExcelUtility();
	
	public static final XSSFWorkbook wb=null;
	public static final WritableWorkbook copy=null;
	public static final WritableSheet copySheet=null;
	public static final String resultSheetPath = "";
	public static final String environment = "Environment";
	public static String environmentSelected = "";
	public static final String RxClaimUIRespnse = "RxClaimUIRespnse";
	public static final String col_testcaseExecution="TestcaseExecution";
	public static final String col_testCaseName="TestCaseName";
	public static final String col_testDescription="TestDescription";
	public static final String col_refreshData="RefreshData";
	public static final String col_envData="Environment";
	public static final String col_parentTagData="ParentTagName";
	public static final String col_webLvlExcData="WebServiceName Lavel Execution";
	public static final String DriverSheetBOOK1 ="TestDataDriver";
	public static final String DriverSheetBOOK2 ="TestDataDriver2";
	public static final String dataSheetDriver="TestDataDriver";
	public static final String TDMSheetDriver="TDM";
	public static final String PASResponseSheet="PASResponseData";
	public static  String tempEnvironmentToBeSet="";
	public static final String testCaseName = "TestCaseName";
	public static final String WebServicesResponseData = "WebServicesResponseData";
	public static final String PropertySheet = "PropertySheet";
	public static final String DBResultSheet = "DBResultSheet";
	public static final String webServiceName="WebServiceName";
	public static final String resultSheet = "ResultSheet";
	public static final String tcCountName="TC_ID";
	public static final String envName="Environment";
	public static final String res_type="type";
	public static final String res_desc="longDescription";
	public static final String res_desc1="message";
	public static final String NoDataFound= "No Data Found";
	public static final String StatusNotcompleted="Not completed";
	public static String host="";
	public static final String hostBook1="APSI7061.uhc.com";
	public static final String hostBook3="apsi906e";
	public static final String hostBook2="apsi7062.uhc.com";
	
	public static final String hostBook1path="C:\\ConsolidatedWebservices\\LeanFTProject\\pcom\\BOOK1.ws";
	public static final String hostBook2path="C:\\ConsolidatedWebservices\\LeanFTProject\\pcom\\BOOK2.ws";
	public static final String hostsxcd1path="C:\\ConsolidatedWebservices\\LeanFTProject\\pcom\\SXCD1.ws";
	
	public static final String PASurl= "http://pasqa.uhc.com";
	public static final String PASuserName= "QA_STD_PATech";
	public static final String PASpassword= "Pasuser2";

	public static final String BK1userName= "d1018";
	public static final String BK2userName= "d1018";
	public static final String Book1password= "nov12018";
	public static final String Book2password= "Nov@2018";
	public static final String catamaran_password= "Nov@2018";
	public static final String catamaran_userName= "DSAT";
	
	// capture screen shot------
	public static int screenCnt=1;
	public static String testCaseNameForScreenShot="";
	public static String screenShotPath="";
	//html Report
	public  static String htmlscreenPath1="";
	public static String htmlreportPath="";
	public static   String htmltestCaseName="";
	public static  String htmlfieldName="";
	public static  String htmlWSResponsePath="";
	public static String htmlscreenPath2="";
	public	static String htmlxmlvalue="";
	public static String htmlto="";
	public static Hyperlink htmllink;
	public static String tcIdName ="";
	public static final String resultPlaceholder = "<!-- INSERT_RESULTS -->";
	public static final String templatePath = "C://ConsolidatedWebservices//Result//Report//Report_Template.html";
	public static final String testcasePlaceholder ="<!--testcase-->";
	
	public static final String screenPath="C://ConsolidatedWebservices//Result//RxClaimScreen";
	public static final String getTieStamp=com.fnGetTimeRead();
	
	public static final String orgFilePathMaster="\\src\\test\\resources\\WebServiceAutomationData_Master.xlsx";
	public static final String destFilePath="\\ResultSheet\\WebServiceAutomationData_"+getTieStamp+".xlsx";
	public static final String testFileName="C:\\ConsolidatedWebservices\\testDataPath.txt";
	public static final String archiveDestFilePath="C:\\ConsolidatedWebservices\\Result\\ResultHistory";
	public static final String resultDestFilePath="C:\\ConsolidatedWebservices\\Result";
	public static final String htmlfilepath = "C://ConsolidatedWebservices//Result//Report//HtmlReports";
	
	
//	public static final String destinationFile=erw.fun_CreateAndGetNewDataSheet(orgFilePathMaster,destFilePath);
//	public static final String destinationFile2 = CommonFunction.getFilePath();
	


}
