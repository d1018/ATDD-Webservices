package com.test.Script;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import com.func.Utility.*;

public class SQLExecution extends commonFunctions{
	
	ExcelUtility erw=new ExcelUtility();
	commonFunctions com=new commonFunctions();
	
	public void testMain(Object[] args) throws SQLException 
	{

		Object environmentVar=args[1];
		Object testCaseName=args[2];
		Object testDescription=args[3];
		Object ParentTagName=args[4];
		Object refreshDataFlag=args[5];
		Object rowNum=args[6];
		Object counterValue = args[8];
		Object testCaseID=args[7];
		Object EnvVariable=args[9];
		int i = Integer.valueOf((String) rowNum);
		int c = Integer.valueOf((String) counterValue);
		
		XSSFSheet wshTemp;
		
		String DBResultSheet = VariableDeclaration.DBResultSheet;		
		String PropertySheet = VariableDeclaration.PropertySheet;
		String TDM =VariableDeclaration.TDMSheetDriver;
		String WebServicesResponseDataSheet = VariableDeclaration.WebServicesResponseData;
		VariableDeclaration.environmentSelected=environmentVar.toString();
		VariableDeclaration.tempEnvironmentToBeSet=erw.getEnvironmentToBeSet(environmentVar.toString().toUpperCase());
	 	System.out.println("environment:"+VariableDeclaration.tempEnvironmentToBeSet);
	 	VariableDeclaration.host=erw.getHostNameToBeSet(VariableDeclaration.tempEnvironmentToBeSet);
	 	System.out.println("host:"+VariableDeclaration.host);
	 	
	 	
		
	 	String fieldValue="";
		String finalValue = "";
		String tempAttributeData[];
		String navScreenName ="";
		String[] navigationArr;
		String[] SP_NameArr;
		String screenData ="";
		
		String SP_Name = "";
		String SPMappingName = "";
		String tempData[];
		Connection conn =null;
		ResultSet  rs =null;
		ArrayList <String> InputParam = new ArrayList<String>();
		ArrayList<String> existingTagCheck = new ArrayList<String>();
		try{
			
			erw.fnSetUpForMasterExcelData();

			 if((testDescription.toString().equals("all valid data"))&&(refreshDataFlag.toString().equalsIgnoreCase("YES")))
			 {
				 
			 wshTemp = erw.fnGetSheet(PropertySheet);
			 int pRow=wshTemp.getLastRowNum();
			 
			 try{
				 for(int p=0;p<=pRow;p++)
				 {
					 int field1Cnt=erw.getColumnHeaderIndex("Attribute1", PropertySheet);
					 int getpColCnt=wshTemp.getRow(p).getLastCellNum();
					 String HeaderTag= wshTemp.getRow(p).getCell(0).toString().toUpperCase().trim();
					 
					 if(ParentTagName.toString().equals(HeaderTag))
					 	{
						 try{
							 
							 String storedProceduretag= wshTemp.getRow(p).getCell(1).toString().toUpperCase().trim();
							 SP_NameArr = storedProceduretag.split(",");
							 System.out.println(SP_NameArr.length);
							 
							 for(int ns=0;ns<SP_NameArr.length;ns++)
							 {
								
								String parametertoPass ="";
								rs=null;
								
								 navigationArr = SP_NameArr[ns].toString().split("->");
								 SPMappingName = navigationArr[0].toString().trim();
								 SP_Name = navigationArr[1].toString().trim();
								 
								 conn = com.getMySqlConnection(); 
								 System.out.println("Connected to the database!!! Successful...");
								 Statement st = conn.createStatement();
								 DatabaseMetaData dbm = conn.getMetaData();
								 rs = dbm.getProcedureColumns("InetFormulary", "dbo", SP_Name,null);
								 
								 while (rs.next()){
									InputParam.add(rs.getString(4).replaceAll("[@/]",""));
								 	System.out.println(InputParam.toString());
								}
								 
								 wshTemp = erw.fnGetSheet(TDM);
								 
								 int iTDM=erw.getTestCaseRowIndexForExcel(testCaseID.toString(),environmentVar.toString(),TDM);
								 
								 int getColCnt=wshTemp.getRow(iTDM).getLastCellNum();
								 try
								 {
									 for(int ip=1;ip<InputParam.size();ip++)
									 {
										 int field1CntTDM=erw.getColumnHeaderIndex("Field1", TDM);
										 try
										 {
											 for(int j=field1CntTDM;j<getColCnt+1;j++){
												 
												 String valData= wshTemp.getRow(iTDM).getCell(j).toString().trim();
												 if(!valData.equals("")){
													 
													 tempData=valData.split(":");
													 if(InputParam.get(ip).toUpperCase().equals(tempData[0].toUpperCase()))
													 {
														 parametertoPass = parametertoPass + "'" + tempData[1] + "'"+",";
														 break;
													 }
													 
													 
												 }
												 
											 }
											 
										 }catch(Exception e){
											 
											 parametertoPass = parametertoPass + null +",";
											 
										 }
										 
									 }
								 }catch(Exception e){
									 System.out.println(e.getMessage());
								 }
								 
								 								 
								 if (parametertoPass.endsWith(",")) {
									 
									 parametertoPass = parametertoPass.substring(0, parametertoPass.length() - 1);
									}
								 
								 try
								 {
									 
										// get connection to SQL
									 
									 conn = com.getMySqlConnection(); 
									 wshTemp = erw.fnGetSheet(PropertySheet);
								 
									 CallableStatement cStmt = conn.prepareCall("{call " + SP_Name + "(" + parametertoPass + ")}");
									 

									 cStmt.executeQuery();
									 boolean results = cStmt.execute();
									 while(results)
								     	{	
							            	
							            	
							            	ResultSet finalResult = cStmt.getResultSet();
							            	ResultSetMetaData colu = finalResult.getMetaData();
							            	int colm = colu.getColumnCount();            	
							            	
							            	while(finalResult.next())
							            	{
							            		
							                	for(int v = 1;v<colm+1;v++)
							                	{
							                		String ColumnName = colu.getColumnName(v).replaceAll("[\\s_&/+$]", "");
							                		
							                	try{
												 	for(int j=field1Cnt;j<getpColCnt+1;j++)
												 	{
												 		String attributeName="";
												 		String propertySPName ="";
												 		String webservicesAttributeMapping = "";
												 		
												 		try
												 		{
												 			String attributeData = wshTemp.getRow(p).getCell(j).toString().trim();
												 			if(!attributeData.equals("")){
												 				tempAttributeData=attributeData.split("[:,/]");
												 				propertySPName = tempAttributeData[0].trim();
												 				attributeName = tempAttributeData[1].trim();
												 				webservicesAttributeMapping = tempAttributeData[2].trim();
												 				
												 				try{
																	 if(SPMappingName.equals(propertySPName))
																	 {
																		 if(attributeName.equals(ColumnName))
																		 {
																			 try{
																				 String tempVariable = finalResult.getString(v).toString().replaceAll("\\s+$", "");
																				 
																			 	if(tempVariable.matches("")||tempVariable==null)
																			 	{
																					 int occurrences = Collections.frequency(existingTagCheck, webservicesAttributeMapping);
																					 if(occurrences != 0)
																					 {
																							finalValue = (finalValue+webservicesAttributeMapping+ occurrences+":"+ "Blank" + "->");
																							existingTagCheck.add(webservicesAttributeMapping);
																					 }else
																					 {
																							finalValue = (finalValue+webservicesAttributeMapping+":"+ "Blank" + "->");
																							existingTagCheck.add(webservicesAttributeMapping);
																					 }
																			 	}else
																			 	{
																					 int occurrences = Collections.frequency(existingTagCheck, webservicesAttributeMapping);
																					 if(occurrences != 0)
																					 {
															                				finalValue = (finalValue+webservicesAttributeMapping+ occurrences+":"+finalResult.getString(v) +"->");
															                				existingTagCheck.add(webservicesAttributeMapping);
																					 }else
																					 {
															                				finalValue = (finalValue+webservicesAttributeMapping+":"+finalResult.getString(v) +"->");
															                				existingTagCheck.add(webservicesAttributeMapping);
																					 }
																			 	}
																				 
																				 break;
																				 
																				 
																			 }catch(Exception e){

																				 int occurrences = Collections.frequency(existingTagCheck, webservicesAttributeMapping);
																				 if(occurrences != 0)
																				 {
																						finalValue = (finalValue+webservicesAttributeMapping+ occurrences+":"+ "null" + "->");
																						existingTagCheck.add(webservicesAttributeMapping);
																				 }else
																				 {
																						finalValue = (finalValue+webservicesAttributeMapping+":"+ "null" + "->");
																						existingTagCheck.add(webservicesAttributeMapping);
																				 }
																				 break;
														           			 }
																		 }
																	 }
												 					
												 					
												 				}catch(Exception e){
											           				 System.out.println(e.getMessage());
											           			 }
												 			}
												 			
												 		}catch(Exception e){
									                		
															 try{
																 
																 String tempVariable = finalResult.getString(v).toString().replaceAll("\\s+$", "");
																 
															 	if(tempVariable.matches("")||tempVariable==null)
															 	{
																	 int occurrences = Collections.frequency(existingTagCheck, ColumnName);
																	 if(occurrences != 0)
																	 {
																			finalValue = (finalValue+ColumnName+ occurrences+":"+ "Blank" + "->");
																			existingTagCheck.add(ColumnName);
																	 }else
																	 {
																			finalValue = (finalValue+ColumnName+":"+ "Blank" + "->");
																			existingTagCheck.add(ColumnName);
																	 }
															 	}else
															 	{
																	 int occurrences = Collections.frequency(existingTagCheck, ColumnName);
																	 if(occurrences != 0)
																	 {
											                				finalValue = (finalValue+ColumnName+ occurrences+":"+finalResult.getString(v) +"->");
											                				existingTagCheck.add(ColumnName);
																	 }else
																	 {
											                				finalValue = (finalValue+ColumnName+":"+finalResult.getString(v) +"->");
											                				existingTagCheck.add(ColumnName);
																	 }
															 	}
																 
																 break;
																 
																 
															 }catch(Exception b){

																 int occurrences = Collections.frequency(existingTagCheck, ColumnName);
																 if(occurrences != 0)
																 {
																		finalValue = (finalValue+ColumnName+ occurrences+":"+ "null" + "->");
																		existingTagCheck.add(ColumnName);
																 }else
																 {
																		finalValue = (finalValue+ColumnName+":"+ "null" + "->");
																		existingTagCheck.add(ColumnName);
																 }
																 break;
										           			 }
									           			 }
												 		
												 	}
												 	
							                	}
							                	catch(Exception e){ System.out.println(e.getMessage());}
												 	
												 	
							                	
							                			                		
							                	}    
							            	}
							            	
							            	finalResult.close();
							             	//Check for the next Result Set
							             	
							             	results = cStmt.getMoreResults();
							            	
							            	
								 }
									 
								 cStmt.close();	 
								 System.out.println(finalValue.toString());
								 
										

									 
								 }catch(Exception e){
									 System.out.println(e.getMessage());
								 }
								 
								 
								 
							 }				 
							 
						 }catch(Exception e){
							 System.out.println(e.getMessage());
						 }
						 
					 	}
					 
				 }
				 
			 }catch(Exception e){
				 
				 rs.close();
				 conn.close();
			 }
			 finally{
				 
					// Update Result to Excel sheet
				 
				 screenData = "HTTPSTatus:200" +"->" + finalValue.toString().trim();
				// screenData = finalValue.toString().trim();
				 erw.setValueIntoCellWithItemsLatestAllValid(testCaseID.toString(),screenData,"DBResultSheet");
			 }
			 
		}else
				
			if((testDescription.toString().toUpperCase().equals("VALID DATA"))&&(refreshDataFlag.toString().toUpperCase().equalsIgnoreCase("YES")))
			 {
					//finalValue = "SuccessIndicator:1";
					
					//screenData = finalValue.toString().trim();
					//erw.setValueIntoCellWithItemsLatest(testCaseID.toString(),screenData,"RxClaimUIRespnse");
					

			 }else
			
				if((refreshDataFlag.toString().equalsIgnoreCase("YES")))
					{
					wshTemp = erw.fnGetSheet(WebServicesResponseDataSheet);
					//int getColCnt=wshTemp.getRow(i).getLastCellNum();
					int getColCnt=20;
					try{
						int field1Cnt=erw.getColumnHeaderIndex("Field1", WebServicesResponseDataSheet);
					 for(int j=field1Cnt;j<getColCnt;j++){
						 
						 String valData= wshTemp.getRow(i).getCell(j).toString().trim();
						 if(valData.contains("res")||valData.contains("HTTP"))
						 {
						 if(!valData.equals("")){
							
							 finalValue = finalValue+valData +"->";
						
						 }
						}
					 }										 
					 
				 }catch(Exception e){
					 System.out.println(e.getMessage());
				 }
					
					screenData = finalValue.toString().trim();
					 erw.setValueIntoCellWithItemsLatestInValid(testCaseID.toString(),screenData,"DBResultSheet",i);
					
					
			}	
			 
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
		
		// Close DB Connection and Excel workbook
			erw.fnExcelCloseSheet();
            

		}
		
		
	}
}
