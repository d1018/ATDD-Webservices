package com.func.Utility;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class UpdateResult {
	

	XSSFWorkbook wb = VariableDeclaration.wb;
	String testCaseCont=VariableDeclaration.tcCountName;
	String envCnt=VariableDeclaration.envName;
	static String driverSheet =VariableDeclaration.dataSheetDriver;
	static String testCaseName =VariableDeclaration.testCaseName;
	static String resultSheet=VariableDeclaration.resultSheet;
	String RxClaimUIRespnseSheet = VariableDeclaration.RxClaimUIRespnse;
	String DBResultSheet = VariableDeclaration.DBResultSheet;
	String WebServicesResponseDataSheet = VariableDeclaration.WebServicesResponseData;
	String webServiceName=VariableDeclaration.webServiceName;
	ExcelUtility erw=new ExcelUtility();
	String getWebServiceName="";
	String getEnvName="";
	String getTCCountName="";
	String gettcName="";
	String actualtag="";
	String actualtagList ="";
	
	String actual= "";
	String expVal= "";
	 String actualData="";
		String[] actualDataArr;
		 String exptedData="";
		 String[] exptedDataArr;
		 int colurcnt=0;
		 commonFunctions com= new commonFunctions();
		 
	public void testMain(Object[] args)
	
	{
		fnupdateResultWithData();
		
	}
	
	
	
	public void fnupdateResultWithData(){
		int serchCnt=0;
		int updateRowData=0;
		int updateRowData1=0;
		String tempData[];
		try{
		 com.fnMovePreviousExcutedFileToArchiveFolder(VariableDeclaration.archiveDestFilePath, VariableDeclaration.resultDestFilePath);
		
		 erw.fnSetUpForWriteToExcelData();
		 erw.fnSetUpForWriteToExcelData1();
		 XSSFSheet wshTemp = erw.fnGetSheet(driverSheet);
		 int irow=wshTemp.getLastRowNum();
		 try{
		 for(int i=1;i<=irow;i++){
			 
			 String[] actualtagArr;
			 String actualtagList ="";
			
			wshTemp = erw.fnGetSheet(driverSheet);
			 int lvlExcCnt=erw.getColumnHeaderIndex("WebServiceName Level Execution", driverSheet);
			 String WebLvlExc= wshTemp.getRow(i).getCell(lvlExcCnt).toString().toUpperCase().trim();
				 int testcaseExecutionCnt=erw.getColumnHeaderIndex("TestcaseExecution", driverSheet);
				 String testcaseExecutionName= wshTemp.getRow(i).getCell(testcaseExecutionCnt).toString().toUpperCase().trim();
				 if(WebLvlExc.equals("YES")&&testcaseExecutionName.equals("YES")){
					 colurcnt=colurcnt+1;
					 int envCnts=erw.getColumnHeaderIndex(envCnt, driverSheet);
					 getEnvName= wshTemp.getRow(i).getCell(envCnts).toString().trim();
					 int webServColCnt=erw.getColumnHeaderIndex("WebServiceName", driverSheet);
					 getWebServiceName= wshTemp.getRow(i).getCell(webServColCnt).toString().trim();
					 
					 int tcColCnt=erw.getColumnHeaderIndex(testCaseCont, driverSheet);
					 getTCCountName= wshTemp.getRow(i).getCell(tcColCnt).toString().trim();
					 int tcName=erw.getColumnHeaderIndex(testCaseName, driverSheet);
					 gettcName= wshTemp.getRow(i).getCell(tcName).toString().trim();
					 serchCnt=serchCnt+1;
					 
						 wshTemp = erw.fnGetSheet(RxClaimUIRespnseSheet);
						 int getColCnt=wshTemp.getRow(i).getLastCellNum();
						 boolean x=false;
						 String colour="GREY";
						 if(colurcnt%2==0){
							x=true; 
							colour="TURQUOISE";
						 }
						 try{
							 int field1Cnt=erw.getColumnHeaderIndex("Field1", RxClaimUIRespnseSheet);
						 for(int j=field1Cnt;j<getColCnt;j++){
							 
							 String valData= wshTemp.getRow(i).getCell(j).toString().trim();
							 if(!valData.equals("")){
								 tempData=valData.split(":");
								 
								 //write data in to CalculateResult Sheet
								 updateRowData=updateRowData+1;
								 String slNumer=Integer.toString(updateRowData);
								erw.setValueIntoCellWithColour(0,slNumer, resultSheet,updateRowData,x,colour);
								erw.setValueIntoCellWithColour(1,getEnvName, resultSheet,updateRowData,x,colour);
								erw.setValueIntoCellWithColour(3,getTCCountName, resultSheet,updateRowData,x,colour);
								erw.setValueIntoCellWithColour(2,getWebServiceName,resultSheet,updateRowData,x,colour);
								erw.setValueIntoCellWithColour(4,gettcName,resultSheet,updateRowData,x,colour);
								actualtag = erw.setValueIntoCellWithColour(5,tempData[0], resultSheet,updateRowData,x,colour);
								actualtagList=actualtagList+":"+actualtag;
								actual= erw.setValueIntoCellWithColour(7,tempData[1], resultSheet,updateRowData,x,colour);
								actualData=actualData+":"+actual;
								
							 }
					 }
						 }catch(Exception e){
							 System.out.println(e.getMessage());
						 }
						 
					//	 erw.updateTestResult();
						 
						 actualDataArr=actualData.split(":");
						 actualtagArr = actualtagList.split(":");
						 System.out.println(actualtagArr.length);
						 System.out.println(actualtagArr[0]);
						 
						 
						 wshTemp = erw.fnGetSheet(WebServicesResponseDataSheet);
						 getColCnt=wshTemp.getRow(i).getLastCellNum();
						 try{
							 for(int d=1;d<actualtagArr.length;d++)
							 {
															 
							 int field1Cnt=erw.getColumnHeaderIndex("Field1", WebServicesResponseDataSheet);
							 
							 try
							 {
							 for(int j=field1Cnt;j<getColCnt+1;j++){
							 
							 String valData= wshTemp.getRow(i).getCell(j).toString().trim();

							 if(!valData.equals("")){
								 tempData=valData.split(":");
								 //write data in to CalculateResult Sheet
								 
								 if(actualtagArr[d].toUpperCase().equals(tempData[0].toUpperCase()))
								 {
								 updateRowData1=updateRowData1+1;
								 try
								 {
								 if((tempData[1]  != null)){
									 
										expVal= erw.setValueIntoCellWithColour(6, tempData[1], resultSheet,updateRowData1,x,colour);
										exptedData=exptedData+":"+expVal;
									}
								 
								 }catch(Exception e){
									 
									 expVal= erw.setValueIntoCellWithColour(6, "No Data Found", resultSheet,updateRowData1,x,colour);
									 exptedData=exptedData+":"+expVal;
									 
								 }
								 break;
								 
								 }
									
								}										 							 
								 
							 }
							}catch(Exception e){
								
								updateRowData1=updateRowData1+1;
								 expVal= erw.setValueIntoCellWithColour(6, "No Tag Value", resultSheet,updateRowData1,x,colour);
								 exptedData=exptedData+":"+expVal;
								
							}
							 
							 
							 }  
					 						 
							 
						 }catch(Exception e){
							 System.out.println(e.getMessage());
						 }
						 
					//	 erw.updateTestResult();
						 
						 exptedDataArr=exptedData.split(":");
				 }
				 
				 
		 }
		 }catch(Exception e){
			 System.out.println(e.getMessage());
		 }
		 wshTemp = erw.fnGetSheet(resultSheet);
		 for(int i1=1;i1<=actualDataArr.length;i1++){
			 boolean x=false;
			 if(i1%2==0){
				x=true; 
			 }
			 if(actualDataArr[i1].trim().equals(exptedDataArr[i1].trim())){
//				 erw.setValueIntoCell("Status", "Pass", resultSheet,i1);
				 erw.setValueIntoCellWithColour(8, "PASS", resultSheet,i1,x,"green");
				 }else{
					 if(actualDataArr[i1].trim().contains("No Data Found")){
						 erw.setValueIntoCellWithColour(8, "Not completed", resultSheet,i1,x,"yellow");
					 }
					 else if(exptedDataArr[i1].trim().contains("No Tag Value"))
						 {
						 erw.setValueIntoCellWithColour(8, "Deffered", resultSheet,i1,x,"yellow");
						 }
					 else{
						 
//					 erw.setValueIntoCell("Status", "Fail", resultSheet,i1); 
					 erw.setValueIntoCellWithColour(8, "FAIL", resultSheet,i1,x,"red");
					 }
				 }
		 }
		 
		 
		}catch(Exception e){
			System.out.println(e.getMessage());
			System.out.println("hi");
		}finally{
		try{
			
			erw.updateTestResult();
		}catch(Exception e){
			e.getMessage();
		}
		}
	}
	
	public void fnupdateResultWithDataforAging(){
		int serchCnt=0;
		int updateRowData=0;
		int updateRowData1=0;
		String tempData[];
		try{
		 com.fnMovePreviousExcutedFileToArchiveFolder(VariableDeclaration.archiveDestFilePath, VariableDeclaration.resultDestFilePath);
		
		 erw.fnSetUpForWriteToExcelData();
		 erw.fnSetUpForWriteToExcelData1();
		 XSSFSheet wshTemp = erw.fnGetSheet(driverSheet);
		 int irow=wshTemp.getLastRowNum();
		 try{
		 for(int i=1;i<=irow;i++){
			 
			 String[] actualtagArr;
			 String actualtagList ="";
			
			wshTemp = erw.fnGetSheet(driverSheet);
			 int lvlExcCnt=erw.getColumnHeaderIndex("WebServiceName Level Execution", driverSheet);
			 String WebLvlExc= wshTemp.getRow(i).getCell(lvlExcCnt).toString().toUpperCase().trim();
				 int testcaseExecutionCnt=erw.getColumnHeaderIndex("TestcaseExecution", driverSheet);
				 String testcaseExecutionName= wshTemp.getRow(i).getCell(testcaseExecutionCnt).toString().toUpperCase().trim();
				 if(WebLvlExc.equals("YES")&&testcaseExecutionName.equals("YES")){
					 colurcnt=colurcnt+1;
					 int envCnts=erw.getColumnHeaderIndex(envCnt, driverSheet);
					 getEnvName= wshTemp.getRow(i).getCell(envCnts).toString().trim();
					 int webServColCnt=erw.getColumnHeaderIndex("WebServiceName", driverSheet);
					 getWebServiceName= wshTemp.getRow(i).getCell(webServColCnt).toString().trim();
					 
					 int tcColCnt=erw.getColumnHeaderIndex(testCaseCont, driverSheet);
					 getTCCountName= wshTemp.getRow(i).getCell(tcColCnt).toString().trim();
					 int tcName=erw.getColumnHeaderIndex(testCaseName, driverSheet);
					 gettcName= wshTemp.getRow(i).getCell(tcName).toString().trim();
					 serchCnt=serchCnt+1;
					 
						 wshTemp = erw.fnGetSheet(DBResultSheet);
						 int getColCnt=wshTemp.getRow(i).getLastCellNum();
						 boolean x=false;
						 String colour="GREY";
						 if(colurcnt%2==0){
							x=true; 
							colour="TURQUOISE";
						 }
						 try{
							 int field1Cnt=erw.getColumnHeaderIndex("Field1", DBResultSheet);
						 for(int j=field1Cnt;j<getColCnt;j++){
							 
							 String valData= wshTemp.getRow(i).getCell(j).toString().trim();
							 if(!valData.equals("")){
								 tempData=valData.split(":");
								 
								 //write data in to CalculateResult Sheet
								 updateRowData=updateRowData+1;
								 String slNumer=Integer.toString(updateRowData);
								erw.setValueIntoCellWithColour(0,slNumer, resultSheet,updateRowData,x,colour);
								erw.setValueIntoCellWithColour(1,getEnvName, resultSheet,updateRowData,x,colour);
								erw.setValueIntoCellWithColour(3,getTCCountName, resultSheet,updateRowData,x,colour);
								erw.setValueIntoCellWithColour(2,getWebServiceName,resultSheet,updateRowData,x,colour);
								erw.setValueIntoCellWithColour(4,gettcName,resultSheet,updateRowData,x,colour);
								actualtag = erw.setValueIntoCellWithColour(5,tempData[0], resultSheet,updateRowData,x,colour);
								actualtagList=actualtagList+":"+actualtag;
								actual= erw.setValueIntoCellWithColour(7,tempData[1], resultSheet,updateRowData,x,colour);
								actualData=actualData+":"+actual;
								
							 }
					 }
						 }catch(Exception e){
							 System.out.println(e.getMessage());
						 }
						 
					//	 erw.updateTestResult();
						 
						 actualDataArr=actualData.split(":");
						 actualtagArr = actualtagList.split(":");
						 System.out.println(actualtagArr.length);
						 System.out.println(actualtagArr[0]);
						 
						 
						 wshTemp = erw.fnGetSheet(WebServicesResponseDataSheet);
						 getColCnt=wshTemp.getRow(i).getLastCellNum();
						 try{
							 for(int d=1;d<actualtagArr.length;d++)
							 {
															 
							 int field1Cnt=erw.getColumnHeaderIndex("Field1", WebServicesResponseDataSheet);
							 
							 try
							 {
							 for(int j=field1Cnt;j<getColCnt+1;j++){
							 
							 String valData= wshTemp.getRow(i).getCell(j).toString().trim();

							 if(!valData.equals("")){
								 tempData=valData.split(":");
								 //write data in to CalculateResult Sheet
								 
								 if(actualtagArr[d].toUpperCase().equals(tempData[0].toUpperCase()))
								 {
								 updateRowData1=updateRowData1+1;
								 try
								 {
								 if((tempData[1]  != null)){
									 
										expVal= erw.setValueIntoCellWithColour(6, tempData[1], resultSheet,updateRowData1,x,colour);
										exptedData=exptedData+":"+expVal;
									}
								 
								 }catch(Exception e){
									 
									 expVal= erw.setValueIntoCellWithColour(6, "No Data Found", resultSheet,updateRowData1,x,colour);
									 exptedData=exptedData+":"+expVal;
									 
								 }
								 break;
								 
								 }
									
								}										 							 
								 
							 }
							}catch(Exception e){
								
								updateRowData1=updateRowData1+1;
								 expVal= erw.setValueIntoCellWithColour(6, "No Tag Value", resultSheet,updateRowData1,x,colour);
								 exptedData=exptedData+":"+expVal;
								
							}
							 
							 
							 }  
					 						 
							 
						 }catch(Exception e){
							 System.out.println(e.getMessage());
						 }
						 
					//	 erw.updateTestResult();
						 
						 exptedDataArr=exptedData.split(":");
				 }
				 
				 
		 }
		 }catch(Exception e){
			 System.out.println(e.getMessage());
		 }
		 wshTemp = erw.fnGetSheet(resultSheet);
		 for(int i1=1;i1<=actualDataArr.length;i1++){
			 boolean x=false;
			 if(i1%2==0){
				x=true; 
			 }
			 if(actualDataArr[i1].trim().equals(exptedDataArr[i1].trim())){
//				 erw.setValueIntoCell("Status", "Pass", resultSheet,i1);
				 erw.setValueIntoCellWithColour(8, "PASS", resultSheet,i1,x,"green");
				 }else{
					 if(actualDataArr[i1].trim().contains("No Data Found")){
						 erw.setValueIntoCellWithColour(8, "Not completed", resultSheet,i1,x,"yellow");
					 }
					 else if(exptedDataArr[i1].trim().contains("No Tag Value"))
						 {
						 erw.setValueIntoCellWithColour(8, "Deffered", resultSheet,i1,x,"yellow");
						 }
					 else{
						 
//					 erw.setValueIntoCell("Status", "Fail", resultSheet,i1); 
					 erw.setValueIntoCellWithColour(8, "FAIL", resultSheet,i1,x,"red");
					 }
				 }
		 }
		 
		 
		}catch(Exception e){
			System.out.println(e.getMessage());
			System.out.println("hi");
		}finally{
		try{
			
			erw.updateTestResult();
		}catch(Exception e){
			e.getMessage();
		}
		}
	}
	
	
		public static String getFilePath() throws IOException
			{
				String sCurrentLine ="";
				String temp="";
		

		BufferedReader br = null;

		try {

			br = new BufferedReader(new FileReader("C:/ConsolidatedWebservices/testDataPath.txt"));

			while ((sCurrentLine = br.readLine()) != null) {
				System.out.println(sCurrentLine);
				temp=sCurrentLine;
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		 
		finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
			
			
		}
		return temp;

	}

	
	
	

	
	
	

}
