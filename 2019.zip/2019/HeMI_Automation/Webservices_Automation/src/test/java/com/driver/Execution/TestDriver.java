package com.driver.Execution;



import java.util.concurrent.Executor;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.func.Utility.VariableDeclaration;
import com.func.Utility.*;
//import com.te.screenUtility.loginTerminal;
import com.test.Script.SQLExecution;
//import com.test.Script.executionScript;

public class TestDriver extends commonFunctions{
	
	//executionScript es =new executionScript();
//	loginTerminal le = new loginTerminal();
	
//	ExcelReadWite erw=new ExcelReadWite();
	
	static ExcelUtility erw=new ExcelUtility();	
	static UpdateResult upe= new UpdateResult();
	XSSFWorkbook wb=VariableDeclaration.wb;
	static XSSFSheet wshTemp;
	
	static String driverSheet =VariableDeclaration.dataSheetDriver;
	static String tempData="";
	static String webSerNmelvlExc="";
	static String webServiceName ="";
	static String[] scripts;
	static String testExecutionFlag="";
	String data2="";
	static String environmentData1="";
	static String refreshDataFlag="";
	static String consumingAppFlag="";
	static String testCaseName="";
	static String testDescription="";
	static String ParentTagName="";
	String[] nameString;
	static String[] envDataToPass = new String[11];
	static String testCaseID ="";
	static String OldEnviValue = "test";
	 
	 public static void main(String[] args) throws Exception 
	 {
		Thread.sleep(2000);
		
		try{
			
			erw.fnSetUpForMasterExcelData();
			Thread.sleep(2000);
			 wshTemp = erw.fnGetSheet(driverSheet);
			
		int counter = 0;		
		 int irow=wshTemp.getLastRowNum();
		 System.out.println("irow:"+irow);
		 for(int i=0;i<=irow;i++){
			 
			 int environmentCnt=erw.getColumnHeaderIndex("Environment", driverSheet);
			 int testCaseIDtCnt=erw.getColumnHeaderIndex("TC_ID", driverSheet);
			 int testCaseNameCnt=erw.getColumnHeaderIndex("TestCaseName", driverSheet);
			 int webServiceNameCnt=erw.getColumnHeaderIndex("WebServiceName", driverSheet);
			 int testDescriptionCnt=erw.getColumnHeaderIndex("TestDescription", driverSheet);
			 int webSerNmelvlExcFlag=erw.getColumnHeaderIndex("WebServiceName Level Execution", driverSheet);
			 int testExecution  = erw.getColumnHeaderIndex("TestcaseExecution", driverSheet);
			 int refreshDatacnt = erw.getColumnHeaderIndex("RefreshData", driverSheet);
			 int consumingApp = erw.getColumnHeaderIndex("ConsumingApp", driverSheet);
			 
			 
			 environmentData1= wshTemp.getRow(i).getCell(environmentCnt).toString().trim();
			 testCaseName= wshTemp.getRow(i).getCell(testCaseNameCnt).toString().trim();
			 webServiceName= wshTemp.getRow(i).getCell(webServiceNameCnt).toString().trim();
			 testDescription= wshTemp.getRow(i).getCell(testDescriptionCnt).toString().trim();
			 testCaseID= wshTemp.getRow(i).getCell(testCaseIDtCnt).toString().trim();
			 webSerNmelvlExc= wshTemp.getRow(i).getCell(webSerNmelvlExcFlag).toString().toUpperCase().trim();
			 testExecutionFlag = wshTemp.getRow(i).getCell(testExecution).toString().toUpperCase().trim();
			 refreshDataFlag = wshTemp.getRow(i).getCell(refreshDatacnt).toString().toUpperCase().trim();
			 consumingAppFlag = wshTemp.getRow(i).getCell(consumingApp).toString().toUpperCase().trim();
			 
		//	 TestCaseName == reqOperationName && TestSuiteName == testSuite && WebserviceLevel == 'Yes'TestcaseExecution =="YES"
				
					 if((webSerNmelvlExc.equalsIgnoreCase("YES"))&& testExecutionFlag.equalsIgnoreCase("YES") ){
						 int parentTagNamecnt = erw.getColumnHeaderIndex("NavigationPath", driverSheet);
						 try
						 {
							 ParentTagName = wshTemp.getRow(i).getCell(parentTagNamecnt).toString().toUpperCase().trim(); 					 

							 
						 }catch(Exception e){
							 ParentTagName = "";
						 }
						 
						 tempData= webServiceName +"_"+environmentData1.toUpperCase()+"_"+testCaseName+"_"+testDescription.toLowerCase()+"_"+ParentTagName.toUpperCase()+"_"+refreshDataFlag.toUpperCase()+"_"+i+"_" +testCaseID.toUpperCase() +"_"+ counter + "_" + OldEnviValue +"_"+consumingAppFlag ;
						 System.out.println("temp--:"+tempData);
						 scripts = tempData.split("_");
						 envDataToPass[0] = scripts[0];
						 envDataToPass[1] = scripts[1];
						 envDataToPass[2] = scripts[2];
						 envDataToPass[3] = scripts[3];
						 envDataToPass[4] = scripts[4];	
						 envDataToPass[5] = scripts[5];
						 envDataToPass[6] = scripts[6];
						 envDataToPass[7] = scripts[7];
						 envDataToPass[8] = scripts[8];
						 envDataToPass[9] = scripts[9];
						 envDataToPass[10] = scripts[10];
						 
						 
						 
						 
						 if(consumingAppFlag.equalsIgnoreCase("INET")){
							 
							SQLExecution envDataToPass;
							  
						 }else
						 { 	//executionScript.main(envDataToPass);

							
						 }
					
						 
						 if(environmentData1.toUpperCase().contains("LORX"))
						 {
							 if(testDescription.toLowerCase().equalsIgnoreCase("all valid data"))
							 {
								 OldEnviValue = "APSI7061.uhc.com";
								 counter++;
							 }else
							 {
								 
							 }
							 
						 }else
							 if(environmentData1.toUpperCase().contains("CATAMARAN(LCTRX)"))
							 {
								 if(testDescription.toLowerCase().equalsIgnoreCase("all valid data"))
								 {
									 OldEnviValue = "apsi906e";
									 counter++;
								 }else
								 {
									 
								 }
								 
							 }else
							 {
								 if(testDescription.toLowerCase().equalsIgnoreCase("all valid data"))
								 {
									 OldEnviValue = "apsi7062.uhc.com";
									 counter++;
								 }else
								 {
									 
								 }
								 
							 }
						 
					 }
				
			try{
				if(counter==10)
					{
					//	thm.closeTE();
						counter=0;
					}
					}catch(Exception e){
						}
		 }
		 }catch(Exception e){
//			 if(data.equalsIgnoreCase("YES")){
//				 executionData=data1.split("-");
//				 tempData=tempData+":"+executionData[0]+"_"+environmentData1.toUpperCase()+"_"+testCaseName+"_"+testCaseIdName;
//				 System.out.println("temp--:"+tempData);
//			 }
			 System.out.println(e.getMessage());
		 }finally{
			 erw.fnExcelCloseSheet();
		 }

		 if(consumingAppFlag.equalsIgnoreCase("INET")){
			 
			 upe.fnupdateResultWithDataforAging();
			 
		 }else
		 {
			 upe.fnupdateResultWithData();
		 }
		
		
		
		erw.fnExcelCloseSheet();
		System.out.println("hi");
	}
	

}
