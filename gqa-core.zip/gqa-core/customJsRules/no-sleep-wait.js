/**
 * @file Rule to disallow sleep and wait methods
 * @author dilip_daga-at-discovery.com
 */

//------------------------------------------------------------------------------
// Rule Definition
//------------------------------------------------------------------------------
module.exports = {
  meta: {
    type: 'problem',

    docs: {
      description: 'disallow sleep / wait methods',
      recommended: true,
    },
    fixable: 'code',
  },
  create(context) {
    return {
      Identifier(node) {
        if (node.name === 'sleep' || node.name === 'wait') {
          context.report({
            node,
            message:
              'Do not use sleep/wait. Use waitUntil or tryUntil for certain condition to be reached.',
          });
        }
      },
    };
  },
};
