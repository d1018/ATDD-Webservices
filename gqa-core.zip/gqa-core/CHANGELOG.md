## 1.12.1 (2023-03-02)

### Fix

- **GQA-15270**: updates Suitest devices ids (#284)

## 1.12.0 (2023-03-01)

### Feat

- **GQA-16862**: add support for nowTV device(s) (#281)
- **GQA-16971**: add Window size function in BrowserActions (#282)
- **GQA-16910**: dump screen src when test fails for Appium / Selenium (#276)
- **GQA-777**: integrate reportportal/agent-js-cucumber (#268)

### Fix

- **GQA-15570**: usage of threads (#278)

### Refactor

- **GQA-393**: refactor devices.json to use global namespacing for Roku devices (#244)
- **GQA-15892**: changed timeout from 30 seconds to 0 seconds (#270)

## 1.11.0 (2023-02-23)

### Feat

- **GQA-794**: deeplink support for android and ios (#269)
- **GQA-16581**: tryUntilVisible to assert visibility attribute for CTVs (#273)
- **GQA-16690**: Appium launch and closeapp method (#272)
- **GQAQE-15363**: slack notification on pr creation (#266)
- **GQAQE-15363**: slack notification on pr creation (#265)

### Fix

- **GQA-15674**: failed to create session, all hs-appium devices (#271)
- **GQA-15607**: headspin public url in the test report is wrongly mapped for few failed test cases (#267)
- **GQA-15620**: workflow update for gqa-automation (#262)
- **GQA-15620**: workflow update for GQA-Automation (#260)

## 1.10.0 (2023-02-16)

### Feat

- **GQA-12043**: introduce a waitUntil that takes a function as input parameter (#251)
- **gqa-746**: jira auto bug filing integration (#249)
- **GQA-14662**: create jake tasks for install uninstall ipas - appleTV (#250)
- **GQA-14727**: refactor Jira API into a class instead (#247)

### Fix

- **GQA-15382**: fix for testrail issue (#255)
- **GQA-13694**: remove HeadSpin-Suitest device cleaning codes (#246)

### Refactor

- **GQA-15130**: converted Logger from JS to TS, and fixed uses of console (#242)

## 1.9.0 (2023-02-09)

### Feat

- **GQA-14663**: create jake tasks for info, install, uninstall apk - fireTab, androidTV, fireTV (#238)
- **GQA-15013**: windowsize and deeplink in appium (#235)
- **GQA-14957**: add integration pipeline for STBT in gqa-core (#228)
- **GQA-14830**: support for different browsers for local execution (#226)
- **gqa-746**: log device summary in html report (#221)
- **GQA-14664**: create jake tasks for upload, delete and list uploaded ipa(s)/apk(s) (#224)
- **gqa-746**: typescript migration for jira auto filing (#215)
- **peo-30079**: unit tests for JIRA API class (#214)
- **PEO-25296**: lock Headspin device under test and camera device (#205)

### Fix

- **GQA-14654**: assert tryUntil, waitUntil, waitUntilVisible for remoteActions (#234)
- **GQA-461**: wrapped setTimeout in a promise to guarantee waiting time (#236)
- **reportportal**: report scenario based statistics (#219)
- **peo-25297**: update devices.json to use global namespace for region across hwa devices (#185)

## 1.8.0 (2023-02-02)

### Feat

- **GQA-14302**: add clean device api for headSpin - suitest devices (#213)
- **PEO-8432**: jira api class (crud operations using jira api) (#200)

### Fix

- **gqa-830**: remove geo from openApp from web (#212)

## 1.7.0 (2023-01-26)

### Feat

- **peo-8110**: enabled eslint for ts files (#195)
- **peo-23334**: shadow dom implementation (#197)
- **peo-8110**: added typescript tooling (#183)

### Refactor

- **PEO-29581**: move headspin url from before to after (#198)

## 1.6.0 (2023-01-19)

### Feat

- **peo-6857,peo-3563**: implemented consolidated json file for STBT reporting to RP (#187)
- **peo8442,peo24470**: implemented config reader logic and post processing of JIRA bugs filing (#166)
- **PEO-25763**: Add Vizio and Playstation to list of supported platforms (#179)

### Fix

- **peo-26901**: timeout after tunnel is set to avoid possible location issues (#188)
- **peo-27359**: refactoring mobile closeApp method (#190)

## 1.5.1 (2023-01-13)

### Fix

- **peo-26767**: js doc for web close app method (#181)

## 1.5.0 (2023-01-12)

### Feat

- **peo-8443**: implement bug hash generation helper part 2 (#173)
- **peo-24624**: stbt result aggregation utility (#167)

### Fix

- **PEO-25201**: fix for occasionally failing to create a headspin session (#161)

## 1.4.0 (2023-01-11)

### Feat

- **peo-8443**: implement bug hash generation helper (#162)
- **peo-8442**: created cached files for each test failure (#149)
- **PEO-24317**: added background app method (#158)

### Fix

- **PEO-7655**: fix for failed to create record session - headspin suitest (#159)
- **regional-routing**: upgrade gqa-regional-routing package (#163)

## 1.3.0 (2023-01-05)

### Feat

- **peo-8442**: internals hooks for auto jira bug filing (#146)

### Fix

- **PEO-24622**: Fix clickCoordinates text method (#153)
- **gqa regional routing update**: gqa regional routing update - fix ca tunnel behavior (#152)
- roku - temporarily removing the hs-us_roku_us_1 from json (#145)

### Refactor

- **peo-5708**: updated cucumber packages to the latest and pin version (#142)
- **peo-8357**: helper sanity check and normalize reading of process.env (#137)
- **PEO-5327**: improved Report Portal upload code and related unit tests (#98)

## 1.2.0 (2022-12-14)

### Feat

- **peo-6881**: baf regional routing integration (#134)

## 1.1.1 (2022-12-08)

## 1.1.0 (2022-12-02)

## 1.0.5 (2022-12-01)

## 1.0.4 (2022-11-25)

## 1.0.3 (2022-11-18)

## 1.0.2 (2022-11-18)

## 1.0.1 (2022-11-16)

## 1.0.0 (2022-11-07)

## 0.0.12 (2022-11-04)

## 0.0.11 (2022-11-04)

## 0.0.10 (2022-11-02)

## 0.0.9 (2022-11-01)

## 0.0.8 (2022-10-25)
