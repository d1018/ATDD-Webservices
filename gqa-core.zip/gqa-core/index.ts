// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { runTestsWithCucumberAsync } from './lib/runTestsWithCucumberAsync';
import { runTestsWithStbtAsync } from './lib/runTestsWithStbtAsync';

export * from './lib/cucumberDefinition';
export {
  runTestsWithCucumberAsync as runner,
  runTestsWithCucumberAsync,
  runTestsWithStbtAsync,
};
