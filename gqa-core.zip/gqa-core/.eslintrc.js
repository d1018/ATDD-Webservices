require('@wbd/eslint-config/patch/modern-module-resolution');

module.exports = {
  env: {
    browser: true,
    commonjs: true,
    es2021: true,
    node: true,
    jest: true,
  },
  extends: [
    'airbnb-base',
    'plugin:node/recommended',
    'plugin:jest/recommended',
    'plugin:jsdoc/recommended',
    'plugin:import/errors',
    'plugin:import/warnings',
    'prettier',

    // TS import
    'plugin:import/typescript',

    // wbd-streaming standard for TypeScript:
    // see: https://github.com/wbd-streaming/wbd-beam-typescript
    '@wbd/eslint-config/profile/node-trusted-tool',
  ],
  parser: '@typescript-eslint/parser',

  parserOptions: {
    tsconfigRootDir: __dirname,
    ecmaVersion: 'latest',
  },

  // resolve files using both .js and .ts extensions
  // reference: https://stackoverflow.com/a/61024769
  settings: {
    node: {
      resolvePaths: [__dirname],
      tryExtensions: ['.js', '.json', '.node', '.ts', '.d.ts'],
    },
  },

  overrides: [
    {
      files: ['*.js'],
      rules: {
        // exclude this rule for .js file since it's only a valid check for ts file
        '@typescript-eslint/no-var-requires': 'off',

        // we don't require extension for import / require
        // except json file
        // reference: https://stackoverflow.com/a/59268871/13274213
        'import/extensions': [
          'error',
          'ignorePackages',
          {
            js: 'never',
            ts: 'never',
            json: 'always',
          },
        ],
      },
    },
    {
      files: ['*.test.ts'],
      rules: {
        // Turning this off for .test.ts files, since Jest requires module mocks to come before imports.
        'import/first': 'off',
        'import/order': 'off',

        // Turning this off for .test.ts files, so that we can load test resources on a per-test basis.
        'global-require': 'off',

        // Making an exception for helper functions whose names start with "expect", so that we can
        // make assertions in our tests via helper functions for increased test clarity.
        'jest/expect-expect': [
          'warn',
          {
            assertFunctionNames: ['expect*'],
          },
        ],
      },
    },
    {
      files: ['*.ts'],
      rules: {
        // exclude these rules for .ts file since ts has its own TSDoc syntax
        // reference: https://tsdoc.org/
        'jsdoc/require-param-type': 'off',
        'jsdoc/require-returns-type': 'off',
        'jsdoc/require-param': 'off',
        'jsdoc/check-param-names': 'off',

        // need this to work with our mix project:
        // reference: https://github.com/mysticatea/eslint-plugin-node/issues/205
        'node/no-unsupported-features/es-syntax': [
          'error',
          { ignores: ['modules'] },
        ],

        // we don't prefer default exports for .ts files
        'import/prefer-default-export': 'off',

        // we don't follow all sources under the src folder
        '@rushstack/packlets/mechanics': 'off',

        // we don't require extension for import / require
        // except json file
        // reference: https://stackoverflow.com/a/59268871/13274213
        'import/extensions': [
          'error',
          'ignorePackages',
          {
            js: 'never',
            ts: 'never',
            json: 'always',
          },
        ],

        // for some reason @cucumber/cucumber/api can't be resolved in TS using
        // @wbd/eslint-config setting; ignore this particular import path error for now
        'import/no-unresolved': [
          'error',
          {
            ignore: ['@cucumber/cucumber/api'],
          },
        ],

        // Changing these to "warn" so that we don't get misleading errors displayed in
        // VSCode while we're in the middle of typing up what is going to be perfectly
        // valid code. The linter will still fail builds, so this doesn't decrease safety.
        '@typescript-eslint/no-unused-vars': 'warn',
        'no-unused-vars': 'warn',
      },
    },
  ],
  rules: {
    'class-methods-use-this': 'off',
    'jest/expect-expect': 'warn',
    'newline-after-var': ['error', 'always'],
    'node/no-unpublished-require': 'off',
    'no-await-in-loop': 'off',
    'no-console': 'error',
    'no-plusplus': 'off',
    'no-process-exit': 'off',
    'no-promise-executor-return': 'off',
    'no-return-assign': 'off',
    'no-sleep-wait': 'off',
    'no-underscore-dangle': 'off',
    'require-await': 'error',
  },

  // https://github.com/microsoft/rushstack/blob/main/eslint/eslint-config/profile/_common.js
  // the rushstack skips to lint the custom type file, but we want to do that, otherwse we will get this
  // eslint warning, which we don't wanted:
  // 0:0  warning  File ignored because of a matching ignore pattern. Use "--no-ignore" to override
  ignorePatterns: ['node_modules', '!types/*.d.ts'],
};
