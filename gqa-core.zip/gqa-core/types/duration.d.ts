// Copyright text placeholder, Warner Bros. Discovery, Inc.

declare module 'duration' {
  class Duration {
    public toString: (input: string) => string;

    public constructor(start: Date, end: Date);
  }
  export = Duration;
}
