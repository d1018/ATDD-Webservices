module.exports = {
  testMatch: ['**/*.test.(js|ts)'],
  collectCoverage: false,
  roots: ['tests'],
  preset: 'ts-jest/presets/js-with-ts',
};
