# JIRA Auto Bug filing with `gqa-automation` project

## Feature flag and related parameters

- JIRA_AUTO_BUG_FILING

```
# set this to "1" to turn on JIRA auto bug filing feature
# by defualt it is set to 0: auto bug filing is disabled by default
process.env.JIRA_AUTO_BUG_FILING=1
```

- JIRA_MAX_NEW_BUGS_ALLOWED_PER_EXECUTION

```
# the max number of bugs allowed to be created per execution
# by default it is set to 3 when unset (allow only file up to 5 new bugs)
process.env.JIRA_MAX_NEW_BUGS_ALLOWED_PER_EXECUTION=10
```

## Highlevel workflow:

1. NPM install of all necessary files for a BAF test run via JFrog: `@wbd/gqa-core`, `@wbd/gqa-regional-routing`).
2. Create a valid `.env` file in the project root folder. Related envs for JIRA auto bug filing is listed below:

```
# JIRA credentials
JIRA_USERNAME="XXX"
JIRA_PASSWORD="YYY"
JIRA_AUTO_BUG_FILING=1  # 1 to turn on bug filing
```

3. Provide a valid `jiraConfig` JS file that exports an object with some essential fields:

```Javascript
// log directory to save the cache file
logDir: 'results/jira',

// API URL of the JIRA server

apiUrl: 'https://wbdstreaming.atlassian.net/rest/api',

// JIRA credentials
username: process.env.JIRA_USERNAME,
password: process.env.JIRA_PASSWORD,

// Project to file bug for
project: 'GQA',

// Epic we should file the bug under
epic: 'GQA-13657',

// list of status that bug is considered "closed" and no longer active
// the  bug search query will exclude bugs that are in one of these status
inactiveBugStatus: ['DONE', 'CANCELLED'],
```

4. Execute a test run:

```bash
npx jake:DTC:ios
```

5. Execute the report generation Jake task:

```bash
npx jake utils:report
```

6. Execute the jira auto bug filing Jake task:

```bash
npx jake utils:autoJiraBug
```

### Sample test artifacts:

```
results.zip:
-- ios_report.html
-- json_report.json
-- jira <dir>
    - jira.xxxx.json
    - jira.yyy.json
```

## High Level sequence diagram

test execution sequence:

```mermaid
sequenceDiagram
    actor Tim
    participant G as GHA workflow
    participant A as gqa-automation
    participant B as gqa-core
    participant C as device farms (Browerstack / HeadSpin / API)
    participant D as JIRA server
    Tim->>G: Trigger
    activate G
    G->>A: git clone / npm install
    A->>B: JFrog npm package download
    B-->>A:
    A-->>G:
    G->>A: entrypoint.sh<br/>- npx jake project:client<br/>(ex: npx jake BEAM:ios)<br/>(jiraConfig.js specified)
    loop
      A->>B: Platform API
      Note over B,C: device interaction via W3C protocol (mostly)
      B->>C: Selenium / Appium / Suitest API, etc
      C-->>B:
      B-->>A:
    end
    A-->>G: result: <br/>- results/report.json <br/>- results/jira/jira.xxx.json (one for each test failure)

    G->>A: - npx jake utils:report
    A-->>G: report.json is generated

    G->>A: - npx jake utils:autoJiraBug<br/>
    A->>B: jiraTask<br/>1. process each results/jira/jira.xxxjson<br/>2.normalize to JIRA payload<br/>3.cb from config<br/>4.invoke JIRA API
    loop
      B->>D: jira API
      D-->>B: ack'ed
    end
    B-->>A: ack'ed
    A-->>G: Jira tickets are created / commented
    G-->>Tim: result: <br/>- results/report.json <br/>- results/jira/jira.xxx.json (one for each test failure)
    deactivate G
    Tim->>D: audit JIRA ticket
    D-->>Tim:
```

## High Level state diagram

Bug searching with bug Id (md5 sum of the stack trace):

```mermaid
stateDiagram
    state "jira.xxx.json" as a
    state "edit issue API" as j0
    state "jira payload customization" as j1
    state "comment issue API" as j2
    state "search issue API" as j3
    state "new bug with bugId" as b
    state "existing bug with new comment" as c
    state "create issue API" as p1
    a --> checksum: md5 calc
    checksum --> j3: jql("Project = GQA AND issuetype = Bug and cf[10202] ~ 'md5' AND status not in ( 'DONE','CANCELLED')
    j3 --> j1: no bug found
    j1 --> p1:
    j3 --> j2: bug found
    p1 --> j0: new bug
    j0 --> b: add bugId
    j2 --> c: add comment
```
