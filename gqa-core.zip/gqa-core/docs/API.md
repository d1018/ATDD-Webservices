# API

The `gqa-core` project exports the following APIs to drive various aspect of the BDD test run.

## BDD APIs:

< < Add more description > >

```
const {
  // hooks
  Before,
  BeforeAll,
  BeforeStep,
  After,
  AfterAll,
  AfterStep,

  // step functions
  Given,
  Then,
  And,
  But,

  // cucumber-js functions
  setDefaultTimeout,
  setDefinitionFunctionWrapper,
  setParallelCanAssign,
  setWorldConstructor,

} = require('@wbd/gqa-core');
```

## Test Runner for Appium, Suitest, and Webdriver tests

< < Add more description > >

```
const { runTestsWithCucumberAsync } = require('@wbd/gqa-core');
```

Usage example:

```
setTimeout(async () => {
  const result = await runTestsWithCucumberAsync({
    paths: ["features"],
    require: ["features/stepDefinition"],
    parallel: 2,
    tags: "@myTag",
  });
  console.log(`runner returns: ${result}`);
}, 100);

```

## Test Runner for STB-Tester tests

To run tests via the STB-Tester testing framework programmatically, use the `runTestsWithStbtAsync()` function,
which you can import from `@wbd/gqa-core`:

```
const { runTestsWithStbtAsync } = require('@wbd/gqa-core')
```

You must provide this function with a configuration object, which can have the following properties:

```
{
  file: '<file_path_of_the_Cucumber_config_file>',
  paths: ['projects/<project_name>/features/*'],
  profiles: ['<some_Cucumber_profile>', '<another_Cucumber_profile>'],
  tags: "<tag_expression>",
}
```

The `paths` property is required, and must have the stated form (i.e., `string[]` containing a single
`string`, which is a file path from the root directory of the repository to the `features` directory of a
single project, ending in a "\*" wildcard).

Usage example:

```
const { runTestsWithStbtAsync } = require('@wbd/gqa-core');

setTimeout(async () => {
  try {
    const result = await runTestsWithCucumberAsync({
      paths: ["features"],
      tags: "@myTag",
    });
    console.log(`runner returns: ${result}`);
  } catch (error) {
    console.log('Test runner failed with an error:`, error);
  }
}, 100);

```

## Jake Tasks (reserved and exclusively used in `gqa-automation-core`):

< < Add more description > >

```
const {
    createRunnerTasks,
    createHeadspinTasks,
    createSuitestTasks,
    createUtilsTasks
} = require('@wbd/gqa-core/tasks');
```

## Jake Tasks Utility Helper functions for CI(reserved and exclusively used in `gqa-automation-core`):

< < Add more description > >

```
const {
    paths,
    runCommandOnFileDiffs,
    hiddenFileFilter,
    obtainValueByKey,
    configureEnvVars,
    downloadFile,
    verifyEnvVars,
    getChangefeatureDetails,
    directoryFilter,
    setEnvVars,
    fetchSSMRegions,
} = require('@wbd/gqa-core/tasks/utils');
```

## Jake Tasks Utility Helper functions for CI(reserved and exclusively used in `gqa-automation-core`):

< < Add more description > >

```
const {
    browserActions,
    mobileActions,
    remoteActions,
    VirtualRemoteControl,
    paths,
    jakeProjects,
    projectList,
    getClients,
    globalHooks,
    testdataHelper,
} = require('@wbd/gqa-core/support');
```

## Use alternative cucumber profile names(reserved and exclusively used in `gqa-automation-core`):

By default `cucumber.js` file is read in the project root folder to define profile:

```
const {
  createRunnerTasks,
} = require('@wbd/gqa-core/tasks');
```

Using default profile:

```
// uses default profile
createRunnerTasks();
```

Using a specific profile:

```
// this uses abc profile
createRunnerTasks({
  cucumberProfiles: 'abc',
});
```

Using multiple profiles:

```
// this uses multiple profiles
createRunnerTasks({
  cucumberProfiles: ['abc', 'def'],
});
```
