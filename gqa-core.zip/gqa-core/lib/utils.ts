// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { logger } from '../support/logger';

/**
 * helper to output hook name and error msg and throw error
 * (should be used only from cucumber hooks function)
 *
 * @param hookName - name of hook
 * @param error - error to throw
 */
export const throwHookError = (hookName: string, error: unknown): never => {
  logger.error(`error thrown from ${hookName} hook!`);
  logger.error(error);
  throw error;
};
