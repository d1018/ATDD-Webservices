// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { Buffer } from 'buffer';
import { execSync } from 'child_process';
import { existsSync } from 'fs';
import { IExecSyncError } from '../support/IExecSyncError';

const EXPECTED_PYTEST_LOCATION: string = '.venv/bin/pytest';

/**
 * Returns the validated path to the `pytest` executable.
 *
 * @returns the validated path to the `pytest` executable
 * @throws If `pytest` is not installed at the expected location
 */
function getPytestPath(): string {
  if (!existsSync(EXPECTED_PYTEST_LOCATION)) {
    throw new Error(
      `Could not find pytest at "${EXPECTED_PYTEST_LOCATION}". If pytest-bdd is not installed, please run ".venv/bin/pip install git+https://github.com/lukeyoui/pytest-bdd.git@v1.0-wbd-alpha" to install it.`,
    );
  }

  return EXPECTED_PYTEST_LOCATION;
}

/**
 * Validates that `paths` contains only a single path, and removes the trailing '*' if present.
 *
 * @param paths - A single file path of the form `<path_to_repo_root>/tests/projects/<project_name>/features/*`,
 * or a string containing paths to multiple feature files, separated by spaces.
 * @returns The full path to the "features" directory of the target client application (e.g. "app_discovery_plus").
 * @throws If the path is not a single file path of the form `<path_to_repo_root>/tests/projects/<project_name>/features/*`.
 */
function getCleanPath(paths: string): string {
  if (paths.includes(' ')) {
    throw new Error(
      'Path cannot include a space, and individual features cannot be specified',
    );
  }

  return paths.endsWith('*') ? paths.substring(0, paths.length - 1) : paths;
}

/**
 * Removes the `@` from any `@tags` in the tagExpression. The tagExpression provided by the rest of the BAF uses
 * tags which always begin with `@`. `pytest-bdd`, on the other hand, uses only tags which do NOT begin with `@`.
 *
 * @param tagExpression - A tag expression (e.g. `@P0 and not @P1`) where the individual tags begin with `@`
 * @returns The same tag expression, with the `@` prefix removed from each individual tag
 */
function getCleanTagExpression(tagExpression: string): string {
  return tagExpression.replaceAll('@', '');
}

/**
 * Executes the `pytest` command to collect test paths for the given path and `@tag` expression.
 *
 * @param paths - A single file path of the form `<path_to_repo_root>/tests/projects/<project_name>/features/*`,
 * or a string containing paths to multiple feature files, separated by spaces.
 * @param tagExpression - The `@tag` expression (e.g. `"@P0 and not @wip"`) that controls which features,
 * scenarios, and examples should be included.
 * @returns the command output returned by a successful pytest execution.
 * @throws If the path is not a single file path of the form `<path_to_repo_root>/tests/projects/<project_name>/features/*`.
 * @throws If `pytest` is not installed at the expected location.
 * @throws If the `pytest` command exits with a non-zero status code.
 */
function runPytestCommand(paths: string, tagExpression: string): string {
  const pytestPath = getPytestPath();
  const cleanPath = getCleanPath(paths);
  const cleanTagExpression = getCleanTagExpression(tagExpression);
  const command = `${pytestPath} --co ${cleanPath} -q -m "${cleanTagExpression}"`;

  let execSyncOutput: string | Buffer;

  try {
    execSyncOutput = execSync(command, { encoding: 'utf-8' });
  } catch (untypedError) {
    const execSyncError: IExecSyncError = untypedError as IExecSyncError;

    if (
      execSyncError.stdout &&
      execSyncError.stdout.includes(
        "ModuleNotFoundError: No module named 'pytest_bdd'",
      )
    ) {
      const installPytestCommand =
        '.venv/bin/pip install git+https://github.com/lukeyoui/pytest-bdd.git@v1.0-wbd-alpha';

      throw new Error(
        `pytest-bdd is not installed. Please run "${installPytestCommand}" to install it.`,
      );
    }

    if (
      execSyncError.stderr &&
      execSyncError.stderr.includes("ERROR: Wrong expression passed to '-m': ")
    ) {
      throw new Error(
        `Invalid tag expression "${tagExpression}". pytest-bdd error was "${execSyncError.stderr.trim()}"`,
      );
    }

    const noTestsInFeature = /no tests collected in/;

    if (execSyncError.stdout && noTestsInFeature.test(execSyncError.stdout)) {
      throw new Error(`No tests found in path "${paths}"`);
    }

    if (execSyncError.stdout) {
      const tagsExcludedAllTests = /no tests collected \((\d+) deselected\) in/;
      const match = execSyncError.stdout.match(tagsExcludedAllTests);

      if (match) {
        const excludedTestCount = match[1];

        throw new Error(
          `No tests found in path "${paths}" matching tag expression "${tagExpression}". ${excludedTestCount} tests were excluded by the tag expression.`,
        );
      }
    }

    // The error is typically in `stderr`. If it is not in `stderr`, it will be in `stdout`.
    const errorOutput =
      execSyncError.stderr !== '' ? execSyncError.stderr : execSyncError.stdout;

    throw new Error(
      `Unknown error executing pytest command "${command}". Error status: ${execSyncError.status}, error output: "${errorOutput}".`,
    );
  }

  return execSyncOutput.toString();
}

/**
 * Parses the raw output (std::out) from the pytest collect call and returns
 * the test paths to be executed. The returned test paths include any
 * parameters to the tests.
 *
 * @param commandOutput - The raw std::out from the pytest collection command.
 * @returns The `pytest` test paths (including parameters) of the tests to be executed on the targeted STB-Tester node(s).
 */
function parseOutput(commandOutput: string): string[] {
  return commandOutput
    .split(/\r?\n/)
    .filter((line) => line.includes('::'))
    .map((test) => test.trim());
}

/**
 * Collects the list of `pytest` test paths to be executed, based on the provided paths and
 * `@tag` expression. The test paths returned will correspond to the features, scenarios,
 * and examples that satisfy the specified `@tag` expression. They can be passed directly
 * to `stbt_rig.py` or the STBT REST API for execution.
 *
 * WARNING: for the time being, the `paths` parameter MUST consist of a single file path
 * of the form `<path_to_repo_root>/projects/<project_name>/features/*`. Providing the path to a specific
 * feature file, or to multiple feature files, is NOT currently supported. Attempting to do so
 * will cause an error. When this behavior is implemented
 * (see {@link https://wbdstreaming.atlassian.net/browse/PEO-5947}),
 * the documentation for `paths` will become:
 *    One or more file paths of the form `"projects/<project_name>/features/<feature_name>.feature"`,
 *    with individual paths separated by spaces; or a single file path of the form
 *    `"projects/project_name>/features/*"`
 *
 * Implementation:
 *
 * Calls the `pytest` CLI (invoking the `pytest-bdd` plugin) to return the `pytest` test paths
 * that meet the specified criteria.
 *
 * @param paths - A single file path of the form `<full_path_to_repo_root>/tests/projects/<project_name>/features/*`,
 * or a string containing the full paths to multiple feature files in project `<project_name>`, separated by spaces.
 * @param tagExpression - The `@tag` expression (e.g. `"@P0 and not @wip"`) that controls which features, scenarios,
 * and examples should be included in the test job.
 * @returns The `pytest` tests paths corresponding to the selected features, scenarios, and examples of all features
 * within project <projectName>.
 * @throws If the path is not a single file path of the form `<full_path_to_repo_root>/tests/projects/<project_name>/features/*`.
 * @throws If `pytest` is not installed, or is not installed at the expected location.
 * @throws If the `pytest` command exits with a non-zero status code.
 */
export function getSelectedStbtTests(
  paths: string,
  tagExpression: string,
): string[] {
  const commandOutput: string = runPytestCommand(paths, tagExpression);
  const selectedTests: string[] = parseOutput(commandOutput);

  return selectedTests;
}
