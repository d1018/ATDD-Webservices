// Copyright text placeholder, Warner Bros. Discovery, Inc.

const STBT_TAG_PREFIX: string = 'STBT_TAG_';

/**
 * Gets any environment variables whose names start with `STBT_TAG_`, and include them in the tags to be
 * passed to the `/run_tests` endpoint.
 *
 * @returns An object whose keys are the environment variables whose names start with `STBT_TAG_`,
 * and whose values are the values of those environment variables.
 */
function getEnvironmentVariablesWithStbtTagPrefix(): Record<
  string,
  string | undefined
> {
  return Object.fromEntries(
    Object.entries(process.env).filter((entry) =>
      entry[0].startsWith(STBT_TAG_PREFIX),
    ),
  );
}

/**
 * Gets the environment variables that should be forwarded to the `/run_tests` endpoint as STBT tags.
 *
 * These include:
 *    1. Certain values (client, product, and region) from the GitHub Action that invoked this test run.
 *    2. Any environment variables whose names start with `'STBT_TAG_'`.
 *
 * @returns An object containing the key/value pairs that should be passed as tags to the `/run_tests`
 * endpoint.
 */
export function getStbtTags(): Record<string, string | undefined> {
  return {
    ...getEnvironmentVariablesWithStbtTagPrefix(),
    client: process.env.CLIENT,
    product: process.env.PRODUCT,
    region: process.env.REGION,
  };
}
