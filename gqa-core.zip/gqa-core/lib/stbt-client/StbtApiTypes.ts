// Copyright text placeholder, Warner Bros. Discovery, Inc.

/**
 * The parameters to execute a test run on an STB-Tester node.
 *
 * Currently, `StbtClient` does not support the `remote_control`, `category`, `soak`, `shuffle`,
 * or `tags` parameters to the `run_tests` endpoint of the STB-Tester REST API.
 *
 * STB-Tester endpoint documentation: {@link https://stb-tester.com/manual/rest-api-v2#post--api-v2-run_tests}
 */
export interface IRunTestsRequestBody {
  /**
   * The STB-Tester `node_id` of the node on which the test job should be executed.
   */
  stbtNodeId: string;

  /**
   * The Git revision specifier (a branch name or a commit SHA) of the test repo revision containing the tests,
   * or "SNAPSHOT" for the user's STBT snapshot (see `getStbtTestPackRevision.ts`).
   */
  testPackRevision: string;

  /**
   * The `pytest` test specifiers for the tests which should be executed. These are of the form
   * "[test_file_path]::[test_function_name][[test_parameter_1],[test_parameter_2],...[test_parameter_n]".
   */
  testCases: string[];

  /**
   * Values to be forwarded to the `/run_tests` endpoint as STBT tags.
   */
  stbtTags: Record<string, string | undefined>;

  /**
   * Uniquely identifies a BAF test run.
   */
  bafTestRunId: string;
}

/**
 * The status of a test job on an STB-Tester node. Once started, a test job is in the 'running'
 * status until it completes. Once it completes, it will remain permanently in the 'exited' status.
 */
export type JobStatus = 'running' | 'exited';

/**
 * The counts of completed tests in the test job, by completion status.
 */
export interface IResultCounts {
  /**
   * The number of tests in the test job that passed.
   */
  pass: number;

  /**
   * The number of tests in the test job that have failed.
   */
  fail: number;

  /**
   * The number of tests in the test job that have failed to complete due to an error.
   */
  error: number;

  /**
   * The total number of tests in the test job that have finished executing.
   */
  total: number;
}

/**
 * The result of executing a test:
 *    - 'pass' -- the test completed successfully
 *    - 'fail' -- the test failed due to a failed test assertion
 *    - 'error' -- the test threw a non-assertion exception
 */
export type TestResult = 'pass' | 'fail' | 'error';

/**
 * The response object from a /run_tests call.
 *
 * STB-Tester endpoint documentation: {@link https://stb-tester.com/manual/rest-api-v2#post--api-v2-run_tests}
 */
export interface IJobResponse {
  /**
   * The STBT `job_uid` of the test job.
   */
  jobUid: string;

  /**
   * The STBT Portal webapp URL of the test job.
   */
  jobUrl: string;

  /**
   * The status of the test job.
   */
  status: JobStatus;

  /**
   * The starting time of the job.
   */
  startTime: string;

  /**
   * The ending time of the job.
   */
  endTime: string;

  /**
   * The counts of tests within the test job, broken out by each of the possible test results
   * (`pass`, `fail`, `error`) and total tests (`total`) of the test job.
   */
  resultCounts: IResultCounts;
}

/**
 * The response object from a /run_tests call.
 *
 * STB-Tester endpoint documentation: {@link https://stb-tester.com/manual/rest-api-v2#post--api-v2-run_tests}
 */
export interface IJobResponseJson {
  /**
   * The STBT `job_uid` of the test job.
   */
  job_uid: string;

  /**
   * The STBT Portal webapp URL of the test job.
   */
  job_url: string;

  /**
   * The status of the test job.
   */
  status: JobStatus;

  /**
   * The starting time of the job.
   */
  start_time: string;

  /**
   * The ending time of the job.
   */
  end_time: string;

  /**
   * The counts of tests within the test job, broken out by each of the possible test results
   * (`pass`, `fail`, `error`) and total tests (`total`) of the test job.
   */
  result_counts: IResultCounts;
}

/**
 * The result of a single test's execution.
 *
 * STB-Tester endpoint documentation: {@link https://stb-tester.com/manual/rest-api-v2#post--api-v2-run_tests}
 */
export interface ITestResult {
  /**
   * The STBT `result_id`; the id of the test result in the STBT REST API.
   */
  resultId: string;

  /**
   * The STBT `job_uid`; the uid of the test job in which the test was executed.
   */
  jobUid: string;

  /**
   * - The STBT `result_url`; the URL of the test result in the STBT REST API.
   */
  resultUrl: string;

  /**
   * The STBT `triage_url`; the URL of the test results in the STBT portal webapp.
   */
  triageUrl: string;

  /**
   * The STBT `start_time`: the starting time of the job.
   */
  startTime: string;

  /**
   * The STBT `end_time`: the ending time of the job.
   */
  endTime: string;

  /**
   * The STBT `test_pack_sha`; the Git revision SHA of the version of the repo from which the test was taken.
   */
  testPackSha: string;

  /**
   * The STBT `result`; the result of the test execution.
   */
  result: TestResult;

  /**
   * The STBT `failure_reason`; the message of the assertion that caused the test to fail.
   */
  failureReason?: string;
}

/**
 * The result of a single test's execution.
 *
 * STB-Tester endpoint documentation: {@link https://stb-tester.com/manual/rest-api-v2#post--api-v2-run_tests}
 */
export interface ITestResultJson {
  /**
   * The id of the test result in the STBT REST API.
   */
  result_id: string;

  /**
   * The uid of the test job in which the test was executed.
   */
  job_uid: string;

  /**
   * - The URL of the test result in the STBT REST API.
   */
  result_url: string;

  /**
   * The URL of the test results in the STBT portal webapp.
   */
  triage_url: string;

  /**
   * The starting time of the job.
   */
  start_time: string;

  /**
   * The ending time of the job.
   */
  end_time: string;

  /**
   * The Git revision SHA of the version of the repo from which the test was taken.
   */
  // eslint-disable-next-line @typescript-eslint/naming-convention
  test_pack_sha: string;

  /**
   * The result of the test execution.
   */
  result: TestResult;

  /**
   * The message of the assertion that caused the test to fail.
   */
  // eslint-disable-next-line @rushstack/no-new-null
  failure_reason: string | null;
}

/**
 * The JSON returned from the `api/v2/jobs/(job_uid)` endpoint.
 *
 * STB-Tester endpoint documentation: {@link https://stb-tester.com/manual/rest-api-v2#inspect-a-test-job}
 */
export interface IJobsResponseJson {
  job_uid: string;
  job_url: string;
  status: JobStatus;
  start_time: string;
  end_time: string;
  result_counts: IResultCounts;
}

/**
 * The line of code, in a BDD steps file, that corresponds to a BDD step (as represented in a 'steps.json' file).
 */
export interface IMatch {
  location: string;
}

/**
 * The result of a BDD step's execution (as represented in a 'steps.json' file).
 */
export interface IResult {
  status: string;
  duration: number;
}

/**
 * A BDD tag (as represented in a 'steps.json' file).
 */
export interface ITag {
  name: string;
  line: number;
}

/**
 * The execution of a BDD step withn a BDD feature or scenario (as represented in a 'steps.json' file).
 */
export interface IStep {
  keyword: string;
  name: string;
  line: number;
  match: IMatch;
  result: IResult;
}

/**
 * The execution of a BDD feature or scenario (as represented in a 'steps.json' file).
 */
export interface IStepsResult {
  keyword: string;
  uri?: string;
  name: string;
  id: string;
  line: number;
  description: string;
  tags: ITag[];
  elements?: IStepsResult[];
  type?: string;
  steps?: IStep[];
}

/**
 * The contents of a `steps.json` file. A `steps.json` file consists of a single-element array
 * whose element is the actual steps-based result we want.
 */
export type StepsFileFormat = [IStepsResult];
