// Copyright text placeholder, Warner Bros. Discovery, Inc.

import axios, { AxiosInstance, AxiosResponse } from 'axios';
import HttpStatus from 'http-status';
import { getCustomError, StbtAxiosError } from './getCustomError';
import {
  IJobResponse,
  IJobResponseJson,
  IJobsResponseJson,
  IResultCounts,
  IRunTestsRequestBody,
  IStepsResult,
  ITestResult,
  ITestResultJson,
  StepsFileFormat,
} from './StbtApiTypes';

const ONE_MINUTE_IN_MILLISECONDS: number = 60 * 1000;

/**
 * The default base URL for the STBT REST API.
 */
const DEFAULT_BASE_URL: string = 'https://hbo.stb-tester.com/';

/**
 * Thick-client object for communicating with the STB-Tester REST API.
 *
 * This class does not attempt to replicate the STBT REST API object-for-object and endpoint-for-endpoint.
 * Instead, it presents an external interface tailored to the needs of the BAF testing framework.
 */
export class StbtClient {
  /**
   * The bearer token for STBT authentication.
   */
  private _stbtAuthToken: string;

  /**
   * The Axios instance for communicating with the STBT REST API.
   */
  private _axiosInstance: AxiosInstance;

  /**
   * Construct a client for the STB-Tester REST API.
   *
   * @param stbtAuthToken - the auth token (previously obtained from the STB-Tester portal webapp)
   * @param baseURL - the base URL of the STBT REST API to be called
   */
  public constructor(
    stbtAuthToken: string,
    baseURL: string = DEFAULT_BASE_URL,
  ) {
    this._stbtAuthToken = stbtAuthToken;

    this._axiosInstance = axios.create({
      baseURL,
      timeout: ONE_MINUTE_IN_MILLISECONDS,
      headers: {
        // This weirdness is not our fault! STB-Tester has chosen to use their own prefix ("token ")
        // rather than the prefix mandated by the standard ("Bearer ") for bearer token authorization.
        // See https://stb-tester.com/manual/rest-api-v2 and https://datatracker.ietf.org/doc/html/rfc6750#section-2.1
        Authorization: `token ${stbtAuthToken}`,
      },
    });
  }

  /**
   * Invokes the `run_tests` endpoint of the STB-Tester REST API with the parameters in `runTestsBody`,
   * executing the `pytest` tests in `testCases` from Git revision `testPackRevision` on STB-Tester node `stbtNodeId`.
   *
   * STB-Tester endpoint documentation: {@link https://stb-tester.com/manual/rest-api-v2#post--api-v2-run_tests}
   *
   * @param requestBody - The parameter object specifying which tests to run, and what STB-Tester node to run them on.
   * @returns The response from the STB-Tester `run_tests` endpoint, with the original Python-style
   * property names converted to the equivalent Javascript-style names.
   * @throws On HTTP Status codes indicating errors in initiating test execution.
   */
  public async runTestsAsync(
    requestBody: IRunTestsRequestBody,
  ): Promise<IJobResponse> {
    const endpointUrl = `api/v2/run_tests`;

    const postBody = {
      node_id: requestBody.stbtNodeId,
      // eslint-disable-next-line @typescript-eslint/naming-convention
      test_pack_revision: requestBody.testPackRevision,
      test_cases: requestBody.testCases,
      tags: requestBody.stbtTags,
      category: requestBody.bafTestRunId,
    };

    try {
      const { data }: AxiosResponse<IJobResponseJson> =
        await this._axiosInstance.post(endpointUrl, postBody);

      return {
        jobUid: data.job_uid,
        jobUrl: data.job_url,
        status: data.status,
        startTime: data.start_time,
        endTime: data.end_time,
        resultCounts: data.result_counts,
      };
    } catch (error) {
      throw getCustomError(error as StbtAxiosError, this._stbtAuthToken);
    }
  }

  /**
   * Waits for the STB-Tester test job with UID `jobUid` to finish executing. This method calls
   * the STBT REST API's `await_completion` endpoint for the given STBT `job_uid` as long as it
   * returns an HTTPStatus Accepted (202), which indicates that the test job is still executing.
   * If the endpoint returns an HTTPStatus OK (200), indicating that the test has finished executing,
   * this method returns immediately. If the endpoint returns any other HTTPStatus, this method
   * throws an `Error` indicating that an unexpected HTTPStatus has been received.
   *
   * STB-Tester endpoint documentation: {@link https://stb-tester.com/manual/rest-api-v2#wait-for-a-job-to-finish}
   *
   * @param jobUid - The STB-Tester `job_uid` of the test job.
   */
  // eslint-disable-next-line require-await, no-unused-vars
  public async waitForTestJobCompletionAsync(jobUid: string): Promise<void> {
    const endpointUrl = `api/v2/jobs/${jobUid}/await_completion`;

    try {
      let result: AxiosResponse = await this._axiosInstance.get(endpointUrl);

      while (result.status === HttpStatus.ACCEPTED) {
        result = await this._axiosInstance.get(endpointUrl);
      }
    } catch (error) {
      throw getCustomError(error as StbtAxiosError, this._stbtAuthToken);
    }
  }

  /**
   * Gets the final status of a test job: `true` if all tests in the test job passed,
   * and `false` if any tests in the test job failed or errored.
   *
   * STB-Tester endpoint documentation: {@link https://stb-tester.com/manual/rest-api-v2#inspect-a-test-job}
   *
   * @param jobUid - The STB-Tester `job_uid` of the test job
   * @returns `true` if all of the tests in the STB-Tester test job completed successfully; otherwise, `false`
   */
  public async isTestJobSuccessfulAsync(jobUid: string): Promise<boolean> {
    const endpointUrl = `api/v2/jobs/${jobUid}`;

    try {
      const { data }: AxiosResponse<IJobsResponseJson> =
        await this._axiosInstance.get(endpointUrl);
      const resultCounts: IResultCounts = data.result_counts;

      return resultCounts.fail === 0 && resultCounts.error === 0;
    } catch (error) {
      throw getCustomError(error as StbtAxiosError, this._stbtAuthToken);
    }
  }

  /**
   * Returns the test results for every test in the test job with the STBT `job_uid` of `jobUid`.
   *
   * STB-Tester endpoint documentation: {@link https://stb-tester.com/manual/rest-api-v2#get-list-of-test-results}
   *
   * @param jobUid - The STB-Tester `job_uid` of the test job
   * @returns The test results for every test in the test job with the STBT `job_uid` of `jobUid`.
   */
  public async getTestResultsForTestJobAsync(
    jobUid: string,
  ): Promise<ITestResult[]> {
    const endpointUrl = `api/v2/results`;

    try {
      const { data }: AxiosResponse<ITestResultJson[]> =
        await this._axiosInstance.get(endpointUrl, {
          params: { filter: `job:${jobUid}` },
        });

      return data.map((result) => ({
        endTime: result.end_time,
        failureReason: result.failure_reason ?? undefined,
        jobUid: result.job_uid,
        result: result.result,
        resultId: result.result_id,
        resultUrl: result.result_url,
        startTime: result.start_time,
        testPackSha: result.test_pack_sha,
        triageUrl: result.triage_url,
      }));
    } catch (error) {
      throw getCustomError(error as StbtAxiosError, this._stbtAuthToken);
    }
  }

  /**
   * Retrieves all of the BDD test results (`steps.json` file contents) from the STB-Tester test job with UID `jobUid`
   * as a single array of `IStepsResults` objects.
   *
   * @param jobUid - The STB-Tester `job_uid` of the test job
   * @returns An array containing the steps results from all of the `steps.json` files associated with a given `job_id`
   */
  public async getJobBddStepsResultsAsync(
    jobUid: string,
  ): Promise<IStepsResult[]> {
    const resultIds: string[] = await this._getResultIdsForTestJobAsync(jobUid);

    return Promise.all(
      resultIds.map((resultId) => this.getTestBddStepsResultAsync(resultId)),
    );
  }

  /**
   * Retrieves the BDD steps test results (`steps.json` file contents) for the STBT test case execution with an STBT `result_id`
   * of `resultId`.
   *
   * @param resultId - The STB-Tester `result_id` of the test case execution.
   * @returns The BDD steps test results from the `steps.json` file associated with the given `resultId`.
   */
  public async getTestBddStepsResultAsync(
    resultId: string,
  ): Promise<IStepsResult> {
    const stepsFile: StepsFileFormat = (await this.getArtifactFromTestRunAsync(
      resultId,
      'steps.json',
    )) as StepsFileFormat;

    // A steps.json file contains a single-element array; that element is the actual steps result JSON that we want.
    return stepsFile[0];
  }

  /**
   * Returns the STBT `result_id`s for every test in the test job with the STBT `job_uid` of `jobUid`.
   *
   * STB-Tester endpoint documentation: {@link https://stb-tester.com/manual/rest-api-v2#get-list-of-test-results}
   *
   * @param jobUid - The STB-Tester `job_uid` of the test job
   * @returns The STBT `result_id`s for every test in the test job with the STBT `job_uid` of `jobUid`.
   */
  private async _getResultIdsForTestJobAsync(
    jobUid: string,
  ): Promise<string[]> {
    const endpointUrl = `api/v2/results`;

    try {
      const { data }: AxiosResponse<ITestResultJson[]> =
        await this._axiosInstance.get(endpointUrl, {
          params: { filter: `job:${jobUid}` },
        });

      return data.map((result) => result.result_id);
    } catch (error) {
      throw getCustomError(error as StbtAxiosError, this._stbtAuthToken);
    }
  }

  /**
   * Retrieves an artifact named `filename` from the STB-Tester test run result with id `result_id`.
   *
   * STB-Tester endpoint documentation: {@link https://stb-tester.com/manual/rest-api-v2#get-an-artifact-produced-during-a-test-run}
   *
   * @param resultId - The STB-Tester `result_id` of the test run
   * @param filename - The name of the artifact attached to the STB-Tester run
   * @returns the contents of the file whose name is `filename`
   */
  public async getArtifactFromTestRunAsync(
    resultId: string,
    filename: string,
  ): Promise<unknown> {
    const endpointUrl = `api/v2/results/${resultId}/artifacts/${filename}`;

    try {
      const { data }: AxiosResponse<unknown> = await this._axiosInstance.get(
        endpointUrl,
      );

      return data;
    } catch (error) {
      throw getCustomError(error as StbtAxiosError, this._stbtAuthToken);
    }
  }
}
