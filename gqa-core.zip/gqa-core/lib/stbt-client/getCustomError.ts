// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { AxiosError } from 'axios';
import HttpStatus from 'http-status';
import { logger } from '../../support/logger';

/**
 * The type of errors thrown by Axios when talking to the STBT REST API.
 */
export type StbtAxiosError = (
  | AxiosError<string, unknown>
  | AxiosError<{ message: string }, unknown>
) & { hostname?: string };

/**
 * Safely stringifies the object `obj`, ignoring circular references
 *
 * @param obj - The object to be stringified.
 * @returns - A JSON string representing `obj`
 */
function safeStringify(obj: object): string {
  const cache: unknown[] = [];

  return JSON.stringify(obj, (key, value) => {
    if (typeof value === 'object' && value !== null) {
      // Duplicate reference found, discard key
      if (cache.includes(value)) {
        return '__CIRCULAR_REFERENCE__';
      }

      // Store value in our collection
      cache.push(value);
    }
    // eslint-disable-next-line consistent-return
    return value;
  });
}

/**
 * Temporarily logging all unhandled Axios errors to make sure we've captured the actual outputs for our testing purposes.
 *
 * @param originalAxiosError - The Axios error object.
 */
function reportUnhandledAxiosError(originalAxiosError: StbtAxiosError): void {
  const axiosError: StbtAxiosError = { ...originalAxiosError };

  axiosError.request = undefined;

  if (axiosError.response) {
    axiosError.response.request = undefined;
    // @ts-ignore We are setting this to an invalid value to avoid a circular reference.
    axiosError.response.config = undefined;
  }

  logger.warn(
    'An unrecognized Axios error was returned from an attempt to call the STBT REST API:',
    safeStringify(axiosError),
  );
}

/**
 * Gets the STB-Tester error message returned in the `message` property of the response body, if
 * it is present. Otherwise, returns `undefined`.
 *
 * @param axiosError - An error thrown by Axios when an HTTPS request fails.
 * @returns The `message` property of the response body, if it is present; otherwise, `undefined`.
 */
function getStbtErrorMessage(axiosError: StbtAxiosError): string | undefined {
  return typeof axiosError.response?.data === 'object' &&
    typeof axiosError.response?.data?.message === 'string'
    ? axiosError.response?.data?.message
    : undefined;
}

/**
 * Throws an appropriate `Error` when a request to an endpoint throws an error due to an unexpected
 * HTTPStatus code.
 *
 * @param axiosError - An Axios error object (see {@link https://axios-http.com/docs/handling_errors}).
 * @param stbtAuthToken - The STBT auth token, displayed (in redacted form) to facilitate debugging of auth issues.
 * @returns A custom `Error` describing the unexpected HTTPStatus code.
 */
export function getCustomError(
  axiosError: StbtAxiosError,
  stbtAuthToken: string,
): Error {
  if (axiosError.response === undefined) {
    if (axiosError.code === 'ECONNREFUSED') {
      return new Error('STB-Tester REST API URL was not provided');
    }
    if (axiosError.code === 'ENOTFOUND') {
      return new Error(
        `STB-Tester REST API URL "${axiosError.hostname}" is invalid`,
      );
    }
  } else {
    const { status } = axiosError.response;

    switch (status) {
      case HttpStatus.BAD_REQUEST: {
        // 400
        const stbtErrorMessage: string | undefined =
          getStbtErrorMessage(axiosError);

        if (stbtErrorMessage) {
          return new Error(stbtErrorMessage);
        }
        break;
      }
      case HttpStatus.FORBIDDEN: {
        // 403
        const firstFive = stbtAuthToken.substring(0, 5);
        const lastFive = stbtAuthToken.substring(stbtAuthToken.length - 5);
        const redactedMiddle = '*'.repeat(22);
        const redactedAuthToken = `${firstFive}${redactedMiddle}${lastFive}`;

        return new Error(`STBT auth token "${redactedAuthToken}" is invalid`);
      }
      case HttpStatus.NOT_FOUND: /* 404 */ {
        const endpointUrl: string | undefined = axiosError.config?.url;
        const htmlErrorMessage: string | undefined =
          typeof axiosError.response?.data === 'string'
            ? axiosError.response?.data
            : undefined;
        const stbtErrorMessage: string | undefined =
          getStbtErrorMessage(axiosError);

        if (endpointUrl && htmlErrorMessage?.includes('404 Not Found')) {
          return new Error(
            `STBT REST API endpoint "${endpointUrl}" was not found`,
          );
        }

        const invalidGitRevisionRegExp =
          /^Unknown test_pack_revision '([^']*)'$/;

        const match = stbtErrorMessage?.match(invalidGitRevisionRegExp);

        if (match) {
          return new Error(`Invalid Git revision specifier "${match[1]}"`);
        }
        break;
      }
      case HttpStatus.CONFLICT: /* 409 */ {
        const stbtErrorMessage: string | undefined =
          getStbtErrorMessage(axiosError);

        if (stbtErrorMessage) {
          throw new Error(stbtErrorMessage);
        }
        break;
      }
      case HttpStatus.TOO_MANY_REQUESTS: /* 429 */ {
        return new Error('STB-Tester request rate limits exceeded');
      }
      case HttpStatus.INTERNAL_SERVER_ERROR: /* 500 */ {
        try {
          const requestBodyString: string | undefined = axiosError.config
            ?.data as string | undefined;

          if (requestBodyString !== undefined) {
            const requestBody: Record<string, unknown> =
              JSON.parse(requestBodyString);
            const requestedNodeId: string | undefined =
              typeof requestBody === 'object' && requestBody !== null
                ? (requestBody as Record<string, string | undefined>).node_id
                : undefined;

            if (requestedNodeId) {
              return new Error(
                `Internal Server Error from STB-Tester. This may indicate that the STBT node ID "${requestedNodeId}" is invalid`,
              );
            }
          } else {
            logger.log(
              'Could not parse node id from body of request. This indicates some other type of internal server error, or that the node id was in the URL of a GET request.',
            );
          }
        } catch (error) {
          logger.log(
            'Error parsing INTERNAL_SERVER_ERROR to get the requested STBT node id. This indicates some other type of internal server error.',
          );
        }
        break;
      }
      case HttpStatus.SERVICE_UNAVAILABLE: /* 503 */ {
        const stbtErrorMessage: string | undefined =
          getStbtErrorMessage(axiosError);

        if (stbtErrorMessage) {
          return new Error(stbtErrorMessage);
        }

        logger.log('SERVICE_UNAVAILABLE error without an error message!');
        break;
      }
      default: {
        logger.log(`Unrecognized HTTP response status code "${status}"`);
      }
    }
  }

  reportUnhandledAxiosError(axiosError);

  return axiosError;
}
