// Copyright text placeholder, Warner Bros. Discovery, Inc.

export interface IJiraConfig {
  /** directory to store the generated JSON file for each test failure */
  logDir: string;

  /** API URL of the Jira Server */
  apiUrl: string;

  /** user name for JIRA auth */
  username: string;

  /** password for JIRA auth */
  password: string;

  /** name of the JIRA project */
  project: string;

  /** JIRA epic key the bug should be filed under; ex: GQA-13657 */
  epic: string;

  /** default bug priority */
  priority: string;

  /**
   * list of status from which bugs are considered closed
   *
   * this has the effect of bug search with bugId where the status in this list will be excluded
   * For example: (bug either in DONE or CANCELLED status are excluded from search)
   *
   * jql: "Project = GQA AND issuetype = Bug and cf[10202] ~ 'md5' AND status not in ( 'DONE','CANCELLED')
   */
  inactiveBugStatus: string[];

  /**
   * callback function to customize the Jira payload
   *
   * @param jiraPayload - JiraPayload that we are going to send to JIRA API
   * @returns JIRAPayload payload that we will send to JIRA API
   */
  customizeNewBugPayload: (jiraPayload: unknown) => unknown;
}
