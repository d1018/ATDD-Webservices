// Copyright text placeholder, Warner Bros. Discovery, Inc.

export interface IJiraTestFailureData {
  /** MD5 hash of `stackMsg`, which usually holds the full stack trace from the test scenario failure */
  bugId: string;

  /** general note for the bug */
  note: string[];

  /** test failure priority */
  priority: string;

  /** test session Id */
  sessionId: string;

  /** test session url */
  sessionUrl: string;

  /** GHA workflow link where this test is executed; only available if this test is run in GHA job */
  ghaWorkflowUrl: string;

  /** The step description that fails the test scenario */
  failedStepDescription: string;

  /** failed step duration, in format of YYm XXs */
  failedStepDuration: string;

  /** Failure message; normally a stack message collected by Cucumber when test fails */
  stackMsg: string;

  /** JIRA project name. Example: "DTC" */
  project: string;

  /** Test device */
  device: string;

  /** Test device name */
  deviceName: string;

  /** Test platform. Example: "webdriver" */
  platform: string;

  /** Geolocation of the test session */
  geolocation: string;

  /** summary of the device info */
  deviceInfoSummary: string;

  /** Test Device Model */
  deviceModel: string;

  /** Test Environment */
  environment: string;

  /** Test Type */
  testType: string;

  /** full path of the SSM file used */
  ssmFile: string;

  /**
   * The combined BDD tags that apply to this test scenario.
   * These are the combination of  the tags of the feature (if any), the tags
   * of the nested scenarios between the feature and this test scenario (if any),
   * and the tags on this test scenario itself (if any).
   * For example, if the feature has the tag "\@P1" and this scenario has the tag "\@P2",
   * this property will have the value "\@P1 \@P2".
   */
  testTags: string;

  /** full path to the feature file in which the test scenario is defined */
  featureFile: string;

  /** name of the feature file in which the test scenario is defined */
  featureName: string;

  /** description of the feature file in which the test scenario is defined */
  featureDescription: string;

  /** name of the test scenario */
  scenarioName: string;

  /** description of the test scenario */
  scenarioDescription: string;

  /**
   * Test Description, containing:
   * 1. feature name and description
   * 2. scenario name description
   * 3. full set of step description and each step test result in the scenario
   */
  testDescription: string[];

  /** time of the failure */
  timestamp: string;

  /**  raw data we want to tag along for more in-depth investigation offline */
  raw?: {
    /** result object from cucumber for the test failure */
    result: unknown;

    /**
     * true if the test failure will be retried by cucumber runtime
     * false if the test fails after all retry are exhausted
     */
    willBeRetried?: boolean;

    /** pickle object from the cucumber for the failed test scenario */
    pickle: unknown;

    /**  gherkinDocument object from the cucumber that contains the failed test scenario */
    gherkinDocument: unknown;
  };
}
