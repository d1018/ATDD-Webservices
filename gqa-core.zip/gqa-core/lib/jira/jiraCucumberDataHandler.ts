// Copyright text placeholder, Warner Bros. Discovery, Inc.

import crypto from 'crypto';
import { v4 } from 'uuid';
import { isAbsolute, join, extname } from 'path';
import { pathExists, writeFile, stat, mkdir } from 'fs-extra';
import Duration from 'duration';

import {
  IWorld,
  ITestStepHookParameter,
  ITestCaseHookParameter,
} from '@cucumber/cucumber';
import {
  TimeConversion,
  Duration as CucumberDuration,
} from '@cucumber/messages';
import {
  doc,
  p,
  bulletList,
  listItem,
  strong,
  codeBlock,
  inlineCard,
  expand,
  text as adfText,
} from '@atlaskit/adf-utils/builders';

import { DocNode, ListItemDefinition } from '@atlaskit/adf-schema';

import { logger } from '../../support/logger';
import { Status } from '../cucumberDefinition';
import { IJiraConfig } from './IJiraConfig';
import { IJiraTestFailureData } from './IJiraTestFailureData';
import { jiraDataConfig } from './jiraDataHandlerConfig';

import {
  runtimeDevice,
  runtimePlatform,
  runtimeGeolocation,
  runtimeDeviceModel,
  runtimeDeviceName,
  runtimeProject,
  runTimeEnvironment,
  runTimeTestType,
  runTimeSSMFile,
  getJiraConfigFile,
} from '../../support/runtimeConfig';

/**
 * create a listItem object per the adf schema
 *
 * @param name - name of item
 * @param content - data of the item, rendered as javascript codeblock
 * @returns listItem object
 */
export const createListItemCodeBlockNode = (
  name: string,
  content: string,
): ListItemDefinition =>
  listItem([
    p(strong(`${name}:`)),
    codeBlock({ language: 'javascript' })(adfText(content)),
  ]);

/**
 * create a doc object per the adf schema
 * reference: JIRA unique format: https://atlaskit.atlassian.com/packages/editor/adf-utils
 *
 * @param data - data object that formulate the doc object
 * @returns a doc node object
 */
export const createJiraBugDescriptionJiraDocNode = (data: {
  /* object that contains failure data */
  failureData: IJiraTestFailureData;
  /* true if new bug or false for an existing bug */
  newBug: boolean;
}): DocNode => {
  const { failureData, newBug } = data;

  const essentialInfo = newBug
    ? jiraDataConfig.essentialInfoForDescription
    : jiraDataConfig.essentialInfoForComment;

  // fields that are rendered as codeblock
  const renderedAsCodeBlock = jiraDataConfig.renderAsBlock;

  // list above the expanded section
  const adfbList = bulletList();

  // list that is wrapped inside a expanded section
  const adfexpandBlist = bulletList();

  // expanded section that wraps the "adfexpandBlist" section
  const adtExpand = expand({ title: jiraDataConfig.expandTitle })(
    adfexpandBlist,
  );

  adfbList.content = [];
  adfexpandBlist.content = [];

  // go thru each data attribute and render them accordingly
  Object.entries(failureData).forEach(([key, value]) => {
    if (jiraDataConfig.skipInfo.includes(key)) {
      // skip logging for this field
      return;
    }

    // rendered either in the main list or in the list that is wrapped inside an expanded section
    const list = essentialInfo.includes(key) ? adfbList : adfexpandBlist;

    let val = Array.isArray(value) ? value.join('\n') : value.trim();

    if (!val) {
      // JIRA doesn't like empty text; we will render a template text when data isn't
      // available
      val = jiraDataConfig.notAvaibleText;
    }

    if (/^((https|http):\/\/|www.)/.test(val)) {
      // if the val is a url, rendered it as an "inlineCard"
      list.content.push(
        listItem([p(strong(`${key}:`), ' ', inlineCard({ url: val }))]),
      );
    } else if (renderedAsCodeBlock.includes(key)) {
      // redner as a code block
      list.content.push(
        listItem([
          p(strong(`${key}:`)),
          codeBlock({ language: 'javascript' })(adfText(val)),
        ]),
      );
    } else {
      // render as regular bold text
      list.content.push(listItem([p(strong(`${key}:`), ' ', val)]));
    }
  });

  // intentionally keep this; used for debugging
  // console.log(JSON.stringify(doc(adfbList, adtExpand)));

  if (newBug) {
    return doc(adfbList, adtExpand);
  }

  // stuff the timestamp into the template text for new comment entry
  const commentMsg = jiraDataConfig.newCommentHeader.replace(
    'TIME_STAMP',
    failureData.timestamp,
  );

  return doc(p(strong(commentMsg)), adfbList, adtExpand);
};

/**
 * get session Id and url for the test session
 *
 * @param world - world object from Cucumber-js
 * @param platformName - platform name under test
 * @returns object containing session details
 */
const getSessionInfo = (
  world: IWorld,
  platformName: string,
):
  | { sessionId: string; sessionPublicUrl: string; deviceInfoSummary: string }
  | undefined => {
  const appiumHSDevices = ['appletv', 'androidtv', 'firetab', 'firetv'];

  const deviceToRun = runtimeDevice().toLowerCase();
  const isAppiumHSDevices = appiumHSDevices.includes(deviceToRun);

  let platform;
  let sessionInfo;

  if (platformName === 'suitest') {
    logger.log('SessionId is not supported yet for suitest platform');
    return undefined;
  }

  // get the driver class that we have to make use to get remote device session info
  if (platformName === 'webdriver') {
    // eslint-disable-next-line global-require
    platform = require('../../support/platform/BrowserActions');
  } else if (platformName === 'appium') {
    // eslint-disable-next-line global-require
    platform = require('../../support/platform/MobileActions');
  }

  if (platform) {
    const [sessionSerialId, publicUrl] = isAppiumHSDevices
      ? [platform.getHsSessionId(), platform.getHsSessionUrl()]
      : [platform.getBsSessionId(), platform.getBsPublicUrl()];

    sessionInfo = {
      sessionId: sessionSerialId,
      sessionPublicUrl: publicUrl,
      deviceInfoSummary: platform.deviceInfoSummary(),
    };
  }

  return sessionInfo;
};

/**
 * return a string that presents the duration for a test scenario execution
 *
 * @param  durationMsg - Cucumber Result.duration object
 * @returns a string that looks like 'XXXmYYY.ZZZs'
 */
export const getDurationSummary = (durationMsg: CucumberDuration): string => {
  const start = new Date(0);
  const end = new Date(TimeConversion.durationToMilliseconds(durationMsg));
  const interval = new Duration(start, end);

  return `${interval.toString('%Ms m %S . %L s').replace(/ /g, '')}`;
};

/**
 * load a JIRA config file into an object
 *
 * @returns object containing JIRA config
 */
const readJiraConfig = async (): Promise<IJiraConfig | undefined> => {
  let jiraConfigFile: string = getJiraConfigFile();

  if (jiraConfigFile) {
    if (!isAbsolute(jiraConfigFile)) {
      // form a full file path if user specify a relative path
      jiraConfigFile = join(process.cwd(), jiraConfigFile);
    }

    if (!(await pathExists(jiraConfigFile))) {
      throw new Error(
        `the Jira config file does not exists: ${jiraConfigFile}`,
      );
    }

    if (extname(jiraConfigFile) !== '.js') {
      throw new Error(
        `the Jira config file should be a script file, with file extension .js`,
      );
    }

    // we will try to load the Jira config file as a JS script file
    try {
      // eslint-disable-next-line import/no-dynamic-require, global-require
      const jiraConfig = require(jiraConfigFile);

      logger.log(`Jira config loaded from ${jiraConfigFile}`);
      return jiraConfig;
    } catch (ex) {
      logger.error(`failed to load Jira config file from ${jiraConfigFile}`);
    }
  }
  return undefined;
};

/**
 * generate a readable timestamp for current time (PST)
 * example: 02/04/2023, 11:11:11 AM PST
 *
 * @returns readable string to represent the current time
 */
const generateReadableTimestamp = (): string =>
  new Date().toLocaleString('en-us', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZoneName: 'short',
  });

/**
 * generate a file on a specific directory
 *
 * @param jiraConfigObj - Jira config
 * @param dataObj - object to write to file
 */
const writeJiraDataFile = async (
  jiraConfigObj: IJiraConfig,
  dataObj: IJiraTestFailureData,
): Promise<void> => {
  const cachedFile = join(jiraConfigObj.logDir, `jira.${v4()}.json`);

  try {
    await writeFile(cachedFile, JSON.stringify(dataObj, undefined, 2));
  } catch (ex) {
    logger.error(ex);
    logger.error(
      `failed to write test failure data to cached file ${cachedFile}`,
    );
  }
};

/**
 * 1. read the Jira config file
 * 2. create an object containing jira config
 * 3. create a specified directory (that stores the failure JSON files) if it doesn't exist
 *
 * @returns resolve to a jira config object read from process.env.JIRA_CONFIG_FILE
 */
export const initJiraConfig = async (): Promise<IJiraConfig | undefined> => {
  let jiraConfigObj = await readJiraConfig();

  // we read the config alright; but let's make sure the log directory exists
  if (jiraConfigObj && jiraConfigObj.logDir) {
    // eslint-disable-next-line prefer-destructuring
    let logDir = jiraConfigObj.logDir;

    if (!isAbsolute(logDir)) {
      // form a full file path if user specify a relative path
      logDir = join(process.cwd(), logDir);
    }

    logger.log(`Jira config log dir: ${logDir}`);

    try {
      // create the target directory if it doesn't exist
      if (
        !(await pathExists(logDir)) ||
        !(await (await stat(logDir)).isDirectory())
      ) {
        logger.warn(
          `logDir does not exists:${jiraConfigObj.logDir}; we will try to create the target directory!`,
        );
        await mkdir(logDir);
      }
    } catch (ex) {
      // disable JIRA logging if we fail to create the log dir for cached file
      logger.error(ex);
      logger.error(`failed to create logDir: ${logDir}`);
      logger.warn(`Jira bug filing will be disabled!`);
      jiraConfigObj = undefined;
    }
  }
  return jiraConfigObj;
};

// cache and create necessary mapping from cucumber world object in order to reconstruct proper test description
// and attach to Cucumber world object
export const addTestDefinitionToJiraCache = ({
  cucumberWorld,
  cucumberBeforeHookParameter,
}: {
  cucumberWorld: IWorld;
  cucumberBeforeHookParameter: ITestCaseHookParameter;
}): void => {
  const world = cucumberWorld;
  const { gherkinDocument } = cucumberBeforeHookParameter;

  if (world) {
    // a dictionary to key test step result with its test step id
    world.stepTestResultLookup = {};

    // a dictionary to key test step definition with its test step id
    world.stepDefLookup = {};

    // a dictionary to key scenario and background definition with its test step id
    world.scenarioAndBackgroundDefLookup = {};

    if (gherkinDocument && gherkinDocument.feature) {
      // save off feature name and description for reporting later
      const { name, description, children } = gherkinDocument.feature;

      world.featureName = name;
      world.featureDescription = description;

      // build a key value pair of [step definition Id: step definition data]
      if (Array.isArray(children)) {
        children.forEach((child) => {
          [child.background, child.scenario].forEach((testData) => {
            if (testData) {
              if (testData.id) {
                world.scenarioAndBackgroundDefLookup[testData.id] = testData;
              }
              if (Array.isArray(testData.steps)) {
                testData.steps.forEach((step: { id: string }) => {
                  world.stepDefLookup[step.id] = step;
                });
              }
            }
          });
        });
      }
    }
  }
};

// cache the failed step step ID and attach to Cucumber world object
export const addFailedStepTestIdToJiraCache = (
  jiraConfigObj: IJiraConfig | undefined,
  {
    cucumberWorld,
    cucumberAfterStepHookParameter,
  }: {
    cucumberWorld: IWorld;
    cucumberAfterStepHookParameter: ITestStepHookParameter;
  },
): void => {
  const world = cucumberWorld;
  const { result, pickleStep } = cucumberAfterStepHookParameter;

  if (world && jiraConfigObj) {
    // build a key value pair of [pickle step Id: pickle step test result]
    world.stepTestResultLookup[pickleStep.id] = result;
    if (result.status === Status.FAILED) {
      // save the pickle step Id that fails
      world.failedStepId = pickleStep.id;
    }
  }
};

/**
 * This function sanitizes the stack message and creates the hash.
 *
 * @param errorMsg - stack message
 * @returns hashValue
 */
export const calMD5 = (errorMsg: string): string => {
  const stackTrace = errorMsg.replaceAll(process.cwd(), '');

  const hashValue = crypto.createHash('md5').update(stackTrace).digest('hex');

  return hashValue;
};

// create a JSON file for a test scenario that has failed
export const createJiraDataFile = async (
  jiraConfigObj: IJiraConfig | undefined,
  {
    cucumberWorld,
    cucumberAfterHookParameter,
  }: {
    cucumberWorld: IWorld;
    cucumberAfterHookParameter: ITestCaseHookParameter;
  },
): Promise<void> => {
  const world = cucumberWorld;
  const { result, pickle, willBeRetried, gherkinDocument } =
    cucumberAfterHookParameter;

  // only log failure that has finished retried (or never set to be re-tried)
  if (
    jiraConfigObj &&
    world &&
    !willBeRetried &&
    result &&
    result.status === Status.FAILED
  ) {
    if (!pickle) {
      logger.error(
        'Please investigate: no pickle data from cucumber-js; skipped logging failures for JIRA bug filing!',
      );
      return;
    }

    const { uri, name, steps } = pickle;

    // log all necessary info for the failed test scenario

    // eslint-disable-next-line prefer-destructuring
    const featureName = world.featureName;
    const featureDescription = world.featureDescription.trim();
    const featureFile = uri;
    const scenarioName = name;
    const testDescription = [];

    let testTags = '';
    let scenarioDescription = '';
    let failedStepDescription = '';

    // log cucumber tags as a single string
    if (Array.isArray(pickle.tags) && pickle.tags.length) {
      const tags = pickle.tags.reduce((acc, val) => `${acc} ${val.name}`, '');

      testTags = tags.trim();
      testDescription.push(`Tags: ${testTags}`);
    }

    // log feature details
    testDescription.push(`Feature Name: ${featureName}`);
    testDescription.push(`Feature Description: ${featureDescription}`);
    testDescription.push(`Feature file: ${featureFile}`);
    testDescription.push(`Scenario: ${name}`);

    // log scenario description:
    // find the scenario definition from our current step nodeId
    // so that we find the scenario description
    if (pickle.astNodeIds) {
      const pickleNodeIds = pickle.astNodeIds.filter(
        (nodeId) => nodeId in world.scenarioAndBackgroundDefLookup,
      );

      // 3b: get the scenario description
      if (
        pickleNodeIds &&
        world.scenarioAndBackgroundDefLookup[pickleNodeIds[0]] &&
        typeof world.scenarioAndBackgroundDefLookup[pickleNodeIds[0]]
          .description === 'string'
      ) {
        scenarioDescription =
          world.scenarioAndBackgroundDefLookup[
            pickleNodeIds[0]
          ].description.trim();
      }
    }

    testDescription.push('Steps:');
    steps.forEach(({ text, id, astNodeIds }, idx) => {
      // get the step "keyword" name as well as each individual step test result to
      // construct the step name as such:
      // "1: Given Today is a good day (PASSED)",
      // "2: Then Do A (FAILED)",
      // "3: Then Do B (SKIPPED)",
      // "4: Then Do C (SKIPPED)"

      // several hoops to build a detailed, meaningful step description string

      // 1: start off with our step description (one without cucumber keyword such as Given/Then/And etc)
      let stepDescription = text;

      // 2: find the step definition from our current step nodeId
      //    so that we can build a detailed text description that has format like:
      //    <Step-number>. <Step-Keyword> <Text-Description> (<Test-Step-Result>)
      //    ex: 2. Given I am OK (FAILED)
      const nodeIds = astNodeIds.filter(
        (nodeId) => nodeId in world.stepDefLookup,
      );

      // 3: get the step keyword from the step definition and build that into step description
      if (
        nodeIds &&
        world.stepDefLookup[nodeIds[0]] &&
        typeof world.stepDefLookup[nodeIds[0]].keyword === 'string'
      ) {
        stepDescription = `${world.stepDefLookup[
          nodeIds[0]
        ].keyword.trim()} ${text}`;
      }

      // 4: put the test step number AND test step result into step description as well
      if (world.stepTestResultLookup && id in world.stepTestResultLookup) {
        // save the failed step description
        if (world.stepTestResultLookup[id].status === Status.FAILED) {
          failedStepDescription = stepDescription;
        }

        stepDescription = `${idx + 1}: ${stepDescription} (${getDurationSummary(
          world.stepTestResultLookup[id].duration,
        )}, ${world.stepTestResultLookup[id].status})`;
      } else {
        // if we do not get a test result, that means the test step is skipped...
        stepDescription = `${idx + 1}: ${stepDescription} (${Status.SKIPPED})`;
      }

      // 5: all good: we should have turned a string like:
      //    Given I am OK
      // to:
      //    2. Given I am OK (FAILED)
      testDescription.push(stepDescription);
    });

    const note: string[] = [];

    // get the GHA workflow url (these env vars should only be set if the test is run as part of GitHub action workflow job)
    const { GITHUB_SERVER_URL, GITHUB_REPOSITORY, GITHUB_RUN_ID } = process.env;

    const ghaWorkflowUrl =
      GITHUB_SERVER_URL && GITHUB_REPOSITORY && GITHUB_RUN_ID
        ? `${GITHUB_SERVER_URL}/${GITHUB_REPOSITORY}/actions/runs/${GITHUB_RUN_ID}`
        : jiraDataConfig.notAvaibleText;

    const stackMsg = result.message || jiraDataConfig.notAvaibleText;

    const sessionInfo = getSessionInfo(world, runtimePlatform());

    // try to parse out the bug priority from the test tags
    const match = testTags.match(/(@[Pp][0-9])/g);

    // eslint-disable-next-line prefer-destructuring
    let priority = jiraConfigObj.priority;

    if (Array.isArray(match) && match.length) {
      // the last match is the tag defined in the scenario level; let's use it
      priority = match[match.length - 1].replace(/@/g, '').toUpperCase();
      note.push(`priority is determined from cucumber tags: ${priority}`);
    } else {
      note.push(`priority is set from default setting: (${priority})`);
    }

    const jiraDataObj: IJiraTestFailureData = {
      note,
      bugId: calMD5(stackMsg),
      priority,
      project: runtimeProject(),
      device: runtimeDevice(),
      deviceName: runtimeDeviceName(),
      platform: runtimePlatform(),
      geolocation: runtimeGeolocation(),
      deviceModel: runtimeDeviceModel(),
      environment: runTimeEnvironment(),
      testType: runTimeTestType(),
      ssmFile: runTimeSSMFile(),
      testTags,
      featureFile,
      featureName,
      featureDescription,
      scenarioName,
      scenarioDescription,
      testDescription,
      failedStepDescription,
      failedStepDuration: getDurationSummary(result.duration),
      stackMsg: stackMsg.replaceAll(process.cwd(), ''),
      sessionId: sessionInfo?.sessionId || jiraDataConfig.notAvaibleText,
      sessionUrl:
        sessionInfo?.sessionPublicUrl || jiraDataConfig.notAvaibleText,
      ghaWorkflowUrl,
      timestamp: generateReadableTimestamp(),
      deviceInfoSummary:
        sessionInfo?.deviceInfoSummary || jiraDataConfig.notAvaibleText,
      raw: {
        result,
        willBeRetried,
        pickle,
        gherkinDocument,
      },
    };

    await writeJiraDataFile(jiraConfigObj, jiraDataObj);
  }
};
