// Copyright text placeholder, Warner Bros. Discovery, Inc.

export interface IJiraDataHandlerConfig {
  /** header text for a comment entry on an existing bug */
  newCommentHeader: string;

  /** bold text provided by user from the config file to show as additional black in JIRA bug description */
  additionalNoteHeader: string;

  /** text to display when data isn't available for a data field */
  notAvaibleText: string;

  /** title for the expand section in JIRA bug description and comment section */
  expandTitle: string;

  /** list of fields that we should render in a codeblock */
  renderAsBlock: string[];

  /** name of the field that we should NOT log to JIRA bug description */
  skipInfo: string[];

  /**
   * list of essential fields that we list as bullet list (outside of the expanable buttlet list)
   * in JIRA bug desciption.
   * anything that isn't in the essentialInfo list will be nested inside an "expand" in the Jira bug description
   */
  essentialInfoForDescription: string[];

  /**
   * list of essential fields that we list as bullet list (outside of the expanable buttlet list)
   * in JIRA bug comment
   * anything that isn't in the essentialInfo list will be nested inside an "expand" in the Jira bug description
   */
  essentialInfoForComment: string[];
}

/**
 * default configuration for how we render the bug info in JIRA
 */
export const jiraDataConfig: IJiraDataHandlerConfig = {
  newCommentHeader: 'Test failed with the same stack message on TIME_STAMP:',

  additionalNoteHeader: 'Additional Notes',

  notAvaibleText: 'info unavailable!',

  expandTitle: 'more details...',

  renderAsBlock: ['stackMsg', 'testDescription', 'note', 'deviceInfoSummary'],

  skipInfo: ['raw', 'timestamp'],

  essentialInfoForDescription: [
    'project',
    'device',
    'platform',
    'geolocation',
    'deviceName',
    'environment',
    'testType',
    'ghaWorkflowUrl',
    'sessionId',
    'sessionUrl',
  ],

  essentialInfoForComment: ['ghaWorkflowUrl', 'sessionId', 'sessionUrl'],
};
