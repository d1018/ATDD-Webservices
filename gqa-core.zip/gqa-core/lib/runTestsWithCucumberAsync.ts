// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { join, relative } from 'path';
import { pathExistsSync } from 'fs-extra';
import {
  runCucumber,
  loadConfiguration,
  loadSupport,
  IConfiguration,
} from '@cucumber/cucumber/api';
import { logger } from '../support/logger';
import reportPortalConfig from '../support/rpConfig';

const {
  overrideCucumberLoadConfiguration,
  // need to disable this as cucumberFormatterHandler is not a ts file yet
  // eslint-disable-next-line @typescript-eslint/no-var-requires
} = require('./cucumberFormatterHandler');
const { isFeatureFlagEnabled } = require('../support/runtimeConfig');

export interface ICoreConfig extends Partial<IConfiguration> {
  file: string;
  profiles: string[];
}

/**
 * Executes the selected BDD tests according to the specified Cucumber configuration.
 *
 * @param config - The Cucumber configuration for the test run
 * @returns `true` if all of the tests succeed without error; `false` otherwise
 */
export async function runTestsWithCucumberAsync(
  config?: ICoreConfig,
): Promise<boolean> {
  if (!config) {
    throw new Error('Please specify a valid test config!');
  }

  const { file, profiles } = config;

  let hookFileName = 'injectedHooks.js';

  if (!pathExistsSync(join(__dirname, hookFileName))) {
    // this accounts for Jest test scneario:
    // when we are testing in Jest, Jest does the in memory complication
    // and won't have "injectedHooks.ts" transpiled to "injectedHooks.js" in the disk
    // as such we will load the file as ts if the js file counterpart doesn't exist
    hookFileName = 'injectedHooks.ts';
  }

  const hookFile = join(__dirname, hookFileName);

  // inject our hooks file
  const requireFiles = [
    // we are injecting our hook file here as one of the require files
    hookFile,
  ];

  if (config.require) {
    requireFiles.push(...config.require);
  }

  const format = config.format ? [...config.format] : [];

  // https://github.com/cucumber/cucumber-js/blob/main/docs/api/cucumber.iloadconfigurationoptions.md
  const { runConfiguration } = await loadConfiguration({
    file,
    profiles,
    provided: {
      // TODO: we can sanity some essential config fields here (and override with what we want if we choose to):
      // for now we are just passing thru everything to cucumber-js

      // https://github.com/cucumber/cucumber-js/blob/main/docs/configuration.md
      // ReportPortal reporting via the cucumber agent is optionally loaded based on RP_AGENT_REPORTING
      ...config,
      require: requireFiles,
      ...(isFeatureFlagEnabled('RP_AGENT_REPORTING') && {
        format: [
          ...format,
          `${join(
            __dirname,
            'reportPortalFormatter.js',
          )}:./results/report_url.txt`,
        ],
      }),
      ...(isFeatureFlagEnabled('RP_AGENT_REPORTING') && {
        formatOptions: [{ snippetInterface: 'synchronous' }],
      }),
    },
  });

  if (isFeatureFlagEnabled('RP_AGENT_REPORTING')) {
    logger.log(`ReportPortal Reporting is enabled
    Endpoint: ${reportPortalConfig.endpoint}
    Launch: ${reportPortalConfig.launch}
    Project: ${reportPortalConfig.project}`);
  }

  // modify what the Cucumber has decided to load
  overrideCucumberLoadConfiguration(runConfiguration);

  // load support codes
  const support = await loadSupport(runConfiguration);

  [
    support.beforeTestStepHookDefinitions,
    support.beforeTestCaseHookDefinitions,
    support.beforeTestRunHookDefinitions,
    support.afterTestStepHookDefinitions,
    support.afterTestCaseHookDefinitions,
    support.afterTestRunHookDefinitions,
  ].forEach((defs) => {
    // orders matter here: we want our hook to be the first element
    // of the definition so our before hook will get executed first
    // before any hook that clients may inject during runtime
    if (Array.isArray(defs)) {
      defs.sort((file1, file2) => {
        const relativePath = relative(process.cwd(), hookFile);

        if (file1.uri === relativePath) {
          return -1;
        }
        if (file2.uri === relativePath) {
          return 1;
        }
        return 0;
      });
    }
  });

  // invoke cucumber runtime with support codes and config
  const { success } = await runCucumber({ ...runConfiguration, support });

  return success;
}
