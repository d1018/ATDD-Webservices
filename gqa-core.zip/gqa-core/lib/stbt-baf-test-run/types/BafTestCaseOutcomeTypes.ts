// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { IStepsResult, ITestResult } from '../../stbt-client';

/**
 * The outcomes (STBT test results and BDD steps results) of one STBT test case execution.
 */
export interface IBafTestCaseResults {
  /**
   * Indicates that this result was successfully retrieved from the STBT REST API.
   */
  isFrameworkError: false;

  /**
   * Whether the test case execution succeeded or failed.
   */
  isSuccess: boolean;

  /**
   * The response from the STBT `results/` endpoint for the test case execution.
   */
  testResult: ITestResult;

  /**
   * The BDD steps result from the test case execution; the contents of the `steps.json` file.
   */
  bddStepsResult: IStepsResult;
}

/**
 * The outcomes (STBT test results and BDD steps results) of one STBT test case execution.
 */
export interface IBafFrameworkError {
  /**
   * Indicates whether the result is a BAF framework error.
   */
  isFrameworkError: true;

  /**
   * The error that occurred when executing the test case or retrieving the test case results.
   */
  error: unknown;
}

/**
 * The outcome of a BAF test case execution. This is either:
 *    1. The results returned by the STBT REST API from the test's execution, or
 *    2. A BAF framework error, if the BAF test framework is unable to execute the
 *       test or retrieve its results from the STBT REST API.
 */
export type IBafTestCaseOutcome = IBafTestCaseResults | IBafFrameworkError;

/**
 * Type guard to distinguish `IBafFrameworkError` outcomes from `IBafTestCaseResults` outcomes
 * when filtering a list.
 *
 * @param testCaseOutcome - An `IBafTestCaseOutcome` that might be an `IBafFrameworkError`.
 * @returns `true` if `testCaseOutcome` is an `IBafFrameworkError`.
 */
export function isFrameworkError(
  testCaseOutcome: IBafTestCaseOutcome,
): testCaseOutcome is IBafFrameworkError {
  return testCaseOutcome.isFrameworkError;
}
