// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { IStepsResult, ITestResult } from '../../stbt-client';

/**
 * The summary of the test outcomes in a BAF test run.
 */
export interface IBafTestRunResults {
  /**
   * A BAF test run is considered to be a success if there are no framework errors
   * (`IBafFrameworkError`), and all of the test cases that were executed passed.
   *
   * If retry is enabled, a test case is considered to have passed whether it passed
   * on its first execution, or only on its second execution.
   */
  isSuccess: boolean;

  /**
   * The list of BDD steps results for all of the tests.
   */
  bddStepsResults: IStepsResult[];

  /**
   * The test results objects returned from the `results/` endpoint in the STBT REST API
   * for the tests.
   */
  testResults: ITestResult[];
}
