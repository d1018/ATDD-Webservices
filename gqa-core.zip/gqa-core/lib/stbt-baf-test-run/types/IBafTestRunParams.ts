// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { StbtClient } from '../../stbt-client';

/**
 * The parameters for constructing a `BafTestManager` to manage a BAF test run.
 */
export interface IBafTestRunParams {
  /**
   * The client object that the `BafTestManager` and its associated objects will use
   * to interact with the STBT REST API.
   */
  stbtClient: StbtClient;

  /**
   * The STBT `node_id`s representing the STBT nodes on which the tests will be run.
   * Tests will be distributed across the given nodes, one at a time, such that all nodes
   * are maximally utilized, and nodes are idle only when there are no more unexecuted
   * tests remaining.
   */
  stbtNodeIds: string[];

  /**
   * The BDD test cases (feature/scenario/example) to be executed on the given STBT nodes.
   */
  testCases: string[];

  /**
   * The Git SHA of the version of the `stb-tester-test-pack-hbo` repo from which the tests
   * should be taken.
   */
  testPackRevision: string;

  /**
   * The key/value pairs to be passed as STBT tags to each test case execution that is invoked
   * via the STBT REST API.
   */
  stbtTags: Record<string, string | undefined>;
}
