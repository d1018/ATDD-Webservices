// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { v4 as uuid } from 'uuid';
import { logger } from '../../support/logger';
import { BafTestCase } from './BafTestCase';
import { BafTestResultsFetcher } from './BafTestResultsFetcher';

/**
 * Constructor parameters for a `BafTestRunner`.
 */
export interface IBafTestRunnerParams {
  /**
   * The STBT node_id of the STBT node assigned to the `BafTestRunner`, on which it must run
   * all of its BAF test cases. BAF test cases must be executed sequentially, as only one
   * STBT test at a time can be run on an STBT node.
   */
  stbtNodeId: string;

  /**
   * A queue containing BAF test cases to be executed.
   *
   * Each `BafTestRunner` in the same `BafTestManager` shares this same pending test cases queue,
   * and should take BAF test cases from this queue as its STBT node becomes available,
   * until the queue is empty.
   */
  pendingTestCases: BafTestCase[];

  /**
   * The `BafTestResultsFetcher` that fetches the results for the BAF test cases that have been
   * executed by this `BafTestRunner`.
   *
   * Each `BafTestRunner` in the same `BafTestManager` shares this same test results fetcher,
   * and should hand off each test cases to it when the test case finishes executing on the
   * `BafTestRunner`'s assigned STBT node.
   */
  bafTestResultsFetcher: BafTestResultsFetcher;
}

/**
 * Executes `BafTestCase`s from its pending queue until the queue is empty, handing
 * off each `BafTestCase` to the `BafTestResultsFetcher` as it finishes running.
 *
 * Functions as a pseudo-thread to ensure that only one `BafTestCase` attempts to
 * execute itself on a given STBT node at one time.
 */
export class BafTestRunner {
  /**
   * The test runner's id, for logging and traceability.
   */
  public readonly id: string = uuid().substring(0, 6);

  private readonly _stbtNodeId: string;

  private readonly _pendingTestCases: BafTestCase[];

  private readonly _bafTestResultsFetcher: BafTestResultsFetcher;

  /**
   * Constructs a `BafTestRunner` targeting node `stbtNodeId`, which will take pending
   * test cases one at a time from `pendingTestCasesQueue`, execute them on STBT node `stbtNodeId`,
   * and then hand thenm off to `bafTestResultsFetcher` to have their results fetched.
   *
   * @param stbtNodeId - The STBT node id on which this `BafTestRunner` is permitted
   * to execute `BafTestCase` tests.
   * @param pendingTestCasesQueue - The pending test cases queue of the parent `BafTestManager`, from which
   * this `BafTestRunner` will obtain test cases to be executed.
   * @param bafTestResultsFetcher - The test results fetcher of the parent `BafTestManager`,
   * which will coordinate test results retrieval for every `BafTestCase` in the `BafTestManager`.
   */
  public constructor({
    stbtNodeId,
    pendingTestCases: pendingTestCasesQueue,
    bafTestResultsFetcher,
  }: IBafTestRunnerParams) {
    this._stbtNodeId = stbtNodeId;
    this._pendingTestCases = pendingTestCasesQueue;
    this._bafTestResultsFetcher = bafTestResultsFetcher;
  }

  /**
   * Takes pending test cases off the queue, running them one at a time, until there are no more.
   *
   * As each test case finishes executing, it is handed off (fire-and-forget) to the
   * `BafTestResultsFetcher`, which manages the fetching of test results. Since this can
   *  be done concurrently with test execution, this `BafTestRunner` immediately takes another
   * `BafTestCase` from the queue and executes it on the assigned STBT node.
   */
  public async runTestCasesAsync(): Promise<void> {
    logger.log(
      `BafTestRunner ${this.id} starting to run test cases on STBT node ${this._stbtNodeId}`,
    );

    while (this._pendingTestCases.length > 0) {
      const testCase: BafTestCase = this._pendingTestCases.shift()!;

      logger.log(
        'Starting to run test case',
        // @ts-ignore
        testCase.isA,
        'on node',
        this._stbtNodeId,
      );

      await testCase.runTestAsync(this._stbtNodeId);

      logger.log(
        'Done running test case',
        // @ts-ignore
        testCase.isA,
        'on node',
        this._stbtNodeId,
      );

      this._bafTestResultsFetcher.fetchResults(testCase);
      logger.log(
        'handing off test case',
        // @ts-ignore
        testCase.isA,
        'to bafTestResultsFetcher',
      );
    }
    logger.log(
      `BafTestRunner ${this.id} done running test cases on STBT node ${this._stbtNodeId}`,
    );
  }
}
