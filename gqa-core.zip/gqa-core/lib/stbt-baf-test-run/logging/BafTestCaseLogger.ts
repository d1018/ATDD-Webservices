// Copyright text placeholder, Warner Bros. Discovery, Inc.

import humanizeDuration from 'humanize-duration';
import { assert } from '../../../support/TypeUtils';
import { logger } from '../../../support/logger';
import { IRunTestsRequestBody } from '../../stbt-client';

/**
 * Logs the lifecycle of a BafTestCase.
 */
export class BafTestCaseLogger {
  /**
   * The id of the BAF test run containing this test case execution.
   */
  private readonly _testRunId: string;

  /**
   * The id of this BAF test case execution.
   */
  private readonly _testCaseId: string;

  /**
   * The id prefix prepended to all log messages for this test case.
   */
  private _nodeSpecificPrefix: string;

  /**
   * The id prefix prepended to all log messages for this test case.
   */
  private _nodeAgnosticPrefix: string;

  /**
   * The start time of the BafTestCase's execution.
   */
  private _testExecutionStart?: number;

  /**
   * The start time of test results retrieval.
   */
  private _resultsRetrievalStart?: number;

  /**
   * Create a logger for the execution of a particular BAF test case within a
   * particular BAF test run.
   *
   * @param testRunId - The id of the BAF test run containing this test case execution.
   * @param testCaseId - The id of this BAF test case execution.
   */
  public constructor(testRunId: string, testCaseId: string) {
    this._testRunId = testRunId;
    this._testCaseId = testCaseId;
    this._nodeAgnosticPrefix = `Run ${this._testRunId} test case ${this._testCaseId}`;

    // We append to this later, once we know our node.
    this._nodeSpecificPrefix = this._nodeAgnosticPrefix;
  }

  public logTestExecutionStart(runParams: IRunTestsRequestBody): void {
    this._nodeSpecificPrefix += ` node ${runParams.stbtNodeId}`;
    this._testExecutionStart = Date.now();
    this._logNodeSpecific(`Executing test "${runParams.testCases[0]}".`);
  }

  /**
   * Log that the BAF test case has started executing on the STBT node.
   */
  public logTestExecutionWaiting(jobUid: string): void {
    if (!this._testExecutionStart) {
      throw new Error('Call "logTestExecutionStart()" first.');
    }

    this._logNodeSpecific(`Waiting for STBT job "${jobUid}" to finish...`);
  }

  /**
   * Log that the BAF test case has finished executing on the STBT node.
   */
  public logTestExecutionEnd(): void {
    assert(this._testExecutionStart, 'Call "logTestExecutionStart()" first.');

    const testRuntimeMs: number = Date.now() - this._testExecutionStart;
    const testRuntime: string = humanizeDuration(testRuntimeMs);

    this._logNodeSpecific(`...test execution finished after ${testRuntime}.`);
  }

  /**
   * Log that the results of the BAF test case are being retrieved from the STBT REST API.
   */
  public logResultsRetrievalStart(): void {
    this._resultsRetrievalStart = Date.now();
    this._logNodeAgnostic('Retrieving test results...');
  }

  /**
   * Log that the results of the BAF test case have been retrieved from the STBT REST API.
   */
  public logResultsRetrievalEnd(): void {
    assert(
      this._resultsRetrievalStart,
      'Call "logResultsRetrievalStart()" first.',
    );

    const retrievalRuntimeMs: number = Date.now() - this._resultsRetrievalStart;
    const retrievalRuntime: string = humanizeDuration(retrievalRuntimeMs);

    this._logNodeAgnostic(
      `...test results retrieved after ${retrievalRuntime}.`,
    );
  }

  /**
   * Log `logMessage` with a node-specific prefix, when the log message pertains to
   * an STBT action which runs on a specific node (e.g. executing a test).
   *
   * @param logMessage - The log message.
   */
  private _logNodeSpecific(logMessage: string): void {
    logger.log(`${this._nodeSpecificPrefix}: ${logMessage}`);
  }

  /**
   * Log `logMessage` with a node-agnostic prefix, when the log message pertains to
   * an STBT action which does not run on a specific node (e.g. retrieving test results).
   *
   * @param logMessage - The log message.
   */
  private _logNodeAgnostic(logMessage: string): void {
    logger.log(`${this._nodeAgnosticPrefix}: ${logMessage}`);
  }
}
