// Copyright text placeholder, Warner Bros. Discovery, Inc.

import humanizeDuration from 'humanize-duration';
import { logger } from '../../../support/logger';
import { assert } from '../../../support/TypeUtils';
import { IBafFrameworkError, IBafTestRunResults } from '../types';

/**
 * Logs the lifecycle of a BafTestManager.
 */
export class BafTestRunLogger {
  /**
   * The id of the BAF test run.
   */
  private readonly _testRunId: string;

  /**
   * The id prefix prepended to all log messages for this test run.
   */
  private _logPrefix: string;

  /**
   * The start time of the BafTestManager's execution.
   */
  private _testRunStart?: number;

  /**
   * Create a logger for the execution of a BAF test run.
   *
   * @param testRunId - The id of the BAF test run.
   * @param stbtNodeIds - The STBT node ids on which the test will be executed.
   * @param testCases - The tests that will be executed as part of this BAF test run.
   * @param testPackRevision - The Git SHA of the branch of the `stb-tester-test-pack-hbo`
   * repo from which the tests should be taken.
   * @param stbtTags - The values, taken from environment variables, which should be passed
   * to the individual test case executions as STBT tags.
   */
  public constructor({
    testRunId,
    stbtNodeIds,
    testCases,
    testPackRevision,
    stbtTags,
  }: {
    testRunId: string;
    stbtNodeIds: string[];
    testCases: string[];
    testPackRevision: string;
    stbtTags: Record<string, string | undefined>;
  }) {
    this._testRunId = testRunId;
    this._logPrefix = `Test run ${this._testRunId}`;
    this._logTestRunCreated({
      stbtNodeIds,
      testCases,
      testPackRevision,
      stbtTags,
    });
  }

  private _logTestRunCreated({
    stbtNodeIds,
    testCases,
    testPackRevision,
    stbtTags,
  }: {
    stbtNodeIds: string[];
    testCases: string[];
    testPackRevision: string;
    stbtTags: Record<string, string | undefined>;
  }): void {
    this._info(
      `created with ${testCases.length} test cases from Git revision "${testPackRevision}".`,
    );
    this._info('will run on STBT node(s):', stbtNodeIds); //  ["${stbtNodeIds.join('", "')}"]`);
    this._info('with STBT tags:', stbtTags);
    this._debug('test cases:', testCases);
  }

  /**
   * Logs the initiation of a BAF test run.
   *
   * @param appPortalUrl - The URL in the STBT web portal at which incremental results for this
   * test run can be viewed.
   * @param restApiUrl - The URL in the STBT REST API from which incremental results for this
   * test run can be retrieved.
   */
  public logTestExecutionsStart(
    appPortalUrl: string,
    restApiUrl: string,
  ): void {
    this._testRunStart = Date.now();

    this._info(`started at ${new Date(this._testRunStart).toISOString()}.`);
    this._info('incremental test results can be obtained from:');
    this._info(`  - the STBT web portal at ${appPortalUrl}`);
    this._info(`  - the STBT REST API at ${restApiUrl}`);
    this._info('waiting for test executions to finish...');
  }

  /**
   * Log that the BAF test run has finished executing on the STBT node.
   */
  public logTestExecutionsEnd(): void {
    assert(this._testRunStart, 'Test executions start has not been logged.');

    const testRuntimeMs: number = Date.now() - this._testRunStart;
    const testRuntime: string = humanizeDuration(testRuntimeMs);

    this._info(`test executions finished after ${testRuntime}.`);
  }

  /**
   * Logs any framework errors that occurred during the execution of the test run.
   *
   * @param frameworkErrors - Any framework errors from the test run execution.
   */
  public logFrameworkErrors(frameworkErrors: IBafFrameworkError[]): void {
    assert(
      frameworkErrors.length > 0,
      'must provide framework errors to be logged.',
    );

    this._error(
      `results are UNDEFINED due to framework errors:`,
      frameworkErrors,
    );
  }

  /**
   * Logs the outcome of a BAF test run, including a summary of the results.
   *
   * @param testRunResults - The results of a BAF test run.
   */
  public logTestRunResults(testRunResults: IBafTestRunResults): void {
    if (testRunResults.isSuccess) {
      this._info(
        `succeeded: all ${testRunResults.testResults.length} tests passed.`,
      );
    } else {
      const totalCount: number = testRunResults.testResults.length;
      const passCount: number = testRunResults.testResults.filter(
        (testCase) => testCase.result === 'pass',
      ).length;
      const failCount: number = totalCount - passCount;
      const passPercent = Math.round((passCount / totalCount) * 10000) / 100;

      this._info(
        `failed: ${failCount} of ${totalCount} tests failed (${passPercent}% passed).`,
      );
    }
  }

  /**
   * Log `debug` at the DEBUG log level with the test run logging prefix.
   *
   * @param debug - The value(s) to be logged at the DEBUG log level.
   */
  private _debug(...debug: unknown[]): void {
    logger.debug(this._logPrefix, ...debug);
  }

  /**
   * Log `info` at the INFO log level with the test run logging prefix.
   *
   * @param info - The value(s) to be logged at the INFO log level.
   */
  private _info(...info: unknown[]): void {
    logger.info(this._logPrefix, ...info);
  }

  /**
   * Log `error` at the ERROR log level with the test run logging prefix.
   *
   * @param error - The value(s) to be logged at the ERROR log level.
   */
  private _error(...error: unknown[]): void {
    logger.error(this._logPrefix, ...error);
  }
}
