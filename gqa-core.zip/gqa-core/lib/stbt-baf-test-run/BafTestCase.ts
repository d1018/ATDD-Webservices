// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { v4 as uuid } from 'uuid';
import { assert } from '../../support/TypeUtils';
import {
  IJobResponse,
  IRunTestsRequestBody,
  IStepsResult,
  ITestResult,
  StbtClient,
} from '../stbt-client';
import { BafTestCaseLogger } from './logging';
import { IBafTestCaseOutcome, IBafTestCaseResults } from './types';

/**
 * Constructor parameters for a `BafTestCase`.
 */
export interface IBafTestCaseParams {
  /**
   * The id of the `BafTestRun` in which this `BafTestCase` will be executed.
   */
  bafTestRunId: string;
  /**
   * A client for interacting with the STBT REST API.
   */
  stbtClient: StbtClient;

  /**
   * The BDD test case to execute.
   */
  testCase: string;

  /**
   * The Git SHA or branch name of the `stb-tester-test-pack-hbo` repo from which
   * the test should be taken.
   */
  testPackRevision: string;

  /**
   * Values to be passed along to the STBT REST API as STBT tags, as part of the test
   * execution command.
   */
  stbtTags: Record<string, string | undefined>;
}

/**
 * Represents the entire life-cycle of a single BAF STBT test case, from pending to executed
 * to (potentially) re-run after a failure to completed to finalized.
 *
 * It keeps track of its state, provides self-monitoring of asynchronous behavior, and
 * can participate in result collection and aggregation.
 *
 * It will only request its results from the STB-Tester device once. It will cache the response to that
 * results request, and return the cached values in response to any future requests for its results.
 */
export class BafTestCase {
  /**
   * The error message returned if `getTestResults()` is called before the test has been started
   * by a call to `runTestAsync()`.
   */
  private static readonly _TEST_NOT_STARTED_MESSAGE: string =
    'Test job has not yet been started. Please call runTestAsync() before calling getResultsAsync().';

  private static readonly _TEST_ALREADY_STARTED_MESSAGE: string =
    'Test job has already been started. Please only call runTestAsync() once.';

  /**
   * The test case's ID, for logging and traceability.
   */
  public readonly id: string = uuid().substring(0, 6);

  /**
   * The `StbtClient` instance for communicating with the STBT REST API.
   */
  private readonly _stbtClient: StbtClient;

  /**
   * The test job parameters to be sent to `StbtClient`'s `runTestsAsync()` method. Does not include
   * the `stbtNodeId` parameter, as the node on which this job should be run is not known until the
   * call to `runTestAsync()`.
   */
  private _testJobParameters: Omit<IRunTestsRequestBody, 'stbtNodeId'>;

  /**
   * The STBT `job_uid` of the STBT test job that will be executing this test.
   */
  private _jobUid?: string;

  /**
   * The cached result of executing the test, if the result has been retrieved.
   *
   * If a framework error occurs while calling runTestAsync(), this will be set
   * to an appropriate `IBafFrameworkError`, and the call to retrieve the test
   * results will never be made.
   */
  private _result: IBafTestCaseOutcome | undefined;

  /**
   * BAF test case lifecycle logger.
   */
  private readonly _bafTestCaseLogger: BafTestCaseLogger;

  public constructor({
    bafTestRunId,
    stbtClient,
    testCase,
    testPackRevision,
    stbtTags,
  }: IBafTestCaseParams) {
    this._bafTestCaseLogger = new BafTestCaseLogger(bafTestRunId, this.id);
    this._testJobParameters = {
      bafTestRunId,
      stbtTags,
      testCases: [testCase],
      testPackRevision,
    };
    this._stbtClient = stbtClient;
  }

  /**
   * Runs the STBT test on the given node. Returns when the test has finished running.
   *
   * @param stbtNodeId - The STBT `node_id` of the STBT node on which to run the test.
   */
  public async runTestAsync(stbtNodeId: string): Promise<void> {
    try {
      assert(!this._jobUid, BafTestCase._TEST_ALREADY_STARTED_MESSAGE);
      const testCaseParams: IRunTestsRequestBody = {
        ...this._testJobParameters,
        stbtNodeId,
      };

      this._bafTestCaseLogger.logTestExecutionStart(testCaseParams);
      const { jobUid }: IJobResponse = await this._stbtClient.runTestsAsync(
        testCaseParams,
      );

      this._jobUid = jobUid;
      this._bafTestCaseLogger.logTestExecutionWaiting(jobUid);
      await this._stbtClient.waitForTestJobCompletionAsync(jobUid);
      this._bafTestCaseLogger.logTestExecutionEnd();
    } catch (error) {
      this._result = {
        isFrameworkError: true,
        error,
      };
    }
  }

  /**
   * Gets the results of the BafTestCase. This includes both the results object from STB-Tester and
   * the BDD steps results from `steps.json`.
   *
   * If the attempt to retrieve results throws an exception, the outcome of the test case will be
   * reported as a BAF framework error.
   *
   * @returns The results of the BafTestCase, or a BAF framework error.
   */
  public async getResultsAsync(): Promise<IBafTestCaseOutcome> {
    if (!this._result) {
      try {
        this._bafTestCaseLogger.logResultsRetrievalStart();
        this._result = await this._getResultsAsync();
        this._bafTestCaseLogger.logResultsRetrievalEnd();
      } catch (error) {
        this._result = {
          isFrameworkError: true,
          error,
        };
      }
    }

    return this._result;
  }

  private async _getResultsAsync(): Promise<IBafTestCaseResults> {
    assert(this._jobUid, BafTestCase._TEST_NOT_STARTED_MESSAGE);

    const jobTestResults: ITestResult[] =
      await this._stbtClient.getTestResultsForTestJobAsync(this._jobUid);
    // A BafTestCase only ever has one STBT test case in its STBT test job.
    const testResult: ITestResult = jobTestResults[0];
    const bddStepsResult: IStepsResult =
      await this._stbtClient.getTestBddStepsResultAsync(testResult.resultId);

    return {
      isFrameworkError: false,
      isSuccess: testResult.result === 'pass',
      testResult,
      bddStepsResult,
    };
  }
}
