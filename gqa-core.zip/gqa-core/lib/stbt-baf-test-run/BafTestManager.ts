// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { v4 as uuid } from 'uuid';
import { partitionByType } from '../../support/TypeUtils';
import { BafTestCase } from './BafTestCase';
import { BafTestResultsFetcher } from './BafTestResultsFetcher';
import { BafTestRunner } from './BafTestRunner';
/* eslint-disable no-console */

import { BafTestRunLogger } from './logging';
import {
  IBafFrameworkError,
  IBafTestCaseOutcome,
  IBafTestCaseResults,
  IBafTestRunParams,
  IBafTestRunResults,
  isFrameworkError,
} from './types';

/**
 * Coordinates a pool of pseudo-threads (represented by a fixed number of `BafTestWorker` objects)
 * which execute individual STBT tests (represented by `BafTestCase` objects) on assigned STBT nodes,
 * and a `BafTestResultsFetcher` which manages the retrieval of test results by the `BafTestCase`s.
 *
 * The `BafTestManager` creates one `BafTestRunner` per assigned STBT node, and starts them running.
 *
 * Each `BafTestRunner` takes a `BafTestCase` and executes it; when it has finished, it takes another
 * `BafTestCase` to execute, until there are none left. This ensures minimal downtime across the assigned
 * STBT nodes.
 *
 * As each `BafTestCase` finishes executing, its `BafTestRunner` hands it off to the `BafTestResultsFetcher`.
 *
 * The `BafTestResultsFetcher` makes a fire-and-forget request to the `BafTestCase` to retrieve its results,
 * and then adds it to the list of pending results requests. When a `BafTestCase` finishes retrieving its results,
 * the `BafTestResultsFetcher` moves that `BafTestCase` from the list of pending results requests to a list
 * of finalized results requests.
 *
 * When all of the BAF tests cases have been executed by the BafTestRunners, the BafTestManager asks the
 * BafTestResultsFetcher to wait on all remaining (pending) test results retrievals. When those have all
 * completed, the BafTestResultsFetcher returns the full list of finalized BAF test cases to the
 * BafTestManager.
 *
 * The `BafTestManager` then aggregates the test results and returns them to `runTestsWithStbtAsync()`.
 */
export class BafTestManager {
  /**
   * The test run's id, for logging and traceability.
   */
  public readonly id: string;

  /**
   * URL in the STBT app portal webapp where the incremental results of this BAF test run
   * can be viewed.
   */
  public readonly appPortalUrl: string;

  /**
   * URL in the STBT REST API from which the incremental results of this BAF test run
   * can be retrieved.
   */
  public readonly restApiUrl: string;

  /**
   * Logger for reporting the progress and results of the BAF test run.
   */
  private readonly _testRunLogger: BafTestRunLogger;

  /**
   * The list of pseudo-threads that take pending BAF test cases from the common pool of
   * pending test cases, and run them on the STBT nodes.
   */
  private readonly _testRunners: BafTestRunner[];

  /**
   * The shared `BafTestResultsFetcher` that is responsible for asynchronously pulling test
   * results from the STBT REST API as tests finish running, and maintaining the list of
   * test case outcomes.
   */
  private readonly _resultsFetcher: BafTestResultsFetcher;

  /**
   * Constructs a `BafTestManager` to manage the BAF test run specified by the constructor
   * parameters object.
   */
  public constructor({
    stbtClient,
    stbtNodeIds,
    testCases,
    testPackRevision,
    stbtTags,
  }: IBafTestRunParams) {
    this.id = uuid().substring(0, 6);
    this.appPortalUrl = `https://hbo.stb-tester.com/app/#/results?filter=category:${this.id}`;
    this.restApiUrl = `https://hbo.stb-tester.com/api/v2/results?filter=category:${this.id}`;

    this._resultsFetcher = new BafTestResultsFetcher();

    const pendingTestCases = testCases.map(
      (testCase) =>
        new BafTestCase({
          bafTestRunId: this.id,
          stbtClient,
          testCase,
          testPackRevision,
          stbtTags,
        }),
    );

    this._testRunners = stbtNodeIds.map(
      (stbtNodeId) =>
        new BafTestRunner({
          stbtNodeId,
          pendingTestCases,
          bafTestResultsFetcher: this._resultsFetcher,
        }),
    );

    this._testRunLogger = new BafTestRunLogger({
      testRunId: this.id,
      stbtNodeIds,
      testCases,
      testPackRevision,
      stbtTags,
    });
  }

  /**
   * Runs all of the BAF test cases in a BAF test run, retrieves their results, and returns the aggregated
   * results.
   */
  public async runTestsAsync(): Promise<IBafTestRunResults> {
    this._testRunLogger.logTestExecutionsStart(
      this.appPortalUrl,
      this.restApiUrl,
    );

    await Promise.all(
      this._testRunners.map((testRunner) => testRunner.runTestCasesAsync()),
    );

    const testCaseOutcomes: IBafTestCaseOutcome[] =
      await this._resultsFetcher.getResultsAsync();

    this._testRunLogger.logTestExecutionsEnd();

    const [frameworkErrors, testCaseResults]: [
      IBafFrameworkError[],
      IBafTestCaseResults[],
    ] = partitionByType(testCaseOutcomes, isFrameworkError);

    if (frameworkErrors.length > 0) {
      this._testRunLogger.logFrameworkErrors(frameworkErrors);
      throw new Error(
        `BAF test run INVALID: ${frameworkErrors.length} framework error(s) in ${testCaseOutcomes.length} test execution(s).`,
      );
    }

    const testRunResults: IBafTestRunResults = {
      isSuccess: testCaseResults.every((outcome) => outcome.isSuccess),
      testResults: testCaseResults.map((outcome) => outcome.testResult),
      bddStepsResults: testCaseResults.map((outcome) => outcome.bddStepsResult),
    };

    this._testRunLogger.logTestRunResults(testRunResults);

    return testRunResults;
  }
}
