// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { logger } from '../../support/logger';
import { BafTestCase } from './BafTestCase';
import { IBafTestCaseOutcome } from './types/BafTestCaseOutcomeTypes';

/**
 * Coordinates the retrieval of test results from all of the `BafTestCase` jobs managed
 * by a `BafTestManager`.
 */
export class BafTestResultsFetcher {
  /**
   * The results-fetching promises which have not yet resolved.
   */
  private readonly _pendingPromises: Set<Promise<IBafTestCaseOutcome>> =
    new Set();

  /**
   * The test case outcomes (BAF results or framework errors) that have been
   * retrieved so far from the BAF test cases.
   */
  private readonly _results: IBafTestCaseOutcome[] = [];

  /**
   * Fire-and-forget the fetching of the results of the given `BafTestCase`. Track the
   * resulting promise until the results have been fetched.
   *
   * This permits the `BafTestResultsManager` to keep track of which `BafTestCase` results
   * have not yet been retrieved, and thus enables the `BafTestManager` to `await` the
   * retrieval of the results for all of its `BafTestCase`s.
   *
   * @param bafTestCase - The test job whose results should be fetched.
   */
  public fetchResults(bafTestCase: BafTestCase): void {
    const pendingPromise: Promise<IBafTestCaseOutcome> =
      bafTestCase.getResultsAsync();

    this._pendingPromises.add(pendingPromise);

    pendingPromise
      .then((result) => {
        this._pendingPromises.delete(pendingPromise);
        this._results.push(result);
      })
      .catch((error) => {
        this._pendingPromises.delete(pendingPromise);
        this._results.push({
          isFrameworkError: true,
          error,
        });
      });
  }

  /**
   * Ensures that all of its managed `BafTestCase`s have retrieved their test results,
   * and then returns those results to its `BafTestManager`.
   *
   * @returns The test results from all of its test runs.
   */
  public async getResultsAsync(): Promise<IBafTestCaseOutcome[]> {
    if (this._pendingPromises.size > 0) {
      await this._getRemainingResultsAsync();
    }

    return this._results;
  }

  /**
   * Retrieves the results of any test cases whose results have not yet been retrieved.
   *
   * @returns The results of any test cases that were pending when this method was called.
   */
  public async _getRemainingResultsAsync(): Promise<IBafTestCaseOutcome[]> {
    const toFinalize: number = this._pendingPromises.size;
    const total: number = toFinalize + this._results.length;

    logger.log(`Fetching remaining ${toFinalize} of ${total} results.`);

    const newlyFinalizedResults: IBafTestCaseOutcome[] = await Promise.all([
      ...this._pendingPromises.values(),
    ]);

    logger.log(`All ${total} results have been retrieved.`);

    return newlyFinalizedResults;
  }
}
