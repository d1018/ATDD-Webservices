// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { writeFileSync } from 'fs';
import { join } from 'path';
import { logger } from '../support/logger';
import { ensureResultsDirectory } from '../support/utilities';
import { paths } from '../tasks/utils';
import { IStepsResult } from './stbt-client';

/**
 * Writes the aggregated results of multiple tests into a new `json_reports.json` file in the `results/`
 * directory.
 *
 * @param bddResultsJson - the aggregated results from multiple tests, to be written to the]
 * `json_report.json` file in the `results/` directory.
 */
export function writeBddJsonReportFile(bddResultsJson: IStepsResult[]): void {
  ensureResultsDirectory();

  writeFileSync(
    join(paths.results, 'json_report.json'),
    JSON.stringify(bddResultsJson),
    'utf-8',
  );

  // Added for https://wbdstreaming.atlassian.net/browse/PEO-3567
  logger.log('Results of the job are:');
  logger.log(JSON.stringify(bddResultsJson));
}
