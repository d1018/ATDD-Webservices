// Copyright text placeholder, Warner Bros. Discovery, Inc.

/* eslint-disable prefer-destructuring */

import * as cucumber from '@cucumber/cucumber';
import { IDefineSupportCodeMethods } from '@cucumber/cucumber/lib/support_code_library_builder/types';

// we are exporting our own implementation here as a library
// see here: https://github.com/cucumber/cucumber-js/blob/main/docs/support_files/api_reference.md

// TODO: we are doing direct pass thru for now
// we should revisit and see if we should wrap and put hook around each of them??

export { TestStepResultStatus as Status } from '@cucumber/messages';

// before hooks
export const Before: IDefineSupportCodeMethods['Before'] = cucumber.Before;
export const BeforeAll: IDefineSupportCodeMethods['BeforeAll'] =
  cucumber.BeforeAll;
export const BeforeStep: IDefineSupportCodeMethods['BeforeStep'] =
  cucumber.BeforeStep;

// after hooks
export const After: IDefineSupportCodeMethods['After'] = cucumber.After;
export const AfterAll: IDefineSupportCodeMethods['AfterAll'] =
  cucumber.AfterAll;
export const AfterStep: IDefineSupportCodeMethods['AfterStep'] =
  cucumber.AfterStep;

// Step definitions
export const Given: IDefineSupportCodeMethods['Given'] = cucumber.Given;
export const When: IDefineSupportCodeMethods['When'] = cucumber.When;
export const Then: IDefineSupportCodeMethods['Then'] = cucumber.Then;

// TODO: do we want to allow use of And and But?
// cucumber-js doesn't have And() and But() defined
// but for better completeness, we can map use of And() and But() to cucumber-js Then() for readability
export const And: IDefineSupportCodeMethods['Then'] = cucumber.Then;
export const But: IDefineSupportCodeMethods['Then'] = cucumber.Then;

// these functions are specified to cucumber-js and are used for customizing test run
// TODO: should we export them or keep them internal and we provide wrapper for these instead
// (so to be framework agnostic)
export const setDefaultTimeout: IDefineSupportCodeMethods['setDefaultTimeout'] =
  cucumber.setDefaultTimeout;
export const setDefinitionFunctionWrapper: IDefineSupportCodeMethods['setDefinitionFunctionWrapper'] =
  cucumber.setDefinitionFunctionWrapper;
export const setParallelCanAssign: IDefineSupportCodeMethods['setParallelCanAssign'] =
  cucumber.setParallelCanAssign;
export const setWorldConstructor: IDefineSupportCodeMethods['setWorldConstructor'] =
  cucumber.setWorldConstructor;
