// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { IConfiguration, loadConfiguration } from '@cucumber/cucumber/api';
import reportPortalConfig from '../support/rpConfig';
import { getSelectedStbtTests } from './getSelectedStbtTests';
import { getStbtNodeIdsForDeviceTypeAsync } from './getStbtNodeIdsForDeviceTypeAsync';
import { getStbtTags } from './getStbtTags';
import { getStbtTestPackRevision } from './getStbtTestPackRevision';
import { BafTestManager, IBafTestRunResults } from './stbt-baf-test-run';
import { StbtClient } from './stbt-client';
import { writeBddJsonReportFile } from './writeBddJsonReportFile';

/**
 * The configuration object to run BDD tests with STBT.
 *
 * This is based on the Cucumber `IConfiguration` object
 * (see {@link https://github.com/cucumber/cucumber-js/blob/main/docs/configuration.md}).
 */
export interface IRunTestsWithStbtAsyncConfig extends Partial<IConfiguration> {
  /**
   * The Cucumber configuration file containing the default values for the repository.
   */
  file: string;

  /**
   * The Cucumber profile or profiles under which the tests should be executed.
   */
  profiles: string[];

  /**
   * A file path of the form `"projects/<project_name>/features/*"`. See `getSelectedStbtTests.js` for details regarding specifying individual features.
   */
  paths: string[];

  /**
   * A tag expression (e.g. `"@P0 and not @wip"`) that controls which features, scenarios, and examples are included in the test run.
   */
  tags?: string;
}

/**
 * Execute the specified test run on the specified STB-Tester node.
 *
 * @param config - The Cucumber configuration for the test run
 * @returns `true` if all of the tests succeed without errors; `false` otherwise
 */
export async function runTestsWithStbtAsync(
  config: IRunTestsWithStbtAsyncConfig,
): Promise<boolean> {
  if (!config) {
    throw new Error('Please specify a valid test config!');
  }

  if (!process.env.STBT_AUTH_TOKEN) {
    throw new Error(
      'No STBT auth token provided in environment variable "STBT_AUTH_TOKEN".',
    );
  }

  if (!process.env.DEVICE) {
    throw new Error(
      'No device type provided in environment variable "DEVICE".',
    );
  }

  const stbtClient = new StbtClient(process.env.STBT_AUTH_TOKEN);

  // Overall flow for this function:
  //
  // 1. Resolve the Cucumber/Gherkin configuration:
  //    Call Cucumber's `loadConfiguration()` method to load the config file and merge it with the given `config` object.
  // 2. Get the features, scenarios, and examples to be executed as pytest test paths:
  //    e.g. `file:test_name_from_scenario[Var1][Var2][Var3]`
  // 3. Acquire an STBT node and its associated device:
  //    a. For now, finding an available STBT node from a list of nodes corresponding to the requested device type
  //    b. Someday, using a call to the Agnostic API based on the MODEL environment variable
  // 4. Get the current Git commit specifier:
  //    a. From the `GIT_COMMIT_SPECIFIER` environment variable (set by the GitHub Actions) if set, or
  //    b. From a call to the Git CLI.
  // 5. Call the STBT REST API to run the selected tests on the selected node
  //
  // 5. Long-poll the STBT REST API to wait for test completion.
  // 6. Create the file of test results.
  //    Create the `./results/test-results.json` file from the `steps.js` test artifacts of the individual tests.
  //
  // NOTE: future feature integrates the long-polling with the test results acquisition, and sends them directly to
  // Report Portal without waiting for the end.

  // 1. Resolve the Cucumber/Gherkin configuration:
  const { useConfiguration } = await loadConfiguration({
    file: config.file,
    profiles: config.profiles,
    provided: {
      // TODO: we can sanity some essential config fields here (and override with what we want if we choose to):
      // for now we are just passing thru everything to cucumber-js

      // https://github.com/cucumber/cucumber-js/blob/main/docs/configuration.md
      ...config,

      // NOTE: we have to do this here instead of in the config file, because our config file (in `stb-tester-test-pack-hbo`)
      // will be a JSON file (`cucumber.json`), rather than an executable Javascript file (`cucumber.js`).
      tags: config.tags || process.env.CUCUMBER_TAG || 'not @wip',
    },
  });

  // 2. Get the pytest test paths of the features, scenarios, and examples to be executed.
  const testCases = getSelectedStbtTests(
    useConfiguration.paths[0],
    useConfiguration.tags,
  );

  // 3. Get one or more STBT nodes with devices of the requested type.
  const stbtNodeIds: string[] = await getStbtNodeIdsForDeviceTypeAsync(
    process.env.DEVICE,
  );

  // 4. Get the current Git commit specifier:
  const testPackRevision = getStbtTestPackRevision();

  // 5. Get any environment variables that should be sent as STBT tags to the test nodes.
  const stbtTags = getStbtTags();

  // 6. Call the STBT REST API to execute the selected tests on the specified STB-Tester node(s).
  const testManager: BafTestManager = new BafTestManager({
    stbtClient,
    stbtNodeIds,
    testCases,
    testPackRevision,
    stbtTags,
  });

  const testRunResults: IBafTestRunResults = await testManager.runTestsAsync();

  // 7. Create the file of BDD test results.
  if (reportPortalConfig.rp_enable === 'true') {
    writeBddJsonReportFile(testRunResults.bddStepsResults);
  }

  return testRunResults.isSuccess;
}
