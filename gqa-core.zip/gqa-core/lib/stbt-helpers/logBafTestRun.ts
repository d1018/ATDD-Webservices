// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { BafTestManager, IBafTestRunResults } from '../stbt-baf-test-run';
import { logger } from '../../support/logger';

/**
 * Logs the initiation of a BAF test run.
 *
 * @param bafTestManager - The `BafTestManager` coordinating this BAF test run.
 * @param stbtNodeIds - The STBT node ids on which the test will be executed.
 * @param testCases - The tests that will be executed as part of this BAF test run.
 * @param testPackRevision - The Git SHA of the branch of the `stb-tester-test-pack-hbo`
 * repo from which the tests should be taken.
 * @param stbtTags - The values, taken from environment variables, which should be passed
 * to the individual test case executions as STBT tags.
 */
export function logBafTestRunStart(
  bafTestManager: BafTestManager,
  stbtNodeIds: string[],
  testCases: string[],
  testPackRevision: string,
  stbtTags: Record<string, string | undefined>,
): void {
  logger.log(`BAF test run ${bafTestManager.id}`);
  logger.log(`Tests from Git revision "${testPackRevision}":`);
  logger.log(testCases);
  logger.log('Passing STBT tags:');
  logger.log(JSON.stringify(stbtTags, undefined, 2));
  logger.log(`Running on node(s): ["${stbtNodeIds.join('", "')}"]`);
  logger.log('Incremental test results can be obtained from:');
  logger.log(`  - the STBT REST API at ${bafTestManager.restApiUrl}`);
  logger.log(`  - the STBT web portal at ${bafTestManager.appPortalUrl}`);
  logger.log('Waiting for test job execution to complete...');
}

/**
 * Logs the ending of a BAF test run, including a summary of the results.
 *
 * @param testRunResults - The results of a BAF test run.
 */
export function logBafTestRunEnd(testRunResults: IBafTestRunResults): void {
  logger.log('...BAF test run execution complete.');

  if (testRunResults.isSuccess) {
    logger.log(
      `Test run succeeded: all ${testRunResults.testResults.length} tests passed.`,
    );
  } else {
    const totalCount: number = testRunResults.testResults.length;
    const passCount: number = testRunResults.testResults.filter(
      (testCase) => testCase.result === 'pass',
    ).length;
    const failCount: number = totalCount - passCount;
    const passPercent = Math.round((passCount / totalCount) * 10000) / 100;

    logger.log(
      `Test run failed: ${failCount} of ${totalCount} tests failed (${passPercent}% passed).`,
    );
  }
}
