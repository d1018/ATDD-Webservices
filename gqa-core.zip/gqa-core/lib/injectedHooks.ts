// Copyright text placeholder, Warner Bros. Discovery, Inc.

/* eslint-disable prefer-arrow-callback */
/* eslint-disable func-names */

import {
  IWorld,
  ITestStepHookParameter,
  ITestCaseHookParameter,
} from '@cucumber/cucumber';

import { IJiraConfig } from './jira/IJiraConfig';
import { throwHookError } from './utils';

import {
  After,
  Before,
  BeforeAll,
  // BeforeStep,
  AfterStep,
  // AfterAll,
} from './cucumberDefinition';

import {
  initJiraConfig,
  createJiraDataFile,
  addTestDefinitionToJiraCache,
  addFailedStepTestIdToJiraCache,
} from './jira/jiraCucumberDataHandler';

let jiraConfigObj: IJiraConfig | undefined;

/*
 * empty hooks for now
 * see https://github.com/cucumber/cucumber-js/blob/main/docs/support_files/hooks.md
 * NOTE: we can only use the world param for non-arrow function
 */

// these hooks are NOT used so far; keep them here for reference
// BeforeStep(async () => {});
// AfterAll(async () => {});

// note: BeforeAll hook is executed only ONCE before all tests are executed per cucumber-js worker process
BeforeAll(async function (): Promise<void> {
  const hookName = 'BeforeAll';

  try {
    jiraConfigObj = await initJiraConfig();
  } catch (ex) {
    throwHookError(hookName, ex as Error);
  }
});

// note: Before hook is executed before a test scenario
Before(function (data: ITestCaseHookParameter): void {
  const hookName = 'Before';

  try {
    if (jiraConfigObj) {
      addTestDefinitionToJiraCache({
        // @ts-ignore: An outer value of 'this' is shadowed by this container.
        cucumberWorld: this as unknown as IWorld,
        cucumberBeforeHookParameter: data,
      });
    }
  } catch (ex) {
    throwHookError(hookName, ex);
  }
});

// note: AfterStep hook is executed after EVERY test step
AfterStep(function (data: ITestStepHookParameter): void {
  const hookName = 'AfterStep';

  try {
    if (jiraConfigObj) {
      addFailedStepTestIdToJiraCache(jiraConfigObj, {
        // @ts-ignore: An outer value of 'this' is shadowed by this container.
        cucumberWorld: this,
        cucumberAfterStepHookParameter: data,
      });
    }
  } catch (ex) {
    throwHookError(hookName, ex);
  }
});

// note: After hook is executed after a test scenario is executed
After(async function (data: ITestCaseHookParameter): Promise<void> {
  const hookName = 'After';

  try {
    if (jiraConfigObj) {
      await createJiraDataFile(jiraConfigObj, {
        // @ts-ignore: An outer value of 'this' is shadowed by this container.
        cucumberWorld: this,
        cucumberAfterHookParameter: data,
      });
    }
  } catch (ex) {
    throwHookError(hookName, ex);
  }
});
