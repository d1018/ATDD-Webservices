// Copyright text placeholder, Warner Bros. Discovery, Inc.

/**
 * The marker value for the `STBT_NODE_ID` environment variable that indicates that we should return the
 * node ids that have been reserved exclusively for Orange Dot.
 */
export const ORANGE_DOT_MARKER: 'ORANGE_DOT' = 'ORANGE_DOT';

/**
 * The mapping from device/client types to the STBT node ids of the STBT nodes that have been ring-fenced
 * for the exclusive use of Orange Dot.
 *
 * This map must be updated whenever the list of ring-fenced STBT nodes changes, and whenever the device
 * associated with one of these ring-fenced STBT nodes is replaced by a device with a different device type.
 */
const ORANGE_DOT_DEVICES_BY_DEVICE_TYPE: Record<string, string[]> = {
  comcast: ['stb-tester-00044b80f5e9', 'stb-tester-00044b80f7df'],
};

/**
 * Returns the node ids of the nodes with the given device type that have been reserved for Orange Dot.
 *
 * @param deviceType - The device type on which the tests should be run.
 * @returns A list of node ids that have been reserved for Orange Dot.
 * @throws If no nodes of the given device type have been reserved for Orange Dot.
 */
function getOrangeDotNodeIds(deviceType: string): string[] {
  const reservedNodes: string[] = ORANGE_DOT_DEVICES_BY_DEVICE_TYPE[deviceType];

  if (reservedNodes) {
    return reservedNodes;
  }

  const reservedTypes: string[] = Object.keys(
    ORANGE_DOT_DEVICES_BY_DEVICE_TYPE,
  );

  const deviceTypesForDisplay: string = `["${reservedTypes.join('", "')}"]`;

  throw new Error(
    `No "${deviceType}" devices are reserved for Orange Dot. Device types with reserved nodes: ${deviceTypesForDisplay}.`,
  );
}

/**
 * Obtains a list of one or more STBT node ids corresponding to StbtTester nodes that contain a device of the
 * requested device/client type.
 *
 * A predetermined STBT node id can be provided to this function via the `STBT_NODE_ID` environment variable.
 * If this environment variable is set, it will take precedence over the normal device lookup procedure, and
 * the normal device lookup procedure will not be executed.
 *
 * If the marker value "ORANGE_DOT" is passed in `STBT_NODE_ID`, a hardcoded list of STBT node ids with appropriate
 * device types will be returned. These STBT node ids correspond to ring-fenced STBT nodes that are exclusively
 * used by Orange Dot. The relationship between device types and ring-fenced STBT node ids is defined in
 * ORANGE_DOT_DEVICES_BY_DEVICE_TYPE.
 *
 * NOTE: this method is not currently asynchronous, as we have not yet implemented the device lookup and
 * device locking features.
 *
 * @param deviceType - The type of the desired device-under-test
 * @returns The STBT `node_id` of a node connected to a device of the specified type.
 */
// eslint-disable-next-line require-await
export async function getStbtNodeIdsForDeviceTypeAsync(
  deviceType: string,
): Promise<string[]> {
  if (process.env.STBT_NODE_ID === ORANGE_DOT_MARKER) {
    return getOrangeDotNodeIds(deviceType);
  }
  if (process.env.STBT_NODE_ID) {
    return [process.env.STBT_NODE_ID];
  }
  throw new Error(
    'STBT_NODE_ID must be set to an STBT node id, or to the marker value "ORANGE_DOT".',
  );
}
