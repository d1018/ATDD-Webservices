// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { execSync } from 'child_process';
import { IExecSyncError } from '../support/IExecSyncError';

const validGitShaRegExp: RegExp = /^[0-9a-f]{40}$/;

/**
 * Gets the current Git SHA using `git rev-parse HEAD`.
 *
 * @returns The current Git SHA.
 */
function getCurrentGitSha(): string {
  // After testing on both `bash` and `zsh`, we concluded that this is the safest option to get the SHA.
  const gitCommand = 'git rev-parse HEAD';

  let execSyncOutput: Buffer;

  try {
    execSyncOutput = execSync(gitCommand);
  } catch (unknownError) {
    const execSyncError: IExecSyncError = unknownError as IExecSyncError;

    // The error is typically in `stderr`. If it is not in `stderr`, it will be in `stdout`.
    const errorOutput =
      execSyncError.stderr !== '' ? execSyncError.stderr : execSyncError.stdout;

    throw new Error(
      `Unknown error executing Git command "${gitCommand}". Status code: ${execSyncError.status}, error output: "${errorOutput}".`,
    );
  }

  return execSyncOutput.toString().trim();
}

/**
 * Returns the value of the `STBT_TEST_PACK_REVISION` environment variable if it is set,
 * or the current Git commit if `STBT_TEST_PACK_REVISION` is not set.
 *
 * `STBT_TEST_PACK_REVISION`, if set, should be set to the branch name or Git commit containing the
 * tests to be executed.
 *
 * NOTE: Support for the "SNAPSHOT" value of `STBT_TEST_PACK_REVISION` is not yet implemented
 * (see {@link https://wbdstreaming.atlassian.net/browse/GQA-14746}). When it is implemented, setting `STBT_TEST_PACK_REVISION`
 * to "SNAPSHOT" will return the branch name of the user's STBT snapshot branch (as created by
 * `stbt_rig.py snapshot`).
 *
 * @returns the Git revision specifier (branch name or SHA) of the test pack
 * revision containing the STBT tests to be executed
 */
export function getStbtTestPackRevision(): string {
  if (process.env.STBT_TEST_PACK_REVISION) {
    return process.env.STBT_TEST_PACK_REVISION;
  }

  const sha = getCurrentGitSha();

  if (!validGitShaRegExp.test(sha)) {
    throw new Error(`Git command returned invalid git hash: "${sha}"`);
  }

  return sha;
}
