/* eslint-disable jsdoc/no-undefined-types */
require('jake');

/**
 * Executes an asynchronous Jake task by wrapping it in a `Promise` that listens for its `complete` and `error` messages,
 * and resolves/rejects itself accordingly.
 *
 * This function always returns `true` if the Jake task completes successfully; if the Jake task throws, it throws a
 * new `Error` object that wraps whatever the Jake task threw (even if it is already an Error object).
 *
 * @param {jake.Task} jakeTask - The Jake task to be executed
 */
async function runJakeTask(jakeTask) {
  const promise = await new Promise((resolve, reject) => {
    jakeTask.addListener('complete', () => {
      resolve();
    });
    jakeTask.addListener('error', (err) => {
      reject(new Error(err));
    });
    jakeTask.invoke();
  });

  return promise;
}

module.exports = {
  runJakeTask,
};
