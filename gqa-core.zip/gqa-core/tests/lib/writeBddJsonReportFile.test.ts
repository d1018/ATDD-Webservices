// Copyright text placeholder, Warner Bros. Discovery, Inc.

const mockEnsureResultsDirectory = jest.fn();
const mockWriteFileSync = jest.fn();

jest.mock('../../support/utilities', () => ({
  ensureResultsDirectory: mockEnsureResultsDirectory,
}));

jest.mock('fs', () => ({
  writeFileSync: mockWriteFileSync,
}));

jest.mock('../../tasks/utils', () => ({
  paths: {
    results: 'results',
  },
}));

const mockLoggerLog = jest.fn();

jest.mock('../../support/logger', () => ({ logger: { log: mockLoggerLog } }));

import { join } from 'path';
import { IStepsResult } from '../../lib/stbt-client';
import { writeBddJsonReportFile } from '../../lib/writeBddJsonReportFile';

describe('writeBddJsonReportFile', () => {
  const stepResultOne: IStepsResult = {
    isA: 'first steps.json file',
  } as unknown as IStepsResult;

  const stepResultTwo: IStepsResult = {
    isA: 'second steps.json file',
  } as unknown as IStepsResult;

  const BDD_RESULTS_JSON: IStepsResult[] = [stepResultOne, stepResultTwo];

  const STRINGIFIED_BDD_RESULTS: string = JSON.stringify(BDD_RESULTS_JSON);

  beforeEach(() => {
    mockLoggerLog.mockClear();
  });

  it('Saves the test results to a file in the results directory', () => {
    // Setup
    // None needed

    // Execute
    writeBddJsonReportFile(BDD_RESULTS_JSON);

    // Verify
    expect(mockEnsureResultsDirectory).toHaveBeenCalledTimes(1);

    expect(mockWriteFileSync).toHaveBeenCalledTimes(1);
    expect(mockWriteFileSync).toHaveBeenCalledWith(
      join('results', 'json_report.json'),
      STRINGIFIED_BDD_RESULTS,
      'utf-8',
    );
  });

  it('Logs the test results to the console', () => {
    // Setup
    // None needed

    // Mock expected log messages
    const expectedLogMessages = [
      'Results of the job are:',
      STRINGIFIED_BDD_RESULTS,
    ];

    // Execute
    writeBddJsonReportFile(BDD_RESULTS_JSON);

    // Verify
    expect(mockLoggerLog).toHaveBeenCalledTimes(expectedLogMessages.length);
    for (let i = 0; i < expectedLogMessages.length; i++) {
      expect(mockLoggerLog).toHaveBeenNthCalledWith(
        i + 1,
        expectedLogMessages[i],
      );
    }
  });
});
