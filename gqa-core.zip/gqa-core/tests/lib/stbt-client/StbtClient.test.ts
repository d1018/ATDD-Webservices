// Copyright text placeholder, Warner Bros. Discovery, Inc.

const mockAxiosGet = jest.fn();
const mockAxiosPost = jest.fn();
const mockAxiosInstance = {
  get: mockAxiosGet,
  post: mockAxiosPost,
};

const mockAxiosCreate = jest.fn();

jest.mock('axios', () => ({
  create: mockAxiosCreate,
}));

const mockLoggerWarn = jest.fn();

jest.mock('../../../support/logger', () => ({
  logger: { warn: mockLoggerWarn },
}));

import HttpStatus from 'http-status';

import {
  IRunTestsRequestBody,
  IStepsResult,
  StbtClient,
  StepsFileFormat,
} from '../../../lib/stbt-client';

describe('lib/stbt-client/StbtClient', () => {
  // This weirdness is not my fault! STB-Tester has chosen to use their own prefix ("token ")
  // rather than the prefix mandated by the standard ("Bearer ") for bearer token authorization.
  // See https://stb-tester.com/manual/rest-api-v2 and https://datatracker.ietf.org/doc/html/rfc6750#section-2.1
  const TEST_STBT_AUTH_TOKEN = '01234567890123456789012345678901';
  const TEST_STBT_AUTH_TOKEN_REDACTED = '01234**********************78901';

  const TEST_EXPECTED_AUTHORIZATION_HEADER = `token ${TEST_STBT_AUTH_TOKEN}`;

  const DEFAULT_STBT_BASE_URL = 'https://hbo.stb-tester.com/';
  const TEST_STBT_BASE_URL = 'https://foo.stb-tester.com/';

  beforeEach(() => {
    jest.clearAllMocks();
    mockAxiosCreate.mockReturnValue(mockAxiosInstance);
  });

  describe('constructor', () => {
    it('creates axios client; defaults base URL and timeout correctly', () => {
      // Setup
      // The setup is handled in beforeEach()

      // Execute (testing the construction of the Axios client, so we are deliberately using `new` for its side effects)
      new StbtClient(TEST_STBT_AUTH_TOKEN);

      // Verify
      expect(mockAxiosCreate).toHaveBeenCalledTimes(1);
      expect(mockAxiosCreate).toHaveBeenCalledWith({
        baseURL: DEFAULT_STBT_BASE_URL,
        timeout: 60 * 1000, // 1 minute in milliseconds
        headers: {
          Authorization: TEST_EXPECTED_AUTHORIZATION_HEADER,
        },
      });
    });

    it('creates axios client; accepts base URL override and sets timeout correctly', () => {
      // Setup
      // The setup is handled in beforeEach()

      // Execute (testing the construction of the Axios client, so we are deliberately using `new` for its side effects)
      new StbtClient(TEST_STBT_AUTH_TOKEN, TEST_STBT_BASE_URL);

      // Verify
      expect(mockAxiosCreate).toHaveBeenCalledTimes(1);
      expect(mockAxiosCreate).toHaveBeenCalledWith({
        baseURL: TEST_STBT_BASE_URL,
        timeout: 60 * 1000, // 1 minute in milliseconds
        headers: {
          Authorization: TEST_EXPECTED_AUTHORIZATION_HEADER,
        },
      });
    });
  });

  describe('instance method', () => {
    const TEST_BAF_TEST_ID: string = 'ABCDE-12345-FGHIJ-678910-KLMNO';

    const TEST_JOB_UID = 'test_job_uid';
    const TEST_JOB_URL = `https://hbo.stb-tester.com/v2/jobs/${TEST_JOB_UID}`;

    const TEST_RESULT_ID_1 = 'test_result_id_1';
    const TEST_RESULT_ID_2 = 'test_result_id_2';
    const TEST_RESULT_URL_1 = `https://hbo.stb-tester.com/api/v2/results/${TEST_JOB_UID}/${TEST_RESULT_ID_1}`;
    const TEST_RESULT_URL_2 = `https://hbo.stb-tester.com/api/v2/results/${TEST_JOB_UID}/${TEST_RESULT_ID_2}`;
    const TEST_TRIAGE_URL_1 = `https://hbo.stb-tester.com/app/#/result/${TEST_JOB_UID}/${TEST_RESULT_ID_1}`;
    const TEST_TRIAGE_URL_2 = `https://hbo.stb-tester.com/app/#/result/${TEST_JOB_UID}/${TEST_RESULT_ID_2}`;
    const TEST_RESULT = 'pass';
    const TEST_STEPS_FILE_NAME = 'steps.json';

    const STBT_NODE_ID = 'test STBT node_id';
    const TEST_CASE_1 = 'test case #1';
    const TEST_CASE_2 = 'test case #2';
    const TEST_PACK_REVISION = '1k1351515';

    const TEST_STATUS = 'test status, either "running" or "exited"';
    const TEST_START_TIME = 'test start time 2022-06-03T08:37:21';
    const TEST_END_TIME = 'test end time 2022-06-03T09:18:21';

    const EMPTY_RUN_TESTS_REQUEST_BODY: IRunTestsRequestBody = {
      bafTestRunId: TEST_BAF_TEST_ID,
      stbtNodeId: 'stb-tester-00001234abcd',
      testCases: [],
      testPackRevision: '1234',
      stbtTags: {},
    };

    const TEST_RESULT_COUNTS = {
      pass: 7,
      fail: 13,
      error: 19,
      total: 39,
    };

    const TEST_RESULTS_IN_JOB = [
      {
        end_time: TEST_END_TIME,
        failure_reason: null,
        job_uid: TEST_JOB_UID,
        result: TEST_RESULT,
        result_id: TEST_RESULT_ID_1,
        result_url: TEST_RESULT_URL_1,
        start_time: TEST_START_TIME,
        test_case: TEST_CASE_1,
        // eslint-disable-next-line @typescript-eslint/naming-convention
        test_pack_sha: TEST_PACK_REVISION,
        triage_url: TEST_TRIAGE_URL_1,
      },
      {
        end_time: TEST_END_TIME,
        failure_reason: null,
        job_uid: TEST_JOB_UID,
        result: TEST_RESULT,
        result_id: TEST_RESULT_ID_2,
        result_url: TEST_RESULT_URL_2,
        start_time: TEST_START_TIME,
        test_case: TEST_CASE_2,
        // eslint-disable-next-line @typescript-eslint/naming-convention
        test_pack_sha: TEST_PACK_REVISION,
        triage_url: TEST_TRIAGE_URL_2,
      },
    ];

    /**
     * Loads the captured Axios error for the specified error case.
     *
     * @param capturedErrorFilename - The filename (no extension) for the captured Axios error,
     * which must be located in the specified directory.
     * @returns The captured Axios error.
     */
    function loadCapturedError(capturedErrorFilename: string): string {
      // eslint-disable-next-line import/no-dynamic-require
      return require(`../../test_resources/lib/stbt-client/axios-errors/${capturedErrorFilename}.json`);
    }

    mockAxiosCreate.mockReturnValueOnce(mockAxiosInstance);
    const stbtClient = new StbtClient(TEST_STBT_AUTH_TOKEN);

    beforeEach(() => {});

    describe('runTestsAsync()', () => {
      const TEST_STBT_TAGS: Record<string, string | undefined> = {
        isA: 'stbt tags object',
        CLIENT: undefined,
      };

      it('calls the run_tests endpoint with the data object converted to Python-style names', async () => {
        // Setup
        const runTestsRequest: IRunTestsRequestBody = {
          bafTestRunId: TEST_BAF_TEST_ID,
          stbtNodeId: STBT_NODE_ID,
          testCases: [TEST_CASE_1, TEST_CASE_2],
          testPackRevision: TEST_PACK_REVISION,
          stbtTags: TEST_STBT_TAGS,
        };

        mockAxiosInstance.post.mockResolvedValue({
          status: HttpStatus.OK,
          data: {},
        });

        const expectedEndpointUrl = 'api/v2/run_tests';
        const expectedPostBody = {
          category: TEST_BAF_TEST_ID,
          node_id: STBT_NODE_ID,
          test_cases: [TEST_CASE_1, TEST_CASE_2],
          // eslint-disable-next-line @typescript-eslint/naming-convention
          test_pack_revision: TEST_PACK_REVISION,
          tags: TEST_STBT_TAGS,
        };

        // Test
        await stbtClient.runTestsAsync(runTestsRequest);

        // Verify
        expect(mockAxiosInstance.post).toHaveBeenCalledTimes(1);
        expect(mockAxiosInstance.post).toHaveBeenCalledWith(
          expectedEndpointUrl,
          expectedPostBody,
        );
      });

      it('converts the response property names from Python form to Javascript form', async () => {
        // Setup
        const axiosPostResponseData = {
          job_uid: TEST_JOB_UID,
          job_url: TEST_JOB_URL,
          status: TEST_STATUS,
          start_time: TEST_START_TIME,
          end_time: TEST_END_TIME,
          result_counts: TEST_RESULT_COUNTS,
        };

        mockAxiosInstance.post.mockResolvedValue({
          status: HttpStatus.OK,
          data: axiosPostResponseData,
        });

        const expectedResult = {
          jobUid: TEST_JOB_UID,
          jobUrl: TEST_JOB_URL,
          status: TEST_STATUS,
          startTime: TEST_START_TIME,
          endTime: TEST_END_TIME,
          resultCounts: {
            pass: TEST_RESULT_COUNTS.pass,
            fail: TEST_RESULT_COUNTS.fail,
            error: TEST_RESULT_COUNTS.error,
            total: TEST_RESULT_COUNTS.total,
          },
        };

        // Test
        const actualResult = await stbtClient.runTestsAsync(
          EMPTY_RUN_TESTS_REQUEST_BODY,
        );

        // Verify
        expect(actualResult).toStrictEqual(expectedResult);
      });

      [
        {
          description: 'one or more of the test paths are invalid',
          responseFile: '400-unknown-test-path',
          expectedError:
            'RunTests: Unknown test "bad/test/case::tests.py". (Remember to include the filename, for example "tests/filename.py::test_something_something".)',
        },
        {
          description: 'the STBT auth token is invalid',
          responseFile: '403-invalid-auth-token',
          expectedError: `STBT auth token "${TEST_STBT_AUTH_TOKEN_REDACTED}" is invalid`,
        },
        {
          description: 'the endpoint path is invalid',
          responseFile: '404-bad-endpoint-path',
          expectedError:
            'STBT REST API endpoint "api/v2/run_testsZZZ" was not found',
        },
        {
          description: 'the git revision specifier is invalid',
          responseFile: '404-unknown-git-revision',
          expectedError:
            'Invalid Git revision specifier "bad-test-pack-revision"',
        },
        {
          description: 'tests are already running on the node',
          responseFile: '409-tests-already-running',
          expectedError:
            "Can't start job; Stb-tester Node stb-tester-00044b80ebf4 is busy running another job",
        },

        {
          description: 'there are too many requests close together',
          responseFile: '429-too-many-requests',
          expectedError: 'STB-Tester request rate limits exceeded',
        },

        {
          description: 'the STBT node id is invalid',
          responseFile: '500-invalid-node',
          expectedError:
            'Internal Server Error from STB-Tester. This may indicate that the STBT node ID "stb-tester-00044b80eeee" is invalid',
        },

        {
          description: 'the STB-Tester node is offline',
          responseFile: '503-node-is-offline',
          expectedError:
            'Node stb-tester-00044b80f7d9 is offline (last seen: 2022-10-17T13:20:58.555145+00:00)',
        },

        {
          description: 'the base URL of the request is invalid',
          responseFile: 'bad-url-error',
          expectedError:
            'STB-Tester REST API URL "hbo123.stb-tester.com" is invalid',
        },

        {
          description: 'if the base URL of the request is omitted',
          responseFile: 'no-url-error',
          expectedError: 'STB-Tester REST API URL was not provided',
        },
      ].forEach(({ description, responseFile, expectedError }) => {
        test(`gives a custom error response when ${description}`, async () => {
          // Setup
          // Load file containing the captured Axios response
          const capturedAxiosError = loadCapturedError(responseFile);

          // Mock the response
          mockAxiosInstance.post.mockRejectedValueOnce(capturedAxiosError);

          // Execute
          const promise = stbtClient.runTestsAsync(
            EMPTY_RUN_TESTS_REQUEST_BODY,
          );

          // Verify
          await expect(promise).rejects.toStrictEqual(new Error(expectedError));
        });
      });

      test(`throws the unchanged Axios error object if no custom error is configured`, async () => {
        // Setup
        // Load file containing the captured Axios response
        const unmappedErrorObject = {
          isA: 'Axios error object for which no custom method is configured',
        };

        // Mock the response
        mockAxiosInstance.post.mockRejectedValueOnce(unmappedErrorObject);

        // Execute
        const promise = stbtClient.runTestsAsync(EMPTY_RUN_TESTS_REQUEST_BODY);

        // Verify
        await expect(promise).rejects.toBe(unmappedErrorObject);
        await expect(promise).rejects.toStrictEqual(unmappedErrorObject);

        expect(mockLoggerWarn).toHaveBeenCalledTimes(1);
        expect(mockLoggerWarn).toHaveBeenCalledWith(
          'An unrecognized Axios error was returned from an attempt to call the STBT REST API:',
          '{"isA":"Axios error object for which no custom method is configured"}',
        );
      });
    });

    describe('waitForTestJobCompletionAsync()', () => {
      it('calls the await_completion endpoint for the job until it returns an HTTPStatus OK (200)', async () => {
        // Setup
        mockAxiosInstance.get
          .mockResolvedValueOnce({
            status: HttpStatus.ACCEPTED,
            data: TEST_JOB_UID,
          })
          .mockResolvedValueOnce({
            status: HttpStatus.ACCEPTED,
            data: TEST_JOB_UID,
          })
          .mockResolvedValue({
            status: HttpStatus.OK,
            data: TEST_JOB_UID,
          });

        const expectedEndpointUrl = `api/v2/jobs/${TEST_JOB_UID}/await_completion`;

        // Test
        await stbtClient.waitForTestJobCompletionAsync(TEST_JOB_UID);

        // Verify
        expect(mockAxiosInstance.get).toHaveBeenCalledTimes(3);
        expect(mockAxiosInstance.get).toHaveBeenNthCalledWith(
          1,
          expectedEndpointUrl,
        );
        expect(mockAxiosInstance.get).toHaveBeenNthCalledWith(
          2,
          expectedEndpointUrl,
        );
        expect(mockAxiosInstance.get).toHaveBeenNthCalledWith(
          3,
          expectedEndpointUrl,
        );
      });
    });

    describe('isTestJobSuccessfulAsync()', () => {
      it('calls the jobs/{job_uid} endpoint with the given job_uid', async () => {
        // Setup
        mockAxiosInstance.get.mockResolvedValue({
          status: HttpStatus.OK,
          data: {
            result_counts: {
              pass: 3,
              fail: 2,
              error: 1,
              total: 6,
            },
          },
        });

        const expectedEndpointUrl = `api/v2/jobs/${TEST_JOB_UID}`;

        // Test
        await stbtClient.isTestJobSuccessfulAsync(TEST_JOB_UID);

        // Verify
        expect(mockAxiosInstance.get).toHaveBeenCalledTimes(1);
        expect(mockAxiosInstance.get).toHaveBeenCalledWith(expectedEndpointUrl);
      });

      it('returns true if all tests pass', async () => {
        // Setup
        const axiosGetResponseData = {
          job_uid: TEST_JOB_UID,
          job_url: TEST_JOB_URL,
          status: TEST_STATUS,
          start_time: TEST_START_TIME,
          end_time: TEST_END_TIME,
          result_counts: {
            pass: 12,
            fail: 0,
            error: 0,
            total: 12,
          },
        };

        mockAxiosInstance.get.mockResolvedValue({
          status: HttpStatus.OK,
          data: axiosGetResponseData,
        });

        const expectedResult = true;

        // Test
        const actualResult = await stbtClient.isTestJobSuccessfulAsync(
          TEST_JOB_UID,
        );

        // Verify
        expect(actualResult).toStrictEqual(expectedResult);
      });

      it('returns false if any tests fail', async () => {
        // Setup
        const axiosGetResponseData = {
          job_uid: TEST_JOB_UID,
          job_url: TEST_JOB_URL,
          status: TEST_STATUS,
          start_time: TEST_START_TIME,
          end_time: TEST_END_TIME,
          result_counts: {
            pass: 12,
            fail: 1,
            error: 0,
            total: 13,
          },
        };

        mockAxiosInstance.get.mockResolvedValue({
          status: HttpStatus.OK,
          data: axiosGetResponseData,
        });

        const expectedResult = false;

        // Test
        const actualResult = await stbtClient.isTestJobSuccessfulAsync(
          TEST_JOB_UID,
        );

        // Verify
        expect(actualResult).toStrictEqual(expectedResult);
      });

      it('returns false if any tests error', async () => {
        // Setup
        const axiosGetResponseData = {
          job_uid: TEST_JOB_UID,
          job_url: TEST_JOB_URL,
          status: TEST_STATUS,
          start_time: TEST_START_TIME,
          end_time: TEST_END_TIME,
          result_counts: {
            pass: 12,
            fail: 0,
            error: 1,
            total: 13,
          },
        };

        mockAxiosInstance.get.mockResolvedValue({
          status: HttpStatus.OK,
          data: axiosGetResponseData,
        });

        const expectedResult = false;

        // Test
        const actualResult = await stbtClient.isTestJobSuccessfulAsync(
          TEST_JOB_UID,
        );

        // Verify
        expect(actualResult).toStrictEqual(expectedResult);
      });
    });

    describe('getArtifactFromTestRunAsync()', () => {
      it('calls the results/{result_id}/artifacts/{filename} endpoint with the given result_id and filename', async () => {
        // Setup
        const stepsResultData = {
          keyword: 'Feature',
          uri: 'step_definition/../welcomeScreen.feature',
          name: 'Welcome Screen',
          id: 'step_definition/../welcomescreen.feature',
          line: 2,
          description:
            'As a user I should be able to verify Welcome Screen functionality',
          tags: [Array],
          elements: [Array],
        };

        const stepsFileContents = [stepsResultData];

        mockAxiosInstance.get.mockResolvedValue({
          status: HttpStatus.OK,
          data: stepsFileContents,
        });

        const expectedEndpointUrl: string = `api/v2/results/${TEST_RESULT_ID_1}/artifacts/${TEST_STEPS_FILE_NAME}`;

        // Test
        const actualArtifactContents: unknown =
          await stbtClient.getArtifactFromTestRunAsync(
            TEST_RESULT_ID_1,
            TEST_STEPS_FILE_NAME,
          );

        // Verify
        expect(mockAxiosInstance.get).toHaveBeenCalledTimes(1);
        expect(mockAxiosInstance.get).toHaveBeenCalledWith(expectedEndpointUrl);

        expect(actualArtifactContents).toStrictEqual(stepsFileContents);
      });
    });

    describe('getJobBddStepsResultsAsync()', () => {
      it('gathers the json responses and combines them into one object', async () => {
        // Setup
        const localStbtClient: StbtClient = new StbtClient(
          TEST_STBT_AUTH_TOKEN,
        );

        const stepResultOne: IStepsResult = {
          isA: 'first steps.json file',
        } as unknown as IStepsResult;

        const stepResultTwo: IStepsResult = {
          isA: 'second steps.json file',
        } as unknown as IStepsResult;

        const stepsJsonFiles: StepsFileFormat[] = [
          [stepResultOne],
          [stepResultTwo],
        ];

        const expectedBddResultsJson: IStepsResult[] = [
          stepResultOne,
          stepResultTwo,
        ];

        // We expect three calls:
        //    1: Get the list of test results for the test job,
        //    2. Get the steps.json for the first test result
        //    3. Get the steps.json for the second test result
        mockAxiosGet.mockImplementation((endpoint) => {
          if (endpoint === 'api/v2/results') {
            return { data: TEST_RESULTS_IN_JOB };
          }
          if (
            endpoint === 'api/v2/results/test_result_id_1/artifacts/steps.json'
          ) {
            return { data: stepsJsonFiles[0] };
          }
          if (
            endpoint === 'api/v2/results/test_result_id_2/artifacts/steps.json'
          ) {
            return { data: stepsJsonFiles[1] };
          }
          throw new Error(
            `Test failed: unexpected STBT REST API endpoint ${endpoint} requested`,
          );
        });

        // Execute
        const actualBddResultsJson =
          await localStbtClient.getJobBddStepsResultsAsync(TEST_JOB_UID);

        // Verify
        expect(mockAxiosGet).toHaveBeenCalledTimes(3);
        expect(mockAxiosGet).toHaveBeenNthCalledWith(1, 'api/v2/results', {
          params: { filter: 'job:test_job_uid' },
        });
        expect(mockAxiosGet).toHaveBeenNthCalledWith(
          2,
          'api/v2/results/test_result_id_1/artifacts/steps.json',
        );
        expect(mockAxiosGet).toHaveBeenNthCalledWith(
          3,
          'api/v2/results/test_result_id_2/artifacts/steps.json',
        );

        expect(actualBddResultsJson).toStrictEqual(expectedBddResultsJson);
      });
    });
  });
});
