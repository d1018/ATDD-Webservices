// Copyright text placeholder, Warner Bros. Discovery, Inc.

/* eslint-disable no-console */

// Mock BafTestCase
const mockBafTestCaseConstructor = jest.fn();

jest.mock('../../../lib/stbt-baf-test-run/BafTestCase', () => ({
  BafTestCase: mockBafTestCaseConstructor,
}));

// Mock BafTestRunner
const mockBafTestRunnerConstructor = jest.fn();

jest.mock('../../../lib/stbt-baf-test-run/BafTestRunner', () => ({
  BafTestRunner: mockBafTestRunnerConstructor,
}));

// Mock BafTestResultsFetcher
const mockBafTestResultsFetcherConstructor = jest.fn();

jest.mock('../../../lib/stbt-baf-test-run/BafTestResultsFetcher', () => ({
  BafTestResultsFetcher: mockBafTestResultsFetcherConstructor,
}));

// Mock BafTestRunLogger
const mockBafTestRunLoggerConstructor = jest.fn();

jest.mock('../../../lib/stbt-baf-test-run/logging', () => ({
  BafTestRunLogger: mockBafTestRunLoggerConstructor,
}));

// Mock uuid()
const mockUuid = jest.fn();

jest.mock('uuid', () => ({
  v4: mockUuid,
}));

import {
  IStepsResult,
  ITestResult,
  StbtClient,
} from '../../../lib/stbt-client';
import {
  BafTestCase,
  BafTestManager,
  BafTestResultsFetcher,
  BafTestRunLogger,
  BafTestRunner,
  IBafTestCaseOutcome,
  // BafTestRunner,
  IBafTestRunParams,
  IBafTestRunResults,
} from '../../../lib/stbt-baf-test-run';

const mockBafTestResultsFetcherGetResultsAsync = jest.fn();
const mockBafTestResultsFetcherInstance: BafTestResultsFetcher = {
  getResultsAsync: mockBafTestResultsFetcherGetResultsAsync,
} as unknown as BafTestResultsFetcher;

const mockLogTestExecutionsStart = jest.fn();
const mockLogTestExecutionsEnd = jest.fn();
const mockLogFrameworkErrors = jest.fn();
const mockLogTestRunResults = jest.fn();
const mockBafTestRunLoggerInstance: BafTestRunLogger = {
  logTestExecutionsStart: mockLogTestExecutionsStart,
  logTestExecutionsEnd: mockLogTestExecutionsEnd,
  logFrameworkErrors: mockLogFrameworkErrors,
  logTestRunResults: mockLogTestRunResults,
} as unknown as BafTestRunLogger;

describe('lib/stbt-baf-test-run/BafTestManager', () => {
  const SAMPLE_STBT_NODE_ID_1: string = 'sampleStbtNodeId1';
  const SAMPLE_STBT_NODE_ID_2: string = 'sampleStbtNodeId2';

  const SAMPLE_STBT_NODE_IDS: string[] = [
    SAMPLE_STBT_NODE_ID_1,
    SAMPLE_STBT_NODE_ID_2,
  ];

  const SAMPLE_UUID: string = '1st6characters';
  const EXPECTED_TEST_RUN_ID: string = '1st6ch';
  const EXPECTED_APP_PORTAL_URL: string =
    'https://hbo.stb-tester.com/app/#/results?filter=category:1st6ch';
  const EXPECTED_REST_API_URL: string =
    'https://hbo.stb-tester.com/api/v2/results?filter=category:1st6ch';

  const SAMPLE_STBT_CLIENT: StbtClient = {
    isA: 'sample mock StbtClient',
  } as unknown as StbtClient;

  const SAMPLE_STBT_TAGS: Record<string, string | undefined> = {
    SAMPLE_STBT_TAG: 'sample stbt tag value',
  };

  const SAMPLE_BDD_TEST_CASE_1: string = 'sample BDD test case 1';
  const SAMPLE_BDD_TEST_CASE_2: string = 'sample BDD test case 2';
  const SAMPLE_BDD_TEST_CASE_3: string = 'sample BDD test case 3';

  const SAMPLE_BDD_TEST_CASES: string[] = [
    SAMPLE_BDD_TEST_CASE_1,
    SAMPLE_BDD_TEST_CASE_2,
    SAMPLE_BDD_TEST_CASE_3,
  ];

  const DUMMY_BAF_TEST_CASE_1: BafTestCase = {
    isA: 'dummy BafTestCase 1',
  } as unknown as BafTestCase;

  const DUMMY_BAF_TEST_CASE_2: BafTestCase = {
    isA: 'dummy BafTestCase 2',
  } as unknown as BafTestCase;

  const DUMMY_BAF_TEST_CASE_3: BafTestCase = {
    isA: 'dummy BafTestCase 3',
  } as unknown as BafTestCase;

  const SAMPLE_TEST_PACK_REVISION: string = 'aaa0sample0git0shaaa';

  const SAMPLE_BAF_TEST_RUN_PARAMS: IBafTestRunParams = {
    stbtClient: SAMPLE_STBT_CLIENT,
    stbtNodeIds: SAMPLE_STBT_NODE_IDS,
    stbtTags: SAMPLE_STBT_TAGS,
    testCases: SAMPLE_BDD_TEST_CASES,
    testPackRevision: SAMPLE_TEST_PACK_REVISION,
  };

  const DUMMY_BAF_TEST_RUNNER_1: BafTestRunner = {
    isA: 'dummy BafTestRunner 1',
    runTestCasesAsync: jest.fn(),
  } as unknown as BafTestRunner;

  const DUMMY_BAF_TEST_RUNNER_2: BafTestRunner = {
    isA: 'dummy BafTestRunner 2',
    runTestCasesAsync: jest.fn(),
  } as unknown as BafTestRunner;

  const DUMMY_TEST_CASE_OUTCOME_SUCCESS: IBafTestCaseOutcome = {
    isFrameworkError: false,
    isSuccess: true,
    testResult: {
      isA: 'stbt test result JSON object',
    } as unknown as ITestResult,
    bddStepsResult: {
      isA: 'stbt steps.json file result thingy',
    } as unknown as IStepsResult,
  };

  const DUMMY_TEST_CASE_OUTCOME_FAILURE: IBafTestCaseOutcome = {
    isFrameworkError: false,
    isSuccess: false,
    testResult: {
      isA: 'stbt test result JSON object',
    } as unknown as ITestResult,
    bddStepsResult: {
      isA: 'stbt steps.json file result thingy',
    } as unknown as IStepsResult,
  };

  const DUMMY_TEST_CASE_OUTCOME_FRAMEWORK_ERROR: IBafTestCaseOutcome = {
    isFrameworkError: true,
    error: {
      isA: 'framework error of some kind',
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();
    mockUuid.mockReturnValueOnce(SAMPLE_UUID);
    mockBafTestResultsFetcherConstructor.mockReturnValueOnce(
      mockBafTestResultsFetcherInstance,
    );
    mockBafTestRunLoggerConstructor.mockReturnValue(
      mockBafTestRunLoggerInstance,
    );
  });

  it('assigns itself a test run ID with uuid()', () => {
    const bafTestRun: BafTestManager = new BafTestManager(
      SAMPLE_BAF_TEST_RUN_PARAMS,
    );

    expect(bafTestRun.id).toBe(EXPECTED_TEST_RUN_ID);
  });

  it('provides URLs to get its results from the STBT App Portal webapp and the STBT REST API', () => {
    const bafTestRun: BafTestManager = new BafTestManager(
      SAMPLE_BAF_TEST_RUN_PARAMS,
    );

    expect(bafTestRun.appPortalUrl).toBe(EXPECTED_APP_PORTAL_URL);
    expect(bafTestRun.restApiUrl).toBe(EXPECTED_REST_API_URL);
  });

  it('logs its own creation', () => {
    // Execute
    new BafTestManager(SAMPLE_BAF_TEST_RUN_PARAMS);

    // Verify
    expect(mockBafTestRunLoggerConstructor).toHaveBeenCalledWith({
      testRunId: EXPECTED_TEST_RUN_ID,
      stbtNodeIds: SAMPLE_STBT_NODE_IDS,
      testCases: SAMPLE_BDD_TEST_CASES,
      testPackRevision: SAMPLE_TEST_PACK_REVISION,
      stbtTags: SAMPLE_STBT_TAGS,
    });
  });

  it('creates a BafTestCase for each BDD test case it is given, forwarding the relevant config values to it', () => {
    // Execute
    new BafTestManager(SAMPLE_BAF_TEST_RUN_PARAMS);

    // Verify
    expect(mockBafTestCaseConstructor).toHaveBeenNthCalledWith(1, {
      bafTestRunId: EXPECTED_TEST_RUN_ID,
      stbtClient: SAMPLE_STBT_CLIENT,
      testCase: SAMPLE_BDD_TEST_CASE_1,
      testPackRevision: SAMPLE_TEST_PACK_REVISION,
      stbtTags: SAMPLE_STBT_TAGS,
    });
    expect(mockBafTestCaseConstructor).toHaveBeenNthCalledWith(2, {
      bafTestRunId: EXPECTED_TEST_RUN_ID,
      stbtClient: SAMPLE_STBT_CLIENT,
      testCase: SAMPLE_BDD_TEST_CASE_2,
      testPackRevision: SAMPLE_TEST_PACK_REVISION,
      stbtTags: SAMPLE_STBT_TAGS,
    });
    expect(mockBafTestCaseConstructor).toHaveBeenNthCalledWith(3, {
      bafTestRunId: EXPECTED_TEST_RUN_ID,
      stbtClient: SAMPLE_STBT_CLIENT,
      testCase: SAMPLE_BDD_TEST_CASE_3,
      testPackRevision: SAMPLE_TEST_PACK_REVISION,
      stbtTags: SAMPLE_STBT_TAGS,
    });

    expect(mockBafTestCaseConstructor).toHaveBeenCalledTimes(3);
  });

  it('creates a BafTestRunner for each STBT node id it is given, passing it pending test case queue and the shared test results fetcher', () => {
    // Setup
    mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_1);
    mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_2);
    mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_3);

    // Execute
    new BafTestManager(SAMPLE_BAF_TEST_RUN_PARAMS);

    // Verify
    expect(mockBafTestRunnerConstructor).toHaveBeenNthCalledWith(1, {
      stbtNodeId: SAMPLE_STBT_NODE_ID_1,
      pendingTestCases: [
        DUMMY_BAF_TEST_CASE_1,
        DUMMY_BAF_TEST_CASE_2,
        DUMMY_BAF_TEST_CASE_3,
      ],
      bafTestResultsFetcher: mockBafTestResultsFetcherInstance,
    });
    expect(mockBafTestRunnerConstructor).toHaveBeenNthCalledWith(2, {
      stbtNodeId: SAMPLE_STBT_NODE_ID_2,
      pendingTestCases: [
        DUMMY_BAF_TEST_CASE_1,
        DUMMY_BAF_TEST_CASE_2,
        DUMMY_BAF_TEST_CASE_3,
      ],
      bafTestResultsFetcher: mockBafTestResultsFetcherInstance,
    });
  });

  describe('runTestsAsync()', () => {
    it('calls all of the test runners to execute the test cases', async () => {
      // Setup
      // Return the mock test cases
      mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_1);
      mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_2);
      mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_3);

      // Return the mock test runners
      mockBafTestRunnerConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_RUNNER_1);
      mockBafTestRunnerConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_RUNNER_2);

      // Create the test manager
      const bafTestManager: BafTestManager = new BafTestManager(
        SAMPLE_BAF_TEST_RUN_PARAMS,
      );

      // Return some mock test case outcomes
      const mockTestCaseOutcomes: IBafTestCaseOutcome[] = [
        DUMMY_TEST_CASE_OUTCOME_SUCCESS,
        DUMMY_TEST_CASE_OUTCOME_FAILURE,
      ];

      mockBafTestResultsFetcherGetResultsAsync.mockResolvedValueOnce(
        mockTestCaseOutcomes,
      );

      // Execute
      await bafTestManager.runTestsAsync();

      // Verify
      expect(DUMMY_BAF_TEST_RUNNER_1.runTestCasesAsync).toHaveBeenCalledTimes(
        1,
      );
      expect(DUMMY_BAF_TEST_RUNNER_2.runTestCasesAsync).toHaveBeenCalledTimes(
        1,
      );
    });

    it('calls the BafTestResultsFetcher to get the results of all of the tests', async () => {
      // Setup
      // Return the mock test cases
      mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_1);
      mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_2);
      mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_3);

      // Return the mock test runners
      mockBafTestRunnerConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_RUNNER_1);
      mockBafTestRunnerConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_RUNNER_2);

      // Create the test manager
      const bafTestManager: BafTestManager = new BafTestManager(
        SAMPLE_BAF_TEST_RUN_PARAMS,
      );

      // Return some mock test case outcomes
      const mockTestCaseOutcomes: IBafTestCaseOutcome[] = [
        DUMMY_TEST_CASE_OUTCOME_SUCCESS,
        DUMMY_TEST_CASE_OUTCOME_FAILURE,
      ];

      mockBafTestResultsFetcherGetResultsAsync.mockResolvedValueOnce(
        mockTestCaseOutcomes,
      );

      // Execute
      await bafTestManager.runTestsAsync();

      // Verify
      expect(
        mockBafTestResultsFetcherInstance.getResultsAsync,
      ).toHaveBeenCalledTimes(1);
    });

    it('throws a "test run INVALID" Error if there are any framework errors, and logs the framework errors', async () => {
      // Setup
      // Return the mock test cases
      mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_1);
      mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_2);
      mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_3);

      // Return the mock test runners
      mockBafTestRunnerConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_RUNNER_1);
      mockBafTestRunnerConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_RUNNER_2);

      const mockTestCaseOutcomes: IBafTestCaseOutcome[] = [
        DUMMY_TEST_CASE_OUTCOME_SUCCESS,
        DUMMY_TEST_CASE_OUTCOME_FAILURE,
        DUMMY_TEST_CASE_OUTCOME_FRAMEWORK_ERROR,
      ];

      // Return the mock test outcomes
      mockBafTestResultsFetcherGetResultsAsync.mockResolvedValueOnce(
        mockTestCaseOutcomes,
      );

      // Create the test manager
      const bafTestManager: BafTestManager = new BafTestManager(
        SAMPLE_BAF_TEST_RUN_PARAMS,
      );

      // Execute & Verify Error
      await expect(() => bafTestManager.runTestsAsync()).rejects.toEqual(
        new Error(
          'BAF test run INVALID: 1 framework error(s) in 3 test execution(s).',
        ),
      );

      // Verify Logging
      expect(mockLogTestExecutionsStart).toHaveBeenCalledWith(
        EXPECTED_APP_PORTAL_URL,
        EXPECTED_REST_API_URL,
      );
      expect(mockLogTestExecutionsStart).toHaveBeenCalledTimes(1);

      expect(mockLogTestExecutionsEnd).toHaveBeenCalledWith();
      expect(mockLogTestExecutionsEnd).toHaveBeenCalledTimes(1);

      expect(mockLogFrameworkErrors).toHaveBeenCalledWith([
        DUMMY_TEST_CASE_OUTCOME_FRAMEWORK_ERROR,
      ]);
      expect(mockLogFrameworkErrors).toHaveBeenCalledTimes(1);

      expect(mockLogTestRunResults).not.toHaveBeenCalled();
    });

    it('returns a failure result for the test run if any tests failed, and logs the test run results', async () => {
      // Setup
      // Return the mock test cases
      mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_1);
      mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_2);

      // Return the mock test runners
      mockBafTestRunnerConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_RUNNER_1);
      mockBafTestRunnerConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_RUNNER_2);

      const mockTestCaseOutcomes: IBafTestCaseOutcome[] = [
        DUMMY_TEST_CASE_OUTCOME_SUCCESS,
        DUMMY_TEST_CASE_OUTCOME_FAILURE,
      ];

      // Return the mock test outcomes
      mockBafTestResultsFetcherGetResultsAsync.mockResolvedValueOnce(
        mockTestCaseOutcomes,
      );

      // Create the test manager
      const bafTestManager: BafTestManager = new BafTestManager(
        SAMPLE_BAF_TEST_RUN_PARAMS,
      );

      // Execute & Verify
      const testRunResults: IBafTestRunResults =
        await bafTestManager.runTestsAsync();

      // Verify
      const expectedTestRunResults: IBafTestRunResults = {
        isSuccess: false,
        testResults: [
          DUMMY_TEST_CASE_OUTCOME_SUCCESS.testResult,
          DUMMY_TEST_CASE_OUTCOME_FAILURE.testResult,
        ],
        bddStepsResults: [
          DUMMY_TEST_CASE_OUTCOME_SUCCESS.bddStepsResult,
          DUMMY_TEST_CASE_OUTCOME_FAILURE.bddStepsResult,
        ],
      };

      expect(testRunResults).toStrictEqual(expectedTestRunResults);

      // Verify Logging
      expect(mockLogTestExecutionsStart).toHaveBeenCalledWith(
        EXPECTED_APP_PORTAL_URL,
        EXPECTED_REST_API_URL,
      );
      expect(mockLogTestExecutionsStart).toHaveBeenCalledTimes(1);

      expect(mockLogTestExecutionsEnd).toHaveBeenCalledWith();
      expect(mockLogTestExecutionsEnd).toHaveBeenCalledTimes(1);

      expect(mockLogTestRunResults).toHaveBeenCalledWith(
        expectedTestRunResults,
      );
      expect(mockLogTestRunResults).toHaveBeenCalledTimes(1);

      expect(mockLogFrameworkErrors).not.toHaveBeenCalled();
    });

    it('returns a success result for the test run if all of the tests passed, and logs the test run results', async () => {
      // Setup
      // Return the mock test cases
      mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_1);
      mockBafTestCaseConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_CASE_2);

      // Return the mock test runners
      mockBafTestRunnerConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_RUNNER_1);
      mockBafTestRunnerConstructor.mockReturnValueOnce(DUMMY_BAF_TEST_RUNNER_2);

      const mockTestCaseOutcomes: IBafTestCaseOutcome[] = [
        DUMMY_TEST_CASE_OUTCOME_SUCCESS,
        DUMMY_TEST_CASE_OUTCOME_SUCCESS,
      ];

      // Return the mock test outcomes
      mockBafTestResultsFetcherGetResultsAsync.mockResolvedValueOnce(
        mockTestCaseOutcomes,
      );

      // Create the test manager
      const bafTestManager: BafTestManager = new BafTestManager(
        SAMPLE_BAF_TEST_RUN_PARAMS,
      );

      // Execute & Verify
      const testRunResults: IBafTestRunResults =
        await bafTestManager.runTestsAsync();

      // Verify
      const expectedTestRunResults: IBafTestRunResults = {
        isSuccess: true,
        testResults: [
          DUMMY_TEST_CASE_OUTCOME_SUCCESS.testResult,
          DUMMY_TEST_CASE_OUTCOME_SUCCESS.testResult,
        ],
        bddStepsResults: [
          DUMMY_TEST_CASE_OUTCOME_SUCCESS.bddStepsResult,
          DUMMY_TEST_CASE_OUTCOME_SUCCESS.bddStepsResult,
        ],
      };

      expect(testRunResults).toStrictEqual(expectedTestRunResults);

      // Verify Logging
      expect(mockLogTestExecutionsStart).toHaveBeenCalledWith(
        EXPECTED_APP_PORTAL_URL,
        EXPECTED_REST_API_URL,
      );
      expect(mockLogTestExecutionsStart).toHaveBeenCalledTimes(1);

      expect(mockLogTestExecutionsEnd).toHaveBeenCalledWith();
      expect(mockLogTestExecutionsEnd).toHaveBeenCalledTimes(1);

      expect(mockLogTestRunResults).toHaveBeenCalledWith(
        expectedTestRunResults,
      );
      expect(mockLogTestRunResults).toHaveBeenCalledTimes(1);

      expect(mockLogFrameworkErrors).not.toHaveBeenCalled();
    });
  });
});
