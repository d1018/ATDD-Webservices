// Copyright text placeholder, Warner Bros. Discovery, Inc.

/* eslint-disable no-console */

const mockFetchResults = jest.fn();

jest.mock('../../../lib/stbt-baf-test-run/BafTestResultsFetcher', () => {});

import {
  BafTestCase,
  BafTestResultsFetcher,
  BafTestRunner,
} from '../../../lib/stbt-baf-test-run';
import { delay } from '../../../support/utilities';

describe('lib/stbt-baf-test-run/BafTestRunner', () => {
  const SAMPLE_STBT_NODE_ID_1 = 'sampleStbtNodeId1';
  const SAMPLE_STBT_NODE_ID_2 = 'sampleStbtNodeId2';

  const mockRunTestAsync1 = jest.fn();
  const TEST_CASE_1: BafTestCase = {
    isA: 'testCase1',
    runTestAsync: mockRunTestAsync1,
  } as unknown as BafTestCase;

  const mockRunTestAsync2 = jest.fn();
  const TEST_CASE_2: BafTestCase = {
    isA: 'testCase2',
    runTestAsync: mockRunTestAsync2,
  } as unknown as BafTestCase;

  const mockRunTestAsync3 = jest.fn();
  const TEST_CASE_3: BafTestCase = {
    isA: 'testCase3',
    runTestAsync: mockRunTestAsync3,
  } as unknown as BafTestCase;

  const mockRunTestAsync4 = jest.fn();
  const TEST_CASE_4: BafTestCase = {
    isA: 'testCase4',
    runTestAsync: mockRunTestAsync4,
  } as unknown as BafTestCase;

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('runs each test case in turn', async () => {
    // Setup
    const reportedExecutions: BafTestCase[] = [];

    mockRunTestAsync1.mockImplementation(async () => {
      if (reportedExecutions.length !== 0) {
        console.log(reportedExecutions);
        throw new Error('Test case 1 did not run 1st');
      }
      reportedExecutions.push(TEST_CASE_1);
      await delay(500);

      // @ts-ignore
      if (reportedExecutions.length !== 1) {
        console.log(reportedExecutions);
        throw new Error(
          'Some other test case ran while test case 1 was running',
        );
      }
    });

    mockRunTestAsync2.mockImplementation(async () => {
      if (reportedExecutions.length !== 1) {
        console.log(reportedExecutions);
        throw new Error('Test case 2 did not run 2nd');
      }
      reportedExecutions.push(TEST_CASE_2);
      await delay(300);

      // @ts-ignore
      if (reportedExecutions.length !== 2) {
        console.log(reportedExecutions);
        throw new Error(
          'Some other test case ran while test case 2 was running',
        );
      }
    });

    mockRunTestAsync3.mockImplementation(async () => {
      if (reportedExecutions.length !== 2) {
        console.log(reportedExecutions);
        throw new Error('Test case 3 did not run 3rd.');
      }
      reportedExecutions.push(TEST_CASE_3);
      await delay(300);

      // @ts-ignore
      if (reportedExecutions.length !== 3) {
        console.log(reportedExecutions);
        throw new Error(
          'Some other test case ran while test case 3 was running',
        );
      }
    });

    mockRunTestAsync4.mockImplementation(async () => {
      if (reportedExecutions.length !== 3) {
        console.log(reportedExecutions);
        throw new Error('Test case 4 did not run 4th.');
      }
      reportedExecutions.push(TEST_CASE_4);
      await delay(50);

      // @ts-ignore
      if (reportedExecutions.length !== 4) {
        console.log(reportedExecutions);
        throw new Error(
          'Some other test case ran while test case 4 was running',
        );
      }
    });

    const bafTestResultsFetcher: BafTestResultsFetcher = {
      fetchResults: mockFetchResults,
    } as unknown as BafTestResultsFetcher;

    const pendingTestCases: BafTestCase[] = [
      TEST_CASE_1,
      TEST_CASE_2,
      TEST_CASE_3,
      TEST_CASE_4,
    ];

    const bafTestRunner: BafTestRunner = new BafTestRunner({
      stbtNodeId: SAMPLE_STBT_NODE_ID_1,
      bafTestResultsFetcher,
      pendingTestCases,
    });

    // Execute
    await bafTestRunner.runTestCasesAsync();

    // Verify
    expect(mockRunTestAsync1).toHaveBeenCalledWith(SAMPLE_STBT_NODE_ID_1);
    expect(mockRunTestAsync2).toHaveBeenCalledWith(SAMPLE_STBT_NODE_ID_1);
    expect(mockRunTestAsync3).toHaveBeenCalledWith(SAMPLE_STBT_NODE_ID_1);
    expect(mockRunTestAsync4).toHaveBeenCalledWith(SAMPLE_STBT_NODE_ID_1);

    expect(mockRunTestAsync1).toHaveBeenCalledTimes(1);
    expect(mockRunTestAsync2).toHaveBeenCalledTimes(1);
    expect(mockRunTestAsync3).toHaveBeenCalledTimes(1);
    expect(mockRunTestAsync4).toHaveBeenCalledTimes(1);

    expect(mockRunTestAsync1.mock.invocationCallOrder[0]).toBeLessThan(
      mockRunTestAsync2.mock.invocationCallOrder[0],
    );
    expect(mockRunTestAsync2.mock.invocationCallOrder[0]).toBeLessThan(
      mockRunTestAsync3.mock.invocationCallOrder[0],
    );
    expect(mockRunTestAsync3.mock.invocationCallOrder[0]).toBeLessThan(
      mockRunTestAsync4.mock.invocationCallOrder[0],
    );

    expect(mockFetchResults).toHaveBeenNthCalledWith(1, TEST_CASE_1);
    expect(mockFetchResults).toHaveBeenNthCalledWith(2, TEST_CASE_2);
    expect(mockFetchResults).toHaveBeenNthCalledWith(3, TEST_CASE_3);
    expect(mockFetchResults).toHaveBeenNthCalledWith(4, TEST_CASE_4);
    expect(mockFetchResults).toHaveBeenCalledTimes(4);
  });

  it('divides the test cases between multiple BafTestRunners that share a pending BafTestCase queue and a BafTestResultsFetcher', async () => {
    // Setup
    const reportedExecutionsNode1: BafTestCase[] = [];
    const reportedExecutionsNode2: BafTestCase[] = [];

    mockRunTestAsync1.mockImplementation(async (nodeId: string) => {
      if (nodeId !== SAMPLE_STBT_NODE_ID_1) {
        throw new Error('Test case 1 did not run on node 1');
      }
      if (reportedExecutionsNode1.length > 0) {
        console.log(reportedExecutionsNode1);
        throw new Error('Test case 1 did not run 1st on node 1');
      }
      reportedExecutionsNode1.push(TEST_CASE_1);
      await delay(500);

      // @ts-ignore
      if (reportedExecutionsNode1.length > 1) {
        console.log(reportedExecutionsNode1);
        throw new Error(
          'Some other test case ran on node 1 while test case 1 was running',
        );
      }
    });

    mockRunTestAsync2.mockImplementation(async (nodeId) => {
      if (nodeId !== SAMPLE_STBT_NODE_ID_2) {
        throw new Error('Test case 2 did not run on node 2');
      }
      if (reportedExecutionsNode2.length > 0) {
        console.log(reportedExecutionsNode2);
        throw new Error('Test case 2 did not run 1st on node 2');
      }
      reportedExecutionsNode2.push(TEST_CASE_2);
      await delay(300);

      // @ts-ignore
      if (reportedExecutionsNode2.length > 1) {
        console.log(reportedExecutionsNode2);
        throw new Error(
          'Some other test case ran on node 2 while test case 2 was running',
        );
      }
    });

    mockRunTestAsync3.mockImplementation(async (nodeId) => {
      if (nodeId !== SAMPLE_STBT_NODE_ID_2) {
        throw new Error('Test case 3 did not run on node 2');
      }
      if (reportedExecutionsNode2.length > 1) {
        console.log(reportedExecutionsNode2);
        throw new Error('Test case 3 did not run 2nd on node 2');
      }
      reportedExecutionsNode2.push(TEST_CASE_3);
      await delay(300);

      // @ts-ignore
      if (reportedExecutionsNode2.length > 2) {
        console.log(reportedExecutionsNode2);
        throw new Error(
          'Some other test case ran on node 2 while test case 3 was running',
        );
      }
    });

    mockRunTestAsync4.mockImplementation(async (nodeId) => {
      if (nodeId !== SAMPLE_STBT_NODE_ID_1) {
        throw new Error('Test case 4 did not run on node 1');
      }
      if (reportedExecutionsNode1.length > 1) {
        console.log(reportedExecutionsNode1);
        throw new Error('Test case 4 did not run 2nd on node 1');
      }
      reportedExecutionsNode1.push(TEST_CASE_4);
      await delay(50);

      // @ts-ignore
      if (reportedExecutionsNode1.length > 2) {
        console.log(reportedExecutionsNode1);
        throw new Error(
          'Some other test case ran on node 1 while test case 4 was running',
        );
      }
    });

    const bafTestResultsFetcher: BafTestResultsFetcher = {
      fetchResults: mockFetchResults,
    } as unknown as BafTestResultsFetcher;

    const pendingTestCases: BafTestCase[] = [
      TEST_CASE_1,
      TEST_CASE_2,
      TEST_CASE_3,
      TEST_CASE_4,
    ];

    const bafTestRunner1: BafTestRunner = new BafTestRunner({
      stbtNodeId: SAMPLE_STBT_NODE_ID_1,
      bafTestResultsFetcher,
      pendingTestCases,
    });

    const bafTestRunner2: BafTestRunner = new BafTestRunner({
      stbtNodeId: SAMPLE_STBT_NODE_ID_2,
      bafTestResultsFetcher,
      pendingTestCases,
    });

    // Execute
    await Promise.all([
      bafTestRunner1.runTestCasesAsync(),
      bafTestRunner2.runTestCasesAsync(),
    ]);

    // Verify
    // Test cases 1 and 4 ran on node 1; test cases 2 & 3 ran on node 2
    expect(mockRunTestAsync1).toHaveBeenCalledWith(SAMPLE_STBT_NODE_ID_1);
    expect(mockRunTestAsync2).toHaveBeenCalledWith(SAMPLE_STBT_NODE_ID_2);
    expect(mockRunTestAsync3).toHaveBeenCalledWith(SAMPLE_STBT_NODE_ID_2);
    expect(mockRunTestAsync4).toHaveBeenCalledWith(SAMPLE_STBT_NODE_ID_1);

    // Every test case was run once
    expect(mockRunTestAsync1).toHaveBeenCalledTimes(1);
    expect(mockRunTestAsync2).toHaveBeenCalledTimes(1);
    expect(mockRunTestAsync3).toHaveBeenCalledTimes(1);
    expect(mockRunTestAsync4).toHaveBeenCalledTimes(1);

    // Order in which the test cases were started: 1, 2, 3, 4
    expect(mockRunTestAsync1.mock.invocationCallOrder[0]).toBeLessThan(
      mockRunTestAsync2.mock.invocationCallOrder[0],
    );
    expect(mockRunTestAsync2.mock.invocationCallOrder[0]).toBeLessThan(
      mockRunTestAsync3.mock.invocationCallOrder[0],
    );
    expect(mockRunTestAsync3.mock.invocationCallOrder[0]).toBeLessThan(
      mockRunTestAsync4.mock.invocationCallOrder[0],
    );

    // Order in which the test cases finished: 2, 1, 4, 3
    expect(mockFetchResults).toHaveBeenNthCalledWith(1, TEST_CASE_2);
    expect(mockFetchResults).toHaveBeenNthCalledWith(2, TEST_CASE_1);
    expect(mockFetchResults).toHaveBeenNthCalledWith(3, TEST_CASE_4);
    expect(mockFetchResults).toHaveBeenNthCalledWith(4, TEST_CASE_3);
    expect(mockFetchResults).toHaveBeenCalledTimes(4);
  });
});
