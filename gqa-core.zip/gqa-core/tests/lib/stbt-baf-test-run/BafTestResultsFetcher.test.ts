// Copyright text placeholder, Warner Bros. Discovery, Inc.

import {
  BafTestCase,
  BafTestResultsFetcher,
  IBafFrameworkError,
  IBafTestCaseResults,
} from '../../../lib/stbt-baf-test-run';
import { delay } from '../../../support/utilities';

describe('lib/stbt-baf-test-run/BafTestResultsFetcher', () => {
  const TEST_CASE_1_RESULTS: IBafTestCaseResults = {
    isA: 'test case 1 results',
  } as unknown as IBafTestCaseResults;
  const mockGetResultsAsync1 = jest.fn();
  const TEST_CASE_1: BafTestCase = {
    getResultsAsync: mockGetResultsAsync1,
  } as unknown as BafTestCase;

  const TEST_CASE_2_RESULTS: IBafTestCaseResults = {
    isA: 'test case 2 results',
  } as unknown as IBafTestCaseResults;
  const mockGetResultsAsync2 = jest.fn();
  const TEST_CASE_2_WITH_DELAY: BafTestCase = {
    getResultsAsync: mockGetResultsAsync2,
  } as unknown as BafTestCase;

  const TEST_CASE_3_RESULTS_1: IBafTestCaseResults = {
    isA: 'test case 3 initial results',
  } as unknown as IBafTestCaseResults;
  const TEST_CASE_3_RESULTS_2: IBafTestCaseResults = {
    isA: 'test case 3 final results',
  } as unknown as IBafTestCaseResults;
  const mockGetResultsAsync3 = jest.fn();
  const TEST_CASE_3: BafTestCase = {
    getResultsAsync: mockGetResultsAsync3,
  } as unknown as BafTestCase;

  beforeEach(() => {
    jest.clearAllMocks();

    mockGetResultsAsync1.mockResolvedValue(TEST_CASE_1_RESULTS);

    mockGetResultsAsync2.mockImplementation(async () => {
      await delay(200);
      return TEST_CASE_2_RESULTS;
    });
    mockGetResultsAsync3.mockResolvedValueOnce(TEST_CASE_3_RESULTS_1);
    mockGetResultsAsync3.mockResolvedValue(TEST_CASE_3_RESULTS_2);
  });

  it('waits for all test cases to resolve', async () => {
    // Setup
    const bafTestResultsFetcher: BafTestResultsFetcher =
      new BafTestResultsFetcher();

    bafTestResultsFetcher.fetchResults(TEST_CASE_1);
    bafTestResultsFetcher.fetchResults(TEST_CASE_2_WITH_DELAY);
    bafTestResultsFetcher.fetchResults(TEST_CASE_3);

    // Give the "fast" mock tests time to resolve themselves.
    await delay(10);

    // Execute
    const actualTestResults = await bafTestResultsFetcher.getResultsAsync();

    // Verify
    expect(actualTestResults).toStrictEqual([
      TEST_CASE_1_RESULTS,
      TEST_CASE_3_RESULTS_1,
      TEST_CASE_2_RESULTS,
    ]);
  });

  it('only gets the test case results from the BafTestCase once', async () => {
    delete process.env.STBT_AUTH_TOKEN;

    // Setup
    const bafTestResultsFetcher: BafTestResultsFetcher =
      new BafTestResultsFetcher();

    bafTestResultsFetcher.fetchResults(TEST_CASE_1);
    bafTestResultsFetcher.fetchResults(TEST_CASE_2_WITH_DELAY);
    bafTestResultsFetcher.fetchResults(TEST_CASE_3);

    // Give the "fast" mock tests time to resolve themselves.
    await delay(10);

    // Execute
    const actualTestResults1 = await bafTestResultsFetcher.getResultsAsync();
    const actualTestResults2 = await bafTestResultsFetcher.getResultsAsync();

    // Verify
    expect(actualTestResults1).toStrictEqual([
      TEST_CASE_1_RESULTS,
      TEST_CASE_3_RESULTS_1,
      TEST_CASE_2_RESULTS,
    ]);
    expect(actualTestResults2).toStrictEqual([
      TEST_CASE_1_RESULTS,
      TEST_CASE_3_RESULTS_1,
      TEST_CASE_2_RESULTS,
    ]);
  });

  it('returns an IBafFrameworkError if one is returned by runTestsAsync', async () => {
    // Setup
    const bafFrameworkError: IBafFrameworkError = {
      isFrameworkError: true,
      error: {
        isA: 'sample framework error',
      },
    };

    mockGetResultsAsync3.mockReset();
    mockGetResultsAsync3.mockResolvedValueOnce(bafFrameworkError);

    const bafTestResultsFetcher: BafTestResultsFetcher =
      new BafTestResultsFetcher();

    bafTestResultsFetcher.fetchResults(TEST_CASE_1);
    bafTestResultsFetcher.fetchResults(TEST_CASE_2_WITH_DELAY);
    bafTestResultsFetcher.fetchResults(TEST_CASE_3);

    // Give the "fast" mock tests time to resolve themselves.
    await delay(10);

    // Execute
    const actualTestResults = await bafTestResultsFetcher.getResultsAsync();

    // Verify
    expect(actualTestResults).toStrictEqual([
      TEST_CASE_1_RESULTS,
      bafFrameworkError,
      TEST_CASE_2_RESULTS,
    ]);
  });

  it('returns an IBafFrameworkError if runTestsAsync throws an exception', async () => {
    // Setup
    const bafFrameworkError: IBafFrameworkError = {
      isFrameworkError: true,
      error: {
        isA: 'sample framework error thrown by getResultsAsync()',
      },
    };

    mockGetResultsAsync3.mockReset();
    mockGetResultsAsync3.mockRejectedValueOnce({
      isA: 'sample framework error thrown by getResultsAsync()',
    });

    const bafTestResultsFetcher: BafTestResultsFetcher =
      new BafTestResultsFetcher();

    bafTestResultsFetcher.fetchResults(TEST_CASE_1);
    bafTestResultsFetcher.fetchResults(TEST_CASE_2_WITH_DELAY);
    bafTestResultsFetcher.fetchResults(TEST_CASE_3);

    // Give the "fast" mock tests time to resolve themselves.
    await delay(10);

    // Execute
    const actualTestResults = await bafTestResultsFetcher.getResultsAsync();

    // Verify
    expect(actualTestResults).toStrictEqual([
      TEST_CASE_1_RESULTS,
      bafFrameworkError,
      TEST_CASE_2_RESULTS,
    ]);
  });
});
