// Copyright text placeholder, Warner Bros. Discovery, Inc.

// Mock BafTestCaseLogger
const mockBafTestCaseLoggerConstructor = jest.fn();

jest.mock('../../../lib/stbt-baf-test-run/logging', () => ({
  BafTestCaseLogger: mockBafTestCaseLoggerConstructor,
}));

// Mock uuid()
const mockUuid = jest.fn();

jest.mock('uuid', () => ({
  v4: mockUuid,
}));

import {
  IJobResponse,
  IRunTestsRequestBody,
  IStepsResult,
  ITestResult,
  StbtClient,
} from '../../../lib/stbt-client';

import {
  BafTestCase,
  BafTestCaseLogger,
  IBafFrameworkError,
  IBafTestCaseOutcome,
} from '../../../lib/stbt-baf-test-run';

const mockStbtClientRunTestsAsync = jest.fn();
const mockWaitForTestJobCompletionAsync = jest.fn();
const mockIsTestJobSuccessfulAsync = jest.fn();
const mockGetJobBddStepsResultsAsync = jest.fn();
const mockGetTestResultsForTestJobAsync = jest.fn();
const mockGetTestBddStepsResultAsync = jest.fn();
const mockStbtClientInstance: StbtClient = {
  runTestsAsync: mockStbtClientRunTestsAsync,
  waitForTestJobCompletionAsync: mockWaitForTestJobCompletionAsync,
  isTestJobSuccessfulAsync: mockIsTestJobSuccessfulAsync,
  getJobBddStepsResultsAsync: mockGetJobBddStepsResultsAsync,
  getTestResultsForTestJobAsync: mockGetTestResultsForTestJobAsync,
  getTestBddStepsResultAsync: mockGetTestBddStepsResultAsync,
} as unknown as StbtClient;

const mockLogTestExecutionStart = jest.fn();
const mockLogTestExecutionWaiting = jest.fn();
const mockLogTestExecutionEnd = jest.fn();
const mockLogResultsRetrievalStart = jest.fn();
const mockLogResultsRetrievalEnd = jest.fn();
const mockBafTestCaseLoggerInstance: BafTestCaseLogger = {
  logTestExecutionStart: mockLogTestExecutionStart,
  logTestExecutionWaiting: mockLogTestExecutionWaiting,
  logTestExecutionEnd: mockLogTestExecutionEnd,
  logResultsRetrievalStart: mockLogResultsRetrievalStart,
  logResultsRetrievalEnd: mockLogResultsRetrievalEnd,
} as unknown as BafTestCaseLogger;

describe('lib/stbt-baf-test-run/BafTestCase', () => {
  const SAMPLE_BAF_TEST_RUN_ID = '12345-abcde-68910-fghij';

  const SAMPLE_UUID: string = 'a1b2c3d4';
  const SAMPLE_STBT_NODE_ID = 'stb-tester-0000abcd1234';
  const SAMPLE_STBT_TEST_PACK_REVISION = 'sample-STBT-test-pack-revision';
  const SAMPLE_STBT_TEST_CASE = 'mock test case #1';

  const SAMPLE_STBT_TAGS = {
    isA: 'sample STBT tags object',
    STBT_TAG_FOO: 'sample value for STBT_TAG_FOO',
  };

  const SAMPLE_STBT_JOB_UID = '/stbt-tester-0000abcd1234/job-13134134';

  const SAMPLE_STBT_JOB_RESULTS: IJobResponse = {
    jobUid: SAMPLE_STBT_JOB_UID,
  } as IJobResponse;

  const SAMPLE_STBT_RESULT_ID: string = '1341k1515kajs';
  const SAMPLE_STBT_TEST_RESULT: ITestResult = {
    endTime: 'fake endTime mock',
    jobUid: SAMPLE_STBT_JOB_UID,
    result: 'pass',
    resultId: SAMPLE_STBT_RESULT_ID,
    resultUrl: 'fake test result URL',
    startTime: 'fake startTime',
    testPackSha: SAMPLE_STBT_TEST_PACK_REVISION,
    triageUrl: 'fake test triage URL',
    failureReason: undefined,
  };

  const SAMPLE_BDD_STEPS_RESULT: IStepsResult = {
    isA: 'first steps.json file',
  } as unknown as IStepsResult;

  beforeEach(() => {
    jest.clearAllMocks();
    mockBafTestCaseLoggerConstructor.mockReturnValue(
      mockBafTestCaseLoggerInstance,
    );
    mockUuid.mockReturnValueOnce(SAMPLE_UUID);
  });

  it('can be constructed', () => {
    expect(
      () =>
        new BafTestCase({
          bafTestRunId: SAMPLE_BAF_TEST_RUN_ID,
          stbtClient: mockStbtClientInstance,
          stbtTags: SAMPLE_STBT_TAGS,
          testCase: SAMPLE_STBT_TEST_CASE,
          testPackRevision: SAMPLE_STBT_TEST_PACK_REVISION,
        }),
    ).not.toThrow();
  });

  describe('runTestAsync()', () => {
    it('calls stbtClient.runTestsAsync with the correct parameters, including the stbtNodeId', async () => {
      // Setup
      const bafTestCase: BafTestCase = new BafTestCase({
        bafTestRunId: SAMPLE_BAF_TEST_RUN_ID,
        stbtClient: mockStbtClientInstance,
        stbtTags: SAMPLE_STBT_TAGS,
        testCase: SAMPLE_STBT_TEST_CASE,
        testPackRevision: SAMPLE_STBT_TEST_PACK_REVISION,
      });

      mockStbtClientRunTestsAsync.mockResolvedValueOnce(
        SAMPLE_STBT_JOB_RESULTS,
      );

      // Execute
      await bafTestCase.runTestAsync(SAMPLE_STBT_NODE_ID);

      // Verify
      const expectedStbtClientRunTestsAsyncParameters: IRunTestsRequestBody = {
        bafTestRunId: SAMPLE_BAF_TEST_RUN_ID,
        stbtTags: SAMPLE_STBT_TAGS,
        testCases: [SAMPLE_STBT_TEST_CASE],
        testPackRevision: SAMPLE_STBT_TEST_PACK_REVISION,
        stbtNodeId: SAMPLE_STBT_NODE_ID,
      };

      expect(mockStbtClientRunTestsAsync).toHaveBeenCalledTimes(1);
      expect(mockStbtClientRunTestsAsync).toHaveBeenCalledWith(
        expectedStbtClientRunTestsAsyncParameters,
      );
    });

    it('waits for the test to complete', async () => {
      // Setup
      const bafTestCase: BafTestCase = new BafTestCase({
        bafTestRunId: SAMPLE_BAF_TEST_RUN_ID,
        stbtClient: mockStbtClientInstance,
        stbtTags: SAMPLE_STBT_TAGS,
        testCase: SAMPLE_STBT_TEST_CASE,
        testPackRevision: SAMPLE_STBT_TEST_PACK_REVISION,
      });

      mockStbtClientRunTestsAsync.mockResolvedValueOnce(
        SAMPLE_STBT_JOB_RESULTS,
      );

      // Execute
      await bafTestCase.runTestAsync(SAMPLE_STBT_NODE_ID);

      // Verify
      expect(mockWaitForTestJobCompletionAsync).toHaveBeenCalledTimes(1);
      expect(mockWaitForTestJobCompletionAsync).toHaveBeenCalledWith(
        SAMPLE_STBT_JOB_UID,
      );
    });

    it('returns an IBafFrameworkError if it is called more than once', async () => {
      // Setup
      const bafTestCase: BafTestCase = new BafTestCase({
        bafTestRunId: SAMPLE_BAF_TEST_RUN_ID,
        stbtClient: mockStbtClientInstance,
        stbtTags: SAMPLE_STBT_TAGS,
        testCase: SAMPLE_STBT_TEST_CASE,
        testPackRevision: SAMPLE_STBT_TEST_PACK_REVISION,
      });

      mockStbtClientRunTestsAsync.mockResolvedValueOnce(
        SAMPLE_STBT_JOB_RESULTS,
      );

      const expectedError: IBafFrameworkError = {
        isFrameworkError: true,
        error: new Error(
          'Test job has already been started. Please only call runTestAsync() once.',
        ),
      };

      // Execute
      await bafTestCase.runTestAsync(SAMPLE_STBT_NODE_ID);
      await bafTestCase.runTestAsync(SAMPLE_STBT_NODE_ID);

      const outcome: IBafTestCaseOutcome = await bafTestCase.getResultsAsync();

      // Verify
      expect(outcome).toStrictEqual(expectedError);

      expect(mockStbtClientRunTestsAsync).toHaveBeenCalledTimes(1);

      expect(mockWaitForTestJobCompletionAsync).toHaveBeenCalledWith(
        SAMPLE_STBT_JOB_UID,
      );
      expect(mockWaitForTestJobCompletionAsync).toHaveBeenCalledTimes(1);

      expect(mockGetTestResultsForTestJobAsync).not.toHaveBeenCalled();
      expect(mockGetTestBddStepsResultAsync).not.toHaveBeenCalled();
    });
  });

  describe('getResultsAsync()', () => {
    it('calls stbtClient.getTestResultsForTestJobAsync() to get the result_id, then calls stbtClient.getTestBddStepsResultAsync() to get the BDD steps result', async () => {
      // Setup
      const bafTestCase: BafTestCase = new BafTestCase({
        bafTestRunId: SAMPLE_BAF_TEST_RUN_ID,
        stbtClient: mockStbtClientInstance,
        stbtTags: SAMPLE_STBT_TAGS,
        testCase: SAMPLE_STBT_TEST_CASE,
        testPackRevision: SAMPLE_STBT_TEST_PACK_REVISION,
      });

      // Must call runTestAsync() first, with a mocked response from stbtClient.runTestsAsync(),
      // so that it has a `job_uid` with which to look up its results.
      mockStbtClientRunTestsAsync.mockResolvedValueOnce(
        SAMPLE_STBT_JOB_RESULTS,
      );
      await bafTestCase.runTestAsync(SAMPLE_STBT_NODE_ID);

      // Mock the test results from the job, which contain only the result of the single test in the job.
      mockGetTestResultsForTestJobAsync.mockResolvedValueOnce([
        SAMPLE_STBT_TEST_RESULT,
      ]);

      // Mock the BDD steps results from the job, which consist of the single test's single `steps.json` file
      mockGetTestBddStepsResultAsync.mockResolvedValueOnce(
        SAMPLE_BDD_STEPS_RESULT,
      );

      const expectedResults: IBafTestCaseOutcome = {
        isFrameworkError: false,
        isSuccess: true,
        bddStepsResult: SAMPLE_BDD_STEPS_RESULT,
        testResult: SAMPLE_STBT_TEST_RESULT,
      };

      // Execute
      const results: IBafTestCaseOutcome = await bafTestCase.getResultsAsync();

      // Verify
      expect(results).toStrictEqual(expectedResults);

      const expectedStbtClientRunTestsAsyncParameters: IRunTestsRequestBody = {
        bafTestRunId: SAMPLE_BAF_TEST_RUN_ID,
        stbtTags: SAMPLE_STBT_TAGS,
        testCases: [SAMPLE_STBT_TEST_CASE],
        testPackRevision: SAMPLE_STBT_TEST_PACK_REVISION,
        stbtNodeId: SAMPLE_STBT_NODE_ID,
      };

      expect(mockStbtClientRunTestsAsync).toHaveBeenCalledTimes(1);
      expect(mockStbtClientRunTestsAsync).toHaveBeenCalledWith(
        expectedStbtClientRunTestsAsyncParameters,
      );

      expect(mockGetTestBddStepsResultAsync).toHaveBeenCalledWith(
        SAMPLE_STBT_RESULT_ID,
      );
      expect(mockGetTestBddStepsResultAsync).toHaveBeenCalledTimes(1);
    });

    it('returns an IBafFrameworkError if it is called before the test has been started', async () => {
      // Setup
      const bafTestCase: BafTestCase = new BafTestCase({
        bafTestRunId: SAMPLE_BAF_TEST_RUN_ID,
        stbtClient: mockStbtClientInstance,
        stbtTags: SAMPLE_STBT_TAGS,
        testCase: SAMPLE_STBT_TEST_CASE,
        testPackRevision: SAMPLE_STBT_TEST_PACK_REVISION,
      });

      const expectedError: IBafFrameworkError = {
        isFrameworkError: true,
        error: new Error(
          'Test job has not yet been started. Please call runTestAsync() before calling getResultsAsync().',
        ),
      };

      // Execute
      const outcome: IBafTestCaseOutcome = await bafTestCase.getResultsAsync();

      // Verify
      expect(outcome).toStrictEqual(expectedError);

      expect(mockGetTestResultsForTestJobAsync).not.toHaveBeenCalled();
      expect(mockGetTestBddStepsResultAsync).not.toHaveBeenCalled();
    });
  });
});
