// Copyright text placeholder, Warner Bros. Discovery, Inc.

// Mock logger
const mockLoggerDebug = jest.fn();
const mockLoggerInfo = jest.fn();
const mockLoggerError = jest.fn();

jest.mock('../../../../support/logger', () => {
  const actual = jest.requireActual('../../../../support/logger');

  return {
    ...actual,
    logger: {
      debug: mockLoggerDebug,
      info: mockLoggerInfo,
      error: mockLoggerError,
    },
  };
});

const dateNowSpy = jest.spyOn(Date, 'now');

import {
  IBafFrameworkError,
  IBafTestRunResults,
} from '../../../../lib/stbt-baf-test-run';
import { ITestResult } from '../../../../lib/stbt-client';
import { BafTestRunLogger } from '../../../../lib/stbt-baf-test-run/logging';

interface ILoggingExpectation {
  debugLogs?: unknown[][];
  infoLogs?: unknown[][];
  errorLogs?: unknown[][];
}

describe('lib/stbt-baf-test-run/logging/BafTestRunLogger', () => {
  const SAMPLE_BAF_TEST_RUN_ID = '1st6ch';
  const SAMPLE_APP_PORTAL_URL: string =
    'https://hbo.stb-tester.com/app/#/results?filter=category:1st6ch';
  const SAMPLE_REST_API_URL: string =
    'https://hbo.stb-tester.com/api/v2/results?filter=category:1st6ch';

  const SAMPLE_STBT_NODE_ID_1: string = 'sampleStbtNodeId1';
  const SAMPLE_STBT_NODE_ID_2: string = 'sampleStbtNodeId2';

  const SAMPLE_STBT_NODE_IDS: string[] = [
    SAMPLE_STBT_NODE_ID_1,
    SAMPLE_STBT_NODE_ID_2,
  ];

  const SAMPLE_STBT_TAGS = {
    isA: 'sample STBT tags object',
    STBT_TAG_FOO: 'sample value for STBT_TAG_FOO',
  };

  const SAMPLE_BDD_TEST_CASE_1: string = 'sample BDD test case 1';
  const SAMPLE_BDD_TEST_CASE_2: string = 'sample BDD test case 2';
  const SAMPLE_BDD_TEST_CASE_3: string = 'sample BDD test case 3';

  const SAMPLE_BDD_TEST_CASES: string[] = [
    SAMPLE_BDD_TEST_CASE_1,
    SAMPLE_BDD_TEST_CASE_2,
    SAMPLE_BDD_TEST_CASE_3,
  ];

  const SAMPLE_TEST_PACK_REVISION: string = 'aaa0sample0git0shaaa';

  const SAMPLE_LOGGER_PARAMS = {
    testRunId: SAMPLE_BAF_TEST_RUN_ID,
    stbtNodeIds: SAMPLE_STBT_NODE_IDS,
    testCases: SAMPLE_BDD_TEST_CASES,
    testPackRevision: SAMPLE_TEST_PACK_REVISION,
    stbtTags: SAMPLE_STBT_TAGS,
  };

  const LOG_PREFIX: string = 'Test run 1st6ch';

  const MOCK_NOW: number = 1675973211607;
  const MOCK_NOW_FORMATTED: string = '2023-02-09T20:06:51.607Z';

  const MOCK_FRAMEWORK_ERROR_1: IBafFrameworkError = {
    isA: 'mock framework error 1',
  } as unknown as IBafFrameworkError;
  const MOCK_FRAMEWORK_ERROR_2: IBafFrameworkError = {
    isA: 'mock framework error 2',
  } as unknown as IBafFrameworkError;

  /**
   * Run this right before the Execute step, to clear out records of any logging
   * done during the Setup step.
   */
  function resetLoggerMocks(): void {
    mockLoggerDebug.mockReset();
    mockLoggerInfo.mockReset();
    mockLoggerError.mockReset();
  }

  /**
   * Expect that the given mock logging function will have been called once for each
   * set of invocation arguments in `logs`, with those invocation arguments.
   */
  function expectLogsToMockLogFunc(
    logs: unknown[][] | undefined,
    mockLogFunc: jest.Mock,
  ): void {
    if (logs) {
      for (let i = 0; i < logs.length; i++) {
        expect(mockLogFunc).toHaveBeenNthCalledWith(
          i + 1,
          LOG_PREFIX,
          ...logs[i],
        );
      }
      expect(mockLogFunc).toHaveBeenCalledTimes(logs.length);
    } else {
      expect(mockLogFunc).not.toHaveBeenCalled();
    }
  }

  /**
   * Verify that the expected logger calls, and only the expected logger calls, have been made.
   */
  function expectLogging({
    debugLogs,
    infoLogs,
    errorLogs,
  }: ILoggingExpectation): void {
    expectLogsToMockLogFunc(debugLogs, mockLoggerDebug);
    expectLogsToMockLogFunc(infoLogs, mockLoggerInfo);
    expectLogsToMockLogFunc(errorLogs, mockLoggerError);
  }

  beforeEach(() => {
    jest.clearAllMocks();
    dateNowSpy.mockReturnValueOnce(MOCK_NOW);
  });

  describe('when constructed', () => {
    it('logs test run creation', () => {
      // Setup
      resetLoggerMocks();

      // Execute
      new BafTestRunLogger(SAMPLE_LOGGER_PARAMS);

      // Verify
      expectLogging({
        debugLogs: [['test cases:', SAMPLE_BDD_TEST_CASES]],
        infoLogs: [
          [
            'created with 3 test cases from Git revision "aaa0sample0git0shaaa".',
          ],
          [
            'will run on STBT node(s):',
            [SAMPLE_STBT_NODE_ID_1, SAMPLE_STBT_NODE_ID_2],
          ],
          ['with STBT tags:', SAMPLE_STBT_TAGS],
        ],
      });
    });
  });

  describe('logTestExecutionsStart', () => {
    it('logs a "starting test executions" message', () => {
      // Setup
      const bafTestRunLogger: BafTestRunLogger = new BafTestRunLogger(
        SAMPLE_LOGGER_PARAMS,
      );

      const sampleAppPortalUrl: string = 'https://sample.app.portal.url/app';
      const sampleRestApiUrl: string = 'https://sample.rest.api.url/api';

      resetLoggerMocks();

      // Execute
      bafTestRunLogger.logTestExecutionsStart(
        sampleAppPortalUrl,
        sampleRestApiUrl,
      );

      // Verify
      expectLogging({
        infoLogs: [
          [`started at ${MOCK_NOW_FORMATTED}.`],
          ['incremental test results can be obtained from:'],
          [`  - the STBT web portal at ${sampleAppPortalUrl}`],
          [`  - the STBT REST API at ${sampleRestApiUrl}`],
          ['waiting for test executions to finish...'],
        ],
      });
    });
  });

  describe('logTestExecutionsEnd', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('can only be called after logTestExecutionStart', () => {
      // Setup
      const bafTestRunLogger: BafTestRunLogger = new BafTestRunLogger(
        SAMPLE_LOGGER_PARAMS,
      );

      resetLoggerMocks();

      // Execute & Verify
      expect(() => bafTestRunLogger.logTestExecutionsEnd()).toThrowError(
        'Test executions start has not been logged',
      );
    });

    it('logs a test executions end message with the total runtime across all tests', () => {
      // Setup
      // Remove the mock value that was set in beforeEach()
      dateNowSpy.mockReset();

      // Create the logger to be tested.
      const bafTestRunLogger: BafTestRunLogger = new BafTestRunLogger(
        SAMPLE_LOGGER_PARAMS,
      );

      // Mock a starting time
      dateNowSpy.mockReturnValueOnce(100000);

      // Start the test executions, grabbing the time at 100000.
      bafTestRunLogger.logTestExecutionsStart(
        SAMPLE_APP_PORTAL_URL,
        SAMPLE_REST_API_URL,
      );

      // Mock a later ending time
      dateNowSpy.mockReturnValueOnce(200000);

      resetLoggerMocks();

      // Execute
      bafTestRunLogger.logTestExecutionsEnd();

      // Verify
      expect(dateNowSpy).toHaveBeenCalledTimes(2);

      expectLogging({
        infoLogs: [['test executions finished after 1 minute, 40 seconds.']],
      });
    });
  });

  describe('logFrameworkErrors', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('throws an exception if no framework errors are provided', () => {
      // Setup
      const bafTestRunLogger: BafTestRunLogger = new BafTestRunLogger(
        SAMPLE_LOGGER_PARAMS,
      );

      resetLoggerMocks();

      // Execute & Verify
      expect(() => bafTestRunLogger.logFrameworkErrors([])).toThrow(
        'must provide framework errors to be logged.',
      );
    });

    it('logs an overall error message and each of the errors', () => {
      // Setup
      const bafTestRunLogger: BafTestRunLogger = new BafTestRunLogger(
        SAMPLE_LOGGER_PARAMS,
      );

      resetLoggerMocks();

      // Execute
      bafTestRunLogger.logFrameworkErrors([
        MOCK_FRAMEWORK_ERROR_1,
        MOCK_FRAMEWORK_ERROR_2,
      ]);

      // Verify
      expectLogging({
        errorLogs: [
          [
            'results are UNDEFINED due to framework errors:',
            [MOCK_FRAMEWORK_ERROR_1, MOCK_FRAMEWORK_ERROR_2],
          ],
        ],
      });
    });
  });

  describe('logTestRunResults', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    [
      {
        description: 'a success message when no tests failed',
        totalCount: 49,
        failCount: 0,
        expectedSummaryMessage: 'succeeded: all 49 tests passed.',
      },
      {
        description:
          'a failure message with percent-passing displayed with no decimals when there is no fractional component to the passing/failing percentage',
        totalCount: 4,
        failCount: 1,
        expectedSummaryMessage: 'failed: 1 of 4 tests failed (75% passed).',
      },
      {
        description:
          'a failure message with percent-passing displayed with single-digit decimals when there is one decimal place in the passing/failing percentage',
        totalCount: 3,
        failCount: 1,
        expectedSummaryMessage: 'failed: 1 of 3 tests failed (66.67% passed).',
      },
      {
        description:
          'a failure message with percent-passing displayed with double-digit decimals when there are two decimal places in the passing/failing percentage',
        totalCount: 1000,
        failCount: 445,
        expectedSummaryMessage:
          'failed: 445 of 1000 tests failed (55.5% passed).',
      },
      {
        description:
          'a failure message with percent-passing displayed with double-digit decimals when there are more than two decimal place in the passing/failing percentage',
        totalCount: 7,
        failCount: 6,
        expectedSummaryMessage: 'failed: 6 of 7 tests failed (14.29% passed).',
      },
    ].forEach(
      ({ description, totalCount, failCount, expectedSummaryMessage }) => {
        it(`logs ${description} after running a test job with ${failCount} failing tests out of ${totalCount}`, () => {
          // Setup
          const bafTestRunLogger: BafTestRunLogger = new BafTestRunLogger(
            SAMPLE_LOGGER_PARAMS,
          );

          const sampleTestRunResults: IBafTestRunResults = {
            isSuccess: failCount === 0,
            bddStepsResults: [],
            testResults: [],
          };

          for (let i = 0; i < totalCount; i++) {
            sampleTestRunResults.testResults[i] = {
              result: i < failCount ? 'fail' : 'pass',
            } as unknown as ITestResult;
          }

          resetLoggerMocks();

          // Execute
          bafTestRunLogger.logTestRunResults(sampleTestRunResults);

          // Verify
          expectLogging({
            infoLogs: [[expectedSummaryMessage]],
          });
        });
      },
    );
  });
});
