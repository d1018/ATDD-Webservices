// Copyright text placeholder, Warner Bros. Discovery, Inc.

// Mock logger
const mockLoggerLog = jest.fn();
const mockLoggerInfo = jest.fn();

jest.mock('../../../../support/logger', () => {
  const actual = jest.requireActual('../../../../support/logger');

  return {
    ...actual,
    logger: {
      log: mockLoggerLog,
      info: mockLoggerInfo,
    },
  };
});

// Mock uuid()
const mockUuid = jest.fn();

jest.mock('uuid', () => ({
  v4: mockUuid,
}));

const dateNowSpy = jest.spyOn(Date, 'now');

import { IRunTestsRequestBody } from '../../../../lib/stbt-client';
import { BafTestCaseLogger } from '../../../../lib/stbt-baf-test-run/logging';

describe('lib/stbt-baf-test-run/logging/BafTestCaseLogger', () => {
  const SAMPLE_BAF_TEST_RUN_ID = 'sampleTestRunId';
  const SAMPLE_BAF_TEST_CASE_ID: string = 'sampleTestCaseId';
  const SAMPLE_STBT_NODE_ID = 'sampleStbtNodeId';
  const SAMPLE_STBT_TEST_PACK_REVISION = 'sampleStbtTestPackRevision';
  const SAMPLE_STBT_TEST_CASE = 'sampleStbtTestCase';

  const SAMPLE_STBT_TAGS = {
    isA: 'sample STBT tags object',
    STBT_TAG_FOO: 'sample value for STBT_TAG_FOO',
  };

  const SAMPLE_STBT_JOB_UID = 'sampleStbtJobUid';

  const SAMPLE_TEST_CASE_START_PARAMS: IRunTestsRequestBody = {
    bafTestRunId: SAMPLE_BAF_TEST_RUN_ID,
    stbtNodeId: SAMPLE_STBT_NODE_ID,
    stbtTags: SAMPLE_STBT_TAGS,
    testCases: [SAMPLE_STBT_TEST_CASE],
    testPackRevision: SAMPLE_STBT_TEST_PACK_REVISION,
  };

  const NODE_SPECIFIC_PREFIX: string =
    'Run sampleTestRunId test case sampleTestCaseId node sampleStbtNodeId:';
  const NODE_AGNOSTIC_PREFIX: string =
    'Run sampleTestRunId test case sampleTestCaseId:';

  beforeEach(() => {
    jest.clearAllMocks();
    mockUuid.mockReturnValueOnce(SAMPLE_BAF_TEST_CASE_ID);
  });

  describe('logTestExecutionStart', () => {
    beforeEach(() => {
      jest.clearAllMocks();
      mockUuid.mockReturnValueOnce(SAMPLE_BAF_TEST_CASE_ID);
    });

    it('logs with the runId, caseId, and stbtNodeId as prefix', () => {
      // Setup
      const bafTestCaseLogger: BafTestCaseLogger = new BafTestCaseLogger(
        SAMPLE_BAF_TEST_RUN_ID,
        SAMPLE_BAF_TEST_CASE_ID,
      );

      // Execute
      bafTestCaseLogger.logTestExecutionStart(SAMPLE_TEST_CASE_START_PARAMS);

      // Verify
      expect(mockLoggerLog).toHaveBeenCalledWith(
        expect.stringContaining(NODE_SPECIFIC_PREFIX),
      );
      expect(mockLoggerLog).toHaveBeenCalledTimes(1);
    });

    it('logs a "starting test execution" message', () => {
      // Setup
      const bafTestCaseLogger: BafTestCaseLogger = new BafTestCaseLogger(
        SAMPLE_BAF_TEST_RUN_ID,
        SAMPLE_BAF_TEST_CASE_ID,
      );

      // Execute
      bafTestCaseLogger.logTestExecutionStart(SAMPLE_TEST_CASE_START_PARAMS);

      // Verify
      expect(mockLoggerLog).toHaveBeenCalledWith(
        `${NODE_SPECIFIC_PREFIX} Executing test "sampleStbtTestCase".`,
      );
      expect(mockLoggerLog).toHaveBeenCalledTimes(1);
    });
  });

  describe('logTestExecutionWaiting', () => {
    beforeEach(() => {
      jest.clearAllMocks();
      mockUuid.mockReturnValueOnce(SAMPLE_BAF_TEST_CASE_ID);
    });

    it('can only be called after logTestExecutionStart', () => {
      // Setup
      const bafTestCaseLogger: BafTestCaseLogger = new BafTestCaseLogger(
        SAMPLE_BAF_TEST_RUN_ID,
        SAMPLE_BAF_TEST_CASE_ID,
      );

      // Execute & Verify
      expect(() =>
        bafTestCaseLogger.logTestExecutionWaiting(SAMPLE_STBT_JOB_UID),
      ).toThrowError('Call "logTestExecutionStart()" first.');
    });

    it('logs with the runId, caseId, and stbtNodeId as prefix', () => {
      // Setup
      const bafTestCaseLogger: BafTestCaseLogger = new BafTestCaseLogger(
        SAMPLE_BAF_TEST_RUN_ID,
        SAMPLE_BAF_TEST_CASE_ID,
      );

      bafTestCaseLogger.logTestExecutionStart(SAMPLE_TEST_CASE_START_PARAMS);
      mockLoggerLog.mockReset();

      // Execute
      bafTestCaseLogger.logTestExecutionWaiting(SAMPLE_STBT_JOB_UID);

      // Verify
      expect(mockLoggerLog).toHaveBeenCalledWith(
        expect.stringContaining(NODE_SPECIFIC_PREFIX),
      );
      expect(mockLoggerLog).toHaveBeenCalledTimes(1);
    });

    it('logs a "waiting for test execution" message', () => {
      // Setup
      const bafTestCaseLogger: BafTestCaseLogger = new BafTestCaseLogger(
        SAMPLE_BAF_TEST_RUN_ID,
        SAMPLE_BAF_TEST_CASE_ID,
      );

      bafTestCaseLogger.logTestExecutionStart(SAMPLE_TEST_CASE_START_PARAMS);
      mockLoggerLog.mockReset();

      // Execute
      bafTestCaseLogger.logTestExecutionWaiting(SAMPLE_STBT_JOB_UID);

      // Verify
      expect(mockLoggerLog).toHaveBeenCalledWith(
        `${NODE_SPECIFIC_PREFIX} Waiting for STBT job "sampleStbtJobUid" to finish...`,
      );
      expect(mockLoggerLog).toHaveBeenCalledTimes(1);
    });
  });

  describe('logTestExecutionEnd', () => {
    beforeEach(() => {
      jest.clearAllMocks();
      mockUuid.mockReturnValueOnce(SAMPLE_BAF_TEST_CASE_ID);
    });

    it('can only be called after logTestExecutionStart', () => {
      // Setup
      const bafTestCaseLogger: BafTestCaseLogger = new BafTestCaseLogger(
        SAMPLE_BAF_TEST_RUN_ID,
        SAMPLE_BAF_TEST_CASE_ID,
      );

      // Execute & Verify
      expect(() => bafTestCaseLogger.logTestExecutionEnd()).toThrowError(
        'Call "logTestExecutionStart()" first.',
      );
    });

    it('logs with the runId, caseId, and stbtNodeId as prefix', () => {
      // Setup
      const bafTestCaseLogger: BafTestCaseLogger = new BafTestCaseLogger(
        SAMPLE_BAF_TEST_RUN_ID,
        SAMPLE_BAF_TEST_CASE_ID,
      );

      bafTestCaseLogger.logTestExecutionStart(SAMPLE_TEST_CASE_START_PARAMS);
      mockLoggerLog.mockReset();

      // Execute
      bafTestCaseLogger.logTestExecutionEnd();

      // Verify
      expect(mockLoggerLog).toHaveBeenCalledWith(
        expect.stringContaining(NODE_SPECIFIC_PREFIX),
      );
      expect(mockLoggerLog).toHaveBeenCalledTimes(1);
    });

    it('logs a test execution end message with the test runtime', () => {
      // Setup
      const bafTestCaseLogger: BafTestCaseLogger = new BafTestCaseLogger(
        SAMPLE_BAF_TEST_RUN_ID,
        SAMPLE_BAF_TEST_CASE_ID,
      );

      // Mock a starting time
      dateNowSpy.mockReturnValueOnce(100000);

      bafTestCaseLogger.logTestExecutionStart(SAMPLE_TEST_CASE_START_PARAMS);

      mockLoggerLog.mockReset();

      // Mock a later ending time
      dateNowSpy.mockReturnValueOnce(200000);

      // Execute
      bafTestCaseLogger.logTestExecutionEnd();

      // Verify
      expect(dateNowSpy).toHaveBeenCalledTimes(2);

      expect(mockLoggerLog).toHaveBeenCalledWith(
        `${NODE_SPECIFIC_PREFIX} ...test execution finished after 1 minute, 40 seconds.`,
      );
      expect(mockLoggerLog).toHaveBeenCalledTimes(1);
    });
  });

  describe('logResultsRetrievalStart', () => {
    beforeEach(() => {
      jest.clearAllMocks();
      mockUuid.mockReturnValueOnce(SAMPLE_BAF_TEST_CASE_ID);
    });

    it('logs with the runId, caseId, and stbtNodeId as prefix', () => {
      // Setup
      const bafTestCaseLogger: BafTestCaseLogger = new BafTestCaseLogger(
        SAMPLE_BAF_TEST_RUN_ID,
        SAMPLE_BAF_TEST_CASE_ID,
      );

      // Execute
      bafTestCaseLogger.logResultsRetrievalStart();

      // Verify
      expect(mockLoggerLog).toHaveBeenCalledWith(
        expect.stringContaining(NODE_AGNOSTIC_PREFIX),
      );
      expect(mockLoggerLog).toHaveBeenCalledTimes(1);
    });

    it('logs a "starting results retrieval" message', () => {
      // Setup
      const bafTestCaseLogger: BafTestCaseLogger = new BafTestCaseLogger(
        SAMPLE_BAF_TEST_RUN_ID,
        SAMPLE_BAF_TEST_CASE_ID,
      );

      bafTestCaseLogger.logTestExecutionStart(SAMPLE_TEST_CASE_START_PARAMS);
      mockLoggerLog.mockReset();

      // Execute
      bafTestCaseLogger.logResultsRetrievalStart();

      // Verify
      expect(mockLoggerLog).toHaveBeenCalledWith(
        `${NODE_AGNOSTIC_PREFIX} Retrieving test results...`,
      );
      expect(mockLoggerLog).toHaveBeenCalledTimes(1);
    });
  });

  describe('logResultsRetrievalEnd', () => {
    beforeEach(() => {
      jest.clearAllMocks();
      mockUuid.mockReturnValueOnce(SAMPLE_BAF_TEST_CASE_ID);
    });

    it('can only be called after logResultsRetrievalStart', () => {
      // Setup
      const bafTestCaseLogger: BafTestCaseLogger = new BafTestCaseLogger(
        SAMPLE_BAF_TEST_RUN_ID,
        SAMPLE_BAF_TEST_CASE_ID,
      );

      // Execute & Verify
      expect(() => bafTestCaseLogger.logResultsRetrievalEnd()).toThrowError(
        'Call "logResultsRetrievalStart()" first.',
      );
    });

    it('logs with the runId, caseId, and stbtNodeId as prefix', () => {
      // Setup
      const bafTestCaseLogger: BafTestCaseLogger = new BafTestCaseLogger(
        SAMPLE_BAF_TEST_RUN_ID,
        SAMPLE_BAF_TEST_CASE_ID,
      );

      bafTestCaseLogger.logResultsRetrievalStart();
      mockLoggerLog.mockReset();

      // Execute
      bafTestCaseLogger.logResultsRetrievalEnd();

      // Verify
      expect(mockLoggerLog).toHaveBeenCalledWith(
        expect.stringContaining(NODE_AGNOSTIC_PREFIX),
      );
      expect(mockLoggerLog).toHaveBeenCalledTimes(1);
    });

    it('logs a test execution end message with the test runtime', () => {
      // Setup
      const bafTestCaseLogger: BafTestCaseLogger = new BafTestCaseLogger(
        SAMPLE_BAF_TEST_RUN_ID,
        SAMPLE_BAF_TEST_CASE_ID,
      );

      // Mock a starting time
      dateNowSpy.mockReturnValueOnce(100000);

      bafTestCaseLogger.logResultsRetrievalStart();

      mockLoggerLog.mockReset();

      // Mock a later ending time
      dateNowSpy.mockReturnValueOnce(200000);

      // Execute
      bafTestCaseLogger.logResultsRetrievalEnd();

      // Verify
      expect(dateNowSpy).toHaveBeenCalledTimes(2);

      expect(mockLoggerLog).toHaveBeenCalledWith(
        `${NODE_AGNOSTIC_PREFIX} ...test results retrieved after 1 minute, 40 seconds.`,
      );
      expect(mockLoggerLog).toHaveBeenCalledTimes(1);
    });
  });
});
