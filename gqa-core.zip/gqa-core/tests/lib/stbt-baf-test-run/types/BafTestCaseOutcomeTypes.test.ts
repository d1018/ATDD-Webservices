// Copyright text placeholder, Warner Bros. Discovery, Inc.

// We disable no-unused-expressions so that we don't get spurious errors
// when checking for type errors by accessing various properties of an object.
//
/* eslint-disable no-unused-expressions */

import { IStepsResult, ITestResult } from '../../../../lib/stbt-client';
import { assert } from '../../../../support/TypeUtils';
import {
  IBafFrameworkError,
  IBafTestCaseOutcome,
  IBafTestCaseResults,
  isFrameworkError,
} from '../../../../lib/stbt-baf-test-run/types';

describe('lib/stbt-baf-test-run/types/BafTestCaseOutcomeTypes', () => {
  const SAMPLE_FRAMEWORK_ERROR: IBafFrameworkError = {
    isFrameworkError: true,
    error: new Error('Sample framework error  cause'),
  };

  const SAMPLE_TEST_FAILURE: IBafTestCaseResults = {
    isFrameworkError: false,
    isSuccess: false,
    testResult: {
      isA: 'fake STBT test result',
    } as unknown as ITestResult,
    bddStepsResult: {
      isA: 'fake BDD steps result',
    } as unknown as IStepsResult,
  };

  const SAMPLE_TEST_SUCCESS: IBafTestCaseResults = {
    isFrameworkError: false,
    isSuccess: true,
    testResult: {
      isA: 'fake STBT test result',
    } as unknown as ITestResult,
    bddStepsResult: {
      isA: 'fake BDD steps result',
    } as unknown as IStepsResult,
  };

  describe('isFrameworkError', () => {
    it('distiguishes between test results and framework errors', () => {
      expect(isFrameworkError(SAMPLE_FRAMEWORK_ERROR)).toBe(true);
      expect(isFrameworkError(SAMPLE_TEST_FAILURE)).toBe(false);
      expect(isFrameworkError(SAMPLE_TEST_SUCCESS)).toBe(false);
    });

    it('acts as a type guard to narrow types', () => {
      const testOutcome: IBafTestCaseOutcome =
        SAMPLE_FRAMEWORK_ERROR as IBafTestCaseOutcome;

      // Only has the property 'isFrameworkError'
      testOutcome.isFrameworkError;

      // @ts-expect-error   Property 'isSuccess' does not exist on type 'IBafFrameworkError'.ts(2339)
      testOutcome.isSuccess;

      // @ts-expect-error   Property 'error' does not exist on type 'IBafTestCaseResults'.ts(2339)
      testOutcome.error;

      // @ts-expect-error   Property 'testResult' does not exist on type 'IBafFrameworkError'.ts(2339)
      testOutcome.testResult;

      // @ts-expect-error   Property 'bddStepsResult' does not exist on type 'IBafFrameworkError'.ts(2339)
      testOutcome.bddStepsResult;

      assert(
        isFrameworkError(testOutcome),
        'Something is wrong with this test',
      );

      // After the assertion, it is known to be an IBafFrameworkError, and thus to have
      // all of its properties.
      expect(testOutcome.isFrameworkError).toBe(true);
      expect(testOutcome.error).not.toBeUndefined();

      // Still doesn't have the IBafTestCaseResults properties
      // @ts-expect-error   Property 'isSuccess' does not exist on type 'IBafFrameworkError'.ts(2339)
      testOutcome.isSuccess;
      // @ts-expect-error   Property 'testResult' does not exist on type 'IBafFrameworkError'.ts(2339)
      testOutcome.testResult;
      // @ts-expect-error   Property 'bddStepsResult' does not exist on type 'IBafFrameworkError'.ts(2339)
      testOutcome.bddStepsResult;
    });
  });
});
