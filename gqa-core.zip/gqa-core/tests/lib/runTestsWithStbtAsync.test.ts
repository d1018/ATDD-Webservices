// Copyright text placeholder, Warner Bros. Discovery, Inc.

const mockLoadConfiguration = jest.fn();

// mock the loadConfiguration out from cucumber API
jest.mock('@cucumber/cucumber/api', () => ({
  loadConfiguration: mockLoadConfiguration,
}));

// mock the getStbtNodeIdsForDeviceTypeAsync() call
const mockGetStbtNodeIdsForDeviceTypeAsync = jest.fn();

jest.mock('../../lib/getStbtNodeIdsForDeviceTypeAsync', () => ({
  getStbtNodeIdsForDeviceTypeAsync: mockGetStbtNodeIdsForDeviceTypeAsync,
}));

// mock the getStbtTestPackRevision() call
const mockGetStbtTestPackRevision = jest.fn();

jest.mock('../../lib/getStbtTestPackRevision', () => ({
  getStbtTestPackRevision: mockGetStbtTestPackRevision,
}));

// mock the getStbtTags() call
const mockGetStbtTags = jest.fn();

jest.mock('../../lib/getStbtTags', () => ({
  getStbtTags: mockGetStbtTags,
}));

// mock the getSelectedStbtTests call
const mockGetSelectedStbtTests = jest.fn();

jest.mock('../../lib/getSelectedStbtTests', () => ({
  getSelectedStbtTests: mockGetSelectedStbtTests,
}));

// Mock uuid()
const mockUuid = jest.fn();

jest.mock('uuid', () => ({
  v4: mockUuid,
}));

// mock the writeBddJsonReportFile call
const mockWriteBddJsonReportFile = jest.fn();

jest.mock('../../lib/writeBddJsonReportFile', () => ({
  writeBddJsonReportFile: mockWriteBddJsonReportFile,
}));

// Mock StbtClient
const mockStbtClientConstructor = jest.fn();

jest.mock('../../lib/stbt-client', () => ({
  StbtClient: mockStbtClientConstructor,
}));

// Mock BafTestManager
const mockBafTestManagerConstructor = jest.fn();

jest.mock('../../lib/stbt-baf-test-run', () => ({
  BafTestManager: mockBafTestManagerConstructor,
}));

jest.mock('../../support/rpConfig', () => ({
  rp_enable: 'true',
}));

const mockStbtClientRunTestsAsync = jest.fn();
const mockWaitForTestJobCompletionAsync = jest.fn();
const mockIsTestJobSuccessfulAsync = jest.fn();
const mockGetJobBddStepsResultsAsync = jest.fn();
const mockGetTestResultsForTestJobAsync = jest.fn();
const mockGetTestBddStepsResultAsync = jest.fn();
const mockStbtClientInstance = {
  runTestsAsync: mockStbtClientRunTestsAsync,
  waitForTestJobCompletionAsync: mockWaitForTestJobCompletionAsync,
  isTestJobSuccessfulAsync: mockIsTestJobSuccessfulAsync,
  getJobBddStepsResultsAsync: mockGetJobBddStepsResultsAsync,
  getTestResultsForTestJobAsync: mockGetTestResultsForTestJobAsync,
  getTestBddStepsResultAsync: mockGetTestBddStepsResultAsync,
};

const mockBafTestManagerRunTestsAsync = jest.fn();
const mockBafTestManagerInstance = {
  runTestsAsync: mockBafTestManagerRunTestsAsync,
};

import { IBafTestRunResults } from '../../lib/stbt-baf-test-run';

import {
  IRunTestsWithStbtAsyncConfig,
  runTestsWithStbtAsync,
} from '../../lib/runTestsWithStbtAsync';
import { IStepsResult, ITestResult } from '../../lib/stbt-client';

describe('lib/runTestsWithStbtAsync', () => {
  const TEST_STBT_AUTH_TOKEN = 'test STBT auth token';
  const TEST_DEVICE_TYPE = 'comcast';

  const TEST_BAF_TEST_RUN_ID = 'test bafTestRunId value';

  const TEST_STBT_NODE_ID = 'test STBT node id';
  const TEST_STBT_TEST_PACK_REVISION = 'test STBT test pack revision';
  const TEST_STBT_TEST_CASES = ['mock test case #1', 'mock test case #2'];

  const TEST_STBT_TAGS = {
    isA: 'test STBT tags object',
    STBT_TAG_FOO: 'value for STBT_TAG_FOO',
  };

  const TEST_STBT_JOB_UID_1 = 'test-stbt-job-uid 1';

  const TEST_STBT_JOB_UID_2 = 'test-stbt-job-uid 2';

  const TEST_PATH_TO_FEATURES_FOLDER_WITH_WILDCARD =
    'projects/this_is_a_test_value/features/*';

  const TEST_TAG_EXPRESSION = '@FOO and not @bar';

  const TEST_STBT_RESULT_ID_1: string = '1341k1515kajs';
  const TEST_STBT_TEST_RESULT_1: ITestResult = {
    endTime: 'fake endTime mock',
    jobUid: TEST_STBT_JOB_UID_1,
    result: 'pass',
    resultId: TEST_STBT_RESULT_ID_1,
    resultUrl: 'fake test result URL',
    startTime: 'fake startTime',
    testPackSha: TEST_STBT_TEST_PACK_REVISION,
    triageUrl: 'fake test triage URL',
    failureReason: undefined,
  };
  const TEST_STBT_RESULT_ID_2: string = '1341k1515kajs';
  const TEST_STBT_TEST_RESULT_2: ITestResult = {
    endTime: 'fake endTime mock',
    jobUid: TEST_STBT_JOB_UID_2,
    result: 'pass',
    resultId: TEST_STBT_RESULT_ID_2,
    resultUrl: 'fake test result URL',
    startTime: 'fake startTime',
    testPackSha: TEST_STBT_TEST_PACK_REVISION,
    triageUrl: 'fake test triage URL',
    failureReason: undefined,
  };
  const TEST_BDD_STEPS_RESULT_1: IStepsResult = {
    isA: 'first steps.json file',
  } as unknown as IStepsResult;

  const TEST_BDD_STEPS_RESULT_2: IStepsResult = {
    isA: 'second steps.json file',
  } as unknown as IStepsResult;

  const AGGREGATED_TEST_RESULTS: IStepsResult[] = [
    TEST_BDD_STEPS_RESULT_1,
    TEST_BDD_STEPS_RESULT_2,
  ];

  const TEST_LOAD_CONFIGURATION_RESULT = {
    useConfiguration: {
      isA: 'test useConfiguration from a mock loadConfiguration() result',
      paths: [TEST_PATH_TO_FEATURES_FOLDER_WITH_WILDCARD],
      tags: TEST_TAG_EXPRESSION,
    },
    isA: 'test loadConfiguration() result',
  };

  const TEST_RUN_TESTS_WITH_STBT_ASYNC_CONFIG: IRunTestsWithStbtAsyncConfig = {
    file: 'test cucumber config file',
    paths: ['test path 1', 'test path 2'],
    profiles: ['test profile 1', 'test profile 2'],
  };

  beforeEach(() => {
    jest.clearAllMocks();
    mockStbtClientConstructor.mockReturnValueOnce(mockStbtClientInstance);
    mockBafTestManagerConstructor.mockReturnValueOnce(
      mockBafTestManagerInstance,
    );
    mockUuid.mockReturnValueOnce(TEST_BAF_TEST_RUN_ID);
    process.env.STBT_AUTH_TOKEN = TEST_STBT_AUTH_TOKEN;
    process.env.DEVICE = TEST_DEVICE_TYPE;
  });

  it('throws an error if no config is provided', async () => {
    // @ts-ignore We have to suppress the type-check error in order not to pass in a config object
    await expect(runTestsWithStbtAsync()).rejects.toThrowError(
      'Please specify a valid test config!',
    );
  });

  it('throws an error if the STBT_AUTH_TOKEN environment variable is undefined', async () => {
    delete process.env.STBT_AUTH_TOKEN;

    await expect(
      runTestsWithStbtAsync(TEST_RUN_TESTS_WITH_STBT_ASYNC_CONFIG),
    ).rejects.toThrowError(
      'No STBT auth token provided in environment variable "STBT_AUTH_TOKEN".',
    );
  });

  it('throws an error if the DEVICE environment variable is undefined', async () => {
    delete process.env.DEVICE;

    await expect(
      runTestsWithStbtAsync(TEST_RUN_TESTS_WITH_STBT_ASYNC_CONFIG),
    ).rejects.toThrowError(
      'No device type provided in environment variable "DEVICE".',
    );
  });

  [
    {
      description: 'empty config',
      cucumberTagExpression: undefined,
      configParameterToRunTestsWithStbtAsync: {
        file: '',
        paths: [],
        profiles: [],
      },
      expectedToBePassedToLoadConfiguration: {
        file: '',
        profiles: [],
        provided: {
          file: '',
          paths: [],
          profiles: [],
          tags: 'not @wip',
        },
      },
      stbtAuthToken: TEST_STBT_AUTH_TOKEN,
      didTestsSucceed: true,
    },
    {
      description: 'tags-expression config',
      cucumberTagExpression: undefined,
      configParameterToRunTestsWithStbtAsync: {
        file: '',
        parallel: 2,
        paths: ['features'],
        profiles: [],
        tags: '@123',
      },
      expectedToBePassedToLoadConfiguration: {
        file: '',
        profiles: [],
        provided: {
          file: '',
          parallel: 2,
          paths: ['features'],
          profiles: [],
          tags: '@123',
        },
      },
      stbtAuthToken: TEST_STBT_AUTH_TOKEN,
      didTestsSucceed: true,
    },
    {
      description: 'CUCUMBER_TAGS is set config',
      cucumberTagExpression: '@P0 and not @wip',
      configParameterToRunTestsWithStbtAsync: {
        file: '',
        parallel: 2,
        paths: ['features'],
        profiles: [],
      },
      expectedToBePassedToLoadConfiguration: {
        file: '',
        profiles: [],
        provided: {
          file: '',
          parallel: 2,
          paths: ['features'],
          profiles: [],
          tags: '@P0 and not @wip',
        },
      },
      stbtAuthToken: TEST_STBT_AUTH_TOKEN,
      didTestsSucceed: true,
    },
    {
      description: 'no-tags-expression and no CUCUMBER_TAG config',
      cucumberTagExpression: undefined,
      configParameterToRunTestsWithStbtAsync: {
        file: '',
        parallel: 2,
        paths: ['features'],
        profiles: [],
      },
      expectedToBePassedToLoadConfiguration: {
        file: '',
        profiles: [],
        provided: {
          file: '',
          parallel: 2,
          paths: ['features'],
          profiles: [],
          tags: 'not @wip',
        },
      },
      stbtAuthToken: TEST_STBT_AUTH_TOKEN,
      didTestsSucceed: true,
    },
    {
      description: 'tags-expression overrides CUCUMBER_TAG config',
      cucumberTagExpression: '@will and @be and @overridden',
      configParameterToRunTestsWithStbtAsync: {
        file: '',
        parallel: 2,
        paths: ['features'],
        profiles: [],
        tags: '@tagsOverride',
      },
      expectedToBePassedToLoadConfiguration: {
        file: '',
        profiles: [],
        provided: {
          file: '',
          parallel: 2,
          paths: ['features'],
          profiles: [],
          tags: '@tagsOverride',
        },
      },
      stbtAuthToken: TEST_STBT_AUTH_TOKEN,
      didTestsSucceed: true,
    },
    {
      description: 'tests pass',
      cucumberTagExpression: undefined,
      configParameterToRunTestsWithStbtAsync: {
        file: 'fooConfig.json',
        parallel: 2,
        paths: ['features'],
        profiles: ['fred', 'barney'],
      },
      expectedToBePassedToLoadConfiguration: {
        file: 'fooConfig.json',
        profiles: ['fred', 'barney'],
        provided: {
          file: 'fooConfig.json',
          parallel: 2,
          paths: ['features'],
          profiles: ['fred', 'barney'],
          tags: 'not @wip',
        },
      },
      stbtAuthToken: TEST_STBT_AUTH_TOKEN,
      didTestsSucceed: true,
    },
    {
      description: 'tests fail',
      cucumberTagExpression: undefined,
      configParameterToRunTestsWithStbtAsync: {
        file: 'fooConfig.json',
        parallel: 2,
        paths: ['features'],
        profiles: ['fred', 'barney'],
      },
      expectedToBePassedToLoadConfiguration: {
        file: 'fooConfig.json',
        profiles: ['fred', 'barney'],
        provided: {
          file: 'fooConfig.json',
          parallel: 2,
          paths: ['features'],
          profiles: ['fred', 'barney'],
          tags: 'not @wip',
        },
      },
      stbtAuthToken: TEST_STBT_AUTH_TOKEN,
      didTestsSucceed: false,
    },
  ].forEach(
    ({
      description,
      cucumberTagExpression,
      configParameterToRunTestsWithStbtAsync,
      expectedToBePassedToLoadConfiguration,
      stbtAuthToken,
      didTestsSucceed,
    }) => {
      it(`passes the config into the cucumber-js loadConfiguration API correctly: ${description}`, async () => {
        // Setup
        // Set STBT_NODE_ID and STBT_AUTH_TOKEN
        process.env.STBT_AUTH_TOKEN = TEST_STBT_AUTH_TOKEN;
        process.env.STBT_NODE_ID = TEST_STBT_NODE_ID;

        // Set CUCUMBER_TAG
        if (cucumberTagExpression === undefined) {
          delete process.env.CUCUMBER_TAG;
        } else {
          process.env.CUCUMBER_TAG = cucumberTagExpression;
        }

        // Set DEVICE
        process.env.DEVICE = TEST_DEVICE_TYPE;

        // Setup mocks for loadConfiguration()
        mockLoadConfiguration.mockReturnValueOnce(
          TEST_LOAD_CONFIGURATION_RESULT,
        );

        // Setup mocks for getStbtNodeIdsForDeviceTypeAsync
        mockGetStbtNodeIdsForDeviceTypeAsync.mockReturnValueOnce([
          TEST_STBT_NODE_ID,
        ]);

        // Setup mocks for getStbtTestPackRevision()
        mockGetStbtTestPackRevision.mockReturnValueOnce(
          TEST_STBT_TEST_PACK_REVISION,
        );

        // Setup mocks for getStbtTags()
        mockGetStbtTags.mockReturnValueOnce(TEST_STBT_TAGS);

        // Setup mocks for for getSelectedStbtTests()
        mockGetSelectedStbtTests.mockReturnValueOnce(TEST_STBT_TEST_CASES);

        // Set STBT_AUTH_TOKEN
        if (stbtAuthToken === undefined) {
          delete process.env.STBT_AUTH_TOKEN;
        } else {
          process.env.STBT_AUTH_TOKEN = stbtAuthToken;
        }

        // Mock bafTestManager.mockImplementationOnce() to return the results.
        const SAMPLE_BAF_TEST_RUN_RESULTS: IBafTestRunResults = {
          isSuccess: didTestsSucceed,
          testResults: [TEST_STBT_TEST_RESULT_1, TEST_STBT_TEST_RESULT_2],
          bddStepsResults: AGGREGATED_TEST_RESULTS,
        };

        mockBafTestManagerRunTestsAsync.mockResolvedValueOnce(
          SAMPLE_BAF_TEST_RUN_RESULTS,
        );

        // Execute
        const actualDidTestsSucceed = await runTestsWithStbtAsync(
          configParameterToRunTestsWithStbtAsync,
        );

        // Verify
        expect(actualDidTestsSucceed).toEqual(didTestsSucceed);

        // Verify that the correctly modified configuration object is passed into loadConfiguration()`
        expect(mockLoadConfiguration).toHaveBeenCalledTimes(1);
        expect(mockLoadConfiguration).toHaveBeenCalledWith(
          expectedToBePassedToLoadConfiguration,
        );

        // Verify that the loaded configuration is passed to getSelectedStbtTests()
        expect(mockGetSelectedStbtTests).toHaveBeenCalledTimes(1);
        expect(mockGetSelectedStbtTests).toHaveBeenCalledWith(
          TEST_PATH_TO_FEATURES_FOLDER_WITH_WILDCARD,
          TEST_TAG_EXPRESSION,
        );

        // Verify that the StbtClient and device type are passed to getStbtNodeIdsForDeviceTypeAsync()
        expect(mockGetStbtNodeIdsForDeviceTypeAsync).toHaveBeenCalledTimes(1);
        expect(mockGetStbtNodeIdsForDeviceTypeAsync).toHaveBeenCalledWith(
          TEST_DEVICE_TYPE,
        );

        // Verify that getStbtTestPackRevision() is called exactly once
        expect(mockGetStbtTestPackRevision).toHaveBeenCalledTimes(1);
        expect(mockGetStbtTestPackRevision).toHaveBeenCalledWith();

        // Verify that getStbtTags() is called exactly once
        expect(mockGetStbtTags).toHaveBeenCalledTimes(1);
        expect(mockGetStbtTags).toHaveBeenCalledWith();

        // Verify that the BafTestManager instance was called correctly
        expect(mockBafTestManagerConstructor).toHaveBeenCalledTimes(1);
        expect(mockBafTestManagerConstructor).toHaveBeenCalledWith({
          stbtClient: mockStbtClientInstance,
          stbtNodeIds: [TEST_STBT_NODE_ID],
          stbtTags: TEST_STBT_TAGS,
          testCases: TEST_STBT_TEST_CASES,
          testPackRevision: TEST_STBT_TEST_PACK_REVISION,
        });

        // Verify that bafTestManager.runTestsAsync was called correctly
        expect(mockBafTestManagerRunTestsAsync).toHaveBeenCalledTimes(1);
        expect(mockBafTestManagerRunTestsAsync).toHaveBeenCalledWith();

        // Verify that writeBddJsonReportFile was called correctly
        expect(mockWriteBddJsonReportFile).toHaveBeenCalledTimes(1);
        expect(mockWriteBddJsonReportFile).toHaveBeenCalledWith(
          AGGREGATED_TEST_RESULTS,
        );
      });
    },
  );
});
