// Copyright text placeholder, Warner Bros. Discovery, Inc.

const mockExecSync = jest.fn();
const mockExistsSync = jest.fn();

jest.mock('child_process', () => {
  const original = jest.requireActual('child_process');

  return {
    ...original,
    execSync: mockExecSync,
  };
});

jest.mock('fs', () => {
  const original = jest.requireActual('fs');

  return {
    ...original,
    existsSync: mockExistsSync,
  };
});

import { readFileSync } from 'fs';
import { resolve } from 'path';
import { getSelectedStbtTests } from '../../lib/getSelectedStbtTests';

describe('lib/getSelectedStbtTests', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  const EXPECTED_PYTEST_LOCATION = '.venv/bin/pytest';
  const EXPECTED_EXEC_SYNC_ENCODING = { encoding: 'utf-8' };

  it('returns the selected tests when the pytest command succeeds', () => {
    // Setup
    // Mock pytest existing at the expected location
    mockExistsSync.mockReturnValueOnce(true);

    // Load the pytest command success output (captured from a real run)
    const successPytestOutputFile = resolve(
      __dirname,
      `../test_resources/lib/getSelectedStbtTests/execSync-success/pytest-output.txt`,
    );
    const successPytestOutput = readFileSync(successPytestOutputFile);

    // Mock the pytest execSync() call with the success output
    mockExecSync.mockReturnValueOnce(successPytestOutput);

    // Load the selected tests that we expect from the pytest success (based on the canned success output)
    const expectedSuccessResult = require('../test_resources/lib/getSelectedStbtTests/execSync-success/selected-tests.json');

    // Execute
    const actualResult = getSelectedStbtTests(
      'someProjectAndFeaturePath/',
      '@someTagExpression @orSomething',
    );

    // Verify
    expect(actualResult).toStrictEqual(expectedSuccessResult);

    expect(mockExistsSync).toHaveBeenCalledTimes(1);
    expect(mockExistsSync).toHaveBeenCalledWith(EXPECTED_PYTEST_LOCATION);

    expect(mockExecSync).toHaveBeenCalledTimes(1);
    expect(mockExecSync).toHaveBeenCalledWith(
      '.venv/bin/pytest --co someProjectAndFeaturePath/ -q -m "someTagExpression orSomething"',
      EXPECTED_EXEC_SYNC_ENCODING,
    );
  });

  it('strips off the trailing "*", if one is present, before calling pytest', () => {
    // Setup
    // Mock pytest existing at the expected location
    mockExistsSync.mockReturnValueOnce(true);

    // Load the pytest command success output (captured from a real run)
    const successPytestOutputFile = resolve(
      __dirname,
      `../test_resources/lib/getSelectedStbtTests/execSync-success/pytest-output.txt`,
    );
    const successPytestOutput = readFileSync(successPytestOutputFile);

    // Mock the pytest execSync() call with the success output
    mockExecSync.mockReturnValueOnce(successPytestOutput);

    // Load the selected tests that we expect from the pytest success (based on the canned success output)
    const expectedSuccessResult = require('../test_resources/lib/getSelectedStbtTests/execSync-success/selected-tests.json');

    // Execute
    const actualResult = getSelectedStbtTests(
      'someProjectAndFeaturePath/*',
      '@someTagExpression @orSomething',
    );

    // Verify
    expect(actualResult).toStrictEqual(expectedSuccessResult);

    expect(mockExistsSync).toHaveBeenCalledTimes(1);
    expect(mockExistsSync).toHaveBeenCalledWith(EXPECTED_PYTEST_LOCATION);

    expect(mockExecSync).toHaveBeenCalledTimes(1);
    expect(mockExecSync).toHaveBeenCalledWith(
      '.venv/bin/pytest --co someProjectAndFeaturePath/ -q -m "someTagExpression orSomething"',
      EXPECTED_EXEC_SYNC_ENCODING,
    );
  });

  it('throws an error when pytest is not installed', () => {
    // Setup
    // Mock pytest not existing at the expected location
    mockExistsSync.mockReturnValueOnce(false);

    // Execute and Verify
    expect(() =>
      getSelectedStbtTests('someProject', 'someTagExpression'),
    ).toThrowError(
      'Could not find pytest at ".venv/bin/pytest". If pytest-bdd is not installed, please run ".venv/bin/pip install git+https://github.com/lukeyoui/pytest-bdd.git@v1.0-wbd-alpha" to install it.',
    );

    // Verify
    expect(mockExistsSync).toHaveBeenCalledTimes(1);
    expect(mockExistsSync).toHaveBeenCalledWith(EXPECTED_PYTEST_LOCATION);

    expect(mockExecSync).not.toHaveBeenCalled();
  });

  it('throws an error when pytest-bdd is not installed, but we try to call it anyway', () => {
    // Setup
    // Mock pytest existing at the expected location, because we're seeing how the error is handled if the test
    // collection fails with the error that happens if it is not installed
    mockExistsSync.mockReturnValueOnce(true);

    const execSyncErrorPytestBddNotInstalled = require('../test_resources/lib/getSelectedStbtTests/execSync-error-objects/pytest-bdd-not-installed.json');

    // Mock pytest exiting with a non-zero status code, and execSync() throwing a corresponding error
    mockExecSync.mockImplementation(() => {
      // Error object thrown by execSync(), containing the output of the pytest command when pytest-bdd is not installed
      throw execSyncErrorPytestBddNotInstalled;
    });

    // Execute and Verify
    expect(() =>
      getSelectedStbtTests(
        'tests/projects/someProject/features/*',
        '@P0 and not @P1',
      ),
    ).toThrowError(
      new Error(
        'pytest-bdd is not installed. Please run ".venv/bin/pip install git+https://github.com/lukeyoui/pytest-bdd.git@v1.0-wbd-alpha" to install it.',
      ),
    );

    // Verify
    expect(mockExistsSync).toHaveBeenCalledTimes(1);
    expect(mockExistsSync).toHaveBeenCalledWith(EXPECTED_PYTEST_LOCATION);

    expect(mockExecSync).toHaveBeenCalledTimes(1);
    expect(mockExecSync).toHaveBeenCalledWith(
      '.venv/bin/pytest --co tests/projects/someProject/features/ -q -m "P0 and not P1"',
      EXPECTED_EXEC_SYNC_ENCODING,
    );
  });

  it('throws an error when the @tag expression is invalid', () => {
    // Setup
    // Mock pytest existing at the expected location
    mockExistsSync.mockReturnValueOnce(true);

    const execSyncErrorInvalidTagExpression = require('../test_resources/lib/getSelectedStbtTests/execSync-error-objects/tagExpression-adn-instead-of-and.json');

    // Mock pytest exiting with a non-zero status code, and execSync() throwing a corresponding error
    mockExecSync.mockImplementation(() => {
      // Error object thrown by execSync(), containing the output of the pytest command when the tag expression is invalid because it contains "adn" instead of "and"
      throw execSyncErrorInvalidTagExpression;
    });

    // Execute and Verify
    expect(() =>
      getSelectedStbtTests(
        'tests/projects/someProject/features/*',
        '@P0 adn not @P1',
      ),
    ).toThrowError(
      new Error(
        `Invalid tag expression "@P0 adn not @P1". pytest-bdd error was "ERROR: Wrong expression passed to '-m': P0 adn not P1: at column 4: expected end of input; got identifier"`,
      ),
    );

    // Verify
    expect(mockExistsSync).toHaveBeenCalledTimes(1);
    expect(mockExistsSync).toHaveBeenCalledWith(EXPECTED_PYTEST_LOCATION);

    expect(mockExecSync).toHaveBeenCalledTimes(1);
    expect(mockExecSync).toHaveBeenCalledWith(
      '.venv/bin/pytest --co tests/projects/someProject/features/ -q -m "P0 adn not P1"',
      EXPECTED_EXEC_SYNC_ENCODING,
    );
  });

  it('throws an error when there are no tests in the feature', () => {
    // Setup
    // Mock pytest existing at the expected location
    mockExistsSync.mockReturnValueOnce(true);

    const execSyncErrorNoTests = require('../test_resources/lib/getSelectedStbtTests/execSync-error-objects/no-tests-in-project-or-feature.json');

    // Mock pytest exiting with a non-zero status code, and execSync() throwing a corresponding error
    mockExecSync.mockImplementation(() => {
      // Error object thrown by execSync(), containing the output of the pytest command when there are no tests in the project/feature
      throw execSyncErrorNoTests;
    });

    // Execute and Verify
    expect(() =>
      getSelectedStbtTests(
        'tests/projects/someProject/features/*',
        '@P0 and not @P1',
      ),
    ).toThrowError(
      new Error(
        `No tests found in path "tests/projects/someProject/features/*"`,
      ),
    );

    // Verify
    expect(mockExistsSync).toHaveBeenCalledTimes(1);
    expect(mockExistsSync).toHaveBeenCalledWith(EXPECTED_PYTEST_LOCATION);

    expect(mockExecSync).toHaveBeenCalledTimes(1);
    expect(mockExecSync).toHaveBeenCalledWith(
      '.venv/bin/pytest --co tests/projects/someProject/features/ -q -m "P0 and not P1"',
      EXPECTED_EXEC_SYNC_ENCODING,
    );
  });

  it('throws an error when there are no tests that match the given tags', () => {
    // Setup
    // Mock pytest existing at the expected location
    mockExistsSync.mockReturnValueOnce(true);

    const execSyncErrorTagExpressionExcludesAllTests = require('../test_resources/lib/getSelectedStbtTests/execSync-error-objects/tagExpression-excludes-all-tests.json');

    // Mock pytest exiting with a non-zero status code, and execSync() throwing a corresponding error
    mockExecSync.mockImplementation(() => {
      // Error object thrown by execSync(), containing the output of the pytest command when there are 37 tests, but the tags exclude all 37 of them
      throw execSyncErrorTagExpressionExcludesAllTests;
    });

    // Execute and Verify
    expect(() =>
      getSelectedStbtTests(
        'tests/projects/someProject/features/*',
        '@P0 and not @P1',
      ),
    ).toThrowError(
      new Error(
        `No tests found in path "tests/projects/someProject/features/*" matching tag expression "@P0 and not @P1". 37 tests were excluded by the tag expression.`,
      ),
    );

    // Verify
    expect(mockExistsSync).toHaveBeenCalledTimes(1);
    expect(mockExistsSync).toHaveBeenCalledWith(EXPECTED_PYTEST_LOCATION);

    expect(mockExecSync).toHaveBeenCalledTimes(1);
    expect(mockExecSync).toHaveBeenCalledWith(
      '.venv/bin/pytest --co tests/projects/someProject/features/ -q -m "P0 and not P1"',
      EXPECTED_EXEC_SYNC_ENCODING,
    );
  });

  it('throws an error when there is a space in the features path', () => {
    // Setup
    // Mock pytest existing at the expected location
    mockExistsSync.mockReturnValueOnce(true);

    // Execute and Verify
    expect(() =>
      getSelectedStbtTests(
        'tests/projects/someProject/features/feature1 tests/projects/someProject/features/feature2',
        '@P0 and not @P1',
      ),
    ).toThrowError(
      new Error(
        'Path cannot include a space, and individual features cannot be specified',
      ),
    );

    // Verify
    expect(mockExistsSync).toHaveBeenCalledTimes(1);
    expect(mockExistsSync).toHaveBeenCalledWith(EXPECTED_PYTEST_LOCATION);

    expect(mockExecSync).not.toHaveBeenCalled();
  });

  it('throws a generic error if something goes wrong, but we do not recognize the stderr contents', () => {
    // Setup
    // Mock pytest existing at the expected location
    mockExistsSync.mockReturnValueOnce(true);

    const execSyncErrorWrittenToStdout = require('../test_resources/lib/getSelectedStbtTests/execSync-error-objects/unknown-error-written-to-stderr.json');

    // Mock pytest exiting with a non-zero status code, and execSync() throwing a corresponding error
    mockExecSync.mockImplementation(() => {
      // Error object thrown by execSync(), containing the output of the pytest command when there are 37 tests, but the tags exclude all 37 of them
      throw execSyncErrorWrittenToStdout;
    });

    // Execute and Verify
    expect(() =>
      getSelectedStbtTests(
        'tests/projects/someProject/features/*',
        '@P0 and not @P1',
      ),
    ).toThrowError(
      new Error(
        'Unknown error executing pytest command ".venv/bin/pytest --co tests/projects/someProject/features/ -q -m "P0 and not P1"". Error status: 4, error output: "some unknown error\nhas occurred".',
      ),
    );

    // Verify
    expect(mockExistsSync).toHaveBeenCalledTimes(1);
    expect(mockExistsSync).toHaveBeenCalledWith(EXPECTED_PYTEST_LOCATION);

    expect(mockExecSync).toHaveBeenCalledTimes(1);
    expect(mockExecSync).toHaveBeenCalledWith(
      '.venv/bin/pytest --co tests/projects/someProject/features/ -q -m "P0 and not P1"',
      EXPECTED_EXEC_SYNC_ENCODING,
    );
  });

  it('throws a generic error if something goes wrong, but there is nothing in stderr (i.e. error was dumped to stdout)', () => {
    // Setup
    // Mock pytest existing at the expected location
    mockExistsSync.mockReturnValueOnce(true);

    const execSyncErrorWrittenToStdout = require('../test_resources/lib/getSelectedStbtTests/execSync-error-objects/unknown-error-written-to-stdout.json');

    // Mock pytest exiting with a non-zero status code, and execSync() throwing a corresponding error
    mockExecSync.mockImplementation(() => {
      // Error object thrown by execSync(), containing the output of the pytest command when there are 37 tests, but the tags exclude all 37 of them
      throw execSyncErrorWrittenToStdout;
    });

    // Execute and Verify
    expect(() =>
      getSelectedStbtTests(
        'tests/projects/someProject/features/*',
        '@P0 and not @P1',
      ),
    ).toThrowError(
      new Error(
        'Unknown error executing pytest command ".venv/bin/pytest --co tests/projects/someProject/features/ -q -m "P0 and not P1"". Error status: 4, error output: "some unknown error\nhas occurred".',
      ),
    );

    // Verify
    expect(mockExistsSync).toHaveBeenCalledTimes(1);
    expect(mockExistsSync).toHaveBeenCalledWith(EXPECTED_PYTEST_LOCATION);

    expect(mockExecSync).toHaveBeenCalledTimes(1);
    expect(mockExecSync).toHaveBeenCalledWith(
      '.venv/bin/pytest --co tests/projects/someProject/features/ -q -m "P0 and not P1"',
      EXPECTED_EXEC_SYNC_ENCODING,
    );
  });
});
