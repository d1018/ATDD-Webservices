// Copyright text placeholder, Warner Bros. Discovery, Inc.

let mockPassThru: { end: () => {} };

jest.mock('@cucumber/cucumber/api', () => {
  const original = jest.requireActual('@cucumber/cucumber/api');
  const mockModule = {
    ...original,
    runCucumber: jest.fn((...args) =>
      original.runCucumber(args[0], {
        stdout: mockPassThru,
      }),
    ),
  };

  return mockModule;
});

import { PassThrough } from 'stream';
import os from 'os';
import { join } from 'path';

import {
  ICoreConfig,
  runTestsWithCucumberAsync,
} from '../../lib/runTestsWithCucumberAsync';

const streamToString = require('stream-to-string');

describe('lib/injectedHooks.js (live) and lib/injectedHooks.ts (in Jest)', () => {
  beforeEach(() => {
    jest.clearAllMocks();

    process.env.DEVICE = 'android';
    delete process.env.JIRA_CONFIG_FILE;
    delete process.env.CI;
    delete process.env.GITHUB_ACTION;
    delete process.env.RUNNER_TEMP;

    mockPassThru = new PassThrough();
  });

  afterEach(() => {
    delete process.env.DEVICE;
  });

  const testConfig = [
    {
      testName: 'ensure our injected hook is executed first',
      runTestsWithCucumberConfig: {
        require: [
          join(
            'tests',
            'test_resources',
            'bddFileForUnitTests',
            'stepDefinition',
            'step3.js',
          ),
        ],
        paths: [
          join('tests', 'test_resources', 'bddFileForUnitTests', 'features'),
        ],
        format: [
          '@cucumber/pretty-formatter',
          `json:${join(process.cwd(), 'results', 'result.json')}`,
        ],
      },
    },
  ];

  // eslint-disable-next-line no-restricted-syntax
  for (const { testName, runTestsWithCucumberConfig } of testConfig) {
    // eslint-disable-next-line no-loop-func
    test(`run cucumber: ${testName}`, async () => {
      // should return false as the test is set to throw
      await expect(
        runTestsWithCucumberAsync(runTestsWithCucumberConfig as ICoreConfig),
      ).resolves.toEqual(false);

      mockPassThru.end();

      let stdOut = await streamToString(mockPassThru as PassThrough);

      // injectedHooks.ts can be loaded instead of injectedHooks.js in case of Jest
      // let's normalize to .js
      stdOut = stdOut.replaceAll('injectedHooks.ts', 'injectedHooks.js');

      // get rid of the src line number as it is subjected to changes from build to build
      // "Before # BAF hook from lib/injectedHooks.js:3"
      // to:
      // "Before # BAF hook from lib/injectedHooks.js"
      stdOut = stdOut.replace(/.js(:(\d)+)+/g, '.js');

      // get rid of the execution time:
      // "Your awesome test(s) ran for 0m00.026s (executing steps: 0m00.010s)"
      // to:
      // "Your awesome test(s) ran for XXX (executing steps: XXX)"
      stdOut = stdOut.replace(/(\d+)m(\d+)\.(\d+)s/g, 'XXX');

      // get rid of local running path too: crash stack contains local path
      stdOut = stdOut.replaceAll(process.cwd(), '<<current_working_dir>>');

      // the cucumber output has color for the text
      // that we need get rid of it before final string compare
      // eslint-disable-next-line no-control-regex
      stdOut = stdOut.replace(/\x1B[[(?);]{0,2}(;?\d)*./g, '');

      // make sure the summary output has our hook listed first, which means it gets executed
      // first before any hook
      expect(stdOut).toContain(
        [
          'Failures:',
          '',
          '1) Scenario: MyTest # tests/test_resources/bddFileForUnitTests/features/test.feature:5',
          '   ✔ Before # BAF hook from lib/injectedHooks.js',
          '   ✔ Before # tests/test_resources/bddFileForUnitTests/stepDefinition/step3.js',
          '   ✔ Given given 1 # tests/test_resources/bddFileForUnitTests/stepDefinition/step3.js',
          '   ✖ Then then 1 # tests/test_resources/bddFileForUnitTests/stepDefinition/step3.js',
          '       Error: an error',
          '           at World.<anonymous> (<<current_working_dir>>/tests/test_resources/bddFileForUnitTests/stepDefinition/step3.js)',
          '   ✔ After # tests/test_resources/bddFileForUnitTests/stepDefinition/step3.js',
          '   ✔ After # BAF hook from lib/injectedHooks.js',
          '',
          'Hello!',
          'Thank you for using BAF!!',
          'You have 1 scenario (1 failed)',
          'You have 2 steps (1 failed, 1 passed)',
          'Your awesome test(s) ran for XXX (executing steps: XXX)',
        ].join(os.EOL),
      );
    });
  }
});
