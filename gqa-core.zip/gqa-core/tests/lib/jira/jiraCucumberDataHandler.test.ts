// Copyright text placeholder, Warner Bros. Discovery, Inc.

import testFailureData from '../../test_resources/jira/testFailureData.json';
import testFailureDocNode from '../../test_resources/jira/testFailureDataDocNode.json';
import { createJiraBugDescriptionJiraDocNode } from '../../../lib/jira/jiraCucumberDataHandler';

describe('createJiraBugDescriptionJiraDocNode', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('generate correct description adt docNode', () => {
    expect(
      createJiraBugDescriptionJiraDocNode({
        failureData: testFailureData,
        newBug: true,
      }),
    ).toMatchObject(testFailureDocNode);
  });
});
