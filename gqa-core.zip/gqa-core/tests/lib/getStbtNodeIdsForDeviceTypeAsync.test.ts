// Copyright text placeholder, Warner Bros. Discovery, Inc.

import {
  ORANGE_DOT_MARKER,
  getStbtNodeIdsForDeviceTypeAsync,
} from '../../lib/getStbtNodeIdsForDeviceTypeAsync';

describe('lib/getStbtNodeIdsForDeviceTypeAsync', () => {
  const TEST_STBT_NODE_ID = 'stb-tester-node-1234567890abcd';

  const UNRESERVED_DEVICE_TYPE = 'fnord';

  const RESERVED_DEVICE_TYPE: string = 'comcast';
  const RESERVED_NODE_IDS: string[] = [
    'stb-tester-00044b80f5e9',
    'stb-tester-00044b80f7df',
  ];

  beforeEach(() => {
    jest.clearAllMocks();
    delete process.env.STBT_NODE_ID;
  });

  afterEach(() => {
    jest.clearAllMocks();
    delete process.env.STBT_NODE_ID;
  });

  it('returns the reserved Orange Dot node id(s) for the specified device type, if there are any, when `STBT_NODE_ID` is set to "ORANGE_DOT"', async () => {
    process.env.STBT_NODE_ID = ORANGE_DOT_MARKER;
    await expect(
      getStbtNodeIdsForDeviceTypeAsync(RESERVED_DEVICE_TYPE),
    ).resolves.toStrictEqual(RESERVED_NODE_IDS);
  });

  it(`throws an Error if asked for the reserved Orange Dot node ids for a device type that has no configured Orange Dot devices, when STBT_NODE_ID is set to "ORANGE_DOT"`, async () => {
    process.env.STBT_NODE_ID = ORANGE_DOT_MARKER;
    await expect(() =>
      getStbtNodeIdsForDeviceTypeAsync(UNRESERVED_DEVICE_TYPE),
    ).rejects.toEqual(
      new Error(
        'No "fnord" devices are reserved for Orange Dot. Device types with reserved nodes: ["comcast"].',
      ),
    );
  });

  it('returns the value of STBT_NODE_ID if it is set to an STBT node id, regardless of device type', async () => {
    process.env.STBT_NODE_ID = TEST_STBT_NODE_ID;

    await expect(
      getStbtNodeIdsForDeviceTypeAsync(RESERVED_DEVICE_TYPE),
    ).resolves.toStrictEqual([TEST_STBT_NODE_ID]);

    await expect(
      getStbtNodeIdsForDeviceTypeAsync(UNRESERVED_DEVICE_TYPE),
    ).resolves.toStrictEqual([TEST_STBT_NODE_ID]);
  });

  it('throws an exception when `STBT_NODE_ID` is not set, since we do not yet have Device Lookup available', async () => {
    delete process.env.STBT_NODE_ID;
    await expect(
      getStbtNodeIdsForDeviceTypeAsync(RESERVED_DEVICE_TYPE),
    ).rejects.toThrowError(
      'STBT_NODE_ID must be set to an STBT node id, or to the marker value "ORANGE_DOT".',
    );
  });
});
