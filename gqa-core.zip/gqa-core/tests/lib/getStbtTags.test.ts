// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { getStbtTags } from '../../lib/getStbtTags';

describe('lib/getStbtTags', () => {
  const CLIENT_ENVIRONMENT_VARIABLE = 'CLIENT';
  const CLIENT_VALUE = 'Comcast';
  const CLIENT_STBT_TAG = 'client';

  const PRODUCT_ENVIRONMENT_VARIABLE = 'PRODUCT';
  const PRODUCT_VALUE = 'Beam';
  const PRODUCT_STBT_TAG = 'product';

  const REGION_ENVIRONMENT_VARIABLE = 'REGION';
  const REGION_VALUE = 'APAC';
  const REGION_STBT_TAG = 'region';

  const STBT_TAG_ONE_ENVIRONMENT_VARIABLE = 'STBT_TAG_ONE';
  const STBT_TAG_ONE_VALUE = 'value of STBT_TAG_ONE';
  const STBT_TAG_ONE_STBT_TAG = 'STBT_TAG_ONE';

  const STBT_TAGNOPE_ENVIRONMENT_VARIABLE = 'STBT_TAGNOPE';
  const STBT_TAGNOPE_VALUE = 'value of STBT_TAGNOPE';

  beforeEach(() => {
    delete process.env[CLIENT_ENVIRONMENT_VARIABLE];
    delete process.env[PRODUCT_ENVIRONMENT_VARIABLE];
    delete process.env[REGION_ENVIRONMENT_VARIABLE];
    delete process.env[STBT_TAG_ONE_ENVIRONMENT_VARIABLE];
    delete process.env[STBT_TAGNOPE_ENVIRONMENT_VARIABLE];
  });

  it('returns the three standard values if they are set', () => {
    // Setup
    process.env[CLIENT_ENVIRONMENT_VARIABLE] = CLIENT_VALUE;
    process.env[PRODUCT_ENVIRONMENT_VARIABLE] = PRODUCT_VALUE;
    process.env[REGION_ENVIRONMENT_VARIABLE] = REGION_VALUE;

    const expectedStbtTags = {
      [CLIENT_STBT_TAG]: CLIENT_VALUE,
      [PRODUCT_STBT_TAG]: PRODUCT_VALUE,
      [REGION_STBT_TAG]: REGION_VALUE,
    };

    // Execute
    const actualStbtTags = getStbtTags();

    // Verify
    expect(actualStbtTags).toStrictEqual(expectedStbtTags);
  });

  it('returns undefined for any of the three standard that are not set, and the empty string for any of the three standards that are set to the empty string', () => {
    // Setup
    process.env[CLIENT_ENVIRONMENT_VARIABLE] = CLIENT_VALUE;
    delete process.env[PRODUCT_ENVIRONMENT_VARIABLE];
    process.env[REGION_ENVIRONMENT_VARIABLE] = '';

    const expectedStbtTags = {
      [CLIENT_STBT_TAG]: CLIENT_VALUE,
      [PRODUCT_STBT_TAG]: undefined,
      [REGION_STBT_TAG]: '',
    };

    // Execute
    const actualStbtTags = getStbtTags();

    // Verify
    expect(actualStbtTags).toStrictEqual(expectedStbtTags);
  });

  it('returns any additional environment tags that start with "STBT_TAG_"', () => {
    // Setup
    process.env[CLIENT_ENVIRONMENT_VARIABLE] = CLIENT_VALUE;
    process.env[PRODUCT_ENVIRONMENT_VARIABLE] = PRODUCT_VALUE;
    process.env[REGION_ENVIRONMENT_VARIABLE] = REGION_VALUE;
    process.env[STBT_TAG_ONE_ENVIRONMENT_VARIABLE] = STBT_TAG_ONE_VALUE;
    process.env[STBT_TAGNOPE_ENVIRONMENT_VARIABLE] = STBT_TAGNOPE_VALUE;

    const expectedStbtTags = {
      [CLIENT_STBT_TAG]: CLIENT_VALUE,
      [PRODUCT_STBT_TAG]: PRODUCT_VALUE,
      [REGION_STBT_TAG]: REGION_VALUE,
      [STBT_TAG_ONE_STBT_TAG]: STBT_TAG_ONE_VALUE,
    };

    // Execute
    const actualStbtTags = getStbtTags();

    // Verify
    expect(actualStbtTags).toStrictEqual(expectedStbtTags);
  });
});
