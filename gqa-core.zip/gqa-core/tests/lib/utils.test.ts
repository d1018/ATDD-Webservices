// Copyright text placeholder, Warner Bros. Discovery, Inc.

import { throwHookError } from '../../lib/utils';

describe('lib/utils.ts', () => {
  test('throwError can throw string', () => {
    expect(() => {
      throwHookError('testing', 'abc');
    }).toThrowError('abc');
  });

  test('throwError can throw error correctly', () => {
    expect(() => {
      throwHookError('testing', new Error('an error'));
    }).toThrowError(new Error('an error'));
  });
});
