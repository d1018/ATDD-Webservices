// Copyright text placeholder, Warner Bros. Discovery, Inc.

const mockLoadConfiguration = jest.fn();
const mockLoadSupport = jest.fn();
const mockRunCucumber = jest.fn();

// mock the loadConfiguration out from cucumber API
jest.mock('@cucumber/cucumber/api', () => {
  const mockModule = {
    loadConfiguration: mockLoadConfiguration,
    loadSupport: mockLoadSupport,
    runCucumber: mockRunCucumber,
  };

  return mockModule;
});

require('@cucumber/cucumber/api');

// eslint-disable-next-line import/first
import { join } from 'path';

// eslint-disable-next-line import/first
import {
  runTestsWithCucumberAsync,
  ICoreConfig,
} from '../../lib/runTestsWithCucumberAsync';

describe('lib/runTestsWithCucumberAsync', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('throw error if config is undefined', async () => {
    await expect(runTestsWithCucumberAsync()).rejects.toThrowError(
      'Please specify a valid test config!',
    );
  });

  [
    {
      description: 'empty config',
      runTestsWithCucumberConfig: {},
      loadConfigurationConfig: {
        profiles: undefined,
        provided: {
          require: [join(process.cwd(), 'lib', 'injectedHooks.ts')],
        },
      },
      result: true,
    },
    {
      description: 'valid config',
      runTestsWithCucumberConfig: {
        file: 'config file',
        profiles: ['default'],
        paths: ['features'],
        require: ['features/stepDefinition'],
        parallel: 2,
        tags: '@123',
      },
      loadConfigurationConfig: {
        file: 'config file',
        profiles: ['default'],
        provided: {
          file: 'config file',
          profiles: ['default'],
          paths: ['features'],
          require: [
            join(process.cwd(), 'lib', 'injectedHooks.ts'),
            'features/stepDefinition',
          ],
          parallel: 2,
          tags: '@123',
        },
      },
      result: true,
    },
    {
      description: 'valid config failing tests',
      runTestsWithCucumberConfig: {
        file: 'config file',
        profiles: ['default'],
        paths: ['features'],
        require: ['features/stepDefinition'],
        parallel: 2,
        tags: '@123',
      },
      loadConfigurationConfig: {
        file: 'config file',
        profiles: ['default'],
        provided: {
          file: 'config file',
          profiles: ['default'],
          paths: ['features'],
          require: [
            join(process.cwd(), 'lib', 'injectedHooks.ts'),
            'features/stepDefinition',
          ],
          parallel: 2,
          tags: '@123',
        },
      },
      result: false,
    },
  ].forEach(
    ({
      description,
      runTestsWithCucumberConfig,
      loadConfigurationConfig,
      result,
    }) => {
      test(`verify runner config is passed into cucumber-js loadConfiguration API correctly: ${description}`, async () => {
        const mockLoadConfigurationResult = {
          runConfiguration: {
            isA: 'mock runConfiguration within a mock loadConfiguration result',
          },
          isA: 'mock loadConfiguration result',
        };
        const mockLoadSupportResult = {
          isA: 'mock loadSupport result',
          support: {
            isA: 'mock support within a mock loadSupport result',
          },
        };
        const mockRunCucumberResult = {
          isA: 'mock runCucumber result',
          success: result,
        };

        mockLoadConfiguration.mockReturnValue(mockLoadConfigurationResult);
        mockLoadSupport.mockReturnValue(mockLoadSupportResult);
        mockRunCucumber.mockReturnValue(mockRunCucumberResult);

        const actualResult = await runTestsWithCucumberAsync(
          runTestsWithCucumberConfig as ICoreConfig,
        );

        expect(mockLoadConfiguration).toBeCalledTimes(1);
        expect(mockLoadConfiguration).toBeCalledWith(loadConfigurationConfig);

        expect(mockLoadSupport).toBeCalledTimes(1);
        expect(mockLoadSupport).toBeCalledWith(
          mockLoadConfigurationResult.runConfiguration,
        );

        expect(mockRunCucumber).toBeCalledTimes(1);
        expect(mockRunCucumber).toBeCalledWith({
          isA: 'mock runConfiguration within a mock loadConfiguration result',
          support: mockLoadSupportResult,
        });

        expect(actualResult).toBe(result);
      });
    },
  );
});
