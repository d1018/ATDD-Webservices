// Copyright text placeholder, Warner Bros. Discovery, Inc.

const mockWriteFile = jest.fn();

jest.mock('fs-extra', () => {
  const original = jest.requireActual('fs-extra');

  return {
    ...original,
    writeFile: mockWriteFile,
  };
});

import { join } from 'path';

import {
  ICoreConfig,
  runTestsWithCucumberAsync,
} from '../../lib/runTestsWithCucumberAsync';

import * as jiraCucumberDataHandler from '../../lib/jira/jiraCucumberDataHandler';

// mock the duration summary to return a static excution time for testing
jest
  .spyOn(jiraCucumberDataHandler, 'getDurationSummary')
  .mockReturnValue('99m.99.99s');

describe('lib/injectedHooks.js with jira enabled', () => {
  beforeEach(() => {
    jest.clearAllMocks();

    process.env.JIRA_CONFIG_FILE =
      'tests/test_resources/jira/jiraTestConfig.js';
    process.env.DEVICE = 'android';
    process.env.PLATFORM = 'appium';

    process.env.SSM_FILE = 'ssm';
    process.env.TEST_TYPE = 'any-type';
    process.env.TEST_ENV = 'integration';

    delete process.env.CI;
    delete process.env.GITHUB_ACTION;
    delete process.env.RUNNER_TEMP;
  });

  afterEach(() => {
    delete process.env.PLATFORM;
    delete process.env.DEVICE;

    delete process.env.SSM_FILE;
    delete process.env.TEST_TYPE;
    delete process.env.TEST_ENV;
  });

  const testConfig = [
    {
      testName: 'ensure our injected hook is executed first',
      runTestsWithCucumberConfig: {
        retry: 2,
        require: [
          join(
            'tests',
            'test_resources',
            'bddFileForUnitTests',
            'stepDefinition',
            'step3.js',
          ),
        ],
        paths: [
          join('tests', 'test_resources', 'bddFileForUnitTests', 'features'),
        ],
        format: [
          '@cucumber/pretty-formatter',
          `json:${join(process.cwd(), 'results', 'result.json')}`,
        ],
      },
    },
  ];

  // eslint-disable-next-line no-restricted-syntax
  for (const { testName, runTestsWithCucumberConfig } of testConfig) {
    // eslint-disable-next-line no-loop-func
    test(`run cucumber: ${testName}`, async () => {
      // should return false as the test is set to throw
      await expect(
        runTestsWithCucumberAsync(runTestsWithCucumberConfig as ICoreConfig),
      ).resolves.toEqual(false);

      expect(mockWriteFile).toBeCalledWith(
        expect.stringMatching(
          // eslint-disable-next-line prefer-regex-literals
          new RegExp('results/jira/jira.([\\d-\\w]+).json'),
        ),
        expect.any(String),
      );

      const jiraObject = JSON.parse(mockWriteFile.mock.calls[0][1]);

      // make sure the generated JIRA object is what we expected
      expect(jiraObject).toEqual(
        expect.objectContaining({
          note: ['priority is determined from cucumber tags: P2'],
          priority: 'P2',
          bugId: '769ac44913aac24a179c0634f4cedaba',
          project: 'DTC',
          device: 'android',
          platform: 'appium',
          geolocation: 'us',
          deviceInfoSummary: expect.any(String),

          deviceModel: 'unknown',
          deviceName: 'unknown',

          environment: 'integration',

          // Test Type
          testType: 'any-type',

          // SSM used
          ssmFile: 'ssm',

          featureDescription: 'I am testing something',
          featureFile:
            'tests/test_resources/bddFileForUnitTests/features/test.feature',
          featureName: 'Test 1',

          scenarioName: 'MyTest',
          scenarioDescription: 'Scenario Description',

          testTags: '@featureTag1 @p1 @ScenarioTag1 @p2',
          testDescription: [
            'Tags: @featureTag1 @p1 @ScenarioTag1 @p2',
            'Feature Name: Test 1',
            'Feature Description: I am testing something',
            'Feature file: tests/test_resources/bddFileForUnitTests/features/test.feature',
            'Scenario: MyTest',
            'Steps:',
            '1: Given given 1 (99m.99.99s, PASSED)',
            '2: Then then 1 (99m.99.99s, FAILED)',
          ],
          failedStepDescription: 'Then then 1',
          failedStepDuration: expect.any(String),
          stackMsg: expect.any(String),
          sessionId: expect.any(String),
          sessionUrl: expect.any(String),
          raw: {
            result: expect.any(Object),
            willBeRetried: false,
            pickle: expect.any(Object),
            gherkinDocument: expect.any(Object),
          },
        }),
      );
    });
  }
});
