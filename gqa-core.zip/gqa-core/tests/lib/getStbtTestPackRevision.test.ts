// Copyright text placeholder, Warner Bros. Discovery, Inc.

const mockExecSync = jest.fn();

jest.mock('child_process', () => {
  const original = jest.requireActual('child_process');

  return {
    ...original,
    execSync: mockExecSync,
  };
});

import { getStbtTestPackRevision } from '../../lib/getStbtTestPackRevision';
import { IExecSyncError } from '../../support/IExecSyncError';

describe('lib/getStbtTestPackRevision', () => {
  const TEST_STBT_TEST_PACK_REVISION =
    '6159bbc1bfec61fbe8ae49fc77da3beed323a083';

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('returns the contents of STBT_TEST_PACK_REVISION if it is set', () => {
    // Setup
    process.env.STBT_TEST_PACK_REVISION = TEST_STBT_TEST_PACK_REVISION;

    const expectedTestPackRevision = TEST_STBT_TEST_PACK_REVISION;

    // Execute
    const actualTestPackRevision = getStbtTestPackRevision();

    // Verify
    expect(actualTestPackRevision).toBe(expectedTestPackRevision);
  });

  it('returns the current Git SHA if STBT_TEST_PACK_REVISION is not set', () => {
    // Setup
    delete process.env.STBT_TEST_PACK_REVISION;

    // Load the captured error
    const execSyncSuccess = require('../test_resources/lib/getStbtTestPackRevision/execSync-success/execSync-success.json');
    const execSyncReturnValue = Buffer.from(execSyncSuccess);

    mockExecSync.mockReturnValueOnce(execSyncReturnValue);

    const expectedTestPackRevision = TEST_STBT_TEST_PACK_REVISION;

    // Execute
    const actualTestPackRevision = getStbtTestPackRevision();

    // Verify
    expect(actualTestPackRevision).toBe(expectedTestPackRevision);

    expect(mockExecSync).toHaveBeenCalledTimes(1);
  });

  [
    ['all numeric', '1234567890123456789012345678901234567890'],
    ['all hex letters', 'abcdefabcdefabcdefabcdefabcdefabcdefabcd'],
    ['numeric and hex letter', '1234abcdef1234abcdef1234abcdef1234abcdef'],
  ].forEach(([description, sha]) => {
    it(`passes if the git command returns a valid Git SHA (i.e., 40 hex characters): ${description} (${sha})`, () => {
      // Setup
      delete process.env.STBT_TEST_PACK_REVISION;

      mockExecSync.mockReturnValueOnce(Buffer.from(`${sha}\n`));

      const expectedTestPackRevision = sha;

      // Execute
      const actualTestPackRevision = getStbtTestPackRevision();

      // Verify
      expect(actualTestPackRevision).toBe(expectedTestPackRevision);

      expect(mockExecSync).toHaveBeenCalledTimes(1);
    });
  });

  [
    ['SHA too long', '1234567890123456789012345678901234567890a'],
    ['SHA too short', '123456789012345678901234567890123456789'],
    ['SHA not hex', '123456789012345678901234567890123456789g'],
  ].forEach(([description, sha]) => {
    it(`throws a meaningful Error if the git command returns an invalid Git SHA (i.e., not 40 hex characters): ${description} (${sha})`, () => {
      // Setup
      delete process.env.STBT_TEST_PACK_REVISION;

      mockExecSync.mockReturnValueOnce(Buffer.from(`${sha}\n`));

      // Execute and Verify Error thrown
      expect(() => getStbtTestPackRevision()).toThrowError(
        `Git command returned invalid git hash: "${sha}"`,
      );

      // Verify
      expect(mockExecSync).toHaveBeenCalledTimes(1);
    });
  });

  it('throws a meaningful error when the git command is invalid', () => {
    // Setup

    // Load the captured error
    const execSyncErrorInvalidGitCommand = require('../test_resources/lib/getStbtTestPackRevision/execSync-error-objects/invalid-git-command.json');

    // Mock the Git command not being supported, or being otherwise invalid
    mockExecSync.mockImplementation(() => {
      // Error object thrown by execSync(), containing the output of the Git command when the Git command is invalid.
      throw execSyncErrorInvalidGitCommand;
    });

    // Execute and Verify
    expect(() => getStbtTestPackRevision()).toThrowError(
      new Error(
        'Unknown error executing Git command "git rev-parse HEAD". Status code: 1, error output: "git: \'rev-parse\' is not a git command. See \'git --help\'.\n".',
      ),
    );
  });

  it('throws a meaningful error when the git revision is not found', () => {
    // Setup

    // Load the captured error
    const execSyncErrorUnknownRevisionOrPath = require('../test_resources/lib/getStbtTestPackRevision/execSync-error-objects/unknown-revision-or-path.json');

    // Mock the Git command not being supported, or being otherwise invalid
    mockExecSync.mockImplementation(() => {
      // Error object thrown by execSync(), containing the output of the Git command when the specified revision or path is invalid.
      throw execSyncErrorUnknownRevisionOrPath;
    });

    // Execute and Verify
    expect(() => getStbtTestPackRevision()).toThrowError(
      new Error(
        "Unknown error executing Git command \"git rev-parse HEAD\". Status code: 128, error output: \"fatal: ambiguous argument 'HEAD': unknown revision or path not in the working tree.\nUse '--' to separate paths from revisions, like this:\n'git <command> [<revision>...] -- [<file>...]'\n\".",
      ),
    );
  });

  test('Throws an error that includes stdout if no error is reported in stderr', () => {
    // Setup
    delete process.env.STBT_TEST_PACK_REVISION;

    mockExecSync.mockImplementation(() => {
      const error: IExecSyncError = {
        output: [
          null,
          'error in stdout line one\\n',
          'error in stdout line two\\n',
        ],
        pid: 12435,
        signal: null,
        status: 3,
        stderr: '',
        stdout: 'error in stdout line one\\nerror in stdout line two\\n',
      };

      throw error;
    });

    // Execute and Verify Error thrown
    expect(() => getStbtTestPackRevision()).toThrowError(
      'Unknown error executing Git command "git rev-parse HEAD". Status code: 3, error output: "error in stdout line one\\nerror in stdout line two\\n".',
    );
  });
});
