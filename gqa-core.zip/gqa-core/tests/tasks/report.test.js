const fs = require('fs');
const jake = require('jake');

const { createReportTask } = require('../../tasks');
const { runJakeTask } = require('../testUtils');

const taskName = 'utils:report';

describe('tasks/reportTask.js', () => {
  test('report task is created and executed successfully', async () => {
    // don't launch report after creation
    // launching a browser process during Jest test execution can cause Jest to fail with timeout :-(
    process.env.DEVICE = 'web';
    createReportTask(false);
    expect(jake.Task[taskName]).toBeDefined();

    const text = fs.readFileSync('tests/tasks/test_sample.json');

    const jsonData = new Uint8Array(Buffer.from(`${text}`));

    fs.writeFileSync('results/json_report.json', jsonData);

    await expect(runJakeTask(jake.Task[taskName])).resolves.not.toThrow();
  });

  test('report task failed to create a report due to missing content', async () => {
    createReportTask();
    expect(jake.Task[taskName]).toBeDefined();

    // create a blank report for testing
    fs.writeFileSync('results/json_report.json', '');

    // the error message has some coloring to it; just validate that it throws for now
    await expect(runJakeTask(jake.Task[taskName])).rejects.toThrow();
  });
});
