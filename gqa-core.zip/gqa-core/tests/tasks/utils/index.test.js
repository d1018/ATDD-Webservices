const fs = require('fs');

const {
  verifyEnvVars,
  hiddenFileFilter,
  obtainValueByKey,
  configureEnvVars,
  directoryFilter,
} = require('../../../tasks/utils');

describe('tasks/utils', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
  });

  describe('hddenFileFilter', () => {
    test('should return "true" when passing "testfile.js"', () => {
      const fileName = 'testfile.js';

      expect(hiddenFileFilter(fileName)).toBeTruthy();
    });

    test('should return "false" when passing ".testfile"', () => {
      const fileName = '.testfile';

      expect(hiddenFileFilter(fileName)).toBeFalsy();
    });
  });

  describe('verifyEnvVars', () => {
    test('doess not throw if all variables are defined', () => {
      const mockVerifyEnvVars = jest.fn(verifyEnvVars);

      mockVerifyEnvVars('string', 10, true, []);
      expect(mockVerifyEnvVars).toHaveBeenCalledTimes(1);
    });

    test('should throw an error when passing an "undefined" variable', () => {
      expect(() => {
        verifyEnvVars('string', 10, true, undefined);
      }).toThrow(/undefined is not set/);
    });
  });

  describe('obtainValueByKey', () => {
    test('should return "undefined" when passing an invalid key', () => {
      expect(obtainValueByKey('INVALID')).toBeFalsy();
    });
  });

  describe('directoryFilter', () => {
    test('should return directory type else falsy', () => {
      expect(directoryFilter('./support')).toBeFalsy();
    });
  });

  describe('configureEnvVars', () => {
    test('should configure environment variables', () => {
      jest.spyOn(fs, 'existsSync').mockImplementation(() => true);
      jest.spyOn(fs, 'copyFileSync').mockImplementation(() => jest.fn());
      jest.spyOn(fs, 'readFileSync').mockImplementation(
        () => `
      TESTING_ONE=testing_one
      TESTING_TWO=testing_two`,
      );
      jest.spyOn(fs, 'writeFileSync').mockImplementation(() => jest.fn());
      const mockConfigureEnvVars = jest.fn(configureEnvVars);

      mockConfigureEnvVars('.suitestrc', '.suitestrc.shadow');
      expect(mockConfigureEnvVars).toHaveBeenCalledTimes(1);
    });
  });
});
