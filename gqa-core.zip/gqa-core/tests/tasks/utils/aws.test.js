const { fetchSSMRegions } = require('../../../tasks/utils/aws');

const pathGB = '/integration-secrets/dev/dtc/android/gqa_core_test/gb';
const pathUS = '/integration-secrets/dev/dtc/android/gqa_core_test/us';
const pathRegression = '/integration-secrets/dev/dtc/android/regression/';

jest.mock('@aws-sdk/client-ssm', () => ({
  SSMClient: function SSMClient() {
    return {
      send: () => {
        const names = JSON.parse(process.env.Parameters).map((Name) => ({
          Name,
        }));

        return { Parameters: names };
      },
    };
  },
  DescribeParametersCommand: function DescribeParametersCommand() {
    return () => {};
  },
}));

describe('tasks/utils/aws', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
  });

  describe('setEnvVars', () => {});

  describe('fetchSSMRegions', () => {
    beforeEach(() => {
      process.env.Parameters = JSON.stringify([pathGB, pathUS]);
    });

    test('returns empty array if no matching SSM params', async () => {
      process.env.Parameters = JSON.stringify([]);

      const result = await fetchSSMRegions(
        'dev',
        'dtc',
        'android',
        'regression',
      );

      expect(result).toEqual([]);
    });

    test('returns empty array if no matching SSM params have region', async () => {
      process.env.Parameters = JSON.stringify([pathRegression]);

      const result = await fetchSSMRegions(
        'dev',
        'dtc',
        'android',
        'regression',
      );

      expect(result).toEqual([]);
    });

    test('returns an array of matching regions', async () => {
      process.env.Parameters = JSON.stringify([pathGB, pathUS]);

      const result = await fetchSSMRegions(
        'dev',
        'dtc',
        'android',
        'gqa_core_test',
      );

      expect(result).toEqual(['gb', 'us']);
    });
  });
});
