// Copyright text placeholder, Warner Bros. Discovery, Inc.

/* eslint-disable import/first,import/order,no-undef,no-unused-vars */

import testFailureData from '../test_resources/jira/testFailureData.json';

let mockBugExists = false;
const mockJiraCreateIssueAPI = jest.fn().mockImplementation((params) => {
  const { customizePayloadFunc } = params;

  // call the callback passed from the config
  customizePayloadFunc({
    description: {
      type: 'doc',
      version: 1,
      content: [
        {
          type: 'bulletList',
          content: [],
        },
      ],
    },
    summary: 'a test summary',
    versions: { name: 'versions' },

    /* eslint-disable @typescript-eslint/naming-convention */
    customfield_10141: { value: 'versions' },
    customfield_10137: { value: 'versions' },

    customfield_10146: [{ value: 'versions' }],
    customfield_10112: [{ value: 'versions' }],
    customfield_10111: [{ value: 'versions' }],
    /* eslint-enable @typescript-eslint/naming-convention */
  });

  return { key: 'createIssueKey', url: 'createIssueKeyUrl' };
});

const mockJiraSearchIssueAPI = jest.fn().mockImplementation(() =>
  mockBugExists
    ? [
        { key: 'searchIssueKey1', url: 'searchIssueKey1Url' },
        { key: 'searchIssueKey2', url: 'searchIssueKey2Url' },
      ]
    : [],
);

const mockJiraCommentIssueAPI = jest.fn().mockResolvedValue({});

const mockJiraUpdateIssueAPI = jest.fn().mockReturnValue({});

const mockJiraObj1 = { ...testFailureData, bugId: 'aaa' };
const mockJiraObj2 = { ...testFailureData, bugId: 'bbb' };
const bugJsonFiles = ['a.json', 'b.json'];

// eslint-disable-next-line @rushstack/hoist-jest-mock
jest.mock('fs-extra', () => {
  const original = jest.requireActual('fs-extra');

  return {
    ...original,
    stat: jest.fn((...args) => {
      if (args && args[0].includes('results/jira')) {
        if (args[0].includes('.json')) {
          return {
            isFile: () => true,
          };
        }
        return {
          isDirectory: () => true,
        };
      }
      return original.stat(...args);
    }),
    readFile: jest.fn((...args) => {
      if (args) {
        if (args && args[0].includes('results/jira')) {
          if (args[0].includes('a.json')) {
            return JSON.stringify(mockJiraObj1);
          }
          return JSON.stringify(mockJiraObj2);
        }
      }

      return original.readFile(...args);
    }),
    readdir: jest.fn((...args) => {
      if (args && args[0].includes('results/jira')) {
        return bugJsonFiles;
      }

      return original.readdir(...args);
    }),
  };
});

// eslint-disable-next-line @rushstack/hoist-jest-mock
jest.mock('../../lib/jira/jiraAPI', () => {
  /* eslint-disable @typescript-eslint/typedef */
  class AJiraClass {
    public commentIssue = mockJiraCommentIssueAPI;

    public searchIssue = mockJiraSearchIssueAPI;

    public createIssue = mockJiraCreateIssueAPI;

    public updateIssue = mockJiraUpdateIssueAPI;
  }
  /* eslint-enable @typescript-eslint/typedef */

  return { JiraAPI: AJiraClass };
});

import { join } from 'path';
import * as core from '@actions/core';

// Jake injects it's definition into the global namespace
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import * as jake from 'jake';

import { createJiraTask } from '../../tasks';

const { runJakeTask } = require('../testUtils');

// stub out the GitHub Action library calls
jest.spyOn(core.summary, 'addHeading').mockReturnValue(core.summary);
jest.spyOn(core.summary, 'addTable').mockReturnValue(core.summary);
jest.spyOn(core.summary, 'addBreak').mockReturnValue(core.summary);
jest.spyOn(core.summary, 'addList').mockReturnValue(core.summary);
jest.spyOn(core.summary, 'write').mockResolvedValue(core.summary);

const taskName = 'utils:autoJiraBug';

describe('tasks/jiraTask.js', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockBugExists = false;
    process.env.JIRA_AUTO_BUG_FILING = '1';
    process.env.JIRA_USERNAME = 'aaa';
    process.env.JIRA_PASSWORD = 'bbb';

    // sim that we are running in GHA env
    process.env.CI = 'yes';
    process.env.GITHUB_ACTION = 'yes';
    process.env.RUNNER_TEMP = 'yes';
  });

  test('jira task is created but failed: JIRA_AUTO_BUG_FILING is not set', async () => {
    delete process.env.JIRA_AUTO_BUG_FILING;
    createJiraTask(
      join('tests', 'test_resources', 'jira', 'jiraTestConfig.js'),
    );
    expect(task(taskName)).toBeDefined();
    await expect(runJakeTask(task(taskName))).resolves.not.toThrow();
  });

  test('jira task is created but failed: config file not specified', async () => {
    createJiraTask();
    expect(task(taskName)).toBeDefined();
    await expect(runJakeTask(task(taskName))).rejects.toThrowError(
      'Error: Jira config file is NOT specified!',
    );
  });

  test('jira task is created but failed: config file does not exist', async () => {
    createJiraTask(join('test', 'test_resources', 'notExist.js'));
    expect(task(taskName)).toBeDefined();
    await expect(runJakeTask(task(taskName))).rejects.toMatchObject({
      message: expect.stringMatching(
        // eslint-disable-next-line prefer-regex-literals
        new RegExp('Error: the Jira config file does not exists: (.+)\\.js$'),
      ),
    });
  });

  test('jira task is created but failed: username and password is not provided', async () => {
    createJiraTask(
      join('tests', 'test_resources', 'jira', 'jiraTestBadConfig.js'),
    );
    expect(task(taskName)).toBeDefined();
    await expect(runJakeTask(task(taskName))).rejects.toMatchObject({
      message: expect.stringMatching(
        'Please retry with username and password set for JIRA connection!',
      ),
    });
  });

  test('jira task is created and executed successfully: new bug is created', async () => {
    createJiraTask(
      join('tests', 'test_resources', 'jira', 'jiraTestConfig.js'),
    );
    expect(task(taskName)).toBeDefined();
    await expect(runJakeTask(task(taskName))).resolves.not.toThrow();
    expect(mockJiraSearchIssueAPI).toHaveBeenCalledTimes(2);
    expect(mockJiraCreateIssueAPI).toHaveBeenCalledTimes(2);
    expect(mockJiraUpdateIssueAPI).toHaveBeenCalledTimes(2);
    expect(mockJiraCommentIssueAPI).toHaveBeenCalledTimes(0);

    [{ bugId: 'aaa' }, { bugId: 'bbb' }].forEach(({ bugId }, idx) => {
      expect(mockJiraSearchIssueAPI.mock.calls[idx]).toEqual([
        {
          excludedStatus: ['DONE', 'CANCELLED'],
          hash: bugId,
        },
      ]);

      expect(mockJiraCreateIssueAPI.mock.calls[idx]).toEqual([
        {
          epic: 'GQA-XXX',
          priority: 'P0',
          description: expect.any(Object),
          summary: expect.any(String),
          customizePayloadFunc: expect.any(Function),
        },
      ]);

      expect(mockJiraUpdateIssueAPI.mock.calls[idx]).toEqual([
        'createIssueKey',
        {
          // eslint-disable-next-line @typescript-eslint/naming-convention
          customfield_10202: bugId,
        },
      ]);
    });
  });

  test('jira task is created and executed successfully: existing bug is commented', async () => {
    mockBugExists = true;
    createJiraTask(
      join('tests', 'test_resources', 'jira', 'jiraTestConfig.js'),
    );
    expect(task(taskName)).toBeDefined();
    await expect(runJakeTask(task(taskName))).resolves.not.toThrow();
    expect(mockJiraSearchIssueAPI).toHaveBeenCalledTimes(2);
    expect(mockJiraCommentIssueAPI).toHaveBeenCalledTimes(2);
    expect(mockJiraCreateIssueAPI).toHaveBeenCalledTimes(0);
    expect(mockJiraUpdateIssueAPI).toHaveBeenCalledTimes(0);

    [{ bugId: 'aaa' }, { bugId: 'bbb' }].forEach(({ bugId }, idx) => {
      expect(mockJiraSearchIssueAPI.mock.calls[idx]).toEqual([
        {
          excludedStatus: ['DONE', 'CANCELLED'],
          hash: bugId,
        },
      ]);

      expect(mockJiraCommentIssueAPI.mock.calls[idx]).toEqual([
        'searchIssueKey1',
        expect.any(Object),
      ]);
    });
  });
});
