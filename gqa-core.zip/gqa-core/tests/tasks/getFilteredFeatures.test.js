const FULL_PATH_TO_PROJECTS_DIRECTORY = 'full_path_to_projects_directory';

const mockExistsSync = jest.fn();

jest.mock('fs', () => ({
  existsSync: mockExistsSync,
}));

jest.mock('../../support/paths', () => ({
  paths: {
    projects: FULL_PATH_TO_PROJECTS_DIRECTORY,
  },
}));

const { join } = require('path');
const { getFilteredFeatures } = require('../../tasks/getFilteredFeatures');

describe('tasks/getFilteredFeatures', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("if we pass in an empty array, we attach a * to the project's features path", () => {
    // setup
    const expectedResult = join(
      FULL_PATH_TO_PROJECTS_DIRECTORY,
      'testProject',
      'features',
      '*',
    );

    // execute
    const result = getFilteredFeatures(
      FULL_PATH_TO_PROJECTS_DIRECTORY,
      'testProject',
      [],
    );

    // verify
    expect(result).toBe(expectedResult);
  });

  test('an error is thrown if the feature file cannot be found', () => {
    // setup
    mockExistsSync.mockReturnValue(false);

    // execute and verify
    expect(() =>
      getFilteredFeatures('path-to-feature-file', 'doesntExist', [
        'bob.feature',
      ]),
    ).toThrowError('bob.feature file does not exist');
  });

  test('an error is thrown if one of the feature files cannot be found', () => {
    // setup
    mockExistsSync.mockReturnValueOnce(true).mockReturnValue(false);

    // execute and verify
    expect(() =>
      getFilteredFeatures(FULL_PATH_TO_PROJECTS_DIRECTORY, 'doesntExist', [
        'bob.feature',
        'sam.feature',
      ]),
    ).toThrowError('sam.feature file does not exist');
  });

  test('if we pass in a single feature file array we get a path back for that one feature file', () => {
    // setup
    mockExistsSync.mockReturnValue(true);

    const expectedResult = join(
      FULL_PATH_TO_PROJECTS_DIRECTORY,
      'testProject',
      'features',
      'sam.feature',
    );

    // execute
    const result = getFilteredFeatures(
      FULL_PATH_TO_PROJECTS_DIRECTORY,
      'testProject',
      ['sam.feature'],
    );

    // verify
    expect(result).toBe(expectedResult);
  });

  test('if we pass in an array with multiple feature files we get back a single string consisting of a path to each of those files separated by a single space', () => {
    // setup
    mockExistsSync.mockReturnValue(true);

    const firstPath = join(
      FULL_PATH_TO_PROJECTS_DIRECTORY,
      'testProject',
      'features',
      'merry.feature',
    );
    const secondPath = join(
      FULL_PATH_TO_PROJECTS_DIRECTORY,
      'testProject',
      'features',
      'pippin.feature',
    );
    const expectedResult = `${firstPath} ${secondPath}`;

    // execute
    const result = getFilteredFeatures(
      FULL_PATH_TO_PROJECTS_DIRECTORY,
      'testProject',
      ['merry.feature', 'pippin.feature'],
    );

    // verify
    expect(result).toBe(expectedResult);
  });
});
