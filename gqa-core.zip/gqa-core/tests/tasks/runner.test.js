// spy on jake module, allowing us to check call count
jest.mock('jake', () => {
  const original = jest.requireActual('jake');

  return {
    ...original,
    desc: jest.fn((...args) => original.desc(...args)),
    task: jest.fn((...args) => original.task(...args)),
  };
});

// mock fs module, allowing us to fake existsSync and readdirSync such that this
// file structure exists during tests:
// ── projects
// │   ├── ATVE
// │   |  ├── android
// │   |  └── roku
// │   ├── DTC
// │   |  ├── android
// │   |  └── roku
//
jest.mock('fs', () => {
  const original = jest.requireActual('fs');

  // eslint-disable-next-line global-require
  const { join } = require('path');
  const projectPath = join(process.cwd(), 'projects');
  const cucumberJsonFile = './results/json_report.json';

  return {
    ...original,
    existsSync: jest.fn((...args) => {
      if (args) {
        const filePath = args[0];

        if (filePath === projectPath) {
          return true;
        }
        // let just mock that we don't have a Cucumber JSON file
        // such that we won't trigger the Report Portal file upload / zip logic
        if (filePath === cucumberJsonFile) {
          return false;
        }
      }

      return original.existsSync(...args);
    }),
    readdirSync: jest.fn((...args) => {
      if (args && args[0].includes(projectPath)) {
        if (args.length > 1 && args[1].withFileTypes) {
          return [
            {
              name: 'ATVE',
              isDirectory: () => true,
            },
            {
              name: 'DTC',
              isDirectory: () => true,
            },
          ];
        }
        return ['android', 'roku', 'web', 'comcast'];
      }
      return original.readdirSync(...args);
    }),
  };
});

// stub the runCucumber to no-op from cucumber API coz we don't want to
// actually run any BDD tests as part of this unit test
jest.mock('@cucumber/cucumber/api', () => {
  const original = jest.requireActual('@cucumber/cucumber/api');

  return {
    ...original,
    loadConfiguration: jest.fn((...args) =>
      original.loadConfiguration(...args),
    ),
    runCucumber: jest.fn(() => ({ success: true })),
  };
});

const mockRunTestsWithStbtAsync = jest.fn();

jest.mock('../../lib/runTestsWithStbtAsync', () => ({
  runTestsWithStbtAsync: mockRunTestsWithStbtAsync,
}));

const { join } = require('path');
const jake = require('jake');

// eslint-disable-next-line import/no-unresolved, node/no-missing-require
const cucumber = require('@cucumber/cucumber/api');
const createTasks = require('../../tasks/runner');
const { runJakeTask } = require('../testUtils');

describe('tasks/runner.js', () => {
  beforeEach(() => {
    cucumber.loadConfiguration.mockClear();
    cucumber.runCucumber.mockClear();
    jake.desc.mockClear();
    jake.task.mockClear();
  });

  test('proper Jake-js tasks are created for all projects and clients, targeting their expected test platforms', async () => {
    createTasks();

    // we should have created 8 Jake.js tasks per our "fake" projects directory
    expect(jake.desc).toBeCalledTimes(8);
    expect(jake.task).toBeCalledTimes(8);

    // these tasks should have been defined
    const nonStbtTestConfigs = [
      {
        taskName: 'ATVE:android',
        platformName: 'appium',
        projectName: 'ATVE',
      },
      {
        taskName: 'ATVE:roku',
        platformName: 'suitest',
        projectName: 'ATVE',
      },
      {
        taskName: 'ATVE:web',
        platformName: 'webdriver',
        projectName: 'ATVE',
      },
      {
        taskName: 'DTC:android',
        platformName: 'appium',
        projectName: 'DTC',
      },
      {
        taskName: 'DTC:roku',
        platformName: 'suitest',
        projectName: 'DTC',
      },
      {
        taskName: 'DTC:web',
        platformName: 'webdriver',
        projectName: 'DTC',
      },
    ];

    const stbtTestConfigs = [
      {
        taskName: 'ATVE:comcast',
        platformName: 'stbt',
        projectName: 'ATVE',
      },
      {
        taskName: 'DTC:comcast',
        platformName: 'stbt',
        projectName: 'DTC',
      },
    ];

    // eslint-disable-next-line no-restricted-syntax
    for (const { taskName, platformName, projectName } of nonStbtTestConfigs) {
      cucumber.runCucumber.mockClear();
      expect(jake.Task[taskName]).toBeDefined();

      await expect(runJakeTask(jake.Task[taskName])).resolves.not.toThrow();

      // verify expected platform name
      expect(process.env.PLATFORM).toBe(platformName);

      expect(cucumber.loadConfiguration).toBeCalledWith({
        file: undefined,
        profiles: ['default'],
        provided: {
          file: undefined,
          parallel: expect.any(Number),
          format: ['@cucumber/pretty-formatter'],
          paths: [
            join(process.cwd(), 'projects', projectName, 'features', '*'),
          ],
          profiles: ['default'],
          require: [join(process.cwd(), 'lib', 'injectedHooks.ts')],
        },
      });
      expect(cucumber.runCucumber).toBeCalledTimes(1);
    }

    // eslint-disable-next-line no-restricted-syntax
    for (const { taskName, platformName, projectName } of stbtTestConfigs) {
      expect(jake.Task[taskName]).toBeDefined();

      mockRunTestsWithStbtAsync.mockClear();
      mockRunTestsWithStbtAsync.mockImplementationOnce(() => true);

      await expect(runJakeTask(jake.Task[taskName])).resolves.not.toThrow();

      // verify expected platform name
      expect(process.env.PLATFORM).toBe(platformName);

      expect(mockRunTestsWithStbtAsync).toBeCalledTimes(1);
      expect(mockRunTestsWithStbtAsync).toBeCalledWith({
        file: undefined,
        parallel: expect.any(Number),
        format: ['@cucumber/pretty-formatter'],
        paths: [
          join(
            process.cwd(),
            'tests',
            'projects',
            projectName,
            'features',
            '*',
          ),
        ],
        profiles: ['default'],
      });
    }
  });

  test('runner tasks are created with a specific single cucumber profile', async () => {
    createTasks({
      cucumberProfiles: 'aProfile',
    });

    await expect(runJakeTask(jake.Task['ATVE:android'])).resolves.not.toThrow();

    expect(cucumber.loadConfiguration).toBeCalledWith({
      file: undefined,
      profiles: ['aProfile'],
      provided: {
        file: undefined,
        parallel: expect.any(Number),
        format: ['@cucumber/pretty-formatter'],
        paths: [join(process.cwd(), 'projects', 'ATVE', 'features', '*')],
        profiles: ['aProfile'],
        require: [join(process.cwd(), 'lib', 'injectedHooks.ts')],
      },
    });
  });

  test('runner tasks are created with multiple cucumber profiles', async () => {
    createTasks({
      cucumberProfiles: ['profileA', 'profileB'],
    });

    await expect(runJakeTask(jake.Task['ATVE:android'])).resolves.not.toThrow();

    expect(cucumber.loadConfiguration).toBeCalledWith({
      file: undefined,
      profiles: ['profileA', 'profileB'],
      provided: {
        file: undefined,
        parallel: expect.any(Number),
        format: ['@cucumber/pretty-formatter'],
        paths: [join(process.cwd(), 'projects', 'ATVE', 'features', '*')],
        profiles: ['profileA', 'profileB'],
        require: [join(process.cwd(), 'lib', 'injectedHooks.ts')],
      },
    });
  });
});
