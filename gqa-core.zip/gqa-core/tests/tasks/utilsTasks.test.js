// spy on jake module, allowing us to check call count
jest.mock('jake', () => {
  const original = jest.requireActual('jake');

  return {
    ...original,
    desc: jest.fn((...args) => original.desc(...args)),
    task: jest.fn((...args) => original.task(...args)),
  };
});

const mockTestData = {
  'utils:clean_logs': [
    {
      name: 'remoteDevicess',
      isDirectory: () => true,
      match: () => true,
    },
    {
      name: '.devices',
      isDirectory: () => true,
      match: () => false,
    },
    {
      name: 'exampleFolder',
      isDirectory: () => true,
      match: () => true,
    },
    {
      name: '.log',
      isDirectory: () => false,
      match: () => false,
    },
    {
      name: 'exampleFile',
      isDirectory: () => false,
      match: () => true,
    },
  ],
  'utils:clean_builds': [
    {
      name: 'remoteDevices',
      isDirectory: () => false,
      match: () => true,
    },
    {
      name: '.devices',
      isDirectory: () => false,
      match: () => false,
    },
    {
      name: 'exampleFile',
      isDirectory: () => false,
      match: () => true,
    },
  ],
};

jest.mock('fs', () => {
  const original = jest.requireActual('fs');
  const folderPath = 'logs';
  const task = 'utils:clean_logs';

  // eslint-disable-next-line global-require
  const { join } = require('path');
  const dir = join(process.cwd(), folderPath);

  const folderNames = mockTestData[task].map((mockFile) => mockFile.name);

  return {
    ...original,
    existsSync: jest.fn((...args) => {
      if (args && args[0] === dir) {
        return true;
      }
      return original.existsSync(...args);
    }),
    readdirSync: jest.fn((...args) => {
      if (args && args[0].includes(dir)) {
        return folderNames;
      }
      return original.readdirSync(...args);
    }),

    rmSync: jest.fn(() => true),
    unlinkSync: jest.fn(() => true),
    statSync: jest.fn((...args) => {
      if (args && args[0].includes(dir)) {
        const result = mockTestData[task].filter((mockFile) =>
          args[0].includes(mockFile.name),
        );

        // we should at least match 1
        return result[0];
      }
      return original.statSync(...args);
    }),
    writeFileSync: jest.fn(() => true),
  };
});

jest.mock('../../tasks/utils/aws', () => ({
  ...jest.requireActual('../../tasks/utils/aws'),
  setEnvVars: jest.fn(() => true),
  fetchSSMRegions: jest.fn().mockResolvedValue(['gb', 'us']),
}));

const jake = require('jake');
const fs = require('fs');
const aws = require('../../tasks/utils/aws');

const createTask = require('../../tasks/utilsTasks');
const { runJakeTask } = require('../testUtils');

describe('tasks/utilsTasks.js', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jake.desc.mockClear();
    jake.task.mockClear();
  });

  test('clean logs', async () => {
    const taskName = 'utils:clean_logs';

    createTask();
    expect(jake.Task[taskName]).toBeDefined();
    // we should have created 4 Jake.js tasks
    expect(jake.desc).toBeCalledTimes(4);
    expect(jake.task).toBeCalledTimes(4);

    await expect(runJakeTask(jake.Task[taskName])).resolves.not.toThrow();
    expect(fs.rmSync).toBeCalledTimes(2);
    expect(fs.unlinkSync).toBeCalledTimes(1);
  });

  test('clean builds', async () => {
    const taskName = 'utils:clean_builds';

    createTask();
    const folderNames = mockTestData[taskName].map((mockFile) => mockFile.name);

    fs.existsSync.mockReturnValueOnce(true);
    fs.readdirSync.mockReturnValueOnce(folderNames);

    expect(jake.Task[taskName]).toBeDefined();
    // we should have created 4 Jake.js tasks
    expect(jake.desc).toBeCalledTimes(4);
    expect(jake.task).toBeCalledTimes(4);
    await expect(runJakeTask(jake.Task[taskName])).resolves.not.toThrow();
    expect(fs.unlinkSync).toBeCalledTimes(2);
  });

  test('setEnvVars task should call setEnvVars method', async () => {
    const taskName = 'utils:setEnvVars';

    createTask();
    expect(jake.desc).toBeCalledTimes(4);
    expect(jake.task).toBeCalledTimes(4);
    await expect(runJakeTask(jake.Task[taskName])).resolves.not.toThrow();
    expect(aws.setEnvVars).toBeCalledTimes(1);
  });

  test('fetchSSMRegions task should call fetchSSMRegions method', async () => {
    const taskName = 'utils:fetchSSMRegions';

    createTask();
    expect(jake.desc).toBeCalledTimes(4);
    expect(jake.task).toBeCalledTimes(4);
    await expect(runJakeTask(jake.Task[taskName])).resolves.not.toThrow();
    await expect(fs.writeFileSync).toBeCalledTimes(1);
  });
});
