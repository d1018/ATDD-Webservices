const { Devices } = require('../../support/remoteDevices');
const { logger } = require('../../support/logger');

beforeEach(() => {
  Devices.devicesList = [];
  process.env.DEVICE = 'roku';
  process.env.GEO = 'us';
});

describe('getDevicesList()', () => {
  test('returns a list of devices when setting proper env values', () => {
    expect(Array.isArray(Devices.getDevicesList())).toBeTruthy();
    expect(Devices.getDevicesList().length).toBeGreaterThan(0);
  });

  test('throws error if the variables are not configured properly', () => {
    process.env.DEVICE = 'device';
    expect(() => {
      Devices.getDevicesList();
    }).toThrowError();
  });

  test('calculate getDevicesList execution time', () => {
    const fillTimeStart = process.hrtime();

    Devices.getDevicesList();
    const fillTimeEnd = process.hrtime(fillTimeStart);

    const retrieveFilledArrayTimeStart = process.hrtime();

    Devices.getDevicesList();
    const retrieveFilledArrayTimeEnd = process.hrtime(
      retrieveFilledArrayTimeStart,
    );

    logger.log(
      `Time to fill the devices array: ${
        fillTimeEnd[0] * 1000 + fillTimeEnd[1] / 1000000
      } ms`,
    );
    logger.log(
      `Time to retrieve filled devices array: ${
        retrieveFilledArrayTimeEnd[0] * 1000 +
        retrieveFilledArrayTimeEnd[1] / 1000000
      } ms`,
    );
    expect(Devices.getDevicesList().length).toBeGreaterThan(0);
  });
});

describe('getDeviceByProperty()', () => {
  test('returns Device object when right variables are set properly', () => {
    const properties = ['suitestId', 'name', 'headspinId', 'cameraId'];
    const values = [
      'fcbc5b43-30a9-4904-b200-cdc4c44ba181',
      'HS-US_Roku_US_1',
      'X01000GNGE6T',
      'R5CN105DQ8A',
    ];

    properties.forEach((property, index) => {
      const device = Devices.getDeviceByProperty(property, values[index]);

      expect(device.getSuitestId()).toBe(values[0]);
      expect(device.getName()).toBe(values[1]);
      expect(device.getHeadspinId()).toBe(values[2]);
      expect(device.getCameraId()).toBe(values[3]);
    });
  });

  test('returns undefined when no devices are available', () => {
    const property = 'name';
    const value = 'No_available_device';

    expect(Devices.getDeviceByProperty(property, value)).toBeUndefined();
  });

  test('returns undefined when wrong properties', () => {
    const property = 'no_valid_property';
    const value = 'HS-US_Roku_GB_2';

    expect(Devices.getDeviceByProperty(property, value)).toBeUndefined();
  });
});
