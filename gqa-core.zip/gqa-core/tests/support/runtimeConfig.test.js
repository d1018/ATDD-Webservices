const config = require('../../support/runtimeConfig');

describe('support/runtimeConfig', () => {
  const name = 'ABC';

  beforeEach(() => {
    delete process.env[name];
  });

  [
    ['123', 123],
    ['0', 0],
    ['-0', -0],
    ['-123', -123],
    [' 100 ', 100],
    [' -200 ', -200],
  ].forEach(([val1, val2]) => {
    test(`readIntFromEnv returns value for parsable string: (${val1})`, () => {
      expect(config.readIntFromEnv(val1, 4)).toBe(val2);
    });
  });

  ['$23445', '!123', 'anything', '', undefined].forEach((val) => {
    test(`readIntFromEnv returns value for non-parsable string: (${val})`, () => {
      expect(config.readIntFromEnv(val, 23)).toBe(23);
    });
  });

  ['true', ' true ', 'TRUE', 'TRUe', 'tRUe', '1', ' 1 '].forEach((val) => {
    test(`isFeatureFlagEnabled returns true for "${val}"`, () => {
      process.env[name] = val;
      expect(config.isFeatureFlagEnabled(name)).toEqual(true);
    });
  });

  [undefined, 'false', 'FALSE', '0'].forEach((val) => {
    test(`isFeatureFlagEnabled returns false for ${val}`, () => {
      process.env[name] = val;
      expect(config.isFeatureFlagEnabled(name)).toEqual(false);
    });
  });

  [
    // case of direct echo'ing for values from process.env.XXXX
    {
      func: 'runtimeDevice',
      varName: 'DEVICE',
      input: 'android',
      output: 'android',
    },
    {
      func: 'runtimeDeviceModel',
      varName: 'MODEL',
      input: 'Awesome',
      output: 'Awesome',
    },
    {
      func: 'runtimeProject',
      varName: 'PROJECT',
      input: 'DTC',
      output: 'DTC',
    },
    {
      func: 'runtimePlatform',
      varName: 'PLATFORM',
      input: 'web',
      output: 'web',
    },
    {
      func: 'runtimeGeolocation',
      varName: 'GEO',
      input: 'uk',
      output: 'uk',
    },
    // case of throwing when necessary process.env.XXXX is not set
    {
      func: 'runtimeDevice',
      varName: 'DEVICE',
      input: undefined,
      output: Error('exception'),
    },

    // case of returning default value if process.env.XXXX is not set
    {
      func: 'runtimeGeolocation',
      varName: 'GEO',
      input: undefined,
      output: 'us',
    },
  ].forEach(({ func, varName, input, output }) => {
    test(`${func}: ${input} --> ${output}`, () => {
      delete process.env[varName];

      if (input !== undefined) {
        process.env[varName] = input;
      }

      if (output.constructor !== Error) {
        // eslint-disable-next-line jest/no-conditional-expect
        expect(config[func]()).toEqual(output);
      } else {
        // eslint-disable-next-line jest/no-conditional-expect
        expect(config[func]).toThrow();
      }
    });
  });
});
