// Copyright text placeholder, Warner Bros. Discovery, Inc.

import {
  isError,
  isObject,
  hasProperty,
  partitionByType,
  partition,
} from '../../support/TypeUtils';

describe('support/ts', () => {
  describe('hasProperty', () => {
    it('returns true if and only if the object has a property of the given name', () => {
      const obj: object = { frodo: 'bilbo' };

      expect(hasProperty(obj, 'frodo')).toBe(true);
      expect(hasProperty(obj, 'bilbo')).toBe(false);
    });

    it('asserts that the object is of a type that has the stated property', () => {
      const obj: object = { frodo: 'bilbo' };

      // @ts-expect-error accessing obj.frodo is not permitted
      if (obj.frodo === 'gandalf') {
        // @ts-expect-error accessing obj.frodo is not permitted
        obj.frodo = 7;
      }

      if (!hasProperty(obj, 'frodo')) {
        // @ts-expect-error accessing obj.frodo is not permitted
        obj.frodo = 7;
        throw new Error(
          'hasProperty() returned false when the object had the property',
        );
      }

      // obj is known to have the property 'frodo'
      expect(obj.frodo).toBe('bilbo');
    });

    it('narrows the type of an object of arbitrary type to an object of that same type that also has the stated property', () => {
      const obj: object = { frodo: 'bilbo', wizard: 'gandalf' };

      // @ts-expect-error Not okay to access obj.frodo here.
      expect(obj.frodo).toBe('bilbo');

      // @ts-expect-error Not okay to access obj.wizard here.
      expect(obj.wizard).toBe('gandalf');

      if (!hasProperty(obj, 'frodo')) {
        throw new Error(
          'hasProperty() returned false when the object had the property',
        );
      }

      // Okay to access obj.frodo here.
      expect(obj.frodo).toBe('bilbo');

      // @ts-expect-error Still not okay to access obj.wizard here.
      expect(obj.wizard).toBe('gandalf');

      if (hasProperty(obj, 'wizard')) {
        obj.frodo = 'hello';
        obj.wizard = 'world';
        return;
      }

      // @ts-expect-error Not okay to access obj.wizard here
      expect(obj.wizard).toBe('gandalf');
    });
  });

  describe('isObject', () => {
    [
      { description: 'undefined', input: undefined, expected: false },
      { description: 'null', input: null, expected: false },
      { description: 'an empty object', input: {}, expected: true },
      { description: 'an object w/ props', input: { foo: 3 }, expected: true },
      { description: 'an empty array', input: [], expected: true },
      { description: 'an array', input: [3, 4, 5], expected: true },
      { description: 'a number', input: 37, expected: false },
      { description: 'a string', input: 'frodo', expected: false },
      { description: 'a boolean', input: true, expected: false },
      { description: 'a function', input: () => 'a', expected: false },
    ].forEach(({ description, input, expected }) => {
      it(`returns ${expected} if the input is ${description}`, () => {
        expect(isObject(input)).toBe(expected);
      });
    });
  });

  describe('isError', () => {
    [
      { description: 'undefined', input: undefined, expected: false },
      { description: 'null', input: null, expected: false },
      { description: 'an empty object', input: {}, expected: false },
      { description: 'an object w/ props', input: { foo: 3 }, expected: false },
      { description: 'an empty array', input: [], expected: false },
      { description: 'an array', input: [3, 4, 5], expected: false },
      { description: 'a number', input: 37, expected: false },
      { description: 'a string', input: 'frodo', expected: false },
      { description: 'a boolean', input: true, expected: false },
      { description: 'a function', input: () => 'a', expected: false },
      {
        description: 'an Error w/o message',
        input: new Error(),
        expected: true,
      },
      {
        description: 'an Error w/ message',
        input: new Error('This error has a message'),
        expected: true,
      },
      {
        description: 'error-like but empty',
        input: { message: '', stack: '' },
        expected: false,
      },
      {
        description: 'error-like with values',
        input: { message: 'whoops!', stack: 'got here\nfrom here' },
        expected: true,
      },
    ].forEach(({ description, input, expected }) => {
      it(`returns ${expected} if the input is ${description}`, () => {
        expect(isError(input)).toBe(expected);
      });
    });
  });

  describe('partition', () => {
    it('divides a list according to a partition function', () => {
      const numbers: number[] = [1, 2, 3, 4, 5, 6, 7];
      const [odds, evens] = partition(numbers, (number) => number % 2 !== 0);

      expect(odds).toStrictEqual([1, 3, 5, 7]);
      expect(evens).toStrictEqual([2, 4, 6]);
    });

    it('divides an empty list into two empty lists', () => {
      const empty: unknown[] = [];
      const [first, second] = partition(empty, (value) => Boolean(value));

      expect(first).toStrictEqual([]);
      expect(second).toStrictEqual([]);
    });

    it('returns empty lists when none match', () => {
      const values: number[] = [1, 2, 3];
      const [first, second] = partition(values, () => true);

      expect(first).toStrictEqual(values);
      expect(second).toStrictEqual([]);

      const [none, some] = partition(values, () => false);

      expect(none).toStrictEqual([]);
      expect(some).toStrictEqual(values);
    });
  });

  describe('partitionByType', () => {
    it('divides a list by type according to a partition function', () => {
      const values: (string | number)[] = [1, 'a', 2, 'b', 3, 'c'];
      const [strings, numbers] = partitionByType(
        values,
        (value): value is string => typeof value === 'string',
      );
      const asStrings: string[] = strings;
      const asNumbers: number[] = numbers;

      expect(asStrings).toStrictEqual(['a', 'b', 'c']);
      expect(asNumbers).toStrictEqual([1, 2, 3]);
    });

    it('divides an empty list into two empty lists', () => {
      const empty: (string | number)[] = [];
      const [strings, numbers] = partitionByType(
        empty,
        (value): value is string => typeof value === 'string',
      );

      const asStrings: string[] = strings;
      const asNumbers: number[] = numbers;

      expect(asStrings).toStrictEqual([]);
      expect(asNumbers).toStrictEqual([]);
    });

    it('returns empty lists when none match', () => {
      const allStrings: (string | number)[] = ['a', 'b', 'c'];
      const [someStrings, noNumbers] = partitionByType(
        allStrings,
        (value): value is string => typeof value === 'string',
      );

      const someStringsAsStrings: string[] = someStrings;
      const noNumbersAsNumbers: number[] = noNumbers;

      expect(someStringsAsStrings).toStrictEqual(['a', 'b', 'c']);
      expect(noNumbersAsNumbers).toStrictEqual([]);

      const allNumbers: (string | number)[] = [1, 2, 3];
      const [noStrings, someNumbers] = partitionByType(
        allNumbers,
        (value): value is string => typeof value === 'string',
      );

      const noStringsAsStrings: string[] = noStrings;
      const someNumbersAsNumbers: number[] = someNumbers;

      expect(noStringsAsStrings).toStrictEqual([]);
      expect(someNumbersAsNumbers).toStrictEqual([1, 2, 3]);
    });
  });
});
