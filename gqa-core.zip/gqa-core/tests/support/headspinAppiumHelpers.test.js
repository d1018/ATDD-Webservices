global.fetch = require('jest-fetch-mock');

global.fetch.enableMocks();
const mockExecSync = jest.fn();

jest.mock('child_process', () => {
  const childProcess = jest.requireActual('child_process');

  return {
    ...childProcess,
    execSync: mockExecSync,
  };
});

const {
  uploadApk,
  uploadIpa,
  deleteApk,
  deleteIpa,
  uploadedApks,
  uploadedIpas,
  uploadedApkPackageNames,
  uploadedIpaBundleIdentifiers,
  listAllAdbDevicesByModel,
  installApk,
  uninstallApk,
  installApkOnAllAndroidTvDevices,
  installApkOnAllFireTabDevices,
  installApkOnAllFireTvDevices,
  uninstallApkOnAllAndroidTvDevices,
  uninstallApkOnAllFireTabDevices,
  uninstallApkOnAllFireTvDevices,
  apkAppInfo,
  ipaAppInfo,
  installIpa,
  uninstallIpa,
  listAlliDevicesByModel,
  installIpaOnAllAppleTvDevices,
  uninstallIpaOnAllAppleTvDevices,
  uploadAppWithTag,
} = require('../../support/headspinAppiumHelpers');

describe('headspinAppiumHelpers', () => {
  const responseUploadedApks = {
    '8c2b3b1a-eee4-40f6-a04c-d96353fbb6b9': {
      hs_tag: null,
      main_activity:
        'com.discovery.plus.presentation.activities.LaunchActivity',
      app_name: 'discovery+',
      app_icon: 'res/mipmap-anydpi-v26/ic_launcher.xml',
      apk_id: '8c2b3b1a-eee4-40f6-a04c-d96353fbb6b9',
      file_size: 27370218,
      version_name: '16.7.1',
      ts_created: 1666346168.066,
      success: true,
      version: '1604874934',
      app_package: 'com.discovery.discoveryplus.mobile',
      instrs: [],
    },
    'e90482cf-5e8f-4062-b79d-157603026059': {
      hs_tag: null,
      main_activity:
        'com.discovery.plus.presentation.activities.TVSplashActivity',
      app_name: 'discovery+',
      app_icon: 'res/drawable/ic_launcher.png',
      apk_id: 'e90482cf-5e8f-4062-b79d-157603026059',
      file_size: 22723623,
      version_name: '1.15.0_ENTERPRISE',
      ts_created: 1627499944.356,
      success: true,
      version: '1604874640',
      app_package: 'com.discovery.discoveryplus.firetv.enterprise',
      instrs: [],
    },
  };

  const responseUploadedIpas = {
    'e4c703e3-c917-4f0c-8169-c4e6620e5752': {
      hs_tag: null,
      bundle_version: '3246',
      success: true,
      file_size: 45439467,
      bundle_name: 'DPlus',
      bundle_identifier: 'com.discovery.enterprise.discoplus',
      ts_created: 1673512138.137,
      bundle_short_version_string: '17.7.2',
      ipa_id: 'e4c703e3-c917-4f0c-8169-c4e6620e5752',
    },
    '3a232732-7182-4da7-899f-834fec7e4246': {
      hs_tag: null,
      bundle_version: '2667',
      success: true,
      file_size: 39496454,
      bundle_name: 'DPlus',
      bundle_identifier: 'com.discovery.mobile.enterprise.discoveryplus.apac',
      ts_created: 1656653526.871,
      bundle_short_version_string: '16.1.0',
      ipa_id: '3a232732-7182-4da7-899f-834fec7e4246',
    },
  };

  const responseUploadedApkPackages = {
    apk_packages: [
      'com.discovery.discoveryplus.firetv',
      'com.discovery.discoplus.enterprise',
      'com.discovery.discoveryplus.mobile',
      'com.discovery.dplay.enterprise',
    ],
    success: true,
  };

  const responseUploadedIpasIdentifiers = {
    success: true,
    bundle_identifiers: [
      'com.discovery.mobile.enterprise.discoveryplus.apac',
      'com.discovery.mobile.enterprise.discoveryplus',
      'com.discovery.mobile.discoveryplus',
      'com.discovery.mobile.enterprise.discovery',
    ],
  };

  const responseAppDelete = {
    status: 'OK',
    status_code: 200,
    success: true,
  };

  const errorResponseHeader = {
    status: 401,
    statusText: 'Authorization Error',
    headers: { 'content-type': 'application/json' },
  };

  const responseApkAppInfo = {
    hs_tag: null,
    main_activity:
      'com.discovery.plus.presentation.activities.TVSplashActivity',
    app_name: 'discovery+',
    app_icon: 'res/drawable-xxxhdpi-v4/ic_app_icon.png',
    apk_id: 'f0d995df-906c-443a-8d23-661dd6b99c25',
    file_size: 57255889,
    version_name: '17.6.0_ENTERPRISE',
    ts_created: 1675669560.658,
    success: true,
    version: '1604875015',
    app_package: 'com.discovery.dplay.enterprise',
    instrs: [],
  };

  const responseListAllAdbDevices = {
    'GCC19D0621220987@dev-ca-tor-2-proxy-9-lin.headspin.io': {
      status: 'device',
      product: 'onyx',
      host: 'dev-ca-tor-2-proxy-9-lin.headspin.io',
      model: 'KFONWI',
      os: 'android',
      serial: 'GCC19D0621220987',
      device_id: 'GCC19D0621220987',
    },
    '19131HFDD3TYJ8@dev-ca-tor-2-proxy-5-lin.headspin.io': {
      status: 'device',
      product: 'sabrina_prod_stable',
      host: 'dev-ca-tor-2-proxy-5-lin.headspin.io',
      model: 'Chromecast',
      os: 'android',
      serial: '19131HFDD3TYJ8',
      device_id: '19131HFDD3TYJ8',
    },
    'G070VM2420250UXS@dev-ca-tor-2-proxy-7-lin.headspin.io': {
      status: 'device',
      product: 'mantis',
      host: 'dev-ca-tor-2-proxy-7-lin.headspin.io',
      model: 'AFTMM',
      os: 'android',
      serial: 'G070VM2420250UXS',
      device_id: 'G070VM2420250UXS',
    },
  };

  const responseInstall = {
    _headspin_progress: '.',
    status: 0,
    returncode: 0,
    stdout: 'Performing Streamed Install\nSuccess\n',
    summary: 'ok',
  };

  const responeUninstallApk = {
    _headspin_progress: '.',
    status: 0,
    returncode: 0,
    stdout: 'Success\n',
    summary: 'ok',
  };

  const errorFailed = {
    _headspin_progress: '.',
    status: 0,
    returncode: 1,
    stdout: 'failed',
    summary: 'ok',
  };

  const responseIpaAppInfo = {
    hs_tag: null,
    bundle_version: '3279-gha-xcode14',
    success: true,
    file_size: 42971767,
    bundle_name: 'DPlus',
    bundle_identifier: 'com.discovery.mobile.enterprise.discoveryplus',
    ts_created: 1675673928.704,
    bundle_short_version_string: '1.0',
    ipa_id: '8887f507-afdb-4a32-9171-e613940f8e38',
  };

  const responseUnintallIpa = {
    status: 0,
    returncode: 0,
    stdout:
      "Removing application: 50%\nUninstalled '8887f507-afdb-4a32-9171-e613940f8e38'\n",
    summary: 'ok',
  };

  const responseiDeviceList = {
    '3c83bd305f19876fb81802ab16458064dbe32edc@dev-us-pao-20-proxy-7-mac.headspin.io':
      {
        status: 'device',
        serial: 'C07F65GQJ1WF',
        os: 'ios',
        host: 'dev-us-pao-20-proxy-7-mac.headspin.io',
        device_id: '3c83bd305f19876fb81802ab16458064dbe32edc',
      },
    'c47ef0f65bedde22e6f1fd0244be0f13bee7a62e@dev-ca-tor-2-proxy-0-mac.headspin.io':
      {
        status: 'device',
        serial: 'FQH4GFQXG6',
        os: 'ios',
        host: 'dev-ca-tor-2-proxy-0-mac.headspin.io',
        device_id: 'c47ef0f65bedde22e6f1fd0244be0f13bee7a62e',
      },
  };

  const responseIDeviceInfo = {
    EthernetAddress: '64:d2:c4:ba:3a:36',
    UniqueDeviceID: '3c83bd305f19876fb81802ab16458064dbe32edc',
    CPUArchitecture: 'arm64',
    ChipID: 32785,
    ModelNumber: 'MQD22',
    DeviceColor: 'unknown',
    ProductType: 'AppleTV6,2',
    TimeZone: 'America/Los_Angeles',
    BootSessionID: '6069785E-C262-4237-8296-3508C5C05AD6',
    BrickState: false,
    DeviceName: 'Home Theater',
    PairRecordProtectionClass: 4,
    TimeZoneOffsetFromUTC: -28800,
    UseRaptorCerts: true,
    Uses24HourClock: false,
    HardwarePlatform: 't8011',
    RegionInfo: 'LL/A',
    BluetoothAddress: '64:d2:c4:b3:f9:1b',
    MLBSerialNumber: 'C0710550S24J8M1GL',
    HardwareModel: 'J105aAP',
    TimeIntervalSince1970: 1675954848.153579,
    FirmwareVersion: 'iBoot-8419.60.44',
    DeviceClass: 'AppleTV',
    PasswordProtected: false,
    SerialNumber: 'C07F65GQJ1WF',
    UniqueChipID: 4016842434297902,
    TelephonyCapability: false,
    BoardId: 2,
    ProtocolVersion: '2',
    ActivationState: 'Activated',
    WiFiAddress: '64:d2:c4:ae:06:31',
    ProductVersion: '16.2',
    BasebandStatus: 'NoTelephonyCapabilty',
    ProductionSOC: true,
    ActivationStateAcknowledged: true,
    BuildVersion: '20K362',
    ProductName: 'Apple TVOS',
    SoftwareBundleVersion: '',
    SupportedDeviceFamilies: [3],
    DieID: 4016842434297902,
    PartitionType: 'GUID_partition_scheme',
    NonVolatileRAM: {
      SystemAudioVolumeSaved: 'dHJ1ZQ==',
      'ota-original-base-os-version': 'MjBLNzE=',
      'auto-boot': 'dHJ1ZQ==',
      bootdelay: 'MA==',
      'boot-args': '',
    },
  };

  const responseIDeviceInfoNext = {
    EthernetAddress: '64:d2:c4:ba:3a:36',
    UniqueDeviceID: '4c83bd305f19876fb81802ab16458064dbe32edc',
    CPUArchitecture: 'arm64',
    ChipID: 32785,
    ModelNumber: 'MQD22',
    DeviceColor: 'unknown',
    ProductType: 'AppleTV6,2',
    TimeZone: 'America/Los_Angeles',
    BootSessionID: '6069785E-C262-4237-8296-3508C5C05AD6',
    BrickState: false,
    DeviceName: 'Home Theater',
    PairRecordProtectionClass: 4,
    TimeZoneOffsetFromUTC: -28800,
    UseRaptorCerts: true,
    Uses24HourClock: false,
    HardwarePlatform: 't8011',
    RegionInfo: 'LL/A',
    BluetoothAddress: '64:d2:c4:b3:f9:1b',
    MLBSerialNumber: 'C0710550S24J8M1GL',
    HardwareModel: 'J105aAP',
    TimeIntervalSince1970: 1675954848.153579,
    FirmwareVersion: 'iBoot-8419.60.44',
    DeviceClass: 'AppleTV',
    PasswordProtected: false,
    SerialNumber: 'C07F65GQJ1WF',
    UniqueChipID: 4016842434297902,
    TelephonyCapability: false,
    BoardId: 2,
    ProtocolVersion: '2',
    ActivationState: 'Activated',
    WiFiAddress: '64:d2:c4:ae:06:31',
    ProductVersion: '16.2',
    BasebandStatus: 'NoTelephonyCapabilty',
    ProductionSOC: true,
    ActivationStateAcknowledged: true,
    BuildVersion: '20K362',
    ProductName: 'Apple TVOS',
    SoftwareBundleVersion: '',
    SupportedDeviceFamilies: [3],
    DieID: 4016842434297902,
    PartitionType: 'GUID_partition_scheme',
    NonVolatileRAM: {
      SystemAudioVolumeSaved: 'dHJ1ZQ==',
      'ota-original-base-os-version': 'MjBLNzE=',
      'auto-boot': 'dHJ1ZQ==',
      bootdelay: 'MA==',
      'boot-args': '',
    },
  };

  process.env.HS_TOKEN = 'qwertyuiopasdfghjklzxcvbnm1234567890'; // dummy

  beforeEach(async () => {
    await fetch.resetMocks();
  });

  it('Uploaded apk(s) - uploadedApks()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseUploadedApks));
    await uploadedApks();

    expect(fetch).toBeCalledTimes(1);
  });

  it('Uploaded apk(s) - uploadedApks() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(uploadedApks()).rejects.toThrow();
  });

  it('Uploaded ipa(s) - uploadedIpas()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseUploadedIpas));
    await uploadedIpas();

    expect(fetch).toBeCalledTimes(1);
  });

  it('Uploaded ipa(s) - uploadedIpas() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(uploadedIpas()).rejects.toThrow();
  });

  it('Uploaded apk package names - uploadedApkPackageNames()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseUploadedApkPackages));
    await uploadedApkPackageNames();

    expect(fetch).toBeCalledTimes(1);
  });

  it('Uploaded apk package names - uploadedApkPackageNames() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(uploadedApkPackageNames()).rejects.toThrow();
  });

  it('Uploaded ipa bundle identifiers - uploadedIpaBundleIdentifiers()', async () => {
    global.fetch.mockResponseOnce(
      JSON.stringify(responseUploadedIpasIdentifiers),
    );
    await uploadedIpaBundleIdentifiers();

    expect(fetch).toBeCalledTimes(1);
  });

  it('Uploaded ipa bundle identifiers - uploadedIpaBundleIdentifiers() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(uploadedIpaBundleIdentifiers()).rejects.toThrow();
  });

  it('Upload apk - uploadApk()', async () => {
    jest.clearAllMocks();

    const responseUpload = {
      apk_id: 'c06c24bc-7111-40d7-bb8e-ee2724780aaf',
      success: true,
    };

    mockExecSync.mockReturnValueOnce(responseUpload);
    await uploadApk('/local/directory/androidtv.apk');

    expect(mockExecSync).toHaveBeenCalledTimes(1);
  });

  it('Upload ipa - uploadIpa()', async () => {
    jest.clearAllMocks();

    const responseUpload = {
      apk_id: '37aaa809-85ec-482f-8d95-554a5ff20292',
      success: true,
    };

    mockExecSync.mockResolvedValueOnce(responseUpload);
    await uploadIpa('/local/directory/appletv.ipa');

    expect(mockExecSync).toHaveBeenCalledTimes(1);
  });

  it('Delete apk - deleteApk()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseAppDelete));
    await deleteApk('c06c24bc-7111-40d7-bb8e-ee2724780aaf');

    expect(fetch).toBeCalledTimes(1);
  });

  it('Delete apk - deleteApk() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(
      deleteApk('c06c24bc-7111-40d7-bb8e-ee2724780aaf'),
    ).rejects.toThrow();
  });

  it('Delete ipa - deleteIpa()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseAppDelete));
    await deleteIpa('37aaa809-85ec-482f-8d95-554a5ff20292');

    expect(fetch).toBeCalledTimes(1);
  });

  it('Delete ipa - deleteIpa() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(
      deleteIpa('a4f95192-f8e9-4321-a920-d4b214bc376a'),
    ).rejects.toThrow();
  });

  it("Apk's app info - apkAppInfo()", async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseApkAppInfo));
    await apkAppInfo('c06c24bc-7111-40d7-bb8e-ee2724780aaf');

    expect(fetch).toBeCalledTimes(1);
  });

  it("Apk's app info - apkAppInfo() - throws Authorization Error when HS_TOKEN is not added", async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(
      apkAppInfo('c06c24bc-7111-40d7-bb8e-ee2724780aaf'),
    ).rejects.toThrow();
  });

  it('List all ADB devices by model - listAllAdbDevicesByModel()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseListAllAdbDevices));
    await listAllAdbDevicesByModel('Chromecast');

    expect(fetch).toBeCalledTimes(1);
  });

  it('List all ADB devices by model - listAllAdbDevicesByModel() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(listAllAdbDevicesByModel('Chromecast')).rejects.toThrow();
  });

  it('Install apk on device - installApk()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseInstall));
    await installApk('G070VM2420650K5H', '80333fe-32fd-4344-9ac1-33dbcf23e2fc');

    expect(fetch).toBeCalledTimes(1);
  });

  it('Install apk on device - installApk() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(
      installApk('G070VM2420650K5H', '80333fe-32fd-4344-9ac1-33dbcf23e2fc'),
    ).rejects.toThrow();
  });

  it('Uninstall apk on device - uninstallApk()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responeUninstallApk));
    await uninstallApk('G070VM2420650K5H', 'com.discovery.dplay.enterprise');

    expect(fetch).toBeCalledTimes(1);
  });

  it('Uninstall apk on device - uninstallApk() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(
      uninstallApk('G070VM2420650K5H', 'com.discovery.dplay.enterprise'),
    ).rejects.toThrow();
  });

  it('Install apk on all Android TV device - installApkOnAllAndroidTvDevices()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseListAllAdbDevices));
    global.fetch.mockResponseOnce(JSON.stringify(responseInstall));
    await installApkOnAllAndroidTvDevices(
      '80333fe-32fd-4344-9ac1-33dbcf23e2fc',
    );

    expect(fetch).toBeCalledTimes(2);
  });

  it('Install apk on all Fire TV device - installApkOnAllFireTvDevices() - throws error for failure', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseListAllAdbDevices));
    global.fetch.mockRejectOnce(Error(JSON.stringify(errorFailed)));

    await installApkOnAllFireTvDevices('80333fe-32fd-4344-9ac1-33dbcf23e2fc');
    expect(fetch).toBeCalledTimes(2);
  });

  it('Install apk on all Android TV device - installApkOnAllAndroidTvDevices() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(
      installApkOnAllAndroidTvDevices('80333fe-32fd-4344-9ac1-33dbcf23e2fc'),
    ).rejects.toThrow();
  });

  it('Install apk on all Fire Tab device - installApkOnAllFireTabDevices()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseListAllAdbDevices));
    global.fetch.mockResponseOnce(JSON.stringify(responseInstall));
    await installApkOnAllFireTabDevices('80333fe-32fd-4344-9ac1-33dbcf23e2fc');

    expect(fetch).toBeCalledTimes(2);
  });

  it('Install apk on all Fire Tab device - installApkOnAllFireTabDevices() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(
      installApkOnAllFireTabDevices('80333fe-32fd-4344-9ac1-33dbcf23e2fc'),
    ).rejects.toThrow();
  });

  it('Install apk on all Fire TV device - installApkOnAllFireTvDevices()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseListAllAdbDevices));
    global.fetch.mockResponseOnce(JSON.stringify(responseInstall));
    await installApkOnAllFireTvDevices('80333fe-32fd-4344-9ac1-33dbcf23e2fc');

    expect(fetch).toBeCalledTimes(2);
  });

  it('Install apk on all Fire TV device - installApkOnAllFireTvDevices() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(
      installApkOnAllFireTvDevices('80333fe-32fd-4344-9ac1-33dbcf23e2fc'),
    ).rejects.toThrow();
  });

  it('Uninstall apk on all Android TV device - uninstallApkOnAllAndroidTvDevices()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseListAllAdbDevices));
    global.fetch.mockResponseOnce(JSON.stringify(responeUninstallApk));
    await uninstallApkOnAllAndroidTvDevices('com.discovery.dplay.enterprise');

    expect(fetch).toBeCalledTimes(2);
  });

  it('Uninstall apk on all Android TV device - uninstallApkOnAllAndroidTvDevices() - throws error for failure', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseListAllAdbDevices));
    global.fetch.mockRejectOnce(Error(JSON.stringify(errorFailed)));

    await uninstallApkOnAllAndroidTvDevices('com.discovery.dplay.enterprise');
    expect(fetch).toBeCalledTimes(2);
  });

  it('Uninstall apk on all Android TV device - uninstallApkOnAllAndroidTvDevices() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(
      uninstallApkOnAllAndroidTvDevices('com.discovery.dplay.enterprise'),
    ).rejects.toThrow();
  });

  it('Uninstall apk on all Fire Tab device - uninstallApkOnAllFireTabDevices()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseListAllAdbDevices));
    global.fetch.mockResponseOnce(JSON.stringify(responeUninstallApk));
    await uninstallApkOnAllFireTabDevices('com.discovery.dplay.enterprise');

    expect(fetch).toBeCalledTimes(2);
  });

  it('Uninstall apk on all Fire Tab device - uninstallApkOnAllFireTabDevices() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(
      uninstallApkOnAllFireTabDevices('com.discovery.dplay.enterprise'),
    ).rejects.toThrow();
  });

  it('Uninstall apk on all Fire TV device - uninstallApkOnAllFireTvDevices()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseListAllAdbDevices));
    global.fetch.mockResponseOnce(JSON.stringify(responeUninstallApk));
    await uninstallApkOnAllFireTvDevices('com.discovery.dplay.enterprise');

    expect(fetch).toBeCalledTimes(2);
  });

  it('Uninstall apk on all Fire TV device - uninstallApkOnAllFireTvDevices() - throws Authorization Error when HS_TOKEN is not added', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(
      uninstallApkOnAllFireTvDevices('com.discovery.dplay.enterprise'),
    ).rejects.toThrow();
  });

  it('Get ipa app info - ipaAppInfo()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseIpaAppInfo));

    await ipaAppInfo('8887f507-afdb-4a32-9171-e613940f8e38');
    expect(fetch).toBeCalledTimes(1);
  });

  it('Install ipa - installIpa()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseInstall));

    await installIpa(
      '3c83bd305f19876fb81802ab16458064dbe32edc',
      '8887f507-afdb-4a32-9171-e613940f8e38',
    );
    expect(fetch).toBeCalledTimes(1);
  });

  it('Uninstall ipa - uninstallIpa()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseUnintallIpa));

    await uninstallIpa(
      '3c83bd305f19876fb81802ab16458064dbe32edc',
      '8887f507-afdb-4a32-9171-e613940f8e38',
    );
    expect(fetch).toBeCalledTimes(1);
  });

  it('List all iDevices by model - listAlliDevicesByModel()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseiDeviceList));
    global.fetch.mockResponse(JSON.stringify(responseIDeviceInfo));

    await listAlliDevicesByModel('AppleTV');
    expect(fetch).toBeCalledTimes(3);
  });

  it('Instal ipa on all Apple TV - installIpaOnAllAppleTvDevices()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseiDeviceList));
    global.fetch.mockResponseOnce(JSON.stringify(responseIDeviceInfo));
    global.fetch.mockResponseOnce(JSON.stringify(responseIDeviceInfoNext));
    global.fetch.mockResponse(JSON.stringify(responseInstall));

    await installIpaOnAllAppleTvDevices('8887f507-afdb-4a32-9171-e613940f8e38');
    expect(fetch).toBeCalledTimes(5);
  });

  it('Install ipa on all Android TV device - installIpaOnAllAppleTvDevices() - throws error for failure', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseiDeviceList));
    global.fetch.mockResponseOnce(JSON.stringify(responseIDeviceInfo));
    global.fetch.mockResponseOnce(JSON.stringify(responseIDeviceInfoNext));
    global.fetch.mockReject(Error(JSON.stringify(errorFailed)));

    await installIpaOnAllAppleTvDevices('8887f507-afdb-4a32-9171-e613940f8e38');
    expect(fetch).toBeCalledTimes(5);
  });

  it('Uninstall ipa from all Apple TVs - uninstallIpaOnAllAppleTvDevices()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseiDeviceList));
    global.fetch.mockResponseOnce(JSON.stringify(responseIDeviceInfo));
    global.fetch.mockResponseOnce(JSON.stringify(responseIDeviceInfoNext));
    global.fetch.mockResponse(JSON.stringify(responseUnintallIpa));

    await uninstallIpaOnAllAppleTvDevices(
      '8887f507-afdb-4a32-9171-e613940f8e38',
    );
    expect(fetch).toBeCalledTimes(5);
  });

  it('Uninstall ipa on all Android TV device - uninstallIpaOnAllAppleTvDevices() - throws error for failure', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseiDeviceList));
    global.fetch.mockResponseOnce(JSON.stringify(responseIDeviceInfo));
    global.fetch.mockResponseOnce(JSON.stringify(responseIDeviceInfoNext));
    global.fetch.mockReject(Error(JSON.stringify(errorFailed)));

    await uninstallIpaOnAllAppleTvDevices(
      '8887f507-afdb-4a32-9171-e613940f8e38',
    );
    expect(fetch).toBeCalledTimes(5);
  });

  it('Upload app with tag - uploadAppWithTag()', async () => {
    global.fetch.mockResponseOnce(JSON.stringify(responseInstall));
    await uploadAppWithTag(
      '/Users/ddaga/Downloads/DTC-tvOS-Release.ipa',
      'AppleTvEmeaRelease',
    );

    expect(fetch).toBeCalledTimes(1);
  });

  it('Upload app with tag - uploadAppWithTag() - throws file type mismatch error', async () => {
    await expect(
      uploadAppWithTag(
        '/Users/ddaga/Downloads/DTC-tvOS-Release.html',
        'AppleTvEmeaRelease',
      ),
    ).rejects.toThrow();
  });

  it('Upload app with tag - uploadAppWithTag() - thows Authorization error', async () => {
    global.fetch.mockResponseOnce('{}', errorResponseHeader);

    await expect(
      uploadAppWithTag(
        '/Users/ddaga/Downloads/DTC-tvOS-Release.ipa',
        'AppleTvEmeaRelease',
      ),
    ).rejects.toThrow();
  });
});
