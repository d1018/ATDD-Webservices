require('dotenv').config();
const os = require('os');
const fs = require('fs');
const path = require('path');

const { execSync } = require('child_process');

// The tests below assume that `process.env.DEVICE` is "android". This ensures that they are correct.
process.env.DEVICE = 'android';

const testRpConfig = require('../test_resources/support/rp/rpConfig');
const { jsonToZipFile, uploadZipFile } = require('../../support/rp');

describe('zip file', () => {
  const testDataZipFileName =
    './tests/test_resources/support/rp/android_result.zip';
  const testDataXmlFileName =
    './tests/test_resources/support/rp/android_result.xml';

  test('confirm that the zip file exists, that its name is dependent on process.env.DEVICE, and that its contents are correct', () => {
    const targetDirectory = fs.mkdtempSync(
      path.join(os.tmpdir(), 'rp.test.js-'),
    );
    const expectedTargetFileName = path.join(
      targetDirectory,
      `android_result.zip`,
    );

    const actualTargetFileName = jsonToZipFile(
      './tests/test_resources/support/rp/json_report.json',
      targetDirectory,
    );

    // The zip file should exist at the returned location.
    expect(fs.existsSync(actualTargetFileName)).toBe(true);

    // The zip file should be created in the target directory, with the expected name.
    expect(actualTargetFileName).toBe(expectedTargetFileName);

    const unzipDirectory = path.join(targetDirectory, 'unzip');

    execSync(`mkdir ${unzipDirectory}`);
    execSync(`unzip ${actualTargetFileName} -d ${unzipDirectory}`);
    const unzippedFilePath = path.join(targetDirectory, 'android_result.xml');

    expect(fs.existsSync(unzippedFilePath)).toBe(true);
    const actualUnzippedFileContents = fs.readFileSync(unzippedFilePath, {
      encoding: 'utf-8',
    });
    const expectedUnzippedFileContents = fs.readFileSync(testDataXmlFileName, {
      encoding: 'utf-8',
    });

    // The contents of the created zip file should match the contents of the test resources zip file.
    expect(actualUnzippedFileContents).toBe(expectedUnzippedFileContents);
  });

  test('confirm that the zip file has been uploaded successfully', async () => {
    // NOTE: this test will fail if the test ReportPortal instance specified in `./tests/test_resources/support/rp/rpConfig.js` is down.
    // NOTE: this test will fail if the auth token in `./tests/test_resources/support/rp/rpConfig.js` is invalid.
    // WARNING: this test is not a unit test; it is an integration test that is dependent on an external web service.
    const isUploadSuccessful = await uploadZipFile(
      testDataZipFileName,
      testRpConfig,
    );

    expect(isUploadSuccessful).toBe(true);
  });
});
