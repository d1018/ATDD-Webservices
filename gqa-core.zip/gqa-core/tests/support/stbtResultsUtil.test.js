const mockFsExistsSync = jest.fn();
const mockFsReadFileSync = jest.fn();
const mockFdReaddirSync = jest.fn();
const mockGetJsonFilesInDir = jest.fn();
const mockResultDirContainsJsonFiles = jest.fn();

jest.mock('fs', () => ({
  existsSync: mockFsExistsSync,
  readFileSync: mockFsReadFileSync,
  readdirSync: mockFdReaddirSync,
}));

const mockLoggerWarn = jest.fn();

jest.mock('../../support/logger', () => ({
  logger: { warn: mockLoggerWarn },
}));

jest.mock('../../support/stbtResultsUtil', () => {
  const stbtResultUtil = jest.requireActual('../../support/stbtResultsUtil');

  return {
    ...stbtResultUtil,
    getJsonFilesInDir: mockGetJsonFilesInDir,
    resultDirContainsJsonFiles: mockResultDirContainsJsonFiles,
  };
});

const stbtResultUtil = require('../../support/stbtResultsUtil');

describe('mergeStbtResults()', () => {
  const emptyJsonFile = '';
  const validJsonFileContents1 = '[{"result":true, "count":2}]';
  const validJsonFileContents2 = '[{"result":true, "count":35}]';

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('when given a bad directory we throw an error', () => {
    // override the fs.existsSync call to return false
    // NOTE: we could pass in a bad string path, but if that ends up ever existing, this test will fail
    mockFsExistsSync.mockReturnValueOnce(false);

    // should check that it's the right error
    expect(() =>
      stbtResultUtil.mergeStbtResults('./irrelevantPath'),
    ).toThrowError();
  });

  test('when given a directory with no JSON files we throw an error', () => {
    // make sure the fs.existsSync call to return true, we don't actually care about the dir
    mockFsExistsSync.mockReturnValueOnce(false);
    // make sure our check for whether the dir contains any json files returns false, just to be sure that throws an error
    mockResultDirContainsJsonFiles.mockReturnValueOnce(false);

    // should check that it's the right error
    expect(() =>
      stbtResultUtil.mergeStbtResults('./irrelevantPath'),
    ).toThrowError();
  });

  test('when one of the JSON files is empty it does not impact the result', () => {
    const files = ['empty.json', 'valid1.json'];

    mockFsExistsSync.mockReturnValue(true);
    mockFdReaddirSync.mockReturnValue(files);
    mockResultDirContainsJsonFiles.mockReturnValueOnce(true);

    mockFsReadFileSync.mockReturnValueOnce(emptyJsonFile);
    mockFsReadFileSync.mockReturnValueOnce(validJsonFileContents1);
    // we need to get the result of the merge and make sure it is what we expect from the const EXPECTED.
    expect(stbtResultUtil.mergeStbtResults('./irrelevantPath')).toStrictEqual([
      { count: 2, result: true },
    ]);
    expect(mockLoggerWarn).toHaveBeenCalledTimes(1);
    expect(mockLoggerWarn).toHaveBeenCalledWith(
      'Caught an error when parsing json files: SyntaxError: Unexpected end of JSON input, skipping file: empty.json',
    );
  });

  test('when given two valid JSON files we produce a joined file', () => {
    const files = ['valid1.json', 'valid2.json'];

    mockFsExistsSync.mockReturnValue(true);
    mockFdReaddirSync.mockReturnValue(files);
    mockResultDirContainsJsonFiles.mockReturnValueOnce(true);

    mockFsReadFileSync.mockReturnValueOnce(validJsonFileContents1);
    mockFsReadFileSync.mockReturnValueOnce(validJsonFileContents2);
    // we need to get the result of the merge and make sure it is what we expect from the const EXPECTED.
    expect(stbtResultUtil.mergeStbtResults('./irrelevantPath')).toStrictEqual([
      { count: 2, result: true },
      { count: 35, result: true },
    ]);
  });
});
