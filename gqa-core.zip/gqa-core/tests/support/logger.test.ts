// Copyright text placeholder, Warner Bros. Discovery, Inc.

const consoleLogSpy = jest.spyOn(console, 'log');
const consoleInfoSpy = jest.spyOn(console, 'info');
const consoleWarnSpy = jest.spyOn(console, 'warn');
const consoleErrorSpy = jest.spyOn(console, 'error');

const dateNowSpy = jest.spyOn(Date, 'now');

const MOCK_YELLOW: string = 'yellow';
const MOCK_RED_BOLD: string = 'RED_BOLD';

jest.mock('../../support/colors', () => ({
  YELLOW: MOCK_YELLOW,
  RED_BOLD: MOCK_RED_BOLD,
}));

import { logger } from '../../support/logger';

describe('the logger singleton', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    consoleLogSpy.mockImplementation(() => {});
    consoleInfoSpy.mockImplementation(() => {});
    consoleWarnSpy.mockImplementation(() => {});
    consoleErrorSpy.mockImplementation(() => {});
  });

  const MOCK_NOW: number = 1675973211607;
  const MOCK_NOW_FORMATTED: string = '2023-02-09T20:06:51.607Z';

  beforeEach(() => {
    dateNowSpy.mockReturnValue(MOCK_NOW);
  });

  /**
   * Returns the expected display color control code for the logLevel.
   *
   * The display color is normal except for 'warn' (yellow) and 'error' (red, bold).
   *
   * @param logLevel - One of the logging levels that will be reported: 'debug', 'info', 'warn', or 'error'.
   * @returns The expected display color control code for the given logging level.
   */
  function _getColorForLogLevel(logLevel: string): string {
    if (logLevel === 'warn') {
      return MOCK_YELLOW;
    }

    if (logLevel === 'error') {
      return MOCK_RED_BOLD;
    }
    return '';
  }

  /**
   * Returns a matcher for the log prefix at the given log level.
   *
   * @param logLevel - One of the logging levels that will be reported: 'debug', 'info', 'warn', or 'error'.
   * @returns A Jest matcher for the prefix of the log entry.
   */
  function _getPrefixMatcher(logLevel: string): string {
    const color: string = _getColorForLogLevel(logLevel);

    return expect.stringMatching(
      `^${color}${MOCK_NOW_FORMATTED}|${process.pid}|${logLevel}$`,
    );
  }

  it('requires at least one argument to the logging functions', () => {
    // @ts-expect-error
    expect(() => logger.log()).toThrowError(
      'Logging functions must be called with at least one argument.',
    );
    // @ts-expect-error
    expect(() => logger.debug()).toThrowError(
      'Logging functions must be called with at least one argument.',
    );
    // @ts-expect-error
    expect(() => logger.info()).toThrowError(
      'Logging functions must be called with at least one argument.',
    );
    // @ts-expect-error
    expect(() => logger.warn()).toThrowError(
      'Logging functions must be called with at least one argument.',
    );
    // @ts-expect-error
    expect(() => logger.error()).toThrowError(
      'Logging functions must be called with at least one argument.',
    );
  });

  it('writes calls to logger.log() to console.log()', () => {
    logger.log('arg 1', 'arg 2', { fred: 37 });

    expect(consoleLogSpy).toHaveBeenCalledTimes(1);
    expect(consoleLogSpy).toHaveBeenCalledWith(
      _getPrefixMatcher('debug'),
      'arg 1',
      'arg 2',
      { fred: 37 },
    );
  });

  it('writes calls to logger.debug() to console.log()', () => {
    logger.debug('arg 1', 'arg 2', { fred: 37 });

    expect(consoleLogSpy).toHaveBeenCalledTimes(1);
    expect(consoleLogSpy).toHaveBeenCalledWith(
      _getPrefixMatcher('debug'),
      'arg 1',
      'arg 2',
      { fred: 37 },
    );
  });

  it('writes calls to logger.info() to console.info()', () => {
    logger.info('arg 1', 'arg 2', { fred: 37 });

    expect(consoleInfoSpy).toHaveBeenCalledTimes(1);
    expect(consoleInfoSpy).toHaveBeenCalledWith(
      _getPrefixMatcher('info'),
      'arg 1',
      'arg 2',
      { fred: 37 },
    );
  });

  it('writes calls to logger.warn() to console.warn()', () => {
    logger.warn('arg 1', 'arg 2', { fred: 37 });

    expect(consoleWarnSpy).toHaveBeenCalledTimes(1);
    expect(consoleWarnSpy).toHaveBeenCalledWith(
      _getPrefixMatcher('warn'),
      'arg 1',
      'arg 2',
      { fred: 37 },
    );
  });

  it('writes calls to logger.error() to console.error()', () => {
    logger.error('arg 1', 'arg 2', { fred: 37 });

    expect(consoleErrorSpy).toHaveBeenCalledTimes(1);
    expect(consoleErrorSpy).toHaveBeenCalledWith(
      _getPrefixMatcher('error'),
      'arg 1',
      'arg 2',
      {
        fred: 37,
      },
    );
  });

  it('prefixes the log entry with a timestamp and the pid of the process', () => {
    const expectedPrefix: string = `${MOCK_NOW_FORMATTED}|${process.pid}|log:`;

    logger.log('arg 1', 'arg 2');

    expect(consoleLogSpy).toHaveBeenCalledTimes(1);
    expect(consoleLogSpy).toHaveBeenCalledWith(
      expectedPrefix,
      'arg 1',
      'arg 2',
    );
  });

  it('displays "debug"-level log messages in default-colored text', () => {
    const expectedPrefix: string = `${MOCK_NOW_FORMATTED}|${process.pid}|debug:`;

    logger.debug('arg 1', 'arg 2');

    expect(consoleLogSpy).toHaveBeenCalledTimes(1);
    expect(consoleLogSpy).toHaveBeenCalledWith(
      expectedPrefix,
      'arg 1',
      'arg 2',
    );
  });

  it('displays "log"-level log messages in default-colored text', () => {
    const expectedPrefix: string = `${MOCK_NOW_FORMATTED}|${process.pid}|log:`;

    logger.log('arg 1', 'arg 2');

    expect(consoleLogSpy).toHaveBeenCalledTimes(1);
    expect(consoleLogSpy).toHaveBeenCalledWith(
      expectedPrefix,
      'arg 1',
      'arg 2',
    );
  });

  it('displays "info"-level log messages in default-colored text', () => {
    const expectedPrefix: string = `${MOCK_NOW_FORMATTED}|${process.pid}|info:`;

    logger.info('arg 1', 'arg 2');

    expect(consoleInfoSpy).toHaveBeenCalledTimes(1);
    expect(consoleInfoSpy).toHaveBeenCalledWith(
      expectedPrefix,
      'arg 1',
      'arg 2',
    );
  });

  it('displays "warn"-level log messages in yellow text', () => {
    const expectedPrefix: string = `${MOCK_YELLOW}${MOCK_NOW_FORMATTED}|${process.pid}|warn:`;

    logger.warn('arg 1', 'arg 2');

    expect(consoleWarnSpy).toHaveBeenCalledTimes(1);
    expect(consoleWarnSpy).toHaveBeenCalledWith(
      expectedPrefix,
      'arg 1',
      'arg 2',
    );
  });

  it('displays "error"-level log messages in bold, red text', () => {
    const expectedPrefix: string = `${MOCK_RED_BOLD}${MOCK_NOW_FORMATTED}|${process.pid}|error:`;

    logger.error('arg 1', 'arg 2');

    expect(consoleErrorSpy).toHaveBeenCalledTimes(1);
    expect(consoleErrorSpy).toHaveBeenCalledWith(
      expectedPrefix,
      'arg 1',
      'arg 2',
    );
  });

  test('logs a JSON stringified version of the first argument if it is an object', () => {
    logger.error({ isA: 'some object' }, 'arg 2');

    expect(consoleErrorSpy).toHaveBeenCalledTimes(1);
    expect(consoleErrorSpy).toHaveBeenCalledWith(
      _getPrefixMatcher('error'),
      '{\n  "isA": "some object"\n}',
      'arg 2',
    );
  });

  test('logs the message and stack trace of the first argument, if it is an Error object', () => {
    const MOCK_ERROR_STACK: string =
      'Error: Some error message\nat SomeClassOrFunction (/path/to/source/file.ts:123:45)\nat SomeOtherClassOrFunction (/and/so/on)';

    const testError: Error = new Error('Some error message');

    testError.stack = MOCK_ERROR_STACK;

    logger.log(testError, 'arg 2', 'arg 3');

    expect(consoleLogSpy).toHaveBeenCalledTimes(1);
    expect(consoleLogSpy).toHaveBeenCalledWith(
      _getPrefixMatcher('debug'),
      `Error: Some error message\nStack: ${MOCK_ERROR_STACK}`,
      'arg 2',
      'arg 3',
    );
  });
});
