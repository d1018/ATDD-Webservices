const { SkipError, errorReason } = require('../../support/customErrors');

describe('support/customError test suite', () => {
  test('should throw a custom error', () => {
    const t = () => {
      throw new SkipError(errorReason.functionTimeout);
    };

    expect(t).toThrow(SkipError);
    expect(t).toThrow('Skipped due to skip reason function timed out');
  });
});
