global.fetch = require('jest-fetch-mock');

global.fetch.enableMocks();

// Set test values for process.env.TESTRAIL_USERNAME and process.env.TESTRAIL_API before requiring
// any modules from `support/testrail`. They all load `support/testrail/utils.js`, which requires
// that these environment variables be set.
process.env.TESTRAIL_USERNAME = 'test_testrail_username';
process.env.TESTRAIL_APIKEY = 'test_testrail_apikey';

const { Suite } = require('../../../support/testrail/suite');
const { InvalidTestCaseError } = require('../../../support/testrail/errors');

describe('support/testrail/suite test suite', () => {
  beforeEach(async () => {
    await fetch.resetMocks();
    const suiteContext = {
      id: 3,
      name: 'Test Suite',
      description: 'Test Suite description',
    };

    this.suite = new Suite(suiteContext);
  });

  test('should be an instance of Suite', () => {
    expect(this.suite).toBeInstanceOf(Suite);
  });

  test('should get all the test cases from a suite', async () => {
    const casesContext = {
      cases: [
        {
          id: 3,
          title: 'Test Case',
          description: 'Test Case description',
        },
      ],
    };

    global.fetch.mockResponseOnce(JSON.stringify(casesContext));
    const testCases = await this.suite.getAllTestCases();

    expect(testCases[0].context.id).toEqual(3);
  });

  test('should get a test case id by name', async () => {
    const casesContext = {
      cases: [
        {
          id: 3,
          title: 'Test Case',
          description: 'Test Case description',
        },
      ],
    };

    global.fetch.mockResponseOnce(JSON.stringify(casesContext));
    const testCaseId = await this.suite.getTestCaseIdByName('Test Case');

    expect(testCaseId).toEqual(3);
  });

  test('should get a test case by id', async () => {
    const casesContext = {
      cases: [
        {
          id: 3,
          title: 'Test Case',
          description: 'Test Case description',
        },
      ],
    };

    global.fetch.mockResponseOnce(JSON.stringify(casesContext));
    const testCase = await this.suite.getTestCase(3);

    expect(testCase.context.id).toEqual(3);
  });

  test('should throw an Error while getting test case', async () => {
    const casesContext = {
      cases: [
        {
          id: 4,
          title: 'Test Case',
          description: 'Test Case description',
        },
      ],
    };

    const expectedError = new InvalidTestCaseError('Test Suite');
    let actualError;

    global.fetch.mockResponseOnce(JSON.stringify(casesContext));

    try {
      await this.suite.getTestCase(3);
    } catch (err) {
      actualError = err;
    }
    expect(actualError).toEqual(expectedError);
  });

  test('should create a test case', async () => {
    const sectionsContext = {
      sections: [
        {
          section_id: 1,
          name: 'Test Section',
          suite_Id: 3,
        },
      ],
    };

    const caseContext = {
      id: 3,
      title: 'Test Case',
      description: 'Test Case description',
    };

    global.fetch.mockResponseOnce(JSON.stringify(sectionsContext));
    global.fetch.mockResponseOnce(JSON.stringify(caseContext));
    const createdTestCase = await this.suite.createTestCase(
      'Test Section',
      caseContext,
    );

    expect(createdTestCase.context.title).toEqual('Test Case');
  });

  test('should create a test case when sectionsContext doe not exists', async () => {
    const sectionsContext = {
      sections: [
        {
          section_id: 1,
          name: 'Test Section',
          suite_id: 3,
        },
      ],
    };
    const addsectionContext = {
      section_id: 2,
      name: 'New section',
      suite_id: 3,
    };
    const caseContext = {
      id: 3,
      section_id: 2,
      title: 'Test Case',
      description: 'Test Case description',
    };

    global.fetch.mockResponseOnce(JSON.stringify(sectionsContext));
    global.fetch.mockResponseOnce(JSON.stringify(addsectionContext));
    global.fetch.mockResponseOnce(JSON.stringify(caseContext));
    const createdTestCase = await this.suite.createTestCase(
      'New section',
      caseContext,
    );

    expect(createdTestCase.context.title).toEqual('Test Case');
    expect(createdTestCase.context.section_id).toEqual(2);
  });

  test('should create a test run', async () => {
    const testRunContext = {
      id: 3,
      name: 'Test Run',
      description: 'Test Run description',
    };

    global.fetch.mockResponseOnce(JSON.stringify(testRunContext));
    const createdTestRun = await this.suite.createTestRun({
      name: 'Test Run',
      description: 'Test Run description',
    });

    expect(createdTestRun.context.name).toEqual('Test Run');
  });

  test('should create a new test plan', async () => {
    const testPlansContext = {
      plans: [
        {
          id: 3,
          name: 'Old Plan',
          description: 'Test Plan description',
        },
      ],
    };
    const today = new Date(Date.now());
    const newTestPlanContext = {
      id: 3,
      name: `New Plan - 1 - ${today.toDateString()}`,
      description: 'Test Plan description',
    };

    global.fetch.mockResponseOnce(JSON.stringify(testPlansContext));
    global.fetch.mockResponseOnce(JSON.stringify(newTestPlanContext));
    const createdTestPlan = await this.suite.createTestPlan('New Plan', 1);

    expect(createdTestPlan.context.name).toEqual(
      `New Plan - 1 - ${today.toDateString()}`,
    );
  });

  test('should return existing test plan', async () => {
    const today = new Date(Date.now());
    const planName = `Old Plan - 1 - ${today.toDateString()} - ${today.toTimeString()}`;
    const testPlansContext = {
      plans: [
        {
          id: 3,
          name: planName,
          description: 'Test Plan description',
        },
      ],
    };
    const oldPlanContext = {
      id: 3,
      name: planName,
      description: 'Test Plan description',
    };

    global.fetch.mockResponseOnce(JSON.stringify(testPlansContext));
    global.fetch.mockResponseOnce(JSON.stringify(oldPlanContext));
    const createdTestPlan = await this.suite.createTestPlan('Old Plan', 1);

    expect(createdTestPlan.context.name).toEqual(planName);
    expect(createdTestPlan.context.id).toEqual(3);
  });
});
