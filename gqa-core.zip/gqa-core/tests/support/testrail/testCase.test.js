global.fetch = require('jest-fetch-mock');

global.fetch.enableMocks();

// Set test values for process.env.TESTRAIL_USERNAME and process.env.TESTRAIL_API before requiring
// any modules from `support/testrail`. They all load `support/testrail/utils.js`, which requires
// that these environment variables be set.
process.env.TESTRAIL_USERNAME = 'test_testrail_username';
process.env.TESTRAIL_APIKEY = 'test_testrail_apikey';

const { TestCase } = require('../../../support/testrail/testCase');

describe('support/testrail/testCase test suite', () => {
  beforeEach(async () => {
    await fetch.resetMocks();
    const testCaseContext = {
      id: 3,
      name: 'Test Case',
      description: 'Test Case description',
    };

    this.testCase = new TestCase(testCaseContext);
  });

  test('should be an instance of TestCase', () => {
    expect(this.testCase).toBeInstanceOf(TestCase);
  });

  test('should update test case', async () => {
    const testCaseContext = {
      id: 3,
      title: 'Test Case Updated',
      description: 'Test Case description Updated',
    };

    global.fetch.mockResponseOnce(JSON.stringify(testCaseContext));
    await this.testCase.update({
      title: 'Test Case Updated',
      description: 'Test Case description Updated',
    });
    expect(this.testCase.context.title).toEqual('Test Case Updated');
  });
});
