// Set test values for process.env.TESTRAIL_USERNAME and process.env.TESTRAIL_API before requiring
// any modules from `support/testrail`. They all load `support/testrail/utils.js`, which requires
// that these environment variables be set.
process.env.TESTRAIL_USERNAME = 'test_testrail_username';
process.env.TESTRAIL_APIKEY = 'test_testrail_apikey';

const { TestCaseResult } = require('../../../support/testrail/testCaseResult');

describe('support/testrail/testCaseResult test suite', () => {
  beforeEach(() => {
    this.testCaseResult = new TestCaseResult({
      id: 1,
      status_id: 1,
      comment: 'Test Case Result comment',
    });
  });

  test('should be an instance of TestCaseResult', () => {
    expect(this.testCaseResult).toBeInstanceOf(TestCaseResult);
  });
});
