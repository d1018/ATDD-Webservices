// Set test values for process.env.TESTRAIL_USERNAME and process.env.TESTRAIL_API before requiring
// any modules from `support/testrail`. They all load `support/testrail/utils.js`, which requires
// that these environment variables be set.
process.env.TESTRAIL_USERNAME = 'test_testrail_username';
process.env.TESTRAIL_APIKEY = 'test_testrail_apikey';

const TestResult = require('../../../support/testrail/testResult');

describe('support/testrail/testResult test suite', () => {
  test('instance of TestResult UNKOWN', () => {
    const status = [
      'UNKNOWN',
      'PASSED',
      'SKIPPED',
      'PENDING',
      'UNDEFINED',
      'AMBIGUOUS',
      'FAILED',
      '',
    ];

    for (let i = 0; i < status.length; i++) {
      this.testResult = new TestResult(1, status[i], { seconds: 2.0 });
      expect(this.testResult).toBeInstanceOf(TestResult);
    }
  });
});
