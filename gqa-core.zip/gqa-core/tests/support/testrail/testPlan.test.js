global.fetch = require('jest-fetch-mock');

global.fetch.enableMocks();

// Set test values for process.env.TESTRAIL_USERNAME and process.env.TESTRAIL_API before requiring
// any modules from `support/testrail`. They all load `support/testrail/utils.js`, which requires
// that these environment variables be set.
process.env.TESTRAIL_USERNAME = 'test_testrail_username';
process.env.TESTRAIL_APIKEY = 'test_testrail_apikey';

const { TestPlan } = require('../../../support/testrail/testPlan');

describe('support/testrail/testPlan test suite', () => {
  beforeEach(async () => {
    await fetch.resetMocks();

    this.testPlanInstance = new TestPlan();
  });

  test('should get a test plan by id', async () => {
    const planContext = {
      id: 3,
      name: 'Test Plan',
      description: 'Test Plan description',
    };

    global.fetch.mockResponseOnce(JSON.stringify(planContext));
    const plan = await this.testPlanInstance.getTestPlan(3);

    expect(plan.context.id).toEqual(3);
  });

  test('should check if test plan exist', async () => {
    const testPlansContext = {
      plans: [
        {
          id: 3,
          name: 'Existing Plan',
          description: 'Test Plan description',
        },
      ],
    };

    global.fetch.mockResponseOnce(JSON.stringify(testPlansContext));
    const testPlanExists = await this.testPlanInstance.checkTestPlanExist(
      'Existing Plan',
      1,
    );

    expect(testPlanExists.length > 0).toEqual(true);
  });
});
