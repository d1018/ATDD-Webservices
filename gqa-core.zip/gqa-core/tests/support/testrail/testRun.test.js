global.fetch = require('jest-fetch-mock');

global.fetch.enableMocks();

// Set test values for process.env.TESTRAIL_USERNAME and process.env.TESTRAIL_API before requiring
// any modules from `support/testrail`. They all load `support/testrail/utils.js`, which requires
// that these environment variables be set.
process.env.TESTRAIL_USERNAME = 'test_testrail_username';
process.env.TESTRAIL_APIKEY = 'test_testrail_apikey';

const { TestRun } = require('../../../support/testrail/testRun');
const { TestCase } = require('../../../support/testrail/testCase');
const {
  InvalidTestCaseStatusError,
  MissedStatusIdError,
  MissedStatusError,
} = require('../../../support/testrail/errors');

describe('support/testrail/testRun test suite', () => {
  beforeEach(async () => {
    await global.fetch.resetMocks();
    const testRunContext = {
      id: 1,
      name: 'Test Run',
      description: 'Test Run description',
    };

    this.testRun = new TestRun(testRunContext);
  });

  test('should be an instance of TestRun', () => {
    expect(this.testRun).toBeInstanceOf(TestRun);
  });

  test('should be add a result to the test run', async () => {
    const payload = {
      results: [
        {
          case_id: 1,
          status_id: 1,
        },
      ],
    };

    global.fetch.mockResponseOnce(JSON.stringify(payload));
    const result = await this.testRun.addResults(payload);

    expect(result).toEqual(payload);
  });

  test('should throw error when suite_id is not found', async () => {
    const payload = {
      results: [
        {
          case_id: 1,
        },
      ],
    };
    const expectedError = new MissedStatusIdError();
    let acctualError;

    global.fetch.mockResponseOnce(JSON.stringify(payload));
    try {
      await this.testRun.addResults(payload);
    } catch (err) {
      acctualError = err;
    }
    expect(acctualError).toEqual(expectedError);
  });

  test('should be create a test case result', async () => {
    const testCase = new TestCase({
      id: 1,
      title: 'Test Case',
      description: 'Test Case description',
    });
    const payload = { status: 'Passed' };

    global.fetch.mockResponseOnce(JSON.stringify(payload));
    const testCaseResult = await this.testRun.createTestCaseResult(
      testCase,
      payload,
    );

    expect(testCaseResult.context.status).toEqual('Passed');
  });
  test('should throw error when testcase status is invalid', async () => {
    const testCase = new TestCase({
      id: 1,
      title: 'Test Case',
      description: 'Test Case description',
    });
    const payload = { status: 'Invalid' };
    const expectedError = new InvalidTestCaseStatusError(payload.status);
    let actualError;

    global.fetch.mockResponseOnce(JSON.stringify(payload));
    try {
      await this.testRun.createTestCaseResult(testCase, payload);
    } catch (err) {
      actualError = err;
    }

    expect(actualError).toEqual(expectedError);
  });

  test('should throw error when status is missed', async () => {
    const testCase = new TestCase({
      id: 1,
      title: 'Test Case',
      description: 'Test Case description',
    });
    const payload = {};

    const expectedError = new MissedStatusError();
    let actualError;

    global.fetch.mockResponseOnce(JSON.stringify(payload));
    try {
      await this.testRun.createTestCaseResult(testCase, payload);
    } catch (err) {
      actualError = err;
    }

    expect(actualError).toEqual(expectedError);
  });
});
