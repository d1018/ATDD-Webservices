global.fetch = require('jest-fetch-mock');

global.fetch.enableMocks();
const fs = require('fs');

const { TestRailClient } = require('../../../support/testrail/testrail');

describe('support/testrail/testrail test suite', () => {
  beforeEach(async () => {
    await global.fetch.resetMocks();
  });

  beforeAll(() => {
    this.client = new TestRailClient();
    process.env.TESTRAIL_USERNAME = 'test_testrail_username';
    process.env.TESTRAIL_APIKEY = 'test_testrail_apikey';
    process.env.TESTRAIL_SEND_RESULTS = 'true';
  });

  afterAll(() => {
    process.env.TESTRAIL_SEND_RESULTS = '';
  });

  test('create an instance of TestRailClient', () => {
    expect(this.client).toBeInstanceOf(TestRailClient);
  });

  test('should reset test runs array', () => {
    this.client.resetTestRuns();

    expect(this.client.testRuns.length).toEqual(0);
  });

  test('should get a suite using a valid suite id', async () => {
    const suiteData = {
      id: 3,
      name: 'Test Suite',
      description: 'Test Suite description',
    };

    global.fetch.mockResponseOnce(JSON.stringify(suiteData));
    const suite = await this.client.getSuite(3);

    expect(suite.context.id).toEqual(3);
  });

  test('should get a test run by id', async () => {
    const runData = {
      id: 3,
      name: 'Test Run',
      description: 'Test Run description',
    };

    global.fetch.mockResponseOnce(JSON.stringify(runData));
    const run = await this.client.getRun(3);

    expect(run.context.id).toEqual(3);
  });

  test('should get a test plan by id', async () => {
    const planData = {
      id: 3,
      name: 'Test Plan',
      description: 'Test Plan description',
    };

    global.fetch.mockResponseOnce(JSON.stringify(planData));
    const plan = await this.client.getTestPlan(3);

    expect(plan.context.id).toEqual(3);
  });

  test('should get a test case by name', async () => {
    const suiteData = {
      id: 3,
      name: 'Test Suite',
      description: 'Test Suite description',
    };
    const casesContext = {
      cases: [
        {
          id: 3,
          title: 'Test Case',
          description: 'Test Case description',
        },
      ],
    };

    global.fetch.mockResponseOnce(JSON.stringify(suiteData));
    global.fetch.mockResponseOnce(JSON.stringify(casesContext));
    const testCase = await this.client.getCaseByName(3, 'Test Case');

    expect(testCase.context.title).toEqual('Test Case');
  });

  test('should get a test case id by name', async () => {
    const suiteData = {
      id: 3,
      name: 'Test Suite',
      description: 'Test Suite description',
    };
    const casesContext = {
      cases: [
        {
          id: 3,
          title: 'Test Case',
          description: 'Test Case description',
        },
      ],
    };

    global.fetch.mockResponseOnce(JSON.stringify(suiteData));
    global.fetch.mockResponseOnce(JSON.stringify(casesContext));
    const testCaseId = await this.client.getCaseIdByName(3, 'Test Case');

    expect(testCaseId).toEqual(3);
  });

  test('should append a result to the test runs array', async () => {
    const expectedValue = 1;

    const suiteData = {
      id: 3,
      name: 'Test Suite',
      description: 'Test Suite description',
    };
    const casesContext = {
      cases: [
        {
          id: 3,
          title: 'Test Case',
          description: 'Test Case description',
        },
      ],
    };
    const testResult = {
      test_id: 3,
      status: 1,
      comment: 'Test Result comment',
      duration: { seconds: 1.0 },
    };

    global.fetch.mockResponseOnce(JSON.stringify(suiteData));
    global.fetch.mockResponseOnce(JSON.stringify(casesContext));
    global.fetch.mockResponseOnce(JSON.stringify(testResult));
    await this.client.appendResult(3, {
      result: testResult,
      pickle: { name: 'Test Case' },
    });

    expect(this.client.testRuns.length).toEqual(expectedValue);
  });

  test('should initialize a test plan', async () => {
    let expectedValue = null;
    const today = new Date(Date.now());
    const planName = `New Plan - 1 - ${today.toDateString()} - ${today.toTimeString()}`;
    const suiteData = {
      id: 3,
      name: 'Test Suite',
      description: 'Test Suite description',
      project_id: 1,
    };
    const testPlansContext = {
      plans: [
        {
          id: 1,
          name: planName,
          description: 'Test Plan description',
        },
      ],
    };
    const newTestPlanContext = {
      id: 1,
      name: planName,
      entries: [
        {
          id: 3,
          name: `New Plan - 1 - ${today.toDateString()} - ${today.toTimeString()}`,
          description: 'Test Plan description',
          runs: [
            {
              id: 3,
              suite_id: 3,
              name: 'Browser test',
              description: 'Test run description',
            },
          ],
        },
      ],
    };

    global.fetch.mockResponseOnce(JSON.stringify(suiteData));
    global.fetch.mockResponseOnce(JSON.stringify(testPlansContext));
    global.fetch.mockResponseOnce(JSON.stringify(newTestPlanContext));

    await this.client.initializePlan('New Plan', 3, 1);
    expectedValue = 1;

    expect(this.client.testPlanId).toEqual(expectedValue);
  });

  test('should add a test run to a plan', async () => {
    let expectedValue = null;

    const suiteData = {
      id: 3,
      name: 'Test Suite',
      description: 'Test Suite description',
    };
    const entryData = {
      id: 1,
      name: 'Test Entry',
      description: 'Test Entry description',
      runs: [{ id: 1, name: 'run 1' }],
    };

    this.testPlanId = 1;
    global.fetch.mockResponseOnce(JSON.stringify(suiteData));
    global.fetch.mockResponseOnce(JSON.stringify(entryData));
    await this.client.addTestRunToPlan(3);
    expectedValue = 1;

    expect(this.client.testRunId).toEqual(expectedValue);
  });

  test('should initialize a test plan without plan entry', async () => {
    const today = new Date(Date.now());
    const planName = `New Plan - 1 - ${today.toDateString()} - ${today.toTimeString()}`;
    const suiteData = {
      id: 3,
      name: 'Test Suite',
      description: 'Test Suite description',
      project_id: 1,
    };
    const testPlansContext = {
      plans: [
        {
          id: 1,
          name: 'Old Plan',
          description: 'Test Plan description',
        },
      ],
    };
    const newTestPlanContext = {
      id: 2,
      name: planName,
      entries: [],
    };

    global.fetch.mockResponseOnce(JSON.stringify(suiteData));
    global.fetch.mockResponseOnce(JSON.stringify(testPlansContext));
    global.fetch.mockResponseOnce(JSON.stringify(newTestPlanContext));

    await this.client.initializePlanWithoutEntry('New Plan', 3, 1);

    expect(this.client.testPlanId).toEqual(newTestPlanContext.id);
  });

  test('should add a test run to a plan with case ids', async () => {
    const suiteData = {
      id: 3,
      name: 'Test Suite',
      description: 'Test Suite description',
    };
    const entryData = {
      id: 1,
      name: 'Test Entry',
      description: 'Test Entry description',
      runs: [{ id: 1, name: 'run 1' }],
    };

    this.testPlanId = 1;
    this.testCaseIds = [1, 2, 3];
    global.fetch.mockResponseOnce(JSON.stringify(suiteData));
    global.fetch.mockResponseOnce(JSON.stringify(entryData));
    await this.client.addTestRunToPlanWithCaseIds(3);

    expect(this.client.testRunId).toEqual(entryData.runs[0].id);
  });

  test('should append an entry to the test plan', async () => {
    const suiteData = {
      id: 3,
      name: 'Test Suite',
      description: 'Test Suite description',
    };
    const entryData = {
      id: 1,
      name: 'Test Entry',
      description: 'Test Entry description',
      runs: [{ id: 1, name: 'run 1' }],
    };

    global.fetch.mockResponseOnce(JSON.stringify(suiteData));
    global.fetch.mockResponseOnce(JSON.stringify(entryData));
    const entry = await this.client.appendEntry(3, entryData);

    expect(entry.id).toEqual(1);
  });

  test('should append an entry to the test plan with case ids', async () => {
    const suiteData = {
      id: 3,
      name: 'Test Suite',
      description: 'Test Suite description',
    };
    const entryData = {
      id: 1,
      name: 'Test Entry',
      description: 'Test Entry description',
      runs: [{ id: 1, name: 'run 1' }],
    };

    this.testPlanId = 1;
    this.testCaseIds = [1, 2, 3];
    global.fetch.mockResponseOnce(JSON.stringify(suiteData));
    global.fetch.mockResponseOnce(JSON.stringify(entryData));
    const entry = await this.client.appendEntryWithCaseIds(3, this.testCaseIds);

    expect(entry.id).toEqual(entryData.runs[0].id);
  });

  test('should append a test case if not present in the suite', async () => {
    const scenario = {
      gherkinDocument: {
        feature: {
          name: 'Feature Name',
          description: 'Feature Description',
        },
      },
      pickle: {
        name: 'New Test Case',
      },
    };
    const suiteData = {
      id: 3,
      name: 'Test Suite',
      description: 'Test Suite description',
    };

    const casesContext = {
      cases: [],
    };
    const sectionsContext = {
      sections: [
        {
          section_id: 1,
          name: 'Feature Name',
          suite_Id: 3,
        },
      ],
    };

    const caseContext = {
      id: 5,
      title: 'New Test Case',
      description: 'New Test Case description',
    };

    global.fetch.mockResponseOnce(JSON.stringify(suiteData));
    global.fetch.mockResponseOnce(JSON.stringify(casesContext));
    global.fetch.mockResponseOnce(JSON.stringify(suiteData));
    global.fetch.mockResponseOnce(JSON.stringify(sectionsContext));
    global.fetch.mockResponseOnce(JSON.stringify(caseContext));
    await this.client.appendTestCase(3, scenario);

    expect(fetch).toBeCalledTimes(5);
  });

  test('should get a test case id', async () => {
    const suiteData = {
      id: 3,
      name: 'Test Suite',
      description: 'Test Suite description',
    };
    const casesContext = {
      cases: [
        {
          id: 3,
          title: 'Test Case',
          description: 'Test Case description',
        },
      ],
    };
    const scenario = {
      pickle: {
        name: 'Test Case',
      },
    };

    this.client.testCaseIds = [];
    global.fetch.mockResponseOnce(JSON.stringify(suiteData));
    global.fetch.mockResponseOnce(JSON.stringify(casesContext));
    await this.client.getTestCaseId(3, scenario);

    expect(this.client.testCaseIds.length).toEqual(1);
    expect(this.client.testCaseIds[0]).toEqual(3);
  });

  test('should save test result', () => {
    const path = 'results/testrail_run_url.log';
    let actualError;

    this.client.saveTestRunUrl();

    try {
      if (fs.existsSync(path)) {
        // file exists
      }
    } catch (err) {
      actualError = err;
    }
    expect(undefined).toEqual(actualError);
  });
});
