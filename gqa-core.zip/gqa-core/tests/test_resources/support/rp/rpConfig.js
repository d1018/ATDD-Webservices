module.exports = {
  token: 'bearer e62994ec-aff9-43aa-b669-4d91cedca601',
  launch: 'ANDROID_TEST_EXAMPLE',
  project: 'GQA-CORE-TEST',
  endpoint:
    'http://afacd7b7f36064c7fb6b2b0c2693bce3-1069666660.us-east-1.elb.amazonaws.com/api/v1/gqa-core-test/launch/import',
  rp_enable: true,
  takeScreenshot: 'onFailure',
  description: `test execution for: ${process.env.DEVICE}`,
  attributes: [
    {
      key: 'Device',
      value: process.env.DEVICE,
    },
  ],
  mode: 'DEFAULT',
  debug: false,
  restClientConfig: {
    timeout: 0,
  },
};
