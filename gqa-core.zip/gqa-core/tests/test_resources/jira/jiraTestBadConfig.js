/* eslint-disable no-param-reassign, dot-notation */
module.exports = {
  logDir: 'results/jira',
  apiUrl: 'https://wbdstreaming.atlassian.net/rest/api',
  priority: 'P3',
  project: 'GQA',
  epic: 'GQA-XXX',
  inactiveBugStatus: ['DONE', 'CANCELLED'],
};
