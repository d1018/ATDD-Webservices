/* eslint-disable no-param-reassign, dot-notation */
module.exports = {
  logDir: 'results/jira',
  apiUrl: 'https://wbdstreaming.atlassian.net/rest/api',
  username: process.env.JIRA_USERNAME,
  password: process.env.JIRA_PASSWORD,
  priority: 'P3',
  project: 'GQA',
  epic: 'GQA-XXX',
  inactiveBugStatus: ['DONE', 'CANCELLED'],

  customizeNewBugPayload: (payload) => {
    try {
      // extra text that when specified, will be logged as an extra bullet point in the bug description
      // this is useful when you want to communicate how the Jira payload is changed in this callback
      // you cna pass an empty text to disable this
      const note = 'extra note from user config';
      // const note = '';

      // Bug Summary (a TextField)
      payload.summary = `Prefix - ${payload.summary}`;

      // Bug Priority (DropDown List)
      // payload.priority.name = 'P3';

      // Affected Version (MultiSelect List)
      payload.versions = [{ name: 'US MVP Launch' }];

      // SelectList

      // Environment (DropDown List)
      payload.customfield_10141.value = 'Integration';

      // Test Execution Type (DropDown List)
      payload.customfield_10137.value = 'Automated';

      // Test Type (MultiSelect List): append to current values
      payload.customfield_10146.push({ value: 'E2E Testing' });

      // Products (MultiSelect List): append to current values
      payload.customfield_10112.push({ value: 'Discovery+' });

      // Group (MultiSelect List): append to current values
      payload.customfield_10111.push({ value: 'GQA TE Test Eng' });

      // Group (MultiSelect List): set to a new list of values
      // payload.customfield_10111 = [{ value: 'GQA TE Test Eng' }];

      // note on return value:
      // return an array, with index 0 being the new payload, and index 1 being the extra string
      // the new payload will be sent to JIRA API during bug creation
      // the note text will be inserted to the bug description
      return [payload, note];
    } catch (ex) {
      // eslint-disable-next-line no-console
      console.log('error detected during Jira payload customizing!');

      // eslint-disable-next-line no-console
      console.log(ex);

      // a return value of undefined means that we will discard whatever changes here and send the original payload to JIRA.
      return undefined;
    }
  },
};
