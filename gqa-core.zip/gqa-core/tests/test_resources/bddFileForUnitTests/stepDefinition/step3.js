const {
  Given,
  Then,
  Before,
  BeforeAll,
  BeforeStep,
  After,
  AfterAll,
  AfterStep,
} = require('../../../../index');

// empty hooks for now
BeforeAll(async () => {});
Before(async () => {});
BeforeStep(async () => {});
AfterStep(async () => {});
After(async () => {});
AfterAll(async () => {});

Given('given 1', () => {});

Then('then 1', () => {
  throw new Error('an error');
});
