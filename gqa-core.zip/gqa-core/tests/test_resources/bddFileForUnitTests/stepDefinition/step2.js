const { Given, Then } = require('../../../../index');

Given('given 1', () => {});

Then('then 1', () => {});
