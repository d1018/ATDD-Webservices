# Case 1 -- error thrown by execSync() if pytest-bdd is not installed

File: `pytest-bdd-not-installed.json`

Indicator: `error.stdout` contains "ModuleNotFoundError: No module named 'pytest_bdd'"

Desired error message: 'pytest-bdd is not installed. Please run ".venv/bin/pip install git+https://github.com/lukeyoui/pytest-bdd.git@v1.0-wbd-alpha" to install it.'

# Case 2 -- error thrown by execSync() if the tagExpression is invalid, because it contains "adn" instead of "and"

File: `tag-expression-adn-instead-of-and.json`

Inputs: `tagExpression` is "@P0 adn not @P1"

Indicator: `error.stderr` contains "ERROR: Wrong expression passed to '-m': "

Contents: `error.stderr` is "ERROR: Wrong expression passed to '-m': P0 adn not P1: at column 4: expected end of input; got identifier\n\n"

Desired error message: 'Invalid tag expression "@P0 adn not @P1". pytest-bdd error was "ERROR: Wrong expression passed to '-m': P0 adn not P1: at column 4: expected end of input; got identifier"'

# Case 3 -- error thrown by execSync() if there are no tests in the project/feature

File: `no-tests-in-project-or-feature.json`

Inputs: path is "tests/projects/app_discovery_plus/features/\*"

Indicator: `error.stdout` contains "no tests collected in "

Contents: `error.stdout` is "\nno tests collected in 0.43s\n"

Desired error message: 'No tests found in path "tests/projects/app_discovery_plus/features/\*"'

# Case 4 -- error thrown by execSync() if there are tests in the project/feature, but the tag expression excludes all of them

File: `tagExpression-excludes-all-tests.json`

Inputs: `tagExpression` is "@P0 and not @P1"

Indicator: `error.stdout` contains "no tests collected (nnn deselected) in ", where "nnn" is the number of tests in the project/feature

Contents: `error.stdout` ends with "\nno tests collected (37 deselected) in 0.41s\n"

Desired error message: 'No tests found in path "tests/projects/app_discovery_plus/features/\*" matching tag expression "@P0 and not @P1". 37 tests were excluded by the tag expression.'
