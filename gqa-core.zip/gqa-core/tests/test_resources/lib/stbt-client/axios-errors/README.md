# Case 1 -- Axios error if one or more of the test paths are invalid

File: `400-unknown-test-path.json`

Inputs: one or more invalid test paths

Example:

```
[
  "tests/projects/app_discovery_plus/features/step_definition/test_example.py::test_account_page[Kids profile-kids-profile-Kids]",
  "tests/projects/app_discovery_plus/features/step_definition/test_example.py::test_account_page[Kids profile-teen-profile-Teen]",
  "bad/test/case::tests.py"
]
```

Indicator: `error.response.status` is `400`

Desired error message: `error.response.data.message` (e.g. `"RunTests: Unknown test \"bad/test/case::tests.py\". (Remember to include the filename, for example \"tests/filename.py::test_something_something\".)"`)

Repro: Add the following code to `runTestsWithStbtAsync` right before the call to `stbtClient.runTestsAsync`

```
  // CREATE ERROR 400-unknown-test-path
  testCases.push('bad/test/case::tests.py');
```

# Case 2 -- Axios error if the STBT auth token is invalid

File: `403-invalid-auth-token.json`

Inputs: `process.env.STBT_AUTH_TOKEN` contains an invalid or expired STBT auth token

Indicator: `error.response.status` is `403`

Desired error message: `"STBT auth token \"${invalidAuthToken}\" is invalid"`, where `invalidAuthToken` is `error.config.headers.Authorization` with the `token ` prefix removed

Repro: Add the following code to the start of the StbtClient constructor

```
    // CREATE ERROR 403-invalid-auth-token
    // eslint-disable-next-line no-param-reassign
    stbtAuthToken = '12345678901234567890123456789012';
```

# Case 3 -- Axios error if the endpoint path is invalid

File: `404-bad-endpoint-path.json`

Inputs: the endpoint path is invalid (e.g. endpoint is `"api/v2/run_testsZZZ"` instead of `"api/v2/run_tests"`

Indicator: `error.response.status` is `404` and `error.response.data` contains `"404 Not Found"`

Desired error message: `"STBT REST API endpoint \"${endpointPath}\" was not found"`

Repro: Replace the first line of `runTestsAsync()` in `StbtClient` with

```
    // CREATE ERROR 404-bad-endpoint-path
    const endpointUrl = `api/v2/run_testsZZZ`;
```

# Case 4 -- Axios error if the git revision specifier is invalid

File: `404-unknown-git-revision.json`

Inputs: git revision specifier is invalid (e.g. `"fake-git-revision"`)

Indicator: `error.response.status` is `404` and `error.response.data.message` matches `"Unknown test_pack_revision 'fake-git-revision'"`

Desired error message: `"Invalid Git revision specifier \"fake-git-revision\""`

Repro: Replace the call to `getStbtTestPackRevision()` in `runTestsWithStbtAsync` with

```
  // CREATE ERROR 404-unknown-git-revision
  const testPackRevision = 'bad-test-pack-revision';
```

# Case 5 -- Axios error if tests are already running on the node

File: `409-tests-already-running.json`

Inputs: there are already tests running on the target node

Indicator: `error.response.status` is `409`

Desired error message: `error.response.data.message` (e.g. `"Can't start job; Stb-tester Node stb-tester-00044b80ebf4 is busy running another job"`)

Repro: Kick off two runs of the GitHub Action at the same time, on the same STB-Tester node, so that they both attempt to run tests on the same node at the same time.

# Case 6 -- Axios error if there are too many requests close together

File: `429-too-many-requests.json`

Inputs: A large number of concurrent requests

Indicator: `error.response.status` is 429

Desired error message: `"STB-Tester request rate limits exceeded"`

Repro: Add the following code to the `runTestsWithStbtAsync`, right before the call to `stbtClient.waitForTestJobCompletionAsync`

```
  // CREATE ERROR 429-too-many-requests
  logger.log('DELIBERATELY CAUSING a 429 Too Many Requests error');

  const spammers = [];

  for (let i = 0; i < 150; i++) {
    spammers.push(stbtClient.getJobBddStepsResultsAsync(jobUid));
  }

  await Promise.all(spammers);
  // Done creating error 429
```

# Case 7 -- Axios error if the STBT node id is invalid

File: `500-invalid-node.json`

Inputs: STBT node id is invalid (e.g. `"stb-tester-00044b80eeee"`)

Indicator: `error.response.status` is 500

Desired error message: `"Internal Server Error from STB-Tester. This may indicate that the STBT node ID \"${requestedNodeId}\" is invalid"`, where `requestedNodeId` is `JSON.parse(error.config.data).node_id`

Repro: Replace the call to `getStbtNodeIdsForDeviceTypeAsync` in `runTestsWithStbtAsync` with

```
  // CREATE ERROR 500-invalid-node
  const stbtNodeIds: string[] = [ 'stb-tester-00044b80eeee' ];
```

# Case 8 -- Axios error if the STB-Tester node is offline

File: `503-node-is-offline.json`

Inputs: the chosen STB-Tester node is offline (e.g. `"stb-tester-00044b80f7d9"`)

Indicator: `error.response.status` is 503

Desired error message: `error.response.data.message` (e.g. `"Node stb-tester-00044b80f7d9 is offline (last seen: 2022-10-17T13:20:58.555145+00:00)"`)

Repro: Replace the call to `getStbNodeIdForDeviceTypeAsync` in `runTestsWithStbtAsync` with

```
  // CREATE ERROR 503-node-is-offline
  const stbtNodeId = 'stb-tester-00044b80f7d9';
```

NOTE: this requires that node `stb-tester-00044b80f7d9` be a valid node that is currently offline

# Case 9 -- Axios error if the base URL of the request is invalid

File: `bad-url-error.json`

Inputs: an invalid base URL (e.g. `hbo123.stb-tester.com`) is specified

Indicator: `error.response` is `undefined`; `error.code` is `"ENOTFOUND"`

Desired error message: `"STB-Tester REST API URL \"${baseUrl}\" is invalid"`, where `baseUrl` is `error.hostname`

Repro: Add the following code to the beginning of the StbtClient constructor:

```
    // CREATE ERROR bad-url-error
    // eslint-disable-next-line no-param-reassign
    baseURL = 'https://hbo123.stb-tester.com/';
```

# Case 10 -- Axios error if the base URL of the request is omitted

File: `no-url-error.json`

Inputs: no base URL is specified

Indicator: `error.response` is `undefined`; `error.code` is `"ECONNREFUSED"`

Desired error message: `"STB-Tester REST API URL was not provided"`

Repro: Add the following code to the beginning of the StbtClient construtor

```
    // CREATE ERROR no-url-error
    // eslint-disable-next-line no-param-reassign
    baseURL = '';
```
