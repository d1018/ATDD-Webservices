# gqa-core

Core test automation framework code responsible for CUJ automation..

`gqa-core` includes the following microservices:

- `gqa-core`

## Creating additional microservices

To create additional microservices within an existing repository...

1. Create directory for `<new-microservice>` in `gqa-core`: `mkdir <new-microservice>`
1. Create and configure an `.omd/<new-microservice>/now.yaml` file
1. Contact an [RDE team member](https://github.com/orgs/wbd-streaming/teams/rde/members) to configure a [SonarCloud](https://docs.sonarcloud.io/) project for the new microservice (state tuned; RDE is working to automate this!).
1. Create a `<new-microservice>/sonar-project.properties` file configuring the [SonarCloud project](https://docs.sonarcloud.io/advanced-setup/ci-based-analysis/sonarscanner-cli/)
1. Create a `<new-microservice>/Makefile` with standard built targets (details TBD; stay tuned!)

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->

**Table of Contents**

- [gqa-core](#gqa-core)
  - [Installation](#installation)
    - [Android Installation](#android-installation)
      - [FireTV/AndroidTV Installation](#firetvandroidtv-installation)
    - [iOS Installation](#ios-installation)
      - [tvOS Installation](#tvos-installation)
    - [Web Installation](#web-installation)
    - [Suitest Installation](#suitest-installation)
      - [Roku Installation](#roku-installation)
      - [Samsung Installation](#samsung-installation)
      - [LG Installation](#lg-installation)
      - [Xbox Installation](#xbox-installation)
  - [JS Standards](#js-standards)
    - [JS Styleguide](#js-styleguide)
    - [JS Doc](#js-doc)
  - [Running](#running)
    - [From Command Line](#from-command-line)
    - [Command Line - Jake tasks](#command-line---jake-tasks)
      - [How tasks are created](#how-tasks-are-created)
      - [How to check available tasks](#how-to-check-available-tasks)
      - [Checking underlying cucumber commands](#checking-underlying-cucumber-commands)
    - [Command Line - Cucumber CLI](#command-line---cucumber-cli)
    - [From Github Actions](#from-github-actions)
    - [Orange Dot Integration](#orange-dot-integration)
    - [Release Tooling Event Bus](#release-tooling-event-bus)
  - [Patterns](#patterns)
    - [Project Layout](#project-layout)
    - [Locator Definitions](#locator-definitions)
    - [Best Practices](#best-practices)
    - [Debugging](#debugging)
    - [Git remote reset](#git-remote-reset)
      - [Checking for ssh setup](#checking-for-ssh-setup)
  - [Frequently Asked Questions](#frequently-asked-questions)
  - [Support Model](#support-model)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

# gqa-core

---

### Installation

---

- Clone repository using ssh

```
git clone git@github.com:wbd-streaming/gqa-core.git
```

SSH installation is needed for the installation of dependencies. If you set up via https your bundle install will fail.

If you have problems cloning via SSH you can try the following

```bash
brew install gh
gh auth login
```

If you need to reset your repository from https to ssh, or check if it is set to ssh please follow this [link](#git-remote-reset)

- Install [NVM](https://github.com/nvm-sh/nvm)
- Use node version specified in `.nvmrc` file by running

```bash
nvm use
```

- Setup jfrog by following the instructions [here](https://wbdstreaming.atlassian.net/wiki/spaces/GQA/pages/117441613/Installing+Blaze+UAF+from+Jfrog)

- Install npm package(s) by running

```bash
npm install
```

---

#### Android Installation

---

Local Setup is not necessary for development but can be useful to speed up development times.

- Setup Appium for local ios execution following instructions [here](<https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#Setup-for-Appium-Test-Execution-on-a-Local-Android-device-(Emulator)>)
- [Install Android Studio](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#Install-Android-Studio)
- [Install SDK Tools](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#Install-SDK-Tools)
- [Setup Environment Variables - Java Home, Android Home](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#Set-up-Environment-Variables)
- [Setup Appium inspector](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#APPIUM-INSPECTOR)
- [Setup Android Emulator](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#Setting-up-Android-Emulator)
- [Handling Geo Blocking - Android](<https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#Handling-Geo-Blocking-(Android)>)
- [Running Android Tests Locally](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#Running-an-Appium-Test-Case-locally)

##### FireTV/AndroidTV Installation

---

#### iOS Installation

---

Local Setup is not necessary for development but can be useful to speed up development times.

- Setup Appium for local ios execution following instructions [here](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#Setup-for-Appium-Test-Execution-on-a-Local-iOS-device)
- [Setup Xcode and webdriver agent](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#Setting-up-Xcode-and-Install-WebDriverAgent)
- [Setup Appium inspector](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#APPIUM-INSPECTOR)
- [Handling GeoBlocking (iOS)](<https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#Handling-Geo-Blocking-(iOS)>)
- [Run iOS tests locally](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#%5BiOS%5D---Running-an-Appium-Test-Case-locally)
- [Build and download app for ios simulator](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#Build-and-Download-.app-for-iOS-simulator)

---

##### tvOS Installation

---

#### Web Installation

---

---

#### Suitest Installation

---

##### Roku Installation

##### Samsung Installation

##### LG Installation

##### Xbox Installation

### JS Standards

---

Our standards for linting, unit tests and threshold tests can be found [here](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3446211946/Javascript+standards)

#### JS Styleguide

We follow the airbnb/js style guide which can be found [here](https://github.com/airbnb/javascript)

#### JS Doc

## TODO

### Running

---

#### From Command Line

---

#### Command Line - Jake tasks

Jake tasks are the recommended way of executing test scripts in parallel. They leveraged by our `entrypoint.sh` script and orange dot pipelines. This allows our pipelines to have a common interface to execute tests across teams.

###### How tasks are created

Test runs can be triggered from the command line by using Jake tasks.
Jake tasks are programmatically made in the `jakefile.js` file. Every Product folder under `projects` is created as a namespace, every `client` folder under the product is a task.

For the following project structure:

```bash
── projects
│   ├── ATVE
│   │   ├── roku
│   │   ├── samsung
│   │   └── xbox
│   └── DTC
│       ├── android
│       ├── features
│       ├── ios
│       ├── lg
│       ├── roku
│       ├── samsung
│       ├── web
│       └── xbox
```

###### How to check available tasks

The following tasks will be created:

```bash
jake ATVE:roku[...features]                                       # ATVE roku
jake ATVE:samsung[...features]                                    # ATVE samsung
...
...
jake BEAM:android[...features]                                    # BEAM android
jake BEAM:appletv[...features]                                    # BEAM appletv
jake BEAM:firetab[...features]                                    # BEAM firetab
jake BEAM:ios[...features]                                        # BEAM ios
jake BEAM:lg[...features]                                         # BEAM lg
...
...
jake DTC:android[...features]                                     # DTC android
jake DTC:androidtv[...features]                                   # DTC androidtv
jake DTC:appletv[...features]                                     # DTC appletv
jake DTC:firetab[...features]                                     # DTC firetab
jake DTC:firetv[...features]                                      # DTC firetv
jake DTC:ios[...features]                                         # DTC ios
...
...
jake headspin:uploadedApks                                        # HeadSpin-Appium: Gets list of uploaded apk(s)
jake headspin:uploadApk[filePath]                                 # HeadSpin-Appium: Upload apk
jake headspin:deleteApk[apkAppID]                                 # HeadSpin-Appium: Delete apk
jake headspin:uploadedApkPackageNames                             # HeadSpin-Appium: List all uploaded APKs' package names
jake headspin:apkAppInfo[apkAppID]                                # HeadSpin-Appium: APK's app information
jake headspin:listAllAdbDevicesByModel[deviceModel]               # HeadSpin-Appium: List all ADB devices by model
jake headspin:installApk[deviceID,apkAppID]                       # HeadSpin-Appium: Install apk on device
jake headspin:uninstallApk[deviceID,packageName]                  # HeadSpin-Appium: Uninstall apk-package on device
jake headspin:installApkOnAllAndroidTvDevices[apkAppID]           # HeadSpin-Appium: Install apk on all Android TV device
jake headspin:installApkOnAllFireTabDevices[apkAppID]             # HeadSpin-Appium: Install apk on all Fire Tab device
jake headspin:installApkOnAllFireTvDevices[apkAppID]              # HeadSpin-Appium: Install apk on all Fire Tv device
jake headspin:uninstallApkOnAllAndroidTvDevices[packageName]      # HeadSpin-Appium: Uninstall apk-package on all Android TV device
jake headspin:uninstallApkOnAllFireTabDevices[packageName]        # HeadSpin-Appium: Uninstall apk-package on all Fire Tab device
jake headspin:uninstallApkOnAllFireTvDevices[packageName]         # HeadSpin-Appium: Uninstall apk-package on all Fire Tv device
jake headspin:uploadedIpas                                        # HeadSpin-Appium: Gets list of uploaded ipa(s)
jake headspin:uploadIpa[filePath]                                 # HeadSpin-Appium: Upload ipa
jake headspin:deleteIpa[ipaAppID]                                 # HeadSpin-Appium: Delete ipa
jake headspin:uploadedIpaBundleIdentifiers                        # HeadSpin-Appium: List all uploaded IPAs' bundle identifiers
jake headspin:ipaAppInfo[ipaAppID]                                # HeadSpin-Appium: IPA's app information
jake headspin:listAlliDevicesByModel[deviceModel]                 # HeadSpin-Appium: List all i-devices by model 'AppleTV'
jake headspin:installIpa[deviceID,ipaAppID]                       # HeadSpin-Appium: Install ipa on device
jake headspin:uninstallIpa[deviceID,ipaAppID]                     # HeadSpin-Appium: Uninstall Ipa on device
jake headspin:installIpaOnAllAppleTvDevices[ipaAppID]             # HeadSpin-Appium: Install ipa on all Apple TV device
jake headspin:uninstallIpaOnAllAppleTvDevices[ipaAppID]           # HeadSpin-Appium: Uninstall ipa app on all Apple TV device
jake headspin:uploadAppWithTag[filePath,appTag]                   # HeadSpin-Appium: Upload app (apk/ipa) with tag
...
jake utils:clean_logs                                             # Empties the logs directory
...
jake utils:report                                                 # Create Cucumber Report
```

You can see all available jake tasks by running `npx jake --tasks` or `npx jake -t` from the command line

###### Checking underlying cucumber commands

When running a jake task you will be able to see the cucumber CLI command that is being programatically created in your console logs. If you are facing issues with your execution try running the underlying cucumber command directly to verify the cucumber-js commands are made correctly.

```bash
⋊> ~/D/D/gqa-automation-core on github_actions ⨯ npx jake DTC:android                                               17:37:59
Starting 'DTC:android'...
exeucuting command:
npx cucumber-js /Users/mswiss/Documents/Discovery/gqa-automation-core/projects/DTC/android/features/*
--parallel 0
--require-module /Users/mswiss/Documents/Discovery/gqa-automation-core/cucumber.js
```

#### Command Line - Cucumber CLI

You can also run your tests directly using cucumber CLI

```bash
npx cucumber-js /Users/mswiss/Documents/Discovery/gqa-automation-core/projects/DTC/android/features/*
--parallel 0
--require-module /Users/mswiss/Documents/Discovery/gqa-automation-core/cucumber.js
```

#### Command Line - Commits

###### How to commit

- We have a pre commit hook to lint the commits to comply with [conventional commits](https://www.conventionalcommits.org/en/v1.0.0/) specifications.
- We use [commitlint](https://github.com/conventional-changelog/commitlint/tree/master/@commitlint/config-conventional) to perform the linting

#### From Github Actions

Test runs for your branch can be executed via github actions using the `Run Tests` job. Instructions can be found [here](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3307374342/Triggering+builds+from+github+actions)

#### Orange Dot Integration

Tests can be integrated into your build and deploy pipeline for your external repo. Instructions can be found [here](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3493267787/Invoking+Test+Suites+from+Build+Deploy+pipelines)

#### Release Tooling Event Bus

TODO

### Reporting

---

#### TestRail

TODO

#### ReportPortal

There are two methods for uploading reports to ReportPortal with varying client support.
| Method | Supports | Description | Flag |
| ----------- | ----------- | --------- | ------ |
| File Upload | STBT and non-STBT clients | Uploads test results at the end of a test execution. Note - reports will not contain test steps or tags | RP_ENABLE=['true / false'] |
| Reporting Agent | non-STBT clients only | Uploads test results during the course of an execution. Provides rich test data reporting including test steps, tags, re-runs, and screenshots | RP_AGENT_REPORTING=['true / false']

Additional onboarding documentation can be found [here](https://wbdstreaming.atlassian.net/wiki/spaces/GQA/pages/108561173/Report+Portal+Onboarding)

#### HTML Reports

Test results will be available in a `./results` directory once a test run is complete. This will include:

```
  -results
    --client_report.html
    --json_report.json
    --client_result.xml
    --client_result.zip
```

---

### Patterns

---

#### Project Layout

- [Unified Automation Framework : Workflow](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3640623852/Unified+Automation+Framework+Adding+new+scenario+-+workflow)

#### Locator Definitions

- [Locator Definitions - Object repository](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3640623852/Unified+Automation+Framework+Adding+new+scenario+-+workflow#Object-repository)

#### Best Practices

- [Best Practices](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/2919762124/Coding)

#### Debugging

- [Visual studio code - Debugging](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3640623852/Unified+Automation+Framework+Adding+new+scenario+-+workflow#Visual-studio-code---Debugging)

#### Configuring IDE Debugger

- [Configure Appium inspector with Browserstack](https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3635707980/GQA-Core+Local+Setup+for+Appium+Test+Execution#Use-Appium-Inspector-along-with-BrowserStack)

---

#### Git remote reset

##### Checking for ssh setup

`git remote -v` will give you an output showing the repo with a `git@github.com:` prefix.

Example
![Screen Shot 2022-07-26 at 11 57 04 AM](https://user-images.githubusercontent.com/1794666/181053468-a3623a4f-a846-4fe8-8f25-76e88283c53a.png)

If you see `origin https://github.com` please follow the instructions [here](https://docs.github.com/en/get-started/getting-started-with-git/managing-remote-repositories) to modify your remote settings

---

### Frequently Asked Questions

---

- Arkose

### Headspin Execution

Please provide details for all the parameters listed below to execute on headspin using Suitest.

- `IS_HEADSPIN_SUITEST`: Set it as true to execute on headspin else false for local execution.
- `PARALLEL`: Set the number for parallel threads. Make sure number should match with remoteDevices.json file count for the specific region. Ex: PARALLEL=3 will run on 2 threads. Max limit is 5.
- `SUITEST_TOKEN_KEY`: Suitest Token ID/Key
- `SUITESTS_TOKEN_PASSWORD`: Suitest Token Password
- `SUITEST_APP_CONFIG_ID`: App config id you would like to run a test against
- `SUITEST_LOG_LEVEL`: Log level defined for Suitest logs, debug value recommended.
- `SUITEST_DEVICE_ID`: suitest id of your local device, used for local execution then set IS_HEADSPIN_SUITEST = false
- `GEO`: country code used to define the region in which devices in Headspin will be located, refer to devices.json file. This is also Required for getting the data from yml files
- `DEVICE`: The Device to ensure which pageobject to fetch for execution while execution(eg. 'SAMSUNG','XBOX','LG' or 'ROKU')
- `MODEL`: Here we provide the Device Model Year so that we can handle the keyboard operations from our code. (eg. "samsung21" or "lg")
- `ENABLE_REGIONAL_ROUTING`: (true/false) Enable the Regional Routing feature to automatically tunnel devices to a specified `GEO`

- Follow this [wiki guide](https://github.com/discovery-digital/disco-suitest/wiki/Suitest:-Setup) which goes through the process of obtaining each value in this file. Note: Make sure not to add comments into this file, they will create parsing issues.

For more details on Suitest API and SDK, the following links are official Suitest docs which are very helpful.

- https://the.suite.st/preferences/api
- https://the.suite.st/preferences/control-units

`.env` Enviromental variables used in the project

- `HS_TOKEN` Headspin token used for doing any API calls to the Headspin APIs. It can be obtained from the [settings page](https://ui-dev.headspin.io/mysettings).

---

### Support Model

---
