const { namespace, task, desc } = require('jake');
const { paths, configureEnvVars } = require('./utils');
const {
  uploadedApks,
  uploadedIpas,
  uploadApk,
  uploadIpa,
  deleteApk,
  deleteIpa,
  uploadedApkPackageNames,
  uploadedIpaBundleIdentifiers,
  apkAppInfo,
  listAllAdbDevicesByModel,
  installApk,
  uninstallApk,
  installApkOnAllAndroidTvDevices,
  installApkOnAllFireTabDevices,
  installApkOnAllFireTvDevices,
  uninstallApkOnAllAndroidTvDevices,
  uninstallApkOnAllFireTabDevices,
  uninstallApkOnAllFireTvDevices,
  ipaAppInfo,
  listAlliDevicesByModel,
  installIpa,
  uninstallIpa,
  installIpaOnAllAppleTvDevices,
  uninstallIpaOnAllAppleTvDevices,
  uploadAppWithTag,
} = require('../support/headspinAppiumHelpers');

/* checked in utils/configureEnvVars */
/* istanbul ignore next */
const createTask = () => {
  namespace('headspin', () => {
    desc('Sets up .env file with headspin environment variables');
    task('setup', () => configureEnvVars(paths.env, paths.envShadow));

    desc('HeadSpin-Appium: Gets list of uploaded apk(s)');
    task('uploadedApks', () => uploadedApks());

    desc('HeadSpin-Appium: Upload apk');
    task('uploadApk', async (filePath) => {
      if (filePath) {
        await uploadApk(filePath);
      } else {
        throw new Error(
          "Needs valid file path!!!\n npx jake headspin:uploadApk['filePath']",
        );
      }
    });

    desc('HeadSpin-Appium: Delete apk');
    task('deleteApk', async (apkAppID) => {
      if (apkAppID) {
        await deleteApk(apkAppID);
      } else {
        throw new Error(
          "Needs valid apk app ID!!!\n npx jake headspin:deleteApk['apkAppID']",
        );
      }
    });

    desc("HeadSpin-Appium: List all uploaded APKs' package names");
    task('uploadedApkPackageNames', () => uploadedApkPackageNames());

    desc("HeadSpin-Appium: APK's app information");
    task('apkAppInfo', async (apkAppID) => {
      if (apkAppID) {
        await apkAppInfo(apkAppID);
      } else {
        throw new Error(
          "Needs valid apk app ID!!!\n npx jake headspin:apkAppInfo['apkAppID']",
        );
      }
    });

    desc('HeadSpin-Appium: List all ADB devices by model');
    task('listAllAdbDevicesByModel', async (deviceModel) => {
      if (deviceModel) {
        await listAllAdbDevicesByModel(deviceModel);
      } else {
        throw new Error(
          "Needs device model!!!\n npx jake headspin:listAllAdbDevicesByModel['deviceModel']",
        );
      }
    });

    desc('HeadSpin-Appium: Install apk on device');
    task('installApk', async (deviceID, apkAppID) => {
      if (deviceID && apkAppID) {
        await installApk(deviceID, apkAppID);
      } else {
        throw new Error(
          `Needs device ID and apk app ID!!!\n npx jake headspin:installApk['deviceID','apkAppID']`,
        );
      }
    });

    desc('HeadSpin-Appium: Uninstall apk-package on device');
    task('uninstallApk', async (deviceID, packageName) => {
      if (deviceID && packageName) {
        await uninstallApk(deviceID, packageName);
      } else {
        throw new Error(
          `Needs device ID and apk package name!!!\n npx jake headspin:uninstallApk['deviceID','packageName']`,
        );
      }
    });

    desc('HeadSpin-Appium: Install apk on all Android TV device');
    task('installApkOnAllAndroidTvDevices', async (apkAppID) => {
      if (apkAppID) {
        await installApkOnAllAndroidTvDevices(apkAppID);
      } else {
        throw new Error(
          `Needs apk app ID!!!\n npx jake headspin:installApkOnAllAndroidTvDevices['apkAppID']`,
        );
      }
    });

    desc('HeadSpin-Appium: Install apk on all Fire Tab device');
    task('installApkOnAllFireTabDevices', async (apkAppID) => {
      if (apkAppID) {
        await installApkOnAllFireTabDevices(apkAppID);
      } else {
        throw new Error(
          `Needs apk app ID!!!\n npx jake headspin:installApkOnAllFireTabDevices['apkAppID']`,
        );
      }
    });

    desc('HeadSpin-Appium: Install apk on all Fire Tv device');
    task('installApkOnAllFireTvDevices', async (apkAppID) => {
      if (apkAppID) {
        await installApkOnAllFireTvDevices(apkAppID);
      } else {
        throw new Error(
          `Needs apk app ID!!!\n npx jake headspin:installApkOnAllFireTvDevices['apkAppID']`,
        );
      }
    });

    desc('HeadSpin-Appium: Uninstall apk-package on all Android TV device');
    task('uninstallApkOnAllAndroidTvDevices', async (packageName) => {
      if (packageName) {
        await uninstallApkOnAllAndroidTvDevices(packageName);
      } else {
        throw new Error(
          `Needs apk package name!!!\n npx jake headspin:uninstallApkOnAllAndroidTvDevices['packageName']`,
        );
      }
    });

    desc('HeadSpin-Appium: Uninstall apk-package on all Fire Tab device');
    task('uninstallApkOnAllFireTabDevices', async (packageName) => {
      if (packageName) {
        await uninstallApkOnAllFireTabDevices(packageName);
      } else {
        throw new Error(
          `Needs apk package name!!!\n npx jake headspin:uninstallApkOnAllFireTabDevices['packageName']`,
        );
      }
    });

    desc('HeadSpin-Appium: Uninstall apk-package on all Fire Tv device');
    task('uninstallApkOnAllFireTvDevices', async (packageName) => {
      if (packageName) {
        await uninstallApkOnAllFireTvDevices(packageName);
      } else {
        throw new Error(
          `Needs apk package name!!!\n npx jake headspin:uninstallApkOnAllFireTvDevices['packageName']`,
        );
      }
    });

    desc('HeadSpin-Appium: Gets list of uploaded ipa(s)');
    task('uploadedIpas', () => uploadedIpas());

    desc('HeadSpin-Appium: Upload ipa');
    task('uploadIpa', async (filePath) => {
      if (filePath) {
        await uploadIpa(filePath);
      } else {
        throw new Error(
          "Needs valid file path!!!\n npx jake headspin:uploadIpa['filePath']",
        );
      }
    });

    desc('HeadSpin-Appium: Delete ipa');
    task('deleteIpa', async (ipaAppID) => {
      if (ipaAppID) {
        await deleteIpa(ipaAppID);
      } else {
        throw new Error(
          "Needs valid ipa app ID!!!\n npx jake headspin:deleteIpa['ipaAppID']",
        );
      }
    });

    desc("HeadSpin-Appium: List all uploaded IPAs' bundle identifiers");
    task('uploadedIpaBundleIdentifiers', () => uploadedIpaBundleIdentifiers());

    desc("HeadSpin-Appium: IPA's app information");
    task('ipaAppInfo', async (ipaAppID) => {
      if (ipaAppID) {
        await ipaAppInfo(ipaAppID);
      } else {
        throw new Error(
          "Needs valid ipa app ID!!!\n npx jake headspin:ipaAppInfo['ipaAppID']",
        );
      }
    });

    desc("HeadSpin-Appium: List all i-devices by model 'AppleTV'");
    task('listAlliDevicesByModel', async (deviceModel) => {
      if (deviceModel) {
        await listAlliDevicesByModel(deviceModel);
      } else {
        throw new Error(
          "Needs device model!!!\n npx jake headspin:listAlliDevicesByModel['deviceModel']",
        );
      }
    });

    desc('HeadSpin-Appium: Install ipa on device');
    task('installIpa', async (deviceID, ipaAppID) => {
      if (deviceID && ipaAppID) {
        await installIpa(deviceID, ipaAppID);
      } else {
        throw new Error(
          `Needs device ID and ipa app ID!!!\n npx jake headspin:installIpa['deviceID','ipaAppID']`,
        );
      }
    });

    desc('HeadSpin-Appium: Uninstall Ipa on device');
    task('uninstallIpa', async (deviceID, ipaAppID) => {
      if (deviceID && ipaAppID) {
        await uninstallIpa(deviceID, ipaAppID);
      } else {
        throw new Error(
          `Needs device ID and ipa app ID!!!\n npx jake headspin:uninstallIpa['deviceID','ipaAppID']`,
        );
      }
    });

    desc('HeadSpin-Appium: Install ipa on all Apple TV device');
    task('installIpaOnAllAppleTvDevices', async (ipaAppID) => {
      if (ipaAppID) {
        await installIpaOnAllAppleTvDevices(ipaAppID);
      } else {
        throw new Error(
          `Needs ipa app ID!!!\n npx jake headspin:installIpaOnAllAppleTvDevices['ipaAppID']`,
        );
      }
    });

    desc('HeadSpin-Appium: Uninstall ipa app on all Apple TV device');
    task('uninstallIpaOnAllAppleTvDevices', async (ipaAppID) => {
      if (ipaAppID) {
        await uninstallIpaOnAllAppleTvDevices(ipaAppID);
      } else {
        throw new Error(
          `Needs ipa app ID!!!\n npx jake headspin:uninstallIpaOnAllAppleTvDevices['ipaAppID']`,
        );
      }
    });

    desc('HeadSpin-Appium: Upload app (apk/ipa) with tag');
    task('uploadAppWithTag', async (filePath, appTag) => {
      if (filePath && appTag) {
        await uploadAppWithTag(filePath, appTag);
      } else {
        throw new Error(
          "Needs valid file path and app tag value!!!\n npx jake headspin:uploadAppWithTag['filePath','appTag']",
        );
      }
    });
  });
};

module.exports = createTask;
