const { namespace, task, desc } = require('jake');

const reporter = require('cucumber-html-reporter');
const fs = require('fs');

const {
  runtimeProject,
  runtimeGeolocation,
  runtimeDevice,
} = require('../support/runtimeConfig');

require('./utils');
require('../support/stringOverrides');

const errorMessageHtml = `<body>
  <h1>Unable to generate report</h1>
  <h2>
    The results file is empty - please check the failure in the test run task.
  </h2>
</body>
`;

/**
 * Creates a Jake task to generate a Cucumber report.
 *
 * @param {boolean} launchReport - If `true`, will launch the report after report creation; defaults to `true`
 */
function createTask(launchReport = true) {
  namespace('utils', () => {
    desc('Create Cucumber Report');
    task('report', () => {
      const device = runtimeDevice();
      const reportTime = `${new Date()}`;
      const reportConfig = {
        theme: 'bootstrap',
        jsonFile: 'results/json_report.json',
        output: `results/${device}_report.html`,
        reportSuiteAsScenarios: true,
        scenarioTimestamp: true,
        launchReport,
        metadata: {
          'Report time': reportTime,
          'Send TestRail Results': process.env.TESTRAIL_SEND_RESULTS || false,
          Project: runtimeProject(),
          Tags: process.env.CUCUMBER_TAG || 'unset',
          Device: device,
          Region: runtimeGeolocation(),
        },
      };

      const jsonFile = fs.readFileSync(reportConfig.jsonFile);

      if (jsonFile.length === 0) {
        fs.writeFileSync(reportConfig.output, errorMessageHtml);

        throw new Error(
          `${reportConfig.jsonFile} is empty - unable to generate report`.RED_BOLD(),
        );
      }

      reporter.generate(reportConfig);
    });
  });
}

module.exports = createTask;
