const { namespace, task, desc } = require('jake');
const path = require('path');
const fs = require('fs');
const { paths, configureEnvVars, hiddenFileFilter } = require('./utils');
const suitest = require('../support/suitest');
const { logger } = require('../support/logger');

const createTask = () => {
  namespace('suitest', () => {
    desc('Sets up .suitestrc file with environment variables');
    task('setup', () =>
      configureEnvVars(paths.suitestrc, paths.suitestrcShadow),
    );

    desc('Get available devices in Suitest');
    task('devices', async () => {
      const { values, errorType } = await suitest.fetchAPI('devices?limit=100');

      if (errorType) {
        logger.error('Error with API call:\n\t', errorType);
      } else {
        values.forEach((device) => logger.log(device));
      }
    });

    desc('Get all apps uploaded in Suitest');
    task('apps', async () => {
      const { values, errorType } = await suitest.fetchAPI('apps?limit=100');

      if (errorType) {
        logger.error('Error with API call:\n\t', errorType);
      } else {
        values.forEach((device) => logger.log(device));
      }
    });

    desc(
      "Upload build to Suitest. Specify build/package path using 'path' argument",
    );
    task('upload', (buildPath) => {
      if (fs.existsSync(buildPath)) {
        // Check if app/package exists
        const { appId, versionId, configId } = process.env;

        if (appId && versionId && configId) {
          suitest.upload(buildPath, appId, versionId, configId, 'auto');
        } else {
          throw new Error(
            'appId, versionId, configId variables have to be defined',
          );
        }
      } else {
        throw new Error('The file path you specified does not exist');
      }
    });

    desc('Upload latest downloaded build from support/build to Suitest');
    task('upload_latest', () => {
      const { appId, versionId, configId } = process.env;

      if (appId && versionId && configId) {
        const buildsDir = paths.builds;
        const builds = fs.readdirSync(buildsDir).filter(hiddenFileFilter);
        const buildPath = path.join(buildsDir, builds.pop());

        suitest.upload(buildPath, appId, versionId, configId, 'auto');
      } else {
        throw new Error(
          'appId, versionId, configId variables have to be defined',
        );
      }
    });
  });
};

module.exports = createTask;
