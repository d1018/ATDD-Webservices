// Copyright text placeholder, Warner Bros. Discovery, Inc.

/* eslint-disable no-undef,no-unused-vars, @typescript-eslint/no-unused-vars */

// jake actually import its definition into the global namespace
import * as jake from 'jake';
import { readdir, stat, readFile } from 'fs-extra';
import { join, extname } from 'path';
import { DocNode } from '@atlaskit/adf-schema';
import * as core from '@actions/core';

import { IJiraConfig } from '../lib/jira/IJiraConfig';
import { jiraDataConfig } from '../lib/jira/jiraDataHandlerConfig';
import { IJiraTestFailureData } from '../lib/jira/IJiraTestFailureData';
import { logger } from '../support/logger';
import { readIntFromEnv } from '../support/runtimeConfig';
import {
  initJiraConfig,
  createJiraBugDescriptionJiraDocNode,
  createListItemCodeBlockNode,
} from '../lib/jira/jiraCucumberDataHandler';

const { isFeatureFlagEnabled } = require('../support/runtimeConfig');

const { JiraAPI } = require('../lib/jira/jiraAPI');

// be default we limit ourselves to file up to certain number of bugs per execution to
// prevent creating excessive amount of JIRA bugs!
// user needs to specify a "JIRA_MAX_NEW_BUGS_ALLOWED_PER_EXECUTION" env var to override this limit
// if they choose to
const maxNewBugsAllowed: number = readIntFromEnv(
  process.env.JIRA_MAX_NEW_BUGS_ALLOWED_PER_EXECUTION || '',
  5,
);

// this is needed for now until the JIRA API is converted to TypeScript
interface IJiraAPI {
  searchIssue: (params: {
    hash: string;
    excludedStatus: string[];
  }) => { key: string; url: string }[];
  updateIssue: (
    issueId: string,
    params: {
      // eslint-disable-next-line @typescript-eslint/naming-convention
      customfield_10202: string;
    },
  ) => { key: string; url: string }[];
  commentIssue: (issueId: string, node: DocNode) => void;
  createIssue: (params: {
    epic: string;
    summary: string;
    description: DocNode;
    customizePayloadFunc: (arg: object) => object;
    priority: string;
  }) => { key: string; url: string };
}

interface IGHASummaryTableCell {
  header: boolean;
  data: string;
}

interface IProcessFailureDataResult {
  /** output of the processing */
  outcome: 'NEW' | 'COMMENT' | 'OVER_LIMIT' | 'ERROR';
  /** url of the bug that is either created or commented on; valid only if outcome is NEW or COMMENT */
  bugUrl?: string;
  /** error when processing the failure data; set only when outcome is OVER_LIMIT or ERROR */
  errMsg?: string;
}

// create a GHA Summart table cell based off data and its data type
const createSummaryTableCell = (
  headerText: string,
  tableData: string[],
  dataType: 'link' | 'text',
): IGHASummaryTableCell[][] => {
  const header = [
    {
      header: true,
      data: headerText,
    },
  ];
  const rows = tableData.map((data) => [
    {
      header: false,
      data: dataType === 'link' ? `<a href="${data}">${data}</a>` : data,
    },
  ]);

  return [header, ...rows];
};
/**
 * create a blob of text (with embedeed hyperlink for bug)
 * to be displayed in GitHub Action workflow summary page
 *
 * @param newBugs - array of text that contains new bug JIRA link
 * @param existingBugs - array of text that contains existing bug JIRA link
 */
const createSummaryForGitHubAction = async (
  newBugs: string[],
  existingBugs: string[],
  skippedFiles: string[],
  errFiles: string[],
): Promise<void> => {
  // generate a summary block in GitHub Action result page
  // reference: https://github.blog/2022-05-09-supercharging-github-actions-with-job-summaries/
  await core.summary
    .addHeading('Bug summary:')
    .addTable(
      createSummaryTableCell(
        `Number of new bug(s) filed: ${newBugs.length}`,
        newBugs,
        'link',
      ),
    )
    .addBreak()
    .addTable(
      createSummaryTableCell(
        `Number of existing bug(s) repro'ed: ${existingBugs.length}`,
        existingBugs,
        'link',
      ),
    )
    .addBreak()
    .addTable(
      createSummaryTableCell(
        `Number of new bug(s) NOT filed for these file(s) due to bug creation limit: ${skippedFiles.length}`,
        skippedFiles,
        'text',
      ),
    )
    .addTable(
      createSummaryTableCell(
        `Number of file(s) processed with error detected: ${errFiles.length}`,
        errFiles,
        'text',
      ),
    )
    .addList([
      `Note: this session is allowed to create a max of ${maxNewBugsAllowed} bug(s) per execution.`,
    ])
    .write();
};

/**
 * create a blob of text for our bug summary
 *
 * @param newBugs - array of text that contains new bug JIRA link
 * @param existingBugs - array of text that contains existing bug JIRA link
 */
const createSummary = async (
  newBugs: string[],
  existingBugs: string[],
  skippedFiles: string[],
  errFiles: string[],
): Promise<void> => {
  const bugSummary = ['', 'bug Summary:'];

  bugSummary.push('-------------------------');
  bugSummary.push(`${newBugs.length} new bug(s) created:`);
  newBugs.forEach((bug) => {
    bugSummary.push(bug);
  });
  bugSummary.push('');
  bugSummary.push(`${existingBugs.length} existing bug(s) detected:`);
  existingBugs.forEach((bug) => {
    bugSummary.push(bug);
  });
  bugSummary.push('');
  bugSummary.push(
    `${skippedFiles.length} new bug(s) NOT filed for these file(s) due to bug creation limit:`,
  );
  skippedFiles.forEach((file) => {
    bugSummary.push(file);
  });
  bugSummary.push('');
  bugSummary.push(
    `${errFiles.length} file(s) processed with error(s) detected:`,
  );
  errFiles.forEach((file) => {
    bugSummary.push(file);
  });
  bugSummary.push('');
  bugSummary.push('-------------------------');
  bugSummary.push(
    `note: this session is allowed to create a max of ${maxNewBugsAllowed} bug(s) per execution.`,
  );
  logger.log(bugSummary.join('\n'));

  // generate a summary block in GitHub Action result page if we are in GHA env
  if (process.env.CI && process.env.GITHUB_ACTION && process.env.RUNNER_TEMP) {
    await createSummaryForGitHubAction(
      newBugs,
      existingBugs,
      skippedFiles,
      errFiles,
    );
  }
};

/**
 * return a function that essentially wraps the user supplied callback specified
 * in the config file (jiraConfig.customizeNewBugPayload() function)
 *
 * note: it does the following:
 * 1. call the the user supplied callback if it's a valid function
 *
 * if it's valid callback function:
 * 1. processes the result from the callback
 * 2. if the return value is valid, we process it and use the new
 *    payload and put the extra note text to the JIRA payload as well
 *
 * if it is NOT a valid function:
 * 1. we simply ignore it and returns our current Jira payload object as if the callback is a no op
 *
 *
 * @param jiraConFig - Jira config object
 * @returns a function callback that wraps the user supplied callback.
 */
const createJiraCallback = (
  jiraConFig: IJiraConfig,
  // eslint-disable-next-line arrow-body-style
): ((arg: object) => object) => {
  return (jiraPayload: object): object => {
    // really make sure it's in fact a function
    if (typeof jiraConFig.customizeNewBugPayload === 'function') {
      const customizeResult = jiraConFig.customizeNewBugPayload(jiraPayload);

      if (Array.isArray(customizeResult) && customizeResult.length === 2) {
        // we get a valid result form the user callback
        const newPayload = customizeResult[0];
        const extraNote = customizeResult[1];

        if (
          extraNote &&
          newPayload &&
          newPayload.description &&
          Array.isArray(newPayload.description.content)
        ) {
          // insert an extra note field if it's returned from the config file
          const bulletList = newPayload.description.content.find(
            (node: { type: string }) => node.type === 'bulletList',
          );

          if (bulletList) {
            // append to the bug description
            bulletList.content.push(
              createListItemCodeBlockNode(
                jiraDataConfig.additionalNoteHeader,
                extraNote,
              ),
            );
          }
        }
        // use the customized Jira payload
        return newPayload;
      }
    }
    // customizeNewBugPayload isn't a valid function object
    // ignore whatever the user pass us
    logger.debug('customizeNewBugPayload is NOT a valid function!');
    return jiraPayload;
  };
};

/**
 * process a json file that contain test failure data and either:
 * - file new bug if hash Id is NOT found in JIRA
 * - put new repo info as a comment to an existing bug if hash Id is found in JIRA
 *
 * @param jiraConfigObj - JiraConfigObject
 * @param jiraWrapper - JiraAPI wrapper class
 * @param failureJsonFile - full file path to a json file capturing test failure data
 * @param shouldCreateNewBug -
 * true: create new bug for hash id that doesn't match any existing bugs in JIRA
 * false: skip creating new bug even for hash id that doesn't match any existing bugs in JIRA (this is used for test purpose)
 * see usage of "MAX_NEW_BUGS_ALLOWED_PER_EXECUTION"
 * @returns outcome of the processing
 */
const processFailureJsonFile = async (
  jiraConfigObj: IJiraConfig,
  jiraWrapper: IJiraAPI,
  failureJsonFile: string,
  shouldCreateNewBug: boolean,
): Promise<IProcessFailureDataResult> => {
  const { epic, logDir, inactiveBugStatus } = jiraConfigObj;
  const fullFilePath = join(logDir, failureJsonFile);

  try {
    logger.log(`processing "${fullFilePath}"...`);
    if (!(await stat(fullFilePath)).isFile()) {
      const errMsg = `"${fullFilePath}" is not a file; ignore!`;

      logger.error(errMsg);
      return { outcome: 'ERROR', errMsg };
    }

    // guard in case we have non-json files in the directory
    if (extname(fullFilePath) !== '.json') {
      const errMsg = `"${fullFilePath}" is not a json file; ignore!`;

      logger.error(errMsg);
      return { outcome: 'ERROR', errMsg };
    }

    const jiraJsonObj: IJiraTestFailureData = JSON.parse(
      await readFile(fullFilePath, 'utf8'),
    );

    // we don't want to process or log raw data
    delete jiraJsonObj.raw;

    const excludedStatus = Array.isArray(inactiveBugStatus)
      ? inactiveBugStatus
      : ['DONE', 'CANCELLED'];

    const result: unknown[] = await jiraWrapper.searchIssue({
      hash: jiraJsonObj.bugId,
      // these status mean the bug(s) no longer "open"
      // so exclude them
      excludedStatus,
    });

    if (Array.isArray(result) && result.length) {
      // we find existing issue with the bugId
      // modify it with new comment
      logger.log(result);
      logger.log(`number of issue(s) found: ${result.length}`);

      // always assume the first one is the one and we will put comment on it
      const issue = result[0];

      await jiraWrapper.commentIssue(
        issue.key,
        createJiraBugDescriptionJiraDocNode({
          failureData: jiraJsonObj,
          newBug: false,
        }),
      );

      logger.log(`"${issue.key}" is updated with the new repro info!`);

      return { outcome: 'COMMENT', bugUrl: issue.url };
    }

    // we did not find any existing issue with the bugId
    // we will go ahead and create one

    // function callback that wraps the user supplied callback from the jira config
    const customizePayloadFunc = createJiraCallback(jiraConfigObj);

    // note on JIRA limit: {"summary":"Summary can't exceed 255 characters."}
    const summary = [
      `[${jiraJsonObj.device}] Test Failed!`,
      `Feature: "${jiraJsonObj.featureName}"`,
      `Scenario: "${jiraJsonObj.scenarioName}"`,
    ]
      .join(' ')
      .trim();

    const description = createJiraBugDescriptionJiraDocNode({
      failureData: jiraJsonObj,
      newBug: true,
    });

    if (shouldCreateNewBug) {
      const createResult = await jiraWrapper.createIssue({
        customizePayloadFunc,
        epic,
        summary,
        description,
        // final bug priority is from the Json object loadfrom the the Json file
        priority: jiraJsonObj.priority,
      });

      logger.log(createResult);

      const updateResult = await jiraWrapper.updateIssue(createResult.key, {
        // eslint-disable-next-line @typescript-eslint/naming-convention
        customfield_10202: jiraJsonObj.bugId,
      });

      logger.log(updateResult);
      return { outcome: 'NEW', bugUrl: createResult.url };
    }

    const errMsg = `skipping file bug for this file: ${fullFilePath}`;

    logger.error(errMsg);
    return { outcome: 'OVER_LIMIT', errMsg };
  } catch (ex) {
    const errMsg = `failed to process JSON file from ${fullFilePath}`;

    logger.error(errMsg);
    logger.error(ex);
    return { outcome: 'ERROR', errMsg };
  }
};

/**
 * Creates a Jake task to process the JIRA JSON files specified in the config folder and file JIRA bugs
 * after some auto triage
 *
 * @param jiraConfigFile - File path to the JIRA config script file
 */
// eslint-disable-next-line import/prefer-default-export
export const createJiraTask = (jiraConfigFile?: string): void => {
  namespace('utils', () => {
    desc('auto bug filing for test failures');
    task('autoJiraBug', async () => {
      // no ops if feature flag is set
      // note: we don't mark the task fail coz we don't want this
      // Jake task to fail a GHA workflow even when the feature flag is not set
      if (!isFeatureFlagEnabled('JIRA_AUTO_BUG_FILING')) {
        logger.warn(
          'Jira auto bug filing feature flag (JIRA_AUTO_BUG_FILING) is NOT enabled!',
        );
        logger.warn('Please retry with the feature flag set!');
        return;
      }

      // fail if config file is not specified
      if (!jiraConfigFile) {
        const msg = 'Jira config file is NOT specified!';

        logger.error(msg);

        // return an exit code of 1 to fail this Jake task
        // eslint-disable-next-line jest/no-jasmine-globals
        fail(msg, 1);
        return;
      }

      logger.log(`Jira config file: ${jiraConfigFile}`);
      process.env.JIRA_CONFIG_FILE = jiraConfigFile;
      const jiraConfigObj = await initJiraConfig();

      if (jiraConfigObj) {
        const { logDir, apiUrl, project, username, password } = jiraConfigObj;

        if (!password || !username) {
          logger.error(
            `JIRA username and password not set in the confg file: ${jiraConfigFile}`,
          );
          // eslint-disable-next-line jest/no-jasmine-globals
          fail(
            'Please retry with username and password set for JIRA connection!',
            1,
          );

          return;
        }

        let success = true;
        const newBugs: string[] = [];
        const existingBugs: string[] = [];
        const skippedFiles: string[] = [];
        const errFiles: string[] = [];

        const files = await readdir(logDir);

        logger.debug(`number of JIRA Json file found: ${files.length}`);

        const jiraWrapper = new JiraAPI({
          url: apiUrl,
          project,
          username,
          password,
        });

        // eslint-disable-next-line no-restricted-syntax
        for (const file of files) {
          // process each json file
          const { outcome, bugUrl, errMsg } = await processFailureJsonFile(
            jiraConfigObj,
            jiraWrapper,
            file,
            newBugs.length < maxNewBugsAllowed,
          );

          if (outcome === 'NEW') {
            newBugs.push(bugUrl as string);
          } else if (outcome === 'COMMENT') {
            existingBugs.push(bugUrl as string);
          } else {
            let msg = '';

            if (outcome === 'OVER_LIMIT') {
              msg = `max number of new bugs(limit:${maxNewBugsAllowed}) allowed to created per execution has reached!`;
              skippedFiles.push(file);
            } else {
              msg = `${outcome}:${errMsg}`;
              errFiles.push(file);
            }

            logger.error(msg);
            success = false;
          }
        }

        // display a summary to user (CLI and GitHub Action result page)
        await createSummary(newBugs, existingBugs, skippedFiles, errFiles);

        // mark the test fail if we find any error when trying to procss any of the JSON data file
        if (!success) {
          // eslint-disable-next-line jest/no-jasmine-globals
          fail('error detected when processing failure data files', 1);
        }
      }
    });
  });
};
