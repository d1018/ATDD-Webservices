const { namespace, task, desc } = require('jake');

const { existsSync } = require('fs');
const {
  runTestsWithCucumberAsync,
} = require('../lib/runTestsWithCucumberAsync');
const { runTestsWithStbtAsync } = require('../lib/runTestsWithStbtAsync');
const { Devices } = require('../support/remoteDevices');
const { isHeadspinSuitestMode } = require('../support/headspin');

const { paths, jakeProjects, getClients } = require(`../support/paths`);
const { getParallelThreads } = require('../support/remoteDeviceUtilities');
const { uploadZipFile, jsonToZipFile } = require('../support/rp');
const reportPortalConfig = require('../support/rpConfig');

const { getFilteredFeatures } = require('./getFilteredFeatures');
const getPlatform = require('./getPlatform');

const {
  calculateParallelThreads,
} = require('../support/remoteDeviceUtilities');

const { logger } = require('../support/logger');

const { isFeatureFlagEnabled } = require('../support/runtimeConfig');
const { ensureResultsDirectory } = require('../support/utilities');

const cloudExecution = !isFeatureFlagEnabled('LOCAL_EXECUTION');

/**
 * Provides an appropriately defaulted and wrapped list of Cucumber profiles based on the (possibly empty)
 * profiles from the Jake tasks configuration object.
 *
 * @param {*} taskConfigProfiles - The Cucumber profiles from the Jake task configuration
 * @returns {string[]} A list of Cucumber profiles with defaults applied
 */
function getDefaultedCucumberProfiles(taskConfigProfiles) {
  // Use the "default" profile if no profile is specified.
  if (!taskConfigProfiles) {
    return ['default'];
  }

  return Array.isArray(taskConfigProfiles)
    ? taskConfigProfiles
    : [taskConfigProfiles];
}

/**
 * Calculates the actual number of parallel threads on which Cucumber should execute the tests, based
 * on various environment variables and targeted platforms.
 *
 * Note on naming: this method makes use of several imported methods with similar names. `calculateParallelThreads()`
 * appears to actually calculate the number of available devices, while `getParallelThreads()` appears to actually
 * calculate the number of parallel threads for Headspin based on the number of available devices. Neither one
 * calculates the number of parallel threads for our purposes, which need to take into account both BrowserStack limitations
 * and platforms for which parallelization is not available.
 *
 * @returns {Promise<number>} The number of parallel threads on which Cucumber should execute the tests
 */
async function computeParallelThreads() {
  let parallelThreads = 0;

  if (isHeadspinSuitestMode()) {
    const devices = Devices.loadDevices();
    const devicesAvailable = await calculateParallelThreads(devices);

    parallelThreads = getParallelThreads(devicesAvailable);
  } else if (cloudExecution) {
    parallelThreads =
      process.env.PARALLEL > 10 ? 10 : process.env.PARALLEL || 1;
  }

  return parallelThreads;
}

/**
 * Processes the test results in the `./results/json_report.json` test results file, and sends them to Report Portal
 * (if the Report Portal configuration indicates that reporting is enabled).
 */
async function processTestResultsAsync() {
  if (reportPortalConfig.rp_enable === 'true') {
    if (existsSync('./results/json_report.json')) {
      const zipFilePath = jsonToZipFile(
        './results/json_report.json',
        'results',
      );

      await uploadZipFile(zipFilePath, reportPortalConfig);
    } else {
      logger.error(
        'Cannot upload test results to ResultPortal: ./results/json_report.json not found.',
      );
    }
  }
}

/**
 * Returns true if the tests are to be run on the STB-Tester platform.
 *
 * @param {string} platform - The testing platform on which the tests will be run.
 * @returns {boolean} `true` if the platform is "stbt", and `false` otherwise.
 */
function isStbt(platform) {
  return platform === 'stbt';
}

/**
 * Creates a Jake task to run the tests for `project`/`client` (with optional filtering to specific features).
 * All of the Jake tasks share the same Cucumber config file and are run under the same Cucumber profile(s), so
 * we pass those in as well.
 *
 * @param {string} project - The name of the project whose tests will be run
 * @param {string} client - The client (aka "device") type on which the tests will be run
 * @param {string} cucumberConfigFile - The path to the Cucumber config file (e.g. `cucumber.js`) that defines
 * the Cucumber profiles under which the tests will be executed
 * @param {string[]} defaultedCucumberProfiles - The Cucumber profile or profiles under which the tests should be executed
 * @param {string[]} jiraConfigFile - The path to the JIRA config file (in JS format)
 */
function createTestRunnerTask(
  project,
  client,
  cucumberConfigFile,
  defaultedCucumberProfiles,
  jiraConfigFile,
) {
  desc(`${project} ${client}`);
  task(client, async (...features) => {
    const platform = getPlatform(client);

    const projectsTreeRoot = isStbt(platform)
      ? paths.stbtProjects
      : paths.projects;

    const filteredFeatures = getFilteredFeatures(
      projectsTreeRoot,
      project,
      features,
    );

    const parallelThreads = await computeParallelThreads();

    logger.log('Executing tests with:');
    logger.log(`    cucumber profiles: ${defaultedCucumberProfiles}`);
    logger.log(`    filtered features: ${filteredFeatures}`);
    logger.log(`    parallel threads: ${parallelThreads}`);
    logger.log(`    platform: ${platform}`);
    logger.log(`    node version: ${process.version}`);

    if (jiraConfigFile) {
      logger.log(`    jiraConfig: ${jiraConfigFile}`);
      process.env.JIRA_CONFIG_FILE = jiraConfigFile;
    }

    process.env.PROJECT = project;
    process.env.DEVICE = client;
    process.env.PLATFORM = platform;

    ensureResultsDirectory();

    let isSuccess;

    try {
      const runTestsAsync = isStbt(platform)
        ? runTestsWithStbtAsync
        : runTestsWithCucumberAsync;

      isSuccess = await runTestsAsync({
        file: cucumberConfigFile,
        profiles: defaultedCucumberProfiles,
        paths: [filteredFeatures],
        parallel: parallelThreads,
        format: ['@cucumber/pretty-formatter'],
      });
    } catch (e) {
      logger.error('Exception thrown from test runner!');
      logger.error(`Exception: [${e}]`);
      throw new Error(e);
    } finally {
      const message = `Test execution completed ${
        isSuccess ? 'successfully' : 'with error(s). Please Check!'
      }`;

      logger.log(message);

      await processTestResultsAsync();
    }
  });
}

/**
 * Creates Jake namespaces for all of the projects in a projects directory (by default, `projects`). Within each namespace,
 * creates Jake tasks for each of the clients (devices) on which that project can run.
 *
 * @param {object} taskConfig - Jake task configuration object
 * @param {string} taskConfig.projectsDir - Path to the `projects` directory; defaults to `<repository_root>/projects`
 * @param {string} taskConfig.cucumberConfigFile - Path to the Cucumber configuration file for the test run;
 * see https://github.com/cucumber/cucumber-js/blob/main/docs/configuration.md#files for details of the file format
 * @param {string[]} taskConfig.cucumberProfiles - Name(s) of the Cucumber profiles under which the tests should be run;
 * @param {string[]} taskConfig.jiraConfigFile - Path to the Jira configuration file for the test run
 * can be a `string` such as 'profileName' or a `string[]` such as ['profileNameA, 'profileNameB']
 */
function createTasks(taskConfig = {}) {
  const { cucumberConfigFile, cucumberProfiles, projectsDir, jiraConfigFile } =
    taskConfig;
  const projects = projectsDir || jakeProjects;

  Object.values(projects).forEach((project) => {
    namespace(project, () => {
      const clients = getClients(project);

      Object.values(clients).forEach((client) => {
        createTestRunnerTask(
          project,
          client,
          cucumberConfigFile,
          getDefaultedCucumberProfiles(cucumberProfiles),
          jiraConfigFile,
        );
      });
    });
  });
}

module.exports = createTasks;
