const { join } = require('path');
const { existsSync } = require('fs');

/**
 * Returns the path or paths from "/" (the root directory of the machine) to the requested feature file or feature files
 * of project `projectName`. If no specific features are requested, returns a single path from "/" to the "features/"
 * folder of project `projectName`, with a terminating wildcard ("*") to indicate that all feature files in the project
 * should be included.
 *
 * @param {string} projectTreeRoot - The root directory of the tree of projects that contains the feature files.
 * @param {string} projectName - The name of the project for which to gather the requested features; this is the name of
 * a client application such as "app_hbo_max", "app_discovery_plus", or "app_hospitality".
 * @param {string} features - An array of requested features file names; if empty, return all features for the project.
 * @returns {string} A `string` containing the file path or paths from "/" (the root directory of the machine) to the
 * requested feature file or feature files, separated by spaces; or containing the path from "/" to the "features"
 * directory of the requested project `projectName`, followed by a wildcard ("*").
 */
function getFilteredFeatures(projectTreeRoot, projectName, features) {
  const featuresDir = join(projectTreeRoot, projectName, 'features');

  if (features.length === 0) {
    return join(featuresDir, '*');
  }

  return features
    .map((feature) => {
      if (feature && !existsSync(join(featuresDir, feature))) {
        throw new Error(`${feature} file does not exist`);
      }

      return join(featuresDir, feature);
    })
    .join(' ');
}

module.exports = { getFilteredFeatures };
