const { namespace, task, desc } = require('jake');
const path = require('path');
const {
  readdirSync,
  unlinkSync,
  statSync,
  rmSync,
  writeFileSync,
} = require('fs');
const {
  setEnvVars,
  fetchSSMRegions,
  hiddenFileFilter,
  paths,
} = require('./utils');
const { logger } = require('../support/logger');

const createTask = () => {
  namespace('utils', () => {
    desc('Empties the logs directory');
    task('clean_logs', () => {
      const logsDir = paths.logs;
      const logs = readdirSync(logsDir).filter(hiddenFileFilter);

      logs.forEach((log) => {
        const item = path.join(logsDir, log);

        if (statSync(item).isDirectory()) {
          rmSync(item, { recursive: true, force: true });
        } else {
          unlinkSync(item);
        }
      });
    });

    desc('Empties the builds directory');
    task('clean_builds', () => {
      const buildsDir = paths.builds;
      const builds = readdirSync(buildsDir).filter(hiddenFileFilter);

      builds.forEach((build) => unlinkSync(path.join(buildsDir, build)));
    });

    desc('Pull paramater value from AWS and set environment variables');
    task(
      'setEnvVars',
      async (environment, product, client, testType, region) => {
        logger.log('setEnvVars jake task');
        await setEnvVars(environment, product, client, testType, region);
      },
    );

    desc('Get regions supported by SSM parameters for this configuration');
    task('fetchSSMRegions', async (environment, product, client, testType) => {
      const regions = await fetchSSMRegions(
        environment,
        product,
        client,
        testType,
      );

      if (regions.length === 0) {
        throw new Error(
          `Unable to find SSM parameters with regions for ${JSON.stringify(
            {
              environment,
              product,
              client,
              testType,
            },
            null,
            2,
          )}`,
        );
      }

      // Writing to file instead of using 'echo', so I can keep those console outputs without messing up the matrix.
      writeFileSync('/tmp/regions', JSON.stringify(regions), 'utf-8');
    });
  });
};

module.exports = createTask;
