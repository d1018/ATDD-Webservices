require('dotenv').config();
require('../../support/stringOverrides');

const fs = require('fs');
const {
  SSMClient,
  GetParameterCommand,
  DescribeParametersCommand,
} = require('@aws-sdk/client-ssm');

const dotenv = require('dotenv');

const { logger } = require('../../support/logger');

/**
 * This function does pull secrets from AWS and store them into the correspoding files
 *
 * @param {string} environment target environment
 * @param {string} product target product
 * @param {string} client target client
 * @param {string} testType target test type
 * @param {string} region target country/city
 */
/* istanbul ignore next */
const setEnvVars = async (environment, product, client, testType, region) => {
  logger.log('setEnvVars aws.js');
  const regionSuffix = region === 'none' ? '' : `/${region}`;
  const paramName = `/integration-secrets/${environment}/${product}/${client}/${testType}${regionSuffix}`;

  // set envs to be used for JIRA bug auto filing
  const additionalEnvVars = [
    `${'SSM_FILE'}="${paramName}"`,
    `${'TEST_TYPE'}="${testType}"`,
    `${'TEST_ENV'}="${environment}"`,
  ];

  logger.log('Getting SSM parameter:', { paramName });

  const ssmClient = new SSMClient();
  const command = new GetParameterCommand({ Name: paramName });

  const response = await ssmClient.send(command);
  const paramValue = response.Parameter.Value;

  const lines = paramValue.split('\n');
  const vars = lines.filter(Boolean).join('\n');

  const envFile = '.env';

  fs.writeFileSync(envFile, `${vars}\n`);
  fs.appendFileSync(envFile, additionalEnvVars.join('\n'));

  dotenv.config();

  if (fs.existsSync(envFile)) {
    logger.log('success setting environment variables');
  }
};

/**
 * Queries AWS to find all SSM parameters that start with these values.
 *
 * @param {string} environment target environment
 * @param {string} product target product
 * @param {string} client target client
 * @param {string} testType target test type
 * @returns {Array} an array of regions
 */
const fetchSSMRegions = async (environment, product, client, testType) => {
  /*
   This is the element that contains the region once the parameter is split to an array, bearing in
   mind that the leading '/' makes an empty element at the start.

   For example, if the SSM parameter has this name:
    /integration-secrets/dev/dtc/roku/regression/br

   ... as an array it becomes:
    ['', 'integration-secrets', 'dev', 'dtc', 'roku', 'regression', 'br' ]
                                                                     ^-- element 6.
   */
  const regionElement = 6;

  // (NOTE: the "/" on the end is important.)
  const filter = `/integration-secrets/${environment}/${product.toLowerCase()}/${client}/${testType}/`;

  logger.log('Finding SSM parameters starting with:', { filter });

  const command = new DescribeParametersCommand({
    Filters: [
      {
        Key: 'Name',
        Option: 'BeginsWith',
        Values: [filter],
      },
    ],
  });

  const ssmClient = new SSMClient();
  const response = await ssmClient.send(command);
  const parameters = response.Parameters || [];

  if (parameters.length === 0) {
    logger.log(
      `No SSM parameters defined that start with '${filter}'`.RED_BOLD(),
    );

    return [];
  }

  const names = parameters.map(({ Name }) => Name);

  logger.log(`SSM parameters that start with '${filter}':`, { names });

  const regions = names
    .map((name) => name.split('/')[regionElement])
    .filter((region) => region.length > 0);

  if (regions.length === 0) {
    logger.log(
      `No SSM parameters that start with '${filter}' have a region element.`.RED_BOLD(),
    );

    return [];
  }

  logger.log(`Identified regions: ${regions}`.WHITE_BOLD());

  return regions;
};

module.exports = {
  setEnvVars,
  fetchSSMRegions,
};
