require('dotenv').config();
require('../../support/stringOverrides');

const { spawnSync, execSync } = require('child_process');
const fs = require('fs');
const http = require('http');
const https = require('https');
const { paths } = require('../../support/paths');
const awsUtils = require('./aws');

// We use console.log() and console.error() in this file (instead of logger.log() and logger.error()), because
// the build tools should not be logging with the same timestamps, etc. prefix as production code.
/* eslint-disable no-console */

/**
 * Fetch unfiltered list of files changed since main.
 *
 * @returns {Array} array of all files changed since main branch.
 */
/* istanbul ignore next */
const getAllChangedFiles = () => {
  try {
    let diffResult = '';

    /*
      If process.env.GITHUB_SHA is set, we're in CI: get all commited changes.
      Else, we're not in CI: get all local changes (including uncomitted).

      WARNING: use syntax that works on Windows versions of unix.
    */
    if (process.env.GITHUB_SHA) {
      diffResult = execSync(
        'git diff-tree -r --no-commit-id --name-only --compact-summary -U0 $GITHUB_SHA origin/main',
      );
    } else {
      const lsDiff = execSync('git ls-files --others --exclude-standard');
      const gitHash = execSync('git merge-base origin/main HEAD');
      const localDiff = execSync(
        `git diff --diff-filter=MAUX --name-only ${gitHash}`,
      );

      diffResult = `${lsDiff} ${localDiff}`;
    }

    return (diffResult || '').toString().split('\n');
  } catch (err) {
    throw new Error(err.output.map((item) => (item || '').toString()));
  }
};

/**
 * Fetch filtered list of files changed since main.
 *
 * @param {string} fileMatcher regex file matcher.
 * @returns {Array} array of all changed files that match 'fileMatcher'.
 */
/* istanbul ignore next */
const getFilteredChangedFiles = (fileMatcher) => {
  const files = getAllChangedFiles();

  if (files.length === 0) {
    console.log('');
    console.log('No changed files'.WHITE_BOLD());

    return files;
  }

  const filteredFiles = files
    .map((file) => file.trim())
    .filter((file) => file.match(fileMatcher))
    .filter((file) => fs.existsSync(file));

  console.log('');

  if (filteredFiles.length === 0) {
    console.log(`No changed files matching ${fileMatcher}`.WHITE_BOLD());
  } else {
    console.log(`Changed Files: ${filteredFiles}`);
  }

  return filteredFiles;
};

/**
 * Runs a specific command on changed files
 *
 * @param {string|RegExp} fileMatcher - file matcher to filter the files based on
 * @param {string} command - command to run on filtered changed files (i.e. "npx eslint")
 * @param {string} failMessage - optional message to be displayed if the command fails.
 */
/* istanbul ignore next */
const runCommandOnFileDiffs = (fileMatcher, command, failMessage = '') => {
  const files = getFilteredChangedFiles(fileMatcher);

  if (files.length === 0) {
    console.log('');
    console.log('No changed files'.WHITE_BOLD());

    return;
  }

  // We need the initial command, then an array of all parameters (incl. changed files)
  const [commandName, ...commandParams] = command.split(' ');
  const parameters = [...commandParams, ...files].filter((item) => item !== '');

  console.log('');
  console.log('COMMAND:'.WHITE_BOLD(), commandName.GREEN());
  console.log('PARAMETERS:'.WHITE_BOLD());
  parameters.map((param) => console.log(`\t${param.GREEN()}`));
  console.log('\n');

  // 'spawn' gives us stdout in color (much clearer, which helps with debugging)
  let ok = false;

  try {
    const result = spawnSync(commandName, parameters, {
      stdio: ['inherit', process.stdout, process.stderr],
      shell: true,
    });

    ok = result.status === 0;
  } catch (err) {
    console.error(err);
  }

  if (!ok) {
    console.log('');
    console.log(`${'RESULT:'.WHITE_BOLD() + ' failed'.RED()}\n`);
    console.log(failMessage.CYAN_BOLD());
    console.log('');

    throw new Error('Failed');
  }

  console.log('');
  console.log(`${'RESULT:'.WHITE_BOLD() + ' ok'.GREEN()}\n`);
  console.log('');
};

/**
 * Tests given string against hidden/dot files. Used mostly to filter out files like .DS_Store, .gitignore, etc.
 *
 * @param {string} item The input string
 * @returns {boolean} Returns whether or not there is a match in the hidden/dot files.
 */
const hiddenFileFilter = (item) => !item.match(/^\./);

const directoryFilter = (item) => {
  fs.lstatSync(item).isDirectory();
};

/**
 * Obtains environment variable based on given key
 *
 * @param {string} key the input key
 * @returns {any} returns the value of the given key
 */
const obtainValueByKey = (key) =>
  ({
    username: process.env.SUITEST_USERNAME,
    password: process.env.SUITEST_PASSWORD,
    orgId: process.env.SUITEST_ORG_ID,
    appConfigId: process.env.SUITEST_APP_CONFIG_ID,
    deviceId: process.env.SUITEST_DEVICE_ID,
    tokenKey: process.env.SUITEST_TOKEN_KEY,
    tokenPassword: process.env.SUITEST_TOKEN_PASSWORD,
    testPackId: process.env.SUITEST_TEST_PACK_ID,
  }[key] || process.env[key]);

/**
 * Configures environment variables within .suitestrc file
 *
 * @param {any} envFile the environment variables file
 * @param {any} shadowFile  the shadow file
 */
const configureEnvVars = (envFile, shadowFile) => {
  if (!fs.existsSync(envFile)) fs.copyFileSync(shadowFile, envFile);

  const vars = fs.readFileSync(shadowFile).toString().split('\n');
  // Add run-time values to non-commented variables
  const newVars = vars
    .filter((variable) => variable.length > 1)
    .filter((variable) => !variable.includes('#'))
    .filter(Boolean)
    .reduce((acc, variable) => {
      const [key, val] = variable.split('=');
      const value = obtainValueByKey(key) || val;

      return `${acc}${key}=${value}\n`;
    }, '');

  fs.writeFileSync(envFile, newVars);
};

/* Downloads a file a from a remote URL to a given file path locally
 *
 * @param {string} url Location of where the file lives. Supports http/https
 * @param {string} filePath Local directory path where the file should be downloaded to
 * @returns {Promise<object>} Meta information about file creation
 */
/* istanbul ignore next */
const downloadFile = (url, filePath) => {
  const proto = !url.charAt(4).localeCompare('s') ? https : http;

  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(filePath);
    let fileInfo = null;

    const request = proto.get(url, (response) => {
      if (response.statusCode !== 200) {
        return reject(
          new Error(`Failed to get '${url}' (${response.statusCode})`),
        );
      }

      fileInfo = {
        mime: response.headers['content-type'],
        size: parseInt(response.headers['content-length'], 10),
      };

      return resolve(response.pipe(file));
    });

    file.on('finish', () => resolve(fileInfo));
    request.on('error', (err) => fs.unlink(filePath, () => reject(err)));
    file.on('error', (err) => fs.unlink(filePath, () => reject(err)));

    request.end();
  });
};

/**
 * Checks any given number of variables to verify they exist, otherwise an error will be thrown
 *
 * @param {*} vars Variables to verify
 * @returns {void}
 */
const verifyEnvVars = (...vars) =>
  vars.forEach((variable) => {
    if (!variable) throw Error(`${variable} is not set`);
  });

/**
 * Gathers information on changed featuer files.
 *
 * @returns {string} space separated details of changed files: product client and feature files.
 */
/* istanbul ignore next */
const getChangefeatureDetails = () => {
  const files = getFilteredChangedFiles('.feature$');

  if (files.length === 0) {
    console.log('NO CHANGED FILES TO PROOCESS'.WHITE_BOLD());
    return '';
  }

  const featureFiles = files.map((file) => file.split('/').pop()).join(',');
  const firstFileParts = files[0].split('/');

  firstFileParts.shift();
  const [product, client] = firstFileParts;

  /*
   NOTE: because this is used by both node and bash scripts (the github workflows), it must return
         a space-separated list of these specific values.
   */
  return `${product} ${client} ${featureFiles}`;
};

module.exports = {
  paths,
  runCommandOnFileDiffs,
  hiddenFileFilter,
  obtainValueByKey,
  configureEnvVars,
  downloadFile,
  verifyEnvVars,
  getChangefeatureDetails,
  directoryFilter,
  ...awsUtils,
};
