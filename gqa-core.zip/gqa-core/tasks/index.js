const createUtilsTasks = require('./utilsTasks');
const createRunnerTasks = require('./runner');
const createSuitestTasks = require('./suitest');
const createHeadspinTasks = require('./headspin');
const createReportTask = require('./reportTask');
const { createJiraTask } = require('./jiraTask');

module.exports = {
  createHeadspinTasks,
  createSuitestTasks,
  createRunnerTasks,
  createUtilsTasks,
  createReportTask,
  createJiraTask,
};
