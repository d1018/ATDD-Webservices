const { runCommandOnFileDiffs } = require('./utils');

const fileMatcher = 'feature$';
const linterCommand = 'npx gherkin-lint';
const lintRulesUrl = 'https://github.com/vsiakka/gherkin-lint#available-rules';

runCommandOnFileDiffs(
  fileMatcher,
  linterCommand,
  `HINT: For help understanding the lint failures, see: ${lintRulesUrl}`,
);
