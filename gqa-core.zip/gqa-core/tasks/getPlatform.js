/**
 * Devices for which tests should be run on appium.
 */
const appiumDevices = [
  'android',
  'ios',
  'ipad',
  'tvos',
  'appletv',
  'androidtv',
  'firetab',
  'firetv',
];

/**
 * Devices for which tests should be run on STB-Tester.
 */
const stbtDevices = ['charter', 'comcast', 'cox', 'directv'];

/**
 * Devices for which tests should be run on Suitest.
 */
const suitestDevices = [
  'roku',
  'samsung',
  'lg',
  'xbox',
  'vizio',
  'playstation',
  'nowtv',
];

/**
 * Devices for which tests should be run on webdriver.
 */
const webdriverDevices = ['web'];

/**
 * Takes a client (device type) and returns the corresponding test platform.  It will eventually change to read
 * from a config file that is nested under each program/client folder so that they have control over this.
 *
 * @param {string} client - The device type against which the tests will be executed
 * @returns {string} The testing platform which will execute the tests
 */
function getPlatform(client) {
  if (appiumDevices.includes(client)) {
    return 'appium';
  }

  if (stbtDevices.includes(client)) {
    return 'stbt';
  }

  if (suitestDevices.includes(client)) {
    return 'suitest';
  }

  if (webdriverDevices.includes(client)) {
    return 'webdriver';
  }

  throw new Error(`Unrecognized client "${client}"`);
}

module.exports = getPlatform;
