require('dotenv').config();
const { runCommandOnFileDiffs } = require('./utils');
const { logger } = require('../support/logger');

// Eslint: match both .ts and .js files
const fileMatcher = '.(js|ts)$';
const [action] = process.argv.map((val) => val).slice(2);

let failed = false;
let failMessage = '';

// eslint
const eslintCommand = `npx eslint ${
  action === 'fix' ? '--fix' : ''
}  --rulesdir ./customJsRules --max-warnings=0`;

try {
  runCommandOnFileDiffs(
    fileMatcher,
    eslintCommand,
    'ESLINT ISSUES: Run `npm run js:fix`. See how to fix / avoid these issues here: https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3432579262/Code+quality+lint+rubocop+and+formatting+prettier',
  );
} catch (e) {
  failed = true;
  failMessage += 'ESLINT failed. ';
}

// prettier
const prettierCommand = `npx prettier ${action === 'fix' ? '-w' : '-c'}`;

try {
  runCommandOnFileDiffs(
    fileMatcher,
    prettierCommand,
    'FORMATTING ISSUES: Run `npm run js:fix`. See how to fix your issues here: https://discoveryinc.atlassian.net/wiki/spaces/GQA/pages/3432579262/Code+quality+lint+rubocop+and+formatting+prettier',
  );
} catch (e) {
  failed = true;
  failMessage += 'PRETTIER failed. ';
}

if (failed) {
  logger.log('');
  logger.log(`${'OVERALL RESULT:'.WHITE_BOLD() + ' failed'.RED()}\n`);
  logger.log(failMessage.CYAN_BOLD());
  logger.log('');

  process.exit(1);
}
