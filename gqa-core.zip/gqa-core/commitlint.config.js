module.exports = {
  extends: ['@commitlint/config-conventional'],
  /*
   * Any rules defined here will override rules from @commitlint/config-conventional
   */
  rules: {
    /**
     * Level - [0..2]: 0 disables the rule. For 1 it will be considered a warning for 2 an error.
     * Applicable - always|never: never inverts the rule.
     */
    'references-empty': [1, 'never'],
  },
  parserPreset: {
    parserOpts: {
      issuePrefixes: ['PEO-'],
    },
  },
};
