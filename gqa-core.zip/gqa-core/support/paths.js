const { existsSync, readdirSync } = require('fs');
const path = require('path');

const rootDir = process.cwd();
const logs = path.join(rootDir, 'logs');

const paths = {
  projects: path.join(rootDir, 'projects'),
  stbtProjects: path.join(rootDir, 'tests', 'projects'),
  suitestrc: path.join(rootDir, '.suitestrc'),
  suitestrcShadow: path.join(rootDir, '.suitestrc.shadow'),
  env: path.join(rootDir, '.env'),
  envShadow: path.join(rootDir, '.env.shadow'),
  builds: path.join(rootDir, 'support', 'builds'),
  logs,
  results: path.join(rootDir, 'results'),
  config: {
    template: path.join(rootDir, 'support', 'config_template.json'),
    runtime: path.join(rootDir, 'support', 'config_runtime.json'),
  },
  screenshots: path.join(logs, 'screenshots'),
};

const projectList = existsSync(paths.projects)
  ? readdirSync(paths.projects, { withFileTypes: true })
      .filter((item) => item.isDirectory())
      .map((item) => item.name)
  : [];

const jakeProjects = projectList.filter((e) => e !== 'support');

/**
 * Takes a parent folder and returns nested client folders.  Used for programmatic jake task creation in tasks/runner.js
 *
 * @param { string } dir folder string and combines with project path
 * @returns { object } sentinel list of clients
 */
function getClients(dir = jakeProjects) {
  const sentinel = [];

  Object.values(readdirSync(path.join(paths.projects, dir))).forEach(
    (client) => {
      if (client !== 'features' && client !== 'testData') {
        sentinel.push(client);
      }
    },
  );
  return sentinel;
}

module.exports = {
  paths,
  jakeProjects,
  projectList,
  getClients,
};
