const { TestRailClient } = require('./testrail/testrail');
const {
  isFeatureFlagEnabled,
  runtimeDevice,
  runtimeProject,
} = require('./runtimeConfig');

class Client {
  constructor() {
    this.testrail = new TestRailClient();
  }

  generatePlanName() {
    const planName = runtimeProject()
      .toUpperCase()
      .concat(
        `_${runtimeDevice().toUpperCase()}`,
        '_',
        process.env.GITHUB_WORKFLOW || 'Local Test',
      );

    return planName;
  }

  generateBuildId() {
    const buildId =
      process.env.GITHUB_RUN_NUMBER || Math.floor(Math.random() * 100);

    return buildId;
  }

  sendResults() {
    return isFeatureFlagEnabled('TESTRAIL_SEND_RESULTS');
  }

  createCustomPlan() {
    return isFeatureFlagEnabled('TESTRAIL_CREATE_CUSTOM_PLAN');
  }

  async createPlan(suiteId) {
    this.testrail.resetTestRuns();
    const planName = this.generatePlanName();
    const buildId = this.generateBuildId();

    await this.testrail.initializePlan(planName, suiteId, buildId);
  }

  async createPlanWithoutEntry(suiteId) {
    this.testrail.resetTestRuns();
    const planName = this.generatePlanName();
    const buildId = this.generateBuildId();

    await this.testrail.initializePlanWithoutEntry(planName, suiteId, buildId);
  }

  async createRun(suiteId) {
    await this.testrail.addTestRunToPlan(suiteId);
  }

  async appendTestCase(suiteId, scenario) {
    await this.testrail.appendTestCase(suiteId, scenario);
  }

  async getTestCaseId(suiteId, scenario) {
    await this.testrail.getTestCaseId(suiteId, scenario);
  }

  async appendResult(suiteId, scenario) {
    await this.testrail.appendResult(suiteId, scenario);
  }

  async addTestRunToPlanWithCaseIds(suiteId) {
    await this.testrail.addTestRunToPlanWithCaseIds(suiteId);
  }

  async publishResults() {
    await this.testrail.publishResults();
  }

  async saveTestRunUrl() {
    await this.testrail.saveTestRunUrl();
  }
}

module.exports = Client;
