// Copyright text placeholder, Warner Bros. Discovery, Inc.

/**
 * The error structure thrown by `execSync()`.
 */
export interface IExecSyncError {
  /**
   * The status return code of the `execSync()` call.
   */
  status: number;

  /**
   * The signal that caused the `execSync()` call to terminate, if any.
   */
  // eslint-disable-next-line @rushstack/no-new-null
  signal: number | null;

  /**
   * The total output of the `execSync()` call, including both lines written to `stdout` and lines written to `stderr`.
   */
  // eslint-disable-next-line @rushstack/no-new-null
  output: (string | null)[];

  /**
   * The process id of the `execSync()` call.
   */
  pid: number;

  /**
   * The complete output that the `execSync()` call wrote to `stdout`.
   */
  stdout: string;

  /**
   * The complete output that the `execSync()` call wrote tot `stderr`.
   */
  stderr: string;
}
