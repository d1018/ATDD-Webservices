// Copyright text placeholder, Warner Bros. Discovery, Inc.

/* eslint-disable */
export class Device {
  private readonly suitestId: string;

  private readonly headspinId: string;

  private readonly cameraId: string;

  private readonly hostname: string;

  private readonly name: string;
  /* eslint-enable */

  public constructor(
    suitestId: string,
    headspinId: string,
    cameraId: string,
    hostname: string,
    name: string,
  ) {
    this.suitestId = suitestId;
    this.headspinId = headspinId;
    this.cameraId = cameraId;
    this.hostname = hostname;
    this.name = name;
  }

  public getSuitestId(): string {
    return this.suitestId;
  }

  public getHeadspinId(): string {
    return this.headspinId;
  }

  public getCameraId(): string {
    return this.cameraId;
  }

  public getName(): string {
    return this.name;
  }

  public getHostname(): string {
    return this.hostname;
  }

  // eslint-disable-next-line @typescript-eslint/naming-convention
  private buildAddress(id: string, hostname: string): string {
    return `${id}@${hostname}`;
  }

  public getHeadspinAddress(): string {
    return this.buildAddress(this.headspinId, this.hostname);
  }

  public getCameraAddress(): string {
    return this.buildAddress(this.cameraId, this.hostname);
  }
}
