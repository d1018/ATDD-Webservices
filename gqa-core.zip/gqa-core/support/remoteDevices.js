const dotenv = require('dotenv');
const devices = require('./remoteDevices.json');
const { runtimeDevice } = require('./runtimeConfig');
// eslint-disable-next-line import/extensions
const { Device } = require('./remoteDevice');
const { logger } = require('./logger');

dotenv.config();

class Devices {
  static devicesList = [];

  static loadDevices() {
    try {
      const type = runtimeDevice().toLowerCase();
      const region = 'global';

      const result = devices[type][region];

      if (result === undefined) {
        throw new Error(
          'There are no devices available for device type and region defined.',
        );
      }

      return result;
    } catch (e) {
      const errorMessage =
        'There are no devices available for device type and region defined.';

      throw new Error(`${errorMessage}\n${e}`);
    }
  }

  static DeviceType() {
    const device = runtimeDevice();

    logger.log(`Device value has been set to: ${device}`);
    return device.toLowerCase();
  }

  static getDeviceId(address) {
    return address.split('@')[0];
  }

  static getDeviceHostname(address) {
    return address.split('@')[1];
  }

  static getDevicesList() {
    if (this.devicesList.length === 0) {
      const rawDevices = this.loadDevices();
      const deviceIds = Object.getOwnPropertyNames(rawDevices);

      deviceIds.forEach((deviceId) => {
        this.devicesList.push(
          new Device(
            deviceId,
            this.getDeviceId(rawDevices[deviceId].dutAddress),
            rawDevices[deviceId].deviceId,
            this.getDeviceHostname(rawDevices[deviceId].dutAddress),
            rawDevices[deviceId].name,
          ),
        );
      });
    }
    return this.devicesList;
  }

  static getDeviceByProperty(property, value) {
    const devicesList = this.getDevicesList();

    return devicesList.find((device) => device[property] === value);
  }
}

module.exports = { Devices };
