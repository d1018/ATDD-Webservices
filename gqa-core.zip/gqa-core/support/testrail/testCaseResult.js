class TestCaseResult {
  constructor(context) {
    this.context = context;
  }
}

module.exports = {
  TestCaseResult,
};
