/* eslint-disable max-classes-per-file */
class ConfigError extends Error {
  constructor(configParams) {
    const missedParams = Object.keys(configParams).filter(
      (key) => !configParams[key],
    );

    super(`Missed parameters: ${missedParams}`);
  }
}

class TestRailError extends Error {
  constructor(err, statusCode) {
    super(`${err} status code: ${statusCode}`);
  }
}

class InvalidTestCaseError extends Error {
  constructor(suiteName) {
    super(`${suiteName} does not contain the specified test case`);
  }
}

class InvalidTestCaseStatusError extends Error {
  constructor(status) {
    super(`Invalid Test result status: ${status}`);
  }
}

class MissedStatusError extends Error {
  constructor() {
    super('Status is required when creating a test result');
  }
}

class MissedStatusIdError extends Error {
  constructor() {
    super('status_id is required when creating a test result');
  }
}

module.exports = {
  ConfigError,
  TestRailError,
  InvalidTestCaseError,
  InvalidTestCaseStatusError,
  MissedStatusError,
  MissedStatusIdError,
};
