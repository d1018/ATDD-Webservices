const { postResource } = require('./utils');
const {
  InvalidTestCaseStatusError,
  MissedStatusError,
  MissedStatusIdError,
} = require('./errors');
const { TestCaseResult } = require('./testCaseResult');
const testRailStatus = require('./testRailStatus');

const getStatusId = (status) => {
  if (testRailStatus[status]) {
    return testRailStatus[status];
  }

  throw new InvalidTestCaseStatusError(status);
};

class TestRun {
  constructor(context) {
    this.context = context;
  }

  async addResults(payload) {
    payload.results.forEach((result) => {
      if (!result.status_id) {
        throw new MissedStatusIdError();
      }
    });

    const resource = `/add_results_for_cases/${this.context.id}`;

    const result = await postResource(resource, payload);

    return result;
  }

  async createTestCaseResult(testCase, payload) {
    const payLoadData = payload;

    if (!payLoadData.status) {
      throw new MissedStatusError();
    }
    payLoadData.status_id = getStatusId(payLoadData.status);
    delete payLoadData.status;
    const resource = `/add_result_for_case/${this.context.id}/${testCase.context.id}`;
    const testCaseResultContext = await postResource(resource, payLoadData);

    return new TestCaseResult(testCaseResultContext);
  }
}

module.exports = {
  TestRun,
};
