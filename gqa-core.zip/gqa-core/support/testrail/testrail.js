const { writeFileSync } = require('fs');
const { paths } = require('../../tasks/utils');
const { getResource, postResource } = require('./utils');
const { Suite } = require('./suite');
const { TestCase } = require('./testCase');
const { TestRun } = require('./testRun');
const { TestPlan } = require('./testPlan');
const TestResult = require('./testResult');
const { ensureResultsDirectory } = require('../utilities');
const { logger } = require('../logger');

const testRailBaseURL = 'https://discovery.testrail.io/index.php?';

class TestRailClient {
  constructor() {
    this.testRuns = [];
    this.testPlanId = null;
    this.testRunId = null;
    this.testCaseIds = [];
  }

  resetTestRuns() {
    this.testRuns = [];
  }

  /**
   * Obtain TestRail suite using suite id
   *
   * @param {number} suiteId Suite ID used within TestRail
   * @returns {Promise<Suite>} Suite object with API response
   */
  async getSuite(suiteId) {
    const resource = `get_suite/${suiteId}`;
    const suiteContext = await getResource(resource);

    return new Suite(suiteContext);
  }

  /**
   * Obtain TestRail Run using Run id
   *
   * @param {number} runId run ID used within TestRail
   * @returns {Promise<TestRun>} testrun object with API response
   */
  async getRun(runId) {
    const resource = `/get_run/${runId}`;
    const runContext = await getResource(resource);

    return new TestRun(runContext);
  }

  /**
   * Obtain TestRail Plan using Plan id
   *
   * @param {number} testPlanId TestPlan ID used within TestRail
   * @returns {Promise<TestPlan>} TestPlan object with API response
   */
  async getTestPlan(testPlanId) {
    const resource = `/get_plan/${testPlanId}`;
    const testPlanContext = await getResource(resource);

    return new TestPlan(testPlanContext);
  }

  /**
   * Obtain test case from TestRail suite using suite id and case name
   *
   * @param {number} suiteId Suite ID where the test case lives within TestRail
   * @param {string} name Test case name
   * @returns {Promise<TestCase>} TestCase object with API response
   */
  async getCaseByName(suiteId, name) {
    const suite = await this.getSuite(suiteId);
    const testcase = await suite.getTestCaseByName(name);

    return testcase;
  }

  /**
   * Obtain test case Id from TestRail suite using suite id and case name
   *
   * @param {number} suiteId Suite ID where the test case lives within TestRail
   * @param {string} name Test case name
   * @returns {number} Test case Id
   */
  async getCaseIdByName(suiteId, name) {
    const suite = await this.getSuite(suiteId);
    const caseId = await suite.getTestCaseIdByName(name);

    return caseId;
  }

  /**
   * Append a TestResult object to testRuns array in order to be stored and later sent up to TestRail
   *
   * @param {number} suiteId Suite ID where the test case lives within TestRail
   * @param {object} scenario Cucumber object containing info about test run
   * @returns {Promise<void>}
   */
  async appendResult(suiteId, scenario) {
    const { result, pickle } = scenario;
    const testCase = await this.getCaseByName(suiteId, pickle.name);

    this.testRuns.push(
      new TestResult(testCase.context.id, result.status, result.duration),
    );
  }

  /**
   * Create  a TestPlan
   *
   * @param {string} planName planName is the name given to TestPlan
   * @param {number} suiteId Suite ID where the test case lives within TestRail
   * @param {number} buildId buildId is ID which we get from pipeline job
   */
  async initializePlan(planName, suiteId, buildId) {
    const suite = await this.getSuite(suiteId);
    const testPlan = await suite.createTestPlan(planName, buildId);

    this.testPlanId = testPlan.context.id;
    if (testPlan.context.entries.length === 0) {
      await this.addTestRunToPlan(suiteId);
    } else {
      this.testRunId = testPlan.context.entries[0].runs[0].id;
    }
  }

  /**
   * Create a TestPlan without plan entry
   *
   * @param {string} planName planName is the name given to TestPlan
   * @param {number} suiteId Suite ID where the test case lives within TestRail
   * @param {number} buildId buildId is ID which we get from pipeline job
   */
  async initializePlanWithoutEntry(planName, suiteId, buildId) {
    const suite = await this.getSuite(suiteId);
    const testPlan = await suite.createTestPlan(planName, buildId);

    this.testPlanId = testPlan.context.id;
  }

  /**
   * Create  a TestRun
   *
   * @param {number} suiteId Suite ID where the test case lives within TestRail
   * @returns {Promise<void>}
   */
  async addTestRunToPlan(suiteId) {
    try {
      const testrun = await this.appendEntry(suiteId, []);

      this.testRunId = testrun.runs[0].id;
    } catch (e) {
      logger.error(e);
    }
  }

  /**
   * Create a TestRun with test case ids
   *
   * @param {number} suiteId Suite ID where the test case lives within TestRail
   * @returns {Promise<void>}
   */
  async addTestRunToPlanWithCaseIds(suiteId) {
    try {
      const testrun = await this.appendEntryWithCaseIds(
        suiteId,
        this.testCaseIds,
      );

      this.testRunId = testrun.runs[0].id;
    } catch (e) {
      logger.error(e);
    }
  }

  /**
   * Append entry to test plan
   *
   * @param {number} suitesId Suite ID where the test case lives within TestRail
   * @param {number} caseIds List of test case ids of the scenarios that are being executed
   * @returns {Promise<void>}
   */
  async appendEntry(suitesId, caseIds) {
    const suite = await this.getSuite(suitesId);
    const suiteName = suite.context.name;
    const planId = this.testPlanId;

    const payload = {
      name: suiteName,
      suite_id: suitesId,
      include_all: true,
      config_ids: [],
      runs: [
        {
          include_all: false,
          case_ids: caseIds,
          config_ids: [],
        },
      ],
    };
    const resource = `/add_plan_entry/${planId}`;
    const entry = await postResource(resource, payload);

    return entry;
  }

  /**
   *Append entry to test plan with test case ids
   *
   * @param {number} suitesId Suite ID where the test case lives within TestRail
   * @param {number} caseIds List of test case ids of the scenarios that are being executed
   * @returns {Promise<void>}
   */
  async appendEntryWithCaseIds(suitesId, caseIds) {
    const suite = await this.getSuite(suitesId);
    const suiteName = suite.context.name;
    const planId = this.testPlanId;

    const payload = {
      name: suiteName,
      suite_id: suitesId,
      include_all: false,
      case_ids: caseIds,
      config_ids: [],
      runs: [
        {
          include_all: true,
          case_ids: caseIds,
          config_ids: [],
        },
      ],
    };
    const resource = `/add_plan_entry/${planId}`;
    const entry = await postResource(resource, payload);

    return entry;
  }

  /**
   * Append Cucumber test case to TestRail if it doesn't already exist
   *
   * @param {number} suiteId Suite ID where the test case lives within TestRail
   * @param {object} scenario Cucumber object containing info about test run
   * @returns {Promise<void>}
   */
  async appendTestCase(suiteId, scenario) {
    const { pickle } = scenario;
    const testCase = await this.getCaseByName(suiteId, pickle.name);

    if (!testCase) {
      const suite = await this.getSuite(suiteId);

      await suite.createTestCase(scenario.gherkinDocument.feature.name, {
        title: pickle.name,
        custom_applicable_platfroms: [1, 2],
      });
    }
  }

  /**
   * Obtain test case Id from TestRail suite using suite id and test case name and sets the same value in test case ids list
   *
   * @param {number} suiteId Suite ID where the test case lives within TestRail
   * @param {object} scenario Cucumber object containing info about test run
   */
  async getTestCaseId(suiteId, scenario) {
    const { pickle } = scenario;
    const testCaseId = await this.getCaseIdByName(suiteId, pickle.name);

    this.testCaseIds.push(testCaseId);
  }

  /**
   * Publish the results to test rail
   */
  async publishResults() {
    const runID = this.testRunId;
    const testRun = await this.getRun(runID);

    await testRun.addResults({ results: this.testRuns });
  }

  /**
   * Save the test run url into a log file
   */
  saveTestRunUrl() {
    const runID = this.testRunId;
    const testRun = `${testRailBaseURL}/runs/view/${runID}`;

    ensureResultsDirectory();

    writeFileSync(`${paths.results}/testrail_run_url.log`, testRun);
  }
}

module.exports = {
  TestRailClient,
};
