const { getResource, postResource } = require('./utils');
const { TestCase } = require('./testCase');
const { TestRun } = require('./testRun');
const { TestPlan } = require('./testPlan');
const { InvalidTestCaseError } = require('./errors');

class Suite {
  constructor(context) {
    this.context = context;
  }

  async getAllTestCases() {
    const resource = `/get_cases/${this.context.project_id}&suite_id=${this.context.id}`;
    const testCasesContext = await getResource(resource);

    return Array.from(testCasesContext.cases).map(
      (testCaseContext) => new TestCase(testCaseContext),
    );
  }

  async getTestCaseByName(name) {
    const resource = `/get_cases/${this.context.project_id}&suite_id=${this.context.id}&filter=${name}`;
    const testCaseContext = await getResource(resource);

    if (
      testCaseContext &&
      testCaseContext.cases &&
      testCaseContext.cases.length > 0
    ) {
      const testCase = new TestCase(testCaseContext.cases[0]);

      return testCase;
    }
    return undefined;
  }

  async getTestCaseIdByName(name) {
    const resource = `/get_cases/${this.context.project_id}&suite_id=${this.context.id}&filter=${name}`;
    const testCaseContext = await getResource(resource);

    if (testCaseContext) {
      return testCaseContext.cases[0].id;
    }
    throw new InvalidTestCaseError(this.context.name);
  }

  async getTestCase(testCaseId) {
    const resource = `/get_cases/${this.context.project_id}&suite_id=${this.context.id}`;
    const testCasesContext = await getResource(resource);
    const testCaseContext = testCasesContext.cases.find(
      (testCaseCtx) => testCaseCtx.id === testCaseId,
    );

    if (testCaseContext) {
      return new TestCase(testCaseContext);
    }
    throw new InvalidTestCaseError(this.context.name);
  }

  async createTestCase(sectionName, payload) {
    const resource = `/get_sections/${this.context.project_id}&suite_id=${this.context.id}`;
    const sectionsContext = await getResource(resource);
    const sectionContext = sectionsContext.sections.find(
      (sectionCtx) => sectionCtx.name === sectionName,
    );

    let sectionId;

    if (!sectionContext) {
      const addSectionResource = `/add_section/${this.context.project_id}`;
      const addsectionContext = await postResource(addSectionResource, {
        name: sectionName,
        suite_id: this.context.id,
      });

      sectionId = addsectionContext.id;
    } else {
      sectionId = sectionContext.id;
    }
    const testCaseResource = `add_case/${sectionId}`;
    const testCaseContext = await postResource(testCaseResource, payload);

    return new TestCase(testCaseContext);
  }

  async createTestRun(payload) {
    const resource = `/add_run/${this.context.project_id}`;
    const testRunContext = await postResource(resource, {
      suite_id: this.context.id,
      ...payload,
    });

    return new TestRun(testRunContext);
  }

  async createTestPlan(planName, buildId) {
    const today = new Date(Date.now());
    const testplan = new TestPlan();
    const testPlanName = `${planName} - ${buildId} - ${today.toDateString()} - ${today.toTimeString()}`;
    //  checking the test plan already exist or not
    const planExist = await testplan.checkTestPlanExist(
      testPlanName,
      this.context.project_id,
    );

    if (planExist.length > 0) {
      const planId = planExist[0].id;
      const testPlan = testplan.getTestPlan(planId);

      return testPlan;
    }

    const payload = {
      name: testPlanName,
    };
    const resource = `/add_plan/${this.context.project_id}`;
    const testPlanContext = await postResource(resource, payload);

    return new TestPlan(testPlanContext);
  }
}

module.exports = {
  Suite,
};
