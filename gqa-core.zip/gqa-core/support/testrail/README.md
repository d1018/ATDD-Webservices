# TestRail API Client

**This client allows you to manage your TestRail resources programmatically**

## Configuration

In order to use this client, you need to configure the following environment variables:

- TESTRAIL_USERNAME
- TESTRAIL_APIKEY

## Usage

1. Suite

```js
const client = new TestRailClient();
const suite = await client.getSuite(1234);
console.log(suite.context.name);
```

some suite properties: id, name, description, is_completed

2. Test Case

```js
const suite = await client.getSuite(1234);
const testCase = await suite.getTestCase(5678);
await testCase.update({
  title: 'updated title',
});
console.log(testCase.contex.title); // updated title
```

Create a test case and add it to the specified section name. A new section will be created if does not exist

```js
const suite = await client.getSuite(1234);
const sectionName = 'Full Regression';
const testCase = await suite.createTestCase(sectionName, {
  title: 'Regression TC',
});
console.log(testCase.context.title); // Regression TC
```

some test case properties: id, section_id, estimate, title

3. Test Run and Test Case Result

```js
const testCase = (await suite.getAllTestCases())[0];
const testRun = await suite.createTestRun({
  name: 'Test Run',
  description: 'testing description',
});

// create a test result for a given test case
await testRun.createTestCaseResult(testCase, {
  status: 'Passed',
  comment: 'The test case passed',
});
```

some test run properties: suite_id, name, description, include_all

some test result properties: status_id, comment, version, defects

test result status:

1. Passed
2. Blocked
3. Untested
4. Retest
5. Failed
6. UnableToTest
7. NotImplementedYet
8. AutomatedPassed
9. PassedWithExceptions
10. NotInScope
11. AutomatedFailed
12. AutomatedOther

Please visit the [TestRail Documentation](https://www.gurock.com/testrail/docs/api) for reference
