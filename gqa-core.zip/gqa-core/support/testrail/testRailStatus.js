const testRailStatus = {
  Passed: 1,
  Blocked: 2,
  Untested: 3,
  Retest: 4,
  Failed: 5,
  UnableToTest: 6,
  NotImplementedYet: 7,
  AutomatedPassed: 8,
  PassedWithExceptions: 9,
  NotInScope: 10,
  AutomatedFailed: 11,
  AutomatedOther: 12,
};

module.exports = testRailStatus;
