const { getResource } = require('./utils');

class TestPlan {
  constructor(context) {
    this.context = context;
  }

  async getTestPlan(testPlanId) {
    const resource = `get_plan/${testPlanId}`;
    const testPlanContext = await getResource(resource);

    return new TestPlan(testPlanContext);
  }

  async checkTestPlanExist(planName, projectId) {
    const resource = `get_plans/${projectId}&is_completed=0`;
    const testPlans = await getResource(resource);
    const existPlanName = testPlans.plans.filter(
      (plan) => plan.name === planName,
    );

    return existPlanName;
  }
}

module.exports = {
  TestPlan,
};
