require('dotenv').config();
require('../../tasks/utils');
const fetch = require('node-fetch');
const retry = require('async-retry');
const { ConfigError, TestRailError } = require('./errors');
const { testrailApi } = require('../hs_config.json');

const getConfig = () => {
  const { TESTRAIL_USERNAME, TESTRAIL_APIKEY } = process.env;

  if (!TESTRAIL_USERNAME || !TESTRAIL_APIKEY) {
    throw new ConfigError({ TESTRAIL_USERNAME, TESTRAIL_APIKEY });
  }

  const credentials = `${TESTRAIL_USERNAME}:${TESTRAIL_APIKEY}`;
  const encodedCredentials = Buffer.from(credentials).toString('base64');

  return {
    baseUrl: testrailApi,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Basic ${encodedCredentials}`,
    },
  };
};

const getResource = async (resource) => {
  const config = getConfig();
  const endpoint = `${config.baseUrl}/${resource}`;
  let response;
  let data;

  try {
    await retry(
      async () => {
        response = await fetch(endpoint, {
          headers: config.headers,
        });
        data = await response.json();

        if (!response.ok) {
          throw new TestRailError(data.error, response.status);
        }
      },
      { retries: 3, minTimeout: 2000, maxTimeout: 3000 },
    );
  } catch (err) {
    throw new TestRailError(data.error, response.status);
  }
  return data;
};

const postResource = async (resource, payload) => {
  const config = getConfig();
  const endpoint = `${config.baseUrl}/${resource}`;
  let data;
  let response;

  try {
    await retry(
      async () => {
        response = await fetch(endpoint, {
          headers: config.headers,
          method: 'POST',
          body: JSON.stringify(payload),
        });

        data = await response.json();
        if (!response.ok) {
          throw new TestRailError(data.error, response.status);
        }
      },
      { retries: 3, minTimeout: 3000, maxTimeout: 5000 },
    );
  } catch (err) {
    throw new TestRailError(data.error, response.status);
  }
  return data;
};

module.exports = {
  getResource,
  postResource,
};
