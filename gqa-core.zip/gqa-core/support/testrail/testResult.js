const testRailStatus = require('./testRailStatus');

/**
 * Assign a result status number TestRail recognizes based on the given Cucumber result status
 *
 * @param {string} status Cucumber result status (ex. 'PASSED', 'FAILED')
 * @returns {number} TestRail status number
 */
const assignStatusId = (status) => {
  switch (status) {
    case 'UNKNOWN':
      return testRailStatus.UnableToTest;
    case 'PASSED':
      return testRailStatus.Passed;
    case 'SKIPPED':
      return testRailStatus.Untested;
    case 'PENDING':
      return testRailStatus.NotImplementedYet;
    case 'UNDEFINED':
      return testRailStatus.NotImplementedYet;
    case 'AMBIGUOUS':
      return testRailStatus.UnableToTest;
    case 'FAILED':
      return testRailStatus.Failed;
    default:
      return testRailStatus.UnableToTest;
  }
};

class TestResult {
  /**
   * Sets up an object that represents a test run in the context of TestRail
   *
   * @param {number} caseId ID of the test case that lives within TestRail
   * @param {string} status Cucumber result status (ex. 'PASSED', 'FAILED', 'UNKNOWN')
   * @param {object} duration Object containing information about test result duration
   */
  constructor(caseId, status, duration) {
    this.case_id = caseId;
    this.status_id = assignStatusId(status);
    this.elapsed = `${duration.seconds}s`;
  }
}

module.exports = TestResult;
