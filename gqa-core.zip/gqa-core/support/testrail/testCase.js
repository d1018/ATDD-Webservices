const { postResource } = require('./utils');

class TestCase {
  constructor(context) {
    this.context = context;
  }

  async update(payload) {
    const resource = `/update_case/${this.context.id}`;
    const testCaseContext = await postResource(resource, payload);

    this.context = testCaseContext;
  }
}

module.exports = {
  TestCase,
};
