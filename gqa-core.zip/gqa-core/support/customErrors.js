class SkipError extends Error {
  constructor(message) {
    super(`Skipped due to skip reason ${message}`);
  }
}
const errorReason = {
  staleElement: 'does not exist in DOM anymore',
  functionTimeout: 'function timed out',
};

module.exports = {
  SkipError,
  errorReason,
};
