const fs = require('fs');
const { logger } = require('./logger');

/**
 * Helper function that parses the contents of a given directory and returns a list of json files.
 *
 * @param {string} targetDir directory containing downloaded json result files
 * @throws {Error} when the supplied directory cannot be found
 * @returns {string[]} array of file names
 */
function getJsonFilesInDir(targetDir) {
  if (!fs.existsSync(targetDir)) {
    throw new Error(`Unable to find specified directory: ${targetDir}`);
  }

  const filesInDir = fs.readdirSync(targetDir);
  const jsonOnlyFiles = filesInDir.filter(
    (file) => file.indexOf('.json') !== -1,
  );

  return jsonOnlyFiles;
}

/**
 * Helper function created to allow unit test scenario when this returns false.
 *
 * @param {string[]} jsonOnlyFiles containing json file names
 * @returns {boolean} true if the array length is greater that 0
 */
function resultDirContainsJsonFiles(jsonOnlyFiles) {
  return jsonOnlyFiles.length > 0;
}

/**
 *  When given a valid directory containing JSON files, this function will concatinate one after the other into a
 * single JSON stream. If any of the JSON files are empty or invalid, they will be ignored.
 *
 * @param {string} resultsDir directory containing downloaded json result files
 * @throws {Error} when the supplied directory does not contain any JSON files
 * @returns {object[]} resulting merged JSON data in an array
 */
function mergeStbtResults(resultsDir) {
  const jsonOnlyFiles = getJsonFilesInDir(resultsDir);

  if (!resultDirContainsJsonFiles(jsonOnlyFiles)) {
    throw new Error(
      `No files matching the '.json' file extension were found in the specified directory: ${resultsDir}. 
      Contents were: ${jsonOnlyFiles}`,
    );
  }

  const jsonData = [];

  jsonOnlyFiles.forEach((file) => {
    try {
      const fileData = JSON.parse(
        fs.readFileSync(`${resultsDir}${file}`, 'utf-8'),
      );

      jsonData.push(fileData[0]);
    } catch (err) {
      logger.warn(
        `Caught an error when parsing json files: ${err}, skipping file: ${file}`,
      );
    }
  });
  return jsonData;
}

/**
 *  Reads contents of all valid JSON files in supplied resultsDir, merges them into a single JSON object which can be
 * consumed by the Cucumber module that converts JSON results to XML for ReportPortal consumption and writes that
 * object out to the specified file.
 *
 * @param {string} resultsDir directory containing downloaded json result files
 * @param {string} outputFile name and location of the final, combined results file
 */
function createMergedStbtResultsFile(resultsDir, outputFile) {
  fs.writeFileSync(
    outputFile,
    JSON.stringify(mergeStbtResults(resultsDir)),
    'utf-8',
  );
}

module.exports = {
  mergeStbtResults,
  createMergedStbtResultsFile,
};
