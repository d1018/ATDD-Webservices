const { existsSync, mkdirSync } = require('fs');

const { paths } = require(`../support/paths`);

/**
 * Some places lose the stack trace - wrapping your code in this will try to maintain it.
 *
 * @param {Function} fn the function to be executed.
 * @returns {Function} returns the function
 */
const stacktraceWrapper = async (fn) => {
  try {
    return await fn();
  } catch (err) {
    throw new Error(err).stack;
  }
};

/**
 * Either the function finishes or the timeout finishes.
 *
 * @param {number} timeoutMs the maximum time to try and complete the function.
 * @param {boolean} throwOnTimeout if true, then throws if timeout, else just records the timeout.
 * @param {Function} fn the function to be executed.
 * @returns {any} Returns a promise
 */
const timeoutWrapper = async (timeoutMs, throwOnTimeout, fn) => {
  await stacktraceWrapper(async () => {
    const wait = async (ms) => {
      await new Promise((resolve) => setTimeout(() => resolve(), ms));
      return 'TIMEOUT';
    };

    const promises = [wait(timeoutMs), fn()];
    const result = await Promise.race(promises);

    if (result === 'TIMEOUT' && throwOnTimeout) {
      throw new Error(`Function did not complete within (${timeoutMs}ms).`);
    }

    return result;
  });
};

/**
 * Repeatedly runs the function until it doesn't 'throw' or return false (throws on fail).
 *
 * @param {Function} fn the function to be executed.
 * @param {number} [timeoutMs=10000] the maximum time to try and complete the function.
 */
const eventually = async (fn, timeoutMs = 20000) => {
  const interval = 250;

  let exception;
  let success = false;

  await timeoutWrapper(timeoutMs, false, async () => {
    while (!success) {
      try {
        exception = undefined;
        success = await fn();

        if (success !== false) {
          break;
        }
      } catch (err) {
        exception = err;
      }

      await new Promise((resolve) => setTimeout(resolve, interval));
    }
  });

  if (success === false) {
    throw new Error(
      `Unable to complete function within timeout (${timeoutMs}ms): ${
        typeof exception === 'object'
          ? JSON.stringify(exception, null, 2)
          : exception
      }`,
    );
  }
};

/**
 * Waits for the specified number of milliseconds. Please use this
 * VERY sparingly, and expect to defend your reasons for each call!
 *
 * @param {number} milliseconds - The number of milliseconds to wait
 */
async function delay(milliseconds) {
  await new Promise((resolve) => setTimeout(resolve, milliseconds));
}

/**
 * Ensures that the `results` directory exists, so that tests can put their results files there.
 */
function ensureResultsDirectory() {
  if (!existsSync(paths.results)) {
    mkdirSync(paths.results);
  }
}

module.exports = { eventually, timeoutWrapper, delay, ensureResultsDirectory };
