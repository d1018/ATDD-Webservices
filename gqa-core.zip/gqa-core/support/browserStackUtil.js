require('./stringOverrides');
const fetch = require('node-fetch');
const { Headers } = require('node-fetch');
const { execSync } = require('child_process');

const username = process.env.BS_USER;
const password = process.env.BS_KEY;
const bsAppPlanAPI = 'https://api.browserstack.com/app-automate/plan.json';
const bsplanAPI = 'https://api.browserstack.com/automate/plan.json';
const bsSessionAPI = 'https://api.browserstack.com/automate/';
const bsAppSessionAPI = 'https://api.browserstack.com/app-automate/';

const { logger } = require('./logger');

const headers = new Headers();

headers.set(
  'Authorization',
  `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}`,
);

// This API fetches details about browser stack group’s Automate plan,
// including the maximum number of parallel tests allowed,
// the number of parallel tests currently running, and the number of parallel tests queued.
const bsPlanDetails = async () => {
  try {
    const response = await fetch(bsplanAPI, { method: 'GET', headers });
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack Plan Details API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// This method returns true if the parallel sessions running on browser stack automate is under the usage limit
const isAutomateUnderBsUsage = async () => {
  const response = await bsPlanDetails();

  logger.log(
    `parallel sessions running : ${response.parallel_sessions_running}`,
  );
  logger.log(
    `team parallel sessions max allowed : ${response.team_parallel_sessions_max_allowed}`,
  );

  return (
    response.parallel_sessions_running <=
    response.team_parallel_sessions_max_allowed
  );
};

//   Once the list of sessions is available, more specific information
//   such as test results and debugging information such as instrumentation logs,
//   device logs, network logs, etc. about a particular session can be queried using the session ID.
const bsSessionDetails = async (sessionId) => {
  try {
    const response = await fetch(`${bsSessionAPI}sessions/${sessionId}.json`, {
      method: 'GET',
      headers,
    });
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack Session Details API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// A session log consists of all the requests made by the session and the corresponding responses.
const bsSessionLogs = async (sessionId) => {
  try {
    const response = await fetch(`${bsSessionAPI}sessions/${sessionId}/logs`, {
      method: 'GET',
      headers,
    });
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack Session Logs API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// Network Logs capture the browser’s performance data such as network traffic, latency, HTTP requests and responses in the HAR format.
const bsSessionNetworkLogs = async (sessionId) => {
  try {
    const response = await fetch(
      `${bsSessionAPI}sessions/${sessionId}/networklogs`,
      { method: 'GET', headers },
    );
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack Session Network Logs API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// Console Logs capture the browser’s JS console output at various steps of the test to troubleshoot JavaScript issues.
const bsSessionConsoleLogs = async (sessionId) => {
  try {
    const response = await fetch(
      `${bsSessionAPI}sessions/${sessionId}/consolelogs`,
      { method: 'GET', headers },
    );
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack Session Console Logs API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// Selenium Logs captures the raw logs of Selenium JAR for your test execution.
// With Selenium logs you can debug the test in case of any exceptions.
const bsSessionSeleniumLogs = async (sessionId) => {
  try {
    const response = await fetch(
      `${bsSessionAPI}sessions/${sessionId}/seleniumlogs`,
      { method: 'GET', headers },
    );
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack Session Selenium Logs API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// This API method marks the Browser Stack automate session status Pass or Fail
const bsAutomateUpdateSessionStatus = async (sessionId, result) => {
  const url = `${bsSessionAPI}sessions/${sessionId}.json`;

  const requestBody = {
    status: result.status,
  };

  const request = {
    method: 'PUT',
    body: JSON.stringify(requestBody),
    headers: new Headers({
      'Content-Type': 'application/json',
      Authorization: `Basic ${Buffer.from(`${username}:${password}`).toString(
        'base64',
      )}`,
    }),
  };

  try {
    const response = await fetch(url, request);
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack Session Status Update API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// This API updates the network type .The list of network type is available in below mentioned link.
// https://www.browserstack.com/docs/automate/selenium/simulate-network-conditions#complete-list-of-network-profiles
const bsAutomateUpdateNetworkType = async (sessionId, networkType) => {
  const url = `${bsSessionAPI}sessions/${sessionId}/update_network.json`;

  const requestBody = {
    networkProfile: networkType,
  };

  const request = {
    method: 'PUT',
    body: JSON.stringify(requestBody),
    headers: new Headers({
      'Content-Type': 'application/json',
      Authorization: `Basic ${Buffer.from(`${username}:${password}`).toString(
        'base64',
      )}`,
    }),
  };

  try {
    const response = await fetch(url, request);
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack Session Update Network Type API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// This API will customize the network as per our requirement .
const bsAutomateUpdateNetwork = async (
  sessionId,
  downloadSpeed,
  uploadSpeed,
  latency,
  packetLoss,
) => {
  const url = `${bsSessionAPI}sessions/${sessionId}/update_network.json`;

  const requestBody = {
    customNetwork: `${downloadSpeed},${uploadSpeed},${latency},${packetLoss}`,
  };

  const request = {
    method: 'PUT',
    body: JSON.stringify(requestBody),
    headers: new Headers({
      'Content-Type': 'application/json',
      Authorization: `Basic ${Buffer.from(`${username}:${password}`).toString(
        'base64',
      )}`,
    }),
  };

  try {
    const response = await fetch(url, request);
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack Session Update Network API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// This API fetches details about browser stack group’s App Automate plan,
// including the maximum number of parallel tests allowed,
// the number of parallel tests currently running, and the number of parallel tests queued.
const bsAppPlanDetails = async () => {
  try {
    const response = await fetch(bsAppPlanAPI, { method: 'GET', headers });
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack App Plan Details API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// Get details of a test session including its status and debugging information such as Appium logs and test video recording.
const bsAppSessionDetails = async (sessionId) => {
  try {
    const response = await fetch(
      `${bsAppSessionAPI}sessions/${sessionId}.json`,
      { method: 'GET', headers },
    );
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack App Session Details API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// Access the logs for the session in textual format.
// It includes information about the test session’s desired capabilities and detailed information about every request and response.
const bsAppSessionTextLogs = async (buildId, sessionId) => {
  try {
    const response = await fetch(
      `${bsAppSessionAPI}builds/${buildId}/sessions/${sessionId}/logs`,
      { method: 'GET', headers },
    );
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack App Session Text Logs API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// Access the device logs for your session. These are system logs specific to your application generated by the OS(Android/iOS)
// and can be helful for debugging any application crashes during test execution.
const bsAppSessionDeviceLogs = async (buildId, sessionId) => {
  try {
    const response = await fetch(
      `${bsAppSessionAPI}builds/${buildId}/sessions/${sessionId}/devicelogs`,
      { method: 'GET', headers },
    );
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack App Session Device Logs API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// Access the Appium logs for your session. These are logs generated by the Appium server and
// contain the details about your each Appium command execution in the test session.
const bsAppSessionAppiumLogs = async (buildId, sessionId) => {
  try {
    const response = await fetch(
      `${bsAppSessionAPI}builds/${buildId}/sessions/${sessionId}/appiumlogs`,
      { method: 'GET', headers },
    );
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack App Session Appium Logs API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// Access the network logs for your session. These logs capture network data such as network traffic,
// latency, HTTP requests/responses in the HAR (HTTP Archive) format.
// You can identify any performance bottlenecks or debug failed REST API responses.
const bsAppSessionNetworkLogs = async (buildId, sessionId) => {
  try {
    const response = await fetch(
      `${bsAppSessionAPI}builds/${buildId}/sessions/${sessionId}/networklogs`,
      { method: 'GET', headers },
    );
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack App Session Network Logs API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// This method returns true if the parallel sessions running on browser stack app-automate is under the usage limit
const isAppUnderBsUsage = async () => {
  const response = await bsAppPlanDetails();

  logger.log(
    `parallel sessions running : ${response.parallel_sessions_running}`,
  );
  logger.log(
    `team parallel sessions max allowed : ${response.team_parallel_sessions_max_allowed}`,
  );

  return (
    response.parallel_sessions_running <=
    response.team_parallel_sessions_max_allowed
  );
};

// This API retrieves a list of recently uploaded apps. It returns the last 10 uploaded apps from your BrowserStack group
const bsAppUploadedAppsList = async () => {
  try {
    const response = await fetch(`${bsAppSessionAPI}recent_group_apps`, {
      method: 'GET',
      headers,
    });
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack App Uploaded Apps List API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// This API method marks the Browser Stack session status Pass or Fail
const bsAppUpdateSessionStatus = async (sessionId, result) => {
  const url = `${bsAppSessionAPI}sessions/${sessionId}.json`;

  const requestBody = {
    status: result.status,
  };

  const request = {
    method: 'PUT',
    body: JSON.stringify(requestBody),
    headers: new Headers({
      'Content-Type': 'application/json',
      Authorization: `Basic ${Buffer.from(`${username}:${password}`).toString(
        'base64',
      )}`,
    }),
  };

  try {
    const response = await fetch(url, request);
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack App Session Status Update API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// This API updates the network type .The list of network type is available in below mentioned link.
// https://www.browserstack.com/docs/automate/selenium/simulate-network-conditions#complete-list-of-network-profiles
const bsAppUpdateNetworkType = async (sessionId, networkType) => {
  const url = `${bsAppSessionAPI}sessions/${sessionId}/update_network.json`;

  const requestBody = {
    networkProfile: networkType,
  };

  const request = {
    method: 'PUT',
    body: JSON.stringify(requestBody),
    headers: new Headers({
      'Content-Type': 'application/json',
      Authorization: `Basic ${Buffer.from(`${username}:${password}`).toString(
        'base64',
      )}`,
    }),
  };

  try {
    const response = await fetch(url, request);
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack App Session Update Network Type API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// This API will customize the network as per our requirement .
const bsAppUpdateNetwork = async (
  sessionId,
  downloadSpeed,
  uploadSpeed,
  latency,
  packetLoss,
) => {
  const url = `${bsAppSessionAPI}sessions/${sessionId}/update_network.json`;

  const requestBody = {
    customNetwork: `${downloadSpeed},${uploadSpeed},${latency},${packetLoss}`,
  };

  const request = {
    method: 'PUT',
    body: JSON.stringify(requestBody),
    headers: new Headers({
      'Content-Type': 'application/json',
      Authorization: `Basic ${Buffer.from(`${username}:${password}`).toString(
        'base64',
      )}`,
    }),
  };

  try {
    const response = await fetch(url, request);
    const data = (await response.ok)
      ? await response.json()
      : new Error(
          `Browser Stack App Session Update Network API : \n HTTP error, status = ${response.status}`.RED_BRIGHT(),
        );

    return data;
  } catch (error) {
    throw new Error(error.toString().RED_BOLD());
  }
};

// This API is used to upload the application under test (AUT) for Appium testing.
// The supported file formats are .apk and .aab files for Android and .ipa file for iOS.
const bsAppUpload = (path, customId) => {
  const command = `curl -u "${username}:${password}" -X POST "https://api-cloud.browserstack.com/app-automate/upload" -F "file=@${path}" -F "custom_id=${customId}" `;

  execSync(command, { stdio: 'inherit', encoding: 'utf-8' });
};

/**
 * Checks whether the specified `client` (device) type is a BrowserStack device, and whether
 * BrowserStack execution has been requested, to determine whether we are in BrowserStack mode.
 *
 * @param {string} client - the device on which tests will be executed
 * @returns {boolean} `true` if the tests will be run in BrowserStack; `false` otherwise
 */
function isBrowserStackMode(client) {
  const browserStackDevices = ['android', 'ios', 'ipad', 'web'];
  const isBrowserStackExecution = process.env.LOCAL_EXECUTION === 'false';

  return browserStackDevices.includes(client) && isBrowserStackExecution;
}

module.exports = {
  bsPlanDetails,
  bsSessionDetails,
  bsSessionLogs,
  bsSessionNetworkLogs,
  bsSessionConsoleLogs,
  bsSessionSeleniumLogs,
  bsAutomateUpdateSessionStatus,
  bsAutomateUpdateNetworkType,
  bsAutomateUpdateNetwork,
  bsAppPlanDetails,
  bsAppSessionDetails,
  bsAppSessionTextLogs,
  bsAppSessionDeviceLogs,
  bsAppSessionAppiumLogs,
  bsAppSessionNetworkLogs,
  isAutomateUnderBsUsage,
  isAppUnderBsUsage,
  bsAppUploadedAppsList,
  bsAppUpdateSessionStatus,
  bsAppUpload,
  bsAppUpdateNetworkType,
  bsAppUpdateNetwork,
  isBrowserStackMode,
};
