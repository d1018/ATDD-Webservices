/* eslint-disable jsdoc/valid-types */
const retry = require('async-retry');
const { pairDevice } = require('suitest-js-api');
const fetch = require('node-fetch');
const prettyjson = require('prettyjson');
const {
  fetchSuitestDeviceDetails,
  isAvailable,
  fetchAPI,
} = require('./suitest');
const { timeoutWrapper } = require('./utilities');
const headspin = require('./headspin');
const { logger } = require('./logger');

const lookForAvailableDevice = async (availableDevices) => {
  // eslint-disable-next-line no-constant-condition
  while (true) {
    for (let i = 0; i < availableDevices.length; i++) {
      const max = availableDevices.length;
      // Returns a random integer from 0 to max available Devices:

      const deviceNumber = Math.floor(Math.random() * max);
      const availableDevice = availableDevices[deviceNumber];

      // Check this device is available according to suitetst.
      const deviceDetails = await fetchSuitestDeviceDetails(
        availableDevice.suitestDeviceId,
      );

      if (deviceDetails) {
        logger.log({
          device: availableDevice.name,
          suitestStatus: deviceDetails.status,
        });
        logger.log('====LOOKING FOR AN AVAILABLE DEVICE====');
        if (isAvailable(deviceDetails)) {
          return availableDevice;
        }
      }
    }
  }
};

const getParallelThreads = (devicesAvailable) => {
  let parallelThreads;
  const { PARALLEL } = process.env;

  if (PARALLEL) {
    if (PARALLEL <= 0) {
      return 0;
    }

    const threadsRequested = PARALLEL;

    if (threadsRequested > devicesAvailable) {
      parallelThreads = devicesAvailable;
      const message = `We are decreasing the amount of Parallel threads due to device availability, Parallel threads requested: ${PARALLEL} devices available: ${devicesAvailable}`;

      logger.warn(message);
    } else {
      parallelThreads = threadsRequested;
    }
  } else {
    parallelThreads = devicesAvailable;
  }

  return parallelThreads;
};

const reconnectDevice = async (device) => {
  try {
    await retry(
      async () => {
        logger.log('reconnecting...', device);

        await timeoutWrapper(300 * 1000, true, () =>
          pairDevice(device.suitestDeviceId),
        );

        logger.log('Succcessfully reconnected:', device);

        if (headspin.isHeadspinSuitestMode()) {
          await headspin.lockDevice(device.suitestDeviceId);
        }
      },
      { retries: 3 },
    );
  } catch (e) {
    throw new Error(e);
  }
};

const validateDeviceStatus = async (connectedDevice) => {
  const deviceDetails = await fetchSuitestDeviceDetails(
    connectedDevice.suitestDeviceId,
  );

  if (deviceDetails.status === 'API_CONTROLLED') {
    logger.log('connected to device:');
    logger.log(connectedDevice);
  } else {
    await reconnectDevice(connectedDevice);
  }
};

/**
 * @async
 * @function calculateParallelThreads
 * Calculates number of parallel threads based on Suitest's and Headspin's API responses.
 // eslint-disable-next-line jsdoc/valid-types
 * @param {devices object} devices - it is an object with the devices.json file data.
 * @returns {Promise<number>} The number of available devices for automation in the moment of execution.
 */

const calculateParallelThreads = async (devices) => {
  const devicesIds = Object.keys(devices);
  const { HS_TOKEN } = process.env;
  const HS_API = `https://${HS_TOKEN}@api-dev.headspin.io/v0`;
  const formattedDevices = devicesIds.map((id) => {
    const suitestDeviceId = id;
    const { name } = devices[id];
    const headspinDeviceId = devices[id].deviceId;
    const { deviceAddress } = devices[id];

    return {
      suitestDeviceId,
      headspinDeviceId,
      name,
      deviceAddress,
    };
  });
  let suitestMatchedDevices = [];
  let suitestAvailableDevices = [];
  let endpoint = 'devices?limit=100';

  do {
    const suitestDevices = await fetchAPI(endpoint);

    const matchedDevices = suitestDevices.values.filter((device) =>
      devicesIds.includes(device.deviceId),
    );

    suitestMatchedDevices = [...suitestMatchedDevices, ...matchedDevices];

    endpoint = 'next' in suitestDevices ? suitestDevices.next : undefined;
    if (endpoint !== undefined) {
      const nextSplitted = endpoint.split('/');

      endpoint = nextSplitted[nextSplitted.length - 1];
    }
  } while (
    suitestMatchedDevices.length < devicesIds.length &&
    endpoint !== undefined
  );

  suitestAvailableDevices = suitestMatchedDevices.filter((matchedDevice) =>
    isAvailable(matchedDevice),
  );

  const getIdsfromSuitest = (deviceIds, device) => {
    deviceIds.push(device.deviceId);
    return deviceIds;
  };

  const filteredSuitestIds = suitestAvailableDevices.reduce(
    getIdsfromSuitest,
    [],
  );

  const hsResponse = await fetch(`${HS_API}/devices`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });
  const hsData = await hsResponse.json();

  if (!hsResponse.ok) {
    const errorMsg = `Failed to fetch Headspin devices: ${
      hsResponse.status
    } - ${hsResponse.statusText}\n${prettyjson.render(hsData)}`;

    throw new Error(errorMsg);
  }

  const hsAvailableDevices = hsData.devices
    .filter(({ device }) => device.owner === null)
    .filter(({ device }) => device.ready)
    // eslint-disable-next-line camelcase
    .map(({ device_id }) => device_id);

  const firstFilteredDevices = formattedDevices.filter(({ suitestDeviceId }) =>
    filteredSuitestIds.includes(suitestDeviceId),
  );

  const secondFilterDevices = firstFilteredDevices.filter(
    ({ headspinDeviceId }) => hsAvailableDevices.includes(headspinDeviceId),
  );

  const numberOfAvailableDevices = secondFilterDevices.length;

  if (numberOfAvailableDevices === 0) {
    throw new Error('There are not available devices.');
  }

  return numberOfAvailableDevices;
};

module.exports = {
  lookForAvailableDevice,
  getParallelThreads,
  validateDeviceStatus,
  calculateParallelThreads,
};
