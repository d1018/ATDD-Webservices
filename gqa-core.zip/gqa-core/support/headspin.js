require('dotenv').config();
const fetch = require('node-fetch');
const prettyjson = require('prettyjson');
const devices = require('./remoteDevices.json');
const { Devices } = require('./remoteDevices');
const { isFeatureFlagEnabled } = require('./runtimeConfig');
const { hsLockDutEnabled } = require('./hs_config.json');
const { logger } = require('./logger');

const { HS_TOKEN } = process.env;

const HS_API = `https://${HS_TOKEN}@api-dev.headspin.io/v0`;

// prefix all logs with this string for easy searching of HeadSpin related log
const LOG_PREFIX = 'HS';

/**
 * Toggles lock state of a device
 *
 * @param {string} deviceId - Device ID from Headspin
 * @param {boolean} lock - the state of the lock
 * @returns {Promise<void>}
 */
const toggleLock = async (deviceId, lock) => {
  const lockState = lock ? 'lock' : 'unlock';

  logger.log(
    `${LOG_PREFIX}: attempting to ${lockState} deviceId:"${deviceId}"...`,
  );

  const res = await fetch(`${HS_API}/devices/${lockState}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      device_id: deviceId,
    }),
  });

  if (res.status === 401) {
    logger.error(
      `${LOG_PREFIX}: failed to ${lockState} deviceId ${deviceId}; status: 401 - ${res.statusText}`,
    );
    return;
  }

  const data = await res.json();

  if (!res.ok) {
    logger.error(data);
    throw new Error(
      `Failed to ${lockState} the device.\n${res.status} - ${
        res.statusText
      }\n${prettyjson.render(data)}`,
    );
  }

  logger.log(
    `${LOG_PREFIX}: successfully ${lockState}'ed deviceId:"${deviceId}"`,
  );
};

/**
 * Locks device from being used by another sessions
 *
 * @param {string} suitestId - Device ID from Suitest
 * @returns {Promise<void>}
 */
const lockDevice = async (suitestId) => {
  const device = Devices.getDeviceByProperty('suitestId', suitestId);

  await toggleLock(device.getCameraId(), true);
  if (hsLockDutEnabled) {
    await toggleLock(device.getHeadspinId(), true);
  }
};

/**
 * Unlocks device to be freed up and used by another session
 *
 * @param {string} suitestId - Device ID from Suitest
 * @returns {Promise<void>}
 */
const unlockDevice = async (suitestId) => {
  const device = Devices.getDeviceByProperty('suitestId', suitestId);

  await toggleLock(device.getCameraId(), false);
  if (hsLockDutEnabled) {
    await toggleLock(device.getHeadspinId(), false);
  }
};

/**
 * check if a device with a particular deviceId is currently locked in HeadSpin
 *
 * @param {string} deviceId - DeviceId of the HeadSpin device
 * @returns {boolean} true if the device is locked; false otherwise
 */
const checkIfDeviceLocked = async (deviceId) => {
  logger.log(
    `${LOG_PREFIX}: check to see if deviceId "${deviceId}" is locked...`,
  );

  const res = await fetch(`${HS_API}/devices/lock`, {
    method: 'GET',
  });

  const data = await res.json();

  if (!res.ok) {
    logger.error(
      `${LOG_PREFIX}: failed to check for lock state for device: "${deviceId}"`,
    );
    throw new Error(
      `Failed check for lock state: ${res.status} - ${
        res.statusText
      }\n${prettyjson.render(data)}`,
    );
  }

  if (data && Array.isArray(data.devices)) {
    const deviceFound = data.devices.find(
      (device) => device && device.device_id === deviceId,
    );

    logger.log(
      `${LOG_PREFIX}: device with deviceId ${deviceId} found to be ${
        deviceFound ? 'locked' : 'unlocked'
      }`,
    );

    return deviceFound !== undefined;
  }

  logger.error(
    `failed to handle response from HS API: ${JSON.stringify(data)}`,
  );
  return false;
};

/**
 * Start video session recording
 *
 * @param {string} deviceAddress Headspin device address
 * @returns {Promise<string>} session ID
 */
const createRecordingSession = async (deviceAddress) => {
  // NOTE: When creating a session for a device that's hosted in an A/V Box, make sure to set capture_network: false,
  // otherwise it won't run because A/V Box devices don't support network capturing.
  logger.log(
    `${LOG_PREFIX}: attempting to create recording session for deviceAddress:"${deviceAddress}"...`,
  );

  const res = await fetch(`${HS_API}/sessions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      session_type: 'capture',
      capture_network: false,
      device_address: deviceAddress,
    }),
  });

  const data = await res.json();

  if (!res.ok) {
    logger.error(
      `${LOG_PREFIX}: failed to create recording session for deviceAddress:"${deviceAddress}"`,
    );
    throw new Error(
      `Failed to start the Headspin session: ${res.status} - ${
        res.statusText
      }\n${prettyjson.render(data)}`,
    );
  }

  logger.log(
    `${LOG_PREFIX}: succeeded creating recording session for HS deviceAddress:"${deviceAddress}"`,
  );
  return data.session_id;
};

/**
 * Stops the session
 *
 * @param {string} sessionId The current session ID
 * @returns {Promise<string>} Returns data.msg
 */
const stopRecordingSession = async (sessionId) => {
  logger.log(
    `${LOG_PREFIX}: attempting to stop recording session for deviceAddress:"${sessionId}"...`,
  );
  const res = await fetch(`${HS_API}/sessions/${sessionId}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ active: false }),
  });

  const data = await res.json();

  if (!res.ok) {
    logger.error(
      `${LOG_PREFIX}: failed to stop recording session for deviceAddress:"${sessionId}"`,
    );

    throw new Error(
      `Failed to stop Headspin session: ${res.status} - ${
        res.statusText
      }\n${prettyjson.render(data)}`,
    );
  }

  logger.log(
    `${LOG_PREFIX}: succeeded stopping recording session for deviceAddress:"${sessionId}"`,
  );

  return data.msg;
};

/**
 * Gets devices we can use for our client / geo etc...
 *
 * @returns {Array} an array of objects containg only the data we need.
 */
const getDevicePool = () => {
  const DEVICE = Devices.DeviceType();
  const formattedDeviceName = DEVICE.toLowerCase();
  const clientDevices = devices[formattedDeviceName] || {};
  const relevantDevices = clientDevices.global;

  if (!relevantDevices) {
    logger.error(`${LOG_PREFIX}: no device pool found!`);
    return [];
  }

  const devicesKeys = Object.keys(relevantDevices);

  return devicesKeys.map((key) => {
    const suitestDeviceId = key;
    const { name } = relevantDevices[key];
    const headspinDeviceId = relevantDevices[key].deviceId;
    const { deviceAddress, dutAddress } = relevantDevices[key];

    return {
      suitestDeviceId,
      headspinDeviceId,
      name,
      deviceAddress,
      dutAddress,
    };
  });
};

/**
 * Get next available device
 *
 * @returns {Promise<object>} Returns device details from support/devices.json, or undefined.
 */
const getAvailableDevices = async () => {
  const res = await fetch(`${HS_API}/devices`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  const data = await res.json();

  if (!res.ok) {
    const errorMsg = `Failed to fetch Headspin devices: ${res.status} - ${
      res.statusText
    }\n${prettyjson.render(data)}`;

    logger.error(errorMsg);
    throw new Error(errorMsg);
  }

  const devicePool = getDevicePool();

  const availableDevices = data.devices
    .filter(({ device }) => device.owner === null)
    .filter(({ device }) => device.ready)
    // Disabling rule here because we don't 'own' this parameter (comes from api response).
    // eslint-disable-next-line camelcase
    .map(({ device_id }) => device_id);

  if (availableDevices.length === 0) {
    throw new Error('Cannot find any available devices');
  }

  return devicePool.filter(({ headspinDeviceId }) =>
    availableDevices.includes(headspinDeviceId),
  );
};

/**
 * Returns HeadSpin Suitest execution value.
 *
 * @returns {boolean} returns headspin suitest value
 */
const isHeadspinSuitestMode = () => isFeatureFlagEnabled('IS_HEADSPIN_SUITEST');

/**
 * Device cleaning using HS api.
 *
 * @param {string} deviceAddress ex: R5CN1042G7V@dev-us-pao-3-proxy-23-lin.headspin.io
 */
const deviceCleaning = async (deviceAddress) => {
  const [deviceID, hostName] = String(deviceAddress).split('@');
  const endPoint = `${HS_API}/device-cleaning/device_id:${deviceID}+hostname:${hostName}/clean`;

  logger.log(
    `${LOG_PREFIX}: attempting to clean device address:"${deviceAddress}"...`,
  );

  const res = await fetch(endPoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  });

  const data = await res.json();

  if (!res.ok) {
    logger.error(
      `${LOG_PREFIX}: failed to clean HS device address:"${deviceAddress}"`,
    );
    throw new Error(
      `Failed to clean device: ${res.status} - ${
        res.statusText
      }\n${prettyjson.render(data)}`,
    );
  }

  logger.log(
    `${LOG_PREFIX}: succeeded cleaning device address:"${deviceAddress}"`,
  );
  logger.log(`${LOG_PREFIX}: Device cleaning response:${JSON.stringify(data)}`);
};

module.exports = {
  checkIfDeviceLocked,
  createRecordingSession,
  stopRecordingSession,
  lockDevice,
  unlockDevice,
  getAvailableDevices,
  isHeadspinSuitestMode,
  deviceCleaning,
  toggleLock,
};
