const FormData = require('form-data');
const fs = require('fs');
const fetch = require('node-fetch');
const { execSync } = require('child_process');
const { join } = require('path');
const cucumberJunitConvert = require('cucumber-junit-convert');

const { logger } = require('./logger');

/**
 * Converts a JSON file of test results into XML format, compresses it into a zip file named `${process.env.DEVICE}_result.xml`,
 * and moves it to the target directory.
 *
 * NOTE: if the target directory already contains a file named `${process.env.DEVICE}_result.xml`, that file
 * will be overwritten.
 *
 * @param {string} jsonFilePath - The path to the JSON file containing the test results
 * @param {string} targetDir - The target directory where the resulting zip file should be written
 * @returns {string} The path to the generated zip file
 */
function jsonToZipFile(jsonFilePath, targetDir) {
  const xmlFileName = `${process.env.DEVICE}_result.xml`;
  const xmlFilePath = join(targetDir, xmlFileName);
  const zipFileName = `${process.env.DEVICE}_result.zip`;
  const zipFilePath = join(targetDir, zipFileName);

  const options = {
    inputJsonFile: jsonFilePath,
    outputXmlFile: xmlFilePath,
    featureNameAsClassName: true,
    failOnUndefinedStep: false,
  };

  cucumberJunitConvert.convert(options);
  const zipXmlFile = `zip ${zipFileName} ${xmlFilePath}`;
  const moveZipFileToTargetDir = `mv ${zipFileName} ${zipFilePath}`;

  execSync(zipXmlFile);
  execSync(moveZipFileToTargetDir);
  return zipFilePath;
}

/**
 * Uploads a zip file to the Report Portal instance. Confirms success via both the HTTP response code and the response
 * message from Report Portal.
 *
 * Warning: despite the name, the `token` property of the `config` parameter must contain the value of an authorization
 * header containing a ReportPortal API auth token, and not just the auth token itself. The token must be structured
 * as "bearer <auth_token>" rather than just "<auth_token>".
 *
 * @param {string} zipFilePath - The path to the zip file to be uploaded
 * @param {object} config - A configuration object that specifies the auth token and endpoint
 * for the ReportPortal API
 * @param {string} config.token - The value of an authorization header containing a ReportPortal API auth token; note
 * that, despite the name, this "token" must be structured as "bearer <auth_token>", rather than just "<auth_token>"
 * @param {string} config.endpoint - The ReportPortal API endpoint to which the zip file should be POSTed
 * @returns {Promise<boolean>} `true` if the file was successfully uploaded, with an HTTP status of 200 in the response,
 * and a success message in the response
 */
async function uploadZipFile(zipFilePath, config) {
  const blob = new FormData();

  blob.append('file', fs.createReadStream(zipFilePath));
  const options = {
    method: 'POST',
    headers: {
      Authorization: config.token,
      Accept: '*/*',
    },
    body: blob,
  };

  const response = await fetch(config.endpoint, options);

  if (response?.status !== 200) {
    logger.log(response);
    return false;
  }

  const data = await response.json();

  logger.log(response);
  logger.log(data);

  const successRegexp = /^Launch with id = .* is successfully imported\.$/;

  return (
    response &&
    response.status === 200 &&
    data.message &&
    successRegexp.test(data.message)
  );
}

module.exports = {
  uploadZipFile,
  jsonToZipFile,
};
