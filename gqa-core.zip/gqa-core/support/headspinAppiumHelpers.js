require('dotenv').config();
const fetch = require('node-fetch');
const prettyjson = require('prettyjson');
const FormData = require('form-data');
const fs = require('fs');
const { execSync } = require('child_process');
const path = require('path');
const { runTimeHSToken } = require('./runtimeConfig');
const { logger } = require('./logger');

const HS_API_V0 = `https://${runTimeHSToken()}@api-dev.headspin.io/v0`;

/**
 * Fetch helper for API response body.
 *
 * @param {*} endPoint URL endpoint of target API.
 * @param {string} requestType type of request POST, GET, PUT, DELETE,..
 * @param {string} errorMsg customised error message to append after 'Failed to '
 * @returns {object} response body JSON.
 */
async function fetcherMethod(endPoint, requestType, errorMsg) {
  const response = await fetch(endPoint, {
    method: requestType,
    headers: { 'Content-Type': 'application/json' },
  });
  const data = await response.json();

  if (!response.ok) {
    throw new Error(`Failed to ${errorMsg}\n${prettyjson.render(data)}`);
  }

  return data;
}

// string constants to avoid typo(s)
const [POST, GET, DELETE] = ['POST', 'GET', 'DELETE'];

const uploadedApks = async () => {
  const endPoint = `${HS_API_V0}/apps/apks`;
  const data = await fetcherMethod(endPoint, GET, 'fetch uploaded apk(s)');

  logger.log('Uploaded apk(s):\n', data);
};

const uploadedIpas = async () => {
  const endPoint = `${HS_API_V0}/apps/ipas`;
  const data = await fetcherMethod(endPoint, GET, 'fetch uploaded ipa(s)');

  logger.log('Uploaded ipa(s):\n', data);
};

const uploadApk = (filePath) => {
  const endPoint = `curl -X POST ${HS_API_V0}/apps/apk/upload --data-binary "@${filePath}"`;

  execSync(endPoint, { stdio: 'inherit', encoding: 'utf-8' });
  logger.log(''); // to have jake footer in new line (Formatting)
};

const uploadIpa = (filePath) => {
  const endPoint = `curl -X POST ${HS_API_V0}/apps/ipa/upload --data-binary "@${filePath}"`;

  execSync(endPoint, { stdio: 'inherit', encoding: 'utf-8' });
  logger.log(''); // to have jake footer in new line (Formatting)
};

const deleteApk = async (apkAppID) => {
  const endPoint = `${HS_API_V0}/apps/apk/${apkAppID}/delete`;
  const data = await fetcherMethod(endPoint, DELETE, 'delete apk');

  logger.log('Deleted apk:', data);
};

const deleteIpa = async (ipaAppID) => {
  const endPoint = `${HS_API_V0}/apps/ipa/${ipaAppID}/delete`;
  const data = await fetcherMethod(endPoint, DELETE, 'delete ipa');

  logger.log('Deleted ipa:', data);
};

const uploadedApkPackageNames = async () => {
  const endPoint = `${HS_API_V0}/apps/apk/packages`;
  const data = await fetcherMethod(
    endPoint,
    GET,
    'get uploaded APKs package names',
  );

  logger.log("List all uploaded APKs' package names:\n", data);
};

const uploadedIpaBundleIdentifiers = async () => {
  const endPoint = `${HS_API_V0}/apps/ipa/identifiers`;
  const data = await fetcherMethod(
    endPoint,
    GET,
    "get uploaded IPAs' bundle identifiers",
  );

  logger.log("List all uploaded IPAs' bundle identifiers:\n", data);
};

const apkAppInfo = async (apkAppID) => {
  const endPoint = `${HS_API_V0}/apps/apk/${apkAppID}/info`;
  const data = await fetcherMethod(endPoint, GET, 'get apk app info');

  logger.log("APK's app information:\n", data);
};

/**
 * Gets list of all adb devices by model value.
 *
 * @param {string} deviceModel adb device model 'KFONWI'/'Chromecast'.
 * @returns {*} list of all adb device by model value.
 */
async function getAllAdbDevicesByModel(deviceModel) {
  const endPoint = `${HS_API_V0}/adb/devices`;
  const data = await fetcherMethod(
    endPoint,
    GET,
    `list all devices for model ${deviceModel}`,
  );
  const completeList = [];

  Object.keys(data).forEach((device) => {
    if (data[device].model === deviceModel)
      completeList.push(data[device].device_id);
  });

  return completeList;
}

const listAllAdbDevicesByModel = async (deviceModel) => {
  const deviceList = await getAllAdbDevicesByModel(deviceModel);

  logger.log(`Devices for ${deviceModel}\n`, deviceList);
};

const installApk = async (deviceID, apkAppId) => {
  const endPoint = `${HS_API_V0}/adb/${deviceID}/install?apk_id=${apkAppId}`;

  await fetcherMethod(
    endPoint,
    POST,
    `install apk with ID '${apkAppId}' on device with ID '${deviceID}'`,
  );
  logger.log(
    `Successfully installed apk with ID '${apkAppId}' on '${deviceID}'`,
  );
};

const uninstallApk = async (deviceID, packageName) => {
  const endPoint = `${HS_API_V0}/adb/${deviceID}/uninstall?package=${packageName}`;

  await fetcherMethod(
    endPoint,
    POST,
    `uninstall apk with package '${packageName}' on device with ID '${deviceID}'`,
  );
  logger.log(
    `Successfully uninstalled apk with package '${packageName}' on '${deviceID}'`,
  );
};

/**
 * Runs apk installer in bulk for list of devices passed.
 *
 * @param {string} deviceList list of devices
 * @param {string} apkAppID app apk ID to install
 */
async function bulkApkInstaller(deviceList, apkAppID) {
  const failures = [];
  const promiseMap = deviceList.map(async (device) => {
    try {
      await installApk(device, apkAppID);
    } catch (e) {
      failures.push(e);
    }
  });

  await Promise.all(promiseMap);

  Object.keys(failures).forEach((failure) => {
    logger.log('Failed:\n', failures[failure]);
  });
}

const installApkOnAllAndroidTvDevices = async (apkAppID) => {
  const deviceList = await getAllAdbDevicesByModel('Chromecast');

  await bulkApkInstaller(deviceList, apkAppID);
};

const installApkOnAllFireTabDevices = async (apkAppID) => {
  const deviceList = await getAllAdbDevicesByModel('KFONWI');

  await bulkApkInstaller(deviceList, apkAppID);
};

const installApkOnAllFireTvDevices = async (apkAppID) => {
  const deviceList = await getAllAdbDevicesByModel('AFTMM');

  await bulkApkInstaller(deviceList, apkAppID);
};

/**
 * Runs apk uninstaller in bulk for list of devices passed.
 *
 * @param {*} deviceList list of devices
 * @param {string} packageName app apk package to uninstall
 */
async function bulkApkUninstaller(deviceList, packageName) {
  const failures = [];
  const promiseMap = deviceList.map(async (device) => {
    try {
      await uninstallApk(device, packageName);
    } catch (e) {
      failures.push(e);
    }
  });

  await Promise.all(promiseMap);

  Object.keys(failures).forEach((failure) => {
    logger.log('Failed:\n', failures[failure]);
  });
}

const uninstallApkOnAllAndroidTvDevices = async (packageName) => {
  const deviceList = await getAllAdbDevicesByModel('Chromecast');

  await bulkApkUninstaller(deviceList, packageName);
};

const uninstallApkOnAllFireTabDevices = async (packageName) => {
  const deviceList = await getAllAdbDevicesByModel('KFONWI');

  await bulkApkUninstaller(deviceList, packageName);
};

const uninstallApkOnAllFireTvDevices = async (packageName) => {
  const deviceList = await getAllAdbDevicesByModel('AFTMM');

  await bulkApkUninstaller(deviceList, packageName);
};

const ipaAppInfo = async (ipaAppID) => {
  const endPoint = `${HS_API_V0}/apps/ipa/${ipaAppID}/info`;
  const data = await fetcherMethod(endPoint, GET, 'get ipa app info');

  logger.log("IPA's app information:\n", data);
};

const installIpa = async (deviceID, ipaAppId) => {
  const endPoint = `${HS_API_V0}/idevice/${deviceID}/installer/install?ipa_id=${ipaAppId}`;

  await fetcherMethod(
    endPoint,
    POST,
    `install ipa with ID '${ipaAppId}' on device with ID '${deviceID}`,
  );
  logger.log(
    `Successfully installed ipa with ID '${ipaAppId}' on '${deviceID}'`,
  );
};

const uninstallIpa = async (deviceID, ipaAppId) => {
  const endPoint = `${HS_API_V0}/idevice/${deviceID}/installer/uninstall?appid=${ipaAppId}`;

  await fetcherMethod(
    endPoint,
    POST,
    `uninstall ipa with package '${ipaAppId}' on device with ID '${deviceID}'`,
  );
  logger.log(
    `Successfully uninstalled ipa with bundleID '${ipaAppId}' on '${deviceID}'`,
  );
};

/**
 * Fetches and returns i-device device information.
 *
 * @param {string} iDeviceID device ID
 * @returns {object} device info object
 */
async function iDeviceInfo(iDeviceID) {
  const endPoint = `${HS_API_V0}/idevice/${iDeviceID}/info?json`;
  const data = await fetcherMethod(endPoint, GET, 'get iDevice info');

  return data;
}

/**
 * Gets list of all i Devices based on device type.
 *
 * @param {string} deviceType device class 'AppleTV'/'iPhone'
 * @returns {*} list of device IDs based on Device Class
 */
async function getAlliDevicesByModel(deviceType) {
  const endPoint = `${HS_API_V0}/idevice/id`;
  const data = await fetcherMethod(endPoint, GET, 'get iDevice list');
  const totalList = [];
  const deviceList = [];

  Object.keys(data).forEach((device) => {
    totalList.push(data[device].device_id);
  });

  const promiseMap = totalList.map(async (deviceID) => {
    const deviceInfo = await iDeviceInfo(deviceID);
    const deviceClassType = deviceInfo.DeviceClass; // ProductName > 'Apple TVOS' / 'iPhone OS'

    if (deviceClassType === deviceType) {
      deviceList.push(deviceID);
    }
  });

  await Promise.all(promiseMap);
  return deviceList;
}

const listAlliDevicesByModel = async (deviceType) => {
  const deviceList = await getAlliDevicesByModel(deviceType);

  logger.log(`List of ${deviceType}:\n`, deviceList);
};

/**
 * Runs ipa installer in bulk for list of devices passed.
 *
 * @param {string} deviceList list of devices
 * @param {string} ipaAppID app ipa ID to install
 */
async function bulkIpaInstaller(deviceList, ipaAppID) {
  const failures = [];
  const promiseMap = deviceList.map(async (device) => {
    try {
      await installIpa(device, ipaAppID);
    } catch (e) {
      failures.push(e);
    }
  });

  await Promise.all(promiseMap);

  Object.keys(failures).forEach((failure) => {
    logger.log('Failed:\n', failures[failure]);
  });
}

const installIpaOnAllAppleTvDevices = async (ipaAppID) => {
  const deviceList = await getAlliDevicesByModel('AppleTV');

  await bulkIpaInstaller(deviceList, ipaAppID);
};

/**
 * Runs ipa uninstaller in bulk for list of devices passed.
 *
 * @param {*} deviceList list of devices
 * @param {string} ipaAppID app ipa package to uninstall
 */
async function bulkIpaUninstaller(deviceList, ipaAppID) {
  const failures = [];
  const promiseMap = deviceList.map(async (device) => {
    try {
      await uninstallIpa(device, ipaAppID);
    } catch (e) {
      failures.push(e);
    }
  });

  await Promise.all(promiseMap);

  Object.keys(failures).forEach((failure) => {
    logger.log('Failed:\n', failures[failure]);
  });
}

const uninstallIpaOnAllAppleTvDevices = async (ipaAppID) => {
  const deviceList = await getAlliDevicesByModel('AppleTV');

  await bulkIpaUninstaller(deviceList, ipaAppID);
};

/**
 * Uploads app to endPoint specified, with absolute filepath of app.
 *
 * @param {string} endPoint URL endpoint of target API
 * @param {string} filePath absolute file path to file
 * @returns {*} JSON response body
 */
async function uploadApp(endPoint, filePath) {
  const fileData = new FormData();

  fileData.append('file', fs.createReadStream(filePath));
  logger.log('Uploading...');
  const requestData = {
    method: POST,
    headers: new Headers({
      'Content-Type': 'application/json',
    }),
    body: fileData,
  };

  const response = await fetch(endPoint, requestData);
  const data = await response.json();

  if (!response.ok) {
    throw new Error(`Failed to upload!!!\n${prettyjson.render(data)}`);
  }
  return data;
}

const uploadAppWithTag = async (filePath, appTag) => {
  const validFileType = ['apk', 'ipa'];
  const fileType = String(path.extname(filePath)).replace('.', '');

  if (validFileType.includes(fileType)) {
    const endPoint = `${HS_API_V0}/apps/${fileType}/upload?hs_tag=${appTag}`;
    const data = await uploadApp(endPoint, filePath);

    logger.log(
      `Successfully uploaded '${fileType}' with tag '${appTag}'.\n`,
      data,
    );
  } else {
    throw new Error(
      `Unknown file type for upload - '${fileType}'!!\n Valid types: ${validFileType}`,
    );
  }
};

module.exports = {
  uploadedApks,
  uploadedIpas,
  uploadApk,
  uploadIpa,
  deleteApk,
  deleteIpa,
  uploadedApkPackageNames,
  uploadedIpaBundleIdentifiers,
  apkAppInfo,
  listAllAdbDevicesByModel,
  installApk,
  uninstallApk,
  installApkOnAllAndroidTvDevices,
  installApkOnAllFireTabDevices,
  installApkOnAllFireTvDevices,
  uninstallApkOnAllAndroidTvDevices,
  uninstallApkOnAllFireTabDevices,
  uninstallApkOnAllFireTvDevices,
  ipaAppInfo,
  installIpa,
  uninstallIpa,
  listAlliDevicesByModel,
  installIpaOnAllAppleTvDevices,
  uninstallIpaOnAllAppleTvDevices,
  uploadAppWithTag,
};
