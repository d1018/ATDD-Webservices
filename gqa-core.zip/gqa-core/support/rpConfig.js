module.exports = {
  token: process.env.RP_TOKEN,
  launch: process.env.RP_LAUNCH,
  project: process.env.RP_PROJECT,
  endpoint: process.env.RP_ENDPOINT,
  rp_enable: process.env.RP_ENABLE,
  takeScreenshot: 'onFailure',
  description: `Test execution for: ${process.env.DEVICE}`,
  attributes: [
    {
      key: 'Device',
      value: process.env.DEVICE,
    },
  ],
  mode: 'DEFAULT',
  debug: false,
  restClientConfig: {
    timeout: 0,
  },
  scenarioBasedStatistics: true,
};
