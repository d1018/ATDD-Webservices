require('./stringOverrides');
require('./handleExit');
require('dotenv').config();
const { readdirSync } = require('fs');
const fs = require('fs');
const retry = require('async-retry');
const path = require('path');
const DeviceRoute = require('@wbd/gqa-regional-routing');
const suitest = require('./platform/RemoteActions');
const appium = require('./platform/MobileActions');
const webdriver = require('./platform/BrowserActions');
const Client = require('./Client');
const headspin = require('./headspin');
const bsUtil = require('./browserStackUtil');
const { connectDevice } = require('./hookFunction');
const { paths, hiddenFileFilter } = require('../tasks/utils');
const { Devices } = require('./remoteDevices');
const { validateDeviceStatus } = require('./remoteDeviceUtilities');
const { errorReason } = require('./customErrors');
const { logger } = require('./logger');
const { PlatformName } = require('./platformName');

const {
  runtimePlatform,
  runtimeDevice,
  isFeatureFlagEnabled,
} = require('./runtimeConfig');

const randomWait = async (ms) => {
  await new Promise((res) => setTimeout(res, ms * Math.random()));
};

const sleep = async (ms) => {
  await new Promise((res) => setTimeout(res, ms));
};

const retryOption = {
  // retry HeadhSpin API calls up to 3 times
  retries: 3,
};

let connectedDevice;
let pairedDevice;
let objpairedDevice;
const remoteDevices = [
  'xbox',
  'samsung',
  'roku',
  'lg',
  'vizio',
  'playstation',
  'nowtv',
];
const testrail = new Client();
let sessionId;
const platformName = runtimePlatform().toLowerCase();
const testPlatform = {
  suitest,
  appium,
  webdriver,
};
const deviceToRun = runtimeDevice().toLowerCase();
const appiumHSDevices = ['appletv', 'androidtv', 'firetab', 'firetv'];
const isAppiumHSDevices = appiumHSDevices.includes(deviceToRun);
const platform = testPlatform[platformName];
const tokenId = process.env.SUITEST_TOKEN_KEY;
const tokenPassword = process.env.SUITEST_TOKEN_PASSWORD;
const appConfigId = process.env.SUITEST_APP_CONFIG_ID;
const logLevel = process.env.SUITEST_LOG_LEVEL;
let deviceRoute;

/**
 * Creates a directory for given path.
 *
 * @param {*} directoryPath path of directory.
 */
const ensureDirectory = (directoryPath) => {
  if (!fs.existsSync(directoryPath)) {
    fs.mkdirSync(directoryPath);
  }
};

/**
 * Attach Session ID and Session URL for both Browser Stack and Head Spin - Appium execution.
 *
 * @param {*} cucumber cucmber instance
 */
const scenarioMetaData = (cucumber) => {
  let sessionSerialId;
  let publicUrl;

  // these info should always be available on all platforms
  cucumber.attach(
    [
      'Device Info Summary:',
      '---------------------',
      platform.deviceInfoSummary(),
      '---------------------',
    ].join('\n'),
    'text/html',
  );

  if ([PlatformName.Appium, PlatformName.Webdriver].includes(platformName)) {
    [sessionSerialId, publicUrl] = isAppiumHSDevices
      ? [platform.getHsSessionId(), platform.getHsSessionUrl()]
      : [platform.getBsSessionId(), platform.getBsPublicUrl()];
  }

  if (sessionSerialId && publicUrl) {
    cucumber.attach(`Session id: ${sessionSerialId}`, 'text/html');
    cucumber.attach(`<a href=${publicUrl}>Public URL</a>`, 'text/html');
  } else if (platformName === 'suitest' && sessionId) {
    const sessionURL = `https://ui.headspin.io/sessions/${sessionId}/waterfall`;

    cucumber.attach(`Session id: ${sessionId}`, 'text/html');
    cucumber.attach(
      `Session URL: <a href=${sessionURL}>HeadSpin session URL</a>`,
      'text/html',
    );
  } else {
    cucumber.attach(`Failed to create a session!!!`, 'text/html');
  }
};

const updateSessionStatus = async (scenario) => {
  if (platformName === PlatformName.Webdriver && scenario.result) {
    await bsUtil.bsAutomateUpdateSessionStatus(
      platform.getBsSessionId(),
      scenario.result,
    );
  }
  if (
    platformName === PlatformName.Appium &&
    scenario.result &&
    !isAppiumHSDevices
  ) {
    await bsUtil.bsAppUpdateSessionStatus(
      platform.getBsSessionId(),
      scenario.result,
    );
  }
};
const captureSource = (source, logFile) => {
  // Disabling because we need to adjust the source globally (byref).
  /* eslint-disable no-param-reassign */
  source.origWrite = source.write;
  source.write = (data) => {
    const logStream = fs.createWriteStream(logFile);

    try {
      logStream.write(data);
    } catch (e) {
      // Not recorded (but don't stop the test for this)
    }

    try {
      source.origWrite(data);
    } catch (e) {
      // Not recorded (but don't stop the test for this)
    }

    logStream.end();
  };
  /* eslint-enable no-param-reassign */
};

const createMataData = ({ orgId, command }) => `
  Suitest test execution log
  --------------------------

  - Date ${new Date().toUTCString()}.
  - Organization ID: ${orgId}
  - App config ID: ${''}
  - Test command: ${command}

    `;
// Directly taken from the suitest codde (adapted where necessary)
const getLogFilePath = (deviceId, deviceName) => {
  const [shortId] = deviceId.split('-');
  const shortName = deviceName.replace(/[^a-z0-9]/gi, '-');

  // Produces 'YYYYMMDD-HHmmss'
  const timePrefix = new Date()
    .toISOString()
    .replace(/-/g, '')
    .replace(/([0-9]*)[A-Z]/, '$1-')
    .replace(/\..*$/, '')
    .replace(/:/g, '');

  const fileName = `${timePrefix}-${shortId}-${shortName}.log`;
  const logRemoteDevicesPath = path.join(paths.logs, 'remoteDevices');

  ensureDirectory(logRemoteDevicesPath);
  return path.join(logRemoteDevicesPath, fileName);
};

// Items that need to be patched to capture output for the suitest log.
const sources = ['stdout', 'stderr'];

const captureSources = ({ deviceId, manufacturer, model }) => {
  const logFile = getLogFilePath(deviceId, `${manufacturer}-${model}`);
  const logStream = fs.createWriteStream(logFile);

  logStream.write(createMataData({}));
  logStream.end();

  sources.forEach((source) => captureSource(process[source], logFile));
};

const resetSources = () => {
  sources.forEach(
    (source) => (process[source].write = process[source].origWrite),
  );
};

const logs = () => readdirSync(paths.logs).filter(hiddenFileFilter);

/**
 * Type of log.
 *
 * @param {data} data log details
 * @param {type} type of the logs
 *  @param {scenarioName} scenarioName of the scenario
 */
const eventHandler = (data, type, scenarioName) => {
  try {
    if (data !== undefined && data.toString().length > 0) {
      const contents = data.pop().toString();

      if (contents.length > 0) {
        const eventType = type === 'consoleLog' ? 'device' : 'network';

        logger.log(eventType, { name: scenarioName, data: contents });
      }
    }
  } catch (e) {
    logger.error(e);
  }
};

exports.beforeAll = async (cucumber, testrailConfig) => {
  const hookName = 'BeforeAll';

  try {
    if (testrail.sendResults()) {
      if (testrail.createCustomPlan()) {
        await testrail.createPlanWithoutEntry(testrailConfig.suite_id);
      } else {
        await testrail.createPlan(testrailConfig.suite_id);
      }
    }
    if (isAppiumHSDevices && !isFeatureFlagEnabled('LOCAL_EXECUTION')) {
      await randomWait(30 * 1000);
    }
    if (remoteDevices.includes(deviceToRun)) {
      await platform.openAppSession(tokenId, tokenPassword);
      await platform.setAppConfig(appConfigId);
      await platform.setLogLevel(logLevel);

      if (headspin.isHeadspinSuitestMode() && process.env.PARALLEL) {
        await randomWait(30 * 1000);
      }

      connectedDevice = await connectDevice();

      if (isFeatureFlagEnabled('ENABLE_REGIONAL_ROUTING')) {
        if (platformName === 'suitest') {
          const devices = Devices.loadDevices();
          const device = devices[connectedDevice.suitestDeviceId];

          deviceRoute = new DeviceRoute({
            device_address: device.dutAddress,
            hs_token: process.env.HS_TOKEN,
          });
          await deviceRoute.assignTunnel(process.env.GEO);
          // will keep this sleep implementation in case we might
          // need to quickly put it back due to stability issues with regional routing.
          // TODO: remove once stability from regional routing API is guaranteed.
          await sleep(0);
          logger.log('tunnel has been set.');
        }
      }
    }
  } catch (ex) {
    logger.error(`error detected from ${hookName} hook!`);
    logger.error(ex);
    throw ex;
  }
};

/**
 *
 * @param {*} cucumber // eslint-disable-line
 * @param {*} scenario // eslint-disable-line
 * @param {*} Status  - Different Cucumber Statuses - Skipped,Aborted, etc-
 * @param {*} skipReason  - Different skip reason
 * Refer to this document for more insights - https://github.com/cucumber/cucumber-js/blob/main/features/skipped_steps.feature
 */
exports.afterStep = (cucumber, scenario, Status, skipReason) => {
  const hookName = 'AfterStep';

  try {
    const skipReasonArray = Object.values(skipReason);

    for (let i = 0; i < skipReasonArray.length; i++) {
      if ((scenario.result.message || '').includes(skipReasonArray[i])) {
        scenario.result.status = Status.SKIPPED; // eslint-disable-line no-param-reassign
        cucumber.attach(JSON.stringify(skipReasonArray[i]), 'text/html');
      }
    }
  } catch (ex) {
    logger.error(`error detected from ${hookName} hook!`);
    logger.error(ex);
    throw ex;
  }
};

exports.before = async (cucumber, testrailConfig, scenario) => {
  const hookName = 'Before';

  try {
    if (remoteDevices.includes(deviceToRun)) {
      await validateDeviceStatus(connectedDevice);

      objpairedDevice = await platform.getSuitest();

      objpairedDevice.on('consoleLog', ({ data, type }) => {
        eventHandler(data, type, scenario.pickle.name);
      });

      objpairedDevice.on('networkLog', ({ data, type }) => {
        eventHandler(data, type, scenario.pickle.name);
      });

      pairedDevice = objpairedDevice.getPairedDevice();

      captureSources(pairedDevice);

      cucumber.attach(
        `Device info: ${JSON.stringify(pairedDevice)}`,
        'text/html',
      );

      await platform.openApp();

      const { deviceId } = pairedDevice;

      try {
        if (headspin.isHeadspinSuitestMode() && deviceId) {
          const devices = Devices.loadDevices();
          const device = devices[deviceId];

          try {
            await retry(async () => {
              // make sure the device is locked and if it isn't,
              // we will try to lock it before creating a recording session
              const isLocked = await headspin.checkIfDeviceLocked(
                device.deviceId,
              );

              if (!isLocked) {
                await headspin.toggleLock(device.deviceId, true);
              }

              sessionId = await headspin.createRecordingSession(
                device.deviceAddress,
              );
            }, retryOption);
            cucumber.attach(`Device: ${device.name}`, 'text/html');
          } catch (e) {
            // unset session Id as we fail to create record session
            // (so there is no session to clean up later on)
            sessionId = undefined;

            const errorMsg = `Failed to create record session: ${e}`;

            logger.error(errorMsg);
            cucumber.attach(errorMsg, 'text/html');
          }
        }
      } catch (e) {
        logger.error(`failed to paired device: ${e}`);
      }
    }
    if (testrail.sendResults()) {
      await testrail.appendTestCase(testrailConfig.suite_id, scenario);
      if (testrail.createCustomPlan()) {
        await testrail.getTestCaseId(testrailConfig.suite_id, scenario);
      }
    }
  } catch (ex) {
    logger.error(`error detected from ${hookName} hook!`);
    logger.error(ex);
    throw ex;
  }
};

exports.after = async (testrailConfig, scenario, cucumber, Status) => {
  const hookName = 'After';

  try {
    if (
      [PlatformName.Appium, PlatformName.Webdriver].includes(platformName) &&
      scenario.result.status === Status.FAILED
    ) {
      // dump the page src if we are performing Selenium or Appium test
      // in case of a failed test
      await platform.getPageSource();
    }

    await updateSessionStatus(scenario);

    if (
      !isFeatureFlagEnabled('LOCAL_EXECUTION') ||
      headspin.isHeadspinSuitestMode()
    ) {
      scenarioMetaData(cucumber);
    }

    if (remoteDevices.includes(deviceToRun)) {
      try {
        if (!scenario.result.status.includes(Status.PASSED)) {
          const base64ss = await platform.takeScreenshot('base64');
          const { gherkinDocument, pickle } = scenario;
          const featureName = gherkinDocument.feature.name;
          const scenarioName = pickle.name;
          const screenshotFile = `${featureName}-${scenarioName}.png`
            .replace(/ /g, '_')
            .replace(/[^a-zA-Z0-9.\-_]/g, '');

          await cucumber.attach(base64ss, 'image/png');
          ensureDirectory(paths.screenshots);
          await platform.saveScreenshot(
            path.join(paths.screenshots, screenshotFile),
          );
        }
      } catch (err) {
        const errorMsg = `Failed to attach screenshot: ${err}`;

        logger.error(errorMsg);
        cucumber.attach(errorMsg, 'text/html');
      }

      if (headspin.isHeadspinSuitestMode()) {
        try {
          await retry(async () => {
            if (sessionId) {
              await headspin.stopRecordingSession(sessionId);
            }
          }, retryOption);
        } catch (e) {
          const errorMsg = `Headspin Error on stopRecordingSession: ${e}`;

          cucumber.attach(errorMsg, 'text/html');
        }
      }

      try {
        await retry(async () => {
          await objpairedDevice.closeApp();
        }, retryOption);
      } catch (e) {
        const errorMsg = `Suitest error on close app: ${e}`;

        cucumber.attach(errorMsg, 'text/html');
      }
      const logData = logs().map(
        (log) =>
          `<li><a href='${path.join(
            paths.logs,
            log,
          )}' target='_blank'>${log}</a></li>`,
      );
      const logList = `<ul>${logData.join('')}</ul>`;

      cucumber.attach(`Screenshot and device logs:\n${logList}`, 'text/html');

      resetSources();
    } else if (
      !(scenario.result.message || '').includes(
        errorReason.functionTimeout.toString(),
      )
    ) {
      await platform.closeApp();
    }
    if (testrail.sendResults()) {
      await testrail.appendResult(testrailConfig.suite_id, scenario);
    }
  } catch (ex) {
    logger.error(`error detected from ${hookName} hook!`);
    logger.error(ex);
    throw ex;
  }
};

exports.afterAll = async (cucumber, testrailConfig) => {
  const hookName = 'AfterAll';

  try {
    const promises = [];

    if (remoteDevices.includes(deviceToRun)) {
      if (headspin.isHeadspinSuitestMode()) {
        objpairedDevice = await platform.getSuitest();
        pairedDevice = objpairedDevice.getPairedDevice();
        const { deviceId } = pairedDevice;

        try {
          await retry(async () => {
            if (
              deviceRoute &&
              isFeatureFlagEnabled('ENABLE_REGIONAL_ROUTING')
            ) {
              await deviceRoute.dropTunnel();
            }
            await headspin.unlockDevice(deviceId);
          }, retryOption);
        } catch (e) {
          const errorMsg = `Headspin Error on unlock device: ${e}`;

          logger.error(errorMsg);
        }
      }
      try {
        await retry(async () => {
          await platform.releaseDevice();
        }, retryOption);
      } catch (e) {
        const errorMsg = `Suitest error on release device: ${e}`;

        logger.error(errorMsg);
        cucumber.attach(errorMsg, 'text/html');
      }

      const closeSession = async () => {
        try {
          await platform.closeSession();
          logger.log('Successfully closed Suitest session');
        } catch (e) {
          logger.error('Failed to close session:', e);
        }
      };

      promises.push(closeSession());
    }

    if (testrail.sendResults()) {
      if (testrail.createCustomPlan()) {
        await testrail.addTestRunToPlanWithCaseIds(testrailConfig.suite_id);
      }
      const postTestRailActions = async () => {
        // These 2 need to run in order.
        try {
          await testrail.publishResults();
          logger.log('Successfully published results'.GREEN_BOLD());
        } catch (e) {
          logger.error('Failed to publish results:'.RED_BOLD(), e);
        }

        try {
          await testrail.saveTestRunUrl();
          logger.log('Successfully saved test url'.GREEN_BRIGHT());
        } catch (e) {
          logger.error('Failed to save test url:'.RED_BRIGHT(), e);
        }
      };

      promises.push(postTestRailActions());
    }

    await Promise.all(promises);
  } catch (ex) {
    logger.error(`error detected from ${hookName} hook!`);
    logger.error(ex);
    throw ex;
  }
};
