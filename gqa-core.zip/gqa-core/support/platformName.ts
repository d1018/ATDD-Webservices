// Copyright text placeholder, Warner Bros. Discovery, Inc.

/**
 * Name of various platforms that we currently support
 */
export const PlatformName: Readonly<Record<string, string>> = {
  Webdriver: 'webdriver',
  Appium: 'appium',
  Suitest: 'suitest',
};
