const browserActions = require('./platform/BrowserActions');
const mobileActions = require('./platform/MobileActions');
const remoteActions = require('./platform/RemoteActions');
const RemoteDefaults = require('./platform/RemoteDefaults');

const globalHooks = require('./hooks');
const customErrors = require('./customErrors');
const paths = require('./paths');
const testdataHelper = require('./testdataHelper');

module.exports = {
  browserActions,
  mobileActions,
  remoteActions,

  globalHooks,
  customErrors,
  testdataHelper,

  ...RemoteDefaults,
  ...paths,
};
