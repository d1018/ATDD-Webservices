/* eslint-disable no-extend-native */
const colors = require('./colors');

const colorNames = Object.keys(colors);

colorNames.forEach(
  (color) =>
    (String.prototype[color] = function strcolor() {
      // return `${colors[color]}${this}${colors.RESET}`
      let newStr = `${colors[color]}${this}`;

      if (!newStr.endsWith(colors.RESET)) {
        newStr = `${newStr}${colors.RESET}`;
      }

      return newStr;
    }),
);
