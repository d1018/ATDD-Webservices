// Copyright text placeholder, Warner Bros. Discovery, Inc.

/**
 * Type guard that determines whether its argument has the property `propertyName`.
 *
 * Wraps `Object.hasOwn()` as a type guard.
 *
 * @param obj - An object.
 * @param propertyName - The name of a possible property.
 * @returns `true` if `obj` has a property `propertyName`; otherwise, false.
 */
export function hasProperty<TPropertyName extends string>(
  obj: object,
  propertyName: TPropertyName,
): obj is { [key in TPropertyName]: unknown } {
  return Object.prototype.hasOwnProperty.call(obj, propertyName);
}

/**
 * Type guard that determines whether its argument is a non-null `object`.
 *
 * @param maybeObject - The value whose type is being checked.
 * @returns boolean - `true` if `maybeObject` is a non-`null` `object`.
 */
export function isObject(maybeObject: unknown): maybeObject is object {
  const isObjectOrNull: boolean = typeof maybeObject === 'object';
  const isNotNull: boolean = maybeObject !== null;

  return isObjectOrNull && isNotNull;
}

/**
 * Type guard that determines whether its argument is an Error object.
 *
 * @param maybeError - The value whose type is being checked.
 * @returns boolean - `true` if `maybeError` is an Error.
 */
export function isError(maybeError: unknown): maybeError is Error {
  if (!isObject(maybeError)) {
    return false;
  }
  if (maybeError instanceof Error) {
    return true;
  }
  return (
    hasProperty(maybeError, 'message') &&
    hasProperty(maybeError, 'stack') &&
    typeof maybeError.message === 'string' &&
    maybeError.message !== '' &&
    typeof maybeError.stack === 'string' &&
    maybeError.stack !== ''
  );
}

/**
 * Given an array of items and a partitioning function, return an array of the partition
 * hits and misses.
 *
 * @param items - An array to be partitioned by the result of the given filter function.
 * @param filter - A function by which we partition items.
 * @returns Two arrays, the first containing all of `items` that pass the filter, and the
 * second containing all of the `items` that do not pass the filter.
 */
export function partition<T>(
  items: T[],
  filter: (element: T) => boolean,
): [T[], T[]] {
  const hits: T[] = [];
  const misses: T[] = [];

  items.forEach((item) => (filter(item) ? hits : misses).push(item));

  return [hits, misses];
}

/**
 * Partitions items from a list into those which satisfy a type guard and those which do
 * not satisfy that type guard. The returned lists are strongly typed according to the
 * type guard's return type.
 *
 * @param items - A list of items to be partitioned by their type, as determined by the
 * type guard function `isOfType`.
 * @param isOfType - A type guard function which is used to determine the partitioning of
 * `items` into two lists, by type.
 * @returns Two arrays, the first containing all of the elements of `items` that are of a type
 * recognized by `isOfType`, and the second containing all of the elements of `items` that are
 * of a type that is not recognized by `isOfType`.
 */
export function partitionByType<TParent, TGuarded extends TParent>(
  items: TParent[],
  isOfType: (item: TParent) => item is TGuarded,
): [TGuarded[], Exclude<TParent, TGuarded>[]] {
  const guarded: TGuarded[] = [];
  const other: Exclude<TParent, TGuarded>[] = [];

  items.forEach((item) =>
    isOfType(item)
      ? guarded.push(item)
      : other.push(item as Exclude<TParent, TGuarded>),
  );
  return [guarded, other];
}

/**
 * Type-narrowing assertion function for arbitrary conditions.
 *
 * @param condition - An arbitrary boolean condition which the type-checker will know
 * to be true if this function returns.
 * @param message - The message for the Error that will be thrown if the given condition
 * is not true.
 */
export function assert(
  condition: unknown,
  message?: string,
): asserts condition {
  if (!condition) {
    throw new Error(message);
  }
}
