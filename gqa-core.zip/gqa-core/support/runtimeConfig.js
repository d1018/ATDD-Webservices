const { logger } = require('./logger');

/**
 * parse and read an integer from a string
 * return the defualt vlaue if the string is undefined or un-parsable
 *
 * @param {string} val string to parse
 * @param {number} defaultVal default value to return if string is undefinded or un-parsable
 * @returns {number} an integer parsed from the string
 */
const readIntFromEnv = (val, defaultVal) => {
  if (val) {
    const parsed = Number.parseInt(val, 10);

    // return default value if the value can't be parsed to an int
    return Number.isNaN(parsed) ? defaultVal : parsed;
  }
  return defaultVal;
};

/**
 * check if a feature flag is enabled
 *
 * Note: a feature flag is considered set when process.env.FEATURE_FLAG_NAME is set to
 * 'true' or '1' (case insensitive match)
 *
 * @param {*} name name of the env variable to read
 * @returns {boolean} true if set; false otherwise
 */
const isFeatureFlagEnabled = (name) =>
  name in process.env && /true|1/i.test(process.env[name].trim());

/**
 * read an environmental variable from process.env
 * defaultVal is returned if the env var is NOT set or throw an exception otherwise
 *
 * @param {string} name name of the env variable to read
 * @param {string} defaultVal default value to return if the env var is not set
 * @returns {string} value of process.env.YOUR_VAR
 */
const readEnvVar = (name, defaultVal) => {
  if (name in process.env) {
    return process.env[name];
  }

  if (defaultVal !== undefined && defaultVal !== null) {
    logger.warn(
      `process.env.${name} is not set; defaulting value to "${defaultVal}"`,
    );
    return defaultVal;
  }

  throw new Error(
    `process.env.${name} is a mandatory field! Please check your configuration!`,
  );
};

/**
 * get platform name from env var; throw if not set
 *
 * @returns {string} value of process.env.PLATFORM
 */
const runtimePlatform = () => readEnvVar('PLATFORM');

/**
 * get project name from env var; default to 'DTC' if not set
 *
 * @returns {string} value of process.env.PROJECT
 */
const runtimeProject = () => readEnvVar('PROJECT', 'DTC');

/**
 * get device name from env var; throw if not set
 *
 * @returns {string} value of process.env.DEVICE
 */
const runtimeDevice = () => readEnvVar('DEVICE');

/**
 * get device name from env var; default to "unknown" if not set
 *
 * @returns {string} value of process.env.DEVICE_NAME
 */
const runtimeDeviceName = () => readEnvVar('DEVICE_NAME', 'unknown');

/**
 * get device model name from env var; default to "unknown" if not set
 *
 * @returns {string} value of process.env.MODEL
 */
const runtimeDeviceModel = () => readEnvVar('MODEL', 'unknown');

/**
 * get geolocation; default to 'us' if not set
 *
 * @returns {string} value of process.env.GEO
 */
const runtimeGeolocation = () => readEnvVar('GEO', 'us');

/**
 * get the Jira config file path from env var
 *
 * @returns {string} path to the JIRA config file
 */
const getJiraConfigFile = () => process.env.JIRA_CONFIG_FILE;

/**
 *: test environment for the test execution; set via setEnvVars()
 *
 * @returns {string} test env
 */
const runTimeEnvironment = () => process.env.TEST_ENV;

/**
 * test type for the test execution; set via setEnvVars()
 *
 * @returns {string} test type
 */
const runTimeTestType = () => process.env.TEST_TYPE;

/**
 * SSM file used for the test execution; set via setEnvVars()
 *
 * @returns {string} test type
 */
const runTimeSSMFile = () => process.env.SSM_FILE;

/**
 * HeadSpin token for authentication.
 *
 * @returns {string} HS token value
 */
const runTimeHSToken = () => process.env.HS_TOKEN;

/**
 * Get the browser from env var
 *
 * @returns {string} browser
 */
const runTimeBrowser = () => readEnvVar('BROWSER', 'chrome');

module.exports = {
  readIntFromEnv,
  isFeatureFlagEnabled,
  runtimeDevice,
  runtimePlatform,
  runtimeGeolocation,
  runtimeDeviceModel,
  runtimeDeviceName,
  runtimeProject,
  runTimeEnvironment,
  runTimeSSMFile,
  runTimeTestType,
  getJiraConfigFile,
  runTimeHSToken,
  runTimeBrowser,
};
