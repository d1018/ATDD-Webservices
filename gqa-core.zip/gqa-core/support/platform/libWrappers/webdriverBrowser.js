const { Builder, until, Key, WebElement } = require('selenium-webdriver');

const assert = require('assert');
const { runTimeBrowser } = require('../../runtimeConfig');
const { logger } = require('../../logger');

class WebdriverBrowser {
  _baseUrl;

  _serverUrl;

  _localExecution;

  _sessionExists = false;

  baseURL(login, password, url) {
    const appURL = url.replace('https://', '');

    this._baseUrl =
      typeof login !== 'undefined'
        ? `https://${login}:${password}@${appURL}`
        : `https://${appURL}`;
  }

  getDriverInstance(localExecution, desiredWebCapabilities, bsServerUrl) {
    if (localExecution === 'true') {
      return new Builder().forBrowser(runTimeBrowser()).build();
    }
    return new Builder()
      .usingServer(bsServerUrl)
      .withCapabilities(desiredWebCapabilities)
      .build();
  }

  getDriver() {
    return this._driver;
  }

  getBsSessionInfo() {
    return this._bsSessionInfo;
  }

  getBsSessionId() {
    return this._bsSessionId;
  }

  getBsPublicUrl() {
    return this._bsPublicUrl;
  }

  getBsNetworkLogsUrl() {
    return this._bsNetworkLogsUrl;
  }

  getBsBrowserConsoleLogsUrl() {
    return this._bsBrowserConsoleLogsUrl;
  }

  getBsSeleniumLogsUrl() {
    return this._bsSeleniumLogsUrl;
  }

  getPageSource = async () => {
    try {
      return await this._driver.getPageSource();
    } catch (ex) {
      // intentionally swallow the error when we fail to take page source
      // and return empty string instead
      // note:
      // the screen dump is for troubleshooting purpose, and we don't want to
      // fail test just because of this
      logger.warn('failed to take page source!');
      logger.warn(ex);
      return '';
    }
  };

  setMaximizeWindow = async () => {
    await this._driver.manage().window().maximize();
  };

  /**
   * This method is used to get the size of the browser window
   */
  getWindowSize = async () => {
    const windowSizeObj = await this._driver.manage().window().getRect();

    return windowSizeObj;
  };

  /**
   * This method quits the entire browser session with all its tabs and windows
   */
  closeApp = async () => {
    if (this._sessionExists) await this._driver.quit();
    this._sessionExists = false;
  };

  /**
   * This method will set implicit timeout for the driver
   *
   * @param {number} time delay value in seconds
   */
  #setImplicitTimeout = async (time) => {
    await this._driver.manage().setTimeouts({ implicit: time * 1000 });
  };

  /**
   * This method will set implicit timeout for the driver to 20 seconds
   */
  #setDefaultImplicitTimeout = async () => {
    await this._driver.manage().setTimeouts({ implicit: 20000 });
  };

  driverInit(serverUrl, localExecution) {
    this._serverUrl = serverUrl;
    this._localExecution = localExecution;
  }

  openApp = async (desiredWebCapabilities) => {
    this._driver = this.getDriverInstance(
      this._localExecution,
      desiredWebCapabilities,
      this._serverUrl,
    );

    this._sessionExists = true;
    await this.setMaximizeWindow();

    if (this._localExecution !== 'true') {
      await this.bsSessionInfo();
    }

    await this.#setDefaultImplicitTimeout();
    await this._driver.get(`https://www.maxmind.com/en/locate-my-ip-address`);

    await this._driver.get(this._baseUrl);
  };

  deepLinkTo = async (url) => {
    await this._driver.get(url);
  };

  switchTab = async (tabNumber) => {
    const windows = await this._driver.getAllWindowHandles();

    if (tabNumber >= windows.length) {
      throw new Error('tab index out of bounds');
    }
    await this._driver.switchTo().window(windows[tabNumber]);
  };

  getAuthURL = async () => {
    let currentURL = await this._driver.getCurrentUrl();

    currentURL = currentURL.replace('https://', '');
    const authUrl = `https://${process.env.LOGIN_DTC}:${process.env.PASSWORD_DTC}@${currentURL}`;

    await this._driver.get(authUrl);
  };

  #elementFetcher = async (locator) => {
    const element =
      (await locator) instanceof WebElement
        ? locator
        : this._driver.findElement(locator);

    return element;
  };

  /**
   * To click on the web element
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  click = async (locator, time = 20) => {
    await this.#setImplicitTimeout(time);
    const element = await this.#elementFetcher(locator);

    await element.click();
    await this.#setDefaultImplicitTimeout();
  };

  /**
   * This method is used find element on the page
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @returns {*} WebElement
   */
  findElement = async (locator) => {
    const element = await this._driver.findElement(locator);

    return element;
  };

  /**
   * This method is used find multiple elements on the page
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @returns {*} WebElements
   */
  findElements = async (locator) => {
    const element = await this._driver.findElements(locator);

    return element;
  };

  /**
   * This returns a boolean value based on whether element is displayed or not
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   * @returns {boolean}  Boolean value based on element visibility
   */
  isDisplayed = async (locator, time = 20) => {
    await this.#setImplicitTimeout(time);
    try {
      const element = await this.#elementFetcher(locator);

      return element.isDisplayed();
    } catch (error) {
      return false;
    } finally {
      await this.#setDefaultImplicitTimeout();
    }
  };

  /**
   * This returns a boolean value based on whether element is enabled or not
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   * @returns {boolean} Boolean value based on element enabled condition
   */
  isEnabled = async (locator, time = 20) => {
    await this.#setImplicitTimeout(time);
    try {
      const element = await this.#elementFetcher(locator);

      return element.isEnabled();
    } catch (error) {
      return false;
    } finally {
      await this.#setDefaultImplicitTimeout();
    }
  };

  /**
   * Gets the size of the given element
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   */
  getElementSizeAndLocation = async (locator) => {
    const element = await this.#elementFetcher(locator);

    return element.getRect();
  };

  /**
   * This method waits for element to be visible for the given time
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time time delay value in seconds, 30.
   */
  waitUntil = async (locator, time = 30) => {
    await this._driver.wait(
      until.elementIsVisible(await this.#elementFetcher(locator), time * 1000),
    );
  };

  /**
   * This method is used to send text to and element
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {string} data text to be passed
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  sendText = async (locator, data, time = 20) => {
    await this.#setImplicitTimeout(time);
    const element = await this.#elementFetcher(locator);

    await element.clear();
    await element.sendKeys(data);
    await this.#setDefaultImplicitTimeout();
  };

  /**
   * This method returns element text
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   * @returns {string} text value of the element
   */
  getText = async (locator, time = 20) => {
    await this.#setImplicitTimeout(time);
    const element = await this.#elementFetcher(locator);

    await this.#setDefaultImplicitTimeout();
    return element.getText();
  };

  /**
   * This method returns text value of the element's attribute.
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {string} attributeName The name of the attribute to query.
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   * @returns {string} text value of the element's attribute.
   */
  getAttribute = async (locator, attributeName, time = 20) => {
    await this.#setImplicitTimeout(time);
    const element = await this.#elementFetcher(locator);

    await this.#setDefaultImplicitTimeout();
    return element.getAttribute(attributeName);
  };

  /**
   * This method is used to perform arrow down function
   *
   * @param {number} count Number of times you want to perform arrow down operation . Default value is 1
   */
  arrowDown = async (count = 1) => {
    const actions = this._driver.actions();

    for (let i = 0; i < count; i++) {
      await actions.sendKeys(Key.ARROW_DOWN).perform();
    }
  };

  /**
   * This method is used to perform arrow up function
   *
   * @param {number} count Number of times you want to perform arrow up operation . Default value is 1
   */
  arrowUp = async (count = 1) => {
    const actions = this._driver.actions();

    for (let i = 0; i < count; i++) {
      await actions.sendKeys(Key.ARROW_UP).perform();
    }
  };

  /**
   * This method is used to perform page up function
   *
   * @param {number} count Number of times you want to perform page up operation . Default value is 1
   */
  pageUp = async (count = 1) => {
    const actions = this._driver.actions();

    for (let i = 0; i < count; i++) {
      await actions.sendKeys(Key.PAGE_UP).perform();
    }
  };

  /**
   * This method is used to perform page down function
   *
   * @param {number} count Number of times you want to perform page down operation . Default value is 1
   */
  pageDown = async (count = 1) => {
    const actions = this._driver.actions();

    for (let i = 0; i < count; i++) {
      await actions.sendKeys(Key.PAGE_DOWN).perform();
    }
  };

  /**
   * Scrolls to the top of the page.
   */
  scrollToPageTop = async () => {
    await this._driver.executeScript(
      'window.scrollTo(document.body.scrollHeight, 0)',
    );
  };

  /**
   * This method is used to perform page down function
   */
  pageBottom = async () => {
    await this._driver.executeScript(
      'window.scrollTo(0, document.body.scrollHeight)',
    );
  };

  /**
   * This method will hover over the element
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  hover = async (locator, time = 20) => {
    await this.#setImplicitTimeout(time);
    const element = await this.#elementFetcher(locator);
    const actions = this._driver.actions({ async: true });

    await actions.move({ origin: element }).perform();
    await this.#setDefaultImplicitTimeout();
  };

  /**
   * This method will click and hold the element
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  clickAndHold = async (locator, time = 20) => {
    await this.#setImplicitTimeout(time);
    const element = await this.#elementFetcher(locator);
    const actions = this._driver.actions({ async: true });

    await actions.move({ origin: element }).press().perform();
    await this.#setDefaultImplicitTimeout();
  };

  /**
   * This method will click and hold the element
   *
   * @param {*} fromLocator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {*} distanceDetails Object e.g. {
   *      toLocator: Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement. Will default to moving to an element if toLocator is provided. Otherwise, will use provided offset
   *      offset: An object with pixel coordinates, e.g. { x: 100, y: 20 }. Default is 100 pixels to the right
   * }
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  clickAndDrag = async (fromLocator, distanceDetails, time = 20) => {
    await this.#setImplicitTimeout(time);
    const fromElement = await this.#elementFetcher(fromLocator);
    const actions = this._driver.actions({ async: true });
    let offset;

    if (distanceDetails.toLocator) {
      const toElement = await this.#elementFetcher(distanceDetails.toLocator);

      await actions.dragAndDrop(fromElement, toElement).perform();
    } else {
      offset = distanceDetails.offset ?? { x: 100, y: 0 };
      actions.dragAndDrop(fromElement, offset).perform();
    }
    await this.#setDefaultImplicitTimeout();
  };

  /**
   * This method will release the element
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  clickAndRelease = async (locator, time = 20) => {
    await this.#setImplicitTimeout(time);
    const element = await this.#elementFetcher(locator);
    const actions = this._driver.actions({ async: true });

    await actions.move({ origin: element }).click().perform();
    await this.#setDefaultImplicitTimeout();
  };

  /**
   * This method is used to scroll to an element
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} maxTries Maximum number of tries
   * @param {number} time Delay value in seconds. Default value is 20 seconds
   * @returns {Error} Error if element is not found after maxTries
   */
  scrollToElement = async (locator, maxTries, time = 20) => {
    for (let i = 1; i <= maxTries; i++) {
      if (await this.isDisplayed(locator, time)) return;
      await this.pageDown();
    }
    throw new Error(
      `Cannot scroll to Element ${JSON.stringify(
        locator,
      )} with ${maxTries} scroll tries`,
    );
  };

  bsSessionInfo = async () => {
    this._bsSessionInfo = JSON.parse(
      await this._driver.executeScript(
        'browserstack_executor: {"action": "getSessionDetails"}',
      ),
    );

    this._bsSessionId = await this.#setSessionDetails(
      this._bsSessionInfo,
      'hashed_id',
    );
    this._bsPublicUrl = await this.#setSessionDetails(
      this._bsSessionInfo,
      'public_url',
    );
    this._bsNetworkLogsUrl = await this.#setSessionDetails(
      this._bsSessionInfo,
      'har_logs_url',
    );
    this._bsBrowserConsoleLogsUrl = await this.#setSessionDetails(
      this._bsSessionInfo,
      'browser_console_logs_url',
    );
    this._bsSeleniumLogsUrl = await this.#setSessionDetails(
      this._bsSessionInfo,
      'selenium_logs_url',
    );
  };

  #setSessionDetails = (sessionDetails, key) => {
    if (sessionDetails[key]) {
      return sessionDetails[key];
    }
    return '';
  };

  /**
   * This method is used to assert whether an element is displayed or not
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {boolean} expectedValue true or false
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  assertDisplay = async (locator, expectedValue, time = 20) => {
    await this.#setImplicitTimeout(time);
    const element = await this.#elementFetcher(locator);

    await this.#setDefaultImplicitTimeout();
    if (expectedValue === true) {
      assert.strictEqual(
        await element.isDisplayed(),
        true,
        'Element not displayed',
      );
    } else {
      assert.strictEqual(
        await element.isDisplayed(),
        false,
        'Element is displayed',
      );
    }
  };

  /**
   * This method is used to assert whether an element is enabled or not
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {boolean} expectedValue true or false
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  assertEnable = async (locator, expectedValue, time = 20) => {
    await this.#setImplicitTimeout(time);
    const element = await this.#elementFetcher(locator);

    await this.#setDefaultImplicitTimeout();
    if (expectedValue === true) {
      assert.strictEqual(
        await element.isEnabled(),
        true,
        'Element not enabled',
      );
    } else {
      assert.strictEqual(
        await element.isEnabled(),
        false,
        'Element is enabled',
      );
    }
  };

  /**
   * This method is used to click on browser back button
   */
  clickBack = async () => {
    await this._driver.navigate().back();
  };

  /**
   * This method is used to get the current URL
   *
   * @returns {string} current URL
   */
  getCurrentUrl = async () => {
    const url = await this._driver.getCurrentUrl();

    return url;
  };

  /**
   * This method is used to refresh the browser
   */
  refreshPage = async () => {
    await this._driver.navigate().refresh();
  };

  /**
   * This method is used to scroll upto an element till the element is visible
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   */
  scrollIntoView = async (locator) => {
    await this._driver.executeScript(
      'document.querySelector(arguments[0]).scrollIntoView();',
      locator,
    );
  };

  /**
   * This method is used to switch to an iframe
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  switchToIframe = async (locator, time = 20) => {
    await this.#setImplicitTimeout(time);
    const element = await this.#elementFetcher(locator);

    await this._driver.switchTo().frame(element);
    await this.#setDefaultImplicitTimeout();
  };

  /**
   * This method is used to switch back to default content or parent frame
   */
  switchToDefaultContent = async () => {
    await this._driver.switchTo().defaultContent();
  };

  /**
   * This method is used to get shadow root of the input locator
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   * @returns {*} Shadow root of the input locator
   */
  getShadowRoot = async (locator, time = 20) => {
    await this.#setImplicitTimeout(time);
    const element = await this.#elementFetcher(locator);
    const shadowRootElement = await element.getShadowRoot();

    await this.#setDefaultImplicitTimeout();
    return shadowRootElement;
  };

  /**
   * This method is used to get shadow element from the input shadow root
   *
   * @param {*} shadowRoot Shadow root element
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   * @returns {*} WebElement
   */
  getShadowElement = async (shadowRoot, locator, time = 20) => {
    await this.#setImplicitTimeout(time);
    const shadowElement = await shadowRoot.findElement(locator);

    await this.#setDefaultImplicitTimeout();
    return shadowElement;
  };
}

module.exports = new WebdriverBrowser();
