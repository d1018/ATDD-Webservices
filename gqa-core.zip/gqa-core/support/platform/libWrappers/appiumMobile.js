const wd = require('wd');
const { logger } = require('../../logger');
const bsUtil = require('../../browserStackUtil');
const remoteDefaults = require('../RemoteDefaults');
const { runtimeDevice } = require('../../runtimeConfig');

const hsToken = process.env.HS_TOKEN;
const headspinServerURL = `https://appium-dev.headspin.io:443/v0/${hsToken}/wd/hub`;
const headSpinAppiumDevices = ['appletv', 'androidtv', 'firetab', 'firetv'];
const { Element } = wd;
const device = runtimeDevice().toLowerCase();
const isHeadspinDevice = headSpinAppiumDevices.includes(device);

class AppiumMobile {
  _driver;

  _appOpen = false;

  _localExecution = false;

  get driver() {
    return this._driver;
  }

  getBsSessionInfo() {
    return this._bsSessionInfo;
  }

  getBsSessionId() {
    return this._bsSessionId;
  }

  getBsBuildId() {
    return this._bsBuildId;
  }

  getBsPublicUrl() {
    return this._bsPublicUrl;
  }

  getBsTextLogsUrl() {
    return this._bsTextLogsUrl;
  }

  getBsDeviceLogsUrl() {
    return this._bsDeviceLogsUrl;
  }

  getBsAppiumLogsUrl() {
    return this._bsAppiumLogsUrl;
  }

  /**
   * Gets Head spin session ID.
   *
   * @returns {string} Head Spin Session ID
   */
  getHsSessionId() {
    return this._hsSessionId;
  }

  /**
   * Gets Head Spin URL for current session.
   *
   * @returns {string} Head Spin Session URL
   */
  getHsSessionUrl() {
    return this._hsPublicUrl;
  }

  getPageSource = async () => {
    try {
      return await this.doRequest('source');
    } catch (ex) {
      // intentionally swallow the error when we fail to take page source
      // and return empty string instead
      // note:
      // the screen dump is for troubleshooting purpose, and we don't want to
      // fail test just because of this
      logger.warn('failed to take page source!');
      logger.warn(ex);
      return '';
    }
  };

  driverInit(serverUrl, localExecution) {
    this._localExecution = localExecution;

    // decide for client what device Farm URL we are going to connect to
    // note: the pass-in value will be ignored and we will use HeadSpin URL if we detect
    // that the device is one of the HeadSPin supported device
    const deviceFarmUrl =
      isHeadspinDevice && !localExecution ? headspinServerURL : serverUrl;

    // we call wd.remote() to prefer "pure async" style of usage
    // see: https://github.com/admc/wd/blob/master/README.md#pure-async
    this._driver = wd.remote(deviceFarmUrl);
  }

  /**
   * invoke a wd.js driver function with a callback, and the callback will either resolve oir
   * reject based on the driver function execution result
   *
   * see https://github.com/admc/wd/blob/master/doc/api.md for function mapping between
   * the function that takes NO callback and its counterpart with a required callback
   *
   * @param {*} funcName name of the wd.js driver that you want to invoke
   * @param  {...any} args list of args that passed into the targeted wd.js driver function
   * @returns {*} it either resolves with the return value from the targeted function or reject with an error object
   * that contains an error description
   */
  doRequest = (funcName, ...args) =>
    new Promise((resolve, reject) => {
      // make sure it's a valid method
      if (!this._driver[funcName]) {
        reject(new Error(`not a supported action: ${funcName}`));
      }

      // perform the requested action
      this._driver[funcName](...args, (err, result) => {
        // logger.debug(`invoking function: ${funcName}`);
        if (err) {
          logger.error(`error found when invoking function ${funcName}!!`);
          logger.error(err);
          reject(err);
        } else {
          // logger.debug('request resolved!');
          // logger.debug(result);
          resolve(result);
        }
      });
    });

  openApp = async (desiredCapabilities) => {
    try {
      await this.doRequest('init', desiredCapabilities);
    } catch (ex) {
      this._hsSessionId = undefined;
      logger.error('Failed to establish an Appium connection! Please check!');
      throw new Error(ex);
    }

    this._appOpen = true;

    if (!this._localExecution) {
      if (isHeadspinDevice) {
        await this.hsSessionInfo();
      } else {
        await this.bsSessionInfo();
      }
    }
  };

  /**
   * Generates and stores HS Session ID and Session URL.
   */
  hsSessionInfo = async () => {
    this._hsSessionId = await this.doRequest('getSessionId');
    logger.debug(`HS session Id: ${this._hsSessionId}`);
    this._hsPublicUrl = `https://ui.headspin.io/sessions/${this._hsSessionId}/waterfall`;
  };

  bsSessionInfo = async () => {
    this._bsSessionId = await this.doRequest('getSessionId');
    logger.debug(`BS session Id: ${this._bsSessionId}`);
    const sessionDetails = await bsUtil.bsAppSessionDetails(this._bsSessionId);

    this._bsSessionInfo = sessionDetails.automation_session;
    this._bsBuildId = await this.#setSessionDetails(
      this._bsSessionInfo,
      'build_name',
    );
    this._bsPublicUrl = await this.#setSessionDetails(
      this._bsSessionInfo,
      'public_url',
    );
    this._bsTextLogsUrl = await this.#setSessionDetails(
      this._bsSessionInfo,
      'logs',
    );
    this._bsDeviceLogsUrl = await this.#setSessionDetails(
      this._bsSessionInfo,
      'device_logs_url',
    );
    this._bsAppiumLogsUrl = await this.#setSessionDetails(
      this._bsSessionInfo,
      'appium_logs_url',
    );
  };

  #setSessionDetails = (sessionDetails, key) => {
    if (sessionDetails[key]) {
      return sessionDetails[key];
    }
    return '';
  };

  getSelectorType = (selector) =>
    Object.getOwnPropertyNames(selector).toString();

  getSelectorValue = (selector) => {
    const type = Object.getOwnPropertyNames(selector).toString();
    const poSelector = selector[type].toString();

    return poSelector;
  };

  #elementFetcher = async (selector, time) => {
    if (selector instanceof Element) return selector;
    if (await this.elementExists(selector, time)) {
      const type = await this.getSelectorType(selector);
      const poSelector = await this.getSelectorValue(selector);
      const element = await this.doRequest('element', type, poSelector);

      if (element) {
        logger.debug(
          `element found with type:[${type}], selector:[${poSelector}]`,
        );
      }
      return element;
    }

    throw new Error(`Selector not found : ${JSON.stringify(selector)}`);
  };

  clickElement = async (element) => {
    await this.doRequest('clickElement', element);
  };

  click = async (selector, time) => {
    const element = await this.#elementFetcher(selector, time);

    await this.clickElement(element);
  };

  waitUntil = async (selector, time) => {
    if (await this.elementExists(selector, time)) return;
    throw new Error(
      `Selector not found in given time!!! ${JSON.stringify(selector)}`,
    );
  };

  /**
   * Try until desired selector is found.
   * Only for Android platforms!!
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} action direction to perform
   * @param {number} maxCount maximum number of times
   * @param {number} pauseSec time delay value in seconds
   */
  tryUntil = async (selector, action, maxCount, pauseSec) => {
    for (let i = 0; i < maxCount; i++) {
      if (await this.elementExists(selector, pauseSec)) {
        return;
      }
      await this.pressKeyCode(this.AKC[action.toUpperCase()]);
    }

    if (await this.elementExists(selector, pauseSec)) return;
    throw new Error(
      `Selector not found after performing ${action} ${maxCount} times!!! ${JSON.stringify(
        selector,
      )}`,
    );
  };

  /**
   * This method will Launch the app-under-test on the device
   */
  launchApp = async () => {
    await this.doRequest('launchApp');
  };

  /**
   * This method will close an app on device
   */
  closeCurrentApp = async () => {
    await this.doRequest('closeApp');
  };

  /**
   * Click on x, y coordinates. Paste text if required on text box.
   *
   * @param {number} xV x-axis value
   * @param {number} yV y-axis value
   * @param {string} text text to paste in textbox
   */
  clickCoordinates = async (xV, yV, text) => {
    await new wd.TouchAction(await this._driver)
      .tap({ x: xV, y: yV })
      .wait(200)
      .release()
      .perform();
    if (text !== '') {
      await this.doRequest('keys', text);
    }
  };

  getSettings = async () => {
    const settings = await this.doRequest('settings');

    return settings;
  };

  updateSettings = async (settings) => {
    // reference for Android (UiAutomator2):
    // https://github.com/appium/appium-uiautomator2-driver#settings-api
    await this.doRequest('updateSettings', settings);
  };

  elementExists = async (selector, time = 5) => {
    await this.doRequest('setImplicitWaitTimeout', time * 1000);
    const type = await this.getSelectorType(selector);
    const poSelector = await this.getSelectorValue(selector);

    const element = await this.doRequest('elements', type, poSelector);

    return Array.isArray(element) && element.length > 0;
  };

  sendText = async (selector, data, time) => {
    const element = await this.#elementFetcher(selector, time);

    await this.doRequest('type', element, data);
  };

  /**
   * Sets text to the active element, if the element accepts input.
   *
   * @param {string} data text to set on active element
   */
  setText = async (data) => {
    await this.doRequest('keys', data);
  };

  fetchAttributeData = async (selector, attribute, time) => {
    const element = await this.#elementFetcher(selector, time);

    const value = await this.doRequest('getAttribute', element, attribute);

    logger.debug(
      `selector: ${selector}, attribute:[${attribute}], value:[${value}]`,
    );
    return value;
  };

  closeApp = async () => {
    if (this._appOpen) {
      await this.doRequest('closeApp');
      await this.doRequest('quit');
      this._appOpen = false;
    }
  };

  /**
   * This method will minimize the app to background for a period of time mentioned
   * Once the waiting period is completed app will be reopened
   *
   * @param {number} time duration in seconds for which the app should be in background
   */
  backgroundApp = async (time) => {
    await this._driver.backgroundApp(time);
  };

  /**
   * Scroll on page from and to desired coordinates
   *
   * @param {number} startX x coordinate of start location
   * @param {number} startY y coordinate of start location
   * @param {number} endX x coordinate of end location
   * @param {number} endY x coordinate of end location
   */
  scrollByCoordinates = async (startX, startY, endX, endY) => {
    await new wd.TouchAction(await this._driver)
      .longPress({ x: startX, y: startY })
      .moveTo({ x: endX, y: endY })
      .release()
      .perform();
  };

  /**
   * Scroll on page in up or down direction
   *
   * @param {string} scrollDirection Value should be up or down
   */
  scrollOnPage = async (scrollDirection) => {
    const windowSize = await this.doRequest('getWindowSize');
    const startX = windowSize.width / 2;
    const endX = startX;
    const startY = windowSize.height / 2;
    const endY =
      scrollDirection.toLowerCase() === 'up'
        ? startY + windowSize.height / 4
        : startY - windowSize.height / 4;

    await this.scrollByCoordinates(startX, startY, endX, endY);
  };

  /**
   * Swipe left or right on screen by referencing a element location.
   * Selector to be passed for scrolling on rails should be
   * the container view in which thumbnail images are displayed
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} direction Value should be left or right
   * @param {number} time time delay value in seconds
   */
  swipeOnElement = async (selector, direction, time) => {
    const element = await this.#elementFetcher(selector, time);
    const elementStartLocation = await this.doRequest('getLocation', element);
    const elementSize = await this.doRequest('getSize', element);
    const startY = elementStartLocation.y + elementSize.height / 3;
    const startX = elementStartLocation.x + elementSize.width / 3;
    const endX =
      direction.toLowerCase() === 'right'
        ? startX + elementSize.width / 4
        : startX - elementSize.width / 4;

    await this.scrollByCoordinates(startX, startY, endX, startY);
  };

  /**
   * Click on device back button
   */
  clickBack = async () => {
    await this.doRequest('back');
  };

  /**
   * Dynamic scroll on page in up or down direction based on screen resolution percentage
   *
   * @param {string} scrollDirection Value can be up or down
   * @param {string} percentageValue Value can be 5%, 10%, 15%, 20%, 25%, 30%
   */
  scrollOnPageByPercentage = async (scrollDirection, percentageValue) => {
    const windowSize = await this.doRequest('getWindowSize');
    const startX = windowSize.width * 0.5;
    const startY = windowSize.height * 0.5;
    const scrollUpAndDownValue = {
      '5%': [windowSize.height * 0.45, windowSize.height * 0.55],
      '10%': [windowSize.height * 0.4, windowSize.height * 0.6],
      '15%': [windowSize.height * 0.35, windowSize.height * 0.65],
      '20%': [windowSize.height * 0.3, windowSize.height * 0.7],
      '25%': [windowSize.height * 0.25, windowSize.height * 0.75],
      '30%': [windowSize.height * 0.2, windowSize.height * 0.8],
      '35%': [windowSize.height * 0.15, windowSize.height * 0.85],
      '40%': [windowSize.height * 0.1, windowSize.height * 0.9],
      '50%': [windowSize.height * 0.05, windowSize.height * 0.95],
    };
    const [downEndY, upEndY] = scrollUpAndDownValue[percentageValue];

    if (scrollDirection.toLowerCase() === 'up') {
      await this.scrollByCoordinates(startX, startY, startX, upEndY);
    } else {
      await this.scrollByCoordinates(startX, startY, startX, downEndY);
    }
  };

  /**
   * Scroll up or down the page until a particular element is visible
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {*} direction Value can be up or down
   * @param {*} time time delay value in seconds, 5
   * @param {*} percentageVal is set to 30% by default, it can be overridden as per requirement
   */
  scrollToElement = async (
    selector,
    direction,
    time,
    percentageVal = '30%',
  ) => {
    for (let count = 0; count <= 15; count++) {
      if (await this.elementExists(selector, time)) break;
      await this.scrollOnPageByPercentage(direction, percentageVal);
    }
    const element = await this.#elementFetcher(selector, time);
    const elementStartLocation = await this.doRequest('getLocation', element);
    const windowSize = await this.doRequest('getWindowSize');

    if (elementStartLocation.y > windowSize.height * 0.5) {
      await this.scrollOnPageByPercentage('down', '20%');
    } else {
      await this.scrollOnPageByPercentage('up', '20%');
    }
  };

  /**
   * Get the list of elements on the DOM
   *
   * @param {*} selector Object which will locate multiple elements, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds
   */
  findElements = async (selector, time) => {
    await this.doRequest('setImplicitWaitTimeout', time * 1000);
    const type = await this.getSelectorType(selector);
    const poSelector = await this.getSelectorValue(selector);
    const elements = await this.doRequest('elements', type, poSelector);

    return elements;
  };

  /**
   *
   * @param {*} selector Object which will locate multiple elements, i.e.  { xpath: "//*[@id='Any']" }
   * @param {*} time time delay value in seconds
   * @returns {Array} array of element coordinates[startX, startY, endX, endY] to locate the exact location of element
   */
  getElementLocation = async (selector, time) => {
    const element = await this.#elementFetcher(selector, time);
    const elementStartLocation = await this.doRequest('getLocation', element);
    const elementSize = await this.doRequest('getSize', element);
    const elementLocations = {
      startXValue: elementStartLocation.x,
      startYValue: elementStartLocation.y,
      endXValue: elementStartLocation.x + elementSize.width,
      endYValue: elementStartLocation.y + elementSize.height,
    };

    return elementLocations;
  };

  /**
   *
   * @param {*} selector Object which will locate multiple elements, i.e.  { xpath: "//*[@id='Any']" }
   * @param {*} time time delay value in seconds
   * @returns {Array} array of element dimensions width & height
   */
  getElementSize = async (selector, time) => {
    const element = await this.#elementFetcher(selector, time);
    const elementSize = await this.doRequest('getSize', element);
    const elementDimensions = {
      width: elementSize.width,
      height: elementSize.height,
    };

    return elementDimensions;
  };

  /**
   * Click on device keyboard by passing keys values mentioned in https://android.googlesource.com/platform/frameworks/base/+/master/core/java/android/view/KeyEvent.java
   *
   * @param {*} keyValues Keyboard Value like { value '8' need to be passed to press key 1 }
   */
  pressKeyCode = async (keyValues) => {
    if (Array.isArray(keyValues)) {
      for (let i = 0; i < keyValues.length; i++) {
        await this.doRequest('pressKeycode', keyValues[i]);
      }
    } else {
      await this.doRequest('pressKeycode', keyValues);
    }
  };

  /**
   * Long press on device keyboard by passing keys values mentioned in https://android.googlesource.com/platform/frameworks/base/+/master/core/java/android/view/KeyEvent.java
   *
   * @param {*} keyValue Keyboard Value like AKC.<any> / { value '8' need to be passed to press key 1 }
   */
  longPressKeyCode = async (keyValue) => {
    await this.doRequest('longPressKeycode', keyValue);
  };

  /**
   * Hide the keyboard if it is shown.
   * Does not work for firetv because driver.isKeyboardShown() is always true
   * amd driver.hideKeyboard() throws an exception if its not shown.
   */
  hideKeyboard = async () => {
    if (await this.doRequest('isKeyboardShown')) {
      await this.doRequest('hideKeyboard');
    }
  };

  /**
   * Sends Number Keys to currently active element
   *
   * @param {*} keyValue Number Value [e.g: 1234]
   */
  sendPassKeys = async (keyValue) => {
    if (!Number(keyValue)) {
      throw new Error(`keyValue passed is not a Number!! '${keyValue}'`);
    }
    for (let i = 0; i < keyValue.toString().length; i++) {
      await this.doRequest('keys', Number(keyValue.toString()[i]));
    }
  };

  /**
   * It clears text of a text box type element
   *
   * @param {*} selector Object which will locate the element, i.e.  { xpath: "//*[@id='Any']" } or Element
   * @param {*} time time delay value in seconds
   */
  clearText = async (selector, time) => {
    const element = await this.#elementFetcher(selector, time);

    return this.doRequest('clear', element);
  };

  /**
   * Will check element is enabled
   *
   * @param {*} selector Object which will locate the element, i.e.  { xpath: "//*[@id='Any']" } or element locator
   * @param {*} time time delay value in seconds
   */
  isEnabled = async (selector, time) => {
    const element = await this.#elementFetcher(selector, time);

    return this.doRequest('isEnabled', element);
  };

  /**
   * Will check element is displayed
   *
   * @param {*} selector Object which will locate the element, i.e.  { xpath: "//*[@id='Any']" } or Element
   * @param {*} time time delay value in seconds
   */
  isDisplayed = async (selector, time) => {
    const element = await this.#elementFetcher(selector, time);

    return this.doRequest('isDisplayed', element);
  };

  /**
   * Performs user action /remote action on device, using appium execute command.
   *
   *  @param {string} actionType  up, down, left, right, menu, select
   */
  userAction = async (actionType) => {
    const actionTypeList = ['up', 'down', 'left', 'right', 'menu', 'select'];

    if (!actionTypeList.includes(actionType)) {
      throw new Error(
        `User Action type is incorrect. ${actionType}. Expected: ${actionTypeList}`,
      );
    }
    await this.doRequest('execute', 'mobile: pressButton', {
      name: `${actionType}`,
    });
  };

  /**
   * This method will launch safari browser on IOS devices
   */
  #launchSafariOnIos = async () => {
    await this.doRequest('execute', 'mobile: launchApp', {
      bundleId: 'com.apple.mobilesafari',
    });
  };

  /**
   * This method will get the current context in which Appium is running
   */
  currentContext = async () => {
    const context = await this.doRequest('currentContext');

    return context;
  };

  /**
   * This function scrolls down the page for given number of times
   *
   * @param {number} iterator [Optional] number of iterations you want to perform to scroll down through the screen. The default value is 1
   */
  scrollDownMax = async (iterator) => {
    let i = 1;
    const windowSize = await this.doRequest('getWindowSize');
    const startVerticalY = windowSize.height * 0.9;
    const endVerticalY = windowSize.height * 0.01;
    const startVerticalX = windowSize.width / 2.1;

    while (i <= iterator) {
      await this.scrollByCoordinates(
        startVerticalX,
        startVerticalY,
        startVerticalX,
        endVerticalY,
      );
      i++;
    }
  };

  /**
   * This function returns the window size
   *
   * @returns {*} The size of the window (width and height)
   */
  getWindowSize = async () => {
    const windowSize = await this.doRequest('getWindowSize');

    return windowSize;
  };

  #deepLinkIos = async (url) => {
    const safariUrlAddressbar = JSON.parse(
      JSON.stringify({
        xpath:
          "//XCUIElementTypeTextField[@label='Address' or @name='TabBarItemTitle']",
      }),
    );
    const openAppText = JSON.parse(
      JSON.stringify({
        xpath: "//XCUIElementTypeButton[@label='Open' or @name='Open']",
      }),
    );

    await this.#launchSafariOnIos();
    await this.click(safariUrlAddressbar);
    await this.setText(`${url}\uE007`);
    await this.click(openAppText, 30);
  };

  /**
   * This function opens the input deep link URL
   *
   * @param {*} url deeplink URL
   */
  deepLinkTo = async (url) => {
    if (device === 'android') {
      await this.doRequest('get', url);
      return;
    }
    if (device === 'ios') {
      await this.#deepLinkIos(url);
    }
  };

  /**
   * Frequently used android key codes.
   * For more key codes refer : https://android.googlesource.com/platform/frameworks/base/+/master/core/java/android/view/KeyEvent.java
   */
  AKC = remoteDefaults.AndroidKeyCodes;
}

module.exports = new AppiumMobile();
