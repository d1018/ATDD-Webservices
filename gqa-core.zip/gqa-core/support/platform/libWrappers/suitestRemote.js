const suitest = require('suitest-js-api');
const remoteDefaults = require('../RemoteDefaults');
const { runtimeDevice, runtimeDeviceModel } = require('../../runtimeConfig');

const { assert, VRC, PROP } = suitest;
const noClearAppSupportDevices = ['roku', 'nowtv'];

class SuitestRemote {
  // Virtual remote control default values.
  VRC = remoteDefaults.VirtualRemoteControl;

  // Element properties to check against
  PROP = remoteDefaults.Properties;

  // Element properties comparators
  COMP = remoteDefaults.Comparators;

  /**
   * Opens app using suitest.
   */
  openApp = async () => {
    if (await suitest.application().hasExited()) {
      await suitest.openApp();
    }
  };

  /**
   * Open session - Suitest.
   *
   * @param {*} tokenId Suitest token ID/key.
   * @param {*} tokenPassword Suitest token password
   */
  openAppSession = async (tokenId, tokenPassword) => {
    await suitest.openSession({ tokenId, tokenPassword });
  };

  /**
   * Set App config -Suitest.
   *
   * @param {*} appConfigId Suitest app config ID.
   */
  setAppConfig = async (appConfigId) => {
    await suitest.setAppConfig(appConfigId);
  };

  /**
   * Set log level - Suitest.
   *
   * @param {*} logLevel Suitest log level.
   */
  setLogLevel = async (logLevel) => {
    await suitest.setLogLevel(logLevel);
  };

  /**
   * Release Devices used by Suitest API.
   */
  releaseDevice = async () => {
    await suitest.releaseDevice();
  };

  getSuitest() {
    return suitest;
  }

  /**
   * Suitest API - take screenshot.
   *
   * @param {*} type image file type.
   * @returns {*} screenshot image
   */
  takeScreenshot = async (type) => {
    const result = await suitest.takeScreenshot(type);

    return result;
  };

  /**
   * Suitest API - save screenshot.
   *
   * @param {*} path file path.
   */
  saveScreenshot = async (path) => {
    await suitest.saveScreenshot(path);
  };

  /**
   * Wait or sleep.
   *
   * @param {number} pauseSec time delay value in seconds, 0.5.
   */
  wait = async (pauseSec = 0.5) => {
    await suitest.sleep(pauseSec * 1000);
  };

  /**
   * Perform actions on remote control buttons.
   *
   * @param {string} command button value "ENTER, UP, DOWN, LEFT, RIGHT, PLAY, BACK, ..."
   * @param {number} count number of times, 1.
   * @param {number} pauseSec time delay value in seconds, 0.5.
   */
  userAction = async (command, count = 1, pauseSec = 0.5) => {
    await suitest
      .press(command)
      .repeat(count)
      .interval(pauseSec * 1000);
  };

  /**
   * Try until desired selector exists.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} action button value "UP, DOWN, LEFT, RIGHT, BACK, ENTER, ..."
   * @param {number} maxcount maximum number of times, 5.
   * @param {number} pauseSec time delay value in seconds, 0.5.
   */
  tryUntil = async (selector, action, maxcount = 5, pauseSec = 0.5) => {
    for (let i = 1; i <= maxcount; i++) {
      const existValue = await suitest
        .element(selector)
        .exists()
        .timeout(pauseSec * 1000);

      if (existValue || i === maxcount) {
        await assert.element(selector).exists();
        break;
      }
      await this.userAction(action, 1);
    }
  };

  /**
   * Navigate until desired selector is found and click ENTER.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} action button value "UP, DOWN, LEFT, RIGHT,BACK, ..."
   * @param {number} maxcount maximum number of times, 5.
   * @param {number} pauseSec time delay value in seconds, 0.5.
   */
  navigateTo = async (selector, action, maxcount = 5, pauseSec = 0.5) => {
    await this.tryUntil(selector, action, maxcount, pauseSec);
    await this.userAction(this.VRC.ENTER, 1);
  };

  /**
   * Close app and clear suitest session.
   * Additionally clears app data for Samsung.
   */
  closeApp = async () => {
    if (!(await suitest.application().hasExited())) {
      if (!noClearAppSupportDevices.includes(runtimeDevice().toLowerCase()))
        await suitest.clearAppData();
      await suitest.closeApp();
    }
  };

  /**
   * clears app data for Samsung.
   */
  clearAppData = async () => {
    await suitest.clearAppData();
  };

  /**
   * Close suitest session.
   * Additionally clears app data for Samsung.
   */
  closeSession = async () => {
    await suitest.closeSession();
  };

  /**
   * Waits until selector is found.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   */
  waitUntil = async (selector, time = 2) => {
    await assert
      .element(selector)
      .exists()
      .timeout(time * 1000);
  };

  /**
   * Waits until selector is visible.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   */
  waitUntilVisible = async (selector, time = 2) => {
    await assert
      .element(selector)
      .visible()
      .timeout(time * 1000);
  };

  /**
   * Returns boolean value for selector exists.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   * @returns {boolean} true or false
   */
  elementExists = async (selector, time = 2) => {
    const result = await suitest
      .element(selector)
      .exists()
      .timeout(time * 1000);

    return result;
  };

  /**
   * Returns boolean value for selector visible.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   * @returns {boolean} true or false
   */
  elementVisible = async (selector, time = 2) => {
    const result = await suitest
      .element(selector)
      .visible()
      .timeout(time * 1000);

    return result;
  };

  /**
   * Returns boolean value for selector does not exist.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   * @returns {boolean} true or false
   */
  doesNotExist = async (selector, time = 2) => {
    const result = await suitest
      .element(selector)
      .doesNot()
      .exist()
      .timeout(time * 1000);

    return result;
  };

  /**
   * Sends text.
   *
   * @param {string} text value to type/send to text box.
   */
  sendText = async (text) => {
    await suitest.assert.window().sendText(text);
  };

  /**
   * Asserts if selector exists.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   */
  assertExists = async (selector, time = 2) => {
    await assert
      .element(selector)
      .exists()
      .timeout(time * 1000);
  };

  /**
   * Asserts if selector does not exists.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   */
  assertDoesNotExist = async (selector, time = 2) => {
    await assert
      .element(selector)
      .doesNot()
      .exist()
      .timeout(time * 1000);
  };

  /**
   * Asserts if selector is Visible.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   */
  assertVisible = async (selector, time = 2) => {
    await assert
      .element(selector)
      .visible()
      .timeout(time * 1000);
  };

  /**
   * Fetches attribute data for selector passed, based on attributeKey/PROP.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} propType i.e "text, image, ... / PROP.<any>"
   * @returns {any} The value present in the attribute
   */
  fetchAttributeData = async (selector, propType) => {
    if (
      !(await suitest
        .element(selector)
        .exists()
        .timeout(20 * 1000))
    ) {
      throw new Error(
        `Element: ${JSON.stringify(selector)} was not present after 20 seconds`,
      );
    }
    const jsonData = await suitest.element(selector);

    if (!(typeof jsonData === 'object')) {
      throw new Error(`This data is not populated correctly: ${jsonData}`);
    }
    const data = JSON.parse(JSON.stringify(jsonData, null, 2));

    if (typeof data[propType] === 'undefined') {
      throw new Error(`Attribute not available: ${propType}`);
    }
    return data[propType];
  };

  #removeExtrakeyboardChar = async () => {
    const model = runtimeDeviceModel().toLowerCase();

    switch (model) {
      case 'samsung17':
      case 'samsung18':
      case 'samsung19':
      case 'samsung20':
        await this.userAction(this.VRC.LEFT, 3);
        break;
      case 'samsung21':
        await this.userAction(this.VRC.UP, 1);
        await this.userAction(this.VRC.LEFT, 1);
        break;
      case 'xboxone':
        await this.userAction(this.VRC.UP, 1, 0.1);
        await this.userAction(this.VRC.RIGHT, 5, 0.1);
        break;
      case 'lg':
        await this.userAction(this.VRC.UP, 2);
        await this.userAction(this.VRC.RIGHT, 6);
        break;
      default:
        throw new Error(
          `#removeExtrakeyboardChar : Device model '${model}' is NOT handled`,
        );
    }
    await this.userAction(this.VRC.ENTER, 1);
    await this.userAction(this.VRC.BACK, 1);
  };

  /**
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} text value to type/send to text box.
   */
  setText = async (selector, text) => {
    await assert.element(selector).setText(text);
    await this.userAction(this.VRC.ENTER, 1);
    await this.#removeExtrakeyboardChar();
  };

  /**
   * Asserts if video is playing
   *
   * @param {number} time time delay value in seconds, 2.
   */
  assertVideoIsPlaying = async (time = 40) => {
    await assert
      .video()
      .isPlaying()
      .timeout(time * 1000);
  };

  /**
   * Check if video is playing
   *
   * @param {number} time time delay value in seconds, 2.
   */
  waitTillVideoIsPlaying = async (time = 40) => {
    await suitest
      .video()
      .isPlaying()
      .timeout(time * 1000);
  };

  /**
   * Returns boolean value for property value match based on comaprision type,.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {*} propType i.e "PROP.TEXT_CONTENT, PROP. , ..."
   * @param {any} matchValue value to match.
   * @param {*} compType i.e [Optional] COMP.EQUAL, ...
   * @returns {boolean} boolean value.
   */
  checkProperty = async (selector, propType, matchValue, compType) => {
    const result = await suitest
      .element(selector)
      .matches({ name: propType, val: matchValue, type: compType });

    return result;
  };

  /**
   * Asserts value for property value match based on comaprision type,.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {*} propType i.e "PROP.TEXT_CONTENT, PROP. , ..."
   * @param {any} matchValue value to match.
   * @param {*} compType i.e [Optional] COMP.EQUAL, ...
   */
  assertProperty = async (selector, propType, matchValue, compType) => {
    await assert
      .element(selector)
      .matches({ name: propType, val: matchValue, type: compType });
  };

  /**
   * Asserts if selector is not visible.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   */
  assertNotVisible = async (selector, time = 2) => {
    await assert
      .element(selector)
      .isNot()
      .visible()
      .timeout(time * 1000);
  };

  /**
   * Returns video details
   *
   * @returns {*} return list of video metadata
   */
  videoDetails = async () => {
    const result = await suitest.video();

    return result;
  };

  /**
   * Check if video is paused
   *
   * @returns {boolean} return true if video is paused else false
   */
  isVideoPaused = async () => {
    const result = await suitest.video().isPaused();

    return result;
  };

  /**
   * scrub the video to the starting of video
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" }
   */
  seekToStartOfVideo = async (locator) => {
    await this.userAction(VRC.REWIND, 4, 1);
    let value = '';

    while (value !== '00:00') {
      value = await this.fetchAttributeData(locator, PROP.TEXT_CONTENT);
    }
    await this.userAction(VRC.PLAY_PAUSE);
    if (await this.isVideoPaused()) {
      await this.userAction(VRC.PLAY_PAUSE);
    }
  };

  /**
   * scrub the video to a specific percentage of video length
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} percentage percentage to seek the video, 5
   */
  scrubVideo = async (locator, percentage = 5) => {
    await this.seekToStartOfVideo(locator);
    const video = await this.videoDetails();

    await this.userAction(VRC.FAST_FWD);
    const timeDelay = Math.round(
      (video.videoLength * percentage) / (1000 * 100 * 20),
    );

    await this.wait(timeDelay);
    await this.userAction(VRC.PLAY_PAUSE);
    await this.waitTillVideoIsPlaying();
  };

  /**
   * Asserts if array of selectors is visible.
   *
   * @param {...any} selectorArray accepts array of locators
   */
  assertVisibleSelectorArray = async (...selectorArray) => {
    const fails = [];
    const promises = selectorArray.map(async (element) => {
      try {
        await assert
          .element(element)
          .visible()
          .timeout(5 * 1000);
      } catch (error) {
        fails.push(error);
      }
    });

    await Promise.all(promises);
    if (fails.length > 0) {
      throw new Error(
        `assertVisibleSelectorArray: Selector(s) not visible/available - ${JSON.stringify(
          fails,
          null,
          2,
        )}`,
      );
    }
  };

  /**
   * Press and hold any given key for given time in seconds (limit 10 sec).
   *
   * @param {string} command button value "ENTER, OK, ..."
   * @param {number} time - time delay value in seconds, 1.
   */
  pressAndHold = async (command, time = 1) => {
    await suitest.press(command, { longPressMs: time * 1000 });
  };

  /**
   * Checks if application has exited, returns boolean value.
   *
   * @param {number} time - time delay value in seconds, 2.
   * @returns {boolean} application exited value.
   */
  isAppExited = async (time = 2) => {
    const result = await suitest
      .application()
      .hasExited()
      .timeout(time * 1000);

    return result;
  };

  timeoutWrapper = async (timeoutMs, throwOnTimeout, fn) => {
    const wait = async (ms) => {
      await new Promise((resolve) => setTimeout(() => resolve(), ms));
      return 'TIMEOUT';
    };

    const promises = [wait(timeoutMs), fn()];
    const result = await Promise.race(promises);

    if (result === 'TIMEOUT' && throwOnTimeout) {
      throw new Error(`Function did not complete within (${timeoutMs}ms).`);
    }

    return result;
  };

  waitByFunc = async (fn, timeoutMs = 20000) => {
    const interval = 250;

    let exception;
    let success = false;

    await this.timeoutWrapper(timeoutMs, false, async () => {
      while (!success) {
        try {
          exception = undefined;
          success = await fn();

          if (success !== false) {
            break;
          }
        } catch (err) {
          exception = err;
        }

        await new Promise((resolve) => setTimeout(resolve, interval));
      }
    });

    if (success === false) {
      throw new Error(
        `Unable to complete function within timeout (${timeoutMs}ms): ${
          typeof exception === 'object'
            ? JSON.stringify(exception, null, 2)
            : exception
        }`,
      );
    }
  };

  /**
   * Try until desired selector is visible.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} action button value "UP, DOWN, LEFT, RIGHT, BACK, ENTER, ..."
   * @param {number} maxcount maximum number of times, 5.
   * @param {number} pauseSec time delay value in seconds, 0.5.
   */
  tryUntilVisible = async (selector, action, maxcount = 5, pauseSec = 0.5) => {
    for (let i = 1; i <= maxcount; i++) {
      const existValue = await suitest
        .element(selector)
        .visible()
        .timeout(pauseSec * 1000);

      if (existValue || i === maxcount) {
        await assert.element(selector).visible();
        break;
      }
      await this.userAction(action, 1);
    }
  };
}

module.exports = new SuitestRemote();
