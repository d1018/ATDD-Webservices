const { Base } = require('./Base');

const wrapper = require('./libWrappers/webdriverBrowser');

class BrowserActions extends Base {
  baseURL(login, password, url) {
    wrapper.baseURL(login, password, url);
  }

  getDriverInstance() {
    return wrapper.getDriverInstance();
  }

  getDriver() {
    return wrapper.getDriver();
  }

  setMaximizeWindow = async () => {
    await wrapper.setMaximizeWindow();
  };

  /**
   * This method is used to get the size of the browser window
   */
  getWindowSize = async () => {
    const windowSize = await wrapper.getWindowSize();

    return windowSize;
  };

  closeApp = async () => {
    await wrapper.closeApp();
  };

  driverInit(serverUrl, localExecution) {
    wrapper.driverInit(serverUrl, localExecution);
  }

  openApp = async (desiredWebCapabilities) => {
    await wrapper.openApp(desiredWebCapabilities);
    this.deviceCaps = desiredWebCapabilities;
  };

  deepLinkTo = async (url) => {
    await wrapper.deepLinkTo(url);
  };

  switchTab = async (tabNumber) => {
    await wrapper.switchTab(tabNumber);
  };

  getAuthURL = async () => {
    await wrapper.getAuthURL();
  };

  /**
   * Gets the size and location of the given element
   *
   * @param {*} locator String CSS locator. Cannot be XPath. e.g. '.className'
   */
  getElementSizeAndLocation = async (locator) => {
    const result = await wrapper.getElementSizeAndLocation(locator);

    return result;
  };

  /**
   * To click on the web element
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  click = async (locator, time = 20) => {
    await wrapper.click(locator, time);
  };

  /**
   * This method is used find element on the page
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @returns {*} WebElement
   */
  findElement = async (locator) => {
    const element = await wrapper.findElement(locator);

    return element;
  };

  /**
   * This method is used find multiple elements on the page
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @returns {*} WebElements
   */
  findElements = async (locator) => {
    const elements = await wrapper.findElements(locator);

    return elements;
  };

  /**
   * This returns a boolean value based on whether element is displayed or not
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   * @returns {boolean}  Boolean value based on element visibility
   */
  isDisplayed = async (locator, time = 20) => {
    const result = await wrapper.isDisplayed(locator, time);

    return result;
  };

  /**
   * This returns a boolean value based on whether element is enabled or not
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   * @returns {boolean} Boolean value based on element enabled condition
   */
  isEnabled = async (locator, time = 20) => {
    const result = await wrapper.isEnabled(locator, time);

    return result;
  };

  /**
   * This method waits for element to be visible for the given time
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time time delay value in seconds, 30.
   */
  waitUntil = async (locator, time = 30) => {
    await wrapper.waitUntil(locator, time);
  };

  /**
   * This method is used to send text to and element
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {string} data text to be passed
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  sendText = async (locator, data, time = 20) => {
    await wrapper.sendText(locator, data, time);
  };

  /**
   * This method returns element text
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   * @returns {string} text value of the element
   */
  getText = async (locator, time = 20) => {
    const result = await wrapper.getText(locator, time);

    return result;
  };

  /**
   * This method returns text value of the element's attribute.
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {string} attributeName The name of the attribute to query.
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   * @returns {string} text value of the element's attribute.
   */
  getAttribute = async (locator, attributeName, time = 20) => {
    const result = await wrapper.getAttribute(locator, attributeName, time);

    return result;
  };

  /**
   * This method is used to perform arrow down function
   *
   * @param {number} count Number of times you want to perform arrow down operation . Default value is 1
   */
  arrowDown = async (count = 1) => {
    await wrapper.arrowDown(count);
  };

  /**
   * This method is used to perform arrow up function
   *
   * @param {number} count Number of times you want to perform arrow up operation . Default value is 1
   */
  arrowUp = async (count = 1) => {
    await wrapper.arrowUp(count);
  };

  /**
   * This method is used to perform page up function
   *
   * @param {number} count Number of times you want to perform page up operation . Default value is 1
   */
  pageUp = async (count = 1) => {
    await wrapper.pageUp(count);
  };

  /**
   * This method is used to perform page down function
   *
   * @param {number} count Number of times you want to perform page down operation . Default value is 1
   */
  pageDown = async (count = 1) => {
    await wrapper.pageDown(count);
  };

  /**
   * Scrolls to the top of the page.
   */
  scrollToPageTop = async () => {
    await wrapper.pageTop();
  };

  /**
   * This method is used to perform page down function
   */
  pageBottom = async () => {
    await wrapper.pageBottom();
  };

  /**
   * This method will hover over the element
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  hover = async (locator, time = 20) => {
    await wrapper.hover(locator, time);
  };

  /**
   * This method will click and hold the element
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  clickAndHold = async (locator, time = 20) => {
    await wrapper.clickAndHold(locator, time);
  };

  /**
   * This method will click and drag the element to the provided element or offset
   *
   * @param {*} fromLocator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {*} distanceDetails Object e.g. {
   *      toLocator: Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement. Will default to moving to an element if toLocator is provided. Otherwise, will use provided offset
   *      offset: An object with pixel coordinates, e.g. { x: 100, y: 20 }. Default is 100 pixels to the right
   * }
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  clickAndDrag = async (fromLocator, distanceDetails, time = 20) => {
    await wrapper.clickAndDrag(fromLocator, distanceDetails, time);
  };

  /**
   * This method will release the element
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  clickAndRelease = async (locator, time = 20) => {
    await wrapper.clickAndRelease(locator, time);
  };

  /**
   * This method is used to scroll to an element
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} maxTries maximum number of tries
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   * @returns {Error} Error if element is not found after maxTries
   */
  scrollToElement = async (locator, maxTries = 5, time = 20) => {
    await wrapper.scrollToElement(locator, maxTries, time);
  };

  /**
   * This method is used to assert whether an element is displayed or not
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {boolean} expectedValue true or false
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  assertDisplay = async (locator, expectedValue, time = 20) => {
    await wrapper.assertDisplay(locator, expectedValue, time);
  };

  /**
   * This method is used to assert whether an element is enabled or not
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {boolean} expectedValue true or false
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  assertEnable = async (locator, expectedValue, time = 20) => {
    await wrapper.assertEnable(locator, expectedValue, time);
  };

  getBsSessionInfo() {
    return wrapper.getBsSessionInfo();
  }

  getBsSessionId() {
    return wrapper.getBsSessionId();
  }

  getBsPublicUrl() {
    return wrapper.getBsPublicUrl();
  }

  getBsNetworkLogsUrl() {
    return wrapper.getBsNetworkLogsUrl();
  }

  getBsBrowserConsoleLogsUrl() {
    return wrapper.getBsBrowserConsoleLogsUrl();
  }

  getBsSeleniumLogsUrl() {
    return wrapper.getBsSeleniumLogsUrl();
  }

  /**
   * dump the page source of the current screen
   *
   * @returns {string} page source
   */
  getPageSource = () => wrapper.getPageSource();

  /**
   * This method is used to click on browser back button
   */
  clickBack = async () => {
    await wrapper.clickBack();
  };

  /**
   * This method is used to get the current URL
   *
   * @returns {string} current URL
   */
  getCurrentUrl = async () => {
    const result = await wrapper.getCurrentUrl();

    return result;
  };

  /**
   * This method is used to refresh the browser
   */
  refreshPage = async () => {
    await wrapper.refreshPage();
  };

  /**
   * This method is used to scroll upto an element till the element is visible
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   */
  scrollIntoView = async (locator) => {
    await wrapper.scrollIntoView(locator);
  };

  /**
   * This method is used to switch to an iframe
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   */
  switchToIframe = async (locator, time = 20) => {
    await wrapper.switchToIframe(locator, time);
  };

  /**
   * This method is used to switch back to default content or parent frame
   */
  switchToDefaultContent = async () => {
    await wrapper.switchToDefaultContent();
  };

  /**
   * This method is used to get shadow root of the input locator
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   * @returns {*} Shadow root of the input locator
   */
  getShadowRoot = async (locator, time = 20) => {
    const shadowRootElement = await wrapper.getShadowRoot(locator, time);

    return shadowRootElement;
  };

  /**
   * This method is used to get shadow element from the input shadow root
   *
   * @param {*} shadowRoot Shadow root element
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" } or WebElement
   * @param {number} time Delay value in seconds . Default value is 20 seconds
   * @returns {*} WebElement
   */
  getShadowElement = async (shadowRoot, locator, time = 20) => {
    const element = await wrapper.getShadowElement(shadowRoot, locator, time);

    return element;
  };
}

module.exports = new BrowserActions();
