require('../../tasks/utils');
const { Base } = require('./Base');
const remoteDefaults = require('./RemoteDefaults');

const wrapper = require('./libWrappers/suitestRemote');

class RemoteActions extends Base {
  // Virtual remote control default values.
  VRC = remoteDefaults.VirtualRemoteControl;

  // Element properties to check against
  PROP = remoteDefaults.Properties;

  // Element properties comparators
  COMP = remoteDefaults.Comparators;

  /**
   * Opens app using suitest.
   */
  openApp = async () => {
    await wrapper.openApp();

    // reset this to undefined coz the deviceCap concept doesn't apply to RemoteActions class
    this.deviceCaps = undefined;
  };

  /**
   * Open session - Suitest.
   *
   * @param {*} tokenID Suitest token ID/key.
   * @param {*} tokenPassword Suitest token password
   */
  openAppSession = async (tokenID, tokenPassword) => {
    await wrapper.openAppSession(tokenID, tokenPassword);
  };

  /**
   * Set App config -Suitest.
   *
   * @param {*} appConfigId Suitest app config ID.
   */
  setAppConfig = async (appConfigId) => {
    await wrapper.setAppConfig(appConfigId);
  };

  /**
   * Set log level - Suitest.
   *
   * @param {*} logLevel Suitest log level.
   */
  setLogLevel = async (logLevel) => {
    await wrapper.setLogLevel(logLevel);
  };

  getSuitest() {
    return wrapper.getSuitest();
  }

  /**
   * Close session for suitest.
   */
  closeSession = async () => {
    await wrapper.closeSession();
  };

  /**
   * Return log type.
   */
  eventHandler = async () => {
    await wrapper.eventHandler();
  };

  /**
   * Release the Deices after the execution.
   */
  releaseDevice = async () => {
    await wrapper.releaseDevice();
  };

  /**
   * Suitest API - take screenshot.
   *
   * @param {*} type image file type.
   * @returns {*} screenshot image
   */
  takeScreenshot = async (type) => {
    const result = await wrapper.takeScreenshot(type);

    return result;
  };

  /**
   * Suitest API - save screenshot.
   *
   * @param {*} path file path.
   */
  saveScreenshot = async (path) => {
    await wrapper.saveScreenshot(path);
  };

  /**
   * Wait or sleep. Available for rare and vital usage alone.
   *
   * @param {number} pauseSec time delay value in seconds, 0.5.
   */
  wait = async (pauseSec = 0.5) => {
    await wrapper.wait(pauseSec);
  };

  /**
   * Perform actions on remote control buttons.
   *
   * @param {string} command button value "ENTER, UP, DOWN, LEFT, RIGHT, PLAY, BACK, ..."
   * @param {number} count number of times, 1.
   * @param {number} pauseSec time delay value in seconds, 0.5.
   */
  userAction = async (command, count = 1, pauseSec = 0.5) => {
    await wrapper.userAction(command, count, pauseSec);
  };

  /**
   * Try until desired selector exists.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} action button value "UP, DOWN, LEFT, RIGHT, BACK, ENTER, ..."
   * @param {number} maxcount maximum number of times, 5.
   * @param {number} pauseSec time delay value in seconds, 0.5.
   */
  tryUntil = async (selector, action, maxcount = 5, pauseSec = 0.5) => {
    await wrapper.tryUntil(selector, action, maxcount, pauseSec);
  };

  /**
   * Navigate until desired selector is found and click ENTER.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} action button value "UP, DOWN, LEFT, RIGHT,BACK, ..."
   * @param {number} maxcount maximum number of times, 5.
   * @param {number} pauseSec time delay value in seconds, 0.5.
   */
  navigateTo = async (selector, action, maxcount = 5, pauseSec = 0.5) => {
    await wrapper.navigateTo(selector, action, maxcount, pauseSec);
  };

  /**
   * Close app and clear suitest session.
   * Additionally clears app data for Samsung.
   */
  closeApp = async () => {
    await wrapper.closeApp();
  };

  /**
   * Waits until selector is found.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   */
  waitUntil = async (selector, time = 2) => {
    await wrapper.waitUntil(selector, time);
  };

  /**
   * Waits until selector is visible.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   */
  waitUntilVisible = async (selector, time = 2) => {
    await wrapper.waitUntilVisible(selector, time);
  };

  /**
   * Returns boolean value for selector exists.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   * @returns {boolean} true or false
   */
  elementExists = async (selector, time = 2) => {
    const result = await wrapper.elementExists(selector, time);

    return result;
  };

  /**
   * Returns boolean value for selector visible.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   * @returns {boolean} true or false
   */
  elementVisible = async (selector, time = 2) => {
    const result = await wrapper.elementVisible(selector, time);

    return result;
  };

  /**
   * Returns boolean value for selector does not exist.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   * @returns {boolean} true or false
   */
  doesNotExist = async (selector, time = 2) => {
    const result = await wrapper.doesNotExist(selector, time);

    return result;
  };

  /**
   * Sends text.
   *
   * @param {string} text value to type/send to text box.
   */
  sendText = async (text) => {
    await wrapper.sendText(text);
  };

  /**
   * Asserts if selector exists.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   */
  assertExists = async (selector, time = 2) => {
    await wrapper.assertExists(selector, time);
  };

  /**
   * Asserts if selector doesnot exists.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   */
  assertDoesNotExist = async (selector, time = 2) => {
    await wrapper.assertDoesNotExist(selector, time);
  };

  /**
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   */
  assertVisible = async (selector, time = 2) => {
    await wrapper.assertVisible(selector, time);
  };

  /**
   * Fetches attribute data for selector passed, based on attributeKey/PROP.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} propType i.e "PROP.TEXT_CONTENT, PROP. , ..."
   * @returns {any} The value present in the attribute
   */
  fetchAttributeData = async (selector, propType) => {
    const result = await wrapper.fetchAttributeData(selector, propType);

    return result;
  };

  /**
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} text value to type/send to text box.
   */
  setText = async (selector, text) => {
    await wrapper.setText(selector, text);
  };

  /**
   * Asserts if video is playing
   *
   * @param {number} time time delay value in seconds, 2.
   */
  assertVideoIsPlaying = async (time = 40) => {
    await wrapper.assertVideoIsPlaying(time);
  };

  /**
   * Return boolean value for video is playing
   *
   * @param {number} time time delay value in seconds, 2.
   */
  waitTillVideoIsPlaying = async (time = 40) => {
    await wrapper.waitTillVideoIsPlaying(time);
  };

  /**
   * Returns boolean value for property value match based on comaprision type,.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {*} propType i.e "PROP.TEXT_CONTENT, PROP. , ..."
   * @param {any} matchValue value to match.
   * @param {*} compType i.e [Optional] COMP.EQUAL, ...
   * @returns {boolean} boolean value.
   */
  checkProperty = async (selector, propType, matchValue, compType = '=') => {
    const result = await wrapper.checkProperty(
      selector,
      propType,
      matchValue,
      compType,
    );

    return result;
  };

  /**
   * Asserts value for property value match based on comaprision type,.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {*} propType i.e "PROP.TEXT_CONTENT, PROP. , ..."
   * @param {any} matchValue value to match.
   * @param {*} compType i.e [Optional] COMP.EQUAL, ...
   */
  assertProperty = async (selector, propType, matchValue, compType = '=') => {
    await wrapper.assertProperty(selector, propType, matchValue, compType);
  };

  /**
   * Asserts if selector is not visible
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds, 2.
   */
  assertNotVisible = async (selector, time = 2) => {
    await wrapper.assertNotVisible(selector, time);
  };

  /**
   * clears app data for Samsung.
   */
  clearAppData = async () => {
    await wrapper.clearAppData();
  };

  /**
   * Returns video details
   *
   * @returns {*} return list of video metadata
   */
  videoDetails = async () => {
    const result = await wrapper.videoDetails();

    return result;
  };

  /**
   * Check if video is paused
   *
   * @returns {boolean} return true if video is paused else false
   */
  isVideoPaused = async () => {
    const result = await wrapper.isVideoPaused();

    return result;
  };

  /**
   * Scrub the video to the starting of video
   */
  seekToStartOfVideo = async () => {
    await wrapper.seekToStartOfVideo();
  };

  /**
   * scrub the video to a specific percentage of video length
   *
   * @param {*} locator Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} percentage percentage to seek the video, 5
   */
  scrubVideo = async (locator, percentage = 5) => {
    await wrapper.scrubVideo(locator, percentage);
  };

  /**
   * Asserts if array of selectors is visible.
   *
   * @param {...any} selectorArray accepts array of locator
   */
  assertVisibleSelectorArray = async (...selectorArray) => {
    await wrapper.assertVisibleSelectorArray(...selectorArray);
  };

  /**
   * Press and hold any given key for given time in seconds (limit 10 sec).
   *
   * @param {string} command button value "ENTER, OK, ..."
   * @param {number} time - time delay value in seconds, 1.
   */
  pressAndHold = async (command, time = 1) => {
    await wrapper.pressAndHold(command, time);
  };

  /**
   * Checks if application has exited, returns boolean value.
   *
   * @param {number} time - time delay value in seconds, 2.
   * @returns {boolean} application exited value.
   */
  isAppExited = async (time = 2) => {
    const result = await wrapper.isAppExited(time);

    return result;
  };

  /**
   * Repeatedley runs the function until it doesn't 'throw' or return false (throws on fail).
   *
   * @param {Function} fn the function to be executed.
   * @param {number} timeoutMs the maximum time to try and complete the function.
   */
  waitByFunc = async (fn, timeoutMs = 20000) => {
    const result = await wrapper.waitByFunc(fn, timeoutMs);

    return result;
  };

  /**
   * Try until desired selector is visible.
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} action button value "UP, DOWN, LEFT, RIGHT, BACK, ENTER, ..."
   * @param {number} maxcount maximum number of times, 5.
   * @param {number} pauseSec time delay value in seconds, 0.5.
   */
  tryUntilVisible = async (selector, action, maxcount = 5, pauseSec = 0.5) => {
    await wrapper.tryUntilVisible(selector, action, maxcount, pauseSec);
  };
}

module.exports = new RemoteActions();
