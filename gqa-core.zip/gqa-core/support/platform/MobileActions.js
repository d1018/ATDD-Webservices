const { Base } = require('./Base');

const wrapper = require('./libWrappers/appiumMobile');
const remoteDefaults = require('./RemoteDefaults');

class MobileActions extends Base {
  get driver() {
    return wrapper.driver();
  }

  driverInit(serverUrl, localExecution) {
    wrapper.driverInit(serverUrl, localExecution);
  }

  openApp = async (capabilities) => {
    await wrapper.openApp(capabilities);
    this.deviceCaps = capabilities;
  };

  /**
   * dump the page source of the current screen
   *
   * @returns {string} page source
   */
  getPageSource = () => wrapper.getPageSource();

  getSelectorType = async (selector) => {
    const result = await wrapper.getSelectorType(selector);

    return result;
  };

  getSelectorValue = async (selector) => {
    const result = await wrapper.getSelectorValue(selector);

    return result;
  };

  clickElement = async (element) => {
    await wrapper.clickElement(element);
  };

  click = async (selector, time = 50) => {
    await wrapper.click(selector, time);
  };

  /**
   * This method will Launch the app-under-test on the device
   */
  launchApp = async () => {
    await wrapper.launchApp();
  };

  /**
   * This method will close an app on device
   */
  closeCurrentApp = async () => {
    await wrapper.closeCurrentApp();
  };

  waitUntil = async (selector, time = 50) => {
    await wrapper.waitUntil(selector, time);
  };

  /**
   * Try until desired selector is found.
   * Only for Android platforms!!
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} action direction to perform
   * @param {number} maxcount maximum number of times, 5.
   * @param {number} pauseSec time delay value in seconds, 0.5.
   */
  tryUntil = async (selector, action, maxcount = 5, pauseSec = 0.5) => {
    await wrapper.tryUntil(selector, action, maxcount, pauseSec);
  };

  /**
   * Click on x, y  coordinates. Paste text if required on text box.
   *
   * @param {number} xAxisValue x-axis value
   * @param {number} yAxisValue y-axis value
   * @param {string} text [Optional] text to paste in textbox
   */
  clickCoordinates = async (xAxisValue, yAxisValue, text = '') => {
    await wrapper.clickCoordinates(xAxisValue, yAxisValue, text);
  };

  elementExists = async (selector, time = 15) => {
    const result = await wrapper.elementExists(selector, time);

    return result;
  };

  getSettings = async () => {
    const settings = await wrapper.getSettings();

    return settings;
  };

  updateSettings = async (settings) => {
    await wrapper.updateSettings(settings);
  };

  sendText = async (selector, data, time = 50) => {
    await wrapper.sendText(selector, data, time);
  };

  /**
   * Sets text to the active element, if the element accepts input.
   *
   * @param {string} data text to set on active element
   */
  setText = async (data) => {
    await wrapper.setText(data);
  };

  fetchAttributeData = async (selector, attribute, time = 50) => {
    const result = await wrapper.fetchAttributeData(selector, attribute, time);

    return result;
  };

  closeApp = async () => {
    await wrapper.closeApp();
  };

  /**
   * This method will get the current context in which Appium is running
   */
  currentContext = async () => {
    const context = await wrapper.currentContext();

    return context;
  };

  /**
   * This method will minimize the app to background for a period of time mentioned
   * Once the waiting period is completed app will be reopened
   *
   * @param {number} time duration in seconds for which the app should be in background, 10
   */
  backgroundApp = async (time = 10) => {
    await wrapper.backgroundApp(time);
  };

  getBsSessionInfo() {
    return wrapper.getBsSessionInfo();
  }

  getBsSessionId() {
    return wrapper.getBsSessionId();
  }

  getBsBuildId() {
    return wrapper.getBsBuildId();
  }

  getBsPublicUrl() {
    return wrapper.getBsPublicUrl();
  }

  getBsTextLogsUrl() {
    return wrapper.getBsTextLogsUrl();
  }

  getBsDeviceLogsUrl() {
    return wrapper.getBsDeviceLogsUrl();
  }

  getBsAppiumLogsUrl() {
    return wrapper.getBsAppiumLogsUrl();
  }

  /**
   * Gets Head spin session ID.
   *
   * @returns {string} Head Spin Session ID
   */
  getHsSessionId = () => wrapper.getHsSessionId();

  /**
   * Gets Head Spin URL for current session.
   *
   * @returns {string} Head Spin Session URL
   */
  getHsSessionUrl = () => wrapper.getHsSessionUrl();

  /**
   * Scroll on page from and to desired coordinates
   *
   * @param {number} startXAxisValue x coordinate of start location
   * @param {number} startYAxisValue y coordinate of start location
   * @param {number} endXAxisValue x coordinate of end location
   * @param {number} endYAxisValue x coordinate of end location
   */
  scrollByCoordinates = async (
    startXAxisValue,
    startYAxisValue,
    endXAxisValue,
    endYAxisValue,
  ) => {
    await wrapper.scrollByCoordinates(
      startXAxisValue,
      startYAxisValue,
      endXAxisValue,
      endYAxisValue,
    );
  };

  /**
   * Scroll on page in up or down direction
   *
   * @param {string} scrollDirection Value should be up or down
   */
  scrollOnPage = async (scrollDirection) => {
    await wrapper.scrollOnPage(scrollDirection);
  };

  /**
   * Swipe left or right on screen by referencing a element location.
   * Selector to be passed for scrolling on rails should be
   * the container view in which thumbnail images are displayed
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {string} direction Value should be left or right
   * @param {number} time time delay value in seconds, 5
   */
  swipeOnElement = async (selector, direction, time = 5) => {
    await wrapper.swipeOnElement(selector, direction, time);
  };

  /**
   * Dynamic scroll on page in up or down direction based on screen resolution percentage
   *
   * @param {string} scrollDirection Value can be up or down
   * @param {string} percentageValue Value can be 5%, 10%, 15%, 20%, 25%, 30%
   */
  scrollOnPageByPercentage = async (scrollDirection, percentageValue) => {
    await wrapper.scrollOnPageByPercentage(scrollDirection, percentageValue);
  };

  /**
   * Scroll up or down the page until a particular element is visible
   *
   * @param {*} selector Object, i.e.  { xpath: "//*[@id='Any']" }
   * @param {*} direction Value can be up or down
   * @param {*} time time delay value in seconds, 5
   * @param {*} percentageVal is set to 30% by default, it can be overridden as per requirement
   */
  scrollToElement = async (
    selector,
    direction,
    time = 5,
    percentageVal = '30%',
  ) => {
    await wrapper.scrollToElement(selector, direction, time, percentageVal);
  };

  /**
   * Click on device back button
   */
  clickBack = async () => {
    await wrapper.clickBack();
  };

  /**
   * Get the list of elements on the DOM
   *
   * @param {*} selector Object which will locate multiple elements, i.e.  { xpath: "//*[@id='Any']" }
   * @param {number} time time delay value in seconds
   */
  findElements = async (selector, time = 5) => {
    const result = await wrapper.findElements(selector, time);

    return result;
  };

  /**
   * Click on device keyboard by passing keys values mentioned in https://android.googlesource.com/platform/frameworks/base/+/master/core/java/android/view/KeyEvent.java
   *
   * @param {*} keyValues Keyboard Value like { value '8' need to be passed to press key 1 }
   */
  pressKeyCode = async (keyValues) => {
    await wrapper.pressKeyCode(keyValues);
  };

  /**
   * Long press on device keyboard by passing keys values mentioned in https://android.googlesource.com/platform/frameworks/base/+/master/core/java/android/view/KeyEvent.java
   *
   * @param {*} keyValue Keyboard Value like AKC.<any> / { value '8' need to be passed to press key 1 }
   */
  longPressKeyCode = async (keyValue) => {
    await wrapper.longPressKeyCode(keyValue);
  };

  /**
   * Hide the keyboard if it is shown
   * Does not work for firetv
   */
  hideKeyboard = async () => {
    await wrapper.hideKeyboard();
  };

  /**
   * Sends Number Keys to currently active element
   *
   * @param {*} keyValue Number Value [e.g: 1234]
   */
  sendPassKeys = async (keyValue) => {
    await wrapper.sendPassKeys(keyValue);
  };

  /**
   *
   * @param {*} selector Object which will locate multiple elements, i.e.  { xpath: "//*[@id='Any']" } or element
   * @param {*} time time delay value in seconds
   * @returns {Array} array of element coordinates[startY, startY, endX,endY]
   */
  getElementLocation = async (selector, time = 5) => {
    const result = await wrapper.getElementLocation(selector, time);

    return result;
  };

  getElementSize = async (selector, time = 5) => {
    const elementSize = await wrapper.getElementSize(selector, time);

    return elementSize;
  };

  /**
   * Will check element is enabled
   *
   * @param {*} selector Object which will locate the element, i.e.  { xpath: "//*[@id='Any']" } or element locator
   * @param {*} time time delay value in seconds
   */
  isEnabled = async (selector, time = 5) => {
    const result = await wrapper.isEnabled(selector, time);

    return result;
  };

  /**
   * It clears text of a text box type element
   *
   * @param {*} selector Object which will locate the element, i.e.  { xpath: "//*[@id='Any']" } or Element
   * @param {*} time time delay value in seconds
   */
  clearText = async (selector, time) => {
    await wrapper.clearText(selector, time);
  };

  /**
   * Will check element is displayed
   *
   * @param {*} selector Object which will locate the element, i.e.  { xpath: "//*[@id='Any']" } or element locator
   * @param {*} time time delay value in seconds
   */
  isDisplayed = async (selector, time = 5) => {
    const result = await wrapper.isDisplayed(selector, time);

    return result;
  };

  /**
   * Performs user action /remote action on device, using appium execute command.
   *
   *  @param {string} actionType  up, down, left, right, menu, select
   */
  userAction = async (actionType) => {
    await wrapper.userAction(actionType);
  };

  /**
   * This function scrolls down the page for given number of times
   *
   * @param {number} iterator [Optional] number of iterations you want to perform to scroll down through the screen. The default value is 1
   */

  scrollDownMax = async (iterator = 1) => {
    await wrapper.scrollDownMax(iterator);
  };

  /**
   * This function returns the window size
   *
   * @returns {*} The size of the window (width and height)
   */
  getwindowSize = async () => {
    const windowSize = await wrapper.getWindowSize();

    return windowSize;
  };

  /**
   * This function opens the input URL
   *
   * @param {*} url deeplink URL
   */
  deepLinkTo = async (url) => {
    await wrapper.deepLinkTo(url);
  };

  /**
   * Frequently used android key codes.
   * For more key codes refer : https://android.googlesource.com/platform/frameworks/base/+/master/core/java/android/view/KeyEvent.java
   */
  AKC = remoteDefaults.AndroidKeyCodes;
}

module.exports = new MobileActions();
