// Copyright text placeholder, Warner Bros. Discovery, Inc.

/* eslint-disable require-await, no-unused-vars */

import { logger } from '../logger';

const {
  runtimeDeviceModel,
  runtimeDevice,
  runtimeDeviceName,
} = require('../runtimeConfig');

export interface IDeviceCaps extends Record<string, string> {}

export class Base {
  protected deviceCaps: IDeviceCaps | undefined;

  /**
   * intentionally throw error for invalid operation
   * note:
   * this method is intended to let derived class throw error in method
   * that should NOT be called during runtime.
   * possible reasons:
   * 1. the method is a base class method that should NOT be called directly, or,
   * 2. the method hasn't yet to be implemented for the particular target method
   */
  protected invalidOp<T = void>(
    msg: string = 'derived class should override this method',
  ): T {
    logger.error('invalid operation detected! Please check!');
    throw new Error(msg);
  }

  private _maskInfo(input: string, secrets: (string | undefined)[]): string {
    let result = input;

    // eslint-disable-next-line no-restricted-syntax
    for (const secret of secrets) {
      if (secret) {
        result = result.replaceAll(secret, 'XXXX');
      }
    }

    return result;
  }

  /**
   * return a summary of the test device info
   *
   * note:
   * This base class method is simply print out the entire device caps plus info that we can
   * get from process.env to echo how the test device is acquired.
   *
   * Derived class should override this method so that it can print info only specific
   * to the type of device under tests, rather than dumping the entire device cap, which contains
   * excessive info.
   *
   * @returns a string that contain the device info summary
   */
  public deviceInfoSummary(): string {
    const caps = {
      device: runtimeDevice(),
      deviceName: runtimeDeviceName(),
      deviceModel: runtimeDeviceModel(),
    };

    const dump = JSON.stringify(
      {
        ...caps,
        ...this.deviceCaps,
      },
      undefined,
      2,
    );

    // we want to mask HeadSpin credentials from the device caps string
    return this._maskInfo(dump, [process.env.BS_USER, process.env.BS_KEY]);
  }

  /**
   * dump the page source of the current screen
   *
   * @returns page source
   */
  public async getPageSource(): Promise<string> {
    return this.invalidOp<string>();
  }

  /**
   * get settings object for the current test session
   *
   * @returns object containing information for the current session
   */
  public async getSettings(): Promise<unknown> {
    return this.invalidOp();
  }

  /**
   * set settings for the current test session
   *
   */
  public async updateSettings(settings: unknown): Promise<void> {
    this.invalidOp();
  }
}
