const { inspect } = require('util');
const { pairDevice } = require('suitest-js-api');
const retry = require('async-retry');
const headspin = require('./headspin');
const { timeoutWrapper } = require('./utilities');
const { getStaticDevice } = require('./suitest');
const { lookForAvailableDevice } = require('./remoteDeviceUtilities');
const { logger } = require('./logger');

const randomWait = async (ms) => {
  await new Promise((res) => setTimeout(res, ms * Math.random()));
};

const getReadyDevice = async (availableDevices) => {
  if (availableDevices.length === 0) {
    throw new Error('There are no available devices.');
  }

  const selectedDevice = await lookForAvailableDevice(availableDevices);

  if (selectedDevice) {
    return selectedDevice;
  }

  throw new Error('None of the available devices are ready in suitest.');
};

const buildDeviceDetails = (device) => ({
  device,
});

const connectDevice = () => {
  const deviceDetails = buildDeviceDetails;

  try {
    return retry(
      async () => {
        // Locally allow the option to just use the device in suitestrc.
        const availableDevices = headspin.isHeadspinSuitestMode()
          ? await headspin.getAvailableDevices()
          : [getStaticDevice()];

        const readyDevice = await getReadyDevice(availableDevices);

        if (headspin.isHeadspinSuitestMode() && process.env.PARALLEL) {
          await randomWait(30 * 1000);
        }
        logger.log('Pairing ...', deviceDetails(readyDevice));

        /*
         I've noticed when this takes more than a few seconds, it never happens. So
         I'm limiting the time it'll try for.
         */
        await timeoutWrapper(300 * 1000, true, () =>
          pairDevice(readyDevice.suitestDeviceId),
        );

        logger.log('Succcessfully paired:', deviceDetails(readyDevice));

        if (headspin.isHeadspinSuitestMode()) {
          await headspin.lockDevice(readyDevice.suitestDeviceId);
        }
        return readyDevice;
      },
      { retries: 3 },
    );
  } catch (e) {
    const error = `Device connect: ${JSON.stringify(e, null, 2)}`;

    logger.error(error);
    logger.error(inspect(e));
    throw new Error(error);
  }
};

module.exports = { connectDevice };
