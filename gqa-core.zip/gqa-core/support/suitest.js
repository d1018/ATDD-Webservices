require('./stringOverrides');
const fetch = require('node-fetch');
const { execSync } = require('child_process');
const { suitestAvailableStatuses } = require('./hs_config.json');
const { logger } = require('./logger');

const API = 'https://the.suite.st/api/public/v4';

const tokenAuth = {
  'X-TokenId': process.env.SUITEST_TOKEN_KEY,
  'X-TokenPassword': process.env.SUITEST_TOKEN_PASSWORD,
};

/**
 * Fetches the Suitest API using a supplied endpoint
 *
 * @param {string} endpoint API endpoint to fetch the api based on
 * @returns {Promise<*>} Promise of API response formatted in JSON
 */
const fetchAPI = async (endpoint) => {
  const response = await fetch(`${API}/${endpoint}`, {
    method: 'GET',
    headers: tokenAuth,
  });

  return response.json();
};

/**
 * Upload build to Suitest
 *
 * @param {string} app Application buffer
 * @param {string} appId Application id, usually found in app settings
 * @param {string} versionId Application version id, found in the URL of the selected test pack page within Suitest ../version/<versionId>/test-packs/....
 * @param {string} configId Configuration id, usually found under app settings
 * @param {"auto" | "manual"} [instrument="auto"] Package instrumentation. Default value is auto but it can be set to manual.
 */
const upload = (app, appId, versionId, configId, instrument = 'auto') => {
  const appName = app.split('/').pop();
  const command = `curl -X PUT "https://the.suite.st/api/public/v3/apps/${appId}/versions/${versionId}/configs/${configId}/package" -H "accept: application/json" -H "x-suitest-instrument: ${instrument}" -H "x-suitest-html-package: false" -H "x-suitest-filename: ${appName}" -H "X-TokenId: ${tokenAuth['X-TokenId']}" -H "X-TokenPassword: ${tokenAuth['X-TokenPassword']}" --upload-file ${app} --show-error --http1.1`;

  execSync(command, { stdio: 'inherit', encoding: 'utf-8' });
};

/**
 * Fetches device details from suitest.
 *
 * @param {string} deviceId The suitest device id.
 * @returns {object|undefined} All Suitest details about the device.
 */
const fetchSuitestDeviceDetails = async (deviceId) => {
  /*
   The api allows you to specify an indexId (device id) to use as a starting point for a page of
   results ... BUT ... it's *from* that ID (i.e. all devices after that one).

   So the only way to fnd your device currently is to keep fetching until it turns up.
   */
  const start = new Date();
  let endpoint = 'devices?limit=100';
  let next;
  let page = 1;

  // Iterate through pages until next is null or we find the device.
  try {
    do {
      const response = await fetchAPI(endpoint);
      const { values } = response;

      next = response.next;
      // Search for device
      const device = values.find((value) => value.deviceId === deviceId);

      if (device) {
        const end = new Date();
        const totalTime = Math.round(end - start) / 100;
        const secondsTime = totalTime.toFixed(2);

        const info = `Suitest device ${deviceId} found on page ${page}, in ${secondsTime} seconds`;

        // Currently useful for building a case to get Suitest to give us query params.
        logger.log(info.CYAN());

        return device;
      }

      if (next) {
        endpoint = next.replace(/^.*(devices)/, '$1');
      }
      page++;
    } while (next);

    logger.error(
      `Device "${deviceId}" not found in suitest (searched ${page} page) - please check the device ID.`
        .RED_BACKGROUND()
        .BLACK(),
    );

    return undefined;
  } catch (e) {
    logger.error(
      `Error finding suitest device details for device "${deviceId}":`,
      e,
    );
  }

  return undefined;
};

const getStaticDevice = () => {
  if (process.env.SUITEST_DEVICE_ID) {
    return {
      suitestDeviceId: process.env.SUITEST_DEVICE_ID,
      headspinDeviceId: undefined,
      name: 'local device',
      deviceAddress: undefined,
    };
  }
  throw new Error('SUITEST_DEVICE_ID is not set.');
};

const isAvailable = (deviceDetails) =>
  suitestAvailableStatuses.includes(deviceDetails.status);

module.exports = {
  fetchAPI,
  upload,
  fetchSuitestDeviceDetails,
  getStaticDevice,
  isAvailable,
};
