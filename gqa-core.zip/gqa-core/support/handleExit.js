const { logger } = require('./logger');

/*
 Some libraries (such as 'suitest-js-api') cause the executed system process to be 'detached' as a 
 child (still not 100% surre how). This means CRTL+C, for example, will leave the cucumber process
 running in your terminal (even after cnotrol has been returned to you).

 This prevents that situation and ensures node exits cleanly and kills all children.
 */
const cleanExit = (signal) => {
  logger.log(`"${signal}" signal receieved - exiting ...`);
  process.exit(
    {
      SIGINT: 2,
      SIGQUIT: 3,
      SIGTERM: 15,
    }[signal],
  );
};

process.on('SIGINT', cleanExit);
process.on('SIGTERM', cleanExit);
process.on('SIGQUIT', cleanExit);
