// Copyright text placeholder, Warner Bros. Discovery, Inc.

import colors from './colors';
import { isError, isObject } from './TypeUtils';

/**
 * The call signature of the methods used to actually write the log entries.
 */
type LoggingFunction = (...args: unknown[]) => void;

/**
 * The possible severity levels of a log message. "log" and "debug" are equivalent.
 */
type LoggingLevel = 'log' | 'debug' | 'info' | 'warn' | 'error';

/**
 * A map from logging levels to their corresponding console logging functions.
 *
 * All values in `LoggingLevel` must have a corresponding logging function.
 */
const LOGGING_FUNCTIONS: Record<LoggingLevel, LoggingFunction> = {
  /* eslint-disable no-console */
  log: console.log,
  debug: console.log,
  info: console.info,
  warn: console.warn,
  error: console.error,
  /* eslint-enable no-console */
};

/**
 * A map from logging levels to the color control codes determining the colors in which they should
 * be displayed in the console log. 'log', 'debug', and 'info' all display in the default color.
 *
 * All values in `LoggingLevel` must have a corresponding display color code.
 */
const DISPLAY_COLOR_CODES: Record<LoggingLevel, string> = {
  log: '',
  debug: '',
  info: '',
  warn: colors.YELLOW,
  error: colors.RED_BOLD,
};

/**
 * An object that logs messages at different levels of severity, with a prefix containing
 * the timestamp, the pid, and the severity. `warn()` logs to the console in yellow,
 * and `error()` logs to the console in bold red.
 *
 * At present, the logger only logs to the console. In the future, it may log to other destinations.
 */
export interface ILogger {
  log(firstArg: unknown, ...otherArgs: unknown[]): void;
  debug(firstArg: unknown, ...otherArgs: unknown[]): void;
  info(firstArg: unknown, ...otherArgs: unknown[]): void;
  warn(firstArg: unknown, ...otherArgs: unknown[]): void;
  error(firstArg: unknown, ...otherArgs: unknown[]): void;
}

/**
 * A singleton class for logging messages. At the moment, all of the logging messages
 * are written to the console.
 *
 * Attempting to call the private constructor (e.g., from Javascript) will throw an exception.
 */
class LoggerImpl implements ILogger {
  private static _isLoggerSingletonCreated: boolean = false;

  public constructor() {
    if (LoggerImpl._isLoggerSingletonCreated) {
      throw new Error(
        'Logger is a singleton, and no additional instances can be constructed. Please call Logger.getInstance() to obtain the singleton instance.',
      );
    }

    LoggerImpl._isLoggerSingletonCreated = true;
  }

  public log(firstArg: unknown, ...otherArgs: unknown[]): void {
    this._proxy('log', firstArg, ...otherArgs);
  }

  public debug(firstArg: unknown, ...otherArgs: unknown[]): void {
    this._proxy('debug', firstArg, ...otherArgs);
  }

  public info(firstArg: unknown, ...otherArgs: unknown[]): void {
    this._proxy('info', firstArg, ...otherArgs);
  }

  public warn(firstArg: unknown, ...otherArgs: unknown[]): void {
    this._proxy('warn', firstArg, ...otherArgs);
  }

  public error(firstArg: unknown, ...otherArgs: unknown[]): void {
    this._proxy('error', firstArg, ...otherArgs);
  }

  private _proxy(
    logLevel: LoggingLevel,
    firstArg: unknown,
    ...otherArgs: unknown[]
  ): void {
    if (firstArg === undefined) {
      throw new Error(
        'Logging functions must be called with at least one argument.',
      );
    }

    LOGGING_FUNCTIONS[logLevel](
      this._getPrefix(logLevel),
      this._stringify(firstArg),
      ...otherArgs,
    );
  }

  private _getPrefix(logLevel: LoggingLevel): string {
    const colorCode: string = DISPLAY_COLOR_CODES[logLevel];
    const timestamp: string = new Date(Date.now()).toISOString();

    return `${colorCode}${timestamp}|${process.pid}|${logLevel}:`;
  }

  private _stringify(firstArg: unknown): string {
    if (isError(firstArg)) {
      return `Error: ${firstArg.message}\nStack: ${firstArg.stack}`;
    }
    if (isObject(firstArg)) {
      return JSON.stringify(firstArg, undefined, 2);
    }
    return `${firstArg}`;
  }
}

export const logger: ILogger = new LoggerImpl();
