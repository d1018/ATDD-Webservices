const yaml = require('js-yaml');
const path = require('path');
const fs = require('fs');

const { runtimeGeolocation, runtimeProject } = require('./runtimeConfig');

const projectPath = process.cwd();

const projectValue = runtimeProject();

const root = path.resolve(projectPath, 'projects', projectValue);

// Temporary measure - remove this once we're no longer copying yaml.
const yamlKey = (key) => `:${key}`;

const getValue = (data, keyPath) => {
  const [parentKey, ...childKeys] = keyPath.toString().split('.');

  return childKeys.length === 0
    ? data[yamlKey(keyPath)]
    : getValue(data[yamlKey(parentKey)], childKeys.join('.'));
};

const loadYML = () => {
  const geoLocation = runtimeGeolocation();
  const ymlFile = path.join(
    root,
    'testData',
    `${geoLocation.toLowerCase()}.yml`,
  );
  const key = yamlKey(projectValue);
  const ymlDefinition = yaml.load(fs.readFileSync(ymlFile), {
    encoding: 'utf-8',
  });

  return ymlDefinition[key];
};

/**
 * Gets a content value.
 *
 * @param {string} keyPath dot-separated key path, i.e "show_with_seasons.show_name_atv"
 * @returns {any} The value from the object that matches the keyPath (string / array etc...)
 */
const getContent = (keyPath) => getValue(loadYML(), keyPath);

module.exports = {
  getContent,
};
